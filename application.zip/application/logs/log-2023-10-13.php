<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-13 17:16:24 --> Config Class Initialized
INFO - 2023-10-13 17:16:24 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:16:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:16:25 --> Utf8 Class Initialized
INFO - 2023-10-13 17:16:25 --> URI Class Initialized
DEBUG - 2023-10-13 17:16:25 --> No URI present. Default controller set.
INFO - 2023-10-13 17:16:25 --> Router Class Initialized
INFO - 2023-10-13 17:16:25 --> Output Class Initialized
INFO - 2023-10-13 17:16:25 --> Security Class Initialized
DEBUG - 2023-10-13 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:16:25 --> Input Class Initialized
INFO - 2023-10-13 17:16:25 --> Language Class Initialized
INFO - 2023-10-13 17:16:25 --> Loader Class Initialized
INFO - 2023-10-13 17:16:25 --> Helper loaded: url_helper
INFO - 2023-10-13 17:16:25 --> Helper loaded: file_helper
INFO - 2023-10-13 17:16:26 --> Database Driver Class Initialized
INFO - 2023-10-13 17:16:26 --> Email Class Initialized
DEBUG - 2023-10-13 17:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:16:26 --> Controller Class Initialized
INFO - 2023-10-13 17:16:26 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:16:26 --> Model "Home_model" initialized
INFO - 2023-10-13 17:16:26 --> Helper loaded: download_helper
INFO - 2023-10-13 17:16:26 --> Helper loaded: form_helper
INFO - 2023-10-13 17:16:26 --> Form Validation Class Initialized
INFO - 2023-10-13 17:16:27 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:16:27 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:16:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:16:27 --> Final output sent to browser
DEBUG - 2023-10-13 17:16:27 --> Total execution time: 2.4322
INFO - 2023-10-13 17:24:13 --> Config Class Initialized
INFO - 2023-10-13 17:24:13 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:24:13 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:24:13 --> Utf8 Class Initialized
INFO - 2023-10-13 17:24:13 --> URI Class Initialized
DEBUG - 2023-10-13 17:24:13 --> No URI present. Default controller set.
INFO - 2023-10-13 17:24:13 --> Router Class Initialized
INFO - 2023-10-13 17:24:13 --> Output Class Initialized
INFO - 2023-10-13 17:24:13 --> Security Class Initialized
DEBUG - 2023-10-13 17:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:24:13 --> Input Class Initialized
INFO - 2023-10-13 17:24:13 --> Language Class Initialized
INFO - 2023-10-13 17:24:13 --> Loader Class Initialized
INFO - 2023-10-13 17:24:13 --> Helper loaded: url_helper
INFO - 2023-10-13 17:24:13 --> Helper loaded: file_helper
INFO - 2023-10-13 17:24:13 --> Database Driver Class Initialized
INFO - 2023-10-13 17:24:13 --> Email Class Initialized
DEBUG - 2023-10-13 17:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:24:13 --> Controller Class Initialized
INFO - 2023-10-13 17:24:13 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:24:13 --> Model "Home_model" initialized
INFO - 2023-10-13 17:24:13 --> Helper loaded: download_helper
INFO - 2023-10-13 17:24:13 --> Helper loaded: form_helper
INFO - 2023-10-13 17:24:13 --> Form Validation Class Initialized
INFO - 2023-10-13 17:24:14 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:24:14 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:24:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:24:14 --> Final output sent to browser
DEBUG - 2023-10-13 17:24:14 --> Total execution time: 0.5383
INFO - 2023-10-13 17:24:19 --> Config Class Initialized
INFO - 2023-10-13 17:24:19 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:24:19 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:24:19 --> Utf8 Class Initialized
INFO - 2023-10-13 17:24:19 --> URI Class Initialized
DEBUG - 2023-10-13 17:24:19 --> No URI present. Default controller set.
INFO - 2023-10-13 17:24:19 --> Router Class Initialized
INFO - 2023-10-13 17:24:19 --> Output Class Initialized
INFO - 2023-10-13 17:24:19 --> Security Class Initialized
DEBUG - 2023-10-13 17:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:24:19 --> Input Class Initialized
INFO - 2023-10-13 17:24:19 --> Language Class Initialized
INFO - 2023-10-13 17:24:19 --> Loader Class Initialized
INFO - 2023-10-13 17:24:19 --> Helper loaded: url_helper
INFO - 2023-10-13 17:24:19 --> Helper loaded: file_helper
INFO - 2023-10-13 17:24:19 --> Database Driver Class Initialized
INFO - 2023-10-13 17:24:19 --> Email Class Initialized
DEBUG - 2023-10-13 17:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:24:19 --> Controller Class Initialized
INFO - 2023-10-13 17:24:19 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:24:19 --> Model "Home_model" initialized
INFO - 2023-10-13 17:24:19 --> Helper loaded: download_helper
INFO - 2023-10-13 17:24:19 --> Helper loaded: form_helper
INFO - 2023-10-13 17:24:19 --> Form Validation Class Initialized
INFO - 2023-10-13 17:24:19 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:24:19 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:24:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:24:19 --> Final output sent to browser
DEBUG - 2023-10-13 17:24:19 --> Total execution time: 0.0828
INFO - 2023-10-13 17:25:30 --> Config Class Initialized
INFO - 2023-10-13 17:25:30 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:25:30 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:25:30 --> Utf8 Class Initialized
INFO - 2023-10-13 17:25:30 --> URI Class Initialized
DEBUG - 2023-10-13 17:25:30 --> No URI present. Default controller set.
INFO - 2023-10-13 17:25:30 --> Router Class Initialized
INFO - 2023-10-13 17:25:30 --> Output Class Initialized
INFO - 2023-10-13 17:25:30 --> Security Class Initialized
DEBUG - 2023-10-13 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:25:30 --> Input Class Initialized
INFO - 2023-10-13 17:25:30 --> Language Class Initialized
INFO - 2023-10-13 17:25:30 --> Loader Class Initialized
INFO - 2023-10-13 17:25:30 --> Helper loaded: url_helper
INFO - 2023-10-13 17:25:30 --> Helper loaded: file_helper
INFO - 2023-10-13 17:25:30 --> Database Driver Class Initialized
INFO - 2023-10-13 17:25:30 --> Email Class Initialized
DEBUG - 2023-10-13 17:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:25:30 --> Controller Class Initialized
INFO - 2023-10-13 17:25:30 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:25:30 --> Model "Home_model" initialized
INFO - 2023-10-13 17:25:30 --> Helper loaded: download_helper
INFO - 2023-10-13 17:25:30 --> Helper loaded: form_helper
INFO - 2023-10-13 17:25:30 --> Form Validation Class Initialized
INFO - 2023-10-13 17:25:30 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:25:30 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:25:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:25:30 --> Final output sent to browser
DEBUG - 2023-10-13 17:25:30 --> Total execution time: 0.1860
INFO - 2023-10-13 17:29:49 --> Config Class Initialized
INFO - 2023-10-13 17:29:49 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:29:49 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:29:49 --> Utf8 Class Initialized
INFO - 2023-10-13 17:29:49 --> URI Class Initialized
DEBUG - 2023-10-13 17:29:49 --> No URI present. Default controller set.
INFO - 2023-10-13 17:29:49 --> Router Class Initialized
INFO - 2023-10-13 17:29:49 --> Output Class Initialized
INFO - 2023-10-13 17:29:49 --> Security Class Initialized
DEBUG - 2023-10-13 17:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:29:49 --> Input Class Initialized
INFO - 2023-10-13 17:29:49 --> Language Class Initialized
INFO - 2023-10-13 17:29:49 --> Loader Class Initialized
INFO - 2023-10-13 17:29:49 --> Helper loaded: url_helper
INFO - 2023-10-13 17:29:49 --> Helper loaded: file_helper
INFO - 2023-10-13 17:29:49 --> Database Driver Class Initialized
INFO - 2023-10-13 17:29:49 --> Email Class Initialized
DEBUG - 2023-10-13 17:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:29:49 --> Controller Class Initialized
INFO - 2023-10-13 17:29:49 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:29:49 --> Model "Home_model" initialized
INFO - 2023-10-13 17:29:49 --> Helper loaded: download_helper
INFO - 2023-10-13 17:29:49 --> Helper loaded: form_helper
INFO - 2023-10-13 17:29:49 --> Form Validation Class Initialized
INFO - 2023-10-13 17:29:49 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:29:49 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:29:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:29:49 --> Final output sent to browser
DEBUG - 2023-10-13 17:29:49 --> Total execution time: 0.2671
INFO - 2023-10-13 17:32:03 --> Config Class Initialized
INFO - 2023-10-13 17:32:03 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:32:03 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:03 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:03 --> URI Class Initialized
INFO - 2023-10-13 17:32:03 --> Router Class Initialized
INFO - 2023-10-13 17:32:03 --> Output Class Initialized
INFO - 2023-10-13 17:32:03 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:03 --> Input Class Initialized
INFO - 2023-10-13 17:32:03 --> Language Class Initialized
ERROR - 2023-10-13 17:32:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:32:04 --> Config Class Initialized
INFO - 2023-10-13 17:32:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:32:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:04 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:04 --> URI Class Initialized
INFO - 2023-10-13 17:32:04 --> Router Class Initialized
INFO - 2023-10-13 17:32:04 --> Output Class Initialized
INFO - 2023-10-13 17:32:04 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:05 --> Config Class Initialized
INFO - 2023-10-13 17:32:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:32:05 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:05 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:05 --> URI Class Initialized
INFO - 2023-10-13 17:32:05 --> Router Class Initialized
INFO - 2023-10-13 17:32:05 --> Output Class Initialized
INFO - 2023-10-13 17:32:05 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:05 --> Input Class Initialized
INFO - 2023-10-13 17:32:05 --> Language Class Initialized
ERROR - 2023-10-13 17:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:32:05 --> Config Class Initialized
INFO - 2023-10-13 17:32:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:32:05 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:05 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:05 --> URI Class Initialized
INFO - 2023-10-13 17:32:05 --> Router Class Initialized
INFO - 2023-10-13 17:32:05 --> Output Class Initialized
INFO - 2023-10-13 17:32:05 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:05 --> Input Class Initialized
INFO - 2023-10-13 17:32:05 --> Language Class Initialized
ERROR - 2023-10-13 17:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:32:07 --> Input Class Initialized
INFO - 2023-10-13 17:32:07 --> Language Class Initialized
ERROR - 2023-10-13 17:32:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:32:08 --> Config Class Initialized
INFO - 2023-10-13 17:32:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:32:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:08 --> Config Class Initialized
INFO - 2023-10-13 17:32:08 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:08 --> Config Class Initialized
INFO - 2023-10-13 17:32:08 --> Hooks Class Initialized
INFO - 2023-10-13 17:32:09 --> Hooks Class Initialized
INFO - 2023-10-13 17:32:09 --> URI Class Initialized
INFO - 2023-10-13 17:32:09 --> Router Class Initialized
DEBUG - 2023-10-13 17:32:09 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:09 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:09 --> URI Class Initialized
INFO - 2023-10-13 17:32:09 --> Router Class Initialized
INFO - 2023-10-13 17:32:09 --> Output Class Initialized
INFO - 2023-10-13 17:32:09 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:09 --> Input Class Initialized
INFO - 2023-10-13 17:32:09 --> Language Class Initialized
ERROR - 2023-10-13 17:32:09 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-13 17:32:09 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:32:09 --> Output Class Initialized
INFO - 2023-10-13 17:32:09 --> Utf8 Class Initialized
INFO - 2023-10-13 17:32:09 --> Security Class Initialized
DEBUG - 2023-10-13 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:09 --> URI Class Initialized
INFO - 2023-10-13 17:32:09 --> Router Class Initialized
INFO - 2023-10-13 17:32:09 --> Input Class Initialized
INFO - 2023-10-13 17:32:09 --> Output Class Initialized
INFO - 2023-10-13 17:32:09 --> Language Class Initialized
INFO - 2023-10-13 17:32:09 --> Security Class Initialized
ERROR - 2023-10-13 17:32:09 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-13 17:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:32:09 --> Input Class Initialized
INFO - 2023-10-13 17:32:09 --> Language Class Initialized
ERROR - 2023-10-13 17:32:09 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:05 --> Config Class Initialized
INFO - 2023-10-13 17:41:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:05 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:05 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:05 --> URI Class Initialized
DEBUG - 2023-10-13 17:41:05 --> No URI present. Default controller set.
INFO - 2023-10-13 17:41:05 --> Router Class Initialized
INFO - 2023-10-13 17:41:06 --> Output Class Initialized
INFO - 2023-10-13 17:41:06 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:06 --> Input Class Initialized
INFO - 2023-10-13 17:41:06 --> Language Class Initialized
INFO - 2023-10-13 17:41:06 --> Loader Class Initialized
INFO - 2023-10-13 17:41:06 --> Helper loaded: url_helper
INFO - 2023-10-13 17:41:06 --> Helper loaded: file_helper
INFO - 2023-10-13 17:41:06 --> Database Driver Class Initialized
INFO - 2023-10-13 17:41:06 --> Email Class Initialized
DEBUG - 2023-10-13 17:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:41:06 --> Controller Class Initialized
INFO - 2023-10-13 17:41:06 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:41:06 --> Model "Home_model" initialized
INFO - 2023-10-13 17:41:06 --> Helper loaded: download_helper
INFO - 2023-10-13 17:41:06 --> Helper loaded: form_helper
INFO - 2023-10-13 17:41:06 --> Form Validation Class Initialized
INFO - 2023-10-13 17:41:06 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:41:06 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:41:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:41:07 --> Final output sent to browser
DEBUG - 2023-10-13 17:41:07 --> Total execution time: 1.0787
INFO - 2023-10-13 17:41:08 --> Config Class Initialized
INFO - 2023-10-13 17:41:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:08 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:08 --> URI Class Initialized
INFO - 2023-10-13 17:41:08 --> Router Class Initialized
INFO - 2023-10-13 17:41:08 --> Output Class Initialized
INFO - 2023-10-13 17:41:08 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:08 --> Input Class Initialized
INFO - 2023-10-13 17:41:08 --> Language Class Initialized
ERROR - 2023-10-13 17:41:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:11 --> Config Class Initialized
INFO - 2023-10-13 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:11 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:11 --> URI Class Initialized
INFO - 2023-10-13 17:41:11 --> Router Class Initialized
INFO - 2023-10-13 17:41:11 --> Output Class Initialized
INFO - 2023-10-13 17:41:11 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:11 --> Input Class Initialized
INFO - 2023-10-13 17:41:11 --> Language Class Initialized
ERROR - 2023-10-13 17:41:11 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:12 --> Config Class Initialized
INFO - 2023-10-13 17:41:12 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:12 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:12 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:12 --> URI Class Initialized
INFO - 2023-10-13 17:41:12 --> Router Class Initialized
INFO - 2023-10-13 17:41:12 --> Output Class Initialized
INFO - 2023-10-13 17:41:12 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:12 --> Input Class Initialized
INFO - 2023-10-13 17:41:12 --> Language Class Initialized
ERROR - 2023-10-13 17:41:12 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:13 --> Config Class Initialized
INFO - 2023-10-13 17:41:13 --> Config Class Initialized
INFO - 2023-10-13 17:41:13 --> Hooks Class Initialized
INFO - 2023-10-13 17:41:13 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:13 --> UTF-8 Support Enabled
DEBUG - 2023-10-13 17:41:13 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:13 --> Config Class Initialized
INFO - 2023-10-13 17:41:13 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:13 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:13 --> URI Class Initialized
INFO - 2023-10-13 17:41:13 --> URI Class Initialized
INFO - 2023-10-13 17:41:13 --> Router Class Initialized
INFO - 2023-10-13 17:41:13 --> Output Class Initialized
INFO - 2023-10-13 17:41:13 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:13 --> Input Class Initialized
INFO - 2023-10-13 17:41:13 --> Language Class Initialized
ERROR - 2023-10-13 17:41:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:14 --> Config Class Initialized
INFO - 2023-10-13 17:41:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:14 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:14 --> URI Class Initialized
INFO - 2023-10-13 17:41:14 --> Router Class Initialized
INFO - 2023-10-13 17:41:14 --> Output Class Initialized
INFO - 2023-10-13 17:41:14 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:14 --> Input Class Initialized
INFO - 2023-10-13 17:41:14 --> Language Class Initialized
ERROR - 2023-10-13 17:41:14 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:14 --> Router Class Initialized
INFO - 2023-10-13 17:41:14 --> Output Class Initialized
INFO - 2023-10-13 17:41:14 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:14 --> Input Class Initialized
INFO - 2023-10-13 17:41:14 --> Language Class Initialized
ERROR - 2023-10-13 17:41:14 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:15 --> Hooks Class Initialized
INFO - 2023-10-13 17:41:39 --> Config Class Initialized
INFO - 2023-10-13 17:41:39 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:40 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:40 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:40 --> URI Class Initialized
DEBUG - 2023-10-13 17:41:40 --> No URI present. Default controller set.
INFO - 2023-10-13 17:41:40 --> Router Class Initialized
INFO - 2023-10-13 17:41:40 --> Output Class Initialized
INFO - 2023-10-13 17:41:40 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:40 --> Input Class Initialized
INFO - 2023-10-13 17:41:40 --> Language Class Initialized
INFO - 2023-10-13 17:41:40 --> Loader Class Initialized
INFO - 2023-10-13 17:41:40 --> Helper loaded: url_helper
INFO - 2023-10-13 17:41:40 --> Helper loaded: file_helper
INFO - 2023-10-13 17:41:40 --> Database Driver Class Initialized
INFO - 2023-10-13 17:41:40 --> Email Class Initialized
DEBUG - 2023-10-13 17:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:41:40 --> Controller Class Initialized
INFO - 2023-10-13 17:41:40 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:41:40 --> Model "Home_model" initialized
INFO - 2023-10-13 17:41:40 --> Helper loaded: download_helper
INFO - 2023-10-13 17:41:40 --> Helper loaded: form_helper
INFO - 2023-10-13 17:41:40 --> Form Validation Class Initialized
INFO - 2023-10-13 17:41:40 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:41:40 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:41:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:41:40 --> Final output sent to browser
DEBUG - 2023-10-13 17:41:41 --> Total execution time: 1.5335
INFO - 2023-10-13 17:41:46 --> Config Class Initialized
INFO - 2023-10-13 17:41:46 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:46 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:46 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:46 --> URI Class Initialized
INFO - 2023-10-13 17:41:46 --> Router Class Initialized
INFO - 2023-10-13 17:41:46 --> Output Class Initialized
INFO - 2023-10-13 17:41:46 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:50 --> Input Class Initialized
INFO - 2023-10-13 17:41:50 --> Language Class Initialized
ERROR - 2023-10-13 17:41:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:51 --> Config Class Initialized
INFO - 2023-10-13 17:41:51 --> Config Class Initialized
INFO - 2023-10-13 17:41:51 --> Config Class Initialized
INFO - 2023-10-13 17:41:51 --> Hooks Class Initialized
INFO - 2023-10-13 17:41:51 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:51 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:51 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:51 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:51 --> Utf8 Class Initialized
DEBUG - 2023-10-13 17:41:51 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:51 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:51 --> URI Class Initialized
INFO - 2023-10-13 17:41:51 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:51 --> Router Class Initialized
INFO - 2023-10-13 17:41:51 --> URI Class Initialized
INFO - 2023-10-13 17:41:51 --> URI Class Initialized
INFO - 2023-10-13 17:41:51 --> Output Class Initialized
INFO - 2023-10-13 17:41:51 --> Router Class Initialized
INFO - 2023-10-13 17:41:51 --> Security Class Initialized
INFO - 2023-10-13 17:41:52 --> Config Class Initialized
INFO - 2023-10-13 17:41:52 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:52 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:52 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:52 --> URI Class Initialized
INFO - 2023-10-13 17:41:52 --> Router Class Initialized
INFO - 2023-10-13 17:41:52 --> Output Class Initialized
INFO - 2023-10-13 17:41:52 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:52 --> Input Class Initialized
INFO - 2023-10-13 17:41:52 --> Language Class Initialized
ERROR - 2023-10-13 17:41:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-13 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:55 --> Output Class Initialized
INFO - 2023-10-13 17:41:55 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:55 --> Input Class Initialized
INFO - 2023-10-13 17:41:55 --> Language Class Initialized
ERROR - 2023-10-13 17:41:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:55 --> Router Class Initialized
INFO - 2023-10-13 17:41:55 --> Config Class Initialized
INFO - 2023-10-13 17:41:55 --> Config Class Initialized
INFO - 2023-10-13 17:41:55 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:41:55 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:55 --> Input Class Initialized
INFO - 2023-10-13 17:41:55 --> Output Class Initialized
INFO - 2023-10-13 17:41:55 --> Hooks Class Initialized
INFO - 2023-10-13 17:41:55 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:55 --> Security Class Initialized
INFO - 2023-10-13 17:41:55 --> Language Class Initialized
ERROR - 2023-10-13 17:41:55 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-13 17:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-13 17:41:55 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:41:55 --> URI Class Initialized
INFO - 2023-10-13 17:41:55 --> Utf8 Class Initialized
INFO - 2023-10-13 17:41:55 --> Input Class Initialized
INFO - 2023-10-13 17:41:55 --> URI Class Initialized
INFO - 2023-10-13 17:41:55 --> Router Class Initialized
INFO - 2023-10-13 17:41:55 --> Language Class Initialized
INFO - 2023-10-13 17:41:55 --> Router Class Initialized
ERROR - 2023-10-13 17:41:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:55 --> Output Class Initialized
INFO - 2023-10-13 17:41:55 --> Output Class Initialized
INFO - 2023-10-13 17:41:55 --> Security Class Initialized
DEBUG - 2023-10-13 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:55 --> Security Class Initialized
INFO - 2023-10-13 17:41:55 --> Input Class Initialized
DEBUG - 2023-10-13 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:41:55 --> Language Class Initialized
INFO - 2023-10-13 17:41:55 --> Input Class Initialized
ERROR - 2023-10-13 17:41:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:41:55 --> Language Class Initialized
ERROR - 2023-10-13 17:41:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:09 --> Config Class Initialized
INFO - 2023-10-13 17:48:09 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:09 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:09 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:09 --> URI Class Initialized
DEBUG - 2023-10-13 17:48:09 --> No URI present. Default controller set.
INFO - 2023-10-13 17:48:09 --> Router Class Initialized
INFO - 2023-10-13 17:48:09 --> Output Class Initialized
INFO - 2023-10-13 17:48:09 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:09 --> Input Class Initialized
INFO - 2023-10-13 17:48:09 --> Language Class Initialized
INFO - 2023-10-13 17:48:09 --> Loader Class Initialized
INFO - 2023-10-13 17:48:09 --> Helper loaded: url_helper
INFO - 2023-10-13 17:48:09 --> Helper loaded: file_helper
INFO - 2023-10-13 17:48:09 --> Database Driver Class Initialized
INFO - 2023-10-13 17:48:09 --> Email Class Initialized
DEBUG - 2023-10-13 17:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:48:09 --> Controller Class Initialized
INFO - 2023-10-13 17:48:09 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:48:09 --> Model "Home_model" initialized
INFO - 2023-10-13 17:48:09 --> Helper loaded: download_helper
INFO - 2023-10-13 17:48:09 --> Helper loaded: form_helper
INFO - 2023-10-13 17:48:09 --> Form Validation Class Initialized
INFO - 2023-10-13 17:48:09 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:48:09 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:48:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:48:09 --> Final output sent to browser
DEBUG - 2023-10-13 17:48:09 --> Total execution time: 0.3316
INFO - 2023-10-13 17:48:12 --> Config Class Initialized
INFO - 2023-10-13 17:48:12 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:15 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:15 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:15 --> URI Class Initialized
INFO - 2023-10-13 17:48:15 --> Router Class Initialized
INFO - 2023-10-13 17:48:15 --> Output Class Initialized
INFO - 2023-10-13 17:48:15 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:15 --> Input Class Initialized
INFO - 2023-10-13 17:48:15 --> Language Class Initialized
ERROR - 2023-10-13 17:48:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:17 --> Config Class Initialized
INFO - 2023-10-13 17:48:17 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:17 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:17 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:17 --> URI Class Initialized
INFO - 2023-10-13 17:48:17 --> Router Class Initialized
INFO - 2023-10-13 17:48:17 --> Output Class Initialized
INFO - 2023-10-13 17:48:17 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:17 --> Input Class Initialized
INFO - 2023-10-13 17:48:17 --> Language Class Initialized
INFO - 2023-10-13 17:48:17 --> Config Class Initialized
INFO - 2023-10-13 17:48:17 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:17 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:17 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:17 --> URI Class Initialized
INFO - 2023-10-13 17:48:17 --> Router Class Initialized
INFO - 2023-10-13 17:48:17 --> Output Class Initialized
INFO - 2023-10-13 17:48:17 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:17 --> Input Class Initialized
INFO - 2023-10-13 17:48:17 --> Language Class Initialized
ERROR - 2023-10-13 17:48:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:17 --> Config Class Initialized
INFO - 2023-10-13 17:48:17 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:17 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:17 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:17 --> URI Class Initialized
INFO - 2023-10-13 17:48:17 --> Router Class Initialized
INFO - 2023-10-13 17:48:17 --> Output Class Initialized
INFO - 2023-10-13 17:48:17 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:17 --> Input Class Initialized
INFO - 2023-10-13 17:48:17 --> Language Class Initialized
ERROR - 2023-10-13 17:48:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:21 --> Config Class Initialized
INFO - 2023-10-13 17:48:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:21 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:21 --> URI Class Initialized
INFO - 2023-10-13 17:48:21 --> Router Class Initialized
INFO - 2023-10-13 17:48:21 --> Output Class Initialized
INFO - 2023-10-13 17:48:21 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:21 --> Input Class Initialized
INFO - 2023-10-13 17:48:21 --> Language Class Initialized
ERROR - 2023-10-13 17:48:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:21 --> Config Class Initialized
INFO - 2023-10-13 17:48:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:21 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:21 --> URI Class Initialized
INFO - 2023-10-13 17:48:21 --> Router Class Initialized
INFO - 2023-10-13 17:48:21 --> Output Class Initialized
INFO - 2023-10-13 17:48:21 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:21 --> Input Class Initialized
INFO - 2023-10-13 17:48:21 --> Language Class Initialized
ERROR - 2023-10-13 17:48:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:48:21 --> Config Class Initialized
INFO - 2023-10-13 17:48:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:48:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:48:21 --> Utf8 Class Initialized
INFO - 2023-10-13 17:48:21 --> URI Class Initialized
INFO - 2023-10-13 17:48:21 --> Router Class Initialized
INFO - 2023-10-13 17:48:21 --> Output Class Initialized
INFO - 2023-10-13 17:48:21 --> Security Class Initialized
DEBUG - 2023-10-13 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:48:21 --> Input Class Initialized
INFO - 2023-10-13 17:48:21 --> Language Class Initialized
ERROR - 2023-10-13 17:48:21 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-13 17:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:01 --> Config Class Initialized
INFO - 2023-10-13 17:50:01 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:01 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:01 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:01 --> URI Class Initialized
DEBUG - 2023-10-13 17:50:01 --> No URI present. Default controller set.
INFO - 2023-10-13 17:50:01 --> Router Class Initialized
INFO - 2023-10-13 17:50:01 --> Output Class Initialized
INFO - 2023-10-13 17:50:01 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:01 --> Input Class Initialized
INFO - 2023-10-13 17:50:01 --> Language Class Initialized
INFO - 2023-10-13 17:50:01 --> Loader Class Initialized
INFO - 2023-10-13 17:50:01 --> Helper loaded: url_helper
INFO - 2023-10-13 17:50:01 --> Helper loaded: file_helper
INFO - 2023-10-13 17:50:01 --> Database Driver Class Initialized
INFO - 2023-10-13 17:50:01 --> Email Class Initialized
DEBUG - 2023-10-13 17:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:50:01 --> Controller Class Initialized
INFO - 2023-10-13 17:50:01 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:50:01 --> Model "Home_model" initialized
INFO - 2023-10-13 17:50:01 --> Helper loaded: download_helper
INFO - 2023-10-13 17:50:01 --> Helper loaded: form_helper
INFO - 2023-10-13 17:50:01 --> Form Validation Class Initialized
INFO - 2023-10-13 17:50:01 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:50:02 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:50:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:50:02 --> Final output sent to browser
DEBUG - 2023-10-13 17:50:02 --> Total execution time: 1.3749
INFO - 2023-10-13 17:50:06 --> Config Class Initialized
INFO - 2023-10-13 17:50:06 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:06 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:06 --> URI Class Initialized
INFO - 2023-10-13 17:50:06 --> Router Class Initialized
INFO - 2023-10-13 17:50:06 --> Output Class Initialized
INFO - 2023-10-13 17:50:06 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:06 --> Input Class Initialized
INFO - 2023-10-13 17:50:06 --> Language Class Initialized
ERROR - 2023-10-13 17:50:06 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:06 --> Config Class Initialized
INFO - 2023-10-13 17:50:06 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:06 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:06 --> URI Class Initialized
INFO - 2023-10-13 17:50:06 --> Router Class Initialized
INFO - 2023-10-13 17:50:06 --> Output Class Initialized
INFO - 2023-10-13 17:50:06 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:06 --> Input Class Initialized
INFO - 2023-10-13 17:50:06 --> Language Class Initialized
ERROR - 2023-10-13 17:50:06 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:06 --> Config Class Initialized
INFO - 2023-10-13 17:50:06 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:06 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:06 --> URI Class Initialized
INFO - 2023-10-13 17:50:06 --> Router Class Initialized
INFO - 2023-10-13 17:50:06 --> Output Class Initialized
INFO - 2023-10-13 17:50:06 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:06 --> Input Class Initialized
INFO - 2023-10-13 17:50:06 --> Language Class Initialized
ERROR - 2023-10-13 17:50:06 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:06 --> Config Class Initialized
INFO - 2023-10-13 17:50:06 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:06 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:06 --> URI Class Initialized
INFO - 2023-10-13 17:50:06 --> Router Class Initialized
INFO - 2023-10-13 17:50:06 --> Output Class Initialized
INFO - 2023-10-13 17:50:06 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:06 --> Input Class Initialized
INFO - 2023-10-13 17:50:06 --> Language Class Initialized
ERROR - 2023-10-13 17:50:06 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:08 --> Config Class Initialized
INFO - 2023-10-13 17:50:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:08 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:08 --> URI Class Initialized
INFO - 2023-10-13 17:50:08 --> Router Class Initialized
INFO - 2023-10-13 17:50:08 --> Output Class Initialized
INFO - 2023-10-13 17:50:08 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:08 --> Input Class Initialized
INFO - 2023-10-13 17:50:08 --> Language Class Initialized
ERROR - 2023-10-13 17:50:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:08 --> Config Class Initialized
INFO - 2023-10-13 17:50:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:08 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:08 --> URI Class Initialized
INFO - 2023-10-13 17:50:08 --> Router Class Initialized
INFO - 2023-10-13 17:50:08 --> Output Class Initialized
INFO - 2023-10-13 17:50:08 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:08 --> Input Class Initialized
INFO - 2023-10-13 17:50:08 --> Language Class Initialized
ERROR - 2023-10-13 17:50:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:08 --> Config Class Initialized
INFO - 2023-10-13 17:50:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:08 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:08 --> URI Class Initialized
INFO - 2023-10-13 17:50:08 --> Router Class Initialized
INFO - 2023-10-13 17:50:08 --> Output Class Initialized
INFO - 2023-10-13 17:50:08 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:08 --> Input Class Initialized
INFO - 2023-10-13 17:50:08 --> Language Class Initialized
ERROR - 2023-10-13 17:50:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:50:57 --> Config Class Initialized
INFO - 2023-10-13 17:50:57 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:50:57 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:50:58 --> Utf8 Class Initialized
INFO - 2023-10-13 17:50:58 --> URI Class Initialized
DEBUG - 2023-10-13 17:50:58 --> No URI present. Default controller set.
INFO - 2023-10-13 17:50:58 --> Router Class Initialized
INFO - 2023-10-13 17:50:58 --> Output Class Initialized
INFO - 2023-10-13 17:50:58 --> Security Class Initialized
DEBUG - 2023-10-13 17:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:50:58 --> Input Class Initialized
INFO - 2023-10-13 17:50:58 --> Language Class Initialized
INFO - 2023-10-13 17:50:58 --> Loader Class Initialized
INFO - 2023-10-13 17:50:58 --> Helper loaded: url_helper
INFO - 2023-10-13 17:50:58 --> Helper loaded: file_helper
INFO - 2023-10-13 17:50:58 --> Database Driver Class Initialized
INFO - 2023-10-13 17:50:58 --> Email Class Initialized
DEBUG - 2023-10-13 17:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:50:58 --> Controller Class Initialized
INFO - 2023-10-13 17:50:58 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:50:58 --> Model "Home_model" initialized
INFO - 2023-10-13 17:50:58 --> Helper loaded: download_helper
INFO - 2023-10-13 17:50:58 --> Helper loaded: form_helper
INFO - 2023-10-13 17:50:58 --> Form Validation Class Initialized
INFO - 2023-10-13 17:50:58 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:50:58 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:50:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:50:58 --> Final output sent to browser
DEBUG - 2023-10-13 17:50:58 --> Total execution time: 0.2374
INFO - 2023-10-13 17:51:00 --> Config Class Initialized
INFO - 2023-10-13 17:51:02 --> Config Class Initialized
INFO - 2023-10-13 17:51:02 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:51:02 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:51:02 --> Utf8 Class Initialized
INFO - 2023-10-13 17:51:02 --> URI Class Initialized
INFO - 2023-10-13 17:51:02 --> Router Class Initialized
INFO - 2023-10-13 17:51:02 --> Output Class Initialized
INFO - 2023-10-13 17:51:02 --> Security Class Initialized
DEBUG - 2023-10-13 17:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:51:02 --> Input Class Initialized
INFO - 2023-10-13 17:51:02 --> Language Class Initialized
ERROR - 2023-10-13 17:51:02 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:51:02 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:51:02 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:51:03 --> Utf8 Class Initialized
INFO - 2023-10-13 17:51:05 --> URI Class Initialized
INFO - 2023-10-13 17:51:05 --> Router Class Initialized
INFO - 2023-10-13 17:51:05 --> Output Class Initialized
INFO - 2023-10-13 17:51:05 --> Security Class Initialized
DEBUG - 2023-10-13 17:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:51:05 --> Input Class Initialized
INFO - 2023-10-13 17:51:05 --> Language Class Initialized
ERROR - 2023-10-13 17:51:05 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:51:53 --> Config Class Initialized
INFO - 2023-10-13 17:51:53 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:51:53 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:51:53 --> Utf8 Class Initialized
INFO - 2023-10-13 17:51:53 --> URI Class Initialized
DEBUG - 2023-10-13 17:51:53 --> No URI present. Default controller set.
INFO - 2023-10-13 17:51:53 --> Router Class Initialized
INFO - 2023-10-13 17:51:53 --> Output Class Initialized
INFO - 2023-10-13 17:51:53 --> Security Class Initialized
DEBUG - 2023-10-13 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:51:53 --> Input Class Initialized
INFO - 2023-10-13 17:51:53 --> Language Class Initialized
INFO - 2023-10-13 17:51:53 --> Loader Class Initialized
INFO - 2023-10-13 17:51:53 --> Helper loaded: url_helper
INFO - 2023-10-13 17:51:53 --> Helper loaded: file_helper
INFO - 2023-10-13 17:51:53 --> Database Driver Class Initialized
INFO - 2023-10-13 17:51:53 --> Email Class Initialized
DEBUG - 2023-10-13 17:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:51:53 --> Controller Class Initialized
INFO - 2023-10-13 17:51:53 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:51:53 --> Model "Home_model" initialized
INFO - 2023-10-13 17:51:53 --> Helper loaded: download_helper
INFO - 2023-10-13 17:51:53 --> Helper loaded: form_helper
INFO - 2023-10-13 17:51:53 --> Form Validation Class Initialized
INFO - 2023-10-13 17:51:53 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:51:53 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:51:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:51:53 --> Final output sent to browser
DEBUG - 2023-10-13 17:51:53 --> Total execution time: 0.1405
INFO - 2023-10-13 17:52:50 --> Config Class Initialized
INFO - 2023-10-13 17:52:50 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:52:50 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:52:50 --> Utf8 Class Initialized
INFO - 2023-10-13 17:52:50 --> URI Class Initialized
INFO - 2023-10-13 17:52:50 --> Router Class Initialized
INFO - 2023-10-13 17:52:50 --> Output Class Initialized
INFO - 2023-10-13 17:52:50 --> Security Class Initialized
DEBUG - 2023-10-13 17:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:52:50 --> Input Class Initialized
INFO - 2023-10-13 17:52:50 --> Language Class Initialized
ERROR - 2023-10-13 17:52:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:52:50 --> Config Class Initialized
INFO - 2023-10-13 17:52:50 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:52:50 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:52:50 --> Utf8 Class Initialized
INFO - 2023-10-13 17:52:50 --> URI Class Initialized
INFO - 2023-10-13 17:52:50 --> Router Class Initialized
INFO - 2023-10-13 17:52:50 --> Output Class Initialized
INFO - 2023-10-13 17:52:50 --> Security Class Initialized
DEBUG - 2023-10-13 17:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:52:50 --> Input Class Initialized
INFO - 2023-10-13 17:52:50 --> Language Class Initialized
ERROR - 2023-10-13 17:52:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:52:51 --> Config Class Initialized
INFO - 2023-10-13 17:52:53 --> Hooks Class Initialized
INFO - 2023-10-13 17:52:56 --> Config Class Initialized
INFO - 2023-10-13 17:52:56 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:52:56 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:52:56 --> Utf8 Class Initialized
INFO - 2023-10-13 17:52:56 --> URI Class Initialized
INFO - 2023-10-13 17:52:56 --> Router Class Initialized
INFO - 2023-10-13 17:52:56 --> Output Class Initialized
INFO - 2023-10-13 17:52:56 --> Security Class Initialized
DEBUG - 2023-10-13 17:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:52:56 --> Input Class Initialized
INFO - 2023-10-13 17:52:56 --> Language Class Initialized
ERROR - 2023-10-13 17:52:56 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:53:00 --> Config Class Initialized
INFO - 2023-10-13 17:53:00 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:53:02 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:53:03 --> Utf8 Class Initialized
INFO - 2023-10-13 17:53:03 --> URI Class Initialized
INFO - 2023-10-13 17:53:03 --> Router Class Initialized
INFO - 2023-10-13 17:53:03 --> Output Class Initialized
INFO - 2023-10-13 17:53:03 --> Security Class Initialized
DEBUG - 2023-10-13 17:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:53:03 --> Input Class Initialized
INFO - 2023-10-13 17:53:03 --> Language Class Initialized
ERROR - 2023-10-13 17:53:03 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:53:04 --> Config Class Initialized
INFO - 2023-10-13 17:53:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:53:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:53:04 --> Utf8 Class Initialized
INFO - 2023-10-13 17:53:04 --> URI Class Initialized
INFO - 2023-10-13 17:53:04 --> Router Class Initialized
INFO - 2023-10-13 17:53:04 --> Output Class Initialized
INFO - 2023-10-13 17:53:04 --> Security Class Initialized
DEBUG - 2023-10-13 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:53:04 --> Input Class Initialized
INFO - 2023-10-13 17:53:04 --> Language Class Initialized
ERROR - 2023-10-13 17:53:04 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:53:42 --> Config Class Initialized
INFO - 2023-10-13 17:53:42 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:53:42 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:53:42 --> Utf8 Class Initialized
INFO - 2023-10-13 17:53:42 --> URI Class Initialized
DEBUG - 2023-10-13 17:53:42 --> No URI present. Default controller set.
INFO - 2023-10-13 17:53:42 --> Router Class Initialized
INFO - 2023-10-13 17:53:42 --> Output Class Initialized
INFO - 2023-10-13 17:53:42 --> Security Class Initialized
DEBUG - 2023-10-13 17:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:53:42 --> Input Class Initialized
INFO - 2023-10-13 17:53:42 --> Language Class Initialized
INFO - 2023-10-13 17:53:42 --> Loader Class Initialized
INFO - 2023-10-13 17:53:42 --> Helper loaded: url_helper
INFO - 2023-10-13 17:53:42 --> Helper loaded: file_helper
INFO - 2023-10-13 17:53:42 --> Database Driver Class Initialized
INFO - 2023-10-13 17:53:43 --> Email Class Initialized
DEBUG - 2023-10-13 17:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:53:43 --> Controller Class Initialized
INFO - 2023-10-13 17:53:43 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:53:43 --> Model "Home_model" initialized
INFO - 2023-10-13 17:53:43 --> Helper loaded: download_helper
INFO - 2023-10-13 17:53:43 --> Helper loaded: form_helper
INFO - 2023-10-13 17:53:44 --> Form Validation Class Initialized
INFO - 2023-10-13 17:53:44 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:53:44 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:53:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:53:44 --> Final output sent to browser
DEBUG - 2023-10-13 17:53:44 --> Total execution time: 1.5891
INFO - 2023-10-13 17:55:08 --> Config Class Initialized
INFO - 2023-10-13 17:55:08 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:08 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:09 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:09 --> URI Class Initialized
INFO - 2023-10-13 17:55:10 --> Router Class Initialized
INFO - 2023-10-13 17:55:10 --> Output Class Initialized
INFO - 2023-10-13 17:55:10 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:10 --> Input Class Initialized
INFO - 2023-10-13 17:55:10 --> Language Class Initialized
ERROR - 2023-10-13 17:55:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:10 --> Config Class Initialized
INFO - 2023-10-13 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:10 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:10 --> URI Class Initialized
INFO - 2023-10-13 17:55:10 --> Router Class Initialized
INFO - 2023-10-13 17:55:10 --> Output Class Initialized
INFO - 2023-10-13 17:55:10 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:10 --> Input Class Initialized
INFO - 2023-10-13 17:55:10 --> Language Class Initialized
ERROR - 2023-10-13 17:55:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:10 --> Config Class Initialized
INFO - 2023-10-13 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:10 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:10 --> URI Class Initialized
INFO - 2023-10-13 17:55:10 --> Router Class Initialized
INFO - 2023-10-13 17:55:10 --> Output Class Initialized
INFO - 2023-10-13 17:55:10 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:10 --> Input Class Initialized
INFO - 2023-10-13 17:55:10 --> Language Class Initialized
ERROR - 2023-10-13 17:55:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:10 --> Config Class Initialized
INFO - 2023-10-13 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:10 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:10 --> URI Class Initialized
INFO - 2023-10-13 17:55:10 --> Router Class Initialized
INFO - 2023-10-13 17:55:10 --> Output Class Initialized
INFO - 2023-10-13 17:55:10 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:10 --> Input Class Initialized
INFO - 2023-10-13 17:55:10 --> Language Class Initialized
ERROR - 2023-10-13 17:55:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:10 --> Config Class Initialized
INFO - 2023-10-13 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:10 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:10 --> URI Class Initialized
INFO - 2023-10-13 17:55:10 --> Router Class Initialized
INFO - 2023-10-13 17:55:10 --> Output Class Initialized
INFO - 2023-10-13 17:55:10 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:10 --> Input Class Initialized
INFO - 2023-10-13 17:55:10 --> Language Class Initialized
ERROR - 2023-10-13 17:55:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:11 --> Config Class Initialized
INFO - 2023-10-13 17:55:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:12 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:12 --> URI Class Initialized
INFO - 2023-10-13 17:55:12 --> Router Class Initialized
INFO - 2023-10-13 17:55:12 --> Output Class Initialized
INFO - 2023-10-13 17:55:12 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:12 --> Input Class Initialized
INFO - 2023-10-13 17:55:12 --> Language Class Initialized
ERROR - 2023-10-13 17:55:12 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:55:14 --> Config Class Initialized
INFO - 2023-10-13 17:55:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:55:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:55:14 --> Utf8 Class Initialized
INFO - 2023-10-13 17:55:14 --> URI Class Initialized
INFO - 2023-10-13 17:55:14 --> Router Class Initialized
INFO - 2023-10-13 17:55:14 --> Output Class Initialized
INFO - 2023-10-13 17:55:15 --> Security Class Initialized
DEBUG - 2023-10-13 17:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:55:15 --> Input Class Initialized
INFO - 2023-10-13 17:55:15 --> Language Class Initialized
ERROR - 2023-10-13 17:55:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:32 --> Config Class Initialized
INFO - 2023-10-13 17:58:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:58:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:32 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:32 --> URI Class Initialized
DEBUG - 2023-10-13 17:58:32 --> No URI present. Default controller set.
INFO - 2023-10-13 17:58:32 --> Router Class Initialized
INFO - 2023-10-13 17:58:32 --> Output Class Initialized
INFO - 2023-10-13 17:58:32 --> Security Class Initialized
DEBUG - 2023-10-13 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:32 --> Input Class Initialized
INFO - 2023-10-13 17:58:32 --> Language Class Initialized
INFO - 2023-10-13 17:58:32 --> Loader Class Initialized
INFO - 2023-10-13 17:58:32 --> Helper loaded: url_helper
INFO - 2023-10-13 17:58:32 --> Helper loaded: file_helper
INFO - 2023-10-13 17:58:32 --> Database Driver Class Initialized
INFO - 2023-10-13 17:58:32 --> Email Class Initialized
DEBUG - 2023-10-13 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 17:58:32 --> Controller Class Initialized
INFO - 2023-10-13 17:58:32 --> Model "Contact_model" initialized
INFO - 2023-10-13 17:58:32 --> Model "Home_model" initialized
INFO - 2023-10-13 17:58:32 --> Helper loaded: download_helper
INFO - 2023-10-13 17:58:32 --> Helper loaded: form_helper
INFO - 2023-10-13 17:58:32 --> Form Validation Class Initialized
INFO - 2023-10-13 17:58:32 --> Helper loaded: custom_helper
INFO - 2023-10-13 17:58:32 --> Model "Social_media_model" initialized
INFO - 2023-10-13 17:58:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 17:58:32 --> Final output sent to browser
DEBUG - 2023-10-13 17:58:32 --> Total execution time: 0.5304
INFO - 2023-10-13 17:58:37 --> Config Class Initialized
INFO - 2023-10-13 17:58:43 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:58:44 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:47 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:47 --> URI Class Initialized
INFO - 2023-10-13 17:58:47 --> Router Class Initialized
INFO - 2023-10-13 17:58:47 --> Output Class Initialized
INFO - 2023-10-13 17:58:47 --> Security Class Initialized
DEBUG - 2023-10-13 17:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:47 --> Input Class Initialized
INFO - 2023-10-13 17:58:47 --> Language Class Initialized
ERROR - 2023-10-13 17:58:47 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:48 --> Config Class Initialized
INFO - 2023-10-13 17:58:48 --> Config Class Initialized
INFO - 2023-10-13 17:58:48 --> Config Class Initialized
INFO - 2023-10-13 17:58:48 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:48 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:48 --> URI Class Initialized
INFO - 2023-10-13 17:58:48 --> Router Class Initialized
INFO - 2023-10-13 17:58:48 --> Output Class Initialized
INFO - 2023-10-13 17:58:48 --> Security Class Initialized
DEBUG - 2023-10-13 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:48 --> Input Class Initialized
INFO - 2023-10-13 17:58:48 --> Language Class Initialized
ERROR - 2023-10-13 17:58:48 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:48 --> Hooks Class Initialized
INFO - 2023-10-13 17:58:48 --> Config Class Initialized
INFO - 2023-10-13 17:58:48 --> Hooks Class Initialized
DEBUG - 2023-10-13 17:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-10-13 17:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:48 --> Hooks Class Initialized
INFO - 2023-10-13 17:58:48 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:48 --> Config Class Initialized
INFO - 2023-10-13 17:58:48 --> URI Class Initialized
DEBUG - 2023-10-13 17:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:48 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:48 --> Router Class Initialized
INFO - 2023-10-13 17:58:48 --> Hooks Class Initialized
INFO - 2023-10-13 17:58:48 --> Utf8 Class Initialized
DEBUG - 2023-10-13 17:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 17:58:48 --> URI Class Initialized
INFO - 2023-10-13 17:58:48 --> Output Class Initialized
INFO - 2023-10-13 17:58:48 --> URI Class Initialized
INFO - 2023-10-13 17:58:49 --> Security Class Initialized
INFO - 2023-10-13 17:58:49 --> Utf8 Class Initialized
INFO - 2023-10-13 17:58:49 --> Router Class Initialized
INFO - 2023-10-13 17:58:49 --> URI Class Initialized
INFO - 2023-10-13 17:58:49 --> Router Class Initialized
INFO - 2023-10-13 17:58:49 --> Output Class Initialized
DEBUG - 2023-10-13 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:49 --> Router Class Initialized
INFO - 2023-10-13 17:58:49 --> Output Class Initialized
INFO - 2023-10-13 17:58:49 --> Output Class Initialized
INFO - 2023-10-13 17:58:49 --> Input Class Initialized
INFO - 2023-10-13 17:58:49 --> Security Class Initialized
INFO - 2023-10-13 17:58:49 --> Language Class Initialized
DEBUG - 2023-10-13 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:49 --> Security Class Initialized
INFO - 2023-10-13 17:58:49 --> Security Class Initialized
ERROR - 2023-10-13 17:58:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:49 --> Input Class Initialized
DEBUG - 2023-10-13 17:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-13 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 17:58:49 --> Language Class Initialized
INFO - 2023-10-13 17:58:49 --> Input Class Initialized
ERROR - 2023-10-13 17:58:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:49 --> Language Class Initialized
INFO - 2023-10-13 17:58:49 --> Input Class Initialized
ERROR - 2023-10-13 17:58:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 17:58:49 --> Language Class Initialized
ERROR - 2023-10-13 17:58:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:03:46 --> Config Class Initialized
INFO - 2023-10-13 18:03:46 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:03:46 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:03:46 --> Utf8 Class Initialized
INFO - 2023-10-13 18:03:46 --> URI Class Initialized
DEBUG - 2023-10-13 18:03:46 --> No URI present. Default controller set.
INFO - 2023-10-13 18:03:46 --> Router Class Initialized
INFO - 2023-10-13 18:03:46 --> Output Class Initialized
INFO - 2023-10-13 18:03:46 --> Security Class Initialized
DEBUG - 2023-10-13 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:03:46 --> Input Class Initialized
INFO - 2023-10-13 18:03:46 --> Language Class Initialized
INFO - 2023-10-13 18:03:46 --> Loader Class Initialized
INFO - 2023-10-13 18:03:46 --> Helper loaded: url_helper
INFO - 2023-10-13 18:03:46 --> Helper loaded: file_helper
INFO - 2023-10-13 18:03:46 --> Database Driver Class Initialized
INFO - 2023-10-13 18:03:46 --> Email Class Initialized
DEBUG - 2023-10-13 18:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:03:46 --> Controller Class Initialized
INFO - 2023-10-13 18:03:46 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:03:46 --> Model "Home_model" initialized
INFO - 2023-10-13 18:03:46 --> Helper loaded: download_helper
INFO - 2023-10-13 18:03:46 --> Helper loaded: form_helper
INFO - 2023-10-13 18:03:46 --> Form Validation Class Initialized
INFO - 2023-10-13 18:03:46 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:03:46 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:03:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:03:46 --> Final output sent to browser
DEBUG - 2023-10-13 18:03:46 --> Total execution time: 0.1196
INFO - 2023-10-13 18:06:28 --> Config Class Initialized
INFO - 2023-10-13 18:06:28 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:06:28 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:06:28 --> Utf8 Class Initialized
INFO - 2023-10-13 18:06:28 --> URI Class Initialized
DEBUG - 2023-10-13 18:06:28 --> No URI present. Default controller set.
INFO - 2023-10-13 18:06:28 --> Router Class Initialized
INFO - 2023-10-13 18:06:28 --> Output Class Initialized
INFO - 2023-10-13 18:06:28 --> Security Class Initialized
DEBUG - 2023-10-13 18:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:06:28 --> Input Class Initialized
INFO - 2023-10-13 18:06:28 --> Language Class Initialized
INFO - 2023-10-13 18:06:28 --> Loader Class Initialized
INFO - 2023-10-13 18:06:28 --> Helper loaded: url_helper
INFO - 2023-10-13 18:06:28 --> Helper loaded: file_helper
INFO - 2023-10-13 18:06:28 --> Database Driver Class Initialized
INFO - 2023-10-13 18:06:28 --> Email Class Initialized
DEBUG - 2023-10-13 18:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:06:28 --> Controller Class Initialized
INFO - 2023-10-13 18:06:28 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:06:28 --> Model "Home_model" initialized
INFO - 2023-10-13 18:06:28 --> Helper loaded: download_helper
INFO - 2023-10-13 18:06:28 --> Helper loaded: form_helper
INFO - 2023-10-13 18:06:28 --> Form Validation Class Initialized
INFO - 2023-10-13 18:06:28 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:06:28 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:06:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:06:29 --> Final output sent to browser
DEBUG - 2023-10-13 18:06:29 --> Total execution time: 0.2136
INFO - 2023-10-13 18:06:52 --> Config Class Initialized
INFO - 2023-10-13 18:06:52 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:06:52 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:06:52 --> Utf8 Class Initialized
INFO - 2023-10-13 18:06:52 --> URI Class Initialized
DEBUG - 2023-10-13 18:06:52 --> No URI present. Default controller set.
INFO - 2023-10-13 18:06:52 --> Router Class Initialized
INFO - 2023-10-13 18:06:52 --> Output Class Initialized
INFO - 2023-10-13 18:06:52 --> Security Class Initialized
DEBUG - 2023-10-13 18:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:06:52 --> Input Class Initialized
INFO - 2023-10-13 18:06:52 --> Language Class Initialized
INFO - 2023-10-13 18:06:52 --> Loader Class Initialized
INFO - 2023-10-13 18:06:52 --> Helper loaded: url_helper
INFO - 2023-10-13 18:06:52 --> Helper loaded: file_helper
INFO - 2023-10-13 18:06:52 --> Database Driver Class Initialized
INFO - 2023-10-13 18:06:52 --> Email Class Initialized
DEBUG - 2023-10-13 18:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:06:52 --> Controller Class Initialized
INFO - 2023-10-13 18:06:52 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:06:52 --> Model "Home_model" initialized
INFO - 2023-10-13 18:06:52 --> Helper loaded: download_helper
INFO - 2023-10-13 18:06:52 --> Helper loaded: form_helper
INFO - 2023-10-13 18:06:52 --> Form Validation Class Initialized
INFO - 2023-10-13 18:06:52 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:06:52 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:06:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:06:52 --> Final output sent to browser
DEBUG - 2023-10-13 18:06:52 --> Total execution time: 0.3186
INFO - 2023-10-13 18:07:05 --> Config Class Initialized
INFO - 2023-10-13 18:07:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:07:05 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:07:05 --> Utf8 Class Initialized
INFO - 2023-10-13 18:07:05 --> URI Class Initialized
DEBUG - 2023-10-13 18:07:05 --> No URI present. Default controller set.
INFO - 2023-10-13 18:07:05 --> Router Class Initialized
INFO - 2023-10-13 18:07:06 --> Output Class Initialized
INFO - 2023-10-13 18:07:06 --> Security Class Initialized
DEBUG - 2023-10-13 18:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:07:06 --> Input Class Initialized
INFO - 2023-10-13 18:07:06 --> Language Class Initialized
INFO - 2023-10-13 18:07:06 --> Loader Class Initialized
INFO - 2023-10-13 18:07:06 --> Helper loaded: url_helper
INFO - 2023-10-13 18:07:06 --> Helper loaded: file_helper
INFO - 2023-10-13 18:07:06 --> Database Driver Class Initialized
INFO - 2023-10-13 18:07:06 --> Email Class Initialized
DEBUG - 2023-10-13 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:07:06 --> Controller Class Initialized
INFO - 2023-10-13 18:07:06 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:07:06 --> Model "Home_model" initialized
INFO - 2023-10-13 18:07:06 --> Helper loaded: download_helper
INFO - 2023-10-13 18:07:06 --> Helper loaded: form_helper
INFO - 2023-10-13 18:07:06 --> Form Validation Class Initialized
INFO - 2023-10-13 18:07:06 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:07:06 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:07:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:07:06 --> Final output sent to browser
DEBUG - 2023-10-13 18:07:06 --> Total execution time: 0.1507
INFO - 2023-10-13 18:08:04 --> Config Class Initialized
INFO - 2023-10-13 18:08:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:08:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:04 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:04 --> URI Class Initialized
DEBUG - 2023-10-13 18:08:04 --> No URI present. Default controller set.
INFO - 2023-10-13 18:08:04 --> Router Class Initialized
INFO - 2023-10-13 18:08:04 --> Output Class Initialized
INFO - 2023-10-13 18:08:04 --> Security Class Initialized
DEBUG - 2023-10-13 18:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:04 --> Input Class Initialized
INFO - 2023-10-13 18:08:04 --> Language Class Initialized
INFO - 2023-10-13 18:08:04 --> Loader Class Initialized
INFO - 2023-10-13 18:08:04 --> Helper loaded: url_helper
INFO - 2023-10-13 18:08:04 --> Helper loaded: file_helper
INFO - 2023-10-13 18:08:04 --> Database Driver Class Initialized
INFO - 2023-10-13 18:08:04 --> Email Class Initialized
DEBUG - 2023-10-13 18:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:08:04 --> Controller Class Initialized
INFO - 2023-10-13 18:08:04 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:08:04 --> Model "Home_model" initialized
INFO - 2023-10-13 18:08:04 --> Helper loaded: download_helper
INFO - 2023-10-13 18:08:04 --> Helper loaded: form_helper
INFO - 2023-10-13 18:08:04 --> Form Validation Class Initialized
INFO - 2023-10-13 18:08:04 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:08:04 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:08:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:08:04 --> Final output sent to browser
DEBUG - 2023-10-13 18:08:04 --> Total execution time: 0.2036
INFO - 2023-10-13 18:08:18 --> Config Class Initialized
INFO - 2023-10-13 18:08:19 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:08:19 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:19 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:20 --> URI Class Initialized
INFO - 2023-10-13 18:08:20 --> Router Class Initialized
INFO - 2023-10-13 18:08:20 --> Output Class Initialized
INFO - 2023-10-13 18:08:20 --> Security Class Initialized
DEBUG - 2023-10-13 18:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:20 --> Input Class Initialized
INFO - 2023-10-13 18:08:20 --> Language Class Initialized
ERROR - 2023-10-13 18:08:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:08:20 --> Config Class Initialized
INFO - 2023-10-13 18:08:20 --> Config Class Initialized
INFO - 2023-10-13 18:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:20 --> Hooks Class Initialized
INFO - 2023-10-13 18:08:20 --> Utf8 Class Initialized
DEBUG - 2023-10-13 18:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:20 --> URI Class Initialized
INFO - 2023-10-13 18:08:20 --> Router Class Initialized
INFO - 2023-10-13 18:08:20 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:20 --> Output Class Initialized
INFO - 2023-10-13 18:08:20 --> URI Class Initialized
INFO - 2023-10-13 18:08:20 --> Security Class Initialized
INFO - 2023-10-13 18:08:20 --> Router Class Initialized
DEBUG - 2023-10-13 18:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:21 --> Input Class Initialized
INFO - 2023-10-13 18:08:21 --> Output Class Initialized
INFO - 2023-10-13 18:08:21 --> Language Class Initialized
INFO - 2023-10-13 18:08:21 --> Security Class Initialized
ERROR - 2023-10-13 18:08:21 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-13 18:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:21 --> Input Class Initialized
INFO - 2023-10-13 18:08:21 --> Language Class Initialized
ERROR - 2023-10-13 18:08:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:08:23 --> Config Class Initialized
INFO - 2023-10-13 18:08:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:08:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:23 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:23 --> URI Class Initialized
INFO - 2023-10-13 18:08:23 --> Router Class Initialized
INFO - 2023-10-13 18:08:23 --> Output Class Initialized
INFO - 2023-10-13 18:08:23 --> Security Class Initialized
DEBUG - 2023-10-13 18:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:23 --> Input Class Initialized
INFO - 2023-10-13 18:08:23 --> Language Class Initialized
ERROR - 2023-10-13 18:08:23 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:08:25 --> Config Class Initialized
INFO - 2023-10-13 18:08:25 --> Config Class Initialized
INFO - 2023-10-13 18:08:25 --> Config Class Initialized
INFO - 2023-10-13 18:08:25 --> Hooks Class Initialized
INFO - 2023-10-13 18:08:25 --> Hooks Class Initialized
INFO - 2023-10-13 18:08:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-10-13 18:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-10-13 18:08:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:08:25 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:25 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:25 --> URI Class Initialized
INFO - 2023-10-13 18:08:25 --> Utf8 Class Initialized
INFO - 2023-10-13 18:08:25 --> Router Class Initialized
INFO - 2023-10-13 18:08:25 --> URI Class Initialized
INFO - 2023-10-13 18:08:25 --> URI Class Initialized
INFO - 2023-10-13 18:08:25 --> Router Class Initialized
INFO - 2023-10-13 18:08:25 --> Router Class Initialized
INFO - 2023-10-13 18:08:25 --> Output Class Initialized
INFO - 2023-10-13 18:08:25 --> Output Class Initialized
INFO - 2023-10-13 18:08:25 --> Output Class Initialized
INFO - 2023-10-13 18:08:25 --> Security Class Initialized
INFO - 2023-10-13 18:08:25 --> Security Class Initialized
INFO - 2023-10-13 18:08:25 --> Security Class Initialized
DEBUG - 2023-10-13 18:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-13 18:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-13 18:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:08:25 --> Input Class Initialized
INFO - 2023-10-13 18:08:25 --> Input Class Initialized
INFO - 2023-10-13 18:08:25 --> Input Class Initialized
INFO - 2023-10-13 18:08:25 --> Language Class Initialized
INFO - 2023-10-13 18:08:25 --> Language Class Initialized
INFO - 2023-10-13 18:08:25 --> Language Class Initialized
ERROR - 2023-10-13 18:08:25 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-13 18:08:25 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-13 18:08:25 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:10:24 --> Config Class Initialized
INFO - 2023-10-13 18:10:24 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:10:24 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:10:24 --> Utf8 Class Initialized
INFO - 2023-10-13 18:10:24 --> URI Class Initialized
DEBUG - 2023-10-13 18:10:24 --> No URI present. Default controller set.
INFO - 2023-10-13 18:10:24 --> Router Class Initialized
INFO - 2023-10-13 18:10:24 --> Output Class Initialized
INFO - 2023-10-13 18:10:24 --> Security Class Initialized
DEBUG - 2023-10-13 18:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:10:24 --> Input Class Initialized
INFO - 2023-10-13 18:10:24 --> Language Class Initialized
INFO - 2023-10-13 18:10:24 --> Loader Class Initialized
INFO - 2023-10-13 18:10:24 --> Helper loaded: url_helper
INFO - 2023-10-13 18:10:24 --> Helper loaded: file_helper
INFO - 2023-10-13 18:10:24 --> Database Driver Class Initialized
INFO - 2023-10-13 18:10:24 --> Email Class Initialized
DEBUG - 2023-10-13 18:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:10:24 --> Controller Class Initialized
INFO - 2023-10-13 18:10:24 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:10:24 --> Model "Home_model" initialized
INFO - 2023-10-13 18:10:24 --> Helper loaded: download_helper
INFO - 2023-10-13 18:10:24 --> Helper loaded: form_helper
INFO - 2023-10-13 18:10:24 --> Form Validation Class Initialized
INFO - 2023-10-13 18:10:24 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:10:24 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:10:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:10:24 --> Final output sent to browser
DEBUG - 2023-10-13 18:10:25 --> Total execution time: 0.1903
INFO - 2023-10-13 18:10:38 --> Config Class Initialized
INFO - 2023-10-13 18:10:38 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:10:38 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:10:38 --> Utf8 Class Initialized
INFO - 2023-10-13 18:10:38 --> URI Class Initialized
INFO - 2023-10-13 18:10:38 --> Router Class Initialized
INFO - 2023-10-13 18:10:38 --> Output Class Initialized
INFO - 2023-10-13 18:10:38 --> Security Class Initialized
DEBUG - 2023-10-13 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:10:38 --> Input Class Initialized
INFO - 2023-10-13 18:10:38 --> Language Class Initialized
ERROR - 2023-10-13 18:10:38 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:10:39 --> Config Class Initialized
INFO - 2023-10-13 18:10:39 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:10:39 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:10:39 --> Utf8 Class Initialized
INFO - 2023-10-13 18:10:39 --> URI Class Initialized
INFO - 2023-10-13 18:10:39 --> Router Class Initialized
INFO - 2023-10-13 18:10:39 --> Output Class Initialized
INFO - 2023-10-13 18:10:39 --> Security Class Initialized
DEBUG - 2023-10-13 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:10:39 --> Input Class Initialized
INFO - 2023-10-13 18:10:39 --> Language Class Initialized
ERROR - 2023-10-13 18:10:39 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:10:43 --> Config Class Initialized
INFO - 2023-10-13 18:10:43 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:10:43 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:10:43 --> Utf8 Class Initialized
INFO - 2023-10-13 18:10:43 --> URI Class Initialized
INFO - 2023-10-13 18:10:43 --> Router Class Initialized
INFO - 2023-10-13 18:10:43 --> Output Class Initialized
INFO - 2023-10-13 18:10:43 --> Security Class Initialized
DEBUG - 2023-10-13 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:10:43 --> Input Class Initialized
INFO - 2023-10-13 18:10:43 --> Language Class Initialized
ERROR - 2023-10-13 18:10:43 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:10:43 --> Config Class Initialized
INFO - 2023-10-13 18:10:43 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:10:43 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:10:43 --> Utf8 Class Initialized
INFO - 2023-10-13 18:10:43 --> URI Class Initialized
INFO - 2023-10-13 18:10:43 --> Router Class Initialized
INFO - 2023-10-13 18:10:43 --> Output Class Initialized
INFO - 2023-10-13 18:10:43 --> Security Class Initialized
DEBUG - 2023-10-13 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:10:43 --> Input Class Initialized
INFO - 2023-10-13 18:10:43 --> Language Class Initialized
ERROR - 2023-10-13 18:10:43 --> 404 Page Not Found: Assets/home
INFO - 2023-10-13 18:12:27 --> Config Class Initialized
INFO - 2023-10-13 18:12:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:12:28 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:12:28 --> Utf8 Class Initialized
INFO - 2023-10-13 18:12:28 --> URI Class Initialized
DEBUG - 2023-10-13 18:12:28 --> No URI present. Default controller set.
INFO - 2023-10-13 18:12:28 --> Router Class Initialized
INFO - 2023-10-13 18:12:28 --> Output Class Initialized
INFO - 2023-10-13 18:12:28 --> Security Class Initialized
DEBUG - 2023-10-13 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:12:29 --> Input Class Initialized
INFO - 2023-10-13 18:12:30 --> Language Class Initialized
INFO - 2023-10-13 18:12:30 --> Loader Class Initialized
INFO - 2023-10-13 18:12:30 --> Helper loaded: url_helper
INFO - 2023-10-13 18:12:30 --> Helper loaded: file_helper
INFO - 2023-10-13 18:12:30 --> Database Driver Class Initialized
INFO - 2023-10-13 18:12:30 --> Email Class Initialized
DEBUG - 2023-10-13 18:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:12:30 --> Controller Class Initialized
INFO - 2023-10-13 18:12:30 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:12:30 --> Model "Home_model" initialized
INFO - 2023-10-13 18:12:30 --> Helper loaded: download_helper
INFO - 2023-10-13 18:12:30 --> Helper loaded: form_helper
INFO - 2023-10-13 18:12:30 --> Form Validation Class Initialized
INFO - 2023-10-13 18:12:30 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:12:30 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:12:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-13 18:12:30 --> Final output sent to browser
DEBUG - 2023-10-13 18:12:31 --> Total execution time: 2.9358
INFO - 2023-10-13 18:14:32 --> Config Class Initialized
INFO - 2023-10-13 18:14:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:14:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:14:32 --> Utf8 Class Initialized
INFO - 2023-10-13 18:14:32 --> URI Class Initialized
INFO - 2023-10-13 18:14:32 --> Router Class Initialized
INFO - 2023-10-13 18:14:32 --> Output Class Initialized
INFO - 2023-10-13 18:14:32 --> Security Class Initialized
DEBUG - 2023-10-13 18:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:14:32 --> Input Class Initialized
INFO - 2023-10-13 18:14:32 --> Language Class Initialized
INFO - 2023-10-13 18:14:32 --> Loader Class Initialized
INFO - 2023-10-13 18:14:32 --> Helper loaded: url_helper
INFO - 2023-10-13 18:14:32 --> Helper loaded: file_helper
INFO - 2023-10-13 18:14:32 --> Database Driver Class Initialized
INFO - 2023-10-13 18:14:32 --> Email Class Initialized
DEBUG - 2023-10-13 18:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:14:32 --> Controller Class Initialized
INFO - 2023-10-13 18:14:32 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:14:32 --> Model "Home_model" initialized
INFO - 2023-10-13 18:14:32 --> Helper loaded: download_helper
INFO - 2023-10-13 18:14:32 --> Helper loaded: form_helper
INFO - 2023-10-13 18:14:32 --> Form Validation Class Initialized
INFO - 2023-10-13 18:14:32 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:14:32 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:14:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-10-13 18:14:32 --> Final output sent to browser
DEBUG - 2023-10-13 18:14:32 --> Total execution time: 0.1171
INFO - 2023-10-13 18:15:04 --> Config Class Initialized
INFO - 2023-10-13 18:15:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:15:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:15:04 --> Utf8 Class Initialized
INFO - 2023-10-13 18:15:04 --> URI Class Initialized
INFO - 2023-10-13 18:15:04 --> Router Class Initialized
INFO - 2023-10-13 18:15:04 --> Output Class Initialized
INFO - 2023-10-13 18:15:04 --> Security Class Initialized
DEBUG - 2023-10-13 18:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:15:04 --> Input Class Initialized
INFO - 2023-10-13 18:15:04 --> Language Class Initialized
INFO - 2023-10-13 18:15:04 --> Loader Class Initialized
INFO - 2023-10-13 18:15:04 --> Helper loaded: url_helper
INFO - 2023-10-13 18:15:04 --> Helper loaded: file_helper
INFO - 2023-10-13 18:15:04 --> Database Driver Class Initialized
INFO - 2023-10-13 18:15:04 --> Email Class Initialized
DEBUG - 2023-10-13 18:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:15:04 --> Controller Class Initialized
INFO - 2023-10-13 18:15:04 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:15:04 --> Model "Home_model" initialized
INFO - 2023-10-13 18:15:04 --> Helper loaded: download_helper
INFO - 2023-10-13 18:15:04 --> Helper loaded: form_helper
INFO - 2023-10-13 18:15:04 --> Form Validation Class Initialized
INFO - 2023-10-13 18:15:04 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:15:04 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:15:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-10-13 18:15:04 --> Final output sent to browser
DEBUG - 2023-10-13 18:15:04 --> Total execution time: 0.1528
INFO - 2023-10-13 18:19:34 --> Config Class Initialized
INFO - 2023-10-13 18:19:34 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:34 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:34 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:34 --> URI Class Initialized
INFO - 2023-10-13 18:19:34 --> Router Class Initialized
INFO - 2023-10-13 18:19:34 --> Output Class Initialized
INFO - 2023-10-13 18:19:34 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:34 --> Input Class Initialized
INFO - 2023-10-13 18:19:34 --> Language Class Initialized
INFO - 2023-10-13 18:19:34 --> Loader Class Initialized
INFO - 2023-10-13 18:19:34 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:34 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:34 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:34 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:34 --> Controller Class Initialized
INFO - 2023-10-13 18:19:34 --> Config Class Initialized
INFO - 2023-10-13 18:19:34 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:34 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:34 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:34 --> URI Class Initialized
INFO - 2023-10-13 18:19:34 --> Router Class Initialized
INFO - 2023-10-13 18:19:34 --> Output Class Initialized
INFO - 2023-10-13 18:19:34 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:34 --> Input Class Initialized
INFO - 2023-10-13 18:19:34 --> Language Class Initialized
INFO - 2023-10-13 18:19:34 --> Loader Class Initialized
INFO - 2023-10-13 18:19:34 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:34 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:34 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:34 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:34 --> Controller Class Initialized
INFO - 2023-10-13 18:19:34 --> Model "User_model" initialized
INFO - 2023-10-13 18:19:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-10-13 18:19:34 --> Final output sent to browser
DEBUG - 2023-10-13 18:19:34 --> Total execution time: 0.0707
INFO - 2023-10-13 18:19:35 --> Config Class Initialized
INFO - 2023-10-13 18:19:35 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:35 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:35 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:35 --> URI Class Initialized
INFO - 2023-10-13 18:19:35 --> Router Class Initialized
INFO - 2023-10-13 18:19:35 --> Output Class Initialized
INFO - 2023-10-13 18:19:35 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:35 --> Input Class Initialized
INFO - 2023-10-13 18:19:35 --> Language Class Initialized
ERROR - 2023-10-13 18:19:35 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-13 18:19:47 --> Config Class Initialized
INFO - 2023-10-13 18:19:47 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:47 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:47 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:47 --> URI Class Initialized
INFO - 2023-10-13 18:19:47 --> Router Class Initialized
INFO - 2023-10-13 18:19:47 --> Output Class Initialized
INFO - 2023-10-13 18:19:47 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:47 --> Input Class Initialized
INFO - 2023-10-13 18:19:47 --> Language Class Initialized
INFO - 2023-10-13 18:19:47 --> Loader Class Initialized
INFO - 2023-10-13 18:19:47 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:47 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:47 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:47 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:47 --> Controller Class Initialized
INFO - 2023-10-13 18:19:47 --> Model "User_model" initialized
INFO - 2023-10-13 18:19:47 --> Config Class Initialized
INFO - 2023-10-13 18:19:47 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:47 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:47 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:47 --> URI Class Initialized
INFO - 2023-10-13 18:19:47 --> Router Class Initialized
INFO - 2023-10-13 18:19:47 --> Output Class Initialized
INFO - 2023-10-13 18:19:47 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:47 --> Input Class Initialized
INFO - 2023-10-13 18:19:47 --> Language Class Initialized
INFO - 2023-10-13 18:19:47 --> Loader Class Initialized
INFO - 2023-10-13 18:19:47 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:47 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:47 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:47 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:47 --> Controller Class Initialized
INFO - 2023-10-13 18:19:47 --> Model "User_model" initialized
INFO - 2023-10-13 18:19:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-10-13 18:19:47 --> Final output sent to browser
DEBUG - 2023-10-13 18:19:47 --> Total execution time: 0.0471
INFO - 2023-10-13 18:19:56 --> Config Class Initialized
INFO - 2023-10-13 18:19:56 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:56 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:56 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:56 --> URI Class Initialized
INFO - 2023-10-13 18:19:56 --> Router Class Initialized
INFO - 2023-10-13 18:19:56 --> Output Class Initialized
INFO - 2023-10-13 18:19:56 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:56 --> Input Class Initialized
INFO - 2023-10-13 18:19:56 --> Language Class Initialized
INFO - 2023-10-13 18:19:56 --> Loader Class Initialized
INFO - 2023-10-13 18:19:56 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:56 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:56 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:56 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:56 --> Controller Class Initialized
INFO - 2023-10-13 18:19:56 --> Model "User_model" initialized
INFO - 2023-10-13 18:19:57 --> Config Class Initialized
INFO - 2023-10-13 18:19:57 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:19:57 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:19:57 --> Utf8 Class Initialized
INFO - 2023-10-13 18:19:57 --> URI Class Initialized
INFO - 2023-10-13 18:19:57 --> Router Class Initialized
INFO - 2023-10-13 18:19:57 --> Output Class Initialized
INFO - 2023-10-13 18:19:57 --> Security Class Initialized
DEBUG - 2023-10-13 18:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:19:57 --> Input Class Initialized
INFO - 2023-10-13 18:19:57 --> Language Class Initialized
INFO - 2023-10-13 18:19:57 --> Loader Class Initialized
INFO - 2023-10-13 18:19:57 --> Helper loaded: url_helper
INFO - 2023-10-13 18:19:57 --> Helper loaded: file_helper
INFO - 2023-10-13 18:19:57 --> Database Driver Class Initialized
INFO - 2023-10-13 18:19:57 --> Email Class Initialized
DEBUG - 2023-10-13 18:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:19:57 --> Controller Class Initialized
INFO - 2023-10-13 18:19:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-10-13 18:19:57 --> Final output sent to browser
DEBUG - 2023-10-13 18:19:57 --> Total execution time: 0.0524
INFO - 2023-10-13 18:20:04 --> Config Class Initialized
INFO - 2023-10-13 18:20:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:20:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:20:04 --> Utf8 Class Initialized
INFO - 2023-10-13 18:20:04 --> URI Class Initialized
INFO - 2023-10-13 18:20:04 --> Router Class Initialized
INFO - 2023-10-13 18:20:04 --> Output Class Initialized
INFO - 2023-10-13 18:20:04 --> Security Class Initialized
DEBUG - 2023-10-13 18:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:20:04 --> Input Class Initialized
INFO - 2023-10-13 18:20:04 --> Language Class Initialized
INFO - 2023-10-13 18:20:04 --> Loader Class Initialized
INFO - 2023-10-13 18:20:04 --> Helper loaded: url_helper
INFO - 2023-10-13 18:20:05 --> Helper loaded: file_helper
INFO - 2023-10-13 18:20:05 --> Database Driver Class Initialized
INFO - 2023-10-13 18:20:05 --> Email Class Initialized
DEBUG - 2023-10-13 18:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:20:05 --> Controller Class Initialized
INFO - 2023-10-13 18:20:05 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:20:05 --> Helper loaded: form_helper
INFO - 2023-10-13 18:20:05 --> Form Validation Class Initialized
INFO - 2023-10-13 18:20:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 18:20:05 --> Final output sent to browser
DEBUG - 2023-10-13 18:20:05 --> Total execution time: 0.0967
INFO - 2023-10-13 18:27:15 --> Config Class Initialized
INFO - 2023-10-13 18:27:15 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:27:15 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:27:15 --> Utf8 Class Initialized
INFO - 2023-10-13 18:27:15 --> URI Class Initialized
INFO - 2023-10-13 18:27:15 --> Router Class Initialized
INFO - 2023-10-13 18:27:15 --> Output Class Initialized
INFO - 2023-10-13 18:27:15 --> Security Class Initialized
DEBUG - 2023-10-13 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:27:15 --> Input Class Initialized
INFO - 2023-10-13 18:27:15 --> Language Class Initialized
INFO - 2023-10-13 18:27:15 --> Loader Class Initialized
INFO - 2023-10-13 18:27:15 --> Helper loaded: url_helper
INFO - 2023-10-13 18:27:15 --> Helper loaded: file_helper
INFO - 2023-10-13 18:27:15 --> Database Driver Class Initialized
INFO - 2023-10-13 18:27:15 --> Email Class Initialized
DEBUG - 2023-10-13 18:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:27:15 --> Controller Class Initialized
INFO - 2023-10-13 18:27:15 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:27:15 --> Helper loaded: form_helper
INFO - 2023-10-13 18:27:15 --> Form Validation Class Initialized
INFO - 2023-10-13 18:27:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-10-13 18:27:15 --> Final output sent to browser
DEBUG - 2023-10-13 18:27:16 --> Total execution time: 0.1174
INFO - 2023-10-13 18:27:16 --> Config Class Initialized
INFO - 2023-10-13 18:27:16 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:27:16 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:27:16 --> Utf8 Class Initialized
INFO - 2023-10-13 18:27:16 --> URI Class Initialized
INFO - 2023-10-13 18:27:16 --> Router Class Initialized
INFO - 2023-10-13 18:27:16 --> Output Class Initialized
INFO - 2023-10-13 18:27:16 --> Security Class Initialized
DEBUG - 2023-10-13 18:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:27:16 --> Input Class Initialized
INFO - 2023-10-13 18:27:16 --> Language Class Initialized
ERROR - 2023-10-13 18:27:16 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-10-13 18:27:23 --> Config Class Initialized
INFO - 2023-10-13 18:27:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:27:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:27:23 --> Utf8 Class Initialized
INFO - 2023-10-13 18:27:23 --> URI Class Initialized
INFO - 2023-10-13 18:27:23 --> Router Class Initialized
INFO - 2023-10-13 18:27:23 --> Output Class Initialized
INFO - 2023-10-13 18:27:23 --> Security Class Initialized
DEBUG - 2023-10-13 18:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:27:23 --> Input Class Initialized
INFO - 2023-10-13 18:27:23 --> Language Class Initialized
INFO - 2023-10-13 18:27:23 --> Loader Class Initialized
INFO - 2023-10-13 18:27:23 --> Helper loaded: url_helper
INFO - 2023-10-13 18:27:24 --> Helper loaded: file_helper
INFO - 2023-10-13 18:27:24 --> Database Driver Class Initialized
INFO - 2023-10-13 18:27:24 --> Email Class Initialized
DEBUG - 2023-10-13 18:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:27:24 --> Controller Class Initialized
INFO - 2023-10-13 18:27:24 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:27:24 --> Model "Home_model" initialized
INFO - 2023-10-13 18:27:24 --> Helper loaded: download_helper
INFO - 2023-10-13 18:27:24 --> Helper loaded: form_helper
INFO - 2023-10-13 18:27:24 --> Form Validation Class Initialized
INFO - 2023-10-13 18:27:24 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:27:24 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:27:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-13 18:27:24 --> Final output sent to browser
DEBUG - 2023-10-13 18:27:24 --> Total execution time: 0.1497
INFO - 2023-10-13 18:27:28 --> Config Class Initialized
INFO - 2023-10-13 18:27:28 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:27:28 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:27:28 --> Utf8 Class Initialized
INFO - 2023-10-13 18:27:28 --> URI Class Initialized
INFO - 2023-10-13 18:27:28 --> Router Class Initialized
INFO - 2023-10-13 18:27:28 --> Output Class Initialized
INFO - 2023-10-13 18:27:28 --> Security Class Initialized
DEBUG - 2023-10-13 18:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:27:28 --> Input Class Initialized
INFO - 2023-10-13 18:27:28 --> Language Class Initialized
INFO - 2023-10-13 18:27:28 --> Loader Class Initialized
INFO - 2023-10-13 18:27:28 --> Helper loaded: url_helper
INFO - 2023-10-13 18:27:28 --> Helper loaded: file_helper
INFO - 2023-10-13 18:27:28 --> Database Driver Class Initialized
INFO - 2023-10-13 18:27:28 --> Email Class Initialized
DEBUG - 2023-10-13 18:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:27:28 --> Controller Class Initialized
INFO - 2023-10-13 18:27:28 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:27:28 --> Model "Home_model" initialized
INFO - 2023-10-13 18:27:28 --> Helper loaded: download_helper
INFO - 2023-10-13 18:27:28 --> Helper loaded: form_helper
INFO - 2023-10-13 18:27:28 --> Form Validation Class Initialized
INFO - 2023-10-13 18:27:28 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:27:28 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:27:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:27:28 --> Final output sent to browser
DEBUG - 2023-10-13 18:27:28 --> Total execution time: 0.0954
INFO - 2023-10-13 18:31:01 --> Config Class Initialized
INFO - 2023-10-13 18:31:01 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:31:01 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:31:01 --> Utf8 Class Initialized
INFO - 2023-10-13 18:31:01 --> URI Class Initialized
INFO - 2023-10-13 18:31:01 --> Router Class Initialized
INFO - 2023-10-13 18:31:01 --> Output Class Initialized
INFO - 2023-10-13 18:31:01 --> Security Class Initialized
DEBUG - 2023-10-13 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:31:01 --> Input Class Initialized
INFO - 2023-10-13 18:31:01 --> Language Class Initialized
INFO - 2023-10-13 18:31:01 --> Loader Class Initialized
INFO - 2023-10-13 18:31:01 --> Helper loaded: url_helper
INFO - 2023-10-13 18:31:01 --> Helper loaded: file_helper
INFO - 2023-10-13 18:31:01 --> Database Driver Class Initialized
INFO - 2023-10-13 18:31:01 --> Email Class Initialized
DEBUG - 2023-10-13 18:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:31:01 --> Controller Class Initialized
INFO - 2023-10-13 18:31:01 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:31:01 --> Helper loaded: form_helper
INFO - 2023-10-13 18:31:01 --> Form Validation Class Initialized
INFO - 2023-10-13 18:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 18:31:01 --> Config Class Initialized
INFO - 2023-10-13 18:31:01 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:31:01 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:31:01 --> Utf8 Class Initialized
INFO - 2023-10-13 18:31:01 --> URI Class Initialized
INFO - 2023-10-13 18:31:01 --> Router Class Initialized
INFO - 2023-10-13 18:31:01 --> Output Class Initialized
INFO - 2023-10-13 18:31:01 --> Security Class Initialized
DEBUG - 2023-10-13 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:31:01 --> Input Class Initialized
INFO - 2023-10-13 18:31:01 --> Language Class Initialized
INFO - 2023-10-13 18:31:01 --> Loader Class Initialized
INFO - 2023-10-13 18:31:01 --> Helper loaded: url_helper
INFO - 2023-10-13 18:31:01 --> Helper loaded: file_helper
INFO - 2023-10-13 18:31:01 --> Database Driver Class Initialized
INFO - 2023-10-13 18:31:01 --> Email Class Initialized
DEBUG - 2023-10-13 18:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:31:01 --> Controller Class Initialized
INFO - 2023-10-13 18:31:01 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:31:01 --> Helper loaded: form_helper
INFO - 2023-10-13 18:31:01 --> Form Validation Class Initialized
INFO - 2023-10-13 18:31:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 18:31:01 --> Final output sent to browser
DEBUG - 2023-10-13 18:31:02 --> Total execution time: 0.1069
INFO - 2023-10-13 18:31:11 --> Config Class Initialized
INFO - 2023-10-13 18:31:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:31:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:31:11 --> Utf8 Class Initialized
INFO - 2023-10-13 18:31:11 --> URI Class Initialized
INFO - 2023-10-13 18:31:11 --> Router Class Initialized
INFO - 2023-10-13 18:31:11 --> Output Class Initialized
INFO - 2023-10-13 18:31:11 --> Security Class Initialized
DEBUG - 2023-10-13 18:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:31:11 --> Input Class Initialized
INFO - 2023-10-13 18:31:11 --> Language Class Initialized
INFO - 2023-10-13 18:31:11 --> Loader Class Initialized
INFO - 2023-10-13 18:31:11 --> Helper loaded: url_helper
INFO - 2023-10-13 18:31:11 --> Helper loaded: file_helper
INFO - 2023-10-13 18:31:11 --> Database Driver Class Initialized
INFO - 2023-10-13 18:31:11 --> Email Class Initialized
DEBUG - 2023-10-13 18:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:31:11 --> Controller Class Initialized
INFO - 2023-10-13 18:31:11 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:31:11 --> Model "Home_model" initialized
INFO - 2023-10-13 18:31:11 --> Helper loaded: download_helper
INFO - 2023-10-13 18:31:11 --> Helper loaded: form_helper
INFO - 2023-10-13 18:31:11 --> Form Validation Class Initialized
INFO - 2023-10-13 18:31:11 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:31:11 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:31:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-13 18:31:11 --> Final output sent to browser
DEBUG - 2023-10-13 18:31:11 --> Total execution time: 0.2016
INFO - 2023-10-13 18:31:18 --> Config Class Initialized
INFO - 2023-10-13 18:31:18 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:31:18 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:31:18 --> Utf8 Class Initialized
INFO - 2023-10-13 18:31:18 --> URI Class Initialized
INFO - 2023-10-13 18:31:18 --> Router Class Initialized
INFO - 2023-10-13 18:31:18 --> Output Class Initialized
INFO - 2023-10-13 18:31:18 --> Security Class Initialized
DEBUG - 2023-10-13 18:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:31:18 --> Input Class Initialized
INFO - 2023-10-13 18:31:18 --> Language Class Initialized
INFO - 2023-10-13 18:31:18 --> Loader Class Initialized
INFO - 2023-10-13 18:31:18 --> Helper loaded: url_helper
INFO - 2023-10-13 18:31:18 --> Helper loaded: file_helper
INFO - 2023-10-13 18:31:18 --> Database Driver Class Initialized
INFO - 2023-10-13 18:31:18 --> Email Class Initialized
DEBUG - 2023-10-13 18:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:31:18 --> Controller Class Initialized
INFO - 2023-10-13 18:31:18 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:31:18 --> Model "Home_model" initialized
INFO - 2023-10-13 18:31:18 --> Helper loaded: download_helper
INFO - 2023-10-13 18:31:18 --> Helper loaded: form_helper
INFO - 2023-10-13 18:31:18 --> Form Validation Class Initialized
INFO - 2023-10-13 18:31:18 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:31:18 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:31:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:31:19 --> Final output sent to browser
DEBUG - 2023-10-13 18:31:19 --> Total execution time: 0.1086
INFO - 2023-10-13 18:31:27 --> Config Class Initialized
INFO - 2023-10-13 18:31:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:31:27 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:31:27 --> Utf8 Class Initialized
INFO - 2023-10-13 18:31:27 --> URI Class Initialized
INFO - 2023-10-13 18:31:27 --> Router Class Initialized
INFO - 2023-10-13 18:31:27 --> Output Class Initialized
INFO - 2023-10-13 18:31:27 --> Security Class Initialized
DEBUG - 2023-10-13 18:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:31:27 --> Input Class Initialized
INFO - 2023-10-13 18:31:27 --> Language Class Initialized
INFO - 2023-10-13 18:31:27 --> Loader Class Initialized
INFO - 2023-10-13 18:31:27 --> Helper loaded: url_helper
INFO - 2023-10-13 18:31:27 --> Helper loaded: file_helper
INFO - 2023-10-13 18:31:27 --> Database Driver Class Initialized
INFO - 2023-10-13 18:31:27 --> Email Class Initialized
DEBUG - 2023-10-13 18:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:31:27 --> Controller Class Initialized
INFO - 2023-10-13 18:31:27 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:31:27 --> Model "Home_model" initialized
INFO - 2023-10-13 18:31:27 --> Helper loaded: download_helper
INFO - 2023-10-13 18:31:27 --> Helper loaded: form_helper
INFO - 2023-10-13 18:31:27 --> Form Validation Class Initialized
INFO - 2023-10-13 18:31:27 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:31:27 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:31:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:31:27 --> Final output sent to browser
DEBUG - 2023-10-13 18:31:28 --> Total execution time: 0.1267
INFO - 2023-10-13 18:55:30 --> Config Class Initialized
INFO - 2023-10-13 18:55:30 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:55:30 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:55:30 --> Utf8 Class Initialized
INFO - 2023-10-13 18:55:30 --> URI Class Initialized
INFO - 2023-10-13 18:55:30 --> Router Class Initialized
INFO - 2023-10-13 18:55:30 --> Output Class Initialized
INFO - 2023-10-13 18:55:30 --> Security Class Initialized
DEBUG - 2023-10-13 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:55:30 --> Input Class Initialized
INFO - 2023-10-13 18:55:30 --> Language Class Initialized
INFO - 2023-10-13 18:55:30 --> Loader Class Initialized
INFO - 2023-10-13 18:55:30 --> Helper loaded: url_helper
INFO - 2023-10-13 18:55:30 --> Helper loaded: file_helper
INFO - 2023-10-13 18:55:30 --> Database Driver Class Initialized
INFO - 2023-10-13 18:55:30 --> Email Class Initialized
DEBUG - 2023-10-13 18:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:55:30 --> Controller Class Initialized
INFO - 2023-10-13 18:55:30 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:55:30 --> Helper loaded: form_helper
INFO - 2023-10-13 18:55:30 --> Form Validation Class Initialized
INFO - 2023-10-13 18:55:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 18:55:30 --> Final output sent to browser
DEBUG - 2023-10-13 18:55:30 --> Total execution time: 0.1053
INFO - 2023-10-13 18:55:31 --> Config Class Initialized
INFO - 2023-10-13 18:55:31 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:55:31 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:55:31 --> Utf8 Class Initialized
INFO - 2023-10-13 18:55:31 --> URI Class Initialized
INFO - 2023-10-13 18:55:31 --> Router Class Initialized
INFO - 2023-10-13 18:55:31 --> Output Class Initialized
INFO - 2023-10-13 18:55:31 --> Security Class Initialized
DEBUG - 2023-10-13 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:55:31 --> Input Class Initialized
INFO - 2023-10-13 18:55:31 --> Language Class Initialized
INFO - 2023-10-13 18:55:31 --> Loader Class Initialized
INFO - 2023-10-13 18:55:31 --> Helper loaded: url_helper
INFO - 2023-10-13 18:55:31 --> Helper loaded: file_helper
INFO - 2023-10-13 18:55:31 --> Database Driver Class Initialized
INFO - 2023-10-13 18:55:31 --> Email Class Initialized
DEBUG - 2023-10-13 18:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:55:31 --> Controller Class Initialized
INFO - 2023-10-13 18:55:31 --> Model "Blog_model" initialized
INFO - 2023-10-13 18:55:31 --> Helper loaded: form_helper
INFO - 2023-10-13 18:55:31 --> Form Validation Class Initialized
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-10-13 18:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-10-13 18:55:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 18:55:31 --> Final output sent to browser
DEBUG - 2023-10-13 18:55:31 --> Total execution time: 0.0749
INFO - 2023-10-13 18:55:39 --> Config Class Initialized
INFO - 2023-10-13 18:55:39 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:55:39 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:55:39 --> Utf8 Class Initialized
INFO - 2023-10-13 18:55:39 --> URI Class Initialized
INFO - 2023-10-13 18:55:39 --> Router Class Initialized
INFO - 2023-10-13 18:55:39 --> Output Class Initialized
INFO - 2023-10-13 18:55:39 --> Security Class Initialized
DEBUG - 2023-10-13 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:55:39 --> Input Class Initialized
INFO - 2023-10-13 18:55:39 --> Language Class Initialized
INFO - 2023-10-13 18:55:39 --> Loader Class Initialized
INFO - 2023-10-13 18:55:39 --> Helper loaded: url_helper
INFO - 2023-10-13 18:55:39 --> Helper loaded: file_helper
INFO - 2023-10-13 18:55:39 --> Database Driver Class Initialized
INFO - 2023-10-13 18:55:39 --> Email Class Initialized
DEBUG - 2023-10-13 18:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:55:39 --> Controller Class Initialized
INFO - 2023-10-13 18:55:39 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:55:39 --> Model "Home_model" initialized
INFO - 2023-10-13 18:55:39 --> Helper loaded: download_helper
INFO - 2023-10-13 18:55:39 --> Helper loaded: form_helper
INFO - 2023-10-13 18:55:39 --> Form Validation Class Initialized
INFO - 2023-10-13 18:55:39 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:55:39 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:55:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:55:39 --> Final output sent to browser
DEBUG - 2023-10-13 18:55:39 --> Total execution time: 0.1179
INFO - 2023-10-13 18:55:54 --> Config Class Initialized
INFO - 2023-10-13 18:55:54 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:55:54 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:55:54 --> Utf8 Class Initialized
INFO - 2023-10-13 18:55:54 --> URI Class Initialized
INFO - 2023-10-13 18:55:54 --> Router Class Initialized
INFO - 2023-10-13 18:55:54 --> Output Class Initialized
INFO - 2023-10-13 18:55:54 --> Security Class Initialized
DEBUG - 2023-10-13 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:55:54 --> Input Class Initialized
INFO - 2023-10-13 18:55:54 --> Language Class Initialized
INFO - 2023-10-13 18:55:54 --> Loader Class Initialized
INFO - 2023-10-13 18:55:54 --> Helper loaded: url_helper
INFO - 2023-10-13 18:55:54 --> Helper loaded: file_helper
INFO - 2023-10-13 18:55:54 --> Database Driver Class Initialized
INFO - 2023-10-13 18:55:54 --> Email Class Initialized
DEBUG - 2023-10-13 18:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:55:54 --> Controller Class Initialized
INFO - 2023-10-13 18:55:54 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:55:54 --> Model "Home_model" initialized
INFO - 2023-10-13 18:55:54 --> Helper loaded: download_helper
INFO - 2023-10-13 18:55:54 --> Helper loaded: form_helper
INFO - 2023-10-13 18:55:54 --> Form Validation Class Initialized
INFO - 2023-10-13 18:55:54 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:55:54 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:55:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:55:54 --> Final output sent to browser
DEBUG - 2023-10-13 18:55:54 --> Total execution time: 0.1162
INFO - 2023-10-13 18:57:21 --> Config Class Initialized
INFO - 2023-10-13 18:57:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:57:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:57:21 --> Utf8 Class Initialized
INFO - 2023-10-13 18:57:21 --> URI Class Initialized
INFO - 2023-10-13 18:57:21 --> Router Class Initialized
INFO - 2023-10-13 18:57:21 --> Output Class Initialized
INFO - 2023-10-13 18:57:21 --> Security Class Initialized
DEBUG - 2023-10-13 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:57:21 --> Input Class Initialized
INFO - 2023-10-13 18:57:21 --> Language Class Initialized
INFO - 2023-10-13 18:57:21 --> Loader Class Initialized
INFO - 2023-10-13 18:57:21 --> Helper loaded: url_helper
INFO - 2023-10-13 18:57:21 --> Helper loaded: file_helper
INFO - 2023-10-13 18:57:21 --> Database Driver Class Initialized
INFO - 2023-10-13 18:57:21 --> Email Class Initialized
DEBUG - 2023-10-13 18:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:57:21 --> Controller Class Initialized
INFO - 2023-10-13 18:57:21 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:57:21 --> Model "Home_model" initialized
INFO - 2023-10-13 18:57:21 --> Helper loaded: download_helper
INFO - 2023-10-13 18:57:22 --> Helper loaded: form_helper
INFO - 2023-10-13 18:57:22 --> Form Validation Class Initialized
INFO - 2023-10-13 18:57:27 --> Config Class Initialized
INFO - 2023-10-13 18:57:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:57:27 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:57:27 --> Utf8 Class Initialized
INFO - 2023-10-13 18:57:27 --> URI Class Initialized
INFO - 2023-10-13 18:57:27 --> Router Class Initialized
INFO - 2023-10-13 18:57:27 --> Output Class Initialized
INFO - 2023-10-13 18:57:27 --> Security Class Initialized
DEBUG - 2023-10-13 18:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:57:27 --> Input Class Initialized
INFO - 2023-10-13 18:57:27 --> Language Class Initialized
INFO - 2023-10-13 18:57:27 --> Loader Class Initialized
INFO - 2023-10-13 18:57:27 --> Helper loaded: url_helper
INFO - 2023-10-13 18:57:27 --> Helper loaded: file_helper
INFO - 2023-10-13 18:57:27 --> Database Driver Class Initialized
INFO - 2023-10-13 18:57:27 --> Email Class Initialized
DEBUG - 2023-10-13 18:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:57:27 --> Controller Class Initialized
INFO - 2023-10-13 18:57:27 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:57:27 --> Model "Home_model" initialized
INFO - 2023-10-13 18:57:27 --> Helper loaded: download_helper
INFO - 2023-10-13 18:57:27 --> Helper loaded: form_helper
INFO - 2023-10-13 18:57:27 --> Form Validation Class Initialized
INFO - 2023-10-13 18:58:44 --> Config Class Initialized
INFO - 2023-10-13 18:58:44 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:58:44 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:58:44 --> Utf8 Class Initialized
INFO - 2023-10-13 18:58:44 --> URI Class Initialized
INFO - 2023-10-13 18:58:44 --> Router Class Initialized
INFO - 2023-10-13 18:58:44 --> Output Class Initialized
INFO - 2023-10-13 18:58:44 --> Security Class Initialized
DEBUG - 2023-10-13 18:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:58:44 --> Input Class Initialized
INFO - 2023-10-13 18:58:44 --> Language Class Initialized
INFO - 2023-10-13 18:58:44 --> Loader Class Initialized
INFO - 2023-10-13 18:58:44 --> Helper loaded: url_helper
INFO - 2023-10-13 18:58:44 --> Helper loaded: file_helper
INFO - 2023-10-13 18:58:44 --> Database Driver Class Initialized
INFO - 2023-10-13 18:58:44 --> Email Class Initialized
DEBUG - 2023-10-13 18:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:58:44 --> Controller Class Initialized
INFO - 2023-10-13 18:58:44 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:58:44 --> Model "Home_model" initialized
INFO - 2023-10-13 18:58:44 --> Helper loaded: download_helper
INFO - 2023-10-13 18:58:44 --> Helper loaded: form_helper
INFO - 2023-10-13 18:58:44 --> Form Validation Class Initialized
INFO - 2023-10-13 18:58:44 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:58:44 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:58:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:58:44 --> Final output sent to browser
DEBUG - 2023-10-13 18:58:44 --> Total execution time: 0.1603
INFO - 2023-10-13 18:59:37 --> Config Class Initialized
INFO - 2023-10-13 18:59:37 --> Hooks Class Initialized
DEBUG - 2023-10-13 18:59:37 --> UTF-8 Support Enabled
INFO - 2023-10-13 18:59:37 --> Utf8 Class Initialized
INFO - 2023-10-13 18:59:37 --> URI Class Initialized
INFO - 2023-10-13 18:59:37 --> Router Class Initialized
INFO - 2023-10-13 18:59:37 --> Output Class Initialized
INFO - 2023-10-13 18:59:37 --> Security Class Initialized
DEBUG - 2023-10-13 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 18:59:37 --> Input Class Initialized
INFO - 2023-10-13 18:59:37 --> Language Class Initialized
INFO - 2023-10-13 18:59:37 --> Loader Class Initialized
INFO - 2023-10-13 18:59:37 --> Helper loaded: url_helper
INFO - 2023-10-13 18:59:37 --> Helper loaded: file_helper
INFO - 2023-10-13 18:59:37 --> Database Driver Class Initialized
INFO - 2023-10-13 18:59:37 --> Email Class Initialized
DEBUG - 2023-10-13 18:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 18:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 18:59:37 --> Controller Class Initialized
INFO - 2023-10-13 18:59:37 --> Model "Contact_model" initialized
INFO - 2023-10-13 18:59:37 --> Model "Home_model" initialized
INFO - 2023-10-13 18:59:37 --> Helper loaded: download_helper
INFO - 2023-10-13 18:59:37 --> Helper loaded: form_helper
INFO - 2023-10-13 18:59:37 --> Form Validation Class Initialized
INFO - 2023-10-13 18:59:37 --> Helper loaded: custom_helper
INFO - 2023-10-13 18:59:37 --> Model "Social_media_model" initialized
INFO - 2023-10-13 18:59:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 18:59:37 --> Final output sent to browser
DEBUG - 2023-10-13 18:59:37 --> Total execution time: 0.2748
INFO - 2023-10-13 19:00:17 --> Config Class Initialized
INFO - 2023-10-13 19:00:17 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:00:17 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:00:17 --> Utf8 Class Initialized
INFO - 2023-10-13 19:00:17 --> URI Class Initialized
INFO - 2023-10-13 19:00:17 --> Router Class Initialized
INFO - 2023-10-13 19:00:17 --> Output Class Initialized
INFO - 2023-10-13 19:00:17 --> Security Class Initialized
DEBUG - 2023-10-13 19:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:00:17 --> Input Class Initialized
INFO - 2023-10-13 19:00:17 --> Language Class Initialized
INFO - 2023-10-13 19:00:17 --> Loader Class Initialized
INFO - 2023-10-13 19:00:17 --> Helper loaded: url_helper
INFO - 2023-10-13 19:00:17 --> Helper loaded: file_helper
INFO - 2023-10-13 19:00:17 --> Database Driver Class Initialized
INFO - 2023-10-13 19:00:17 --> Email Class Initialized
DEBUG - 2023-10-13 19:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:00:17 --> Controller Class Initialized
INFO - 2023-10-13 19:00:17 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:00:17 --> Helper loaded: form_helper
INFO - 2023-10-13 19:00:17 --> Form Validation Class Initialized
INFO - 2023-10-13 19:00:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:00:17 --> Final output sent to browser
DEBUG - 2023-10-13 19:00:17 --> Total execution time: 0.1044
INFO - 2023-10-13 19:00:18 --> Config Class Initialized
INFO - 2023-10-13 19:00:18 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:00:18 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:00:18 --> Utf8 Class Initialized
INFO - 2023-10-13 19:00:18 --> URI Class Initialized
INFO - 2023-10-13 19:00:18 --> Router Class Initialized
INFO - 2023-10-13 19:00:18 --> Output Class Initialized
INFO - 2023-10-13 19:00:18 --> Security Class Initialized
DEBUG - 2023-10-13 19:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:00:18 --> Input Class Initialized
INFO - 2023-10-13 19:00:18 --> Language Class Initialized
ERROR - 2023-10-13 19:00:18 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-13 19:00:19 --> Config Class Initialized
INFO - 2023-10-13 19:00:19 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:00:19 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:00:19 --> Utf8 Class Initialized
INFO - 2023-10-13 19:00:19 --> URI Class Initialized
INFO - 2023-10-13 19:00:19 --> Router Class Initialized
INFO - 2023-10-13 19:00:19 --> Output Class Initialized
INFO - 2023-10-13 19:00:19 --> Security Class Initialized
DEBUG - 2023-10-13 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:00:19 --> Input Class Initialized
INFO - 2023-10-13 19:00:19 --> Language Class Initialized
INFO - 2023-10-13 19:00:19 --> Loader Class Initialized
INFO - 2023-10-13 19:00:19 --> Helper loaded: url_helper
INFO - 2023-10-13 19:00:19 --> Helper loaded: file_helper
INFO - 2023-10-13 19:00:19 --> Database Driver Class Initialized
INFO - 2023-10-13 19:00:19 --> Email Class Initialized
DEBUG - 2023-10-13 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:00:19 --> Controller Class Initialized
INFO - 2023-10-13 19:00:19 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:00:19 --> Helper loaded: form_helper
INFO - 2023-10-13 19:00:19 --> Form Validation Class Initialized
INFO - 2023-10-13 19:00:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-10-13 19:00:19 --> Final output sent to browser
DEBUG - 2023-10-13 19:00:19 --> Total execution time: 0.1026
INFO - 2023-10-13 19:00:20 --> Config Class Initialized
INFO - 2023-10-13 19:00:20 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:00:20 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:00:20 --> Utf8 Class Initialized
INFO - 2023-10-13 19:00:20 --> URI Class Initialized
INFO - 2023-10-13 19:00:20 --> Router Class Initialized
INFO - 2023-10-13 19:00:20 --> Output Class Initialized
INFO - 2023-10-13 19:00:20 --> Security Class Initialized
DEBUG - 2023-10-13 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:00:20 --> Input Class Initialized
INFO - 2023-10-13 19:00:20 --> Language Class Initialized
ERROR - 2023-10-13 19:00:20 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-10-13 19:02:59 --> Config Class Initialized
INFO - 2023-10-13 19:02:59 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:02:59 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:02:59 --> Utf8 Class Initialized
INFO - 2023-10-13 19:02:59 --> URI Class Initialized
INFO - 2023-10-13 19:02:59 --> Router Class Initialized
INFO - 2023-10-13 19:02:59 --> Output Class Initialized
INFO - 2023-10-13 19:02:59 --> Security Class Initialized
DEBUG - 2023-10-13 19:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:02:59 --> Input Class Initialized
INFO - 2023-10-13 19:02:59 --> Language Class Initialized
INFO - 2023-10-13 19:02:59 --> Loader Class Initialized
INFO - 2023-10-13 19:02:59 --> Helper loaded: url_helper
INFO - 2023-10-13 19:02:59 --> Helper loaded: file_helper
INFO - 2023-10-13 19:02:59 --> Database Driver Class Initialized
INFO - 2023-10-13 19:02:59 --> Email Class Initialized
DEBUG - 2023-10-13 19:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:00 --> Controller Class Initialized
INFO - 2023-10-13 19:03:00 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:03:00 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:00 --> Form Validation Class Initialized
INFO - 2023-10-13 19:03:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:03:00 --> Config Class Initialized
INFO - 2023-10-13 19:03:00 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:03:00 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:03:00 --> Utf8 Class Initialized
INFO - 2023-10-13 19:03:00 --> URI Class Initialized
INFO - 2023-10-13 19:03:00 --> Router Class Initialized
INFO - 2023-10-13 19:03:00 --> Output Class Initialized
INFO - 2023-10-13 19:03:00 --> Security Class Initialized
DEBUG - 2023-10-13 19:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:03:00 --> Input Class Initialized
INFO - 2023-10-13 19:03:00 --> Language Class Initialized
INFO - 2023-10-13 19:03:00 --> Loader Class Initialized
INFO - 2023-10-13 19:03:00 --> Helper loaded: url_helper
INFO - 2023-10-13 19:03:00 --> Helper loaded: file_helper
INFO - 2023-10-13 19:03:00 --> Database Driver Class Initialized
INFO - 2023-10-13 19:03:00 --> Email Class Initialized
DEBUG - 2023-10-13 19:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:00 --> Controller Class Initialized
INFO - 2023-10-13 19:03:00 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:03:00 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:00 --> Form Validation Class Initialized
INFO - 2023-10-13 19:03:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:03:00 --> Final output sent to browser
DEBUG - 2023-10-13 19:03:01 --> Total execution time: 0.3129
INFO - 2023-10-13 19:03:05 --> Config Class Initialized
INFO - 2023-10-13 19:03:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:03:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:03:06 --> Utf8 Class Initialized
INFO - 2023-10-13 19:03:06 --> URI Class Initialized
INFO - 2023-10-13 19:03:06 --> Router Class Initialized
INFO - 2023-10-13 19:03:06 --> Output Class Initialized
INFO - 2023-10-13 19:03:06 --> Security Class Initialized
DEBUG - 2023-10-13 19:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:03:06 --> Input Class Initialized
INFO - 2023-10-13 19:03:06 --> Language Class Initialized
INFO - 2023-10-13 19:03:06 --> Loader Class Initialized
INFO - 2023-10-13 19:03:06 --> Helper loaded: url_helper
INFO - 2023-10-13 19:03:06 --> Helper loaded: file_helper
INFO - 2023-10-13 19:03:06 --> Database Driver Class Initialized
INFO - 2023-10-13 19:03:06 --> Email Class Initialized
DEBUG - 2023-10-13 19:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:06 --> Controller Class Initialized
INFO - 2023-10-13 19:03:06 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:03:06 --> Model "Home_model" initialized
INFO - 2023-10-13 19:03:06 --> Helper loaded: download_helper
INFO - 2023-10-13 19:03:06 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:06 --> Form Validation Class Initialized
INFO - 2023-10-13 19:03:06 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:03:06 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:03:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-13 19:03:06 --> Final output sent to browser
DEBUG - 2023-10-13 19:03:06 --> Total execution time: 0.1544
INFO - 2023-10-13 19:03:12 --> Config Class Initialized
INFO - 2023-10-13 19:03:12 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:03:12 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:03:12 --> Utf8 Class Initialized
INFO - 2023-10-13 19:03:12 --> URI Class Initialized
INFO - 2023-10-13 19:03:12 --> Router Class Initialized
INFO - 2023-10-13 19:03:12 --> Output Class Initialized
INFO - 2023-10-13 19:03:12 --> Security Class Initialized
DEBUG - 2023-10-13 19:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:03:12 --> Input Class Initialized
INFO - 2023-10-13 19:03:12 --> Language Class Initialized
INFO - 2023-10-13 19:03:12 --> Loader Class Initialized
INFO - 2023-10-13 19:03:12 --> Helper loaded: url_helper
INFO - 2023-10-13 19:03:12 --> Helper loaded: file_helper
INFO - 2023-10-13 19:03:12 --> Database Driver Class Initialized
INFO - 2023-10-13 19:03:12 --> Email Class Initialized
DEBUG - 2023-10-13 19:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:12 --> Controller Class Initialized
INFO - 2023-10-13 19:03:12 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:03:12 --> Model "Home_model" initialized
INFO - 2023-10-13 19:03:12 --> Helper loaded: download_helper
INFO - 2023-10-13 19:03:12 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:12 --> Form Validation Class Initialized
INFO - 2023-10-13 19:03:12 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:03:12 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:03:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 19:03:12 --> Final output sent to browser
DEBUG - 2023-10-13 19:03:12 --> Total execution time: 0.0660
INFO - 2023-10-13 19:03:58 --> Config Class Initialized
INFO - 2023-10-13 19:03:58 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:03:58 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:03:58 --> Utf8 Class Initialized
INFO - 2023-10-13 19:03:58 --> URI Class Initialized
INFO - 2023-10-13 19:03:58 --> Router Class Initialized
INFO - 2023-10-13 19:03:58 --> Output Class Initialized
INFO - 2023-10-13 19:03:58 --> Security Class Initialized
DEBUG - 2023-10-13 19:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:03:58 --> Input Class Initialized
INFO - 2023-10-13 19:03:58 --> Language Class Initialized
INFO - 2023-10-13 19:03:58 --> Loader Class Initialized
INFO - 2023-10-13 19:03:58 --> Helper loaded: url_helper
INFO - 2023-10-13 19:03:58 --> Helper loaded: file_helper
INFO - 2023-10-13 19:03:58 --> Database Driver Class Initialized
INFO - 2023-10-13 19:03:58 --> Email Class Initialized
DEBUG - 2023-10-13 19:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:58 --> Controller Class Initialized
INFO - 2023-10-13 19:03:58 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:03:58 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:58 --> Form Validation Class Initialized
INFO - 2023-10-13 19:03:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:03:58 --> Final output sent to browser
DEBUG - 2023-10-13 19:03:58 --> Total execution time: 0.0920
INFO - 2023-10-13 19:03:59 --> Config Class Initialized
INFO - 2023-10-13 19:03:59 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:03:59 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:03:59 --> Utf8 Class Initialized
INFO - 2023-10-13 19:03:59 --> URI Class Initialized
INFO - 2023-10-13 19:03:59 --> Router Class Initialized
INFO - 2023-10-13 19:03:59 --> Output Class Initialized
INFO - 2023-10-13 19:03:59 --> Security Class Initialized
DEBUG - 2023-10-13 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:03:59 --> Input Class Initialized
INFO - 2023-10-13 19:03:59 --> Language Class Initialized
INFO - 2023-10-13 19:03:59 --> Loader Class Initialized
INFO - 2023-10-13 19:03:59 --> Helper loaded: url_helper
INFO - 2023-10-13 19:03:59 --> Helper loaded: file_helper
INFO - 2023-10-13 19:03:59 --> Database Driver Class Initialized
INFO - 2023-10-13 19:03:59 --> Email Class Initialized
DEBUG - 2023-10-13 19:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:03:59 --> Controller Class Initialized
INFO - 2023-10-13 19:03:59 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:03:59 --> Helper loaded: form_helper
INFO - 2023-10-13 19:03:59 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-10-13 19:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-10-13 19:03:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:03:59 --> Final output sent to browser
DEBUG - 2023-10-13 19:03:59 --> Total execution time: 0.1301
INFO - 2023-10-13 19:04:07 --> Config Class Initialized
INFO - 2023-10-13 19:04:07 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:04:07 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:04:07 --> Utf8 Class Initialized
INFO - 2023-10-13 19:04:07 --> URI Class Initialized
INFO - 2023-10-13 19:04:07 --> Router Class Initialized
INFO - 2023-10-13 19:04:07 --> Output Class Initialized
INFO - 2023-10-13 19:04:07 --> Security Class Initialized
DEBUG - 2023-10-13 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:04:07 --> Input Class Initialized
INFO - 2023-10-13 19:04:07 --> Language Class Initialized
INFO - 2023-10-13 19:04:07 --> Loader Class Initialized
INFO - 2023-10-13 19:04:07 --> Helper loaded: url_helper
INFO - 2023-10-13 19:04:07 --> Helper loaded: file_helper
INFO - 2023-10-13 19:04:07 --> Database Driver Class Initialized
INFO - 2023-10-13 19:04:07 --> Email Class Initialized
DEBUG - 2023-10-13 19:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:04:07 --> Controller Class Initialized
INFO - 2023-10-13 19:04:07 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:04:07 --> Helper loaded: form_helper
INFO - 2023-10-13 19:04:07 --> Form Validation Class Initialized
INFO - 2023-10-13 19:04:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:04:07 --> Config Class Initialized
INFO - 2023-10-13 19:04:07 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:04:07 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:04:07 --> Utf8 Class Initialized
INFO - 2023-10-13 19:04:07 --> URI Class Initialized
INFO - 2023-10-13 19:04:07 --> Router Class Initialized
INFO - 2023-10-13 19:04:07 --> Output Class Initialized
INFO - 2023-10-13 19:04:07 --> Security Class Initialized
DEBUG - 2023-10-13 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:04:07 --> Input Class Initialized
INFO - 2023-10-13 19:04:07 --> Language Class Initialized
INFO - 2023-10-13 19:04:07 --> Loader Class Initialized
INFO - 2023-10-13 19:04:07 --> Helper loaded: url_helper
INFO - 2023-10-13 19:04:07 --> Helper loaded: file_helper
INFO - 2023-10-13 19:04:07 --> Database Driver Class Initialized
INFO - 2023-10-13 19:04:07 --> Email Class Initialized
DEBUG - 2023-10-13 19:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:04:07 --> Controller Class Initialized
INFO - 2023-10-13 19:04:07 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:04:07 --> Helper loaded: form_helper
INFO - 2023-10-13 19:04:07 --> Form Validation Class Initialized
INFO - 2023-10-13 19:04:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:04:07 --> Final output sent to browser
DEBUG - 2023-10-13 19:04:08 --> Total execution time: 0.1096
INFO - 2023-10-13 19:04:10 --> Config Class Initialized
INFO - 2023-10-13 19:04:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:04:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:04:10 --> Utf8 Class Initialized
INFO - 2023-10-13 19:04:10 --> URI Class Initialized
INFO - 2023-10-13 19:04:10 --> Router Class Initialized
INFO - 2023-10-13 19:04:10 --> Output Class Initialized
INFO - 2023-10-13 19:04:10 --> Security Class Initialized
DEBUG - 2023-10-13 19:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:04:10 --> Input Class Initialized
INFO - 2023-10-13 19:04:10 --> Language Class Initialized
INFO - 2023-10-13 19:04:10 --> Loader Class Initialized
INFO - 2023-10-13 19:04:10 --> Helper loaded: url_helper
INFO - 2023-10-13 19:04:10 --> Helper loaded: file_helper
INFO - 2023-10-13 19:04:10 --> Database Driver Class Initialized
INFO - 2023-10-13 19:04:10 --> Email Class Initialized
DEBUG - 2023-10-13 19:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:04:10 --> Controller Class Initialized
INFO - 2023-10-13 19:04:10 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:04:10 --> Model "Home_model" initialized
INFO - 2023-10-13 19:04:10 --> Helper loaded: download_helper
INFO - 2023-10-13 19:04:10 --> Helper loaded: form_helper
INFO - 2023-10-13 19:04:10 --> Form Validation Class Initialized
INFO - 2023-10-13 19:04:10 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:04:10 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:04:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 19:04:10 --> Final output sent to browser
DEBUG - 2023-10-13 19:04:10 --> Total execution time: 0.1573
INFO - 2023-10-13 19:09:00 --> Config Class Initialized
INFO - 2023-10-13 19:09:00 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:09:00 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:09:00 --> Utf8 Class Initialized
INFO - 2023-10-13 19:09:00 --> URI Class Initialized
INFO - 2023-10-13 19:09:00 --> Router Class Initialized
INFO - 2023-10-13 19:09:00 --> Output Class Initialized
INFO - 2023-10-13 19:09:00 --> Security Class Initialized
DEBUG - 2023-10-13 19:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:09:00 --> Input Class Initialized
INFO - 2023-10-13 19:09:00 --> Language Class Initialized
INFO - 2023-10-13 19:09:00 --> Loader Class Initialized
INFO - 2023-10-13 19:09:00 --> Helper loaded: url_helper
INFO - 2023-10-13 19:09:00 --> Helper loaded: file_helper
INFO - 2023-10-13 19:09:00 --> Database Driver Class Initialized
INFO - 2023-10-13 19:09:00 --> Email Class Initialized
DEBUG - 2023-10-13 19:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:09:00 --> Controller Class Initialized
INFO - 2023-10-13 19:09:00 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:09:00 --> Helper loaded: form_helper
INFO - 2023-10-13 19:09:00 --> Form Validation Class Initialized
INFO - 2023-10-13 19:09:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-10-13 19:09:00 --> Final output sent to browser
DEBUG - 2023-10-13 19:09:00 --> Total execution time: 0.1383
INFO - 2023-10-13 19:12:00 --> Config Class Initialized
INFO - 2023-10-13 19:12:00 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:00 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:00 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:00 --> URI Class Initialized
INFO - 2023-10-13 19:12:00 --> Router Class Initialized
INFO - 2023-10-13 19:12:00 --> Output Class Initialized
INFO - 2023-10-13 19:12:00 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:00 --> Input Class Initialized
INFO - 2023-10-13 19:12:00 --> Language Class Initialized
INFO - 2023-10-13 19:12:00 --> Loader Class Initialized
INFO - 2023-10-13 19:12:00 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:00 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:00 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:00 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:00 --> Controller Class Initialized
INFO - 2023-10-13 19:12:00 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:00 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:00 --> Form Validation Class Initialized
INFO - 2023-10-13 19:12:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-10-13 19:12:00 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:00 --> Total execution time: 0.1310
INFO - 2023-10-13 19:12:02 --> Config Class Initialized
INFO - 2023-10-13 19:12:02 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:02 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:02 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:02 --> URI Class Initialized
INFO - 2023-10-13 19:12:02 --> Router Class Initialized
INFO - 2023-10-13 19:12:02 --> Output Class Initialized
INFO - 2023-10-13 19:12:02 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:02 --> Input Class Initialized
INFO - 2023-10-13 19:12:02 --> Language Class Initialized
ERROR - 2023-10-13 19:12:02 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-10-13 19:12:26 --> Config Class Initialized
INFO - 2023-10-13 19:12:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:27 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:27 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:27 --> URI Class Initialized
INFO - 2023-10-13 19:12:27 --> Router Class Initialized
INFO - 2023-10-13 19:12:27 --> Output Class Initialized
INFO - 2023-10-13 19:12:27 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:27 --> Input Class Initialized
INFO - 2023-10-13 19:12:27 --> Language Class Initialized
INFO - 2023-10-13 19:12:27 --> Loader Class Initialized
INFO - 2023-10-13 19:12:27 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:27 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:27 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:27 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:27 --> Controller Class Initialized
INFO - 2023-10-13 19:12:27 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:27 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:27 --> Form Validation Class Initialized
INFO - 2023-10-13 19:12:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:12:27 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:27 --> Total execution time: 0.0932
INFO - 2023-10-13 19:12:27 --> Config Class Initialized
INFO - 2023-10-13 19:12:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:27 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:27 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:27 --> URI Class Initialized
INFO - 2023-10-13 19:12:27 --> Router Class Initialized
INFO - 2023-10-13 19:12:27 --> Output Class Initialized
INFO - 2023-10-13 19:12:27 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:27 --> Input Class Initialized
INFO - 2023-10-13 19:12:27 --> Language Class Initialized
ERROR - 2023-10-13 19:12:27 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-13 19:12:31 --> Config Class Initialized
INFO - 2023-10-13 19:12:31 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:31 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:31 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:31 --> URI Class Initialized
INFO - 2023-10-13 19:12:31 --> Router Class Initialized
INFO - 2023-10-13 19:12:31 --> Output Class Initialized
INFO - 2023-10-13 19:12:31 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:31 --> Input Class Initialized
INFO - 2023-10-13 19:12:31 --> Language Class Initialized
INFO - 2023-10-13 19:12:31 --> Loader Class Initialized
INFO - 2023-10-13 19:12:31 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:31 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:31 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:31 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:31 --> Controller Class Initialized
INFO - 2023-10-13 19:12:31 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:31 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:31 --> Form Validation Class Initialized
INFO - 2023-10-13 19:12:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:12:31 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:31 --> Total execution time: 0.1530
INFO - 2023-10-13 19:12:32 --> Config Class Initialized
INFO - 2023-10-13 19:12:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:32 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:32 --> URI Class Initialized
INFO - 2023-10-13 19:12:32 --> Router Class Initialized
INFO - 2023-10-13 19:12:32 --> Output Class Initialized
INFO - 2023-10-13 19:12:32 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:32 --> Input Class Initialized
INFO - 2023-10-13 19:12:32 --> Language Class Initialized
INFO - 2023-10-13 19:12:32 --> Loader Class Initialized
INFO - 2023-10-13 19:12:32 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:32 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:32 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:32 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:32 --> Controller Class Initialized
INFO - 2023-10-13 19:12:32 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:32 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:32 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 85
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 100
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 111
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 123
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 133
ERROR - 2023-10-13 19:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
INFO - 2023-10-13 19:12:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:12:32 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:32 --> Total execution time: 0.1480
INFO - 2023-10-13 19:12:43 --> Config Class Initialized
INFO - 2023-10-13 19:12:43 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:43 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:43 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:43 --> URI Class Initialized
INFO - 2023-10-13 19:12:43 --> Router Class Initialized
INFO - 2023-10-13 19:12:43 --> Output Class Initialized
INFO - 2023-10-13 19:12:43 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:43 --> Input Class Initialized
INFO - 2023-10-13 19:12:43 --> Language Class Initialized
INFO - 2023-10-13 19:12:43 --> Loader Class Initialized
INFO - 2023-10-13 19:12:43 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:43 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:43 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:43 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:43 --> Controller Class Initialized
INFO - 2023-10-13 19:12:43 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:43 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:43 --> Form Validation Class Initialized
INFO - 2023-10-13 19:12:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:12:43 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:43 --> Total execution time: 0.1111
INFO - 2023-10-13 19:12:45 --> Config Class Initialized
INFO - 2023-10-13 19:12:45 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:12:45 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:12:45 --> Utf8 Class Initialized
INFO - 2023-10-13 19:12:45 --> URI Class Initialized
INFO - 2023-10-13 19:12:45 --> Router Class Initialized
INFO - 2023-10-13 19:12:45 --> Output Class Initialized
INFO - 2023-10-13 19:12:45 --> Security Class Initialized
DEBUG - 2023-10-13 19:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:12:45 --> Input Class Initialized
INFO - 2023-10-13 19:12:45 --> Language Class Initialized
INFO - 2023-10-13 19:12:45 --> Loader Class Initialized
INFO - 2023-10-13 19:12:45 --> Helper loaded: url_helper
INFO - 2023-10-13 19:12:45 --> Helper loaded: file_helper
INFO - 2023-10-13 19:12:45 --> Database Driver Class Initialized
INFO - 2023-10-13 19:12:45 --> Email Class Initialized
DEBUG - 2023-10-13 19:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:12:45 --> Controller Class Initialized
INFO - 2023-10-13 19:12:45 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:12:45 --> Helper loaded: form_helper
INFO - 2023-10-13 19:12:45 --> Form Validation Class Initialized
INFO - 2023-10-13 19:12:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-10-13 19:12:45 --> Final output sent to browser
DEBUG - 2023-10-13 19:12:45 --> Total execution time: 0.0995
INFO - 2023-10-13 19:13:16 --> Config Class Initialized
INFO - 2023-10-13 19:13:16 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:16 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:16 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:16 --> URI Class Initialized
INFO - 2023-10-13 19:13:16 --> Router Class Initialized
INFO - 2023-10-13 19:13:16 --> Output Class Initialized
INFO - 2023-10-13 19:13:16 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:16 --> Input Class Initialized
INFO - 2023-10-13 19:13:16 --> Language Class Initialized
INFO - 2023-10-13 19:13:16 --> Loader Class Initialized
INFO - 2023-10-13 19:13:16 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:16 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:16 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:16 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:16 --> Controller Class Initialized
INFO - 2023-10-13 19:13:16 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:16 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:16 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:13:17 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:17 --> Total execution time: 0.0900
INFO - 2023-10-13 19:13:22 --> Config Class Initialized
INFO - 2023-10-13 19:13:22 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:22 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:22 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:22 --> URI Class Initialized
INFO - 2023-10-13 19:13:22 --> Router Class Initialized
INFO - 2023-10-13 19:13:22 --> Output Class Initialized
INFO - 2023-10-13 19:13:22 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:22 --> Input Class Initialized
INFO - 2023-10-13 19:13:22 --> Language Class Initialized
INFO - 2023-10-13 19:13:22 --> Loader Class Initialized
INFO - 2023-10-13 19:13:22 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:22 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:22 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:22 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:22 --> Controller Class Initialized
INFO - 2023-10-13 19:13:22 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:22 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:22 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:22 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:22 --> Total execution time: 0.1665
INFO - 2023-10-13 19:13:22 --> Config Class Initialized
INFO - 2023-10-13 19:13:22 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:22 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:22 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:22 --> URI Class Initialized
INFO - 2023-10-13 19:13:22 --> Router Class Initialized
INFO - 2023-10-13 19:13:22 --> Output Class Initialized
INFO - 2023-10-13 19:13:22 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:22 --> Input Class Initialized
INFO - 2023-10-13 19:13:22 --> Language Class Initialized
INFO - 2023-10-13 19:13:22 --> Loader Class Initialized
INFO - 2023-10-13 19:13:22 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:22 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:22 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:22 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:22 --> Controller Class Initialized
INFO - 2023-10-13 19:13:22 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:23 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:23 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 87
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 102
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 113
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 125
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
ERROR - 2023-10-13 19:13:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 137
INFO - 2023-10-13 19:13:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:23 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:23 --> Total execution time: 0.1392
INFO - 2023-10-13 19:13:37 --> Config Class Initialized
INFO - 2023-10-13 19:13:37 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:37 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:37 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:37 --> URI Class Initialized
INFO - 2023-10-13 19:13:37 --> Router Class Initialized
INFO - 2023-10-13 19:13:37 --> Output Class Initialized
INFO - 2023-10-13 19:13:37 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:37 --> Input Class Initialized
INFO - 2023-10-13 19:13:37 --> Language Class Initialized
INFO - 2023-10-13 19:13:37 --> Loader Class Initialized
INFO - 2023-10-13 19:13:37 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:37 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:37 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:37 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:37 --> Controller Class Initialized
INFO - 2023-10-13 19:13:37 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:37 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:37 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:13:37 --> Config Class Initialized
INFO - 2023-10-13 19:13:37 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:37 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:37 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:37 --> URI Class Initialized
INFO - 2023-10-13 19:13:37 --> Router Class Initialized
INFO - 2023-10-13 19:13:37 --> Output Class Initialized
INFO - 2023-10-13 19:13:37 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:37 --> Input Class Initialized
INFO - 2023-10-13 19:13:37 --> Language Class Initialized
INFO - 2023-10-13 19:13:37 --> Loader Class Initialized
INFO - 2023-10-13 19:13:37 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:37 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:37 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:37 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:37 --> Controller Class Initialized
INFO - 2023-10-13 19:13:37 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:37 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:37 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:13:37 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:37 --> Total execution time: 0.0923
INFO - 2023-10-13 19:13:39 --> Config Class Initialized
INFO - 2023-10-13 19:13:39 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:39 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:39 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:39 --> URI Class Initialized
INFO - 2023-10-13 19:13:39 --> Router Class Initialized
INFO - 2023-10-13 19:13:39 --> Output Class Initialized
INFO - 2023-10-13 19:13:39 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:39 --> Input Class Initialized
INFO - 2023-10-13 19:13:39 --> Language Class Initialized
INFO - 2023-10-13 19:13:39 --> Loader Class Initialized
INFO - 2023-10-13 19:13:39 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:39 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:39 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:39 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:39 --> Controller Class Initialized
INFO - 2023-10-13 19:13:39 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:39 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:39 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:40 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:40 --> Total execution time: 0.1143
INFO - 2023-10-13 19:13:40 --> Config Class Initialized
INFO - 2023-10-13 19:13:40 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:40 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:40 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:40 --> URI Class Initialized
INFO - 2023-10-13 19:13:40 --> Router Class Initialized
INFO - 2023-10-13 19:13:40 --> Output Class Initialized
INFO - 2023-10-13 19:13:40 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:40 --> Input Class Initialized
INFO - 2023-10-13 19:13:40 --> Language Class Initialized
INFO - 2023-10-13 19:13:40 --> Loader Class Initialized
INFO - 2023-10-13 19:13:40 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:40 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:40 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:40 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:40 --> Controller Class Initialized
INFO - 2023-10-13 19:13:40 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:40 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:40 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 87
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 102
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 113
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 125
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
ERROR - 2023-10-13 19:13:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 137
INFO - 2023-10-13 19:13:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:40 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:40 --> Total execution time: 0.3345
INFO - 2023-10-13 19:13:42 --> Config Class Initialized
INFO - 2023-10-13 19:13:42 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:42 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:42 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:42 --> URI Class Initialized
INFO - 2023-10-13 19:13:42 --> Router Class Initialized
INFO - 2023-10-13 19:13:42 --> Output Class Initialized
INFO - 2023-10-13 19:13:42 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:42 --> Input Class Initialized
INFO - 2023-10-13 19:13:42 --> Language Class Initialized
INFO - 2023-10-13 19:13:42 --> Loader Class Initialized
INFO - 2023-10-13 19:13:42 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:42 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:42 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:42 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:42 --> Controller Class Initialized
INFO - 2023-10-13 19:13:42 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:42 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:42 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:13:42 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:43 --> Total execution time: 0.1191
INFO - 2023-10-13 19:13:44 --> Config Class Initialized
INFO - 2023-10-13 19:13:44 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:44 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:44 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:44 --> URI Class Initialized
INFO - 2023-10-13 19:13:44 --> Router Class Initialized
INFO - 2023-10-13 19:13:44 --> Output Class Initialized
INFO - 2023-10-13 19:13:44 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:44 --> Input Class Initialized
INFO - 2023-10-13 19:13:44 --> Language Class Initialized
INFO - 2023-10-13 19:13:44 --> Loader Class Initialized
INFO - 2023-10-13 19:13:44 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:44 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:44 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:44 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:44 --> Controller Class Initialized
INFO - 2023-10-13 19:13:44 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:44 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:44 --> Form Validation Class Initialized
INFO - 2023-10-13 19:13:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:44 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:44 --> Total execution time: 0.0509
INFO - 2023-10-13 19:13:45 --> Config Class Initialized
INFO - 2023-10-13 19:13:45 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:13:45 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:13:45 --> Utf8 Class Initialized
INFO - 2023-10-13 19:13:45 --> URI Class Initialized
INFO - 2023-10-13 19:13:45 --> Router Class Initialized
INFO - 2023-10-13 19:13:45 --> Output Class Initialized
INFO - 2023-10-13 19:13:45 --> Security Class Initialized
DEBUG - 2023-10-13 19:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:13:45 --> Input Class Initialized
INFO - 2023-10-13 19:13:45 --> Language Class Initialized
INFO - 2023-10-13 19:13:45 --> Loader Class Initialized
INFO - 2023-10-13 19:13:45 --> Helper loaded: url_helper
INFO - 2023-10-13 19:13:45 --> Helper loaded: file_helper
INFO - 2023-10-13 19:13:45 --> Database Driver Class Initialized
INFO - 2023-10-13 19:13:45 --> Email Class Initialized
DEBUG - 2023-10-13 19:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:13:45 --> Controller Class Initialized
INFO - 2023-10-13 19:13:45 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:13:45 --> Helper loaded: form_helper
INFO - 2023-10-13 19:13:45 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 87
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 102
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 113
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 125
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
ERROR - 2023-10-13 19:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 137
INFO - 2023-10-13 19:13:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:13:45 --> Final output sent to browser
DEBUG - 2023-10-13 19:13:45 --> Total execution time: 0.0655
INFO - 2023-10-13 19:14:11 --> Config Class Initialized
INFO - 2023-10-13 19:14:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:14:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:14:11 --> Utf8 Class Initialized
INFO - 2023-10-13 19:14:11 --> URI Class Initialized
INFO - 2023-10-13 19:14:11 --> Router Class Initialized
INFO - 2023-10-13 19:14:11 --> Output Class Initialized
INFO - 2023-10-13 19:14:11 --> Security Class Initialized
DEBUG - 2023-10-13 19:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:14:11 --> Input Class Initialized
INFO - 2023-10-13 19:14:11 --> Language Class Initialized
INFO - 2023-10-13 19:14:11 --> Loader Class Initialized
INFO - 2023-10-13 19:14:11 --> Helper loaded: url_helper
INFO - 2023-10-13 19:14:11 --> Helper loaded: file_helper
INFO - 2023-10-13 19:14:11 --> Database Driver Class Initialized
INFO - 2023-10-13 19:14:11 --> Email Class Initialized
DEBUG - 2023-10-13 19:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:14:11 --> Controller Class Initialized
INFO - 2023-10-13 19:14:11 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:14:11 --> Helper loaded: form_helper
INFO - 2023-10-13 19:14:11 --> Form Validation Class Initialized
INFO - 2023-10-13 19:14:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:14:11 --> Config Class Initialized
INFO - 2023-10-13 19:14:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:14:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:14:11 --> Utf8 Class Initialized
INFO - 2023-10-13 19:14:11 --> URI Class Initialized
INFO - 2023-10-13 19:14:11 --> Router Class Initialized
INFO - 2023-10-13 19:14:11 --> Output Class Initialized
INFO - 2023-10-13 19:14:11 --> Security Class Initialized
DEBUG - 2023-10-13 19:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:14:11 --> Input Class Initialized
INFO - 2023-10-13 19:14:11 --> Language Class Initialized
INFO - 2023-10-13 19:14:11 --> Loader Class Initialized
INFO - 2023-10-13 19:14:11 --> Helper loaded: url_helper
INFO - 2023-10-13 19:14:11 --> Helper loaded: file_helper
INFO - 2023-10-13 19:14:11 --> Database Driver Class Initialized
INFO - 2023-10-13 19:14:11 --> Email Class Initialized
DEBUG - 2023-10-13 19:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:14:11 --> Controller Class Initialized
INFO - 2023-10-13 19:14:11 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:14:11 --> Helper loaded: form_helper
INFO - 2023-10-13 19:14:11 --> Form Validation Class Initialized
INFO - 2023-10-13 19:14:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:14:11 --> Final output sent to browser
DEBUG - 2023-10-13 19:14:11 --> Total execution time: 0.0574
INFO - 2023-10-13 19:14:14 --> Config Class Initialized
INFO - 2023-10-13 19:14:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:14:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:14:14 --> Utf8 Class Initialized
INFO - 2023-10-13 19:14:14 --> URI Class Initialized
INFO - 2023-10-13 19:14:14 --> Router Class Initialized
INFO - 2023-10-13 19:14:14 --> Output Class Initialized
INFO - 2023-10-13 19:14:14 --> Security Class Initialized
DEBUG - 2023-10-13 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:14:14 --> Input Class Initialized
INFO - 2023-10-13 19:14:14 --> Language Class Initialized
INFO - 2023-10-13 19:14:14 --> Loader Class Initialized
INFO - 2023-10-13 19:14:14 --> Helper loaded: url_helper
INFO - 2023-10-13 19:14:14 --> Helper loaded: file_helper
INFO - 2023-10-13 19:14:14 --> Database Driver Class Initialized
INFO - 2023-10-13 19:14:14 --> Email Class Initialized
DEBUG - 2023-10-13 19:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:14:14 --> Controller Class Initialized
INFO - 2023-10-13 19:14:14 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:14:14 --> Helper loaded: form_helper
INFO - 2023-10-13 19:14:14 --> Form Validation Class Initialized
INFO - 2023-10-13 19:14:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:14:14 --> Final output sent to browser
DEBUG - 2023-10-13 19:14:14 --> Total execution time: 0.0546
INFO - 2023-10-13 19:14:14 --> Config Class Initialized
INFO - 2023-10-13 19:14:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:14:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:14:14 --> Utf8 Class Initialized
INFO - 2023-10-13 19:14:14 --> URI Class Initialized
INFO - 2023-10-13 19:14:14 --> Router Class Initialized
INFO - 2023-10-13 19:14:14 --> Output Class Initialized
INFO - 2023-10-13 19:14:14 --> Security Class Initialized
DEBUG - 2023-10-13 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:14:14 --> Input Class Initialized
INFO - 2023-10-13 19:14:14 --> Language Class Initialized
INFO - 2023-10-13 19:14:14 --> Loader Class Initialized
INFO - 2023-10-13 19:14:15 --> Helper loaded: url_helper
INFO - 2023-10-13 19:14:15 --> Helper loaded: file_helper
INFO - 2023-10-13 19:14:15 --> Database Driver Class Initialized
INFO - 2023-10-13 19:14:15 --> Email Class Initialized
DEBUG - 2023-10-13 19:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:14:15 --> Controller Class Initialized
INFO - 2023-10-13 19:14:15 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:14:15 --> Helper loaded: form_helper
INFO - 2023-10-13 19:14:15 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 87
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 102
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 113
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 125
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
ERROR - 2023-10-13 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 137
INFO - 2023-10-13 19:14:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:14:15 --> Final output sent to browser
DEBUG - 2023-10-13 19:14:15 --> Total execution time: 0.2631
INFO - 2023-10-13 19:15:03 --> Config Class Initialized
INFO - 2023-10-13 19:15:03 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:03 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:03 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:03 --> URI Class Initialized
INFO - 2023-10-13 19:15:03 --> Router Class Initialized
INFO - 2023-10-13 19:15:03 --> Output Class Initialized
INFO - 2023-10-13 19:15:03 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:03 --> Input Class Initialized
INFO - 2023-10-13 19:15:03 --> Language Class Initialized
INFO - 2023-10-13 19:15:03 --> Loader Class Initialized
INFO - 2023-10-13 19:15:03 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:03 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:03 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:03 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:03 --> Controller Class Initialized
INFO - 2023-10-13 19:15:03 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:15:03 --> Model "Home_model" initialized
INFO - 2023-10-13 19:15:03 --> Helper loaded: download_helper
INFO - 2023-10-13 19:15:03 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:03 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:03 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:15:03 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:15:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 19:15:03 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:03 --> Total execution time: 0.1878
INFO - 2023-10-13 19:15:11 --> Config Class Initialized
INFO - 2023-10-13 19:15:11 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:11 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:11 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:11 --> URI Class Initialized
INFO - 2023-10-13 19:15:11 --> Router Class Initialized
INFO - 2023-10-13 19:15:11 --> Output Class Initialized
INFO - 2023-10-13 19:15:11 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:11 --> Input Class Initialized
INFO - 2023-10-13 19:15:11 --> Language Class Initialized
INFO - 2023-10-13 19:15:11 --> Loader Class Initialized
INFO - 2023-10-13 19:15:11 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:11 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:11 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:11 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:11 --> Controller Class Initialized
INFO - 2023-10-13 19:15:11 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:15:11 --> Model "Home_model" initialized
INFO - 2023-10-13 19:15:11 --> Helper loaded: download_helper
INFO - 2023-10-13 19:15:11 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:11 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:11 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:15:11 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:15:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-13 19:15:11 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:11 --> Total execution time: 0.1144
INFO - 2023-10-13 19:15:14 --> Config Class Initialized
INFO - 2023-10-13 19:15:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:14 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:14 --> URI Class Initialized
INFO - 2023-10-13 19:15:14 --> Router Class Initialized
INFO - 2023-10-13 19:15:14 --> Output Class Initialized
INFO - 2023-10-13 19:15:14 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:14 --> Input Class Initialized
INFO - 2023-10-13 19:15:14 --> Language Class Initialized
INFO - 2023-10-13 19:15:14 --> Loader Class Initialized
INFO - 2023-10-13 19:15:14 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:14 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:14 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:14 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:14 --> Controller Class Initialized
INFO - 2023-10-13 19:15:14 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:15:14 --> Model "Home_model" initialized
INFO - 2023-10-13 19:15:14 --> Helper loaded: download_helper
INFO - 2023-10-13 19:15:14 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:14 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:14 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:15:14 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:15:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 19:15:14 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:14 --> Total execution time: 0.0960
INFO - 2023-10-13 19:15:21 --> Config Class Initialized
INFO - 2023-10-13 19:15:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:21 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:21 --> URI Class Initialized
INFO - 2023-10-13 19:15:21 --> Router Class Initialized
INFO - 2023-10-13 19:15:21 --> Output Class Initialized
INFO - 2023-10-13 19:15:21 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:21 --> Input Class Initialized
INFO - 2023-10-13 19:15:21 --> Language Class Initialized
INFO - 2023-10-13 19:15:21 --> Loader Class Initialized
INFO - 2023-10-13 19:15:21 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:21 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:21 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:21 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:21 --> Controller Class Initialized
INFO - 2023-10-13 19:15:21 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:15:21 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:21 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:15:21 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:21 --> Total execution time: 0.0937
INFO - 2023-10-13 19:15:22 --> Config Class Initialized
INFO - 2023-10-13 19:15:22 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:22 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:22 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:22 --> URI Class Initialized
INFO - 2023-10-13 19:15:22 --> Router Class Initialized
INFO - 2023-10-13 19:15:22 --> Output Class Initialized
INFO - 2023-10-13 19:15:22 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:22 --> Input Class Initialized
INFO - 2023-10-13 19:15:22 --> Language Class Initialized
ERROR - 2023-10-13 19:15:22 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-13 19:15:25 --> Config Class Initialized
INFO - 2023-10-13 19:15:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:25 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:25 --> URI Class Initialized
INFO - 2023-10-13 19:15:25 --> Router Class Initialized
INFO - 2023-10-13 19:15:25 --> Output Class Initialized
INFO - 2023-10-13 19:15:25 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:25 --> Input Class Initialized
INFO - 2023-10-13 19:15:25 --> Language Class Initialized
INFO - 2023-10-13 19:15:25 --> Loader Class Initialized
INFO - 2023-10-13 19:15:25 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:25 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:25 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:25 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:25 --> Controller Class Initialized
INFO - 2023-10-13 19:15:25 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:15:25 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:25 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:15:25 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:25 --> Total execution time: 0.1082
INFO - 2023-10-13 19:15:25 --> Config Class Initialized
INFO - 2023-10-13 19:15:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:25 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:25 --> URI Class Initialized
INFO - 2023-10-13 19:15:25 --> Router Class Initialized
INFO - 2023-10-13 19:15:25 --> Output Class Initialized
INFO - 2023-10-13 19:15:25 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:25 --> Input Class Initialized
INFO - 2023-10-13 19:15:25 --> Language Class Initialized
INFO - 2023-10-13 19:15:25 --> Loader Class Initialized
INFO - 2023-10-13 19:15:25 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:25 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:25 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:25 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:25 --> Controller Class Initialized
INFO - 2023-10-13 19:15:25 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:15:25 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:25 --> Form Validation Class Initialized
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 87
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 102
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 113
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 125
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 135
ERROR - 2023-10-13 19:15:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 137
INFO - 2023-10-13 19:15:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-10-13 19:15:25 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:25 --> Total execution time: 0.3908
INFO - 2023-10-13 19:15:55 --> Config Class Initialized
INFO - 2023-10-13 19:15:55 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:55 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:55 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:55 --> URI Class Initialized
INFO - 2023-10-13 19:15:55 --> Router Class Initialized
INFO - 2023-10-13 19:15:56 --> Output Class Initialized
INFO - 2023-10-13 19:15:56 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:56 --> Input Class Initialized
INFO - 2023-10-13 19:15:56 --> Language Class Initialized
INFO - 2023-10-13 19:15:56 --> Loader Class Initialized
INFO - 2023-10-13 19:15:56 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:56 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:56 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:56 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:56 --> Controller Class Initialized
INFO - 2023-10-13 19:15:56 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:15:56 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:56 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:15:56 --> Config Class Initialized
INFO - 2023-10-13 19:15:56 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:15:56 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:15:56 --> Utf8 Class Initialized
INFO - 2023-10-13 19:15:56 --> URI Class Initialized
INFO - 2023-10-13 19:15:56 --> Router Class Initialized
INFO - 2023-10-13 19:15:56 --> Output Class Initialized
INFO - 2023-10-13 19:15:56 --> Security Class Initialized
DEBUG - 2023-10-13 19:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:15:56 --> Input Class Initialized
INFO - 2023-10-13 19:15:56 --> Language Class Initialized
INFO - 2023-10-13 19:15:56 --> Loader Class Initialized
INFO - 2023-10-13 19:15:56 --> Helper loaded: url_helper
INFO - 2023-10-13 19:15:56 --> Helper loaded: file_helper
INFO - 2023-10-13 19:15:56 --> Database Driver Class Initialized
INFO - 2023-10-13 19:15:56 --> Email Class Initialized
DEBUG - 2023-10-13 19:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:15:56 --> Controller Class Initialized
INFO - 2023-10-13 19:15:56 --> Model "Blog_model" initialized
INFO - 2023-10-13 19:15:56 --> Helper loaded: form_helper
INFO - 2023-10-13 19:15:56 --> Form Validation Class Initialized
INFO - 2023-10-13 19:15:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-10-13 19:15:56 --> Final output sent to browser
DEBUG - 2023-10-13 19:15:56 --> Total execution time: 0.0919
INFO - 2023-10-13 19:16:01 --> Config Class Initialized
INFO - 2023-10-13 19:16:01 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:16:01 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:16:01 --> Utf8 Class Initialized
INFO - 2023-10-13 19:16:01 --> URI Class Initialized
INFO - 2023-10-13 19:16:01 --> Router Class Initialized
INFO - 2023-10-13 19:16:01 --> Output Class Initialized
INFO - 2023-10-13 19:16:01 --> Security Class Initialized
DEBUG - 2023-10-13 19:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:16:01 --> Input Class Initialized
INFO - 2023-10-13 19:16:01 --> Language Class Initialized
INFO - 2023-10-13 19:16:01 --> Loader Class Initialized
INFO - 2023-10-13 19:16:01 --> Helper loaded: url_helper
INFO - 2023-10-13 19:16:01 --> Helper loaded: file_helper
INFO - 2023-10-13 19:16:01 --> Database Driver Class Initialized
INFO - 2023-10-13 19:16:01 --> Email Class Initialized
DEBUG - 2023-10-13 19:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:16:01 --> Controller Class Initialized
INFO - 2023-10-13 19:16:01 --> Model "Contact_model" initialized
INFO - 2023-10-13 19:16:01 --> Model "Home_model" initialized
INFO - 2023-10-13 19:16:01 --> Helper loaded: download_helper
INFO - 2023-10-13 19:16:01 --> Helper loaded: form_helper
INFO - 2023-10-13 19:16:01 --> Form Validation Class Initialized
INFO - 2023-10-13 19:16:01 --> Helper loaded: custom_helper
INFO - 2023-10-13 19:16:01 --> Model "Social_media_model" initialized
INFO - 2023-10-13 19:16:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-10-13 19:16:01 --> Final output sent to browser
DEBUG - 2023-10-13 19:16:01 --> Total execution time: 0.1787
