<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-19 07:33:04 --> Config Class Initialized
INFO - 2023-11-19 07:33:04 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:33:04 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:33:04 --> Utf8 Class Initialized
INFO - 2023-11-19 07:33:04 --> URI Class Initialized
INFO - 2023-11-19 07:33:04 --> Router Class Initialized
INFO - 2023-11-19 07:33:04 --> Output Class Initialized
INFO - 2023-11-19 07:33:04 --> Security Class Initialized
DEBUG - 2023-11-19 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:33:04 --> Input Class Initialized
INFO - 2023-11-19 07:33:04 --> Language Class Initialized
INFO - 2023-11-19 07:33:04 --> Loader Class Initialized
INFO - 2023-11-19 07:33:04 --> Helper loaded: url_helper
INFO - 2023-11-19 07:33:04 --> Helper loaded: file_helper
INFO - 2023-11-19 07:33:04 --> Database Driver Class Initialized
INFO - 2023-11-19 07:33:04 --> Email Class Initialized
DEBUG - 2023-11-19 07:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:33:04 --> Controller Class Initialized
INFO - 2023-11-19 07:33:04 --> Model "Contact_model" initialized
INFO - 2023-11-19 07:33:04 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 07:33:04 --> Model "Home_model" initialized
INFO - 2023-11-19 07:33:04 --> Helper loaded: download_helper
INFO - 2023-11-19 07:33:04 --> Helper loaded: form_helper
INFO - 2023-11-19 07:33:04 --> Form Validation Class Initialized
INFO - 2023-11-19 12:03:04 --> Helper loaded: custom_helper
INFO - 2023-11-19 12:03:04 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 12:03:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 12:03:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-11-19 12:03:04 --> Final output sent to browser
DEBUG - 2023-11-19 12:03:04 --> Total execution time: 0.1661
INFO - 2023-11-19 07:48:38 --> Config Class Initialized
INFO - 2023-11-19 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:38 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:38 --> URI Class Initialized
INFO - 2023-11-19 07:48:38 --> Router Class Initialized
INFO - 2023-11-19 07:48:38 --> Output Class Initialized
INFO - 2023-11-19 07:48:38 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:38 --> Input Class Initialized
INFO - 2023-11-19 07:48:38 --> Language Class Initialized
INFO - 2023-11-19 07:48:38 --> Loader Class Initialized
INFO - 2023-11-19 07:48:38 --> Helper loaded: url_helper
INFO - 2023-11-19 07:48:38 --> Helper loaded: file_helper
INFO - 2023-11-19 07:48:38 --> Database Driver Class Initialized
INFO - 2023-11-19 07:48:38 --> Email Class Initialized
DEBUG - 2023-11-19 07:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:48:38 --> Controller Class Initialized
INFO - 2023-11-19 07:48:38 --> Model "User_model" initialized
INFO - 2023-11-19 07:48:38 --> Config Class Initialized
INFO - 2023-11-19 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:38 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:38 --> URI Class Initialized
INFO - 2023-11-19 07:48:38 --> Router Class Initialized
INFO - 2023-11-19 07:48:38 --> Output Class Initialized
INFO - 2023-11-19 07:48:38 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:38 --> Input Class Initialized
INFO - 2023-11-19 07:48:38 --> Language Class Initialized
INFO - 2023-11-19 07:48:38 --> Loader Class Initialized
INFO - 2023-11-19 07:48:38 --> Helper loaded: url_helper
INFO - 2023-11-19 07:48:38 --> Helper loaded: file_helper
INFO - 2023-11-19 07:48:38 --> Database Driver Class Initialized
INFO - 2023-11-19 07:48:38 --> Email Class Initialized
DEBUG - 2023-11-19 07:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:48:38 --> Controller Class Initialized
INFO - 2023-11-19 07:48:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-11-19 07:48:38 --> Final output sent to browser
DEBUG - 2023-11-19 07:48:38 --> Total execution time: 0.0575
INFO - 2023-11-19 07:48:39 --> Config Class Initialized
INFO - 2023-11-19 07:48:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:39 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:39 --> URI Class Initialized
INFO - 2023-11-19 07:48:39 --> Router Class Initialized
INFO - 2023-11-19 07:48:39 --> Output Class Initialized
INFO - 2023-11-19 07:48:39 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:39 --> Input Class Initialized
INFO - 2023-11-19 07:48:39 --> Language Class Initialized
ERROR - 2023-11-19 07:48:39 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-11-19 07:48:42 --> Config Class Initialized
INFO - 2023-11-19 07:48:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:42 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:42 --> URI Class Initialized
INFO - 2023-11-19 07:48:42 --> Router Class Initialized
INFO - 2023-11-19 07:48:42 --> Output Class Initialized
INFO - 2023-11-19 07:48:42 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:42 --> Input Class Initialized
INFO - 2023-11-19 07:48:42 --> Language Class Initialized
INFO - 2023-11-19 07:48:42 --> Loader Class Initialized
INFO - 2023-11-19 07:48:42 --> Helper loaded: url_helper
INFO - 2023-11-19 07:48:42 --> Helper loaded: file_helper
INFO - 2023-11-19 07:48:42 --> Database Driver Class Initialized
INFO - 2023-11-19 07:48:42 --> Email Class Initialized
DEBUG - 2023-11-19 07:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:48:42 --> Controller Class Initialized
INFO - 2023-11-19 07:48:42 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:48:42 --> Helper loaded: form_helper
INFO - 2023-11-19 07:48:42 --> Form Validation Class Initialized
INFO - 2023-11-19 07:48:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:48:42 --> Final output sent to browser
DEBUG - 2023-11-19 07:48:42 --> Total execution time: 0.0553
INFO - 2023-11-19 07:48:51 --> Config Class Initialized
INFO - 2023-11-19 07:48:51 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:51 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:51 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:51 --> URI Class Initialized
INFO - 2023-11-19 07:48:51 --> Router Class Initialized
INFO - 2023-11-19 07:48:51 --> Output Class Initialized
INFO - 2023-11-19 07:48:51 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:51 --> Input Class Initialized
INFO - 2023-11-19 07:48:51 --> Language Class Initialized
INFO - 2023-11-19 07:48:51 --> Loader Class Initialized
INFO - 2023-11-19 07:48:51 --> Helper loaded: url_helper
INFO - 2023-11-19 07:48:51 --> Helper loaded: file_helper
INFO - 2023-11-19 07:48:51 --> Database Driver Class Initialized
INFO - 2023-11-19 07:48:51 --> Email Class Initialized
DEBUG - 2023-11-19 07:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:48:51 --> Controller Class Initialized
INFO - 2023-11-19 07:48:51 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:48:51 --> Helper loaded: form_helper
INFO - 2023-11-19 07:48:51 --> Form Validation Class Initialized
INFO - 2023-11-19 07:48:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:48:51 --> Final output sent to browser
DEBUG - 2023-11-19 07:48:51 --> Total execution time: 0.0742
INFO - 2023-11-19 07:48:52 --> Config Class Initialized
INFO - 2023-11-19 07:48:52 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:48:52 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:48:52 --> Utf8 Class Initialized
INFO - 2023-11-19 07:48:52 --> URI Class Initialized
INFO - 2023-11-19 07:48:52 --> Router Class Initialized
INFO - 2023-11-19 07:48:52 --> Output Class Initialized
INFO - 2023-11-19 07:48:52 --> Security Class Initialized
DEBUG - 2023-11-19 07:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:48:52 --> Input Class Initialized
INFO - 2023-11-19 07:48:52 --> Language Class Initialized
INFO - 2023-11-19 07:48:52 --> Loader Class Initialized
INFO - 2023-11-19 07:48:52 --> Helper loaded: url_helper
INFO - 2023-11-19 07:48:52 --> Helper loaded: file_helper
INFO - 2023-11-19 07:48:52 --> Database Driver Class Initialized
INFO - 2023-11-19 07:48:52 --> Email Class Initialized
DEBUG - 2023-11-19 07:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:48:52 --> Controller Class Initialized
INFO - 2023-11-19 07:48:52 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:48:52 --> Helper loaded: form_helper
INFO - 2023-11-19 07:48:52 --> Form Validation Class Initialized
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-11-19 07:48:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-11-19 07:48:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:48:52 --> Final output sent to browser
DEBUG - 2023-11-19 07:48:52 --> Total execution time: 0.0554
INFO - 2023-11-19 07:49:42 --> Config Class Initialized
INFO - 2023-11-19 07:49:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:49:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:49:42 --> Utf8 Class Initialized
INFO - 2023-11-19 07:49:42 --> URI Class Initialized
INFO - 2023-11-19 07:49:42 --> Router Class Initialized
INFO - 2023-11-19 07:49:42 --> Output Class Initialized
INFO - 2023-11-19 07:49:42 --> Security Class Initialized
DEBUG - 2023-11-19 07:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:49:42 --> Input Class Initialized
INFO - 2023-11-19 07:49:42 --> Language Class Initialized
INFO - 2023-11-19 07:49:42 --> Loader Class Initialized
INFO - 2023-11-19 07:49:42 --> Helper loaded: url_helper
INFO - 2023-11-19 07:49:42 --> Helper loaded: file_helper
INFO - 2023-11-19 07:49:42 --> Database Driver Class Initialized
INFO - 2023-11-19 07:49:42 --> Email Class Initialized
DEBUG - 2023-11-19 07:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:49:42 --> Controller Class Initialized
INFO - 2023-11-19 07:49:42 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:49:42 --> Helper loaded: form_helper
INFO - 2023-11-19 07:49:42 --> Form Validation Class Initialized
INFO - 2023-11-19 07:49:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-19 07:49:42 --> Config Class Initialized
INFO - 2023-11-19 07:49:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:49:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:49:42 --> Utf8 Class Initialized
INFO - 2023-11-19 07:49:42 --> URI Class Initialized
INFO - 2023-11-19 07:49:42 --> Router Class Initialized
INFO - 2023-11-19 07:49:42 --> Output Class Initialized
INFO - 2023-11-19 07:49:42 --> Security Class Initialized
DEBUG - 2023-11-19 07:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:49:42 --> Input Class Initialized
INFO - 2023-11-19 07:49:42 --> Language Class Initialized
INFO - 2023-11-19 07:49:42 --> Loader Class Initialized
INFO - 2023-11-19 07:49:42 --> Helper loaded: url_helper
INFO - 2023-11-19 07:49:42 --> Helper loaded: file_helper
INFO - 2023-11-19 07:49:42 --> Database Driver Class Initialized
INFO - 2023-11-19 07:49:42 --> Email Class Initialized
DEBUG - 2023-11-19 07:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:49:42 --> Controller Class Initialized
INFO - 2023-11-19 07:49:42 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:49:42 --> Helper loaded: form_helper
INFO - 2023-11-19 07:49:42 --> Form Validation Class Initialized
INFO - 2023-11-19 07:49:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:49:42 --> Final output sent to browser
DEBUG - 2023-11-19 07:49:42 --> Total execution time: 0.0657
INFO - 2023-11-19 07:49:47 --> Config Class Initialized
INFO - 2023-11-19 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:49:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:49:47 --> URI Class Initialized
INFO - 2023-11-19 07:49:47 --> Router Class Initialized
INFO - 2023-11-19 07:49:47 --> Output Class Initialized
INFO - 2023-11-19 07:49:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:49:47 --> Input Class Initialized
INFO - 2023-11-19 07:49:47 --> Language Class Initialized
INFO - 2023-11-19 07:49:47 --> Loader Class Initialized
INFO - 2023-11-19 07:49:47 --> Helper loaded: url_helper
INFO - 2023-11-19 07:49:47 --> Helper loaded: file_helper
INFO - 2023-11-19 07:49:47 --> Database Driver Class Initialized
INFO - 2023-11-19 07:49:47 --> Email Class Initialized
DEBUG - 2023-11-19 07:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:49:47 --> Controller Class Initialized
INFO - 2023-11-19 07:49:47 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:49:47 --> Helper loaded: form_helper
INFO - 2023-11-19 07:49:47 --> Form Validation Class Initialized
INFO - 2023-11-19 07:49:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:49:47 --> Final output sent to browser
DEBUG - 2023-11-19 07:49:47 --> Total execution time: 0.0616
INFO - 2023-11-19 07:49:48 --> Config Class Initialized
INFO - 2023-11-19 07:49:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:49:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:49:48 --> Utf8 Class Initialized
INFO - 2023-11-19 07:49:48 --> URI Class Initialized
INFO - 2023-11-19 07:49:48 --> Router Class Initialized
INFO - 2023-11-19 07:49:48 --> Output Class Initialized
INFO - 2023-11-19 07:49:48 --> Security Class Initialized
DEBUG - 2023-11-19 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:49:48 --> Input Class Initialized
INFO - 2023-11-19 07:49:48 --> Language Class Initialized
INFO - 2023-11-19 07:49:48 --> Loader Class Initialized
INFO - 2023-11-19 07:49:48 --> Helper loaded: url_helper
INFO - 2023-11-19 07:49:48 --> Helper loaded: file_helper
INFO - 2023-11-19 07:49:48 --> Database Driver Class Initialized
INFO - 2023-11-19 07:49:48 --> Email Class Initialized
DEBUG - 2023-11-19 07:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:49:48 --> Controller Class Initialized
INFO - 2023-11-19 07:49:48 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:49:48 --> Helper loaded: form_helper
INFO - 2023-11-19 07:49:48 --> Form Validation Class Initialized
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-11-19 07:49:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-11-19 07:49:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:49:48 --> Final output sent to browser
DEBUG - 2023-11-19 07:49:48 --> Total execution time: 0.0551
INFO - 2023-11-19 07:50:06 --> Config Class Initialized
INFO - 2023-11-19 07:50:06 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:06 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:06 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:06 --> URI Class Initialized
INFO - 2023-11-19 07:50:06 --> Router Class Initialized
INFO - 2023-11-19 07:50:06 --> Output Class Initialized
INFO - 2023-11-19 07:50:06 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:06 --> Input Class Initialized
INFO - 2023-11-19 07:50:06 --> Language Class Initialized
INFO - 2023-11-19 07:50:06 --> Loader Class Initialized
INFO - 2023-11-19 07:50:06 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:06 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:06 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:06 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:06 --> Controller Class Initialized
INFO - 2023-11-19 07:50:06 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:06 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:06 --> Form Validation Class Initialized
INFO - 2023-11-19 07:50:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-19 07:50:06 --> Config Class Initialized
INFO - 2023-11-19 07:50:06 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:06 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:06 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:06 --> URI Class Initialized
INFO - 2023-11-19 07:50:06 --> Router Class Initialized
INFO - 2023-11-19 07:50:06 --> Output Class Initialized
INFO - 2023-11-19 07:50:06 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:06 --> Input Class Initialized
INFO - 2023-11-19 07:50:06 --> Language Class Initialized
INFO - 2023-11-19 07:50:06 --> Loader Class Initialized
INFO - 2023-11-19 07:50:06 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:06 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:06 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:06 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:06 --> Controller Class Initialized
INFO - 2023-11-19 07:50:06 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:06 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:06 --> Form Validation Class Initialized
INFO - 2023-11-19 07:50:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:50:06 --> Final output sent to browser
DEBUG - 2023-11-19 07:50:06 --> Total execution time: 0.0540
INFO - 2023-11-19 07:50:13 --> Config Class Initialized
INFO - 2023-11-19 07:50:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:13 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:13 --> URI Class Initialized
INFO - 2023-11-19 07:50:13 --> Router Class Initialized
INFO - 2023-11-19 07:50:13 --> Output Class Initialized
INFO - 2023-11-19 07:50:13 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:13 --> Input Class Initialized
INFO - 2023-11-19 07:50:13 --> Language Class Initialized
INFO - 2023-11-19 07:50:13 --> Loader Class Initialized
INFO - 2023-11-19 07:50:13 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:13 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:13 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:13 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:13 --> Controller Class Initialized
INFO - 2023-11-19 07:50:13 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:13 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:13 --> Form Validation Class Initialized
INFO - 2023-11-19 07:50:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:50:13 --> Final output sent to browser
DEBUG - 2023-11-19 07:50:13 --> Total execution time: 0.0487
INFO - 2023-11-19 07:50:14 --> Config Class Initialized
INFO - 2023-11-19 07:50:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:14 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:14 --> URI Class Initialized
INFO - 2023-11-19 07:50:14 --> Router Class Initialized
INFO - 2023-11-19 07:50:14 --> Output Class Initialized
INFO - 2023-11-19 07:50:14 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:14 --> Input Class Initialized
INFO - 2023-11-19 07:50:14 --> Language Class Initialized
INFO - 2023-11-19 07:50:14 --> Loader Class Initialized
INFO - 2023-11-19 07:50:14 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:14 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:14 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:14 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:14 --> Controller Class Initialized
INFO - 2023-11-19 07:50:14 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:14 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:14 --> Form Validation Class Initialized
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-11-19 07:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-11-19 07:50:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:50:14 --> Final output sent to browser
DEBUG - 2023-11-19 07:50:14 --> Total execution time: 0.0886
INFO - 2023-11-19 07:50:27 --> Config Class Initialized
INFO - 2023-11-19 07:50:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:27 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:27 --> URI Class Initialized
INFO - 2023-11-19 07:50:27 --> Router Class Initialized
INFO - 2023-11-19 07:50:27 --> Output Class Initialized
INFO - 2023-11-19 07:50:27 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:27 --> Input Class Initialized
INFO - 2023-11-19 07:50:27 --> Language Class Initialized
INFO - 2023-11-19 07:50:27 --> Loader Class Initialized
INFO - 2023-11-19 07:50:27 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:27 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:27 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:27 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:27 --> Controller Class Initialized
INFO - 2023-11-19 07:50:27 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:27 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:27 --> Form Validation Class Initialized
INFO - 2023-11-19 07:50:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-19 07:50:27 --> Config Class Initialized
INFO - 2023-11-19 07:50:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:27 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:27 --> URI Class Initialized
INFO - 2023-11-19 07:50:27 --> Router Class Initialized
INFO - 2023-11-19 07:50:27 --> Output Class Initialized
INFO - 2023-11-19 07:50:27 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:27 --> Input Class Initialized
INFO - 2023-11-19 07:50:27 --> Language Class Initialized
INFO - 2023-11-19 07:50:27 --> Loader Class Initialized
INFO - 2023-11-19 07:50:27 --> Helper loaded: url_helper
INFO - 2023-11-19 07:50:27 --> Helper loaded: file_helper
INFO - 2023-11-19 07:50:27 --> Database Driver Class Initialized
INFO - 2023-11-19 07:50:27 --> Email Class Initialized
DEBUG - 2023-11-19 07:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:50:27 --> Controller Class Initialized
INFO - 2023-11-19 07:50:27 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:50:27 --> Helper loaded: form_helper
INFO - 2023-11-19 07:50:27 --> Form Validation Class Initialized
INFO - 2023-11-19 07:50:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:50:27 --> Final output sent to browser
DEBUG - 2023-11-19 07:50:27 --> Total execution time: 0.0489
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:47 --> Config Class Initialized
INFO - 2023-11-19 07:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:47 --> URI Class Initialized
INFO - 2023-11-19 07:50:47 --> Router Class Initialized
INFO - 2023-11-19 07:50:47 --> Output Class Initialized
INFO - 2023-11-19 07:50:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:47 --> Input Class Initialized
INFO - 2023-11-19 07:50:47 --> Language Class Initialized
ERROR - 2023-11-19 07:50:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:50:48 --> Config Class Initialized
INFO - 2023-11-19 07:50:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:50:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:50:48 --> Utf8 Class Initialized
INFO - 2023-11-19 07:50:48 --> URI Class Initialized
INFO - 2023-11-19 07:50:48 --> Router Class Initialized
INFO - 2023-11-19 07:50:48 --> Output Class Initialized
INFO - 2023-11-19 07:50:48 --> Security Class Initialized
DEBUG - 2023-11-19 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:50:48 --> Input Class Initialized
INFO - 2023-11-19 07:50:48 --> Language Class Initialized
ERROR - 2023-11-19 07:50:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:29 --> Config Class Initialized
INFO - 2023-11-19 07:51:29 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:29 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:29 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:29 --> URI Class Initialized
INFO - 2023-11-19 07:51:29 --> Router Class Initialized
INFO - 2023-11-19 07:51:29 --> Output Class Initialized
INFO - 2023-11-19 07:51:29 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:29 --> Input Class Initialized
INFO - 2023-11-19 07:51:29 --> Language Class Initialized
ERROR - 2023-11-19 07:51:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:31 --> Config Class Initialized
INFO - 2023-11-19 07:51:31 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:31 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:31 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:31 --> URI Class Initialized
INFO - 2023-11-19 07:51:31 --> Router Class Initialized
INFO - 2023-11-19 07:51:31 --> Output Class Initialized
INFO - 2023-11-19 07:51:31 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:31 --> Input Class Initialized
INFO - 2023-11-19 07:51:31 --> Language Class Initialized
ERROR - 2023-11-19 07:51:31 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:31 --> Config Class Initialized
INFO - 2023-11-19 07:51:31 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:31 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:31 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:31 --> URI Class Initialized
INFO - 2023-11-19 07:51:31 --> Router Class Initialized
INFO - 2023-11-19 07:51:31 --> Output Class Initialized
INFO - 2023-11-19 07:51:31 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:31 --> Input Class Initialized
INFO - 2023-11-19 07:51:31 --> Language Class Initialized
INFO - 2023-11-19 07:51:33 --> Config Class Initialized
INFO - 2023-11-19 07:51:33 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:33 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:33 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:33 --> URI Class Initialized
INFO - 2023-11-19 07:51:33 --> Router Class Initialized
INFO - 2023-11-19 07:51:33 --> Output Class Initialized
INFO - 2023-11-19 07:51:33 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:33 --> Input Class Initialized
INFO - 2023-11-19 07:51:33 --> Language Class Initialized
ERROR - 2023-11-19 07:51:33 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-19 07:51:33 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:33 --> Config Class Initialized
INFO - 2023-11-19 07:51:33 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:33 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:33 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:33 --> URI Class Initialized
INFO - 2023-11-19 07:51:33 --> Router Class Initialized
INFO - 2023-11-19 07:51:33 --> Output Class Initialized
INFO - 2023-11-19 07:51:33 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:33 --> Input Class Initialized
INFO - 2023-11-19 07:51:33 --> Language Class Initialized
ERROR - 2023-11-19 07:51:33 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:33 --> Config Class Initialized
INFO - 2023-11-19 07:51:33 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:33 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:33 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:33 --> URI Class Initialized
INFO - 2023-11-19 07:51:33 --> Router Class Initialized
INFO - 2023-11-19 07:51:33 --> Output Class Initialized
INFO - 2023-11-19 07:51:33 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:33 --> Input Class Initialized
INFO - 2023-11-19 07:51:33 --> Language Class Initialized
ERROR - 2023-11-19 07:51:33 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:51 --> Config Class Initialized
INFO - 2023-11-19 07:51:51 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:51 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:51 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:51 --> URI Class Initialized
INFO - 2023-11-19 07:51:51 --> Router Class Initialized
INFO - 2023-11-19 07:51:51 --> Output Class Initialized
INFO - 2023-11-19 07:51:52 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:52 --> Input Class Initialized
INFO - 2023-11-19 07:51:52 --> Language Class Initialized
ERROR - 2023-11-19 07:51:52 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:53 --> Config Class Initialized
INFO - 2023-11-19 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:53 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:53 --> URI Class Initialized
INFO - 2023-11-19 07:51:53 --> Router Class Initialized
INFO - 2023-11-19 07:51:53 --> Output Class Initialized
INFO - 2023-11-19 07:51:53 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:53 --> Input Class Initialized
INFO - 2023-11-19 07:51:53 --> Language Class Initialized
ERROR - 2023-11-19 07:51:53 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:53 --> Config Class Initialized
INFO - 2023-11-19 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:53 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:53 --> URI Class Initialized
INFO - 2023-11-19 07:51:53 --> Router Class Initialized
INFO - 2023-11-19 07:51:53 --> Output Class Initialized
INFO - 2023-11-19 07:51:53 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:53 --> Input Class Initialized
INFO - 2023-11-19 07:51:53 --> Language Class Initialized
ERROR - 2023-11-19 07:51:53 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:54 --> Config Class Initialized
INFO - 2023-11-19 07:51:54 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:54 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:54 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:54 --> URI Class Initialized
INFO - 2023-11-19 07:51:54 --> Router Class Initialized
INFO - 2023-11-19 07:51:54 --> Output Class Initialized
INFO - 2023-11-19 07:51:54 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:54 --> Input Class Initialized
INFO - 2023-11-19 07:51:54 --> Language Class Initialized
ERROR - 2023-11-19 07:51:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:54 --> Config Class Initialized
INFO - 2023-11-19 07:51:54 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:54 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:54 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:54 --> URI Class Initialized
INFO - 2023-11-19 07:51:54 --> Router Class Initialized
INFO - 2023-11-19 07:51:54 --> Output Class Initialized
INFO - 2023-11-19 07:51:54 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:54 --> Input Class Initialized
INFO - 2023-11-19 07:51:54 --> Language Class Initialized
ERROR - 2023-11-19 07:51:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:54 --> Config Class Initialized
INFO - 2023-11-19 07:51:54 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:54 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:54 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:54 --> URI Class Initialized
INFO - 2023-11-19 07:51:54 --> Router Class Initialized
INFO - 2023-11-19 07:51:54 --> Output Class Initialized
INFO - 2023-11-19 07:51:54 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:54 --> Input Class Initialized
INFO - 2023-11-19 07:51:54 --> Language Class Initialized
ERROR - 2023-11-19 07:51:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:51:55 --> Config Class Initialized
INFO - 2023-11-19 07:51:55 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:51:55 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:51:55 --> Utf8 Class Initialized
INFO - 2023-11-19 07:51:55 --> URI Class Initialized
INFO - 2023-11-19 07:51:55 --> Router Class Initialized
INFO - 2023-11-19 07:51:55 --> Output Class Initialized
INFO - 2023-11-19 07:51:55 --> Security Class Initialized
DEBUG - 2023-11-19 07:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:51:55 --> Input Class Initialized
INFO - 2023-11-19 07:51:55 --> Language Class Initialized
ERROR - 2023-11-19 07:51:55 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:17 --> Config Class Initialized
INFO - 2023-11-19 07:52:17 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:17 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:17 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:17 --> URI Class Initialized
INFO - 2023-11-19 07:52:17 --> Router Class Initialized
INFO - 2023-11-19 07:52:17 --> Output Class Initialized
INFO - 2023-11-19 07:52:18 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:18 --> Input Class Initialized
INFO - 2023-11-19 07:52:18 --> Language Class Initialized
INFO - 2023-11-19 07:52:18 --> Loader Class Initialized
INFO - 2023-11-19 07:52:18 --> Helper loaded: url_helper
INFO - 2023-11-19 07:52:18 --> Helper loaded: file_helper
INFO - 2023-11-19 07:52:18 --> Database Driver Class Initialized
INFO - 2023-11-19 07:52:18 --> Email Class Initialized
DEBUG - 2023-11-19 07:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:52:18 --> Controller Class Initialized
INFO - 2023-11-19 07:52:18 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:52:18 --> Helper loaded: form_helper
INFO - 2023-11-19 07:52:18 --> Form Validation Class Initialized
INFO - 2023-11-19 07:52:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:52:18 --> Final output sent to browser
DEBUG - 2023-11-19 07:52:18 --> Total execution time: 1.3927
INFO - 2023-11-19 07:52:22 --> Config Class Initialized
INFO - 2023-11-19 07:52:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:22 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:22 --> URI Class Initialized
INFO - 2023-11-19 07:52:22 --> Router Class Initialized
INFO - 2023-11-19 07:52:22 --> Output Class Initialized
INFO - 2023-11-19 07:52:22 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:22 --> Input Class Initialized
INFO - 2023-11-19 07:52:22 --> Language Class Initialized
ERROR - 2023-11-19 07:52:22 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-11-19 07:52:45 --> Config Class Initialized
INFO - 2023-11-19 07:52:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:45 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:45 --> URI Class Initialized
INFO - 2023-11-19 07:52:45 --> Router Class Initialized
INFO - 2023-11-19 07:52:45 --> Output Class Initialized
INFO - 2023-11-19 07:52:45 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:45 --> Input Class Initialized
INFO - 2023-11-19 07:52:45 --> Language Class Initialized
ERROR - 2023-11-19 07:52:45 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:46 --> Config Class Initialized
INFO - 2023-11-19 07:52:46 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:46 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:46 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:46 --> URI Class Initialized
INFO - 2023-11-19 07:52:46 --> Router Class Initialized
INFO - 2023-11-19 07:52:46 --> Output Class Initialized
INFO - 2023-11-19 07:52:46 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:46 --> Input Class Initialized
INFO - 2023-11-19 07:52:46 --> Language Class Initialized
ERROR - 2023-11-19 07:52:46 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:47 --> Config Class Initialized
INFO - 2023-11-19 07:52:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:47 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:47 --> URI Class Initialized
INFO - 2023-11-19 07:52:47 --> Router Class Initialized
INFO - 2023-11-19 07:52:47 --> Output Class Initialized
INFO - 2023-11-19 07:52:47 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:47 --> Input Class Initialized
INFO - 2023-11-19 07:52:47 --> Language Class Initialized
ERROR - 2023-11-19 07:52:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:48 --> Config Class Initialized
INFO - 2023-11-19 07:52:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:48 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:48 --> URI Class Initialized
INFO - 2023-11-19 07:52:48 --> Router Class Initialized
INFO - 2023-11-19 07:52:48 --> Output Class Initialized
INFO - 2023-11-19 07:52:48 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:48 --> Input Class Initialized
INFO - 2023-11-19 07:52:48 --> Language Class Initialized
ERROR - 2023-11-19 07:52:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:49 --> Config Class Initialized
INFO - 2023-11-19 07:52:49 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:49 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:49 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:49 --> URI Class Initialized
INFO - 2023-11-19 07:52:49 --> Router Class Initialized
INFO - 2023-11-19 07:52:49 --> Output Class Initialized
INFO - 2023-11-19 07:52:49 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:49 --> Input Class Initialized
INFO - 2023-11-19 07:52:49 --> Language Class Initialized
ERROR - 2023-11-19 07:52:49 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:52:56 --> Config Class Initialized
INFO - 2023-11-19 07:52:56 --> Hooks Class Initialized
INFO - 2023-11-19 07:52:56 --> Config Class Initialized
INFO - 2023-11-19 07:52:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:52:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:56 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:56 --> URI Class Initialized
INFO - 2023-11-19 07:52:56 --> Router Class Initialized
INFO - 2023-11-19 07:52:56 --> Output Class Initialized
INFO - 2023-11-19 07:52:56 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:56 --> Input Class Initialized
INFO - 2023-11-19 07:52:56 --> Language Class Initialized
ERROR - 2023-11-19 07:52:56 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 07:52:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:52:57 --> Utf8 Class Initialized
INFO - 2023-11-19 07:52:57 --> URI Class Initialized
INFO - 2023-11-19 07:52:57 --> Router Class Initialized
INFO - 2023-11-19 07:52:57 --> Output Class Initialized
INFO - 2023-11-19 07:52:57 --> Security Class Initialized
DEBUG - 2023-11-19 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:52:57 --> Input Class Initialized
INFO - 2023-11-19 07:52:57 --> Language Class Initialized
ERROR - 2023-11-19 07:52:57 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 07:53:44 --> Config Class Initialized
INFO - 2023-11-19 07:53:44 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:53:44 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:53:44 --> Utf8 Class Initialized
INFO - 2023-11-19 07:53:44 --> URI Class Initialized
INFO - 2023-11-19 07:53:44 --> Router Class Initialized
INFO - 2023-11-19 07:53:44 --> Output Class Initialized
INFO - 2023-11-19 07:53:44 --> Security Class Initialized
DEBUG - 2023-11-19 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:53:44 --> Input Class Initialized
INFO - 2023-11-19 07:53:44 --> Language Class Initialized
ERROR - 2023-11-19 07:53:44 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:53:44 --> Config Class Initialized
INFO - 2023-11-19 07:53:44 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:53:44 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:53:44 --> Utf8 Class Initialized
INFO - 2023-11-19 07:53:44 --> URI Class Initialized
INFO - 2023-11-19 07:53:44 --> Router Class Initialized
INFO - 2023-11-19 07:53:44 --> Output Class Initialized
INFO - 2023-11-19 07:53:44 --> Security Class Initialized
DEBUG - 2023-11-19 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:53:44 --> Input Class Initialized
INFO - 2023-11-19 07:53:44 --> Language Class Initialized
ERROR - 2023-11-19 07:53:44 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:20 --> Config Class Initialized
INFO - 2023-11-19 07:54:20 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:20 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:20 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:20 --> URI Class Initialized
INFO - 2023-11-19 07:54:20 --> Router Class Initialized
INFO - 2023-11-19 07:54:20 --> Output Class Initialized
INFO - 2023-11-19 07:54:20 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:20 --> Input Class Initialized
INFO - 2023-11-19 07:54:20 --> Language Class Initialized
INFO - 2023-11-19 07:54:20 --> Loader Class Initialized
INFO - 2023-11-19 07:54:20 --> Helper loaded: url_helper
INFO - 2023-11-19 07:54:20 --> Helper loaded: file_helper
INFO - 2023-11-19 07:54:20 --> Database Driver Class Initialized
INFO - 2023-11-19 07:54:20 --> Email Class Initialized
DEBUG - 2023-11-19 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:54:20 --> Controller Class Initialized
INFO - 2023-11-19 07:54:20 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:54:20 --> Helper loaded: form_helper
INFO - 2023-11-19 07:54:20 --> Form Validation Class Initialized
INFO - 2023-11-19 07:54:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:54:20 --> Final output sent to browser
DEBUG - 2023-11-19 07:54:20 --> Total execution time: 0.0815
INFO - 2023-11-19 07:54:21 --> Config Class Initialized
INFO - 2023-11-19 07:54:21 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:21 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:21 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:21 --> URI Class Initialized
INFO - 2023-11-19 07:54:21 --> Router Class Initialized
INFO - 2023-11-19 07:54:21 --> Output Class Initialized
INFO - 2023-11-19 07:54:21 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:21 --> Input Class Initialized
INFO - 2023-11-19 07:54:21 --> Language Class Initialized
ERROR - 2023-11-19 07:54:21 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:21 --> Config Class Initialized
INFO - 2023-11-19 07:54:21 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:21 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:21 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:21 --> URI Class Initialized
INFO - 2023-11-19 07:54:21 --> Router Class Initialized
INFO - 2023-11-19 07:54:21 --> Output Class Initialized
INFO - 2023-11-19 07:54:21 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:21 --> Input Class Initialized
INFO - 2023-11-19 07:54:21 --> Language Class Initialized
ERROR - 2023-11-19 07:54:21 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:34 --> Config Class Initialized
INFO - 2023-11-19 07:54:34 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:34 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:34 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:34 --> URI Class Initialized
INFO - 2023-11-19 07:54:34 --> Router Class Initialized
INFO - 2023-11-19 07:54:34 --> Output Class Initialized
INFO - 2023-11-19 07:54:34 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:34 --> Input Class Initialized
INFO - 2023-11-19 07:54:34 --> Language Class Initialized
INFO - 2023-11-19 07:54:34 --> Loader Class Initialized
INFO - 2023-11-19 07:54:34 --> Helper loaded: url_helper
INFO - 2023-11-19 07:54:34 --> Helper loaded: file_helper
INFO - 2023-11-19 07:54:34 --> Database Driver Class Initialized
INFO - 2023-11-19 07:54:34 --> Email Class Initialized
DEBUG - 2023-11-19 07:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:54:34 --> Controller Class Initialized
INFO - 2023-11-19 07:54:34 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:54:34 --> Helper loaded: form_helper
INFO - 2023-11-19 07:54:34 --> Form Validation Class Initialized
INFO - 2023-11-19 07:54:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:54:34 --> Final output sent to browser
DEBUG - 2023-11-19 07:54:34 --> Total execution time: 0.0579
INFO - 2023-11-19 07:54:35 --> Config Class Initialized
INFO - 2023-11-19 07:54:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:35 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:35 --> URI Class Initialized
INFO - 2023-11-19 07:54:35 --> Router Class Initialized
INFO - 2023-11-19 07:54:35 --> Output Class Initialized
INFO - 2023-11-19 07:54:35 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:35 --> Input Class Initialized
INFO - 2023-11-19 07:54:35 --> Language Class Initialized
ERROR - 2023-11-19 07:54:35 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:35 --> Config Class Initialized
INFO - 2023-11-19 07:54:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:35 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:35 --> URI Class Initialized
INFO - 2023-11-19 07:54:35 --> Router Class Initialized
INFO - 2023-11-19 07:54:35 --> Output Class Initialized
INFO - 2023-11-19 07:54:35 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:35 --> Input Class Initialized
INFO - 2023-11-19 07:54:35 --> Language Class Initialized
ERROR - 2023-11-19 07:54:35 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:35 --> Config Class Initialized
INFO - 2023-11-19 07:54:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:35 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:35 --> URI Class Initialized
INFO - 2023-11-19 07:54:35 --> Router Class Initialized
INFO - 2023-11-19 07:54:35 --> Output Class Initialized
INFO - 2023-11-19 07:54:35 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:35 --> Input Class Initialized
INFO - 2023-11-19 07:54:35 --> Language Class Initialized
INFO - 2023-11-19 07:54:35 --> Loader Class Initialized
INFO - 2023-11-19 07:54:35 --> Helper loaded: url_helper
INFO - 2023-11-19 07:54:35 --> Helper loaded: file_helper
INFO - 2023-11-19 07:54:35 --> Database Driver Class Initialized
INFO - 2023-11-19 07:54:35 --> Email Class Initialized
DEBUG - 2023-11-19 07:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:54:35 --> Controller Class Initialized
INFO - 2023-11-19 07:54:35 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:54:35 --> Helper loaded: form_helper
INFO - 2023-11-19 07:54:35 --> Form Validation Class Initialized
INFO - 2023-11-19 07:54:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-11-19 07:54:35 --> Final output sent to browser
DEBUG - 2023-11-19 07:54:35 --> Total execution time: 0.1494
INFO - 2023-11-19 07:54:36 --> Config Class Initialized
INFO - 2023-11-19 07:54:36 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:36 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:36 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:36 --> URI Class Initialized
INFO - 2023-11-19 07:54:36 --> Router Class Initialized
INFO - 2023-11-19 07:54:36 --> Output Class Initialized
INFO - 2023-11-19 07:54:36 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:36 --> Input Class Initialized
INFO - 2023-11-19 07:54:36 --> Language Class Initialized
ERROR - 2023-11-19 07:54:36 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:36 --> Config Class Initialized
INFO - 2023-11-19 07:54:36 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:36 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:36 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:36 --> URI Class Initialized
INFO - 2023-11-19 07:54:36 --> Router Class Initialized
INFO - 2023-11-19 07:54:36 --> Output Class Initialized
INFO - 2023-11-19 07:54:36 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:36 --> Input Class Initialized
INFO - 2023-11-19 07:54:36 --> Language Class Initialized
ERROR - 2023-11-19 07:54:36 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:36 --> Config Class Initialized
INFO - 2023-11-19 07:54:36 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:36 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:36 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:36 --> URI Class Initialized
INFO - 2023-11-19 07:54:36 --> Router Class Initialized
INFO - 2023-11-19 07:54:36 --> Output Class Initialized
INFO - 2023-11-19 07:54:36 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:36 --> Input Class Initialized
INFO - 2023-11-19 07:54:36 --> Language Class Initialized
INFO - 2023-11-19 07:54:36 --> Loader Class Initialized
INFO - 2023-11-19 07:54:36 --> Helper loaded: url_helper
INFO - 2023-11-19 07:54:36 --> Helper loaded: file_helper
INFO - 2023-11-19 07:54:36 --> Database Driver Class Initialized
INFO - 2023-11-19 07:54:36 --> Email Class Initialized
DEBUG - 2023-11-19 07:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:54:36 --> Controller Class Initialized
INFO - 2023-11-19 07:54:36 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:54:36 --> Helper loaded: form_helper
INFO - 2023-11-19 07:54:36 --> Form Validation Class Initialized
INFO - 2023-11-19 07:54:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:54:36 --> Final output sent to browser
DEBUG - 2023-11-19 07:54:36 --> Total execution time: 0.0974
INFO - 2023-11-19 07:54:38 --> Config Class Initialized
INFO - 2023-11-19 07:54:38 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:38 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:38 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:38 --> URI Class Initialized
INFO - 2023-11-19 07:54:38 --> Router Class Initialized
INFO - 2023-11-19 07:54:38 --> Output Class Initialized
INFO - 2023-11-19 07:54:38 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:38 --> Input Class Initialized
INFO - 2023-11-19 07:54:38 --> Language Class Initialized
ERROR - 2023-11-19 07:54:38 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 07:54:38 --> Config Class Initialized
INFO - 2023-11-19 07:54:38 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:54:38 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:54:38 --> Utf8 Class Initialized
INFO - 2023-11-19 07:54:38 --> URI Class Initialized
INFO - 2023-11-19 07:54:38 --> Router Class Initialized
INFO - 2023-11-19 07:54:38 --> Output Class Initialized
INFO - 2023-11-19 07:54:38 --> Security Class Initialized
DEBUG - 2023-11-19 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:54:38 --> Input Class Initialized
INFO - 2023-11-19 07:54:38 --> Language Class Initialized
INFO - 2023-11-19 07:54:38 --> Loader Class Initialized
INFO - 2023-11-19 07:54:38 --> Helper loaded: url_helper
INFO - 2023-11-19 07:54:38 --> Helper loaded: file_helper
INFO - 2023-11-19 07:54:38 --> Database Driver Class Initialized
INFO - 2023-11-19 07:54:38 --> Email Class Initialized
DEBUG - 2023-11-19 07:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:54:38 --> Controller Class Initialized
INFO - 2023-11-19 07:54:38 --> Model "Banner_model" initialized
INFO - 2023-11-19 07:54:38 --> Helper loaded: form_helper
INFO - 2023-11-19 07:54:38 --> Form Validation Class Initialized
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-11-19 07:54:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-11-19 07:54:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-11-19 07:54:38 --> Final output sent to browser
DEBUG - 2023-11-19 07:54:38 --> Total execution time: 0.0716
INFO - 2023-11-19 07:55:17 --> Config Class Initialized
INFO - 2023-11-19 07:55:17 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:55:17 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:55:17 --> Utf8 Class Initialized
INFO - 2023-11-19 07:55:17 --> URI Class Initialized
DEBUG - 2023-11-19 07:55:17 --> No URI present. Default controller set.
INFO - 2023-11-19 07:55:17 --> Router Class Initialized
INFO - 2023-11-19 07:55:17 --> Output Class Initialized
INFO - 2023-11-19 07:55:17 --> Security Class Initialized
DEBUG - 2023-11-19 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:55:17 --> Input Class Initialized
INFO - 2023-11-19 07:55:17 --> Language Class Initialized
INFO - 2023-11-19 07:55:17 --> Loader Class Initialized
INFO - 2023-11-19 07:55:17 --> Helper loaded: url_helper
INFO - 2023-11-19 07:55:17 --> Helper loaded: file_helper
INFO - 2023-11-19 07:55:17 --> Database Driver Class Initialized
INFO - 2023-11-19 07:55:17 --> Email Class Initialized
DEBUG - 2023-11-19 07:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:55:17 --> Controller Class Initialized
INFO - 2023-11-19 07:55:17 --> Model "Contact_model" initialized
INFO - 2023-11-19 07:55:17 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 07:55:17 --> Model "Home_model" initialized
INFO - 2023-11-19 07:55:17 --> Helper loaded: download_helper
INFO - 2023-11-19 07:55:17 --> Helper loaded: form_helper
INFO - 2023-11-19 07:55:17 --> Form Validation Class Initialized
INFO - 2023-11-19 12:25:17 --> Helper loaded: custom_helper
INFO - 2023-11-19 12:25:17 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 12:25:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 12:25:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 12:25:17 --> Final output sent to browser
DEBUG - 2023-11-19 12:25:17 --> Total execution time: 0.4706
INFO - 2023-11-19 07:58:55 --> Config Class Initialized
INFO - 2023-11-19 07:58:55 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:58:55 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:58:55 --> Utf8 Class Initialized
INFO - 2023-11-19 07:58:55 --> URI Class Initialized
DEBUG - 2023-11-19 07:58:55 --> No URI present. Default controller set.
INFO - 2023-11-19 07:58:55 --> Router Class Initialized
INFO - 2023-11-19 07:58:55 --> Output Class Initialized
INFO - 2023-11-19 07:58:55 --> Security Class Initialized
DEBUG - 2023-11-19 07:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:58:55 --> Input Class Initialized
INFO - 2023-11-19 07:58:55 --> Language Class Initialized
INFO - 2023-11-19 07:58:55 --> Loader Class Initialized
INFO - 2023-11-19 07:58:55 --> Helper loaded: url_helper
INFO - 2023-11-19 07:58:55 --> Helper loaded: file_helper
INFO - 2023-11-19 07:58:55 --> Database Driver Class Initialized
INFO - 2023-11-19 07:58:55 --> Email Class Initialized
DEBUG - 2023-11-19 07:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:58:55 --> Controller Class Initialized
INFO - 2023-11-19 07:58:55 --> Model "Contact_model" initialized
INFO - 2023-11-19 07:58:55 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 07:58:55 --> Model "Home_model" initialized
INFO - 2023-11-19 07:58:55 --> Helper loaded: download_helper
INFO - 2023-11-19 07:58:55 --> Helper loaded: form_helper
INFO - 2023-11-19 07:58:55 --> Form Validation Class Initialized
INFO - 2023-11-19 12:28:55 --> Helper loaded: custom_helper
INFO - 2023-11-19 12:28:55 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 12:28:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 12:28:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 12:28:55 --> Final output sent to browser
DEBUG - 2023-11-19 12:28:55 --> Total execution time: 0.2160
INFO - 2023-11-19 08:04:10 --> Config Class Initialized
INFO - 2023-11-19 08:04:10 --> Hooks Class Initialized
DEBUG - 2023-11-19 08:04:10 --> UTF-8 Support Enabled
INFO - 2023-11-19 08:04:10 --> Utf8 Class Initialized
INFO - 2023-11-19 08:04:10 --> URI Class Initialized
DEBUG - 2023-11-19 08:04:10 --> No URI present. Default controller set.
INFO - 2023-11-19 08:04:10 --> Router Class Initialized
INFO - 2023-11-19 08:04:10 --> Output Class Initialized
INFO - 2023-11-19 08:04:10 --> Security Class Initialized
DEBUG - 2023-11-19 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 08:04:10 --> Input Class Initialized
INFO - 2023-11-19 08:04:10 --> Language Class Initialized
INFO - 2023-11-19 08:04:10 --> Loader Class Initialized
INFO - 2023-11-19 08:04:10 --> Helper loaded: url_helper
INFO - 2023-11-19 08:04:10 --> Helper loaded: file_helper
INFO - 2023-11-19 08:04:10 --> Database Driver Class Initialized
INFO - 2023-11-19 08:04:10 --> Email Class Initialized
DEBUG - 2023-11-19 08:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 08:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 08:04:10 --> Controller Class Initialized
INFO - 2023-11-19 08:04:10 --> Model "Contact_model" initialized
INFO - 2023-11-19 08:04:10 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 08:04:10 --> Model "Home_model" initialized
INFO - 2023-11-19 08:04:10 --> Helper loaded: download_helper
INFO - 2023-11-19 08:04:10 --> Helper loaded: form_helper
INFO - 2023-11-19 08:04:10 --> Form Validation Class Initialized
INFO - 2023-11-19 12:34:10 --> Helper loaded: custom_helper
INFO - 2023-11-19 12:34:10 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 12:34:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 12:34:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 12:34:10 --> Final output sent to browser
DEBUG - 2023-11-19 12:34:10 --> Total execution time: 0.0928
INFO - 2023-11-19 09:34:18 --> Config Class Initialized
INFO - 2023-11-19 09:34:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:34:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:34:18 --> Utf8 Class Initialized
INFO - 2023-11-19 09:34:18 --> URI Class Initialized
INFO - 2023-11-19 09:34:18 --> Router Class Initialized
INFO - 2023-11-19 09:34:18 --> Output Class Initialized
INFO - 2023-11-19 09:34:18 --> Security Class Initialized
DEBUG - 2023-11-19 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:34:18 --> Input Class Initialized
INFO - 2023-11-19 09:34:18 --> Language Class Initialized
INFO - 2023-11-19 09:34:18 --> Loader Class Initialized
INFO - 2023-11-19 09:34:18 --> Helper loaded: url_helper
INFO - 2023-11-19 09:34:18 --> Helper loaded: file_helper
INFO - 2023-11-19 09:34:18 --> Database Driver Class Initialized
INFO - 2023-11-19 09:34:18 --> Email Class Initialized
DEBUG - 2023-11-19 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 09:34:18 --> Controller Class Initialized
INFO - 2023-11-19 09:34:18 --> Model "Testimonials_model" initialized
INFO - 2023-11-19 09:34:18 --> Helper loaded: form_helper
INFO - 2023-11-19 09:34:18 --> Form Validation Class Initialized
INFO - 2023-11-19 09:34:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_list.php
INFO - 2023-11-19 09:34:18 --> Final output sent to browser
DEBUG - 2023-11-19 09:34:18 --> Total execution time: 0.0885
INFO - 2023-11-19 09:34:22 --> Config Class Initialized
INFO - 2023-11-19 09:34:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:34:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:34:22 --> Utf8 Class Initialized
INFO - 2023-11-19 09:34:22 --> URI Class Initialized
INFO - 2023-11-19 09:34:22 --> Router Class Initialized
INFO - 2023-11-19 09:34:22 --> Output Class Initialized
INFO - 2023-11-19 09:34:22 --> Security Class Initialized
DEBUG - 2023-11-19 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:34:22 --> Input Class Initialized
INFO - 2023-11-19 09:34:22 --> Language Class Initialized
INFO - 2023-11-19 09:34:22 --> Config Class Initialized
INFO - 2023-11-19 09:34:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:34:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:34:22 --> Utf8 Class Initialized
INFO - 2023-11-19 09:34:22 --> URI Class Initialized
INFO - 2023-11-19 09:34:22 --> Router Class Initialized
INFO - 2023-11-19 09:34:22 --> Output Class Initialized
INFO - 2023-11-19 09:34:22 --> Security Class Initialized
DEBUG - 2023-11-19 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:34:22 --> Input Class Initialized
INFO - 2023-11-19 09:34:22 --> Language Class Initialized
ERROR - 2023-11-19 09:34:23 --> 404 Page Not Found: admin/Images/favicon.png
ERROR - 2023-11-19 09:34:23 --> 404 Page Not Found: Assets/admin
INFO - 2023-11-19 09:34:41 --> Config Class Initialized
INFO - 2023-11-19 09:34:41 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:34:41 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:34:41 --> Utf8 Class Initialized
INFO - 2023-11-19 09:34:41 --> URI Class Initialized
INFO - 2023-11-19 09:34:41 --> Router Class Initialized
INFO - 2023-11-19 09:34:41 --> Output Class Initialized
INFO - 2023-11-19 09:34:41 --> Security Class Initialized
DEBUG - 2023-11-19 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:34:41 --> Input Class Initialized
INFO - 2023-11-19 09:34:41 --> Language Class Initialized
INFO - 2023-11-19 09:34:41 --> Loader Class Initialized
INFO - 2023-11-19 09:34:41 --> Helper loaded: url_helper
INFO - 2023-11-19 09:34:41 --> Helper loaded: file_helper
INFO - 2023-11-19 09:34:41 --> Database Driver Class Initialized
INFO - 2023-11-19 09:34:41 --> Email Class Initialized
DEBUG - 2023-11-19 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 09:34:41 --> Controller Class Initialized
INFO - 2023-11-19 09:34:41 --> Model "User_model" initialized
INFO - 2023-11-19 09:34:41 --> Config Class Initialized
INFO - 2023-11-19 09:34:41 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:34:41 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:34:41 --> Utf8 Class Initialized
INFO - 2023-11-19 09:34:41 --> URI Class Initialized
INFO - 2023-11-19 09:34:41 --> Router Class Initialized
INFO - 2023-11-19 09:34:41 --> Output Class Initialized
INFO - 2023-11-19 09:34:41 --> Security Class Initialized
DEBUG - 2023-11-19 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:34:41 --> Input Class Initialized
INFO - 2023-11-19 09:34:41 --> Language Class Initialized
INFO - 2023-11-19 09:34:41 --> Loader Class Initialized
INFO - 2023-11-19 09:34:41 --> Helper loaded: url_helper
INFO - 2023-11-19 09:34:41 --> Helper loaded: file_helper
INFO - 2023-11-19 09:34:41 --> Database Driver Class Initialized
INFO - 2023-11-19 09:34:41 --> Email Class Initialized
DEBUG - 2023-11-19 09:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 09:34:41 --> Controller Class Initialized
INFO - 2023-11-19 09:34:41 --> Model "User_model" initialized
INFO - 2023-11-19 09:34:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-11-19 09:34:41 --> Final output sent to browser
DEBUG - 2023-11-19 09:34:41 --> Total execution time: 0.0627
INFO - 2023-11-19 11:43:51 --> Config Class Initialized
INFO - 2023-11-19 11:43:51 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:43:51 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:43:51 --> Utf8 Class Initialized
INFO - 2023-11-19 11:43:52 --> URI Class Initialized
DEBUG - 2023-11-19 11:43:52 --> No URI present. Default controller set.
INFO - 2023-11-19 11:43:52 --> Router Class Initialized
INFO - 2023-11-19 11:43:52 --> Output Class Initialized
INFO - 2023-11-19 11:43:52 --> Security Class Initialized
DEBUG - 2023-11-19 11:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:43:52 --> Input Class Initialized
INFO - 2023-11-19 11:43:52 --> Language Class Initialized
INFO - 2023-11-19 11:43:52 --> Loader Class Initialized
INFO - 2023-11-19 11:43:52 --> Helper loaded: url_helper
INFO - 2023-11-19 11:43:52 --> Helper loaded: file_helper
INFO - 2023-11-19 11:43:52 --> Database Driver Class Initialized
INFO - 2023-11-19 11:43:52 --> Email Class Initialized
DEBUG - 2023-11-19 11:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:43:52 --> Controller Class Initialized
INFO - 2023-11-19 11:43:52 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:43:52 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:43:52 --> Model "Home_model" initialized
INFO - 2023-11-19 11:43:52 --> Helper loaded: download_helper
INFO - 2023-11-19 11:43:52 --> Helper loaded: form_helper
INFO - 2023-11-19 11:43:52 --> Form Validation Class Initialized
INFO - 2023-11-19 16:13:52 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:13:52 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:13:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:13:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 16:13:52 --> Final output sent to browser
DEBUG - 2023-11-19 16:13:52 --> Total execution time: 1.0733
INFO - 2023-11-19 11:44:01 --> Config Class Initialized
INFO - 2023-11-19 11:44:01 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:44:01 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:44:01 --> Utf8 Class Initialized
INFO - 2023-11-19 11:44:02 --> URI Class Initialized
INFO - 2023-11-19 11:44:02 --> Router Class Initialized
INFO - 2023-11-19 11:44:02 --> Output Class Initialized
INFO - 2023-11-19 11:44:02 --> Security Class Initialized
DEBUG - 2023-11-19 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:44:02 --> Input Class Initialized
INFO - 2023-11-19 11:44:02 --> Language Class Initialized
INFO - 2023-11-19 11:44:02 --> Loader Class Initialized
INFO - 2023-11-19 11:44:02 --> Helper loaded: url_helper
INFO - 2023-11-19 11:44:02 --> Helper loaded: file_helper
INFO - 2023-11-19 11:44:02 --> Database Driver Class Initialized
INFO - 2023-11-19 11:44:02 --> Email Class Initialized
DEBUG - 2023-11-19 11:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:44:02 --> Controller Class Initialized
INFO - 2023-11-19 11:44:02 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:44:02 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:44:02 --> Model "Home_model" initialized
INFO - 2023-11-19 11:44:02 --> Helper loaded: download_helper
INFO - 2023-11-19 11:44:02 --> Helper loaded: form_helper
INFO - 2023-11-19 11:44:02 --> Form Validation Class Initialized
INFO - 2023-11-19 16:14:02 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:14:02 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:14:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:14:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:14:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:14:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:14:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:14:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:14:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:14:03 --> Final output sent to browser
DEBUG - 2023-11-19 16:14:03 --> Total execution time: 1.5637
INFO - 2023-11-19 11:44:21 --> Config Class Initialized
INFO - 2023-11-19 11:44:21 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:44:21 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:44:21 --> Utf8 Class Initialized
INFO - 2023-11-19 11:44:21 --> URI Class Initialized
INFO - 2023-11-19 11:44:21 --> Router Class Initialized
INFO - 2023-11-19 11:44:21 --> Output Class Initialized
INFO - 2023-11-19 11:44:21 --> Security Class Initialized
DEBUG - 2023-11-19 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:44:21 --> Input Class Initialized
INFO - 2023-11-19 11:44:21 --> Language Class Initialized
INFO - 2023-11-19 11:44:21 --> Loader Class Initialized
INFO - 2023-11-19 11:44:21 --> Helper loaded: url_helper
INFO - 2023-11-19 11:44:21 --> Helper loaded: file_helper
INFO - 2023-11-19 11:44:21 --> Database Driver Class Initialized
INFO - 2023-11-19 11:44:21 --> Email Class Initialized
DEBUG - 2023-11-19 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:44:21 --> Controller Class Initialized
INFO - 2023-11-19 11:44:21 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:44:21 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:44:21 --> Model "Home_model" initialized
INFO - 2023-11-19 11:44:21 --> Helper loaded: download_helper
INFO - 2023-11-19 11:44:21 --> Helper loaded: form_helper
INFO - 2023-11-19 11:44:21 --> Form Validation Class Initialized
INFO - 2023-11-19 16:14:21 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:14:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:14:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:14:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:14:22 --> Final output sent to browser
DEBUG - 2023-11-19 16:14:22 --> Total execution time: 0.1611
INFO - 2023-11-19 11:46:05 --> Config Class Initialized
INFO - 2023-11-19 11:46:05 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:46:05 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:05 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:05 --> URI Class Initialized
INFO - 2023-11-19 11:46:05 --> Router Class Initialized
INFO - 2023-11-19 11:46:05 --> Output Class Initialized
INFO - 2023-11-19 11:46:05 --> Security Class Initialized
DEBUG - 2023-11-19 11:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:46:05 --> Input Class Initialized
INFO - 2023-11-19 11:46:05 --> Language Class Initialized
INFO - 2023-11-19 11:46:05 --> Loader Class Initialized
INFO - 2023-11-19 11:46:05 --> Helper loaded: url_helper
INFO - 2023-11-19 11:46:05 --> Helper loaded: file_helper
INFO - 2023-11-19 11:46:05 --> Database Driver Class Initialized
INFO - 2023-11-19 11:46:05 --> Email Class Initialized
DEBUG - 2023-11-19 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:46:05 --> Controller Class Initialized
INFO - 2023-11-19 11:46:05 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:46:05 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:46:05 --> Model "Home_model" initialized
INFO - 2023-11-19 11:46:05 --> Helper loaded: download_helper
INFO - 2023-11-19 11:46:05 --> Helper loaded: form_helper
INFO - 2023-11-19 11:46:05 --> Form Validation Class Initialized
INFO - 2023-11-19 16:16:05 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:16:05 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:16:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:16:05 --> Final output sent to browser
DEBUG - 2023-11-19 16:16:06 --> Total execution time: 0.1929
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:46:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:14 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:14 --> URI Class Initialized
INFO - 2023-11-19 11:46:14 --> Router Class Initialized
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:46:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:14 --> Output Class Initialized
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
INFO - 2023-11-19 11:46:14 --> URI Class Initialized
INFO - 2023-11-19 11:46:14 --> Security Class Initialized
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
INFO - 2023-11-19 11:46:14 --> Config Class Initialized
INFO - 2023-11-19 11:46:14 --> Router Class Initialized
DEBUG - 2023-11-19 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:46:14 --> Output Class Initialized
INFO - 2023-11-19 11:46:14 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:14 --> URI Class Initialized
INFO - 2023-11-19 11:46:14 --> Router Class Initialized
INFO - 2023-11-19 11:46:14 --> Output Class Initialized
INFO - 2023-11-19 11:46:14 --> Security Class Initialized
DEBUG - 2023-11-19 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:46:14 --> Input Class Initialized
INFO - 2023-11-19 11:46:14 --> Language Class Initialized
ERROR - 2023-11-19 11:46:14 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 11:46:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:14 --> Hooks Class Initialized
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Config Class Initialized
INFO - 2023-11-19 11:46:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:46:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:15 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:15 --> URI Class Initialized
INFO - 2023-11-19 11:46:15 --> Router Class Initialized
INFO - 2023-11-19 11:46:15 --> Output Class Initialized
INFO - 2023-11-19 11:46:15 --> Security Class Initialized
DEBUG - 2023-11-19 11:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:46:15 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:15 --> Security Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
INFO - 2023-11-19 11:46:15 --> Utf8 Class Initialized
DEBUG - 2023-11-19 11:46:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:46:15 --> Utf8 Class Initialized
INFO - 2023-11-19 11:46:15 --> URI Class Initialized
DEBUG - 2023-11-19 11:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:46:15 --> URI Class Initialized
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Router Class Initialized
INFO - 2023-11-19 11:46:15 --> URI Class Initialized
INFO - 2023-11-19 11:46:15 --> Router Class Initialized
INFO - 2023-11-19 11:46:15 --> Router Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
INFO - 2023-11-19 11:46:15 --> Output Class Initialized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:46:15 --> Output Class Initialized
INFO - 2023-11-19 11:46:15 --> Output Class Initialized
INFO - 2023-11-19 11:46:15 --> Security Class Initialized
INFO - 2023-11-19 11:46:15 --> Security Class Initialized
DEBUG - 2023-11-19 11:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-19 11:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:46:15 --> Security Class Initialized
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 11:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:46:15 --> Input Class Initialized
INFO - 2023-11-19 11:46:15 --> Language Class Initialized
ERROR - 2023-11-19 11:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:47:21 --> Config Class Initialized
INFO - 2023-11-19 11:47:21 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:47:21 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:47:21 --> Utf8 Class Initialized
INFO - 2023-11-19 11:47:21 --> URI Class Initialized
INFO - 2023-11-19 11:47:21 --> Router Class Initialized
INFO - 2023-11-19 11:47:21 --> Output Class Initialized
INFO - 2023-11-19 11:47:21 --> Security Class Initialized
DEBUG - 2023-11-19 11:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:47:21 --> Input Class Initialized
INFO - 2023-11-19 11:47:21 --> Language Class Initialized
INFO - 2023-11-19 11:47:21 --> Loader Class Initialized
INFO - 2023-11-19 11:47:21 --> Helper loaded: url_helper
INFO - 2023-11-19 11:47:21 --> Helper loaded: file_helper
INFO - 2023-11-19 11:47:21 --> Database Driver Class Initialized
INFO - 2023-11-19 11:47:21 --> Email Class Initialized
DEBUG - 2023-11-19 11:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:47:21 --> Controller Class Initialized
INFO - 2023-11-19 11:47:21 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:47:21 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:47:21 --> Model "Home_model" initialized
INFO - 2023-11-19 11:47:21 --> Helper loaded: download_helper
INFO - 2023-11-19 11:47:21 --> Helper loaded: form_helper
INFO - 2023-11-19 11:47:21 --> Form Validation Class Initialized
INFO - 2023-11-19 16:17:21 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:17:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:17:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:17:21 --> Final output sent to browser
DEBUG - 2023-11-19 16:17:21 --> Total execution time: 0.3164
INFO - 2023-11-19 11:48:55 --> Config Class Initialized
INFO - 2023-11-19 11:48:55 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:48:55 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:48:55 --> Utf8 Class Initialized
INFO - 2023-11-19 11:48:55 --> URI Class Initialized
INFO - 2023-11-19 11:48:55 --> Router Class Initialized
INFO - 2023-11-19 11:48:55 --> Output Class Initialized
INFO - 2023-11-19 11:48:55 --> Security Class Initialized
DEBUG - 2023-11-19 11:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:48:55 --> Input Class Initialized
INFO - 2023-11-19 11:48:56 --> Language Class Initialized
INFO - 2023-11-19 11:48:56 --> Loader Class Initialized
INFO - 2023-11-19 11:48:56 --> Helper loaded: url_helper
INFO - 2023-11-19 11:48:56 --> Helper loaded: file_helper
INFO - 2023-11-19 11:48:56 --> Database Driver Class Initialized
INFO - 2023-11-19 11:48:56 --> Email Class Initialized
DEBUG - 2023-11-19 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:48:56 --> Controller Class Initialized
INFO - 2023-11-19 11:48:56 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:48:56 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:48:56 --> Model "Home_model" initialized
INFO - 2023-11-19 11:48:56 --> Helper loaded: download_helper
INFO - 2023-11-19 11:48:56 --> Helper loaded: form_helper
INFO - 2023-11-19 11:48:56 --> Form Validation Class Initialized
INFO - 2023-11-19 16:18:57 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:18:57 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:18:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:18:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:18:57 --> Final output sent to browser
DEBUG - 2023-11-19 16:18:58 --> Total execution time: 1.3781
INFO - 2023-11-19 11:48:59 --> Config Class Initialized
INFO - 2023-11-19 11:48:59 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:48:59 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:48:59 --> Utf8 Class Initialized
INFO - 2023-11-19 11:48:59 --> URI Class Initialized
INFO - 2023-11-19 11:48:59 --> Router Class Initialized
INFO - 2023-11-19 11:48:59 --> Output Class Initialized
INFO - 2023-11-19 11:48:59 --> Security Class Initialized
DEBUG - 2023-11-19 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:48:59 --> Input Class Initialized
INFO - 2023-11-19 11:48:59 --> Language Class Initialized
ERROR - 2023-11-19 11:48:59 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:49:03 --> Config Class Initialized
INFO - 2023-11-19 11:49:03 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:49:03 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:49:03 --> Utf8 Class Initialized
INFO - 2023-11-19 11:49:03 --> URI Class Initialized
INFO - 2023-11-19 11:49:03 --> Router Class Initialized
INFO - 2023-11-19 11:49:04 --> Output Class Initialized
INFO - 2023-11-19 11:49:04 --> Config Class Initialized
INFO - 2023-11-19 11:49:04 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:49:04 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:49:04 --> Utf8 Class Initialized
INFO - 2023-11-19 11:49:04 --> URI Class Initialized
INFO - 2023-11-19 11:49:04 --> Router Class Initialized
INFO - 2023-11-19 11:49:04 --> Output Class Initialized
INFO - 2023-11-19 11:49:04 --> Security Class Initialized
DEBUG - 2023-11-19 11:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:49:04 --> Input Class Initialized
INFO - 2023-11-19 11:49:04 --> Language Class Initialized
ERROR - 2023-11-19 11:49:04 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:49:05 --> Config Class Initialized
INFO - 2023-11-19 11:49:05 --> Config Class Initialized
INFO - 2023-11-19 11:49:05 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:49:05 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:49:05 --> Utf8 Class Initialized
INFO - 2023-11-19 11:49:05 --> URI Class Initialized
INFO - 2023-11-19 11:49:05 --> Router Class Initialized
INFO - 2023-11-19 11:49:05 --> Output Class Initialized
INFO - 2023-11-19 11:49:05 --> Security Class Initialized
DEBUG - 2023-11-19 11:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:49:05 --> Input Class Initialized
INFO - 2023-11-19 11:49:05 --> Language Class Initialized
ERROR - 2023-11-19 11:49:05 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:49:06 --> Hooks Class Initialized
INFO - 2023-11-19 11:50:07 --> Config Class Initialized
INFO - 2023-11-19 11:50:07 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:07 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:07 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:07 --> URI Class Initialized
INFO - 2023-11-19 11:50:07 --> Router Class Initialized
INFO - 2023-11-19 11:50:07 --> Output Class Initialized
INFO - 2023-11-19 11:50:07 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:07 --> Input Class Initialized
INFO - 2023-11-19 11:50:07 --> Language Class Initialized
INFO - 2023-11-19 11:50:07 --> Loader Class Initialized
INFO - 2023-11-19 11:50:07 --> Helper loaded: url_helper
INFO - 2023-11-19 11:50:07 --> Helper loaded: file_helper
INFO - 2023-11-19 11:50:07 --> Database Driver Class Initialized
INFO - 2023-11-19 11:50:07 --> Email Class Initialized
DEBUG - 2023-11-19 11:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:50:07 --> Controller Class Initialized
INFO - 2023-11-19 11:50:07 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:50:07 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:50:07 --> Model "Home_model" initialized
INFO - 2023-11-19 11:50:07 --> Helper loaded: download_helper
INFO - 2023-11-19 11:50:07 --> Helper loaded: form_helper
INFO - 2023-11-19 11:50:07 --> Form Validation Class Initialized
INFO - 2023-11-19 16:20:09 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:20:09 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:20:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:20:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:20:10 --> Final output sent to browser
DEBUG - 2023-11-19 16:20:10 --> Total execution time: 2.8829
INFO - 2023-11-19 11:50:12 --> Config Class Initialized
INFO - 2023-11-19 11:50:12 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:12 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:12 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:12 --> URI Class Initialized
INFO - 2023-11-19 11:50:12 --> Router Class Initialized
INFO - 2023-11-19 11:50:12 --> Output Class Initialized
INFO - 2023-11-19 11:50:12 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:12 --> Input Class Initialized
INFO - 2023-11-19 11:50:12 --> Language Class Initialized
ERROR - 2023-11-19 11:50:12 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:50:15 --> Config Class Initialized
INFO - 2023-11-19 11:50:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:15 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:15 --> URI Class Initialized
INFO - 2023-11-19 11:50:15 --> Router Class Initialized
INFO - 2023-11-19 11:50:15 --> Output Class Initialized
INFO - 2023-11-19 11:50:15 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:15 --> Input Class Initialized
INFO - 2023-11-19 11:50:15 --> Language Class Initialized
ERROR - 2023-11-19 11:50:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:50:15 --> Config Class Initialized
INFO - 2023-11-19 11:50:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:15 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:15 --> URI Class Initialized
INFO - 2023-11-19 11:50:15 --> Router Class Initialized
INFO - 2023-11-19 11:50:15 --> Output Class Initialized
INFO - 2023-11-19 11:50:15 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:15 --> Input Class Initialized
INFO - 2023-11-19 11:50:15 --> Language Class Initialized
ERROR - 2023-11-19 11:50:15 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:50:17 --> Config Class Initialized
INFO - 2023-11-19 11:50:17 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:17 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:17 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:17 --> URI Class Initialized
INFO - 2023-11-19 11:50:17 --> Router Class Initialized
INFO - 2023-11-19 11:50:17 --> Output Class Initialized
INFO - 2023-11-19 11:50:17 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:17 --> Input Class Initialized
INFO - 2023-11-19 11:50:17 --> Language Class Initialized
ERROR - 2023-11-19 11:50:17 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:50:20 --> Config Class Initialized
INFO - 2023-11-19 11:50:20 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:20 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:20 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:20 --> URI Class Initialized
INFO - 2023-11-19 11:50:20 --> Router Class Initialized
INFO - 2023-11-19 11:50:20 --> Output Class Initialized
INFO - 2023-11-19 11:50:20 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:20 --> Input Class Initialized
INFO - 2023-11-19 11:50:20 --> Language Class Initialized
ERROR - 2023-11-19 11:50:20 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:50:20 --> Config Class Initialized
INFO - 2023-11-19 11:50:20 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:50:20 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:50:20 --> Utf8 Class Initialized
INFO - 2023-11-19 11:50:20 --> URI Class Initialized
INFO - 2023-11-19 11:50:20 --> Router Class Initialized
INFO - 2023-11-19 11:50:20 --> Output Class Initialized
INFO - 2023-11-19 11:50:20 --> Security Class Initialized
DEBUG - 2023-11-19 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:50:20 --> Input Class Initialized
INFO - 2023-11-19 11:50:20 --> Language Class Initialized
ERROR - 2023-11-19 11:50:20 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:52:36 --> Config Class Initialized
INFO - 2023-11-19 11:52:36 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:52:36 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:52:36 --> Utf8 Class Initialized
INFO - 2023-11-19 11:52:36 --> URI Class Initialized
INFO - 2023-11-19 11:52:36 --> Router Class Initialized
INFO - 2023-11-19 11:52:36 --> Output Class Initialized
INFO - 2023-11-19 11:52:36 --> Security Class Initialized
DEBUG - 2023-11-19 11:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:52:36 --> Input Class Initialized
INFO - 2023-11-19 11:52:36 --> Language Class Initialized
INFO - 2023-11-19 11:52:36 --> Loader Class Initialized
INFO - 2023-11-19 11:52:36 --> Helper loaded: url_helper
INFO - 2023-11-19 11:52:36 --> Helper loaded: file_helper
INFO - 2023-11-19 11:52:36 --> Database Driver Class Initialized
INFO - 2023-11-19 11:52:36 --> Email Class Initialized
DEBUG - 2023-11-19 11:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:52:36 --> Controller Class Initialized
INFO - 2023-11-19 11:52:36 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:52:36 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:52:36 --> Model "Home_model" initialized
INFO - 2023-11-19 11:52:36 --> Helper loaded: download_helper
INFO - 2023-11-19 11:52:36 --> Helper loaded: form_helper
INFO - 2023-11-19 11:52:36 --> Form Validation Class Initialized
INFO - 2023-11-19 16:22:36 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:22:37 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:22:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:22:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:22:37 --> Final output sent to browser
DEBUG - 2023-11-19 16:22:37 --> Total execution time: 0.3177
INFO - 2023-11-19 11:52:40 --> Config Class Initialized
INFO - 2023-11-19 11:52:40 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:52:40 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:52:40 --> Utf8 Class Initialized
INFO - 2023-11-19 11:52:40 --> URI Class Initialized
INFO - 2023-11-19 11:52:40 --> Router Class Initialized
INFO - 2023-11-19 11:52:40 --> Output Class Initialized
INFO - 2023-11-19 11:52:40 --> Security Class Initialized
DEBUG - 2023-11-19 11:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:52:40 --> Input Class Initialized
INFO - 2023-11-19 11:52:40 --> Language Class Initialized
ERROR - 2023-11-19 11:52:40 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:54:18 --> Config Class Initialized
INFO - 2023-11-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-11-19 11:54:18 --> URI Class Initialized
INFO - 2023-11-19 11:54:18 --> Router Class Initialized
INFO - 2023-11-19 11:54:18 --> Output Class Initialized
INFO - 2023-11-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-11-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:54:18 --> Input Class Initialized
INFO - 2023-11-19 11:54:18 --> Language Class Initialized
INFO - 2023-11-19 11:54:18 --> Loader Class Initialized
INFO - 2023-11-19 11:54:18 --> Helper loaded: url_helper
INFO - 2023-11-19 11:54:18 --> Helper loaded: file_helper
INFO - 2023-11-19 11:54:18 --> Database Driver Class Initialized
INFO - 2023-11-19 11:54:18 --> Email Class Initialized
DEBUG - 2023-11-19 11:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 11:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 11:54:18 --> Controller Class Initialized
INFO - 2023-11-19 11:54:18 --> Model "Contact_model" initialized
INFO - 2023-11-19 11:54:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 11:54:18 --> Model "Home_model" initialized
INFO - 2023-11-19 11:54:18 --> Helper loaded: download_helper
INFO - 2023-11-19 11:54:18 --> Helper loaded: form_helper
INFO - 2023-11-19 11:54:18 --> Form Validation Class Initialized
INFO - 2023-11-19 16:24:18 --> Helper loaded: custom_helper
INFO - 2023-11-19 16:24:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 16:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 16:24:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 16:24:18 --> Final output sent to browser
DEBUG - 2023-11-19 16:24:18 --> Total execution time: 0.1975
INFO - 2023-11-19 11:54:19 --> Config Class Initialized
INFO - 2023-11-19 11:54:19 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:54:19 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:54:19 --> Utf8 Class Initialized
INFO - 2023-11-19 11:54:19 --> URI Class Initialized
INFO - 2023-11-19 11:54:19 --> Router Class Initialized
INFO - 2023-11-19 11:54:19 --> Output Class Initialized
INFO - 2023-11-19 11:54:19 --> Security Class Initialized
DEBUG - 2023-11-19 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:54:19 --> Input Class Initialized
INFO - 2023-11-19 11:54:19 --> Language Class Initialized
ERROR - 2023-11-19 11:54:19 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:54:22 --> Config Class Initialized
INFO - 2023-11-19 11:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:54:22 --> Utf8 Class Initialized
INFO - 2023-11-19 11:54:22 --> URI Class Initialized
INFO - 2023-11-19 11:54:22 --> Router Class Initialized
INFO - 2023-11-19 11:54:22 --> Output Class Initialized
INFO - 2023-11-19 11:54:22 --> Security Class Initialized
DEBUG - 2023-11-19 11:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 11:54:22 --> Input Class Initialized
INFO - 2023-11-19 11:54:22 --> Language Class Initialized
ERROR - 2023-11-19 11:54:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 11:54:22 --> Config Class Initialized
INFO - 2023-11-19 11:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:54:22 --> Utf8 Class Initialized
INFO - 2023-11-19 11:54:22 --> Config Class Initialized
INFO - 2023-11-19 11:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 11:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 11:54:22 --> Utf8 Class Initialized
INFO - 2023-11-19 11:54:22 --> URI Class Initialized
INFO - 2023-11-19 11:54:22 --> Router Class Initialized
INFO - 2023-11-19 11:54:22 --> Output Class Initialized
INFO - 2023-11-19 15:25:07 --> Config Class Initialized
INFO - 2023-11-19 15:25:07 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:25:07 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:25:07 --> Utf8 Class Initialized
INFO - 2023-11-19 15:25:07 --> URI Class Initialized
DEBUG - 2023-11-19 15:25:07 --> No URI present. Default controller set.
INFO - 2023-11-19 15:25:07 --> Router Class Initialized
INFO - 2023-11-19 15:25:07 --> Output Class Initialized
INFO - 2023-11-19 15:25:07 --> Security Class Initialized
DEBUG - 2023-11-19 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:25:07 --> Input Class Initialized
INFO - 2023-11-19 15:25:07 --> Language Class Initialized
INFO - 2023-11-19 15:25:07 --> Loader Class Initialized
INFO - 2023-11-19 15:25:07 --> Helper loaded: url_helper
INFO - 2023-11-19 15:25:07 --> Helper loaded: file_helper
INFO - 2023-11-19 15:25:07 --> Database Driver Class Initialized
INFO - 2023-11-19 15:25:07 --> Email Class Initialized
DEBUG - 2023-11-19 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:25:07 --> Controller Class Initialized
INFO - 2023-11-19 15:25:07 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:25:07 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:25:07 --> Model "Home_model" initialized
INFO - 2023-11-19 15:25:07 --> Helper loaded: download_helper
INFO - 2023-11-19 15:25:07 --> Helper loaded: form_helper
INFO - 2023-11-19 15:25:07 --> Form Validation Class Initialized
INFO - 2023-11-19 19:55:07 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:55:07 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:55:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:55:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 19:55:08 --> Final output sent to browser
DEBUG - 2023-11-19 19:55:08 --> Total execution time: 0.2077
INFO - 2023-11-19 15:25:15 --> Config Class Initialized
INFO - 2023-11-19 15:25:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:25:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:25:15 --> Utf8 Class Initialized
INFO - 2023-11-19 15:25:15 --> URI Class Initialized
INFO - 2023-11-19 15:25:15 --> Router Class Initialized
INFO - 2023-11-19 15:25:15 --> Output Class Initialized
INFO - 2023-11-19 15:25:15 --> Security Class Initialized
DEBUG - 2023-11-19 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:25:15 --> Input Class Initialized
INFO - 2023-11-19 15:25:15 --> Language Class Initialized
INFO - 2023-11-19 15:25:15 --> Loader Class Initialized
INFO - 2023-11-19 15:25:15 --> Helper loaded: url_helper
INFO - 2023-11-19 15:25:15 --> Helper loaded: file_helper
INFO - 2023-11-19 15:25:15 --> Database Driver Class Initialized
INFO - 2023-11-19 15:25:15 --> Email Class Initialized
DEBUG - 2023-11-19 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:25:15 --> Controller Class Initialized
INFO - 2023-11-19 15:25:15 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:25:15 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:25:15 --> Model "Home_model" initialized
INFO - 2023-11-19 15:25:15 --> Helper loaded: download_helper
INFO - 2023-11-19 15:25:16 --> Helper loaded: form_helper
INFO - 2023-11-19 15:25:16 --> Form Validation Class Initialized
INFO - 2023-11-19 19:55:16 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:55:16 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:55:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 19:55:16 --> Final output sent to browser
DEBUG - 2023-11-19 19:55:16 --> Total execution time: 0.8692
INFO - 2023-11-19 15:25:26 --> Config Class Initialized
INFO - 2023-11-19 15:25:26 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:25:26 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:25:26 --> Utf8 Class Initialized
INFO - 2023-11-19 15:25:26 --> URI Class Initialized
INFO - 2023-11-19 15:25:26 --> Router Class Initialized
INFO - 2023-11-19 15:25:26 --> Output Class Initialized
INFO - 2023-11-19 15:25:26 --> Security Class Initialized
DEBUG - 2023-11-19 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:25:26 --> Input Class Initialized
INFO - 2023-11-19 15:25:26 --> Language Class Initialized
INFO - 2023-11-19 15:25:26 --> Loader Class Initialized
INFO - 2023-11-19 15:25:26 --> Helper loaded: url_helper
INFO - 2023-11-19 15:25:26 --> Helper loaded: file_helper
INFO - 2023-11-19 15:25:26 --> Database Driver Class Initialized
INFO - 2023-11-19 15:25:26 --> Email Class Initialized
DEBUG - 2023-11-19 15:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:25:26 --> Controller Class Initialized
INFO - 2023-11-19 15:25:26 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:25:26 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:25:26 --> Model "Home_model" initialized
INFO - 2023-11-19 15:25:26 --> Helper loaded: download_helper
INFO - 2023-11-19 15:25:26 --> Helper loaded: form_helper
INFO - 2023-11-19 15:25:26 --> Form Validation Class Initialized
INFO - 2023-11-19 19:55:26 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:55:26 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:55:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:55:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 19:55:27 --> Final output sent to browser
DEBUG - 2023-11-19 19:55:27 --> Total execution time: 0.1515
INFO - 2023-11-19 15:25:46 --> Config Class Initialized
INFO - 2023-11-19 15:25:46 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:25:46 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:25:46 --> Utf8 Class Initialized
INFO - 2023-11-19 15:25:46 --> URI Class Initialized
INFO - 2023-11-19 15:25:46 --> Router Class Initialized
INFO - 2023-11-19 15:25:46 --> Output Class Initialized
INFO - 2023-11-19 15:25:46 --> Security Class Initialized
DEBUG - 2023-11-19 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:25:46 --> Input Class Initialized
INFO - 2023-11-19 15:25:46 --> Language Class Initialized
INFO - 2023-11-19 15:25:46 --> Loader Class Initialized
INFO - 2023-11-19 15:25:46 --> Helper loaded: url_helper
INFO - 2023-11-19 15:25:46 --> Helper loaded: file_helper
INFO - 2023-11-19 15:25:46 --> Database Driver Class Initialized
INFO - 2023-11-19 15:25:46 --> Email Class Initialized
DEBUG - 2023-11-19 15:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:25:46 --> Controller Class Initialized
INFO - 2023-11-19 15:25:46 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:25:46 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:25:46 --> Model "Home_model" initialized
INFO - 2023-11-19 15:25:46 --> Helper loaded: download_helper
INFO - 2023-11-19 15:25:46 --> Helper loaded: form_helper
INFO - 2023-11-19 15:25:46 --> Form Validation Class Initialized
INFO - 2023-11-19 19:55:46 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:55:46 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:55:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:55:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 19:55:46 --> Final output sent to browser
DEBUG - 2023-11-19 19:55:46 --> Total execution time: 0.4105
INFO - 2023-11-19 15:28:00 --> Config Class Initialized
INFO - 2023-11-19 15:28:00 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:00 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:00 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:00 --> URI Class Initialized
INFO - 2023-11-19 15:28:00 --> Router Class Initialized
INFO - 2023-11-19 15:28:00 --> Output Class Initialized
INFO - 2023-11-19 15:28:00 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:00 --> Input Class Initialized
INFO - 2023-11-19 15:28:00 --> Language Class Initialized
INFO - 2023-11-19 15:28:00 --> Loader Class Initialized
INFO - 2023-11-19 15:28:00 --> Helper loaded: url_helper
INFO - 2023-11-19 15:28:00 --> Helper loaded: file_helper
INFO - 2023-11-19 15:28:00 --> Database Driver Class Initialized
INFO - 2023-11-19 15:28:00 --> Email Class Initialized
DEBUG - 2023-11-19 15:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:28:00 --> Controller Class Initialized
INFO - 2023-11-19 15:28:00 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:28:00 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:28:00 --> Model "Home_model" initialized
INFO - 2023-11-19 15:28:00 --> Helper loaded: download_helper
INFO - 2023-11-19 15:28:00 --> Helper loaded: form_helper
INFO - 2023-11-19 15:28:00 --> Form Validation Class Initialized
INFO - 2023-11-19 19:58:00 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:58:00 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:58:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:58:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 19:58:00 --> Final output sent to browser
DEBUG - 2023-11-19 19:58:01 --> Total execution time: 0.3008
INFO - 2023-11-19 15:28:10 --> Config Class Initialized
INFO - 2023-11-19 15:28:12 --> Hooks Class Initialized
INFO - 2023-11-19 15:28:12 --> Config Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
INFO - 2023-11-19 15:28:13 --> Config Class Initialized
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> Config Class Initialized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
INFO - 2023-11-19 15:28:13 --> Config Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Config Class Initialized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
INFO - 2023-11-19 15:28:13 --> Config Class Initialized
INFO - 2023-11-19 15:28:13 --> Hooks Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-19 15:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
INFO - 2023-11-19 15:28:13 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:13 --> URI Class Initialized
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
INFO - 2023-11-19 15:28:13 --> Router Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:13 --> Output Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:13 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Input Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
INFO - 2023-11-19 15:28:13 --> Language Class Initialized
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-19 15:28:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:28:36 --> Config Class Initialized
INFO - 2023-11-19 15:28:36 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:36 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:36 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:36 --> URI Class Initialized
INFO - 2023-11-19 15:28:36 --> Router Class Initialized
INFO - 2023-11-19 15:28:36 --> Output Class Initialized
INFO - 2023-11-19 15:28:36 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:36 --> Input Class Initialized
INFO - 2023-11-19 15:28:36 --> Language Class Initialized
INFO - 2023-11-19 15:28:36 --> Loader Class Initialized
INFO - 2023-11-19 15:28:36 --> Helper loaded: url_helper
INFO - 2023-11-19 15:28:36 --> Helper loaded: file_helper
INFO - 2023-11-19 15:28:36 --> Database Driver Class Initialized
INFO - 2023-11-19 15:28:36 --> Email Class Initialized
DEBUG - 2023-11-19 15:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:28:36 --> Controller Class Initialized
INFO - 2023-11-19 15:28:36 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:28:36 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:28:36 --> Model "Home_model" initialized
INFO - 2023-11-19 15:28:36 --> Helper loaded: download_helper
INFO - 2023-11-19 15:28:36 --> Helper loaded: form_helper
INFO - 2023-11-19 15:28:36 --> Form Validation Class Initialized
INFO - 2023-11-19 19:58:36 --> Helper loaded: custom_helper
INFO - 2023-11-19 19:58:36 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 19:58:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 19:58:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 19:58:36 --> Final output sent to browser
DEBUG - 2023-11-19 19:58:36 --> Total execution time: 0.2696
INFO - 2023-11-19 15:31:21 --> Config Class Initialized
INFO - 2023-11-19 15:31:21 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:31:21 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:31:21 --> Utf8 Class Initialized
INFO - 2023-11-19 15:31:21 --> URI Class Initialized
INFO - 2023-11-19 15:31:21 --> Router Class Initialized
INFO - 2023-11-19 15:31:21 --> Output Class Initialized
INFO - 2023-11-19 15:31:21 --> Security Class Initialized
DEBUG - 2023-11-19 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:31:21 --> Input Class Initialized
INFO - 2023-11-19 15:31:21 --> Language Class Initialized
INFO - 2023-11-19 15:31:21 --> Loader Class Initialized
INFO - 2023-11-19 15:31:21 --> Helper loaded: url_helper
INFO - 2023-11-19 15:31:21 --> Helper loaded: file_helper
INFO - 2023-11-19 15:31:21 --> Database Driver Class Initialized
INFO - 2023-11-19 15:31:21 --> Email Class Initialized
DEBUG - 2023-11-19 15:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:31:21 --> Controller Class Initialized
INFO - 2023-11-19 15:31:21 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:31:21 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:31:21 --> Model "Home_model" initialized
INFO - 2023-11-19 15:31:21 --> Helper loaded: download_helper
INFO - 2023-11-19 15:31:21 --> Helper loaded: form_helper
INFO - 2023-11-19 15:31:21 --> Form Validation Class Initialized
INFO - 2023-11-19 20:01:21 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:01:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:01:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:01:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:01:21 --> Final output sent to browser
DEBUG - 2023-11-19 20:01:22 --> Total execution time: 0.2883
INFO - 2023-11-19 15:31:24 --> Config Class Initialized
INFO - 2023-11-19 15:31:24 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:31:24 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:31:24 --> Utf8 Class Initialized
INFO - 2023-11-19 15:31:24 --> URI Class Initialized
INFO - 2023-11-19 15:31:24 --> Router Class Initialized
INFO - 2023-11-19 15:31:24 --> Output Class Initialized
INFO - 2023-11-19 15:31:24 --> Security Class Initialized
DEBUG - 2023-11-19 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:31:24 --> Input Class Initialized
INFO - 2023-11-19 15:31:24 --> Language Class Initialized
ERROR - 2023-11-19 15:31:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:39 --> Config Class Initialized
INFO - 2023-11-19 15:32:40 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:40 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:40 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:40 --> URI Class Initialized
INFO - 2023-11-19 15:32:40 --> Router Class Initialized
INFO - 2023-11-19 15:32:40 --> Output Class Initialized
INFO - 2023-11-19 15:32:40 --> Security Class Initialized
DEBUG - 2023-11-19 15:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:40 --> Input Class Initialized
INFO - 2023-11-19 15:32:40 --> Language Class Initialized
INFO - 2023-11-19 15:32:40 --> Loader Class Initialized
INFO - 2023-11-19 15:32:40 --> Helper loaded: url_helper
INFO - 2023-11-19 15:32:40 --> Helper loaded: file_helper
INFO - 2023-11-19 15:32:40 --> Database Driver Class Initialized
INFO - 2023-11-19 15:32:40 --> Email Class Initialized
DEBUG - 2023-11-19 15:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:32:40 --> Controller Class Initialized
INFO - 2023-11-19 15:32:40 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:32:40 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:32:40 --> Model "Home_model" initialized
INFO - 2023-11-19 15:32:40 --> Helper loaded: download_helper
INFO - 2023-11-19 15:32:40 --> Helper loaded: form_helper
INFO - 2023-11-19 15:32:40 --> Form Validation Class Initialized
INFO - 2023-11-19 20:02:40 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:02:40 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:02:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:02:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:02:40 --> Final output sent to browser
DEBUG - 2023-11-19 20:02:40 --> Total execution time: 0.5371
INFO - 2023-11-19 15:32:43 --> Config Class Initialized
INFO - 2023-11-19 15:32:43 --> Config Class Initialized
INFO - 2023-11-19 15:32:43 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:43 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:43 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:43 --> URI Class Initialized
INFO - 2023-11-19 15:32:43 --> Router Class Initialized
INFO - 2023-11-19 15:32:43 --> Output Class Initialized
INFO - 2023-11-19 15:32:43 --> Security Class Initialized
DEBUG - 2023-11-19 15:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:43 --> Input Class Initialized
INFO - 2023-11-19 15:32:43 --> Language Class Initialized
ERROR - 2023-11-19 15:32:43 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:44 --> Config Class Initialized
INFO - 2023-11-19 15:32:44 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:44 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:44 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:45 --> Config Class Initialized
INFO - 2023-11-19 15:32:45 --> Config Class Initialized
INFO - 2023-11-19 15:32:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:45 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:45 --> URI Class Initialized
INFO - 2023-11-19 15:32:45 --> Router Class Initialized
INFO - 2023-11-19 15:32:45 --> Output Class Initialized
INFO - 2023-11-19 15:32:45 --> Security Class Initialized
DEBUG - 2023-11-19 15:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:45 --> Input Class Initialized
INFO - 2023-11-19 15:32:45 --> Language Class Initialized
ERROR - 2023-11-19 15:32:45 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:46 --> Config Class Initialized
INFO - 2023-11-19 15:32:46 --> URI Class Initialized
INFO - 2023-11-19 15:32:47 --> Hooks Class Initialized
INFO - 2023-11-19 15:32:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:47 --> Hooks Class Initialized
INFO - 2023-11-19 15:32:47 --> Config Class Initialized
INFO - 2023-11-19 15:32:47 --> Router Class Initialized
DEBUG - 2023-11-19 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 15:32:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:47 --> Output Class Initialized
INFO - 2023-11-19 15:32:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:47 --> Security Class Initialized
INFO - 2023-11-19 15:32:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:47 --> URI Class Initialized
INFO - 2023-11-19 15:32:47 --> URI Class Initialized
INFO - 2023-11-19 15:32:47 --> URI Class Initialized
DEBUG - 2023-11-19 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:47 --> Router Class Initialized
INFO - 2023-11-19 15:32:47 --> Input Class Initialized
INFO - 2023-11-19 15:32:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:47 --> Router Class Initialized
INFO - 2023-11-19 15:32:47 --> Output Class Initialized
INFO - 2023-11-19 15:32:47 --> Router Class Initialized
INFO - 2023-11-19 15:32:47 --> Output Class Initialized
INFO - 2023-11-19 15:32:47 --> Language Class Initialized
INFO - 2023-11-19 15:32:47 --> Security Class Initialized
INFO - 2023-11-19 15:32:47 --> URI Class Initialized
ERROR - 2023-11-19 15:32:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:47 --> Router Class Initialized
DEBUG - 2023-11-19 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:47 --> Security Class Initialized
INFO - 2023-11-19 15:32:47 --> Output Class Initialized
INFO - 2023-11-19 15:32:47 --> Output Class Initialized
INFO - 2023-11-19 15:32:47 --> Input Class Initialized
INFO - 2023-11-19 15:32:47 --> Security Class Initialized
INFO - 2023-11-19 15:32:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-19 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:47 --> Language Class Initialized
INFO - 2023-11-19 15:32:47 --> Input Class Initialized
DEBUG - 2023-11-19 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:47 --> Input Class Initialized
INFO - 2023-11-19 15:32:47 --> Language Class Initialized
ERROR - 2023-11-19 15:32:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:47 --> Language Class Initialized
INFO - 2023-11-19 15:32:47 --> Input Class Initialized
ERROR - 2023-11-19 15:32:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:47 --> Language Class Initialized
ERROR - 2023-11-19 15:32:47 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-19 15:32:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:32:48 --> Config Class Initialized
INFO - 2023-11-19 15:32:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:32:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:32:48 --> Utf8 Class Initialized
INFO - 2023-11-19 15:32:48 --> URI Class Initialized
INFO - 2023-11-19 15:32:48 --> Router Class Initialized
INFO - 2023-11-19 15:32:48 --> Output Class Initialized
INFO - 2023-11-19 15:32:48 --> Security Class Initialized
DEBUG - 2023-11-19 15:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:32:48 --> Input Class Initialized
INFO - 2023-11-19 15:32:48 --> Language Class Initialized
INFO - 2023-11-19 15:32:48 --> Loader Class Initialized
INFO - 2023-11-19 15:32:48 --> Helper loaded: url_helper
INFO - 2023-11-19 15:32:48 --> Helper loaded: file_helper
INFO - 2023-11-19 15:32:48 --> Database Driver Class Initialized
INFO - 2023-11-19 15:32:48 --> Email Class Initialized
DEBUG - 2023-11-19 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:32:48 --> Controller Class Initialized
INFO - 2023-11-19 15:32:48 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:32:48 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:32:48 --> Model "Home_model" initialized
INFO - 2023-11-19 15:32:48 --> Helper loaded: download_helper
INFO - 2023-11-19 15:32:48 --> Helper loaded: form_helper
INFO - 2023-11-19 15:32:48 --> Form Validation Class Initialized
INFO - 2023-11-19 20:02:48 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:02:48 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:02:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:02:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:02:48 --> Final output sent to browser
DEBUG - 2023-11-19 20:02:48 --> Total execution time: 0.1258
INFO - 2023-11-19 15:34:27 --> Config Class Initialized
INFO - 2023-11-19 15:34:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:27 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:27 --> URI Class Initialized
INFO - 2023-11-19 15:34:27 --> Router Class Initialized
INFO - 2023-11-19 15:34:27 --> Output Class Initialized
INFO - 2023-11-19 15:34:27 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:27 --> Input Class Initialized
INFO - 2023-11-19 15:34:27 --> Language Class Initialized
INFO - 2023-11-19 15:34:27 --> Loader Class Initialized
INFO - 2023-11-19 15:34:27 --> Helper loaded: url_helper
INFO - 2023-11-19 15:34:27 --> Helper loaded: file_helper
INFO - 2023-11-19 15:34:27 --> Database Driver Class Initialized
INFO - 2023-11-19 15:34:27 --> Email Class Initialized
DEBUG - 2023-11-19 15:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:34:27 --> Controller Class Initialized
INFO - 2023-11-19 15:34:27 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:34:27 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:34:27 --> Model "Home_model" initialized
INFO - 2023-11-19 15:34:27 --> Helper loaded: download_helper
INFO - 2023-11-19 15:34:27 --> Helper loaded: form_helper
INFO - 2023-11-19 15:34:27 --> Form Validation Class Initialized
INFO - 2023-11-19 20:04:27 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:04:27 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:04:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:04:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:04:28 --> Final output sent to browser
DEBUG - 2023-11-19 20:04:28 --> Total execution time: 0.2872
INFO - 2023-11-19 15:34:30 --> Config Class Initialized
INFO - 2023-11-19 15:34:30 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:30 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:30 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:30 --> URI Class Initialized
INFO - 2023-11-19 15:34:30 --> Router Class Initialized
INFO - 2023-11-19 15:34:30 --> Output Class Initialized
INFO - 2023-11-19 15:34:30 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:30 --> Input Class Initialized
INFO - 2023-11-19 15:34:30 --> Language Class Initialized
ERROR - 2023-11-19 15:34:30 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:31 --> Config Class Initialized
INFO - 2023-11-19 15:34:31 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:31 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:31 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:31 --> URI Class Initialized
INFO - 2023-11-19 15:34:31 --> Router Class Initialized
INFO - 2023-11-19 15:34:31 --> Output Class Initialized
INFO - 2023-11-19 15:34:31 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:31 --> Input Class Initialized
INFO - 2023-11-19 15:34:31 --> Language Class Initialized
ERROR - 2023-11-19 15:34:31 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:35 --> Config Class Initialized
INFO - 2023-11-19 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:35 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:35 --> URI Class Initialized
INFO - 2023-11-19 15:34:35 --> Router Class Initialized
INFO - 2023-11-19 15:34:35 --> Output Class Initialized
INFO - 2023-11-19 15:34:35 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:35 --> Input Class Initialized
INFO - 2023-11-19 15:34:35 --> Language Class Initialized
ERROR - 2023-11-19 15:34:35 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:35 --> Config Class Initialized
INFO - 2023-11-19 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:35 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:35 --> URI Class Initialized
INFO - 2023-11-19 15:34:35 --> Router Class Initialized
INFO - 2023-11-19 15:34:35 --> Output Class Initialized
INFO - 2023-11-19 15:34:35 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:35 --> Input Class Initialized
INFO - 2023-11-19 15:34:35 --> Language Class Initialized
ERROR - 2023-11-19 15:34:35 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:35 --> Config Class Initialized
INFO - 2023-11-19 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:35 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:35 --> URI Class Initialized
INFO - 2023-11-19 15:34:35 --> Router Class Initialized
INFO - 2023-11-19 15:34:35 --> Output Class Initialized
INFO - 2023-11-19 15:34:35 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:35 --> Input Class Initialized
INFO - 2023-11-19 15:34:35 --> Language Class Initialized
ERROR - 2023-11-19 15:34:35 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:35 --> Config Class Initialized
INFO - 2023-11-19 15:34:35 --> Config Class Initialized
INFO - 2023-11-19 15:34:35 --> Hooks Class Initialized
INFO - 2023-11-19 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:35 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:35 --> URI Class Initialized
INFO - 2023-11-19 15:34:35 --> Router Class Initialized
INFO - 2023-11-19 15:34:35 --> Output Class Initialized
INFO - 2023-11-19 15:34:35 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:35 --> Input Class Initialized
INFO - 2023-11-19 15:34:35 --> Language Class Initialized
ERROR - 2023-11-19 15:34:35 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:35 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:35 --> URI Class Initialized
INFO - 2023-11-19 15:34:35 --> Router Class Initialized
INFO - 2023-11-19 15:34:35 --> Output Class Initialized
INFO - 2023-11-19 15:34:35 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:35 --> Input Class Initialized
INFO - 2023-11-19 15:34:35 --> Language Class Initialized
ERROR - 2023-11-19 15:34:35 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:44 --> Config Class Initialized
INFO - 2023-11-19 15:34:44 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:44 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:44 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:44 --> URI Class Initialized
INFO - 2023-11-19 15:34:44 --> Router Class Initialized
INFO - 2023-11-19 15:34:44 --> Output Class Initialized
INFO - 2023-11-19 15:34:44 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:44 --> Input Class Initialized
INFO - 2023-11-19 15:34:44 --> Language Class Initialized
INFO - 2023-11-19 15:34:44 --> Loader Class Initialized
INFO - 2023-11-19 15:34:44 --> Helper loaded: url_helper
INFO - 2023-11-19 15:34:44 --> Helper loaded: file_helper
INFO - 2023-11-19 15:34:44 --> Database Driver Class Initialized
INFO - 2023-11-19 15:34:44 --> Email Class Initialized
DEBUG - 2023-11-19 15:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:34:44 --> Controller Class Initialized
INFO - 2023-11-19 15:34:44 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:34:44 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:34:44 --> Model "Home_model" initialized
INFO - 2023-11-19 15:34:44 --> Helper loaded: download_helper
INFO - 2023-11-19 15:34:44 --> Helper loaded: form_helper
INFO - 2023-11-19 15:34:44 --> Form Validation Class Initialized
INFO - 2023-11-19 20:04:44 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:04:44 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:04:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:04:44 --> Final output sent to browser
DEBUG - 2023-11-19 20:04:44 --> Total execution time: 0.1627
INFO - 2023-11-19 15:34:45 --> Config Class Initialized
INFO - 2023-11-19 15:34:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:45 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:45 --> URI Class Initialized
INFO - 2023-11-19 15:34:45 --> Router Class Initialized
INFO - 2023-11-19 15:34:45 --> Output Class Initialized
INFO - 2023-11-19 15:34:45 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:45 --> Input Class Initialized
INFO - 2023-11-19 15:34:45 --> Language Class Initialized
ERROR - 2023-11-19 15:34:45 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:45 --> Config Class Initialized
INFO - 2023-11-19 15:34:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:45 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:45 --> URI Class Initialized
INFO - 2023-11-19 15:34:45 --> Router Class Initialized
INFO - 2023-11-19 15:34:45 --> Output Class Initialized
INFO - 2023-11-19 15:34:45 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:45 --> Config Class Initialized
INFO - 2023-11-19 15:34:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:45 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:45 --> URI Class Initialized
INFO - 2023-11-19 15:34:45 --> Router Class Initialized
INFO - 2023-11-19 15:34:45 --> Output Class Initialized
INFO - 2023-11-19 15:34:45 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
INFO - 2023-11-19 15:34:47 --> Config Class Initialized
INFO - 2023-11-19 15:34:47 --> Hooks Class Initialized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
INFO - 2023-11-19 15:34:47 --> Config Class Initialized
DEBUG - 2023-11-19 15:34:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
INFO - 2023-11-19 15:34:47 --> Hooks Class Initialized
INFO - 2023-11-19 15:34:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
INFO - 2023-11-19 15:34:47 --> URI Class Initialized
DEBUG - 2023-11-19 15:34:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:47 --> URI Class Initialized
INFO - 2023-11-19 15:34:47 --> Router Class Initialized
INFO - 2023-11-19 15:34:47 --> Output Class Initialized
INFO - 2023-11-19 15:34:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:47 --> Config Class Initialized
INFO - 2023-11-19 15:34:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:34:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:47 --> URI Class Initialized
INFO - 2023-11-19 15:34:47 --> Router Class Initialized
INFO - 2023-11-19 15:34:47 --> Output Class Initialized
INFO - 2023-11-19 15:34:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:47 --> Config Class Initialized
INFO - 2023-11-19 15:34:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:34:47 --> UTF-8 Support Enabled
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:34:47 --> Router Class Initialized
INFO - 2023-11-19 15:34:47 --> URI Class Initialized
INFO - 2023-11-19 15:34:47 --> Output Class Initialized
INFO - 2023-11-19 15:34:47 --> Router Class Initialized
INFO - 2023-11-19 15:34:47 --> Security Class Initialized
INFO - 2023-11-19 15:34:47 --> Output Class Initialized
DEBUG - 2023-11-19 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:47 --> Security Class Initialized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
DEBUG - 2023-11-19 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
INFO - 2023-11-19 15:34:47 --> Input Class Initialized
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:34:47 --> Language Class Initialized
ERROR - 2023-11-19 15:34:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:43:34 --> Config Class Initialized
INFO - 2023-11-19 15:43:34 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:43:34 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:43:34 --> Utf8 Class Initialized
INFO - 2023-11-19 15:43:34 --> URI Class Initialized
INFO - 2023-11-19 15:43:34 --> Router Class Initialized
INFO - 2023-11-19 15:43:34 --> Output Class Initialized
INFO - 2023-11-19 15:43:34 --> Security Class Initialized
DEBUG - 2023-11-19 15:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:43:34 --> Input Class Initialized
INFO - 2023-11-19 15:43:34 --> Language Class Initialized
INFO - 2023-11-19 15:43:34 --> Loader Class Initialized
INFO - 2023-11-19 15:43:34 --> Helper loaded: url_helper
INFO - 2023-11-19 15:43:34 --> Helper loaded: file_helper
INFO - 2023-11-19 15:43:34 --> Database Driver Class Initialized
INFO - 2023-11-19 15:43:34 --> Email Class Initialized
DEBUG - 2023-11-19 15:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:43:34 --> Controller Class Initialized
INFO - 2023-11-19 15:43:34 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:43:34 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:43:34 --> Model "Home_model" initialized
INFO - 2023-11-19 15:43:34 --> Helper loaded: download_helper
INFO - 2023-11-19 15:43:34 --> Helper loaded: form_helper
INFO - 2023-11-19 15:43:34 --> Form Validation Class Initialized
INFO - 2023-11-19 20:13:34 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:13:34 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:13:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:13:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:13:35 --> Final output sent to browser
DEBUG - 2023-11-19 20:13:35 --> Total execution time: 0.2691
INFO - 2023-11-19 15:43:36 --> Config Class Initialized
INFO - 2023-11-19 15:43:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:43:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:43:37 --> Utf8 Class Initialized
INFO - 2023-11-19 15:43:38 --> Config Class Initialized
INFO - 2023-11-19 15:43:38 --> Hooks Class Initialized
INFO - 2023-11-19 15:43:38 --> URI Class Initialized
DEBUG - 2023-11-19 15:43:38 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:43:38 --> Router Class Initialized
INFO - 2023-11-19 15:43:38 --> Utf8 Class Initialized
INFO - 2023-11-19 15:43:38 --> Output Class Initialized
INFO - 2023-11-19 15:43:38 --> URI Class Initialized
INFO - 2023-11-19 15:43:38 --> Security Class Initialized
INFO - 2023-11-19 15:43:38 --> Router Class Initialized
DEBUG - 2023-11-19 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:43:38 --> Output Class Initialized
INFO - 2023-11-19 15:43:38 --> Input Class Initialized
INFO - 2023-11-19 15:43:38 --> Security Class Initialized
INFO - 2023-11-19 15:43:38 --> Language Class Initialized
DEBUG - 2023-11-19 15:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-19 15:43:38 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:43:38 --> Input Class Initialized
INFO - 2023-11-19 15:43:38 --> Language Class Initialized
ERROR - 2023-11-19 15:43:38 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:43:40 --> Config Class Initialized
INFO - 2023-11-19 15:57:45 --> Config Class Initialized
INFO - 2023-11-19 15:57:45 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:45 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:45 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:45 --> URI Class Initialized
INFO - 2023-11-19 15:57:45 --> Router Class Initialized
INFO - 2023-11-19 15:57:45 --> Output Class Initialized
INFO - 2023-11-19 15:57:45 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:45 --> Input Class Initialized
INFO - 2023-11-19 15:57:45 --> Language Class Initialized
INFO - 2023-11-19 15:57:45 --> Loader Class Initialized
INFO - 2023-11-19 15:57:45 --> Helper loaded: url_helper
INFO - 2023-11-19 15:57:45 --> Helper loaded: file_helper
INFO - 2023-11-19 15:57:45 --> Database Driver Class Initialized
INFO - 2023-11-19 15:57:45 --> Email Class Initialized
DEBUG - 2023-11-19 15:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:57:45 --> Controller Class Initialized
INFO - 2023-11-19 15:57:45 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:57:45 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:57:45 --> Model "Home_model" initialized
INFO - 2023-11-19 15:57:45 --> Helper loaded: download_helper
INFO - 2023-11-19 15:57:45 --> Helper loaded: form_helper
INFO - 2023-11-19 15:57:45 --> Form Validation Class Initialized
INFO - 2023-11-19 20:27:45 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:27:45 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:27:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:27:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:27:45 --> Final output sent to browser
DEBUG - 2023-11-19 20:27:45 --> Total execution time: 0.2368
INFO - 2023-11-19 15:57:46 --> Config Class Initialized
INFO - 2023-11-19 15:57:46 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:46 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:46 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:46 --> URI Class Initialized
INFO - 2023-11-19 15:57:46 --> Router Class Initialized
INFO - 2023-11-19 15:57:46 --> Output Class Initialized
INFO - 2023-11-19 15:57:46 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:46 --> Input Class Initialized
INFO - 2023-11-19 15:57:46 --> Language Class Initialized
ERROR - 2023-11-19 15:57:46 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:47 --> Config Class Initialized
INFO - 2023-11-19 15:57:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:47 --> URI Class Initialized
INFO - 2023-11-19 15:57:47 --> Router Class Initialized
INFO - 2023-11-19 15:57:47 --> Output Class Initialized
INFO - 2023-11-19 15:57:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:47 --> Input Class Initialized
INFO - 2023-11-19 15:57:47 --> Language Class Initialized
ERROR - 2023-11-19 15:57:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:47 --> Config Class Initialized
INFO - 2023-11-19 15:57:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:47 --> URI Class Initialized
INFO - 2023-11-19 15:57:47 --> Router Class Initialized
INFO - 2023-11-19 15:57:47 --> Output Class Initialized
INFO - 2023-11-19 15:57:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:47 --> Input Class Initialized
INFO - 2023-11-19 15:57:47 --> Language Class Initialized
ERROR - 2023-11-19 15:57:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:47 --> Config Class Initialized
INFO - 2023-11-19 15:57:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:47 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:47 --> URI Class Initialized
INFO - 2023-11-19 15:57:47 --> Router Class Initialized
INFO - 2023-11-19 15:57:47 --> Output Class Initialized
INFO - 2023-11-19 15:57:47 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:47 --> Input Class Initialized
INFO - 2023-11-19 15:57:47 --> Language Class Initialized
ERROR - 2023-11-19 15:57:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:48 --> Config Class Initialized
INFO - 2023-11-19 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:48 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:48 --> URI Class Initialized
INFO - 2023-11-19 15:57:48 --> Router Class Initialized
INFO - 2023-11-19 15:57:48 --> Output Class Initialized
INFO - 2023-11-19 15:57:48 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:48 --> Input Class Initialized
INFO - 2023-11-19 15:57:48 --> Language Class Initialized
ERROR - 2023-11-19 15:57:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:48 --> Config Class Initialized
INFO - 2023-11-19 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:48 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:48 --> URI Class Initialized
INFO - 2023-11-19 15:57:48 --> Router Class Initialized
INFO - 2023-11-19 15:57:48 --> Output Class Initialized
INFO - 2023-11-19 15:57:48 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:48 --> Input Class Initialized
INFO - 2023-11-19 15:57:48 --> Language Class Initialized
ERROR - 2023-11-19 15:57:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:57:48 --> Config Class Initialized
INFO - 2023-11-19 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:57:48 --> Utf8 Class Initialized
INFO - 2023-11-19 15:57:48 --> URI Class Initialized
INFO - 2023-11-19 15:57:48 --> Router Class Initialized
INFO - 2023-11-19 15:57:48 --> Output Class Initialized
INFO - 2023-11-19 15:57:48 --> Security Class Initialized
DEBUG - 2023-11-19 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:57:48 --> Input Class Initialized
INFO - 2023-11-19 15:57:48 --> Language Class Initialized
ERROR - 2023-11-19 15:57:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:58:34 --> Config Class Initialized
INFO - 2023-11-19 15:58:34 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:34 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:34 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:34 --> URI Class Initialized
INFO - 2023-11-19 15:58:34 --> Router Class Initialized
INFO - 2023-11-19 15:58:34 --> Output Class Initialized
INFO - 2023-11-19 15:58:34 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:34 --> Input Class Initialized
INFO - 2023-11-19 15:58:34 --> Language Class Initialized
INFO - 2023-11-19 15:58:34 --> Loader Class Initialized
INFO - 2023-11-19 15:58:34 --> Helper loaded: url_helper
INFO - 2023-11-19 15:58:34 --> Helper loaded: file_helper
INFO - 2023-11-19 15:58:34 --> Database Driver Class Initialized
INFO - 2023-11-19 15:58:34 --> Email Class Initialized
DEBUG - 2023-11-19 15:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:58:34 --> Controller Class Initialized
INFO - 2023-11-19 15:58:34 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:58:34 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:58:34 --> Model "Home_model" initialized
INFO - 2023-11-19 15:58:34 --> Helper loaded: download_helper
INFO - 2023-11-19 15:58:34 --> Helper loaded: form_helper
INFO - 2023-11-19 15:58:34 --> Form Validation Class Initialized
INFO - 2023-11-19 20:28:34 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:28:34 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:28:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:28:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:28:34 --> Final output sent to browser
DEBUG - 2023-11-19 20:28:34 --> Total execution time: 0.2525
INFO - 2023-11-19 15:58:37 --> Config Class Initialized
INFO - 2023-11-19 15:58:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:37 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:37 --> URI Class Initialized
INFO - 2023-11-19 15:58:37 --> Router Class Initialized
INFO - 2023-11-19 15:58:37 --> Output Class Initialized
INFO - 2023-11-19 15:58:37 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:37 --> Input Class Initialized
INFO - 2023-11-19 15:58:37 --> Language Class Initialized
ERROR - 2023-11-19 15:58:37 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:58:37 --> Config Class Initialized
INFO - 2023-11-19 15:58:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:37 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:37 --> URI Class Initialized
INFO - 2023-11-19 15:58:37 --> Router Class Initialized
INFO - 2023-11-19 15:58:37 --> Output Class Initialized
INFO - 2023-11-19 15:58:37 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:37 --> Input Class Initialized
INFO - 2023-11-19 15:58:37 --> Language Class Initialized
ERROR - 2023-11-19 15:58:37 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:58:39 --> Config Class Initialized
INFO - 2023-11-19 15:58:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:39 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:39 --> URI Class Initialized
INFO - 2023-11-19 15:58:39 --> Router Class Initialized
INFO - 2023-11-19 15:58:39 --> Output Class Initialized
INFO - 2023-11-19 15:58:39 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:39 --> Input Class Initialized
INFO - 2023-11-19 15:58:39 --> Language Class Initialized
ERROR - 2023-11-19 15:58:39 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:58:39 --> Config Class Initialized
INFO - 2023-11-19 15:58:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:39 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:39 --> URI Class Initialized
INFO - 2023-11-19 15:58:39 --> Router Class Initialized
INFO - 2023-11-19 15:58:39 --> Output Class Initialized
INFO - 2023-11-19 15:58:39 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:39 --> Input Class Initialized
INFO - 2023-11-19 15:58:39 --> Language Class Initialized
ERROR - 2023-11-19 15:58:39 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:58:39 --> Config Class Initialized
INFO - 2023-11-19 15:58:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:58:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:58:39 --> Utf8 Class Initialized
INFO - 2023-11-19 15:58:39 --> URI Class Initialized
INFO - 2023-11-19 15:58:39 --> Router Class Initialized
INFO - 2023-11-19 15:58:39 --> Output Class Initialized
INFO - 2023-11-19 15:58:39 --> Security Class Initialized
DEBUG - 2023-11-19 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:58:39 --> Input Class Initialized
INFO - 2023-11-19 15:58:39 --> Language Class Initialized
ERROR - 2023-11-19 15:58:39 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:59:12 --> Config Class Initialized
INFO - 2023-11-19 15:59:12 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:59:12 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:59:12 --> Utf8 Class Initialized
INFO - 2023-11-19 15:59:12 --> URI Class Initialized
INFO - 2023-11-19 15:59:12 --> Router Class Initialized
INFO - 2023-11-19 15:59:12 --> Output Class Initialized
INFO - 2023-11-19 15:59:12 --> Security Class Initialized
DEBUG - 2023-11-19 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:59:12 --> Input Class Initialized
INFO - 2023-11-19 15:59:12 --> Language Class Initialized
INFO - 2023-11-19 15:59:12 --> Loader Class Initialized
INFO - 2023-11-19 15:59:12 --> Helper loaded: url_helper
INFO - 2023-11-19 15:59:12 --> Helper loaded: file_helper
INFO - 2023-11-19 15:59:12 --> Database Driver Class Initialized
INFO - 2023-11-19 15:59:12 --> Email Class Initialized
DEBUG - 2023-11-19 15:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:59:12 --> Controller Class Initialized
INFO - 2023-11-19 15:59:12 --> Model "Contact_model" initialized
INFO - 2023-11-19 15:59:12 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 15:59:12 --> Model "Home_model" initialized
INFO - 2023-11-19 15:59:12 --> Helper loaded: download_helper
INFO - 2023-11-19 15:59:12 --> Helper loaded: form_helper
INFO - 2023-11-19 15:59:12 --> Form Validation Class Initialized
INFO - 2023-11-19 20:29:12 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:29:12 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:29:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:29:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:29:12 --> Final output sent to browser
DEBUG - 2023-11-19 20:29:12 --> Total execution time: 0.2654
INFO - 2023-11-19 15:59:14 --> Config Class Initialized
INFO - 2023-11-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:59:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:59:14 --> Utf8 Class Initialized
INFO - 2023-11-19 15:59:14 --> URI Class Initialized
INFO - 2023-11-19 15:59:14 --> Router Class Initialized
INFO - 2023-11-19 15:59:14 --> Output Class Initialized
INFO - 2023-11-19 15:59:14 --> Security Class Initialized
DEBUG - 2023-11-19 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:59:14 --> Input Class Initialized
INFO - 2023-11-19 15:59:14 --> Language Class Initialized
ERROR - 2023-11-19 15:59:14 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 15:59:14 --> Config Class Initialized
INFO - 2023-11-19 15:59:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:59:17 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:59:17 --> Utf8 Class Initialized
INFO - 2023-11-19 16:03:18 --> Config Class Initialized
INFO - 2023-11-19 16:03:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:03:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:03:18 --> Utf8 Class Initialized
INFO - 2023-11-19 16:03:18 --> URI Class Initialized
INFO - 2023-11-19 16:03:18 --> Router Class Initialized
INFO - 2023-11-19 16:03:18 --> Output Class Initialized
INFO - 2023-11-19 16:03:18 --> Security Class Initialized
DEBUG - 2023-11-19 16:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:03:18 --> Input Class Initialized
INFO - 2023-11-19 16:03:18 --> Language Class Initialized
INFO - 2023-11-19 16:03:18 --> Loader Class Initialized
INFO - 2023-11-19 16:03:18 --> Helper loaded: url_helper
INFO - 2023-11-19 16:03:18 --> Helper loaded: file_helper
INFO - 2023-11-19 16:03:18 --> Database Driver Class Initialized
INFO - 2023-11-19 16:03:18 --> Email Class Initialized
DEBUG - 2023-11-19 16:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:03:18 --> Controller Class Initialized
INFO - 2023-11-19 16:03:18 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:03:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:03:18 --> Model "Home_model" initialized
INFO - 2023-11-19 16:03:18 --> Helper loaded: download_helper
INFO - 2023-11-19 16:03:18 --> Helper loaded: form_helper
INFO - 2023-11-19 16:03:18 --> Form Validation Class Initialized
INFO - 2023-11-19 20:33:18 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:33:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:33:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:33:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:33:19 --> Final output sent to browser
DEBUG - 2023-11-19 20:33:19 --> Total execution time: 0.2687
INFO - 2023-11-19 16:03:23 --> Config Class Initialized
INFO - 2023-11-19 16:03:24 --> Config Class Initialized
INFO - 2023-11-19 16:03:24 --> Config Class Initialized
INFO - 2023-11-19 16:03:24 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:03:24 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:03:24 --> Utf8 Class Initialized
INFO - 2023-11-19 16:03:24 --> URI Class Initialized
INFO - 2023-11-19 16:03:24 --> Router Class Initialized
INFO - 2023-11-19 16:03:24 --> Output Class Initialized
INFO - 2023-11-19 16:03:24 --> Security Class Initialized
DEBUG - 2023-11-19 16:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:03:24 --> Input Class Initialized
INFO - 2023-11-19 16:03:24 --> Language Class Initialized
ERROR - 2023-11-19 16:03:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:06:07 --> Config Class Initialized
INFO - 2023-11-19 16:06:07 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:07 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:07 --> Utf8 Class Initialized
INFO - 2023-11-19 16:06:07 --> URI Class Initialized
INFO - 2023-11-19 16:06:07 --> Router Class Initialized
INFO - 2023-11-19 16:06:07 --> Output Class Initialized
INFO - 2023-11-19 16:06:07 --> Security Class Initialized
DEBUG - 2023-11-19 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:06:07 --> Input Class Initialized
INFO - 2023-11-19 16:06:07 --> Language Class Initialized
INFO - 2023-11-19 16:06:07 --> Loader Class Initialized
INFO - 2023-11-19 16:06:07 --> Helper loaded: url_helper
INFO - 2023-11-19 16:06:07 --> Helper loaded: file_helper
INFO - 2023-11-19 16:06:07 --> Database Driver Class Initialized
INFO - 2023-11-19 16:06:07 --> Email Class Initialized
DEBUG - 2023-11-19 16:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:06:07 --> Controller Class Initialized
INFO - 2023-11-19 16:06:07 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:06:07 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:06:07 --> Model "Home_model" initialized
INFO - 2023-11-19 16:06:07 --> Helper loaded: download_helper
INFO - 2023-11-19 16:06:07 --> Helper loaded: form_helper
INFO - 2023-11-19 16:06:07 --> Form Validation Class Initialized
INFO - 2023-11-19 20:36:07 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:36:07 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:36:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:36:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:36:07 --> Final output sent to browser
DEBUG - 2023-11-19 20:36:07 --> Total execution time: 0.2844
INFO - 2023-11-19 16:06:08 --> Config Class Initialized
INFO - 2023-11-19 16:06:08 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:08 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:08 --> Utf8 Class Initialized
INFO - 2023-11-19 16:06:08 --> URI Class Initialized
INFO - 2023-11-19 16:06:08 --> Router Class Initialized
INFO - 2023-11-19 16:06:08 --> Output Class Initialized
INFO - 2023-11-19 16:06:08 --> Security Class Initialized
DEBUG - 2023-11-19 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:06:08 --> Input Class Initialized
INFO - 2023-11-19 16:06:08 --> Language Class Initialized
ERROR - 2023-11-19 16:06:08 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:06:09 --> Config Class Initialized
INFO - 2023-11-19 16:06:09 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:09 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:09 --> Utf8 Class Initialized
INFO - 2023-11-19 16:06:10 --> Config Class Initialized
INFO - 2023-11-19 16:06:10 --> Config Class Initialized
INFO - 2023-11-19 16:06:10 --> Hooks Class Initialized
INFO - 2023-11-19 16:06:12 --> Config Class Initialized
INFO - 2023-11-19 16:06:12 --> Config Class Initialized
INFO - 2023-11-19 16:06:12 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:12 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:12 --> Utf8 Class Initialized
INFO - 2023-11-19 16:06:12 --> URI Class Initialized
INFO - 2023-11-19 16:06:12 --> Router Class Initialized
INFO - 2023-11-19 16:06:12 --> Output Class Initialized
INFO - 2023-11-19 16:06:12 --> Security Class Initialized
DEBUG - 2023-11-19 16:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:06:12 --> Input Class Initialized
INFO - 2023-11-19 16:06:12 --> Language Class Initialized
ERROR - 2023-11-19 16:06:12 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:06:12 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:12 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:06:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:06:13 --> Utf8 Class Initialized
INFO - 2023-11-19 16:06:13 --> URI Class Initialized
INFO - 2023-11-19 16:06:13 --> Router Class Initialized
INFO - 2023-11-19 16:06:13 --> Output Class Initialized
INFO - 2023-11-19 16:06:13 --> Security Class Initialized
DEBUG - 2023-11-19 16:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:06:13 --> Input Class Initialized
INFO - 2023-11-19 16:06:13 --> Language Class Initialized
ERROR - 2023-11-19 16:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:11:54 --> Config Class Initialized
INFO - 2023-11-19 16:11:54 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:11:54 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:11:54 --> Utf8 Class Initialized
INFO - 2023-11-19 16:11:54 --> URI Class Initialized
INFO - 2023-11-19 16:11:54 --> Router Class Initialized
INFO - 2023-11-19 16:11:54 --> Output Class Initialized
INFO - 2023-11-19 16:11:54 --> Security Class Initialized
DEBUG - 2023-11-19 16:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:11:54 --> Input Class Initialized
INFO - 2023-11-19 16:11:54 --> Language Class Initialized
INFO - 2023-11-19 16:11:54 --> Loader Class Initialized
INFO - 2023-11-19 16:11:54 --> Helper loaded: url_helper
INFO - 2023-11-19 16:11:54 --> Helper loaded: file_helper
INFO - 2023-11-19 16:11:54 --> Database Driver Class Initialized
INFO - 2023-11-19 16:11:54 --> Email Class Initialized
DEBUG - 2023-11-19 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:11:54 --> Controller Class Initialized
INFO - 2023-11-19 16:11:54 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:11:54 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:11:54 --> Model "Home_model" initialized
INFO - 2023-11-19 16:11:54 --> Helper loaded: download_helper
INFO - 2023-11-19 16:11:54 --> Helper loaded: form_helper
INFO - 2023-11-19 16:11:54 --> Form Validation Class Initialized
INFO - 2023-11-19 20:41:54 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:41:54 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:41:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:41:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:41:54 --> Final output sent to browser
DEBUG - 2023-11-19 20:41:54 --> Total execution time: 0.2680
INFO - 2023-11-19 16:11:56 --> Config Class Initialized
INFO - 2023-11-19 16:11:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:11:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:11:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:11:56 --> URI Class Initialized
INFO - 2023-11-19 16:11:56 --> Router Class Initialized
INFO - 2023-11-19 16:11:56 --> Output Class Initialized
INFO - 2023-11-19 16:11:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:11:56 --> Config Class Initialized
INFO - 2023-11-19 16:11:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:11:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:11:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:11:56 --> URI Class Initialized
INFO - 2023-11-19 16:11:56 --> Router Class Initialized
INFO - 2023-11-19 16:11:56 --> Output Class Initialized
INFO - 2023-11-19 16:11:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:11:56 --> Input Class Initialized
INFO - 2023-11-19 16:11:56 --> Language Class Initialized
ERROR - 2023-11-19 16:11:56 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:11:56 --> Input Class Initialized
INFO - 2023-11-19 16:11:57 --> Language Class Initialized
ERROR - 2023-11-19 16:11:57 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:11:57 --> Config Class Initialized
INFO - 2023-11-19 16:11:57 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:11:57 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:11:57 --> Config Class Initialized
INFO - 2023-11-19 16:11:57 --> Utf8 Class Initialized
INFO - 2023-11-19 16:11:57 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:11:57 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:11:57 --> URI Class Initialized
INFO - 2023-11-19 16:11:57 --> Utf8 Class Initialized
INFO - 2023-11-19 16:11:57 --> Router Class Initialized
INFO - 2023-11-19 16:13:33 --> Config Class Initialized
INFO - 2023-11-19 16:13:33 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:33 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:33 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:33 --> URI Class Initialized
INFO - 2023-11-19 16:13:33 --> Router Class Initialized
INFO - 2023-11-19 16:13:33 --> Output Class Initialized
INFO - 2023-11-19 16:13:33 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:33 --> Input Class Initialized
INFO - 2023-11-19 16:13:33 --> Language Class Initialized
INFO - 2023-11-19 16:13:33 --> Loader Class Initialized
INFO - 2023-11-19 16:13:33 --> Helper loaded: url_helper
INFO - 2023-11-19 16:13:33 --> Helper loaded: file_helper
INFO - 2023-11-19 16:13:33 --> Database Driver Class Initialized
INFO - 2023-11-19 16:13:33 --> Email Class Initialized
DEBUG - 2023-11-19 16:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:13:33 --> Controller Class Initialized
INFO - 2023-11-19 16:13:33 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:13:33 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:13:33 --> Model "Home_model" initialized
INFO - 2023-11-19 16:13:33 --> Helper loaded: download_helper
INFO - 2023-11-19 16:13:33 --> Helper loaded: form_helper
INFO - 2023-11-19 16:13:33 --> Form Validation Class Initialized
INFO - 2023-11-19 20:43:33 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:43:33 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:43:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:43:33 --> Final output sent to browser
DEBUG - 2023-11-19 20:43:33 --> Total execution time: 0.2984
INFO - 2023-11-19 16:13:34 --> Config Class Initialized
INFO - 2023-11-19 16:13:34 --> Hooks Class Initialized
INFO - 2023-11-19 16:13:34 --> Config Class Initialized
INFO - 2023-11-19 16:13:34 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:34 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:34 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:34 --> URI Class Initialized
INFO - 2023-11-19 16:13:34 --> Router Class Initialized
INFO - 2023-11-19 16:13:34 --> Output Class Initialized
INFO - 2023-11-19 16:13:34 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 16:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:35 --> Input Class Initialized
INFO - 2023-11-19 16:13:35 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:35 --> Language Class Initialized
ERROR - 2023-11-19 16:13:35 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:35 --> URI Class Initialized
INFO - 2023-11-19 16:13:35 --> Router Class Initialized
INFO - 2023-11-19 16:13:35 --> Output Class Initialized
INFO - 2023-11-19 16:13:36 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:36 --> Input Class Initialized
INFO - 2023-11-19 16:13:36 --> Language Class Initialized
ERROR - 2023-11-19 16:13:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:37 --> Config Class Initialized
INFO - 2023-11-19 16:13:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:37 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:37 --> URI Class Initialized
INFO - 2023-11-19 16:13:37 --> Router Class Initialized
INFO - 2023-11-19 16:13:37 --> Output Class Initialized
INFO - 2023-11-19 16:13:37 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:37 --> Input Class Initialized
INFO - 2023-11-19 16:13:37 --> Language Class Initialized
ERROR - 2023-11-19 16:13:37 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:37 --> Config Class Initialized
INFO - 2023-11-19 16:13:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:37 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:37 --> URI Class Initialized
INFO - 2023-11-19 16:13:37 --> Router Class Initialized
INFO - 2023-11-19 16:13:37 --> Output Class Initialized
INFO - 2023-11-19 16:13:37 --> Security Class Initialized
INFO - 2023-11-19 16:13:39 --> Config Class Initialized
INFO - 2023-11-19 16:13:39 --> Config Class Initialized
INFO - 2023-11-19 16:13:39 --> Hooks Class Initialized
INFO - 2023-11-19 16:13:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 16:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:39 --> Input Class Initialized
INFO - 2023-11-19 16:13:39 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:39 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:39 --> Config Class Initialized
INFO - 2023-11-19 16:13:39 --> URI Class Initialized
INFO - 2023-11-19 16:13:39 --> Hooks Class Initialized
INFO - 2023-11-19 16:13:39 --> Language Class Initialized
INFO - 2023-11-19 16:13:39 --> URI Class Initialized
ERROR - 2023-11-19 16:13:39 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:39 --> Router Class Initialized
INFO - 2023-11-19 16:13:39 --> Output Class Initialized
INFO - 2023-11-19 16:13:39 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:39 --> Input Class Initialized
INFO - 2023-11-19 16:13:39 --> Language Class Initialized
ERROR - 2023-11-19 16:13:39 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 16:13:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:39 --> Router Class Initialized
INFO - 2023-11-19 16:13:39 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:39 --> Output Class Initialized
INFO - 2023-11-19 16:13:39 --> URI Class Initialized
INFO - 2023-11-19 16:13:39 --> Security Class Initialized
INFO - 2023-11-19 16:13:39 --> Router Class Initialized
DEBUG - 2023-11-19 16:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:39 --> Output Class Initialized
INFO - 2023-11-19 16:13:39 --> Input Class Initialized
INFO - 2023-11-19 16:13:40 --> Security Class Initialized
INFO - 2023-11-19 16:13:40 --> Language Class Initialized
DEBUG - 2023-11-19 16:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-19 16:13:40 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:40 --> Input Class Initialized
INFO - 2023-11-19 16:13:40 --> Language Class Initialized
ERROR - 2023-11-19 16:13:40 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:13:42 --> Config Class Initialized
INFO - 2023-11-19 16:13:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:13:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:13:42 --> Utf8 Class Initialized
INFO - 2023-11-19 16:13:42 --> URI Class Initialized
INFO - 2023-11-19 16:13:42 --> Router Class Initialized
INFO - 2023-11-19 16:13:42 --> Output Class Initialized
INFO - 2023-11-19 16:13:42 --> Security Class Initialized
DEBUG - 2023-11-19 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:13:42 --> Input Class Initialized
INFO - 2023-11-19 16:13:42 --> Language Class Initialized
INFO - 2023-11-19 16:13:42 --> Loader Class Initialized
INFO - 2023-11-19 16:13:42 --> Helper loaded: url_helper
INFO - 2023-11-19 16:13:42 --> Helper loaded: file_helper
INFO - 2023-11-19 16:13:42 --> Database Driver Class Initialized
INFO - 2023-11-19 16:13:42 --> Email Class Initialized
DEBUG - 2023-11-19 16:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:13:42 --> Controller Class Initialized
INFO - 2023-11-19 16:13:42 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:13:42 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:13:42 --> Model "Home_model" initialized
INFO - 2023-11-19 16:13:42 --> Helper loaded: download_helper
INFO - 2023-11-19 16:13:42 --> Helper loaded: form_helper
INFO - 2023-11-19 16:13:42 --> Form Validation Class Initialized
INFO - 2023-11-19 20:43:42 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:43:42 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:43:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:43:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:43:42 --> Final output sent to browser
DEBUG - 2023-11-19 20:43:42 --> Total execution time: 0.1539
INFO - 2023-11-19 16:16:53 --> Config Class Initialized
INFO - 2023-11-19 16:16:53 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:53 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:53 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:53 --> URI Class Initialized
INFO - 2023-11-19 16:16:53 --> Router Class Initialized
INFO - 2023-11-19 16:16:53 --> Output Class Initialized
INFO - 2023-11-19 16:16:53 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:53 --> Input Class Initialized
INFO - 2023-11-19 16:16:53 --> Language Class Initialized
INFO - 2023-11-19 16:16:53 --> Loader Class Initialized
INFO - 2023-11-19 16:16:53 --> Helper loaded: url_helper
INFO - 2023-11-19 16:16:53 --> Helper loaded: file_helper
INFO - 2023-11-19 16:16:53 --> Database Driver Class Initialized
INFO - 2023-11-19 16:16:53 --> Email Class Initialized
DEBUG - 2023-11-19 16:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:16:53 --> Controller Class Initialized
INFO - 2023-11-19 16:16:53 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:16:53 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:16:53 --> Model "Home_model" initialized
INFO - 2023-11-19 16:16:53 --> Helper loaded: download_helper
INFO - 2023-11-19 16:16:53 --> Helper loaded: form_helper
INFO - 2023-11-19 16:16:53 --> Form Validation Class Initialized
INFO - 2023-11-19 20:46:53 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:46:53 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:46:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:46:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:46:53 --> Final output sent to browser
DEBUG - 2023-11-19 20:46:53 --> Total execution time: 0.2573
INFO - 2023-11-19 16:16:55 --> Config Class Initialized
INFO - 2023-11-19 16:16:55 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:55 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:55 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:55 --> URI Class Initialized
INFO - 2023-11-19 16:16:55 --> Router Class Initialized
INFO - 2023-11-19 16:16:55 --> Output Class Initialized
INFO - 2023-11-19 16:16:55 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:55 --> Input Class Initialized
INFO - 2023-11-19 16:16:55 --> Language Class Initialized
ERROR - 2023-11-19 16:16:55 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:55 --> Config Class Initialized
INFO - 2023-11-19 16:16:55 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:55 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:55 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:55 --> URI Class Initialized
INFO - 2023-11-19 16:16:55 --> Router Class Initialized
INFO - 2023-11-19 16:16:55 --> Output Class Initialized
INFO - 2023-11-19 16:16:55 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:55 --> Input Class Initialized
INFO - 2023-11-19 16:16:55 --> Language Class Initialized
ERROR - 2023-11-19 16:16:55 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:55 --> Config Class Initialized
INFO - 2023-11-19 16:16:56 --> Config Class Initialized
INFO - 2023-11-19 16:16:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:56 --> URI Class Initialized
INFO - 2023-11-19 16:16:56 --> Router Class Initialized
INFO - 2023-11-19 16:16:56 --> Output Class Initialized
INFO - 2023-11-19 16:16:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:56 --> Input Class Initialized
INFO - 2023-11-19 16:16:56 --> Language Class Initialized
ERROR - 2023-11-19 16:16:56 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:56 --> Config Class Initialized
INFO - 2023-11-19 16:16:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:56 --> URI Class Initialized
INFO - 2023-11-19 16:16:56 --> Router Class Initialized
INFO - 2023-11-19 16:16:56 --> Output Class Initialized
INFO - 2023-11-19 16:16:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:56 --> Input Class Initialized
INFO - 2023-11-19 16:16:56 --> Language Class Initialized
ERROR - 2023-11-19 16:16:56 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:56 --> URI Class Initialized
INFO - 2023-11-19 16:16:56 --> Router Class Initialized
INFO - 2023-11-19 16:16:56 --> Output Class Initialized
INFO - 2023-11-19 16:16:56 --> Config Class Initialized
INFO - 2023-11-19 16:16:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:56 --> URI Class Initialized
INFO - 2023-11-19 16:16:56 --> Router Class Initialized
INFO - 2023-11-19 16:16:56 --> Output Class Initialized
INFO - 2023-11-19 16:16:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:56 --> Input Class Initialized
INFO - 2023-11-19 16:16:56 --> Language Class Initialized
ERROR - 2023-11-19 16:16:56 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:56 --> Input Class Initialized
INFO - 2023-11-19 16:16:56 --> Language Class Initialized
INFO - 2023-11-19 16:16:56 --> Config Class Initialized
INFO - 2023-11-19 16:16:56 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:16:56 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:16:56 --> Utf8 Class Initialized
INFO - 2023-11-19 16:16:56 --> URI Class Initialized
INFO - 2023-11-19 16:16:56 --> Router Class Initialized
ERROR - 2023-11-19 16:16:56 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:16:56 --> Output Class Initialized
INFO - 2023-11-19 16:16:56 --> Security Class Initialized
DEBUG - 2023-11-19 16:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:16:58 --> Input Class Initialized
INFO - 2023-11-19 16:16:58 --> Language Class Initialized
ERROR - 2023-11-19 16:16:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:07 --> Config Class Initialized
INFO - 2023-11-19 16:18:07 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:07 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:07 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:07 --> URI Class Initialized
INFO - 2023-11-19 16:18:07 --> Router Class Initialized
INFO - 2023-11-19 16:18:07 --> Output Class Initialized
INFO - 2023-11-19 16:18:07 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:07 --> Input Class Initialized
INFO - 2023-11-19 16:18:07 --> Language Class Initialized
INFO - 2023-11-19 16:18:07 --> Loader Class Initialized
INFO - 2023-11-19 16:18:07 --> Helper loaded: url_helper
INFO - 2023-11-19 16:18:07 --> Helper loaded: file_helper
INFO - 2023-11-19 16:18:07 --> Database Driver Class Initialized
INFO - 2023-11-19 16:18:07 --> Email Class Initialized
DEBUG - 2023-11-19 16:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:18:07 --> Controller Class Initialized
INFO - 2023-11-19 16:18:07 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:18:07 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:18:07 --> Model "Home_model" initialized
INFO - 2023-11-19 16:18:08 --> Helper loaded: download_helper
INFO - 2023-11-19 16:18:08 --> Helper loaded: form_helper
INFO - 2023-11-19 16:18:08 --> Form Validation Class Initialized
INFO - 2023-11-19 20:48:08 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:48:08 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:48:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:48:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:48:08 --> Final output sent to browser
DEBUG - 2023-11-19 20:48:08 --> Total execution time: 0.2679
INFO - 2023-11-19 16:18:10 --> Config Class Initialized
INFO - 2023-11-19 16:18:10 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:10 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:10 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:10 --> URI Class Initialized
INFO - 2023-11-19 16:18:10 --> Router Class Initialized
INFO - 2023-11-19 16:18:10 --> Output Class Initialized
INFO - 2023-11-19 16:18:10 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:10 --> Input Class Initialized
INFO - 2023-11-19 16:18:10 --> Language Class Initialized
ERROR - 2023-11-19 16:18:10 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:10 --> Config Class Initialized
INFO - 2023-11-19 16:18:10 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:10 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:10 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:11 --> URI Class Initialized
INFO - 2023-11-19 16:18:11 --> Router Class Initialized
INFO - 2023-11-19 16:18:11 --> Output Class Initialized
INFO - 2023-11-19 16:18:11 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:11 --> Input Class Initialized
INFO - 2023-11-19 16:18:11 --> Language Class Initialized
ERROR - 2023-11-19 16:18:11 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:11 --> Config Class Initialized
INFO - 2023-11-19 16:18:12 --> Hooks Class Initialized
INFO - 2023-11-19 16:18:12 --> Config Class Initialized
INFO - 2023-11-19 16:18:12 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:13 --> Config Class Initialized
INFO - 2023-11-19 16:18:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:13 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:13 --> URI Class Initialized
INFO - 2023-11-19 16:18:13 --> Router Class Initialized
INFO - 2023-11-19 16:18:13 --> Output Class Initialized
INFO - 2023-11-19 16:18:13 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:13 --> Input Class Initialized
INFO - 2023-11-19 16:18:13 --> Language Class Initialized
ERROR - 2023-11-19 16:18:13 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:15 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:15 --> URI Class Initialized
DEBUG - 2023-11-19 16:18:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:15 --> Config Class Initialized
INFO - 2023-11-19 16:18:15 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:15 --> Hooks Class Initialized
INFO - 2023-11-19 16:18:15 --> URI Class Initialized
INFO - 2023-11-19 16:18:15 --> Config Class Initialized
INFO - 2023-11-19 16:18:15 --> Router Class Initialized
INFO - 2023-11-19 16:18:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:15 --> Router Class Initialized
INFO - 2023-11-19 16:18:15 --> Output Class Initialized
INFO - 2023-11-19 16:18:15 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:15 --> Output Class Initialized
DEBUG - 2023-11-19 16:18:16 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:16 --> Security Class Initialized
INFO - 2023-11-19 16:18:16 --> URI Class Initialized
INFO - 2023-11-19 16:18:16 --> Security Class Initialized
INFO - 2023-11-19 16:18:16 --> Utf8 Class Initialized
DEBUG - 2023-11-19 16:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:16 --> Input Class Initialized
INFO - 2023-11-19 16:18:16 --> Language Class Initialized
ERROR - 2023-11-19 16:18:16 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 16:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:16 --> URI Class Initialized
INFO - 2023-11-19 16:18:16 --> Router Class Initialized
INFO - 2023-11-19 16:18:16 --> Router Class Initialized
INFO - 2023-11-19 16:18:16 --> Input Class Initialized
INFO - 2023-11-19 16:18:16 --> Output Class Initialized
INFO - 2023-11-19 16:18:16 --> Output Class Initialized
INFO - 2023-11-19 16:18:16 --> Language Class Initialized
INFO - 2023-11-19 16:18:16 --> Security Class Initialized
INFO - 2023-11-19 16:18:16 --> Security Class Initialized
ERROR - 2023-11-19 16:18:16 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-19 16:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-19 16:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:16 --> Input Class Initialized
INFO - 2023-11-19 16:18:16 --> Language Class Initialized
ERROR - 2023-11-19 16:18:16 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:16 --> Input Class Initialized
INFO - 2023-11-19 16:18:16 --> Language Class Initialized
ERROR - 2023-11-19 16:18:16 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:42 --> Config Class Initialized
INFO - 2023-11-19 16:18:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:42 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:42 --> URI Class Initialized
INFO - 2023-11-19 16:18:42 --> Router Class Initialized
INFO - 2023-11-19 16:18:42 --> Output Class Initialized
INFO - 2023-11-19 16:18:42 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:42 --> Input Class Initialized
INFO - 2023-11-19 16:18:42 --> Language Class Initialized
INFO - 2023-11-19 16:18:42 --> Loader Class Initialized
INFO - 2023-11-19 16:18:42 --> Helper loaded: url_helper
INFO - 2023-11-19 16:18:42 --> Helper loaded: file_helper
INFO - 2023-11-19 16:18:42 --> Database Driver Class Initialized
INFO - 2023-11-19 16:18:42 --> Email Class Initialized
DEBUG - 2023-11-19 16:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:18:42 --> Controller Class Initialized
INFO - 2023-11-19 16:18:42 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:18:42 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:18:42 --> Model "Home_model" initialized
INFO - 2023-11-19 16:18:42 --> Helper loaded: download_helper
INFO - 2023-11-19 16:18:42 --> Helper loaded: form_helper
INFO - 2023-11-19 16:18:42 --> Form Validation Class Initialized
INFO - 2023-11-19 20:48:42 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:48:42 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:48:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:48:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:48:43 --> Final output sent to browser
DEBUG - 2023-11-19 20:48:43 --> Total execution time: 0.2979
INFO - 2023-11-19 16:18:44 --> Config Class Initialized
INFO - 2023-11-19 16:18:44 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:44 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:44 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:44 --> URI Class Initialized
INFO - 2023-11-19 16:18:44 --> Router Class Initialized
INFO - 2023-11-19 16:18:44 --> Output Class Initialized
INFO - 2023-11-19 16:18:44 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:44 --> Input Class Initialized
INFO - 2023-11-19 16:18:44 --> Language Class Initialized
ERROR - 2023-11-19 16:18:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:46 --> Config Class Initialized
INFO - 2023-11-19 16:18:46 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:46 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:46 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:46 --> URI Class Initialized
INFO - 2023-11-19 16:18:46 --> Router Class Initialized
INFO - 2023-11-19 16:18:46 --> Output Class Initialized
INFO - 2023-11-19 16:18:46 --> Security Class Initialized
INFO - 2023-11-19 16:18:47 --> Config Class Initialized
INFO - 2023-11-19 16:18:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:47 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:47 --> URI Class Initialized
INFO - 2023-11-19 16:18:47 --> Router Class Initialized
INFO - 2023-11-19 16:18:47 --> Output Class Initialized
INFO - 2023-11-19 16:18:47 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:47 --> Input Class Initialized
DEBUG - 2023-11-19 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:47 --> Input Class Initialized
INFO - 2023-11-19 16:18:47 --> Config Class Initialized
INFO - 2023-11-19 16:18:47 --> Config Class Initialized
INFO - 2023-11-19 16:18:47 --> Language Class Initialized
INFO - 2023-11-19 16:18:47 --> Config Class Initialized
INFO - 2023-11-19 16:18:47 --> Hooks Class Initialized
INFO - 2023-11-19 16:18:47 --> Hooks Class Initialized
INFO - 2023-11-19 16:18:47 --> Config Class Initialized
INFO - 2023-11-19 16:18:47 --> Hooks Class Initialized
ERROR - 2023-11-19 16:18:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:47 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-11-19 16:18:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:47 --> Language Class Initialized
INFO - 2023-11-19 16:18:47 --> Utf8 Class Initialized
DEBUG - 2023-11-19 16:18:47 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:18:48 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:48 --> URI Class Initialized
INFO - 2023-11-19 16:18:48 --> Router Class Initialized
INFO - 2023-11-19 16:18:48 --> Output Class Initialized
INFO - 2023-11-19 16:18:48 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:48 --> Input Class Initialized
INFO - 2023-11-19 16:18:48 --> Language Class Initialized
ERROR - 2023-11-19 16:18:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:48 --> URI Class Initialized
INFO - 2023-11-19 16:18:48 --> Router Class Initialized
INFO - 2023-11-19 16:18:48 --> Output Class Initialized
INFO - 2023-11-19 16:18:48 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:48 --> Input Class Initialized
INFO - 2023-11-19 16:18:48 --> Language Class Initialized
ERROR - 2023-11-19 16:18:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:48 --> Utf8 Class Initialized
INFO - 2023-11-19 16:18:48 --> URI Class Initialized
INFO - 2023-11-19 16:18:48 --> Router Class Initialized
INFO - 2023-11-19 16:18:48 --> Output Class Initialized
INFO - 2023-11-19 16:18:48 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:48 --> Input Class Initialized
INFO - 2023-11-19 16:18:48 --> Language Class Initialized
ERROR - 2023-11-19 16:18:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:48 --> Utf8 Class Initialized
ERROR - 2023-11-19 16:18:49 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:18:49 --> URI Class Initialized
INFO - 2023-11-19 16:18:49 --> Router Class Initialized
INFO - 2023-11-19 16:18:49 --> Output Class Initialized
INFO - 2023-11-19 16:18:49 --> Security Class Initialized
DEBUG - 2023-11-19 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:18:49 --> Input Class Initialized
INFO - 2023-11-19 16:18:49 --> Language Class Initialized
ERROR - 2023-11-19 16:18:49 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:23:26 --> Config Class Initialized
INFO - 2023-11-19 16:23:26 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:23:26 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:23:26 --> Utf8 Class Initialized
INFO - 2023-11-19 16:23:26 --> URI Class Initialized
INFO - 2023-11-19 16:23:26 --> Router Class Initialized
INFO - 2023-11-19 16:23:26 --> Output Class Initialized
INFO - 2023-11-19 16:23:26 --> Security Class Initialized
DEBUG - 2023-11-19 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:23:26 --> Input Class Initialized
INFO - 2023-11-19 16:23:26 --> Language Class Initialized
INFO - 2023-11-19 16:23:26 --> Loader Class Initialized
INFO - 2023-11-19 16:23:26 --> Helper loaded: url_helper
INFO - 2023-11-19 16:23:26 --> Helper loaded: file_helper
INFO - 2023-11-19 16:23:26 --> Database Driver Class Initialized
INFO - 2023-11-19 16:23:26 --> Email Class Initialized
DEBUG - 2023-11-19 16:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:23:26 --> Controller Class Initialized
INFO - 2023-11-19 16:23:26 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:23:26 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:23:26 --> Model "Home_model" initialized
INFO - 2023-11-19 16:23:26 --> Helper loaded: download_helper
INFO - 2023-11-19 16:23:26 --> Helper loaded: form_helper
INFO - 2023-11-19 16:23:26 --> Form Validation Class Initialized
INFO - 2023-11-19 20:53:26 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:53:26 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:53:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:53:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:53:26 --> Final output sent to browser
DEBUG - 2023-11-19 20:53:26 --> Total execution time: 0.1626
INFO - 2023-11-19 16:23:28 --> Config Class Initialized
INFO - 2023-11-19 16:23:28 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:23:28 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:23:28 --> Utf8 Class Initialized
INFO - 2023-11-19 16:23:28 --> URI Class Initialized
INFO - 2023-11-19 16:23:28 --> Router Class Initialized
INFO - 2023-11-19 16:23:28 --> Output Class Initialized
INFO - 2023-11-19 16:23:28 --> Security Class Initialized
DEBUG - 2023-11-19 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:23:29 --> Config Class Initialized
INFO - 2023-11-19 16:23:29 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:23:29 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:23:29 --> Utf8 Class Initialized
INFO - 2023-11-19 16:23:29 --> URI Class Initialized
INFO - 2023-11-19 16:23:29 --> Router Class Initialized
INFO - 2023-11-19 16:23:29 --> Output Class Initialized
INFO - 2023-11-19 16:23:29 --> Security Class Initialized
DEBUG - 2023-11-19 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:23:29 --> Input Class Initialized
INFO - 2023-11-19 16:23:29 --> Language Class Initialized
ERROR - 2023-11-19 16:23:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-19 16:23:29 --> Input Class Initialized
INFO - 2023-11-19 16:23:29 --> Language Class Initialized
INFO - 2023-11-19 16:23:43 --> Config Class Initialized
INFO - 2023-11-19 16:23:43 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:23:43 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:23:43 --> Utf8 Class Initialized
INFO - 2023-11-19 16:23:43 --> URI Class Initialized
INFO - 2023-11-19 16:23:43 --> Router Class Initialized
INFO - 2023-11-19 16:23:43 --> Output Class Initialized
INFO - 2023-11-19 16:23:43 --> Security Class Initialized
DEBUG - 2023-11-19 16:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:23:43 --> Input Class Initialized
INFO - 2023-11-19 16:23:43 --> Language Class Initialized
INFO - 2023-11-19 16:23:43 --> Loader Class Initialized
INFO - 2023-11-19 16:23:43 --> Helper loaded: url_helper
INFO - 2023-11-19 16:23:43 --> Helper loaded: file_helper
INFO - 2023-11-19 16:23:43 --> Database Driver Class Initialized
INFO - 2023-11-19 16:23:43 --> Email Class Initialized
DEBUG - 2023-11-19 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:23:44 --> Controller Class Initialized
INFO - 2023-11-19 16:23:44 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:23:44 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:23:44 --> Model "Home_model" initialized
INFO - 2023-11-19 16:23:44 --> Helper loaded: download_helper
INFO - 2023-11-19 16:23:44 --> Helper loaded: form_helper
INFO - 2023-11-19 16:23:44 --> Form Validation Class Initialized
INFO - 2023-11-19 20:53:44 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:53:44 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:53:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:53:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:53:44 --> Final output sent to browser
DEBUG - 2023-11-19 20:53:44 --> Total execution time: 0.1611
INFO - 2023-11-19 16:25:28 --> Config Class Initialized
INFO - 2023-11-19 16:25:28 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:25:28 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:25:28 --> Utf8 Class Initialized
INFO - 2023-11-19 16:25:28 --> URI Class Initialized
INFO - 2023-11-19 16:25:28 --> Router Class Initialized
INFO - 2023-11-19 16:25:28 --> Output Class Initialized
INFO - 2023-11-19 16:25:28 --> Security Class Initialized
DEBUG - 2023-11-19 16:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:25:28 --> Input Class Initialized
INFO - 2023-11-19 16:25:28 --> Language Class Initialized
INFO - 2023-11-19 16:25:28 --> Loader Class Initialized
INFO - 2023-11-19 16:25:28 --> Helper loaded: url_helper
INFO - 2023-11-19 16:25:28 --> Helper loaded: file_helper
INFO - 2023-11-19 16:25:28 --> Database Driver Class Initialized
INFO - 2023-11-19 16:25:28 --> Email Class Initialized
DEBUG - 2023-11-19 16:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:25:28 --> Controller Class Initialized
INFO - 2023-11-19 16:25:28 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:25:28 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:25:28 --> Model "Home_model" initialized
INFO - 2023-11-19 16:25:28 --> Helper loaded: download_helper
INFO - 2023-11-19 16:25:28 --> Helper loaded: form_helper
INFO - 2023-11-19 16:25:28 --> Form Validation Class Initialized
INFO - 2023-11-19 20:55:28 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:55:28 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:55:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:55:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:55:28 --> Final output sent to browser
DEBUG - 2023-11-19 20:55:28 --> Total execution time: 0.1515
INFO - 2023-11-19 16:25:39 --> Config Class Initialized
INFO - 2023-11-19 16:25:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:25:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:25:39 --> Utf8 Class Initialized
INFO - 2023-11-19 16:25:39 --> URI Class Initialized
INFO - 2023-11-19 16:25:39 --> Router Class Initialized
INFO - 2023-11-19 16:25:39 --> Output Class Initialized
INFO - 2023-11-19 16:25:39 --> Security Class Initialized
DEBUG - 2023-11-19 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:25:39 --> Input Class Initialized
INFO - 2023-11-19 16:25:39 --> Language Class Initialized
INFO - 2023-11-19 16:25:39 --> Loader Class Initialized
INFO - 2023-11-19 16:25:39 --> Helper loaded: url_helper
INFO - 2023-11-19 16:25:39 --> Helper loaded: file_helper
INFO - 2023-11-19 16:25:39 --> Database Driver Class Initialized
INFO - 2023-11-19 16:25:39 --> Email Class Initialized
DEBUG - 2023-11-19 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:25:39 --> Controller Class Initialized
INFO - 2023-11-19 16:25:39 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:25:39 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:25:39 --> Model "Home_model" initialized
INFO - 2023-11-19 16:25:39 --> Helper loaded: download_helper
INFO - 2023-11-19 16:25:39 --> Helper loaded: form_helper
INFO - 2023-11-19 16:25:39 --> Form Validation Class Initialized
INFO - 2023-11-19 20:55:39 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:55:39 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:55:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:55:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:55:39 --> Final output sent to browser
DEBUG - 2023-11-19 20:55:39 --> Total execution time: 0.1736
INFO - 2023-11-19 16:25:54 --> Config Class Initialized
INFO - 2023-11-19 16:25:54 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:25:54 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:25:54 --> Utf8 Class Initialized
INFO - 2023-11-19 16:25:54 --> URI Class Initialized
DEBUG - 2023-11-19 16:25:54 --> No URI present. Default controller set.
INFO - 2023-11-19 16:25:54 --> Router Class Initialized
INFO - 2023-11-19 16:25:54 --> Output Class Initialized
INFO - 2023-11-19 16:25:54 --> Security Class Initialized
DEBUG - 2023-11-19 16:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:25:54 --> Input Class Initialized
INFO - 2023-11-19 16:25:54 --> Language Class Initialized
INFO - 2023-11-19 16:25:54 --> Loader Class Initialized
INFO - 2023-11-19 16:25:54 --> Helper loaded: url_helper
INFO - 2023-11-19 16:25:54 --> Helper loaded: file_helper
INFO - 2023-11-19 16:25:54 --> Database Driver Class Initialized
INFO - 2023-11-19 16:25:54 --> Email Class Initialized
DEBUG - 2023-11-19 16:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:25:54 --> Controller Class Initialized
INFO - 2023-11-19 16:25:54 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:25:54 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:25:54 --> Model "Home_model" initialized
INFO - 2023-11-19 16:25:54 --> Helper loaded: download_helper
INFO - 2023-11-19 16:25:54 --> Helper loaded: form_helper
INFO - 2023-11-19 16:25:54 --> Form Validation Class Initialized
INFO - 2023-11-19 20:55:54 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:55:54 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:55:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:55:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 20:55:54 --> Final output sent to browser
DEBUG - 2023-11-19 20:55:54 --> Total execution time: 0.2032
INFO - 2023-11-19 16:26:13 --> Config Class Initialized
INFO - 2023-11-19 16:26:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:26:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:26:13 --> Utf8 Class Initialized
INFO - 2023-11-19 16:26:13 --> URI Class Initialized
INFO - 2023-11-19 16:26:13 --> Router Class Initialized
INFO - 2023-11-19 16:26:13 --> Output Class Initialized
INFO - 2023-11-19 16:26:13 --> Security Class Initialized
DEBUG - 2023-11-19 16:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:26:13 --> Input Class Initialized
INFO - 2023-11-19 16:26:13 --> Language Class Initialized
INFO - 2023-11-19 16:26:13 --> Loader Class Initialized
INFO - 2023-11-19 16:26:13 --> Helper loaded: url_helper
INFO - 2023-11-19 16:26:13 --> Helper loaded: file_helper
INFO - 2023-11-19 16:26:13 --> Database Driver Class Initialized
INFO - 2023-11-19 16:26:14 --> Email Class Initialized
DEBUG - 2023-11-19 16:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:26:14 --> Controller Class Initialized
INFO - 2023-11-19 16:26:14 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:26:14 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:26:14 --> Model "Home_model" initialized
INFO - 2023-11-19 16:26:14 --> Helper loaded: download_helper
INFO - 2023-11-19 16:26:14 --> Helper loaded: form_helper
INFO - 2023-11-19 16:26:14 --> Form Validation Class Initialized
INFO - 2023-11-19 20:56:14 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:56:14 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:56:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-11-19 20:56:14 --> Final output sent to browser
DEBUG - 2023-11-19 20:56:14 --> Total execution time: 0.1506
INFO - 2023-11-19 16:26:28 --> Config Class Initialized
INFO - 2023-11-19 16:26:28 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:26:28 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:26:28 --> Utf8 Class Initialized
INFO - 2023-11-19 16:26:28 --> URI Class Initialized
INFO - 2023-11-19 16:26:28 --> Router Class Initialized
INFO - 2023-11-19 16:26:28 --> Output Class Initialized
INFO - 2023-11-19 16:26:28 --> Security Class Initialized
DEBUG - 2023-11-19 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:26:28 --> Input Class Initialized
INFO - 2023-11-19 16:26:28 --> Language Class Initialized
INFO - 2023-11-19 16:26:28 --> Loader Class Initialized
INFO - 2023-11-19 16:26:28 --> Helper loaded: url_helper
INFO - 2023-11-19 16:26:28 --> Helper loaded: file_helper
INFO - 2023-11-19 16:26:28 --> Database Driver Class Initialized
INFO - 2023-11-19 16:26:28 --> Email Class Initialized
DEBUG - 2023-11-19 16:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:26:28 --> Controller Class Initialized
INFO - 2023-11-19 16:26:28 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:26:28 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:26:28 --> Model "Home_model" initialized
INFO - 2023-11-19 16:26:28 --> Helper loaded: download_helper
INFO - 2023-11-19 16:26:28 --> Helper loaded: form_helper
INFO - 2023-11-19 16:26:28 --> Form Validation Class Initialized
INFO - 2023-11-19 20:56:28 --> Helper loaded: custom_helper
INFO - 2023-11-19 20:56:28 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 20:56:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 20:56:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 20:56:28 --> Final output sent to browser
DEBUG - 2023-11-19 20:56:28 --> Total execution time: 0.1447
INFO - 2023-11-19 16:29:25 --> Config Class Initialized
INFO - 2023-11-19 16:29:25 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:29:25 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:29:25 --> Utf8 Class Initialized
INFO - 2023-11-19 16:29:25 --> URI Class Initialized
INFO - 2023-11-19 16:29:25 --> Router Class Initialized
INFO - 2023-11-19 16:29:25 --> Output Class Initialized
INFO - 2023-11-19 16:29:25 --> Security Class Initialized
DEBUG - 2023-11-19 16:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:29:25 --> Input Class Initialized
INFO - 2023-11-19 16:29:25 --> Language Class Initialized
INFO - 2023-11-19 16:29:25 --> Loader Class Initialized
INFO - 2023-11-19 16:29:25 --> Helper loaded: url_helper
INFO - 2023-11-19 16:29:25 --> Helper loaded: file_helper
INFO - 2023-11-19 16:29:25 --> Database Driver Class Initialized
INFO - 2023-11-19 16:29:25 --> Email Class Initialized
DEBUG - 2023-11-19 16:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:29:25 --> Controller Class Initialized
INFO - 2023-11-19 16:29:25 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:29:25 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:29:25 --> Model "Home_model" initialized
INFO - 2023-11-19 16:29:25 --> Helper loaded: download_helper
INFO - 2023-11-19 16:29:25 --> Helper loaded: form_helper
INFO - 2023-11-19 16:29:25 --> Form Validation Class Initialized
ERROR - 2023-11-19 20:59:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 118
ERROR - 2023-11-19 20:59:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 119
ERROR - 2023-11-19 20:59:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `services`
WHERE `id` >
AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5
INFO - 2023-11-19 20:59:25 --> Language file loaded: language/english/db_lang.php
INFO - 2023-11-19 16:29:28 --> Config Class Initialized
INFO - 2023-11-19 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:29:28 --> Utf8 Class Initialized
INFO - 2023-11-19 16:29:28 --> URI Class Initialized
INFO - 2023-11-19 16:29:28 --> Router Class Initialized
INFO - 2023-11-19 16:29:28 --> Output Class Initialized
INFO - 2023-11-19 16:29:28 --> Security Class Initialized
DEBUG - 2023-11-19 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:29:28 --> Input Class Initialized
INFO - 2023-11-19 16:29:28 --> Language Class Initialized
INFO - 2023-11-19 16:29:28 --> Loader Class Initialized
INFO - 2023-11-19 16:29:28 --> Helper loaded: url_helper
INFO - 2023-11-19 16:29:28 --> Helper loaded: file_helper
INFO - 2023-11-19 16:29:28 --> Database Driver Class Initialized
INFO - 2023-11-19 16:29:28 --> Email Class Initialized
DEBUG - 2023-11-19 16:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:29:28 --> Controller Class Initialized
INFO - 2023-11-19 16:29:28 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:29:28 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:29:28 --> Model "Home_model" initialized
INFO - 2023-11-19 16:29:28 --> Helper loaded: download_helper
INFO - 2023-11-19 16:29:28 --> Helper loaded: form_helper
INFO - 2023-11-19 16:29:28 --> Form Validation Class Initialized
ERROR - 2023-11-19 20:59:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 118
ERROR - 2023-11-19 20:59:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 119
ERROR - 2023-11-19 20:59:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `services`
WHERE `id` >
AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5
INFO - 2023-11-19 20:59:28 --> Language file loaded: language/english/db_lang.php
INFO - 2023-11-19 16:31:30 --> Config Class Initialized
INFO - 2023-11-19 16:31:30 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:31:30 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:31:30 --> Utf8 Class Initialized
INFO - 2023-11-19 16:31:30 --> URI Class Initialized
INFO - 2023-11-19 16:31:30 --> Router Class Initialized
INFO - 2023-11-19 16:31:30 --> Output Class Initialized
INFO - 2023-11-19 16:31:30 --> Security Class Initialized
DEBUG - 2023-11-19 16:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:31:30 --> Input Class Initialized
INFO - 2023-11-19 16:31:30 --> Language Class Initialized
INFO - 2023-11-19 16:31:30 --> Loader Class Initialized
INFO - 2023-11-19 16:31:30 --> Helper loaded: url_helper
INFO - 2023-11-19 16:31:30 --> Helper loaded: file_helper
INFO - 2023-11-19 16:31:30 --> Database Driver Class Initialized
INFO - 2023-11-19 16:31:30 --> Email Class Initialized
DEBUG - 2023-11-19 16:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:31:30 --> Controller Class Initialized
INFO - 2023-11-19 16:31:30 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:31:30 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:31:30 --> Model "Home_model" initialized
INFO - 2023-11-19 16:31:30 --> Helper loaded: download_helper
INFO - 2023-11-19 16:31:30 --> Helper loaded: form_helper
INFO - 2023-11-19 16:31:30 --> Form Validation Class Initialized
ERROR - 2023-11-19 21:01:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 118
ERROR - 2023-11-19 21:01:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 119
ERROR - 2023-11-19 21:01:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `services`
WHERE `id` >
AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5
INFO - 2023-11-19 21:01:30 --> Language file loaded: language/english/db_lang.php
INFO - 2023-11-19 16:31:32 --> Config Class Initialized
INFO - 2023-11-19 16:31:32 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:31:32 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:31:32 --> Utf8 Class Initialized
INFO - 2023-11-19 16:31:32 --> URI Class Initialized
INFO - 2023-11-19 16:31:32 --> Router Class Initialized
INFO - 2023-11-19 16:31:32 --> Output Class Initialized
INFO - 2023-11-19 16:31:32 --> Security Class Initialized
DEBUG - 2023-11-19 16:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:31:32 --> Input Class Initialized
INFO - 2023-11-19 16:31:32 --> Language Class Initialized
INFO - 2023-11-19 16:31:32 --> Loader Class Initialized
INFO - 2023-11-19 16:31:32 --> Helper loaded: url_helper
INFO - 2023-11-19 16:31:32 --> Helper loaded: file_helper
INFO - 2023-11-19 16:31:32 --> Database Driver Class Initialized
INFO - 2023-11-19 16:31:32 --> Email Class Initialized
DEBUG - 2023-11-19 16:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:31:32 --> Controller Class Initialized
INFO - 2023-11-19 16:31:32 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:31:32 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:31:32 --> Model "Home_model" initialized
INFO - 2023-11-19 16:31:32 --> Helper loaded: download_helper
INFO - 2023-11-19 16:31:32 --> Helper loaded: form_helper
INFO - 2023-11-19 16:31:32 --> Form Validation Class Initialized
INFO - 2023-11-19 21:01:32 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:01:32 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:01:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:01:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-19 21:01:32 --> Final output sent to browser
DEBUG - 2023-11-19 21:01:32 --> Total execution time: 0.1202
INFO - 2023-11-19 16:31:35 --> Config Class Initialized
INFO - 2023-11-19 16:31:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:31:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:31:35 --> Utf8 Class Initialized
INFO - 2023-11-19 16:31:35 --> URI Class Initialized
INFO - 2023-11-19 16:31:35 --> Router Class Initialized
INFO - 2023-11-19 16:31:35 --> Output Class Initialized
INFO - 2023-11-19 16:31:35 --> Security Class Initialized
DEBUG - 2023-11-19 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:31:35 --> Input Class Initialized
INFO - 2023-11-19 16:31:35 --> Language Class Initialized
INFO - 2023-11-19 16:31:35 --> Loader Class Initialized
INFO - 2023-11-19 16:31:35 --> Helper loaded: url_helper
INFO - 2023-11-19 16:31:35 --> Helper loaded: file_helper
INFO - 2023-11-19 16:31:35 --> Database Driver Class Initialized
INFO - 2023-11-19 16:31:35 --> Email Class Initialized
DEBUG - 2023-11-19 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:31:35 --> Controller Class Initialized
INFO - 2023-11-19 16:31:35 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:31:35 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:31:35 --> Model "Home_model" initialized
INFO - 2023-11-19 16:31:35 --> Helper loaded: download_helper
INFO - 2023-11-19 16:31:35 --> Helper loaded: form_helper
INFO - 2023-11-19 16:31:35 --> Form Validation Class Initialized
INFO - 2023-11-19 21:01:35 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:01:35 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:01:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:01:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-11-19 21:01:35 --> Final output sent to browser
DEBUG - 2023-11-19 21:01:35 --> Total execution time: 0.1456
INFO - 2023-11-19 16:31:39 --> Config Class Initialized
INFO - 2023-11-19 16:31:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:31:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:31:39 --> Utf8 Class Initialized
INFO - 2023-11-19 16:31:39 --> URI Class Initialized
INFO - 2023-11-19 16:31:39 --> Router Class Initialized
INFO - 2023-11-19 16:31:39 --> Output Class Initialized
INFO - 2023-11-19 16:31:39 --> Security Class Initialized
DEBUG - 2023-11-19 16:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:31:39 --> Input Class Initialized
INFO - 2023-11-19 16:31:39 --> Language Class Initialized
INFO - 2023-11-19 16:31:39 --> Loader Class Initialized
INFO - 2023-11-19 16:31:39 --> Helper loaded: url_helper
INFO - 2023-11-19 16:31:39 --> Helper loaded: file_helper
INFO - 2023-11-19 16:31:39 --> Database Driver Class Initialized
INFO - 2023-11-19 16:31:39 --> Email Class Initialized
DEBUG - 2023-11-19 16:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:31:39 --> Controller Class Initialized
INFO - 2023-11-19 16:31:39 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:31:39 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:31:39 --> Model "Home_model" initialized
INFO - 2023-11-19 16:31:39 --> Helper loaded: download_helper
INFO - 2023-11-19 16:31:39 --> Helper loaded: form_helper
INFO - 2023-11-19 16:31:39 --> Form Validation Class Initialized
INFO - 2023-11-19 21:01:39 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:01:39 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:01:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:01:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-11-19 21:01:39 --> Final output sent to browser
DEBUG - 2023-11-19 21:01:39 --> Total execution time: 0.1779
INFO - 2023-11-19 16:31:42 --> Config Class Initialized
INFO - 2023-11-19 16:31:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:31:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:31:42 --> Utf8 Class Initialized
INFO - 2023-11-19 16:31:42 --> URI Class Initialized
INFO - 2023-11-19 16:31:42 --> Router Class Initialized
INFO - 2023-11-19 16:31:42 --> Output Class Initialized
INFO - 2023-11-19 16:31:42 --> Security Class Initialized
DEBUG - 2023-11-19 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:31:42 --> Input Class Initialized
INFO - 2023-11-19 16:31:42 --> Language Class Initialized
INFO - 2023-11-19 16:31:42 --> Loader Class Initialized
INFO - 2023-11-19 16:31:42 --> Helper loaded: url_helper
INFO - 2023-11-19 16:31:42 --> Helper loaded: file_helper
INFO - 2023-11-19 16:31:42 --> Database Driver Class Initialized
INFO - 2023-11-19 16:31:42 --> Email Class Initialized
DEBUG - 2023-11-19 16:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:31:42 --> Controller Class Initialized
INFO - 2023-11-19 16:31:42 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:31:42 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:31:42 --> Model "Home_model" initialized
INFO - 2023-11-19 16:31:42 --> Helper loaded: download_helper
INFO - 2023-11-19 16:31:42 --> Helper loaded: form_helper
INFO - 2023-11-19 16:31:42 --> Form Validation Class Initialized
INFO - 2023-11-19 21:01:42 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:01:42 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:01:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:01:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-11-19 21:01:43 --> Final output sent to browser
DEBUG - 2023-11-19 21:01:43 --> Total execution time: 0.2515
INFO - 2023-11-19 16:32:18 --> Config Class Initialized
INFO - 2023-11-19 16:32:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:18 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:18 --> URI Class Initialized
INFO - 2023-11-19 16:32:18 --> Router Class Initialized
INFO - 2023-11-19 16:32:18 --> Output Class Initialized
INFO - 2023-11-19 16:32:18 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:18 --> Input Class Initialized
INFO - 2023-11-19 16:32:18 --> Language Class Initialized
INFO - 2023-11-19 16:32:18 --> Loader Class Initialized
INFO - 2023-11-19 16:32:18 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:18 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:18 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:18 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:18 --> Controller Class Initialized
INFO - 2023-11-19 16:32:18 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:18 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:18 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:18 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:18 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:18 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-11-19 21:02:18 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:18 --> Total execution time: 0.1488
INFO - 2023-11-19 16:32:23 --> Config Class Initialized
INFO - 2023-11-19 16:32:23 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:23 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:23 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:23 --> URI Class Initialized
INFO - 2023-11-19 16:32:23 --> Router Class Initialized
INFO - 2023-11-19 16:32:23 --> Output Class Initialized
INFO - 2023-11-19 16:32:23 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:23 --> Input Class Initialized
INFO - 2023-11-19 16:32:23 --> Language Class Initialized
INFO - 2023-11-19 16:32:23 --> Loader Class Initialized
INFO - 2023-11-19 16:32:23 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:23 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:23 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:23 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:23 --> Controller Class Initialized
INFO - 2023-11-19 16:32:23 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:23 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:23 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:23 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:23 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:23 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:23 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:23 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-11-19 21:02:23 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:23 --> Total execution time: 0.1736
INFO - 2023-11-19 16:32:25 --> Config Class Initialized
INFO - 2023-11-19 16:32:25 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:25 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:25 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:25 --> URI Class Initialized
INFO - 2023-11-19 16:32:25 --> Router Class Initialized
INFO - 2023-11-19 16:32:25 --> Output Class Initialized
INFO - 2023-11-19 16:32:25 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:25 --> Input Class Initialized
INFO - 2023-11-19 16:32:25 --> Language Class Initialized
INFO - 2023-11-19 16:32:25 --> Loader Class Initialized
INFO - 2023-11-19 16:32:25 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:25 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:25 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:25 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:25 --> Controller Class Initialized
INFO - 2023-11-19 16:32:25 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:25 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:25 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:25 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:25 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:25 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:25 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:25 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-11-19 21:02:25 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:25 --> Total execution time: 0.1806
INFO - 2023-11-19 16:32:29 --> Config Class Initialized
INFO - 2023-11-19 16:32:29 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:29 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:29 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:29 --> URI Class Initialized
INFO - 2023-11-19 16:32:29 --> Router Class Initialized
INFO - 2023-11-19 16:32:29 --> Output Class Initialized
INFO - 2023-11-19 16:32:29 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:29 --> Input Class Initialized
INFO - 2023-11-19 16:32:29 --> Language Class Initialized
INFO - 2023-11-19 16:32:29 --> Loader Class Initialized
INFO - 2023-11-19 16:32:29 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:29 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:29 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:29 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:29 --> Controller Class Initialized
INFO - 2023-11-19 16:32:29 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:29 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:29 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:29 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:29 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:29 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:29 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:29 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-11-19 21:02:29 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:30 --> Total execution time: 0.1843
INFO - 2023-11-19 16:32:32 --> Config Class Initialized
INFO - 2023-11-19 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:32 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:32 --> URI Class Initialized
INFO - 2023-11-19 16:32:32 --> Router Class Initialized
INFO - 2023-11-19 16:32:32 --> Output Class Initialized
INFO - 2023-11-19 16:32:32 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:32 --> Input Class Initialized
INFO - 2023-11-19 16:32:32 --> Language Class Initialized
INFO - 2023-11-19 16:32:32 --> Loader Class Initialized
INFO - 2023-11-19 16:32:32 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:32 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:32 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:32 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:32 --> Controller Class Initialized
INFO - 2023-11-19 16:32:32 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:32 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:32 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:32 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:32 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:32 --> Form Validation Class Initialized
INFO - 2023-11-19 16:32:35 --> Config Class Initialized
INFO - 2023-11-19 16:32:35 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:35 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:35 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:35 --> URI Class Initialized
INFO - 2023-11-19 16:32:35 --> Router Class Initialized
INFO - 2023-11-19 16:32:35 --> Output Class Initialized
INFO - 2023-11-19 16:32:35 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:35 --> Input Class Initialized
INFO - 2023-11-19 16:32:35 --> Language Class Initialized
INFO - 2023-11-19 16:32:35 --> Loader Class Initialized
INFO - 2023-11-19 16:32:35 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:35 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:35 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:35 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:35 --> Controller Class Initialized
INFO - 2023-11-19 16:32:35 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:35 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:35 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:35 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:35 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:35 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:35 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:35 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-11-19 21:02:35 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:35 --> Total execution time: 0.1521
INFO - 2023-11-19 16:32:42 --> Config Class Initialized
INFO - 2023-11-19 16:32:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:32:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:32:42 --> Utf8 Class Initialized
INFO - 2023-11-19 16:32:42 --> URI Class Initialized
INFO - 2023-11-19 16:32:42 --> Router Class Initialized
INFO - 2023-11-19 16:32:42 --> Output Class Initialized
INFO - 2023-11-19 16:32:42 --> Security Class Initialized
DEBUG - 2023-11-19 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:32:42 --> Input Class Initialized
INFO - 2023-11-19 16:32:42 --> Language Class Initialized
INFO - 2023-11-19 16:32:42 --> Loader Class Initialized
INFO - 2023-11-19 16:32:42 --> Helper loaded: url_helper
INFO - 2023-11-19 16:32:42 --> Helper loaded: file_helper
INFO - 2023-11-19 16:32:42 --> Database Driver Class Initialized
INFO - 2023-11-19 16:32:42 --> Email Class Initialized
DEBUG - 2023-11-19 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:32:42 --> Controller Class Initialized
INFO - 2023-11-19 16:32:42 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:32:42 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:32:42 --> Model "Home_model" initialized
INFO - 2023-11-19 16:32:42 --> Helper loaded: download_helper
INFO - 2023-11-19 16:32:42 --> Helper loaded: form_helper
INFO - 2023-11-19 16:32:42 --> Form Validation Class Initialized
INFO - 2023-11-19 21:02:42 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:02:42 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:02:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:02:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-11-19 21:02:42 --> Final output sent to browser
DEBUG - 2023-11-19 21:02:42 --> Total execution time: 0.1492
INFO - 2023-11-19 16:33:01 --> Config Class Initialized
INFO - 2023-11-19 16:33:01 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:33:01 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:33:01 --> Utf8 Class Initialized
INFO - 2023-11-19 16:33:01 --> URI Class Initialized
DEBUG - 2023-11-19 16:33:01 --> No URI present. Default controller set.
INFO - 2023-11-19 16:33:01 --> Router Class Initialized
INFO - 2023-11-19 16:33:01 --> Output Class Initialized
INFO - 2023-11-19 16:33:01 --> Security Class Initialized
DEBUG - 2023-11-19 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:33:01 --> Input Class Initialized
INFO - 2023-11-19 16:33:01 --> Language Class Initialized
INFO - 2023-11-19 16:33:01 --> Loader Class Initialized
INFO - 2023-11-19 16:33:01 --> Helper loaded: url_helper
INFO - 2023-11-19 16:33:01 --> Helper loaded: file_helper
INFO - 2023-11-19 16:33:01 --> Database Driver Class Initialized
INFO - 2023-11-19 16:33:01 --> Email Class Initialized
DEBUG - 2023-11-19 16:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:33:01 --> Controller Class Initialized
INFO - 2023-11-19 16:33:01 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:33:01 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:33:01 --> Model "Home_model" initialized
INFO - 2023-11-19 16:33:01 --> Helper loaded: download_helper
INFO - 2023-11-19 16:33:01 --> Helper loaded: form_helper
INFO - 2023-11-19 16:33:01 --> Form Validation Class Initialized
INFO - 2023-11-19 21:03:01 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:03:01 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:03:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:03:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 21:03:01 --> Final output sent to browser
DEBUG - 2023-11-19 21:03:01 --> Total execution time: 0.1493
INFO - 2023-11-19 16:33:22 --> Config Class Initialized
INFO - 2023-11-19 16:33:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:33:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:33:22 --> Utf8 Class Initialized
INFO - 2023-11-19 16:33:22 --> URI Class Initialized
DEBUG - 2023-11-19 16:33:22 --> No URI present. Default controller set.
INFO - 2023-11-19 16:33:22 --> Router Class Initialized
INFO - 2023-11-19 16:33:22 --> Output Class Initialized
INFO - 2023-11-19 16:33:22 --> Security Class Initialized
DEBUG - 2023-11-19 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:33:22 --> Input Class Initialized
INFO - 2023-11-19 16:33:22 --> Language Class Initialized
INFO - 2023-11-19 16:33:22 --> Loader Class Initialized
INFO - 2023-11-19 16:33:22 --> Helper loaded: url_helper
INFO - 2023-11-19 16:33:22 --> Helper loaded: file_helper
INFO - 2023-11-19 16:33:22 --> Database Driver Class Initialized
INFO - 2023-11-19 16:33:22 --> Email Class Initialized
DEBUG - 2023-11-19 16:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:33:22 --> Controller Class Initialized
INFO - 2023-11-19 16:33:22 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:33:22 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:33:22 --> Model "Home_model" initialized
INFO - 2023-11-19 16:33:22 --> Helper loaded: download_helper
INFO - 2023-11-19 16:33:22 --> Helper loaded: form_helper
INFO - 2023-11-19 16:33:22 --> Form Validation Class Initialized
INFO - 2023-11-19 21:03:22 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:03:22 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:03:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:03:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 21:03:23 --> Final output sent to browser
DEBUG - 2023-11-19 21:03:23 --> Total execution time: 0.1594
INFO - 2023-11-19 16:37:06 --> Config Class Initialized
INFO - 2023-11-19 16:37:06 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:37:06 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:37:06 --> Utf8 Class Initialized
INFO - 2023-11-19 16:37:06 --> URI Class Initialized
DEBUG - 2023-11-19 16:37:06 --> No URI present. Default controller set.
INFO - 2023-11-19 16:37:06 --> Router Class Initialized
INFO - 2023-11-19 16:37:06 --> Output Class Initialized
INFO - 2023-11-19 16:37:06 --> Security Class Initialized
DEBUG - 2023-11-19 16:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:37:06 --> Input Class Initialized
INFO - 2023-11-19 16:37:06 --> Language Class Initialized
INFO - 2023-11-19 16:37:06 --> Loader Class Initialized
INFO - 2023-11-19 16:37:06 --> Helper loaded: url_helper
INFO - 2023-11-19 16:37:06 --> Helper loaded: file_helper
INFO - 2023-11-19 16:37:06 --> Database Driver Class Initialized
INFO - 2023-11-19 16:37:06 --> Email Class Initialized
DEBUG - 2023-11-19 16:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:37:06 --> Controller Class Initialized
INFO - 2023-11-19 16:37:06 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:37:06 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:37:06 --> Model "Home_model" initialized
INFO - 2023-11-19 16:37:06 --> Helper loaded: download_helper
INFO - 2023-11-19 16:37:06 --> Helper loaded: form_helper
INFO - 2023-11-19 16:37:06 --> Form Validation Class Initialized
INFO - 2023-11-19 21:07:06 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:07:06 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:07:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:07:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-19 21:07:06 --> Final output sent to browser
DEBUG - 2023-11-19 21:07:06 --> Total execution time: 0.1531
INFO - 2023-11-19 16:37:32 --> Config Class Initialized
INFO - 2023-11-19 16:37:32 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:37:32 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:37:32 --> Utf8 Class Initialized
INFO - 2023-11-19 16:37:32 --> URI Class Initialized
INFO - 2023-11-19 16:37:32 --> Router Class Initialized
INFO - 2023-11-19 16:37:32 --> Output Class Initialized
INFO - 2023-11-19 16:37:32 --> Security Class Initialized
DEBUG - 2023-11-19 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:37:32 --> Input Class Initialized
INFO - 2023-11-19 16:37:32 --> Language Class Initialized
INFO - 2023-11-19 16:37:32 --> Loader Class Initialized
INFO - 2023-11-19 16:37:32 --> Helper loaded: url_helper
INFO - 2023-11-19 16:37:32 --> Helper loaded: file_helper
INFO - 2023-11-19 16:37:32 --> Database Driver Class Initialized
INFO - 2023-11-19 16:37:32 --> Email Class Initialized
DEBUG - 2023-11-19 16:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:37:32 --> Controller Class Initialized
INFO - 2023-11-19 16:37:32 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:37:32 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:37:32 --> Model "Home_model" initialized
INFO - 2023-11-19 16:37:32 --> Helper loaded: download_helper
INFO - 2023-11-19 16:37:32 --> Helper loaded: form_helper
INFO - 2023-11-19 16:37:32 --> Form Validation Class Initialized
INFO - 2023-11-19 21:07:32 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:07:32 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:07:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:07:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/gallery.php
INFO - 2023-11-19 21:07:33 --> Final output sent to browser
DEBUG - 2023-11-19 21:07:33 --> Total execution time: 0.1877
INFO - 2023-11-19 16:38:18 --> Config Class Initialized
INFO - 2023-11-19 16:38:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:38:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:38:18 --> Utf8 Class Initialized
INFO - 2023-11-19 16:38:18 --> URI Class Initialized
INFO - 2023-11-19 16:38:18 --> Router Class Initialized
INFO - 2023-11-19 16:38:18 --> Output Class Initialized
INFO - 2023-11-19 16:38:18 --> Security Class Initialized
DEBUG - 2023-11-19 16:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:38:18 --> Input Class Initialized
INFO - 2023-11-19 16:38:18 --> Language Class Initialized
INFO - 2023-11-19 16:38:18 --> Loader Class Initialized
INFO - 2023-11-19 16:38:18 --> Helper loaded: url_helper
INFO - 2023-11-19 16:38:18 --> Helper loaded: file_helper
INFO - 2023-11-19 16:38:18 --> Database Driver Class Initialized
INFO - 2023-11-19 16:38:18 --> Email Class Initialized
DEBUG - 2023-11-19 16:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:38:18 --> Controller Class Initialized
INFO - 2023-11-19 16:38:18 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:38:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:38:18 --> Model "Home_model" initialized
INFO - 2023-11-19 16:38:18 --> Helper loaded: download_helper
INFO - 2023-11-19 16:38:18 --> Helper loaded: form_helper
INFO - 2023-11-19 16:38:18 --> Form Validation Class Initialized
INFO - 2023-11-19 21:08:18 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:08:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:08:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:08:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/gallery.php
INFO - 2023-11-19 21:08:18 --> Final output sent to browser
DEBUG - 2023-11-19 21:08:19 --> Total execution time: 0.1381
INFO - 2023-11-19 16:38:27 --> Config Class Initialized
INFO - 2023-11-19 16:38:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:38:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:38:27 --> Utf8 Class Initialized
INFO - 2023-11-19 16:38:27 --> URI Class Initialized
INFO - 2023-11-19 16:38:27 --> Router Class Initialized
INFO - 2023-11-19 16:38:27 --> Output Class Initialized
INFO - 2023-11-19 16:38:27 --> Security Class Initialized
DEBUG - 2023-11-19 16:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:38:27 --> Input Class Initialized
INFO - 2023-11-19 16:38:27 --> Language Class Initialized
INFO - 2023-11-19 16:38:27 --> Loader Class Initialized
INFO - 2023-11-19 16:38:27 --> Helper loaded: url_helper
INFO - 2023-11-19 16:38:27 --> Helper loaded: file_helper
INFO - 2023-11-19 16:38:27 --> Database Driver Class Initialized
INFO - 2023-11-19 16:38:27 --> Email Class Initialized
DEBUG - 2023-11-19 16:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:38:27 --> Controller Class Initialized
INFO - 2023-11-19 16:38:27 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:38:27 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:38:27 --> Model "Home_model" initialized
INFO - 2023-11-19 16:38:27 --> Helper loaded: download_helper
INFO - 2023-11-19 16:38:27 --> Helper loaded: form_helper
INFO - 2023-11-19 16:38:27 --> Form Validation Class Initialized
INFO - 2023-11-19 21:08:27 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:08:27 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:08:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:08:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/gallery.php
INFO - 2023-11-19 21:08:28 --> Final output sent to browser
DEBUG - 2023-11-19 21:08:28 --> Total execution time: 0.1595
INFO - 2023-11-19 16:39:13 --> Config Class Initialized
INFO - 2023-11-19 16:39:13 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:39:13 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:39:13 --> Utf8 Class Initialized
INFO - 2023-11-19 16:39:13 --> URI Class Initialized
INFO - 2023-11-19 16:39:13 --> Router Class Initialized
INFO - 2023-11-19 16:39:13 --> Output Class Initialized
INFO - 2023-11-19 16:39:13 --> Security Class Initialized
DEBUG - 2023-11-19 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:39:13 --> Input Class Initialized
INFO - 2023-11-19 16:39:13 --> Language Class Initialized
INFO - 2023-11-19 16:39:13 --> Loader Class Initialized
INFO - 2023-11-19 16:39:13 --> Helper loaded: url_helper
INFO - 2023-11-19 16:39:13 --> Helper loaded: file_helper
INFO - 2023-11-19 16:39:13 --> Database Driver Class Initialized
INFO - 2023-11-19 16:39:13 --> Email Class Initialized
DEBUG - 2023-11-19 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:39:13 --> Controller Class Initialized
INFO - 2023-11-19 16:39:13 --> Model "Contact_model" initialized
INFO - 2023-11-19 16:39:13 --> Model "CareerFormModel" initialized
INFO - 2023-11-19 16:39:13 --> Model "Home_model" initialized
INFO - 2023-11-19 16:39:13 --> Helper loaded: download_helper
INFO - 2023-11-19 16:39:13 --> Helper loaded: form_helper
INFO - 2023-11-19 16:39:13 --> Form Validation Class Initialized
INFO - 2023-11-19 21:09:13 --> Helper loaded: custom_helper
INFO - 2023-11-19 21:09:13 --> Model "Social_media_model" initialized
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-19 21:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-19 21:09:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-11-19 21:09:13 --> Final output sent to browser
DEBUG - 2023-11-19 21:09:13 --> Total execution time: 0.2098
INFO - 2023-11-19 16:39:14 --> Config Class Initialized
INFO - 2023-11-19 16:39:14 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:39:14 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:39:14 --> Utf8 Class Initialized
INFO - 2023-11-19 16:39:14 --> URI Class Initialized
INFO - 2023-11-19 16:39:14 --> Router Class Initialized
INFO - 2023-11-19 16:39:14 --> Output Class Initialized
INFO - 2023-11-19 16:39:14 --> Security Class Initialized
DEBUG - 2023-11-19 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:39:14 --> Input Class Initialized
INFO - 2023-11-19 16:39:14 --> Language Class Initialized
ERROR - 2023-11-19 16:39:14 --> 404 Page Not Found: Assets/images
