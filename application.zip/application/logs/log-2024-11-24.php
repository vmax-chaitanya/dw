<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-24 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 17:52:48 --> Total execution time: 0.1716
DEBUG - 2024-11-24 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 17:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 17:52:48 --> Total execution time: 0.0910
DEBUG - 2024-11-24 13:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 18:14:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 18:14:14 --> Total execution time: 0.1265
DEBUG - 2024-11-24 13:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 18:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 18:14:15 --> Total execution time: 0.1093
DEBUG - 2024-11-24 13:48:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 18:18:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 18:18:16 --> Total execution time: 0.1753
DEBUG - 2024-11-24 13:53:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 18:23:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 18:23:14 --> Total execution time: 0.1443
DEBUG - 2024-11-24 13:54:10 --> UTF-8 Support Enabled
DEBUG - 2024-11-24 13:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-24 13:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-24 18:24:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-24 18:24:10 --> Total execution time: 0.1144
