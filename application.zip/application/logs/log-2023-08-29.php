<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-29 07:23:22 --> Config Class Initialized
INFO - 2023-08-29 07:23:22 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:23:22 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:23:22 --> Utf8 Class Initialized
INFO - 2023-08-29 07:23:22 --> URI Class Initialized
INFO - 2023-08-29 07:23:22 --> Router Class Initialized
INFO - 2023-08-29 07:23:22 --> Output Class Initialized
INFO - 2023-08-29 07:23:22 --> Security Class Initialized
DEBUG - 2023-08-29 07:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:23:22 --> Input Class Initialized
INFO - 2023-08-29 07:23:22 --> Language Class Initialized
INFO - 2023-08-29 07:23:23 --> Loader Class Initialized
INFO - 2023-08-29 07:23:23 --> Helper loaded: url_helper
INFO - 2023-08-29 07:23:23 --> Helper loaded: file_helper
INFO - 2023-08-29 07:23:23 --> Database Driver Class Initialized
INFO - 2023-08-29 07:23:23 --> Email Class Initialized
DEBUG - 2023-08-29 07:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:23:23 --> Controller Class Initialized
INFO - 2023-08-29 07:23:23 --> Model "User_model" initialized
INFO - 2023-08-29 07:23:23 --> Config Class Initialized
INFO - 2023-08-29 07:23:23 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:23:23 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:23:23 --> Utf8 Class Initialized
INFO - 2023-08-29 07:23:23 --> URI Class Initialized
INFO - 2023-08-29 07:23:23 --> Router Class Initialized
INFO - 2023-08-29 07:23:23 --> Output Class Initialized
INFO - 2023-08-29 07:23:23 --> Security Class Initialized
DEBUG - 2023-08-29 07:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:23:23 --> Input Class Initialized
INFO - 2023-08-29 07:23:23 --> Language Class Initialized
INFO - 2023-08-29 07:23:23 --> Loader Class Initialized
INFO - 2023-08-29 07:23:23 --> Helper loaded: url_helper
INFO - 2023-08-29 07:23:23 --> Helper loaded: file_helper
INFO - 2023-08-29 07:23:23 --> Database Driver Class Initialized
INFO - 2023-08-29 07:23:23 --> Email Class Initialized
DEBUG - 2023-08-29 07:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:23:23 --> Controller Class Initialized
INFO - 2023-08-29 07:23:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-29 07:23:23 --> Final output sent to browser
DEBUG - 2023-08-29 07:23:23 --> Total execution time: 0.1298
INFO - 2023-08-29 07:23:24 --> Config Class Initialized
INFO - 2023-08-29 07:23:24 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:23:24 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:23:24 --> Utf8 Class Initialized
INFO - 2023-08-29 07:23:24 --> URI Class Initialized
INFO - 2023-08-29 07:23:24 --> Router Class Initialized
INFO - 2023-08-29 07:23:24 --> Output Class Initialized
INFO - 2023-08-29 07:23:24 --> Security Class Initialized
DEBUG - 2023-08-29 07:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:23:24 --> Input Class Initialized
INFO - 2023-08-29 07:23:24 --> Language Class Initialized
ERROR - 2023-08-29 07:23:24 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-29 07:24:18 --> Config Class Initialized
INFO - 2023-08-29 07:24:18 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:18 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:18 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:18 --> URI Class Initialized
INFO - 2023-08-29 07:24:18 --> Router Class Initialized
INFO - 2023-08-29 07:24:18 --> Output Class Initialized
INFO - 2023-08-29 07:24:18 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:18 --> Input Class Initialized
INFO - 2023-08-29 07:24:18 --> Language Class Initialized
INFO - 2023-08-29 07:24:19 --> Loader Class Initialized
INFO - 2023-08-29 07:24:19 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:19 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:19 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:19 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:19 --> Controller Class Initialized
INFO - 2023-08-29 07:24:20 --> Model "Banner_model" initialized
INFO - 2023-08-29 07:24:20 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:20 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-29 07:24:21 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:21 --> Total execution time: 2.5526
INFO - 2023-08-29 07:24:24 --> Config Class Initialized
INFO - 2023-08-29 07:24:24 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:24 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:24 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:24 --> URI Class Initialized
INFO - 2023-08-29 07:24:24 --> Router Class Initialized
INFO - 2023-08-29 07:24:24 --> Output Class Initialized
INFO - 2023-08-29 07:24:24 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:24 --> Input Class Initialized
INFO - 2023-08-29 07:24:24 --> Language Class Initialized
INFO - 2023-08-29 07:24:24 --> Loader Class Initialized
INFO - 2023-08-29 07:24:24 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:24 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:24 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:24 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:24 --> Controller Class Initialized
INFO - 2023-08-29 07:24:24 --> Model "Banner_model" initialized
INFO - 2023-08-29 07:24:24 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:24 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-29 07:24:24 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:24 --> Total execution time: 0.6995
INFO - 2023-08-29 07:24:25 --> Config Class Initialized
INFO - 2023-08-29 07:24:25 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:25 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:25 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:25 --> URI Class Initialized
INFO - 2023-08-29 07:24:25 --> Router Class Initialized
INFO - 2023-08-29 07:24:25 --> Output Class Initialized
INFO - 2023-08-29 07:24:25 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:25 --> Input Class Initialized
INFO - 2023-08-29 07:24:25 --> Language Class Initialized
ERROR - 2023-08-29 07:24:25 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-29 07:24:35 --> Config Class Initialized
INFO - 2023-08-29 07:24:35 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:35 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:35 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:35 --> URI Class Initialized
INFO - 2023-08-29 07:24:35 --> Router Class Initialized
INFO - 2023-08-29 07:24:35 --> Output Class Initialized
INFO - 2023-08-29 07:24:35 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:35 --> Input Class Initialized
INFO - 2023-08-29 07:24:35 --> Language Class Initialized
INFO - 2023-08-29 07:24:35 --> Loader Class Initialized
INFO - 2023-08-29 07:24:35 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:35 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:35 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:35 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:35 --> Controller Class Initialized
INFO - 2023-08-29 07:24:35 --> Model "Banner_model" initialized
INFO - 2023-08-29 07:24:35 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:35 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-29 07:24:35 --> Config Class Initialized
INFO - 2023-08-29 07:24:35 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:35 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:35 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:35 --> URI Class Initialized
INFO - 2023-08-29 07:24:35 --> Router Class Initialized
INFO - 2023-08-29 07:24:35 --> Output Class Initialized
INFO - 2023-08-29 07:24:35 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:35 --> Input Class Initialized
INFO - 2023-08-29 07:24:35 --> Language Class Initialized
INFO - 2023-08-29 07:24:35 --> Loader Class Initialized
INFO - 2023-08-29 07:24:35 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:35 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:35 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:35 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:35 --> Controller Class Initialized
INFO - 2023-08-29 07:24:35 --> Model "Banner_model" initialized
INFO - 2023-08-29 07:24:35 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:35 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-29 07:24:35 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:35 --> Total execution time: 0.0467
INFO - 2023-08-29 07:24:39 --> Config Class Initialized
INFO - 2023-08-29 07:24:39 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:39 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:39 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:39 --> URI Class Initialized
INFO - 2023-08-29 07:24:39 --> Router Class Initialized
INFO - 2023-08-29 07:24:39 --> Output Class Initialized
INFO - 2023-08-29 07:24:39 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:39 --> Input Class Initialized
INFO - 2023-08-29 07:24:39 --> Language Class Initialized
INFO - 2023-08-29 07:24:39 --> Loader Class Initialized
INFO - 2023-08-29 07:24:39 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:39 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:39 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:39 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:39 --> Controller Class Initialized
INFO - 2023-08-29 07:24:39 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:39 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:39 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-29 07:24:39 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:39 --> Total execution time: 0.1376
INFO - 2023-08-29 07:24:40 --> Config Class Initialized
INFO - 2023-08-29 07:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:40 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:40 --> URI Class Initialized
INFO - 2023-08-29 07:24:40 --> Router Class Initialized
INFO - 2023-08-29 07:24:40 --> Output Class Initialized
INFO - 2023-08-29 07:24:40 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:40 --> Input Class Initialized
INFO - 2023-08-29 07:24:40 --> Language Class Initialized
INFO - 2023-08-29 07:24:40 --> Loader Class Initialized
INFO - 2023-08-29 07:24:40 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:40 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:40 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:40 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:40 --> Controller Class Initialized
INFO - 2023-08-29 07:24:40 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:40 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:40 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-29 07:24:40 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:40 --> Total execution time: 0.0770
INFO - 2023-08-29 07:24:40 --> Config Class Initialized
INFO - 2023-08-29 07:24:40 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:40 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:40 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:40 --> URI Class Initialized
INFO - 2023-08-29 07:24:40 --> Router Class Initialized
INFO - 2023-08-29 07:24:40 --> Output Class Initialized
INFO - 2023-08-29 07:24:40 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:40 --> Input Class Initialized
INFO - 2023-08-29 07:24:40 --> Language Class Initialized
ERROR - 2023-08-29 07:24:40 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-29 07:24:45 --> Config Class Initialized
INFO - 2023-08-29 07:24:45 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:45 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:45 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:45 --> URI Class Initialized
INFO - 2023-08-29 07:24:45 --> Router Class Initialized
INFO - 2023-08-29 07:24:45 --> Output Class Initialized
INFO - 2023-08-29 07:24:45 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:45 --> Input Class Initialized
INFO - 2023-08-29 07:24:45 --> Language Class Initialized
INFO - 2023-08-29 07:24:45 --> Loader Class Initialized
INFO - 2023-08-29 07:24:45 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:45 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:45 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:45 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:45 --> Controller Class Initialized
INFO - 2023-08-29 07:24:45 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:45 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:45 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-29 07:24:45 --> Config Class Initialized
INFO - 2023-08-29 07:24:45 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:45 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:45 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:45 --> URI Class Initialized
INFO - 2023-08-29 07:24:45 --> Router Class Initialized
INFO - 2023-08-29 07:24:45 --> Output Class Initialized
INFO - 2023-08-29 07:24:45 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:45 --> Input Class Initialized
INFO - 2023-08-29 07:24:45 --> Language Class Initialized
INFO - 2023-08-29 07:24:45 --> Loader Class Initialized
INFO - 2023-08-29 07:24:45 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:45 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:45 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:45 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:45 --> Controller Class Initialized
INFO - 2023-08-29 07:24:45 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:45 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:45 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-29 07:24:45 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:45 --> Total execution time: 0.0431
INFO - 2023-08-29 07:24:51 --> Config Class Initialized
INFO - 2023-08-29 07:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:51 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:51 --> URI Class Initialized
INFO - 2023-08-29 07:24:51 --> Router Class Initialized
INFO - 2023-08-29 07:24:51 --> Output Class Initialized
INFO - 2023-08-29 07:24:51 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:51 --> Input Class Initialized
INFO - 2023-08-29 07:24:51 --> Language Class Initialized
INFO - 2023-08-29 07:24:51 --> Loader Class Initialized
INFO - 2023-08-29 07:24:51 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:51 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:51 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:51 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:51 --> Controller Class Initialized
INFO - 2023-08-29 07:24:51 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:51 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:51 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-29 07:24:51 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:51 --> Total execution time: 0.0598
INFO - 2023-08-29 07:24:51 --> Config Class Initialized
INFO - 2023-08-29 07:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:51 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:51 --> URI Class Initialized
INFO - 2023-08-29 07:24:51 --> Router Class Initialized
INFO - 2023-08-29 07:24:51 --> Output Class Initialized
INFO - 2023-08-29 07:24:51 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:51 --> Input Class Initialized
INFO - 2023-08-29 07:24:51 --> Language Class Initialized
INFO - 2023-08-29 07:24:51 --> Loader Class Initialized
INFO - 2023-08-29 07:24:51 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:51 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:51 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:51 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:51 --> Controller Class Initialized
INFO - 2023-08-29 07:24:51 --> Model "Blog_model" initialized
INFO - 2023-08-29 07:24:51 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:51 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-29 07:24:51 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:51 --> Total execution time: 0.0486
INFO - 2023-08-29 07:24:53 --> Config Class Initialized
INFO - 2023-08-29 07:24:53 --> Hooks Class Initialized
DEBUG - 2023-08-29 07:24:53 --> UTF-8 Support Enabled
INFO - 2023-08-29 07:24:53 --> Utf8 Class Initialized
INFO - 2023-08-29 07:24:53 --> URI Class Initialized
INFO - 2023-08-29 07:24:53 --> Router Class Initialized
INFO - 2023-08-29 07:24:53 --> Output Class Initialized
INFO - 2023-08-29 07:24:53 --> Security Class Initialized
DEBUG - 2023-08-29 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 07:24:53 --> Input Class Initialized
INFO - 2023-08-29 07:24:53 --> Language Class Initialized
INFO - 2023-08-29 07:24:53 --> Loader Class Initialized
INFO - 2023-08-29 07:24:53 --> Helper loaded: url_helper
INFO - 2023-08-29 07:24:53 --> Helper loaded: file_helper
INFO - 2023-08-29 07:24:53 --> Database Driver Class Initialized
INFO - 2023-08-29 07:24:53 --> Email Class Initialized
DEBUG - 2023-08-29 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 07:24:53 --> Controller Class Initialized
INFO - 2023-08-29 07:24:53 --> Model "Banner_model" initialized
INFO - 2023-08-29 07:24:53 --> Helper loaded: form_helper
INFO - 2023-08-29 07:24:53 --> Form Validation Class Initialized
INFO - 2023-08-29 07:24:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-29 07:24:53 --> Final output sent to browser
DEBUG - 2023-08-29 07:24:53 --> Total execution time: 0.0446
