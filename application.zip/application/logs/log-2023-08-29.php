<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-29 17:52:36 --> Config Class Initialized
INFO - 2023-08-29 17:52:36 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:36 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:36 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:36 --> URI Class Initialized
DEBUG - 2023-08-29 17:52:36 --> No URI present. Default controller set.
INFO - 2023-08-29 17:52:36 --> Router Class Initialized
INFO - 2023-08-29 17:52:36 --> Output Class Initialized
INFO - 2023-08-29 17:52:36 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:36 --> Input Class Initialized
INFO - 2023-08-29 17:52:36 --> Language Class Initialized
INFO - 2023-08-29 17:52:36 --> Loader Class Initialized
INFO - 2023-08-29 17:52:36 --> Helper loaded: url_helper
INFO - 2023-08-29 17:52:36 --> Helper loaded: file_helper
INFO - 2023-08-29 17:52:36 --> Database Driver Class Initialized
INFO - 2023-08-29 17:52:36 --> Email Class Initialized
DEBUG - 2023-08-29 17:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 17:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 17:52:36 --> Controller Class Initialized
INFO - 2023-08-29 17:52:36 --> Model "Contact_model" initialized
INFO - 2023-08-29 17:52:36 --> Model "Home_model" initialized
INFO - 2023-08-29 17:52:36 --> Helper loaded: download_helper
INFO - 2023-08-29 17:52:36 --> Helper loaded: form_helper
INFO - 2023-08-29 17:52:36 --> Form Validation Class Initialized
INFO - 2023-08-29 17:52:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-29 17:52:36 --> Final output sent to browser
DEBUG - 2023-08-29 17:52:36 --> Total execution time: 0.3787
INFO - 2023-08-29 17:52:39 --> Config Class Initialized
INFO - 2023-08-29 17:52:39 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:39 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:39 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:39 --> URI Class Initialized
INFO - 2023-08-29 17:52:39 --> Router Class Initialized
INFO - 2023-08-29 17:52:39 --> Output Class Initialized
INFO - 2023-08-29 17:52:39 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:39 --> Input Class Initialized
INFO - 2023-08-29 17:52:39 --> Language Class Initialized
ERROR - 2023-08-29 17:52:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 17:52:39 --> Config Class Initialized
INFO - 2023-08-29 17:52:39 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:39 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:39 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:39 --> URI Class Initialized
INFO - 2023-08-29 17:52:39 --> Router Class Initialized
INFO - 2023-08-29 17:52:39 --> Output Class Initialized
INFO - 2023-08-29 17:52:39 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:39 --> Input Class Initialized
INFO - 2023-08-29 17:52:39 --> Language Class Initialized
ERROR - 2023-08-29 17:52:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 17:52:42 --> Config Class Initialized
INFO - 2023-08-29 17:52:42 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:42 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:42 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:42 --> URI Class Initialized
INFO - 2023-08-29 17:52:42 --> Router Class Initialized
INFO - 2023-08-29 17:52:42 --> Output Class Initialized
INFO - 2023-08-29 17:52:42 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:42 --> Input Class Initialized
INFO - 2023-08-29 17:52:42 --> Language Class Initialized
INFO - 2023-08-29 17:52:42 --> Loader Class Initialized
INFO - 2023-08-29 17:52:42 --> Helper loaded: url_helper
INFO - 2023-08-29 17:52:42 --> Helper loaded: file_helper
INFO - 2023-08-29 17:52:42 --> Database Driver Class Initialized
INFO - 2023-08-29 17:52:42 --> Email Class Initialized
DEBUG - 2023-08-29 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 17:52:42 --> Controller Class Initialized
INFO - 2023-08-29 17:52:42 --> Model "Contact_model" initialized
INFO - 2023-08-29 17:52:42 --> Model "Home_model" initialized
INFO - 2023-08-29 17:52:42 --> Helper loaded: download_helper
INFO - 2023-08-29 17:52:42 --> Helper loaded: form_helper
INFO - 2023-08-29 17:52:42 --> Form Validation Class Initialized
INFO - 2023-08-29 17:52:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-29 17:52:43 --> Final output sent to browser
DEBUG - 2023-08-29 17:52:43 --> Total execution time: 0.3530
INFO - 2023-08-29 17:52:44 --> Config Class Initialized
INFO - 2023-08-29 17:52:44 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:44 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:44 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:44 --> URI Class Initialized
INFO - 2023-08-29 17:52:44 --> Router Class Initialized
INFO - 2023-08-29 17:52:44 --> Output Class Initialized
INFO - 2023-08-29 17:52:44 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:44 --> Input Class Initialized
INFO - 2023-08-29 17:52:44 --> Language Class Initialized
ERROR - 2023-08-29 17:52:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 17:52:44 --> Config Class Initialized
INFO - 2023-08-29 17:52:44 --> Hooks Class Initialized
DEBUG - 2023-08-29 17:52:44 --> UTF-8 Support Enabled
INFO - 2023-08-29 17:52:44 --> Utf8 Class Initialized
INFO - 2023-08-29 17:52:44 --> URI Class Initialized
INFO - 2023-08-29 17:52:44 --> Router Class Initialized
INFO - 2023-08-29 17:52:44 --> Output Class Initialized
INFO - 2023-08-29 17:52:44 --> Security Class Initialized
DEBUG - 2023-08-29 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 17:52:44 --> Input Class Initialized
INFO - 2023-08-29 17:52:44 --> Language Class Initialized
ERROR - 2023-08-29 17:52:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 18:36:41 --> Config Class Initialized
INFO - 2023-08-29 18:36:41 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:36:41 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:36:41 --> Utf8 Class Initialized
INFO - 2023-08-29 18:36:41 --> URI Class Initialized
INFO - 2023-08-29 18:36:41 --> Router Class Initialized
INFO - 2023-08-29 18:36:41 --> Output Class Initialized
INFO - 2023-08-29 18:36:41 --> Security Class Initialized
DEBUG - 2023-08-29 18:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:36:41 --> Input Class Initialized
INFO - 2023-08-29 18:36:41 --> Language Class Initialized
INFO - 2023-08-29 18:36:41 --> Loader Class Initialized
INFO - 2023-08-29 18:36:41 --> Helper loaded: url_helper
INFO - 2023-08-29 18:36:41 --> Helper loaded: file_helper
INFO - 2023-08-29 18:36:41 --> Database Driver Class Initialized
INFO - 2023-08-29 18:36:41 --> Email Class Initialized
DEBUG - 2023-08-29 18:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:36:41 --> Controller Class Initialized
INFO - 2023-08-29 18:36:41 --> Model "Contact_model" initialized
INFO - 2023-08-29 18:36:41 --> Model "Home_model" initialized
INFO - 2023-08-29 18:36:41 --> Helper loaded: download_helper
INFO - 2023-08-29 18:36:41 --> Helper loaded: form_helper
INFO - 2023-08-29 18:36:41 --> Form Validation Class Initialized
INFO - 2023-08-29 18:36:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-29 18:36:41 --> Final output sent to browser
DEBUG - 2023-08-29 18:36:41 --> Total execution time: 4.9118
INFO - 2023-08-29 18:36:43 --> Config Class Initialized
INFO - 2023-08-29 18:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:36:43 --> Utf8 Class Initialized
INFO - 2023-08-29 18:36:43 --> URI Class Initialized
INFO - 2023-08-29 18:36:43 --> Router Class Initialized
INFO - 2023-08-29 18:36:43 --> Output Class Initialized
INFO - 2023-08-29 18:36:43 --> Security Class Initialized
DEBUG - 2023-08-29 18:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:36:43 --> Input Class Initialized
INFO - 2023-08-29 18:36:43 --> Language Class Initialized
ERROR - 2023-08-29 18:36:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 18:36:43 --> Config Class Initialized
INFO - 2023-08-29 18:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:36:43 --> Utf8 Class Initialized
INFO - 2023-08-29 18:36:43 --> URI Class Initialized
INFO - 2023-08-29 18:36:43 --> Router Class Initialized
INFO - 2023-08-29 18:36:43 --> Output Class Initialized
INFO - 2023-08-29 18:36:43 --> Security Class Initialized
DEBUG - 2023-08-29 18:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:36:43 --> Input Class Initialized
INFO - 2023-08-29 18:36:43 --> Language Class Initialized
ERROR - 2023-08-29 18:36:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 18:38:34 --> Config Class Initialized
INFO - 2023-08-29 18:38:34 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:34 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:34 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:34 --> URI Class Initialized
INFO - 2023-08-29 18:38:34 --> Router Class Initialized
INFO - 2023-08-29 18:38:34 --> Output Class Initialized
INFO - 2023-08-29 18:38:34 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:34 --> Input Class Initialized
INFO - 2023-08-29 18:38:34 --> Language Class Initialized
INFO - 2023-08-29 18:38:34 --> Loader Class Initialized
INFO - 2023-08-29 18:38:34 --> Helper loaded: url_helper
INFO - 2023-08-29 18:38:34 --> Helper loaded: file_helper
INFO - 2023-08-29 18:38:34 --> Database Driver Class Initialized
INFO - 2023-08-29 18:38:34 --> Email Class Initialized
DEBUG - 2023-08-29 18:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:38:34 --> Controller Class Initialized
INFO - 2023-08-29 18:38:34 --> Model "User_model" initialized
INFO - 2023-08-29 18:38:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-29 18:38:34 --> Final output sent to browser
DEBUG - 2023-08-29 18:38:34 --> Total execution time: 0.1666
INFO - 2023-08-29 18:38:39 --> Config Class Initialized
INFO - 2023-08-29 18:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:39 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:39 --> URI Class Initialized
INFO - 2023-08-29 18:38:39 --> Router Class Initialized
INFO - 2023-08-29 18:38:39 --> Output Class Initialized
INFO - 2023-08-29 18:38:39 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:39 --> Input Class Initialized
INFO - 2023-08-29 18:38:39 --> Language Class Initialized
ERROR - 2023-08-29 18:38:39 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-29 18:38:47 --> Config Class Initialized
INFO - 2023-08-29 18:38:47 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:47 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:47 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:47 --> URI Class Initialized
INFO - 2023-08-29 18:38:47 --> Router Class Initialized
INFO - 2023-08-29 18:38:47 --> Output Class Initialized
INFO - 2023-08-29 18:38:47 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:47 --> Input Class Initialized
INFO - 2023-08-29 18:38:47 --> Language Class Initialized
INFO - 2023-08-29 18:38:47 --> Loader Class Initialized
INFO - 2023-08-29 18:38:47 --> Helper loaded: url_helper
INFO - 2023-08-29 18:38:47 --> Helper loaded: file_helper
INFO - 2023-08-29 18:38:47 --> Database Driver Class Initialized
INFO - 2023-08-29 18:38:47 --> Email Class Initialized
DEBUG - 2023-08-29 18:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:38:47 --> Controller Class Initialized
INFO - 2023-08-29 18:38:47 --> Model "User_model" initialized
INFO - 2023-08-29 18:38:47 --> Config Class Initialized
INFO - 2023-08-29 18:38:47 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:47 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:47 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:47 --> URI Class Initialized
INFO - 2023-08-29 18:38:47 --> Router Class Initialized
INFO - 2023-08-29 18:38:47 --> Output Class Initialized
INFO - 2023-08-29 18:38:47 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:47 --> Input Class Initialized
INFO - 2023-08-29 18:38:47 --> Language Class Initialized
INFO - 2023-08-29 18:38:47 --> Loader Class Initialized
INFO - 2023-08-29 18:38:47 --> Helper loaded: url_helper
INFO - 2023-08-29 18:38:47 --> Helper loaded: file_helper
INFO - 2023-08-29 18:38:47 --> Database Driver Class Initialized
INFO - 2023-08-29 18:38:47 --> Email Class Initialized
DEBUG - 2023-08-29 18:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:38:47 --> Controller Class Initialized
INFO - 2023-08-29 18:38:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-29 18:38:47 --> Final output sent to browser
DEBUG - 2023-08-29 18:38:47 --> Total execution time: 0.0345
INFO - 2023-08-29 18:38:55 --> Config Class Initialized
INFO - 2023-08-29 18:38:55 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:55 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:55 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:55 --> URI Class Initialized
INFO - 2023-08-29 18:38:55 --> Router Class Initialized
INFO - 2023-08-29 18:38:55 --> Output Class Initialized
INFO - 2023-08-29 18:38:55 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:55 --> Input Class Initialized
INFO - 2023-08-29 18:38:55 --> Language Class Initialized
INFO - 2023-08-29 18:38:55 --> Loader Class Initialized
INFO - 2023-08-29 18:38:55 --> Helper loaded: url_helper
INFO - 2023-08-29 18:38:55 --> Helper loaded: file_helper
INFO - 2023-08-29 18:38:55 --> Database Driver Class Initialized
INFO - 2023-08-29 18:38:55 --> Email Class Initialized
DEBUG - 2023-08-29 18:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:38:56 --> Controller Class Initialized
INFO - 2023-08-29 18:38:56 --> Model "Services_model" initialized
INFO - 2023-08-29 18:38:56 --> Helper loaded: form_helper
INFO - 2023-08-29 18:38:56 --> Form Validation Class Initialized
INFO - 2023-08-29 18:38:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-29 18:38:56 --> Final output sent to browser
DEBUG - 2023-08-29 18:38:56 --> Total execution time: 0.0549
INFO - 2023-08-29 18:38:59 --> Config Class Initialized
INFO - 2023-08-29 18:38:59 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:38:59 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:38:59 --> Utf8 Class Initialized
INFO - 2023-08-29 18:38:59 --> URI Class Initialized
INFO - 2023-08-29 18:38:59 --> Router Class Initialized
INFO - 2023-08-29 18:38:59 --> Output Class Initialized
INFO - 2023-08-29 18:38:59 --> Security Class Initialized
DEBUG - 2023-08-29 18:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:38:59 --> Input Class Initialized
INFO - 2023-08-29 18:38:59 --> Language Class Initialized
INFO - 2023-08-29 18:38:59 --> Loader Class Initialized
INFO - 2023-08-29 18:38:59 --> Helper loaded: url_helper
INFO - 2023-08-29 18:38:59 --> Helper loaded: file_helper
INFO - 2023-08-29 18:38:59 --> Database Driver Class Initialized
INFO - 2023-08-29 18:38:59 --> Email Class Initialized
DEBUG - 2023-08-29 18:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:38:59 --> Controller Class Initialized
INFO - 2023-08-29 18:38:59 --> Model "Services_model" initialized
INFO - 2023-08-29 18:38:59 --> Helper loaded: form_helper
INFO - 2023-08-29 18:38:59 --> Form Validation Class Initialized
INFO - 2023-08-29 18:38:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-29 18:38:59 --> Final output sent to browser
DEBUG - 2023-08-29 18:38:59 --> Total execution time: 0.0448
INFO - 2023-08-29 18:39:01 --> Config Class Initialized
INFO - 2023-08-29 18:39:01 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:39:01 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:39:01 --> Utf8 Class Initialized
INFO - 2023-08-29 18:39:01 --> URI Class Initialized
INFO - 2023-08-29 18:39:01 --> Router Class Initialized
INFO - 2023-08-29 18:39:01 --> Output Class Initialized
INFO - 2023-08-29 18:39:01 --> Security Class Initialized
DEBUG - 2023-08-29 18:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:39:01 --> Input Class Initialized
INFO - 2023-08-29 18:39:01 --> Language Class Initialized
INFO - 2023-08-29 18:39:01 --> Loader Class Initialized
INFO - 2023-08-29 18:39:01 --> Helper loaded: url_helper
INFO - 2023-08-29 18:39:01 --> Helper loaded: file_helper
INFO - 2023-08-29 18:39:01 --> Database Driver Class Initialized
INFO - 2023-08-29 18:39:01 --> Email Class Initialized
DEBUG - 2023-08-29 18:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:39:01 --> Controller Class Initialized
INFO - 2023-08-29 18:39:01 --> Model "Services_model" initialized
INFO - 2023-08-29 18:39:01 --> Helper loaded: form_helper
INFO - 2023-08-29 18:39:01 --> Form Validation Class Initialized
INFO - 2023-08-29 18:39:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-29 18:39:01 --> Final output sent to browser
DEBUG - 2023-08-29 18:39:01 --> Total execution time: 0.0524
INFO - 2023-08-29 18:39:03 --> Config Class Initialized
INFO - 2023-08-29 18:39:03 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:39:03 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:39:03 --> Utf8 Class Initialized
INFO - 2023-08-29 18:39:03 --> URI Class Initialized
INFO - 2023-08-29 18:39:03 --> Router Class Initialized
INFO - 2023-08-29 18:39:03 --> Output Class Initialized
INFO - 2023-08-29 18:39:03 --> Security Class Initialized
DEBUG - 2023-08-29 18:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:39:03 --> Input Class Initialized
INFO - 2023-08-29 18:39:03 --> Language Class Initialized
INFO - 2023-08-29 18:39:03 --> Loader Class Initialized
INFO - 2023-08-29 18:39:03 --> Helper loaded: url_helper
INFO - 2023-08-29 18:39:03 --> Helper loaded: file_helper
INFO - 2023-08-29 18:39:03 --> Database Driver Class Initialized
INFO - 2023-08-29 18:39:03 --> Email Class Initialized
DEBUG - 2023-08-29 18:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:39:03 --> Controller Class Initialized
INFO - 2023-08-29 18:39:03 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:39:03 --> Helper loaded: form_helper
INFO - 2023-08-29 18:39:03 --> Form Validation Class Initialized
INFO - 2023-08-29 18:39:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-29 18:39:03 --> Final output sent to browser
DEBUG - 2023-08-29 18:39:03 --> Total execution time: 0.0502
INFO - 2023-08-29 18:39:07 --> Config Class Initialized
INFO - 2023-08-29 18:39:07 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:39:07 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:39:07 --> Utf8 Class Initialized
INFO - 2023-08-29 18:39:07 --> URI Class Initialized
INFO - 2023-08-29 18:39:07 --> Router Class Initialized
INFO - 2023-08-29 18:39:07 --> Output Class Initialized
INFO - 2023-08-29 18:39:07 --> Security Class Initialized
DEBUG - 2023-08-29 18:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:39:07 --> Input Class Initialized
INFO - 2023-08-29 18:39:07 --> Language Class Initialized
INFO - 2023-08-29 18:39:07 --> Loader Class Initialized
INFO - 2023-08-29 18:39:07 --> Helper loaded: url_helper
INFO - 2023-08-29 18:39:07 --> Helper loaded: file_helper
INFO - 2023-08-29 18:39:07 --> Database Driver Class Initialized
INFO - 2023-08-29 18:39:07 --> Email Class Initialized
DEBUG - 2023-08-29 18:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:39:07 --> Controller Class Initialized
INFO - 2023-08-29 18:39:07 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:39:07 --> Helper loaded: form_helper
INFO - 2023-08-29 18:39:07 --> Form Validation Class Initialized
INFO - 2023-08-29 18:39:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:39:07 --> Final output sent to browser
DEBUG - 2023-08-29 18:39:07 --> Total execution time: 0.0464
INFO - 2023-08-29 18:39:12 --> Config Class Initialized
INFO - 2023-08-29 18:39:12 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:39:12 --> Utf8 Class Initialized
INFO - 2023-08-29 18:39:12 --> URI Class Initialized
INFO - 2023-08-29 18:39:12 --> Router Class Initialized
INFO - 2023-08-29 18:39:12 --> Output Class Initialized
INFO - 2023-08-29 18:39:12 --> Security Class Initialized
DEBUG - 2023-08-29 18:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:39:12 --> Input Class Initialized
INFO - 2023-08-29 18:39:12 --> Language Class Initialized
INFO - 2023-08-29 18:39:12 --> Loader Class Initialized
INFO - 2023-08-29 18:39:12 --> Helper loaded: url_helper
INFO - 2023-08-29 18:39:12 --> Helper loaded: file_helper
INFO - 2023-08-29 18:39:12 --> Database Driver Class Initialized
INFO - 2023-08-29 18:39:12 --> Email Class Initialized
DEBUG - 2023-08-29 18:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:39:12 --> Controller Class Initialized
INFO - 2023-08-29 18:39:12 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:39:12 --> Helper loaded: form_helper
INFO - 2023-08-29 18:39:12 --> Form Validation Class Initialized
INFO - 2023-08-29 18:39:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:39:12 --> Final output sent to browser
DEBUG - 2023-08-29 18:39:12 --> Total execution time: 0.0634
INFO - 2023-08-29 18:40:27 --> Config Class Initialized
INFO - 2023-08-29 18:40:27 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:40:27 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:40:27 --> Utf8 Class Initialized
INFO - 2023-08-29 18:40:27 --> URI Class Initialized
INFO - 2023-08-29 18:40:27 --> Router Class Initialized
INFO - 2023-08-29 18:40:27 --> Output Class Initialized
INFO - 2023-08-29 18:40:27 --> Security Class Initialized
DEBUG - 2023-08-29 18:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:40:27 --> Input Class Initialized
INFO - 2023-08-29 18:40:27 --> Language Class Initialized
INFO - 2023-08-29 18:40:27 --> Loader Class Initialized
INFO - 2023-08-29 18:40:27 --> Helper loaded: url_helper
INFO - 2023-08-29 18:40:27 --> Helper loaded: file_helper
INFO - 2023-08-29 18:40:27 --> Database Driver Class Initialized
INFO - 2023-08-29 18:40:28 --> Email Class Initialized
DEBUG - 2023-08-29 18:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:40:28 --> Controller Class Initialized
INFO - 2023-08-29 18:40:28 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:40:28 --> Helper loaded: form_helper
INFO - 2023-08-29 18:40:28 --> Form Validation Class Initialized
INFO - 2023-08-29 18:40:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:40:28 --> Final output sent to browser
DEBUG - 2023-08-29 18:40:28 --> Total execution time: 0.7262
INFO - 2023-08-29 18:40:29 --> Config Class Initialized
INFO - 2023-08-29 18:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:40:29 --> Utf8 Class Initialized
INFO - 2023-08-29 18:40:29 --> URI Class Initialized
INFO - 2023-08-29 18:40:29 --> Router Class Initialized
INFO - 2023-08-29 18:40:29 --> Output Class Initialized
INFO - 2023-08-29 18:40:29 --> Security Class Initialized
DEBUG - 2023-08-29 18:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:40:29 --> Input Class Initialized
INFO - 2023-08-29 18:40:29 --> Language Class Initialized
INFO - 2023-08-29 18:40:29 --> Loader Class Initialized
INFO - 2023-08-29 18:40:29 --> Helper loaded: url_helper
INFO - 2023-08-29 18:40:29 --> Helper loaded: file_helper
INFO - 2023-08-29 18:40:29 --> Database Driver Class Initialized
INFO - 2023-08-29 18:40:29 --> Email Class Initialized
DEBUG - 2023-08-29 18:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:40:29 --> Controller Class Initialized
INFO - 2023-08-29 18:40:29 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:40:29 --> Helper loaded: form_helper
INFO - 2023-08-29 18:40:29 --> Form Validation Class Initialized
INFO - 2023-08-29 18:40:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:40:29 --> Final output sent to browser
DEBUG - 2023-08-29 18:40:29 --> Total execution time: 0.0521
INFO - 2023-08-29 18:42:01 --> Config Class Initialized
INFO - 2023-08-29 18:42:01 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:42:01 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:42:01 --> Utf8 Class Initialized
INFO - 2023-08-29 18:42:01 --> URI Class Initialized
INFO - 2023-08-29 18:42:01 --> Router Class Initialized
INFO - 2023-08-29 18:42:01 --> Output Class Initialized
INFO - 2023-08-29 18:42:01 --> Security Class Initialized
DEBUG - 2023-08-29 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:42:01 --> Input Class Initialized
INFO - 2023-08-29 18:42:01 --> Language Class Initialized
INFO - 2023-08-29 18:42:01 --> Loader Class Initialized
INFO - 2023-08-29 18:42:01 --> Helper loaded: url_helper
INFO - 2023-08-29 18:42:01 --> Helper loaded: file_helper
INFO - 2023-08-29 18:42:01 --> Database Driver Class Initialized
INFO - 2023-08-29 18:42:01 --> Email Class Initialized
DEBUG - 2023-08-29 18:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:42:01 --> Controller Class Initialized
INFO - 2023-08-29 18:42:01 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:42:01 --> Helper loaded: form_helper
INFO - 2023-08-29 18:42:02 --> Form Validation Class Initialized
INFO - 2023-08-29 18:42:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:42:02 --> Final output sent to browser
DEBUG - 2023-08-29 18:42:02 --> Total execution time: 0.7729
INFO - 2023-08-29 18:42:03 --> Config Class Initialized
INFO - 2023-08-29 18:42:03 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:42:03 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:42:03 --> Utf8 Class Initialized
INFO - 2023-08-29 18:42:03 --> URI Class Initialized
INFO - 2023-08-29 18:42:03 --> Router Class Initialized
INFO - 2023-08-29 18:42:03 --> Output Class Initialized
INFO - 2023-08-29 18:42:03 --> Security Class Initialized
DEBUG - 2023-08-29 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:42:03 --> Input Class Initialized
INFO - 2023-08-29 18:42:03 --> Language Class Initialized
INFO - 2023-08-29 18:42:03 --> Loader Class Initialized
INFO - 2023-08-29 18:42:03 --> Helper loaded: url_helper
INFO - 2023-08-29 18:42:03 --> Helper loaded: file_helper
INFO - 2023-08-29 18:42:03 --> Database Driver Class Initialized
INFO - 2023-08-29 18:42:03 --> Email Class Initialized
DEBUG - 2023-08-29 18:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:42:03 --> Controller Class Initialized
INFO - 2023-08-29 18:42:03 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:42:03 --> Helper loaded: form_helper
INFO - 2023-08-29 18:42:03 --> Form Validation Class Initialized
INFO - 2023-08-29 18:42:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:42:03 --> Final output sent to browser
DEBUG - 2023-08-29 18:42:03 --> Total execution time: 0.0500
INFO - 2023-08-29 18:44:41 --> Config Class Initialized
INFO - 2023-08-29 18:44:42 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:44:42 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:44:42 --> Utf8 Class Initialized
INFO - 2023-08-29 18:44:42 --> URI Class Initialized
INFO - 2023-08-29 18:44:42 --> Router Class Initialized
INFO - 2023-08-29 18:44:42 --> Output Class Initialized
INFO - 2023-08-29 18:44:42 --> Security Class Initialized
DEBUG - 2023-08-29 18:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:44:42 --> Input Class Initialized
INFO - 2023-08-29 18:44:42 --> Language Class Initialized
INFO - 2023-08-29 18:44:42 --> Loader Class Initialized
INFO - 2023-08-29 18:44:42 --> Helper loaded: url_helper
INFO - 2023-08-29 18:44:42 --> Helper loaded: file_helper
INFO - 2023-08-29 18:44:42 --> Database Driver Class Initialized
INFO - 2023-08-29 18:44:42 --> Email Class Initialized
DEBUG - 2023-08-29 18:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:44:42 --> Controller Class Initialized
INFO - 2023-08-29 18:44:42 --> Model "Services_model" initialized
INFO - 2023-08-29 18:44:42 --> Helper loaded: form_helper
INFO - 2023-08-29 18:44:42 --> Form Validation Class Initialized
INFO - 2023-08-29 18:44:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-29 18:44:42 --> Final output sent to browser
DEBUG - 2023-08-29 18:44:42 --> Total execution time: 0.3812
INFO - 2023-08-29 18:44:45 --> Config Class Initialized
INFO - 2023-08-29 18:44:45 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:44:45 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:44:45 --> Utf8 Class Initialized
INFO - 2023-08-29 18:44:45 --> URI Class Initialized
INFO - 2023-08-29 18:44:45 --> Router Class Initialized
INFO - 2023-08-29 18:44:45 --> Output Class Initialized
INFO - 2023-08-29 18:44:45 --> Security Class Initialized
DEBUG - 2023-08-29 18:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:44:45 --> Input Class Initialized
INFO - 2023-08-29 18:44:45 --> Language Class Initialized
INFO - 2023-08-29 18:44:45 --> Loader Class Initialized
INFO - 2023-08-29 18:44:45 --> Helper loaded: url_helper
INFO - 2023-08-29 18:44:45 --> Helper loaded: file_helper
INFO - 2023-08-29 18:44:45 --> Database Driver Class Initialized
INFO - 2023-08-29 18:44:45 --> Email Class Initialized
DEBUG - 2023-08-29 18:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:44:45 --> Controller Class Initialized
INFO - 2023-08-29 18:44:45 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:44:45 --> Helper loaded: form_helper
INFO - 2023-08-29 18:44:45 --> Form Validation Class Initialized
INFO - 2023-08-29 18:44:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-29 18:44:45 --> Final output sent to browser
DEBUG - 2023-08-29 18:44:45 --> Total execution time: 0.4215
INFO - 2023-08-29 18:44:46 --> Config Class Initialized
INFO - 2023-08-29 18:44:46 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:44:46 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:44:46 --> Utf8 Class Initialized
INFO - 2023-08-29 18:44:46 --> URI Class Initialized
INFO - 2023-08-29 18:44:46 --> Router Class Initialized
INFO - 2023-08-29 18:44:46 --> Output Class Initialized
INFO - 2023-08-29 18:44:46 --> Security Class Initialized
DEBUG - 2023-08-29 18:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:44:46 --> Input Class Initialized
INFO - 2023-08-29 18:44:46 --> Language Class Initialized
ERROR - 2023-08-29 18:44:46 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-08-29 18:44:48 --> Config Class Initialized
INFO - 2023-08-29 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:44:48 --> Utf8 Class Initialized
INFO - 2023-08-29 18:44:48 --> URI Class Initialized
INFO - 2023-08-29 18:44:48 --> Router Class Initialized
INFO - 2023-08-29 18:44:48 --> Output Class Initialized
INFO - 2023-08-29 18:44:48 --> Security Class Initialized
DEBUG - 2023-08-29 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:44:48 --> Input Class Initialized
INFO - 2023-08-29 18:44:48 --> Language Class Initialized
INFO - 2023-08-29 18:44:48 --> Loader Class Initialized
INFO - 2023-08-29 18:44:48 --> Helper loaded: url_helper
INFO - 2023-08-29 18:44:48 --> Helper loaded: file_helper
INFO - 2023-08-29 18:44:48 --> Database Driver Class Initialized
INFO - 2023-08-29 18:44:49 --> Email Class Initialized
DEBUG - 2023-08-29 18:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:44:49 --> Controller Class Initialized
INFO - 2023-08-29 18:44:49 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:44:49 --> Helper loaded: form_helper
INFO - 2023-08-29 18:44:49 --> Form Validation Class Initialized
INFO - 2023-08-29 18:44:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:44:49 --> Final output sent to browser
DEBUG - 2023-08-29 18:44:49 --> Total execution time: 0.4381
INFO - 2023-08-29 18:44:49 --> Config Class Initialized
INFO - 2023-08-29 18:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:44:49 --> Utf8 Class Initialized
INFO - 2023-08-29 18:44:49 --> URI Class Initialized
INFO - 2023-08-29 18:44:50 --> Router Class Initialized
INFO - 2023-08-29 18:44:50 --> Output Class Initialized
INFO - 2023-08-29 18:44:50 --> Security Class Initialized
DEBUG - 2023-08-29 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:44:50 --> Input Class Initialized
INFO - 2023-08-29 18:44:50 --> Language Class Initialized
INFO - 2023-08-29 18:44:50 --> Loader Class Initialized
INFO - 2023-08-29 18:44:50 --> Helper loaded: url_helper
INFO - 2023-08-29 18:44:50 --> Helper loaded: file_helper
INFO - 2023-08-29 18:44:50 --> Database Driver Class Initialized
INFO - 2023-08-29 18:44:50 --> Email Class Initialized
DEBUG - 2023-08-29 18:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:44:50 --> Controller Class Initialized
INFO - 2023-08-29 18:44:50 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:44:50 --> Helper loaded: form_helper
INFO - 2023-08-29 18:44:50 --> Form Validation Class Initialized
INFO - 2023-08-29 18:44:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-08-29 18:44:50 --> Final output sent to browser
DEBUG - 2023-08-29 18:44:50 --> Total execution time: 0.4858
INFO - 2023-08-29 18:45:10 --> Config Class Initialized
INFO - 2023-08-29 18:45:10 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:10 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:10 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:10 --> URI Class Initialized
INFO - 2023-08-29 18:45:10 --> Router Class Initialized
INFO - 2023-08-29 18:45:10 --> Output Class Initialized
INFO - 2023-08-29 18:45:10 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:11 --> Input Class Initialized
INFO - 2023-08-29 18:45:11 --> Language Class Initialized
INFO - 2023-08-29 18:45:11 --> Loader Class Initialized
INFO - 2023-08-29 18:45:11 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:11 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:11 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:11 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:11 --> Controller Class Initialized
INFO - 2023-08-29 18:45:11 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:11 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:11 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-29 18:45:11 --> Config Class Initialized
INFO - 2023-08-29 18:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:11 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:11 --> URI Class Initialized
INFO - 2023-08-29 18:45:11 --> Router Class Initialized
INFO - 2023-08-29 18:45:11 --> Output Class Initialized
INFO - 2023-08-29 18:45:11 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:11 --> Input Class Initialized
INFO - 2023-08-29 18:45:11 --> Language Class Initialized
INFO - 2023-08-29 18:45:11 --> Loader Class Initialized
INFO - 2023-08-29 18:45:11 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:11 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:11 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:11 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:11 --> Controller Class Initialized
INFO - 2023-08-29 18:45:11 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:11 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:11 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-29 18:45:11 --> Final output sent to browser
DEBUG - 2023-08-29 18:45:11 --> Total execution time: 0.5575
INFO - 2023-08-29 18:45:15 --> Config Class Initialized
INFO - 2023-08-29 18:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:15 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:15 --> URI Class Initialized
INFO - 2023-08-29 18:45:15 --> Router Class Initialized
INFO - 2023-08-29 18:45:15 --> Output Class Initialized
INFO - 2023-08-29 18:45:15 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:15 --> Input Class Initialized
INFO - 2023-08-29 18:45:15 --> Language Class Initialized
INFO - 2023-08-29 18:45:16 --> Loader Class Initialized
INFO - 2023-08-29 18:45:16 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:16 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:16 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:16 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:16 --> Controller Class Initialized
INFO - 2023-08-29 18:45:16 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:16 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:16 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-29 18:45:16 --> Final output sent to browser
DEBUG - 2023-08-29 18:45:16 --> Total execution time: 0.4872
INFO - 2023-08-29 18:45:17 --> Config Class Initialized
INFO - 2023-08-29 18:45:17 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:17 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:17 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:17 --> URI Class Initialized
INFO - 2023-08-29 18:45:17 --> Router Class Initialized
INFO - 2023-08-29 18:45:17 --> Output Class Initialized
INFO - 2023-08-29 18:45:17 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:17 --> Input Class Initialized
INFO - 2023-08-29 18:45:17 --> Language Class Initialized
INFO - 2023-08-29 18:45:17 --> Loader Class Initialized
INFO - 2023-08-29 18:45:17 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:17 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:17 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:17 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:17 --> Controller Class Initialized
INFO - 2023-08-29 18:45:17 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:17 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:17 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-08-29 18:45:17 --> Final output sent to browser
DEBUG - 2023-08-29 18:45:17 --> Total execution time: 0.4332
INFO - 2023-08-29 18:45:26 --> Config Class Initialized
INFO - 2023-08-29 18:45:26 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:26 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:26 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:26 --> URI Class Initialized
INFO - 2023-08-29 18:45:26 --> Router Class Initialized
INFO - 2023-08-29 18:45:26 --> Output Class Initialized
INFO - 2023-08-29 18:45:26 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:26 --> Input Class Initialized
INFO - 2023-08-29 18:45:26 --> Language Class Initialized
INFO - 2023-08-29 18:45:26 --> Loader Class Initialized
INFO - 2023-08-29 18:45:26 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:26 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:26 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:27 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:27 --> Controller Class Initialized
INFO - 2023-08-29 18:45:27 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:27 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:27 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-29 18:45:27 --> Config Class Initialized
INFO - 2023-08-29 18:45:27 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:45:27 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:45:27 --> Utf8 Class Initialized
INFO - 2023-08-29 18:45:27 --> URI Class Initialized
INFO - 2023-08-29 18:45:27 --> Router Class Initialized
INFO - 2023-08-29 18:45:27 --> Output Class Initialized
INFO - 2023-08-29 18:45:27 --> Security Class Initialized
DEBUG - 2023-08-29 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:45:27 --> Input Class Initialized
INFO - 2023-08-29 18:45:27 --> Language Class Initialized
INFO - 2023-08-29 18:45:27 --> Loader Class Initialized
INFO - 2023-08-29 18:45:27 --> Helper loaded: url_helper
INFO - 2023-08-29 18:45:27 --> Helper loaded: file_helper
INFO - 2023-08-29 18:45:27 --> Database Driver Class Initialized
INFO - 2023-08-29 18:45:27 --> Email Class Initialized
DEBUG - 2023-08-29 18:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:45:27 --> Controller Class Initialized
INFO - 2023-08-29 18:45:27 --> Model "Services_cards_model" initialized
INFO - 2023-08-29 18:45:27 --> Helper loaded: form_helper
INFO - 2023-08-29 18:45:27 --> Form Validation Class Initialized
INFO - 2023-08-29 18:45:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-29 18:45:27 --> Final output sent to browser
DEBUG - 2023-08-29 18:45:27 --> Total execution time: 0.4668
INFO - 2023-08-29 18:53:56 --> Config Class Initialized
INFO - 2023-08-29 18:53:56 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:53:56 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:53:56 --> Utf8 Class Initialized
INFO - 2023-08-29 18:53:56 --> URI Class Initialized
INFO - 2023-08-29 18:53:56 --> Router Class Initialized
INFO - 2023-08-29 18:53:56 --> Output Class Initialized
INFO - 2023-08-29 18:53:56 --> Security Class Initialized
DEBUG - 2023-08-29 18:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:53:56 --> Input Class Initialized
INFO - 2023-08-29 18:53:56 --> Language Class Initialized
INFO - 2023-08-29 18:53:56 --> Loader Class Initialized
INFO - 2023-08-29 18:53:56 --> Helper loaded: url_helper
INFO - 2023-08-29 18:53:56 --> Helper loaded: file_helper
INFO - 2023-08-29 18:53:56 --> Database Driver Class Initialized
INFO - 2023-08-29 18:53:56 --> Email Class Initialized
DEBUG - 2023-08-29 18:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:53:56 --> Controller Class Initialized
INFO - 2023-08-29 18:53:56 --> Model "Services_model" initialized
INFO - 2023-08-29 18:53:56 --> Helper loaded: form_helper
INFO - 2023-08-29 18:53:56 --> Form Validation Class Initialized
INFO - 2023-08-29 18:53:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-29 18:53:56 --> Final output sent to browser
DEBUG - 2023-08-29 18:53:56 --> Total execution time: 0.5132
INFO - 2023-08-29 18:53:58 --> Config Class Initialized
INFO - 2023-08-29 18:53:58 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:53:58 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:53:58 --> Utf8 Class Initialized
INFO - 2023-08-29 18:53:58 --> URI Class Initialized
INFO - 2023-08-29 18:53:58 --> Router Class Initialized
INFO - 2023-08-29 18:53:58 --> Output Class Initialized
INFO - 2023-08-29 18:53:59 --> Security Class Initialized
DEBUG - 2023-08-29 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:53:59 --> Input Class Initialized
INFO - 2023-08-29 18:53:59 --> Language Class Initialized
INFO - 2023-08-29 18:53:59 --> Loader Class Initialized
INFO - 2023-08-29 18:53:59 --> Helper loaded: url_helper
INFO - 2023-08-29 18:53:59 --> Helper loaded: file_helper
INFO - 2023-08-29 18:53:59 --> Database Driver Class Initialized
INFO - 2023-08-29 18:53:59 --> Email Class Initialized
INFO - 2023-08-29 18:53:59 --> Config Class Initialized
INFO - 2023-08-29 18:53:59 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:54:00 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:54:00 --> Utf8 Class Initialized
INFO - 2023-08-29 18:54:00 --> URI Class Initialized
INFO - 2023-08-29 18:54:00 --> Router Class Initialized
INFO - 2023-08-29 18:54:00 --> Output Class Initialized
INFO - 2023-08-29 18:54:00 --> Security Class Initialized
DEBUG - 2023-08-29 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:54:00 --> Input Class Initialized
INFO - 2023-08-29 18:54:00 --> Language Class Initialized
ERROR - 2023-08-29 18:54:00 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-29 18:54:32 --> Config Class Initialized
INFO - 2023-08-29 18:54:32 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:54:32 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:54:32 --> Utf8 Class Initialized
INFO - 2023-08-29 18:54:32 --> URI Class Initialized
DEBUG - 2023-08-29 18:54:32 --> No URI present. Default controller set.
INFO - 2023-08-29 18:54:32 --> Router Class Initialized
INFO - 2023-08-29 18:54:32 --> Output Class Initialized
INFO - 2023-08-29 18:54:32 --> Security Class Initialized
DEBUG - 2023-08-29 18:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:54:32 --> Input Class Initialized
INFO - 2023-08-29 18:54:32 --> Language Class Initialized
INFO - 2023-08-29 18:54:32 --> Loader Class Initialized
INFO - 2023-08-29 18:54:32 --> Helper loaded: url_helper
INFO - 2023-08-29 18:54:32 --> Helper loaded: file_helper
INFO - 2023-08-29 18:54:32 --> Database Driver Class Initialized
INFO - 2023-08-29 18:54:32 --> Email Class Initialized
DEBUG - 2023-08-29 18:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 18:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 18:54:32 --> Controller Class Initialized
INFO - 2023-08-29 18:54:32 --> Model "Contact_model" initialized
INFO - 2023-08-29 18:54:32 --> Model "Home_model" initialized
INFO - 2023-08-29 18:54:32 --> Helper loaded: download_helper
INFO - 2023-08-29 18:54:32 --> Helper loaded: form_helper
INFO - 2023-08-29 18:54:32 --> Form Validation Class Initialized
INFO - 2023-08-29 18:54:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-29 18:54:32 --> Final output sent to browser
DEBUG - 2023-08-29 18:54:33 --> Total execution time: 1.1872
INFO - 2023-08-29 18:54:33 --> Config Class Initialized
INFO - 2023-08-29 18:54:33 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:54:33 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:54:33 --> Utf8 Class Initialized
INFO - 2023-08-29 18:54:33 --> URI Class Initialized
INFO - 2023-08-29 18:54:33 --> Router Class Initialized
INFO - 2023-08-29 18:54:33 --> Output Class Initialized
INFO - 2023-08-29 18:54:33 --> Security Class Initialized
DEBUG - 2023-08-29 18:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:54:33 --> Input Class Initialized
INFO - 2023-08-29 18:54:33 --> Language Class Initialized
ERROR - 2023-08-29 18:54:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 18:54:34 --> Config Class Initialized
INFO - 2023-08-29 18:54:35 --> Hooks Class Initialized
DEBUG - 2023-08-29 18:54:35 --> UTF-8 Support Enabled
INFO - 2023-08-29 18:54:35 --> Utf8 Class Initialized
INFO - 2023-08-29 18:54:35 --> URI Class Initialized
INFO - 2023-08-29 18:54:35 --> Router Class Initialized
INFO - 2023-08-29 18:54:35 --> Output Class Initialized
INFO - 2023-08-29 18:54:35 --> Security Class Initialized
DEBUG - 2023-08-29 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 18:54:35 --> Input Class Initialized
INFO - 2023-08-29 18:54:36 --> Language Class Initialized
ERROR - 2023-08-29 18:54:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:13:21 --> Config Class Initialized
INFO - 2023-08-29 19:13:21 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:13:21 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:13:21 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:21 --> Config Class Initialized
INFO - 2023-08-29 19:13:21 --> Hooks Class Initialized
INFO - 2023-08-29 19:13:21 --> URI Class Initialized
INFO - 2023-08-29 19:13:21 --> Config Class Initialized
INFO - 2023-08-29 19:13:21 --> Config Class Initialized
DEBUG - 2023-08-29 19:13:21 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:13:21 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:21 --> URI Class Initialized
INFO - 2023-08-29 19:13:21 --> Router Class Initialized
INFO - 2023-08-29 19:13:21 --> Output Class Initialized
INFO - 2023-08-29 19:13:21 --> Security Class Initialized
DEBUG - 2023-08-29 19:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:13:21 --> Input Class Initialized
INFO - 2023-08-29 19:13:21 --> Language Class Initialized
ERROR - 2023-08-29 19:13:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:13:22 --> Hooks Class Initialized
INFO - 2023-08-29 19:13:22 --> Router Class Initialized
INFO - 2023-08-29 19:13:22 --> Config Class Initialized
INFO - 2023-08-29 19:13:22 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:13:22 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:13:22 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:22 --> URI Class Initialized
INFO - 2023-08-29 19:13:22 --> Router Class Initialized
INFO - 2023-08-29 19:13:22 --> Output Class Initialized
INFO - 2023-08-29 19:13:22 --> Security Class Initialized
DEBUG - 2023-08-29 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:13:22 --> Input Class Initialized
INFO - 2023-08-29 19:13:22 --> Language Class Initialized
ERROR - 2023-08-29 19:13:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:13:22 --> Output Class Initialized
INFO - 2023-08-29 19:13:22 --> Security Class Initialized
DEBUG - 2023-08-29 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:13:22 --> Input Class Initialized
INFO - 2023-08-29 19:13:22 --> Language Class Initialized
ERROR - 2023-08-29 19:13:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:13:22 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:13:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-29 19:13:22 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:13:22 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:22 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:22 --> URI Class Initialized
INFO - 2023-08-29 19:13:22 --> URI Class Initialized
INFO - 2023-08-29 19:13:22 --> Router Class Initialized
INFO - 2023-08-29 19:13:22 --> Output Class Initialized
INFO - 2023-08-29 19:13:22 --> Router Class Initialized
INFO - 2023-08-29 19:13:22 --> Security Class Initialized
INFO - 2023-08-29 19:13:22 --> Output Class Initialized
DEBUG - 2023-08-29 19:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:13:22 --> Security Class Initialized
INFO - 2023-08-29 19:13:22 --> Input Class Initialized
INFO - 2023-08-29 19:13:22 --> Language Class Initialized
DEBUG - 2023-08-29 19:13:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-29 19:13:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:13:22 --> Input Class Initialized
INFO - 2023-08-29 19:13:22 --> Language Class Initialized
ERROR - 2023-08-29 19:13:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:13:23 --> Config Class Initialized
INFO - 2023-08-29 19:13:23 --> Config Class Initialized
INFO - 2023-08-29 19:13:23 --> Hooks Class Initialized
INFO - 2023-08-29 19:13:23 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:13:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-29 19:13:23 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:13:23 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:23 --> Utf8 Class Initialized
INFO - 2023-08-29 19:13:23 --> URI Class Initialized
INFO - 2023-08-29 19:13:23 --> URI Class Initialized
INFO - 2023-08-29 19:13:23 --> Router Class Initialized
INFO - 2023-08-29 19:13:24 --> Output Class Initialized
INFO - 2023-08-29 19:13:24 --> Router Class Initialized
INFO - 2023-08-29 19:13:24 --> Security Class Initialized
INFO - 2023-08-29 19:13:24 --> Output Class Initialized
INFO - 2023-08-29 19:13:24 --> Security Class Initialized
DEBUG - 2023-08-29 19:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-29 19:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:13:24 --> Input Class Initialized
INFO - 2023-08-29 19:13:24 --> Input Class Initialized
INFO - 2023-08-29 19:13:24 --> Language Class Initialized
INFO - 2023-08-29 19:13:24 --> Language Class Initialized
ERROR - 2023-08-29 19:13:24 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-29 19:13:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:14:23 --> Config Class Initialized
INFO - 2023-08-29 19:14:23 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:23 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:23 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:23 --> URI Class Initialized
DEBUG - 2023-08-29 19:14:23 --> No URI present. Default controller set.
INFO - 2023-08-29 19:14:23 --> Router Class Initialized
INFO - 2023-08-29 19:14:23 --> Output Class Initialized
INFO - 2023-08-29 19:14:23 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:23 --> Input Class Initialized
INFO - 2023-08-29 19:14:23 --> Language Class Initialized
INFO - 2023-08-29 19:14:23 --> Loader Class Initialized
INFO - 2023-08-29 19:14:23 --> Helper loaded: url_helper
INFO - 2023-08-29 19:14:23 --> Helper loaded: file_helper
INFO - 2023-08-29 19:14:23 --> Database Driver Class Initialized
INFO - 2023-08-29 19:14:23 --> Email Class Initialized
DEBUG - 2023-08-29 19:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:14:23 --> Controller Class Initialized
INFO - 2023-08-29 19:14:23 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:14:23 --> Model "Home_model" initialized
INFO - 2023-08-29 19:14:23 --> Helper loaded: download_helper
INFO - 2023-08-29 19:14:23 --> Helper loaded: form_helper
INFO - 2023-08-29 19:14:23 --> Form Validation Class Initialized
INFO - 2023-08-29 19:14:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-29 19:14:23 --> Final output sent to browser
DEBUG - 2023-08-29 19:14:24 --> Total execution time: 1.0000
INFO - 2023-08-29 19:14:26 --> Config Class Initialized
INFO - 2023-08-29 19:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:26 --> Config Class Initialized
INFO - 2023-08-29 19:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:26 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:26 --> URI Class Initialized
INFO - 2023-08-29 19:14:26 --> Router Class Initialized
INFO - 2023-08-29 19:14:26 --> Output Class Initialized
INFO - 2023-08-29 19:14:26 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:26 --> Input Class Initialized
INFO - 2023-08-29 19:14:26 --> Language Class Initialized
ERROR - 2023-08-29 19:14:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:14:26 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:26 --> URI Class Initialized
INFO - 2023-08-29 19:14:26 --> Router Class Initialized
INFO - 2023-08-29 19:14:26 --> Output Class Initialized
INFO - 2023-08-29 19:14:26 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:26 --> Input Class Initialized
INFO - 2023-08-29 19:14:26 --> Language Class Initialized
ERROR - 2023-08-29 19:14:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:14:36 --> Config Class Initialized
INFO - 2023-08-29 19:14:37 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:37 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:37 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:37 --> URI Class Initialized
DEBUG - 2023-08-29 19:14:37 --> No URI present. Default controller set.
INFO - 2023-08-29 19:14:37 --> Router Class Initialized
INFO - 2023-08-29 19:14:37 --> Output Class Initialized
INFO - 2023-08-29 19:14:37 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:37 --> Input Class Initialized
INFO - 2023-08-29 19:14:37 --> Language Class Initialized
INFO - 2023-08-29 19:14:37 --> Loader Class Initialized
INFO - 2023-08-29 19:14:37 --> Helper loaded: url_helper
INFO - 2023-08-29 19:14:37 --> Helper loaded: file_helper
INFO - 2023-08-29 19:14:37 --> Database Driver Class Initialized
INFO - 2023-08-29 19:14:37 --> Email Class Initialized
DEBUG - 2023-08-29 19:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:14:37 --> Controller Class Initialized
INFO - 2023-08-29 19:14:37 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:14:37 --> Model "Home_model" initialized
INFO - 2023-08-29 19:14:37 --> Helper loaded: download_helper
INFO - 2023-08-29 19:14:37 --> Helper loaded: form_helper
INFO - 2023-08-29 19:14:37 --> Form Validation Class Initialized
INFO - 2023-08-29 19:14:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-29 19:14:37 --> Final output sent to browser
DEBUG - 2023-08-29 19:14:38 --> Total execution time: 0.9632
INFO - 2023-08-29 19:14:38 --> Config Class Initialized
INFO - 2023-08-29 19:14:38 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:38 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:38 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:38 --> URI Class Initialized
INFO - 2023-08-29 19:14:38 --> Router Class Initialized
INFO - 2023-08-29 19:14:38 --> Output Class Initialized
INFO - 2023-08-29 19:14:38 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:38 --> Input Class Initialized
INFO - 2023-08-29 19:14:38 --> Language Class Initialized
ERROR - 2023-08-29 19:14:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:14:38 --> Config Class Initialized
INFO - 2023-08-29 19:14:38 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:14:38 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:14:39 --> Utf8 Class Initialized
INFO - 2023-08-29 19:14:39 --> URI Class Initialized
INFO - 2023-08-29 19:14:39 --> Router Class Initialized
INFO - 2023-08-29 19:14:39 --> Output Class Initialized
INFO - 2023-08-29 19:14:39 --> Security Class Initialized
DEBUG - 2023-08-29 19:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:14:39 --> Input Class Initialized
INFO - 2023-08-29 19:14:39 --> Language Class Initialized
ERROR - 2023-08-29 19:14:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:16:33 --> Config Class Initialized
INFO - 2023-08-29 19:16:33 --> Config Class Initialized
INFO - 2023-08-29 19:16:33 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:16:33 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:33 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:33 --> URI Class Initialized
INFO - 2023-08-29 19:16:33 --> Router Class Initialized
INFO - 2023-08-29 19:16:33 --> Output Class Initialized
INFO - 2023-08-29 19:16:33 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:33 --> Input Class Initialized
INFO - 2023-08-29 19:16:33 --> Language Class Initialized
ERROR - 2023-08-29 19:16:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:34 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:16:34 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:34 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:34 --> Config Class Initialized
INFO - 2023-08-29 19:16:34 --> URI Class Initialized
INFO - 2023-08-29 19:16:34 --> Config Class Initialized
INFO - 2023-08-29 19:16:35 --> Hooks Class Initialized
INFO - 2023-08-29 19:16:35 --> Hooks Class Initialized
INFO - 2023-08-29 19:16:35 --> Router Class Initialized
INFO - 2023-08-29 19:16:35 --> Output Class Initialized
DEBUG - 2023-08-29 19:16:36 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:36 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-29 19:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:36 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:36 --> URI Class Initialized
INFO - 2023-08-29 19:16:36 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:37 --> Router Class Initialized
INFO - 2023-08-29 19:16:37 --> URI Class Initialized
INFO - 2023-08-29 19:16:37 --> Output Class Initialized
INFO - 2023-08-29 19:16:37 --> Input Class Initialized
INFO - 2023-08-29 19:16:37 --> Router Class Initialized
INFO - 2023-08-29 19:16:38 --> Output Class Initialized
INFO - 2023-08-29 19:16:38 --> Config Class Initialized
INFO - 2023-08-29 19:16:38 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:38 --> Input Class Initialized
INFO - 2023-08-29 19:16:38 --> Language Class Initialized
ERROR - 2023-08-29 19:16:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:38 --> Language Class Initialized
INFO - 2023-08-29 19:16:38 --> Hooks Class Initialized
ERROR - 2023-08-29 19:16:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:38 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-29 19:16:38 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:38 --> Input Class Initialized
INFO - 2023-08-29 19:16:38 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:38 --> Language Class Initialized
INFO - 2023-08-29 19:16:38 --> URI Class Initialized
INFO - 2023-08-29 19:16:39 --> Router Class Initialized
ERROR - 2023-08-29 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:39 --> Output Class Initialized
INFO - 2023-08-29 19:16:39 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:39 --> Input Class Initialized
INFO - 2023-08-29 19:16:39 --> Language Class Initialized
ERROR - 2023-08-29 19:16:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:40 --> Config Class Initialized
INFO - 2023-08-29 19:16:40 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:16:40 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:40 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:40 --> URI Class Initialized
INFO - 2023-08-29 19:16:40 --> Router Class Initialized
INFO - 2023-08-29 19:16:40 --> Output Class Initialized
INFO - 2023-08-29 19:16:40 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:40 --> Input Class Initialized
INFO - 2023-08-29 19:16:40 --> Language Class Initialized
ERROR - 2023-08-29 19:16:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:16:40 --> Config Class Initialized
INFO - 2023-08-29 19:16:40 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:16:40 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:16:40 --> Utf8 Class Initialized
INFO - 2023-08-29 19:16:40 --> URI Class Initialized
INFO - 2023-08-29 19:16:40 --> Router Class Initialized
INFO - 2023-08-29 19:16:40 --> Output Class Initialized
INFO - 2023-08-29 19:16:40 --> Security Class Initialized
DEBUG - 2023-08-29 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:16:40 --> Input Class Initialized
INFO - 2023-08-29 19:16:41 --> Language Class Initialized
ERROR - 2023-08-29 19:16:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-29 19:18:51 --> Config Class Initialized
INFO - 2023-08-29 19:18:51 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:18:51 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:18:51 --> Utf8 Class Initialized
INFO - 2023-08-29 19:18:51 --> URI Class Initialized
INFO - 2023-08-29 19:18:51 --> Router Class Initialized
INFO - 2023-08-29 19:18:51 --> Output Class Initialized
INFO - 2023-08-29 19:18:51 --> Security Class Initialized
DEBUG - 2023-08-29 19:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:18:52 --> Input Class Initialized
INFO - 2023-08-29 19:18:52 --> Language Class Initialized
INFO - 2023-08-29 19:18:52 --> Loader Class Initialized
INFO - 2023-08-29 19:18:52 --> Helper loaded: url_helper
INFO - 2023-08-29 19:18:52 --> Helper loaded: file_helper
INFO - 2023-08-29 19:18:52 --> Database Driver Class Initialized
INFO - 2023-08-29 19:18:52 --> Email Class Initialized
DEBUG - 2023-08-29 19:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:18:52 --> Controller Class Initialized
INFO - 2023-08-29 19:18:52 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:18:52 --> Model "Home_model" initialized
INFO - 2023-08-29 19:18:52 --> Helper loaded: download_helper
INFO - 2023-08-29 19:18:52 --> Helper loaded: form_helper
INFO - 2023-08-29 19:18:52 --> Form Validation Class Initialized
INFO - 2023-08-29 19:18:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-29 19:18:52 --> Final output sent to browser
DEBUG - 2023-08-29 19:18:52 --> Total execution time: 0.7799
INFO - 2023-08-29 19:18:53 --> Config Class Initialized
INFO - 2023-08-29 19:18:53 --> Hooks Class Initialized
INFO - 2023-08-29 19:18:53 --> Config Class Initialized
INFO - 2023-08-29 19:18:53 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:18:53 --> Utf8 Class Initialized
INFO - 2023-08-29 19:18:53 --> URI Class Initialized
INFO - 2023-08-29 19:18:53 --> Router Class Initialized
INFO - 2023-08-29 19:18:53 --> Output Class Initialized
INFO - 2023-08-29 19:18:53 --> Security Class Initialized
DEBUG - 2023-08-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:18:53 --> Input Class Initialized
INFO - 2023-08-29 19:18:53 --> Language Class Initialized
ERROR - 2023-08-29 19:18:53 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:18:53 --> Utf8 Class Initialized
INFO - 2023-08-29 19:18:53 --> URI Class Initialized
INFO - 2023-08-29 19:18:53 --> Router Class Initialized
INFO - 2023-08-29 19:18:53 --> Output Class Initialized
INFO - 2023-08-29 19:18:53 --> Security Class Initialized
DEBUG - 2023-08-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:18:53 --> Input Class Initialized
INFO - 2023-08-29 19:18:53 --> Language Class Initialized
ERROR - 2023-08-29 19:18:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:19:02 --> Config Class Initialized
INFO - 2023-08-29 19:19:02 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:19:02 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:19:02 --> Utf8 Class Initialized
INFO - 2023-08-29 19:19:02 --> URI Class Initialized
INFO - 2023-08-29 19:19:02 --> Router Class Initialized
INFO - 2023-08-29 19:19:02 --> Output Class Initialized
INFO - 2023-08-29 19:19:02 --> Security Class Initialized
DEBUG - 2023-08-29 19:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:19:02 --> Input Class Initialized
INFO - 2023-08-29 19:19:02 --> Language Class Initialized
INFO - 2023-08-29 19:19:02 --> Loader Class Initialized
INFO - 2023-08-29 19:19:02 --> Helper loaded: url_helper
INFO - 2023-08-29 19:19:02 --> Helper loaded: file_helper
INFO - 2023-08-29 19:19:02 --> Database Driver Class Initialized
INFO - 2023-08-29 19:19:02 --> Email Class Initialized
DEBUG - 2023-08-29 19:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:19:02 --> Controller Class Initialized
INFO - 2023-08-29 19:19:03 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:19:03 --> Model "Home_model" initialized
INFO - 2023-08-29 19:19:03 --> Helper loaded: download_helper
INFO - 2023-08-29 19:19:03 --> Helper loaded: form_helper
INFO - 2023-08-29 19:19:03 --> Form Validation Class Initialized
INFO - 2023-08-29 19:19:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-29 19:19:03 --> Final output sent to browser
DEBUG - 2023-08-29 19:19:03 --> Total execution time: 0.8505
INFO - 2023-08-29 19:19:03 --> Config Class Initialized
INFO - 2023-08-29 19:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:19:03 --> Utf8 Class Initialized
INFO - 2023-08-29 19:19:03 --> URI Class Initialized
INFO - 2023-08-29 19:19:03 --> Router Class Initialized
INFO - 2023-08-29 19:19:03 --> Output Class Initialized
INFO - 2023-08-29 19:19:03 --> Security Class Initialized
DEBUG - 2023-08-29 19:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:19:03 --> Input Class Initialized
INFO - 2023-08-29 19:19:03 --> Language Class Initialized
ERROR - 2023-08-29 19:19:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:19:03 --> Config Class Initialized
INFO - 2023-08-29 19:19:04 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:19:04 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:19:04 --> Utf8 Class Initialized
INFO - 2023-08-29 19:19:04 --> URI Class Initialized
INFO - 2023-08-29 19:19:04 --> Router Class Initialized
INFO - 2023-08-29 19:19:04 --> Output Class Initialized
INFO - 2023-08-29 19:19:04 --> Security Class Initialized
DEBUG - 2023-08-29 19:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:19:04 --> Input Class Initialized
INFO - 2023-08-29 19:19:04 --> Language Class Initialized
ERROR - 2023-08-29 19:19:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:20:08 --> Config Class Initialized
INFO - 2023-08-29 19:20:08 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:20:08 --> Utf8 Class Initialized
INFO - 2023-08-29 19:20:08 --> URI Class Initialized
DEBUG - 2023-08-29 19:20:08 --> No URI present. Default controller set.
INFO - 2023-08-29 19:20:08 --> Router Class Initialized
INFO - 2023-08-29 19:20:08 --> Output Class Initialized
INFO - 2023-08-29 19:20:08 --> Security Class Initialized
DEBUG - 2023-08-29 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:20:08 --> Input Class Initialized
INFO - 2023-08-29 19:20:08 --> Language Class Initialized
INFO - 2023-08-29 19:20:08 --> Loader Class Initialized
INFO - 2023-08-29 19:20:08 --> Helper loaded: url_helper
INFO - 2023-08-29 19:20:08 --> Helper loaded: file_helper
INFO - 2023-08-29 19:20:08 --> Database Driver Class Initialized
INFO - 2023-08-29 19:20:08 --> Email Class Initialized
DEBUG - 2023-08-29 19:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:20:08 --> Controller Class Initialized
INFO - 2023-08-29 19:20:08 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:20:08 --> Model "Home_model" initialized
INFO - 2023-08-29 19:20:08 --> Helper loaded: download_helper
INFO - 2023-08-29 19:20:08 --> Helper loaded: form_helper
INFO - 2023-08-29 19:20:08 --> Form Validation Class Initialized
INFO - 2023-08-29 19:20:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-29 19:20:09 --> Final output sent to browser
DEBUG - 2023-08-29 19:20:09 --> Total execution time: 0.8378
INFO - 2023-08-29 19:20:09 --> Config Class Initialized
INFO - 2023-08-29 19:20:09 --> Hooks Class Initialized
INFO - 2023-08-29 19:20:09 --> Config Class Initialized
INFO - 2023-08-29 19:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:20:09 --> Utf8 Class Initialized
INFO - 2023-08-29 19:20:09 --> URI Class Initialized
INFO - 2023-08-29 19:20:09 --> Router Class Initialized
INFO - 2023-08-29 19:20:09 --> Output Class Initialized
INFO - 2023-08-29 19:20:09 --> Security Class Initialized
DEBUG - 2023-08-29 19:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:20:09 --> Input Class Initialized
INFO - 2023-08-29 19:20:09 --> Language Class Initialized
ERROR - 2023-08-29 19:20:09 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-29 19:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:20:09 --> Utf8 Class Initialized
INFO - 2023-08-29 19:20:10 --> URI Class Initialized
INFO - 2023-08-29 19:20:10 --> Router Class Initialized
INFO - 2023-08-29 19:20:10 --> Output Class Initialized
INFO - 2023-08-29 19:20:10 --> Security Class Initialized
DEBUG - 2023-08-29 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:20:10 --> Input Class Initialized
INFO - 2023-08-29 19:20:10 --> Language Class Initialized
ERROR - 2023-08-29 19:20:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-29 19:20:41 --> Config Class Initialized
INFO - 2023-08-29 19:20:41 --> Hooks Class Initialized
DEBUG - 2023-08-29 19:20:41 --> UTF-8 Support Enabled
INFO - 2023-08-29 19:20:41 --> Utf8 Class Initialized
INFO - 2023-08-29 19:20:41 --> URI Class Initialized
INFO - 2023-08-29 19:20:41 --> Router Class Initialized
INFO - 2023-08-29 19:20:41 --> Output Class Initialized
INFO - 2023-08-29 19:20:41 --> Security Class Initialized
DEBUG - 2023-08-29 19:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-29 19:20:42 --> Input Class Initialized
INFO - 2023-08-29 19:20:42 --> Language Class Initialized
INFO - 2023-08-29 19:20:42 --> Loader Class Initialized
INFO - 2023-08-29 19:20:42 --> Helper loaded: url_helper
INFO - 2023-08-29 19:20:42 --> Helper loaded: file_helper
INFO - 2023-08-29 19:20:42 --> Database Driver Class Initialized
INFO - 2023-08-29 19:20:42 --> Email Class Initialized
DEBUG - 2023-08-29 19:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-29 19:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-29 19:20:42 --> Controller Class Initialized
INFO - 2023-08-29 19:20:42 --> Model "Contact_model" initialized
INFO - 2023-08-29 19:20:42 --> Model "Home_model" initialized
INFO - 2023-08-29 19:20:42 --> Helper loaded: download_helper
INFO - 2023-08-29 19:20:42 --> Helper loaded: form_helper
INFO - 2023-08-29 19:20:43 --> Form Validation Class Initialized
INFO - 2023-08-29 19:20:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-29 19:20:43 --> Final output sent to browser
DEBUG - 2023-08-29 19:20:43 --> Total execution time: 1.7327
