<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-16 07:58:39 --> Config Class Initialized
INFO - 2023-09-16 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:58:39 --> Utf8 Class Initialized
INFO - 2023-09-16 07:58:39 --> URI Class Initialized
DEBUG - 2023-09-16 07:58:39 --> No URI present. Default controller set.
INFO - 2023-09-16 07:58:39 --> Router Class Initialized
INFO - 2023-09-16 07:58:39 --> Output Class Initialized
INFO - 2023-09-16 07:58:39 --> Security Class Initialized
DEBUG - 2023-09-16 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:58:39 --> Input Class Initialized
INFO - 2023-09-16 07:58:39 --> Language Class Initialized
INFO - 2023-09-16 07:58:39 --> Loader Class Initialized
INFO - 2023-09-16 07:58:39 --> Helper loaded: url_helper
INFO - 2023-09-16 07:58:39 --> Helper loaded: file_helper
INFO - 2023-09-16 07:58:39 --> Database Driver Class Initialized
INFO - 2023-09-16 07:58:39 --> Email Class Initialized
DEBUG - 2023-09-16 07:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:58:39 --> Controller Class Initialized
INFO - 2023-09-16 07:58:39 --> Model "Contact_model" initialized
INFO - 2023-09-16 07:58:39 --> Model "Home_model" initialized
INFO - 2023-09-16 07:58:39 --> Helper loaded: download_helper
INFO - 2023-09-16 07:58:39 --> Helper loaded: form_helper
INFO - 2023-09-16 07:58:39 --> Form Validation Class Initialized
INFO - 2023-09-16 07:58:40 --> Helper loaded: custom_helper
INFO - 2023-09-16 07:58:40 --> Model "Social_media_model" initialized
INFO - 2023-09-16 07:58:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-16 07:58:40 --> Final output sent to browser
DEBUG - 2023-09-16 07:58:40 --> Total execution time: 1.1574
INFO - 2023-09-16 07:58:43 --> Config Class Initialized
INFO - 2023-09-16 07:58:43 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:58:43 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:58:43 --> Utf8 Class Initialized
INFO - 2023-09-16 07:58:43 --> URI Class Initialized
INFO - 2023-09-16 07:58:43 --> Router Class Initialized
INFO - 2023-09-16 07:58:43 --> Output Class Initialized
INFO - 2023-09-16 07:58:43 --> Security Class Initialized
DEBUG - 2023-09-16 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:58:43 --> Input Class Initialized
INFO - 2023-09-16 07:58:43 --> Language Class Initialized
INFO - 2023-09-16 07:58:43 --> Loader Class Initialized
INFO - 2023-09-16 07:58:43 --> Helper loaded: url_helper
INFO - 2023-09-16 07:58:43 --> Helper loaded: file_helper
INFO - 2023-09-16 07:58:43 --> Database Driver Class Initialized
INFO - 2023-09-16 07:58:43 --> Email Class Initialized
DEBUG - 2023-09-16 07:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:58:43 --> Controller Class Initialized
INFO - 2023-09-16 07:58:43 --> Config Class Initialized
INFO - 2023-09-16 07:58:43 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:58:43 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:58:43 --> Utf8 Class Initialized
INFO - 2023-09-16 07:58:43 --> URI Class Initialized
INFO - 2023-09-16 07:58:43 --> Router Class Initialized
INFO - 2023-09-16 07:58:43 --> Output Class Initialized
INFO - 2023-09-16 07:58:43 --> Security Class Initialized
DEBUG - 2023-09-16 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:58:43 --> Input Class Initialized
INFO - 2023-09-16 07:58:43 --> Language Class Initialized
INFO - 2023-09-16 07:58:43 --> Loader Class Initialized
INFO - 2023-09-16 07:58:43 --> Helper loaded: url_helper
INFO - 2023-09-16 07:58:43 --> Helper loaded: file_helper
INFO - 2023-09-16 07:58:43 --> Database Driver Class Initialized
INFO - 2023-09-16 07:58:43 --> Email Class Initialized
DEBUG - 2023-09-16 07:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:58:43 --> Controller Class Initialized
INFO - 2023-09-16 07:58:44 --> Model "User_model" initialized
INFO - 2023-09-16 07:58:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-16 07:58:44 --> Final output sent to browser
DEBUG - 2023-09-16 07:58:44 --> Total execution time: 0.2005
INFO - 2023-09-16 07:58:44 --> Config Class Initialized
INFO - 2023-09-16 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:58:44 --> Utf8 Class Initialized
INFO - 2023-09-16 07:58:44 --> URI Class Initialized
INFO - 2023-09-16 07:58:44 --> Router Class Initialized
INFO - 2023-09-16 07:58:44 --> Output Class Initialized
INFO - 2023-09-16 07:58:44 --> Security Class Initialized
DEBUG - 2023-09-16 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:58:44 --> Input Class Initialized
INFO - 2023-09-16 07:58:44 --> Language Class Initialized
ERROR - 2023-09-16 07:58:44 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-16 07:59:04 --> Config Class Initialized
INFO - 2023-09-16 07:59:04 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:04 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:04 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:04 --> URI Class Initialized
INFO - 2023-09-16 07:59:04 --> Router Class Initialized
INFO - 2023-09-16 07:59:04 --> Output Class Initialized
INFO - 2023-09-16 07:59:04 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:04 --> Input Class Initialized
INFO - 2023-09-16 07:59:04 --> Language Class Initialized
INFO - 2023-09-16 07:59:04 --> Loader Class Initialized
INFO - 2023-09-16 07:59:04 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:04 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:04 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:04 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:04 --> Controller Class Initialized
INFO - 2023-09-16 07:59:04 --> Model "User_model" initialized
INFO - 2023-09-16 07:59:04 --> Config Class Initialized
INFO - 2023-09-16 07:59:04 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:04 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:04 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:04 --> URI Class Initialized
INFO - 2023-09-16 07:59:04 --> Router Class Initialized
INFO - 2023-09-16 07:59:04 --> Output Class Initialized
INFO - 2023-09-16 07:59:04 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:04 --> Input Class Initialized
INFO - 2023-09-16 07:59:04 --> Language Class Initialized
INFO - 2023-09-16 07:59:04 --> Loader Class Initialized
INFO - 2023-09-16 07:59:04 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:04 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:04 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:04 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:04 --> Controller Class Initialized
INFO - 2023-09-16 07:59:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-16 07:59:04 --> Final output sent to browser
DEBUG - 2023-09-16 07:59:04 --> Total execution time: 0.1264
INFO - 2023-09-16 07:59:09 --> Config Class Initialized
INFO - 2023-09-16 07:59:09 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:09 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:09 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:09 --> URI Class Initialized
INFO - 2023-09-16 07:59:09 --> Router Class Initialized
INFO - 2023-09-16 07:59:09 --> Output Class Initialized
INFO - 2023-09-16 07:59:09 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:09 --> Input Class Initialized
INFO - 2023-09-16 07:59:09 --> Language Class Initialized
INFO - 2023-09-16 07:59:09 --> Loader Class Initialized
INFO - 2023-09-16 07:59:09 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:09 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:09 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:09 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:09 --> Controller Class Initialized
INFO - 2023-09-16 07:59:09 --> Model "Services_model" initialized
INFO - 2023-09-16 07:59:09 --> Helper loaded: form_helper
INFO - 2023-09-16 07:59:09 --> Form Validation Class Initialized
INFO - 2023-09-16 07:59:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-16 07:59:09 --> Final output sent to browser
DEBUG - 2023-09-16 07:59:09 --> Total execution time: 0.1111
INFO - 2023-09-16 07:59:11 --> Config Class Initialized
INFO - 2023-09-16 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:11 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:11 --> URI Class Initialized
INFO - 2023-09-16 07:59:11 --> Router Class Initialized
INFO - 2023-09-16 07:59:11 --> Output Class Initialized
INFO - 2023-09-16 07:59:11 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:11 --> Input Class Initialized
INFO - 2023-09-16 07:59:11 --> Language Class Initialized
INFO - 2023-09-16 07:59:11 --> Loader Class Initialized
INFO - 2023-09-16 07:59:11 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:11 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:11 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:11 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:11 --> Controller Class Initialized
INFO - 2023-09-16 07:59:11 --> Model "Services_model" initialized
INFO - 2023-09-16 07:59:11 --> Helper loaded: form_helper
INFO - 2023-09-16 07:59:11 --> Form Validation Class Initialized
INFO - 2023-09-16 07:59:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-16 07:59:11 --> Final output sent to browser
DEBUG - 2023-09-16 07:59:11 --> Total execution time: 0.0513
INFO - 2023-09-16 07:59:11 --> Config Class Initialized
INFO - 2023-09-16 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:11 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:11 --> URI Class Initialized
INFO - 2023-09-16 07:59:11 --> Router Class Initialized
INFO - 2023-09-16 07:59:11 --> Output Class Initialized
INFO - 2023-09-16 07:59:11 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:11 --> Input Class Initialized
INFO - 2023-09-16 07:59:11 --> Language Class Initialized
ERROR - 2023-09-16 07:59:11 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-16 07:59:59 --> Config Class Initialized
INFO - 2023-09-16 07:59:59 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:59 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:59 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:59 --> URI Class Initialized
INFO - 2023-09-16 07:59:59 --> Router Class Initialized
INFO - 2023-09-16 07:59:59 --> Output Class Initialized
INFO - 2023-09-16 07:59:59 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:59 --> Input Class Initialized
INFO - 2023-09-16 07:59:59 --> Language Class Initialized
INFO - 2023-09-16 07:59:59 --> Loader Class Initialized
INFO - 2023-09-16 07:59:59 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:59 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:59 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:59 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:59 --> Controller Class Initialized
INFO - 2023-09-16 07:59:59 --> Model "Services_model" initialized
INFO - 2023-09-16 07:59:59 --> Helper loaded: form_helper
INFO - 2023-09-16 07:59:59 --> Form Validation Class Initialized
INFO - 2023-09-16 07:59:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-16 07:59:59 --> Config Class Initialized
INFO - 2023-09-16 07:59:59 --> Hooks Class Initialized
DEBUG - 2023-09-16 07:59:59 --> UTF-8 Support Enabled
INFO - 2023-09-16 07:59:59 --> Utf8 Class Initialized
INFO - 2023-09-16 07:59:59 --> URI Class Initialized
INFO - 2023-09-16 07:59:59 --> Router Class Initialized
INFO - 2023-09-16 07:59:59 --> Output Class Initialized
INFO - 2023-09-16 07:59:59 --> Security Class Initialized
DEBUG - 2023-09-16 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 07:59:59 --> Input Class Initialized
INFO - 2023-09-16 07:59:59 --> Language Class Initialized
INFO - 2023-09-16 07:59:59 --> Loader Class Initialized
INFO - 2023-09-16 07:59:59 --> Helper loaded: url_helper
INFO - 2023-09-16 07:59:59 --> Helper loaded: file_helper
INFO - 2023-09-16 07:59:59 --> Database Driver Class Initialized
INFO - 2023-09-16 07:59:59 --> Email Class Initialized
DEBUG - 2023-09-16 07:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 07:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 07:59:59 --> Controller Class Initialized
INFO - 2023-09-16 07:59:59 --> Model "Services_model" initialized
INFO - 2023-09-16 07:59:59 --> Helper loaded: form_helper
INFO - 2023-09-16 07:59:59 --> Form Validation Class Initialized
INFO - 2023-09-16 07:59:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-16 07:59:59 --> Final output sent to browser
DEBUG - 2023-09-16 07:59:59 --> Total execution time: 0.0474
INFO - 2023-09-16 08:13:26 --> Config Class Initialized
INFO - 2023-09-16 08:13:26 --> Hooks Class Initialized
DEBUG - 2023-09-16 08:13:26 --> UTF-8 Support Enabled
INFO - 2023-09-16 08:13:26 --> Utf8 Class Initialized
INFO - 2023-09-16 08:13:26 --> URI Class Initialized
INFO - 2023-09-16 08:13:26 --> Router Class Initialized
INFO - 2023-09-16 08:13:26 --> Output Class Initialized
INFO - 2023-09-16 08:13:26 --> Security Class Initialized
DEBUG - 2023-09-16 08:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 08:13:26 --> Input Class Initialized
INFO - 2023-09-16 08:13:26 --> Language Class Initialized
INFO - 2023-09-16 08:13:26 --> Loader Class Initialized
INFO - 2023-09-16 08:13:26 --> Helper loaded: url_helper
INFO - 2023-09-16 08:13:26 --> Helper loaded: file_helper
INFO - 2023-09-16 08:13:26 --> Database Driver Class Initialized
INFO - 2023-09-16 08:13:26 --> Email Class Initialized
DEBUG - 2023-09-16 08:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-16 08:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 08:13:26 --> Controller Class Initialized
INFO - 2023-09-16 08:13:26 --> Model "Services_model" initialized
INFO - 2023-09-16 08:13:26 --> Helper loaded: form_helper
INFO - 2023-09-16 08:13:26 --> Form Validation Class Initialized
INFO - 2023-09-16 08:13:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-16 08:13:26 --> Final output sent to browser
DEBUG - 2023-09-16 08:13:26 --> Total execution time: 0.0542
