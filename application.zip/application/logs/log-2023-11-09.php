<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-09 16:05:00 --> Config Class Initialized
INFO - 2023-11-09 16:05:00 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:05:00 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:05:00 --> Utf8 Class Initialized
INFO - 2023-11-09 16:05:00 --> URI Class Initialized
DEBUG - 2023-11-09 16:05:00 --> No URI present. Default controller set.
INFO - 2023-11-09 16:05:00 --> Router Class Initialized
INFO - 2023-11-09 16:05:00 --> Output Class Initialized
INFO - 2023-11-09 16:05:00 --> Security Class Initialized
DEBUG - 2023-11-09 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:05:00 --> Input Class Initialized
INFO - 2023-11-09 16:05:00 --> Language Class Initialized
INFO - 2023-11-09 16:05:00 --> Loader Class Initialized
INFO - 2023-11-09 16:05:00 --> Helper loaded: url_helper
INFO - 2023-11-09 16:05:00 --> Helper loaded: file_helper
INFO - 2023-11-09 16:05:00 --> Database Driver Class Initialized
INFO - 2023-11-09 16:05:00 --> Email Class Initialized
DEBUG - 2023-11-09 16:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:05:00 --> Controller Class Initialized
INFO - 2023-11-09 16:05:00 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:05:00 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:05:00 --> Model "Home_model" initialized
INFO - 2023-11-09 16:05:00 --> Helper loaded: download_helper
INFO - 2023-11-09 16:05:00 --> Helper loaded: form_helper
INFO - 2023-11-09 16:05:00 --> Form Validation Class Initialized
INFO - 2023-11-09 20:35:01 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:35:01 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:35:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:35:01 --> Final output sent to browser
DEBUG - 2023-11-09 20:35:01 --> Total execution time: 1.0844
INFO - 2023-11-09 16:05:12 --> Config Class Initialized
INFO - 2023-11-09 16:05:12 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:05:12 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:05:12 --> Utf8 Class Initialized
INFO - 2023-11-09 16:05:12 --> URI Class Initialized
DEBUG - 2023-11-09 16:05:12 --> No URI present. Default controller set.
INFO - 2023-11-09 16:05:12 --> Router Class Initialized
INFO - 2023-11-09 16:05:12 --> Output Class Initialized
INFO - 2023-11-09 16:05:12 --> Security Class Initialized
DEBUG - 2023-11-09 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:05:12 --> Input Class Initialized
INFO - 2023-11-09 16:05:12 --> Language Class Initialized
INFO - 2023-11-09 16:05:12 --> Loader Class Initialized
INFO - 2023-11-09 16:05:12 --> Helper loaded: url_helper
INFO - 2023-11-09 16:05:12 --> Helper loaded: file_helper
INFO - 2023-11-09 16:05:12 --> Database Driver Class Initialized
INFO - 2023-11-09 16:05:12 --> Email Class Initialized
DEBUG - 2023-11-09 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:05:12 --> Controller Class Initialized
INFO - 2023-11-09 16:05:12 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:05:12 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:05:12 --> Model "Home_model" initialized
INFO - 2023-11-09 16:05:12 --> Helper loaded: download_helper
INFO - 2023-11-09 16:05:12 --> Helper loaded: form_helper
INFO - 2023-11-09 16:05:12 --> Form Validation Class Initialized
INFO - 2023-11-09 20:35:12 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:35:12 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:35:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:35:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:35:12 --> Final output sent to browser
DEBUG - 2023-11-09 20:35:12 --> Total execution time: 0.1099
INFO - 2023-11-09 16:05:39 --> Config Class Initialized
INFO - 2023-11-09 16:05:39 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:05:39 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:05:39 --> Utf8 Class Initialized
INFO - 2023-11-09 16:05:39 --> URI Class Initialized
DEBUG - 2023-11-09 16:05:39 --> No URI present. Default controller set.
INFO - 2023-11-09 16:05:39 --> Router Class Initialized
INFO - 2023-11-09 16:05:39 --> Output Class Initialized
INFO - 2023-11-09 16:05:39 --> Security Class Initialized
DEBUG - 2023-11-09 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:05:39 --> Input Class Initialized
INFO - 2023-11-09 16:05:39 --> Language Class Initialized
INFO - 2023-11-09 16:05:39 --> Loader Class Initialized
INFO - 2023-11-09 16:05:39 --> Helper loaded: url_helper
INFO - 2023-11-09 16:05:39 --> Helper loaded: file_helper
INFO - 2023-11-09 16:05:39 --> Database Driver Class Initialized
INFO - 2023-11-09 16:05:39 --> Email Class Initialized
DEBUG - 2023-11-09 16:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:05:39 --> Controller Class Initialized
INFO - 2023-11-09 16:05:39 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:05:39 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:05:39 --> Model "Home_model" initialized
INFO - 2023-11-09 16:05:39 --> Helper loaded: download_helper
INFO - 2023-11-09 16:05:39 --> Helper loaded: form_helper
INFO - 2023-11-09 16:05:39 --> Form Validation Class Initialized
INFO - 2023-11-09 20:35:39 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:35:39 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:35:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:35:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:35:39 --> Final output sent to browser
DEBUG - 2023-11-09 20:35:39 --> Total execution time: 0.1919
INFO - 2023-11-09 16:05:53 --> Config Class Initialized
INFO - 2023-11-09 16:05:53 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:05:53 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:05:53 --> Utf8 Class Initialized
INFO - 2023-11-09 16:05:53 --> URI Class Initialized
DEBUG - 2023-11-09 16:05:53 --> No URI present. Default controller set.
INFO - 2023-11-09 16:05:53 --> Router Class Initialized
INFO - 2023-11-09 16:05:53 --> Output Class Initialized
INFO - 2023-11-09 16:05:53 --> Security Class Initialized
DEBUG - 2023-11-09 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:05:53 --> Input Class Initialized
INFO - 2023-11-09 16:05:53 --> Language Class Initialized
INFO - 2023-11-09 16:05:53 --> Loader Class Initialized
INFO - 2023-11-09 16:05:53 --> Helper loaded: url_helper
INFO - 2023-11-09 16:05:53 --> Helper loaded: file_helper
INFO - 2023-11-09 16:05:53 --> Database Driver Class Initialized
INFO - 2023-11-09 16:05:53 --> Email Class Initialized
DEBUG - 2023-11-09 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:05:53 --> Controller Class Initialized
INFO - 2023-11-09 16:05:53 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:05:53 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:05:53 --> Model "Home_model" initialized
INFO - 2023-11-09 16:05:53 --> Helper loaded: download_helper
INFO - 2023-11-09 16:05:53 --> Helper loaded: form_helper
INFO - 2023-11-09 16:05:53 --> Form Validation Class Initialized
INFO - 2023-11-09 20:35:53 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:35:53 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:35:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:35:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:35:53 --> Final output sent to browser
DEBUG - 2023-11-09 20:35:53 --> Total execution time: 0.1152
INFO - 2023-11-09 16:06:04 --> Config Class Initialized
INFO - 2023-11-09 16:06:04 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:04 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:04 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:04 --> URI Class Initialized
DEBUG - 2023-11-09 16:06:04 --> No URI present. Default controller set.
INFO - 2023-11-09 16:06:04 --> Router Class Initialized
INFO - 2023-11-09 16:06:04 --> Output Class Initialized
INFO - 2023-11-09 16:06:04 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:04 --> Input Class Initialized
INFO - 2023-11-09 16:06:04 --> Language Class Initialized
INFO - 2023-11-09 16:06:04 --> Loader Class Initialized
INFO - 2023-11-09 16:06:04 --> Helper loaded: url_helper
INFO - 2023-11-09 16:06:04 --> Helper loaded: file_helper
INFO - 2023-11-09 16:06:04 --> Database Driver Class Initialized
INFO - 2023-11-09 16:06:04 --> Email Class Initialized
DEBUG - 2023-11-09 16:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:06:04 --> Controller Class Initialized
INFO - 2023-11-09 16:06:04 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:06:04 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:06:04 --> Model "Home_model" initialized
INFO - 2023-11-09 16:06:04 --> Helper loaded: download_helper
INFO - 2023-11-09 16:06:04 --> Helper loaded: form_helper
INFO - 2023-11-09 16:06:04 --> Form Validation Class Initialized
INFO - 2023-11-09 20:36:04 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:36:04 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:36:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:36:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:36:04 --> Final output sent to browser
DEBUG - 2023-11-09 20:36:04 --> Total execution time: 0.2124
INFO - 2023-11-09 16:06:21 --> Config Class Initialized
INFO - 2023-11-09 16:06:21 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:21 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:21 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:21 --> URI Class Initialized
DEBUG - 2023-11-09 16:06:21 --> No URI present. Default controller set.
INFO - 2023-11-09 16:06:21 --> Router Class Initialized
INFO - 2023-11-09 16:06:21 --> Output Class Initialized
INFO - 2023-11-09 16:06:21 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:21 --> Input Class Initialized
INFO - 2023-11-09 16:06:21 --> Language Class Initialized
INFO - 2023-11-09 16:06:21 --> Loader Class Initialized
INFO - 2023-11-09 16:06:21 --> Helper loaded: url_helper
INFO - 2023-11-09 16:06:21 --> Helper loaded: file_helper
INFO - 2023-11-09 16:06:21 --> Database Driver Class Initialized
INFO - 2023-11-09 16:06:21 --> Email Class Initialized
DEBUG - 2023-11-09 16:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:06:21 --> Controller Class Initialized
INFO - 2023-11-09 16:06:21 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:06:21 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:06:21 --> Model "Home_model" initialized
INFO - 2023-11-09 16:06:21 --> Helper loaded: download_helper
INFO - 2023-11-09 16:06:21 --> Helper loaded: form_helper
INFO - 2023-11-09 16:06:21 --> Form Validation Class Initialized
INFO - 2023-11-09 20:36:21 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:36:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:36:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:36:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:36:21 --> Final output sent to browser
DEBUG - 2023-11-09 20:36:21 --> Total execution time: 0.0783
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:06:36 --> Config Class Initialized
INFO - 2023-11-09 16:06:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:06:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:06:36 --> Utf8 Class Initialized
INFO - 2023-11-09 16:06:36 --> URI Class Initialized
INFO - 2023-11-09 16:06:36 --> Router Class Initialized
INFO - 2023-11-09 16:06:36 --> Output Class Initialized
INFO - 2023-11-09 16:06:36 --> Security Class Initialized
DEBUG - 2023-11-09 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:06:36 --> Input Class Initialized
INFO - 2023-11-09 16:06:36 --> Language Class Initialized
ERROR - 2023-11-09 16:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:13 --> Config Class Initialized
INFO - 2023-11-09 16:07:13 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:13 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:13 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:13 --> URI Class Initialized
DEBUG - 2023-11-09 16:07:13 --> No URI present. Default controller set.
INFO - 2023-11-09 16:07:13 --> Router Class Initialized
INFO - 2023-11-09 16:07:13 --> Output Class Initialized
INFO - 2023-11-09 16:07:13 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:13 --> Input Class Initialized
INFO - 2023-11-09 16:07:13 --> Language Class Initialized
INFO - 2023-11-09 16:07:13 --> Loader Class Initialized
INFO - 2023-11-09 16:07:13 --> Helper loaded: url_helper
INFO - 2023-11-09 16:07:13 --> Helper loaded: file_helper
INFO - 2023-11-09 16:07:13 --> Database Driver Class Initialized
INFO - 2023-11-09 16:07:13 --> Email Class Initialized
DEBUG - 2023-11-09 16:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:07:13 --> Controller Class Initialized
INFO - 2023-11-09 16:07:13 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:07:13 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:07:13 --> Model "Home_model" initialized
INFO - 2023-11-09 16:07:13 --> Helper loaded: download_helper
INFO - 2023-11-09 16:07:13 --> Helper loaded: form_helper
INFO - 2023-11-09 16:07:13 --> Form Validation Class Initialized
INFO - 2023-11-09 20:37:13 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:37:13 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:37:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:37:13 --> Final output sent to browser
DEBUG - 2023-11-09 20:37:13 --> Total execution time: 0.1588
INFO - 2023-11-09 16:07:14 --> Config Class Initialized
INFO - 2023-11-09 16:07:14 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:14 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:14 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:14 --> URI Class Initialized
INFO - 2023-11-09 16:07:14 --> Router Class Initialized
INFO - 2023-11-09 16:07:14 --> Output Class Initialized
INFO - 2023-11-09 16:07:14 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:14 --> Input Class Initialized
INFO - 2023-11-09 16:07:14 --> Language Class Initialized
ERROR - 2023-11-09 16:07:14 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:16 --> Config Class Initialized
INFO - 2023-11-09 16:07:16 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:16 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:16 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:16 --> URI Class Initialized
INFO - 2023-11-09 16:07:16 --> Router Class Initialized
INFO - 2023-11-09 16:07:16 --> Output Class Initialized
INFO - 2023-11-09 16:07:16 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:16 --> Input Class Initialized
INFO - 2023-11-09 16:07:16 --> Language Class Initialized
ERROR - 2023-11-09 16:07:16 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:16 --> Config Class Initialized
INFO - 2023-11-09 16:07:16 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:16 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:16 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:16 --> URI Class Initialized
INFO - 2023-11-09 16:07:16 --> Router Class Initialized
INFO - 2023-11-09 16:07:16 --> Output Class Initialized
INFO - 2023-11-09 16:07:16 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:16 --> Input Class Initialized
INFO - 2023-11-09 16:07:16 --> Language Class Initialized
ERROR - 2023-11-09 16:07:16 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:16 --> Config Class Initialized
INFO - 2023-11-09 16:07:16 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:16 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:16 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:16 --> URI Class Initialized
INFO - 2023-11-09 16:07:16 --> Router Class Initialized
INFO - 2023-11-09 16:07:16 --> Output Class Initialized
INFO - 2023-11-09 16:07:16 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:16 --> Input Class Initialized
INFO - 2023-11-09 16:07:16 --> Language Class Initialized
ERROR - 2023-11-09 16:07:16 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:17 --> Config Class Initialized
INFO - 2023-11-09 16:07:17 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:17 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:17 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:17 --> URI Class Initialized
INFO - 2023-11-09 16:07:17 --> Router Class Initialized
INFO - 2023-11-09 16:07:17 --> Output Class Initialized
INFO - 2023-11-09 16:07:17 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:17 --> Input Class Initialized
INFO - 2023-11-09 16:07:17 --> Language Class Initialized
ERROR - 2023-11-09 16:07:17 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:18 --> Config Class Initialized
INFO - 2023-11-09 16:07:18 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:18 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:18 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:18 --> URI Class Initialized
INFO - 2023-11-09 16:07:18 --> Router Class Initialized
INFO - 2023-11-09 16:07:18 --> Output Class Initialized
INFO - 2023-11-09 16:07:18 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:18 --> Input Class Initialized
INFO - 2023-11-09 16:07:18 --> Language Class Initialized
ERROR - 2023-11-09 16:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:07:18 --> Config Class Initialized
INFO - 2023-11-09 16:07:18 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:07:18 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:07:18 --> Utf8 Class Initialized
INFO - 2023-11-09 16:07:18 --> URI Class Initialized
INFO - 2023-11-09 16:07:18 --> Router Class Initialized
INFO - 2023-11-09 16:07:18 --> Output Class Initialized
INFO - 2023-11-09 16:07:18 --> Security Class Initialized
DEBUG - 2023-11-09 16:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:07:18 --> Input Class Initialized
INFO - 2023-11-09 16:07:18 --> Language Class Initialized
ERROR - 2023-11-09 16:07:18 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:10:56 --> Config Class Initialized
INFO - 2023-11-09 16:10:56 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:56 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:56 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:56 --> URI Class Initialized
DEBUG - 2023-11-09 16:10:56 --> No URI present. Default controller set.
INFO - 2023-11-09 16:10:56 --> Router Class Initialized
INFO - 2023-11-09 16:10:56 --> Output Class Initialized
INFO - 2023-11-09 16:10:56 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:56 --> Input Class Initialized
INFO - 2023-11-09 16:10:56 --> Language Class Initialized
INFO - 2023-11-09 16:10:56 --> Loader Class Initialized
INFO - 2023-11-09 16:10:56 --> Helper loaded: url_helper
INFO - 2023-11-09 16:10:56 --> Helper loaded: file_helper
INFO - 2023-11-09 16:10:56 --> Database Driver Class Initialized
INFO - 2023-11-09 16:10:56 --> Email Class Initialized
DEBUG - 2023-11-09 16:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:10:56 --> Controller Class Initialized
INFO - 2023-11-09 16:10:56 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:10:56 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:10:56 --> Model "Home_model" initialized
INFO - 2023-11-09 16:10:56 --> Helper loaded: download_helper
INFO - 2023-11-09 16:10:56 --> Helper loaded: form_helper
INFO - 2023-11-09 16:10:56 --> Form Validation Class Initialized
INFO - 2023-11-09 20:40:56 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:40:56 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:40:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:40:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:40:56 --> Final output sent to browser
DEBUG - 2023-11-09 20:40:56 --> Total execution time: 0.1063
INFO - 2023-11-09 16:10:57 --> Config Class Initialized
INFO - 2023-11-09 16:10:57 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:57 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:57 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:57 --> URI Class Initialized
INFO - 2023-11-09 16:10:57 --> Router Class Initialized
INFO - 2023-11-09 16:10:57 --> Output Class Initialized
INFO - 2023-11-09 16:10:57 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:57 --> Input Class Initialized
INFO - 2023-11-09 16:10:57 --> Language Class Initialized
ERROR - 2023-11-09 16:10:57 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:10:59 --> Config Class Initialized
INFO - 2023-11-09 16:10:59 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:59 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:59 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:59 --> URI Class Initialized
INFO - 2023-11-09 16:10:59 --> Router Class Initialized
INFO - 2023-11-09 16:10:59 --> Output Class Initialized
INFO - 2023-11-09 16:10:59 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:59 --> Input Class Initialized
INFO - 2023-11-09 16:10:59 --> Language Class Initialized
ERROR - 2023-11-09 16:10:59 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:10:59 --> Config Class Initialized
INFO - 2023-11-09 16:10:59 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:59 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:59 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:59 --> URI Class Initialized
INFO - 2023-11-09 16:10:59 --> Router Class Initialized
INFO - 2023-11-09 16:10:59 --> Output Class Initialized
INFO - 2023-11-09 16:10:59 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:59 --> Input Class Initialized
INFO - 2023-11-09 16:10:59 --> Language Class Initialized
ERROR - 2023-11-09 16:10:59 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:10:59 --> Config Class Initialized
INFO - 2023-11-09 16:10:59 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:59 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:59 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:59 --> URI Class Initialized
INFO - 2023-11-09 16:10:59 --> Router Class Initialized
INFO - 2023-11-09 16:10:59 --> Output Class Initialized
INFO - 2023-11-09 16:10:59 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:59 --> Input Class Initialized
INFO - 2023-11-09 16:10:59 --> Language Class Initialized
ERROR - 2023-11-09 16:10:59 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:10:59 --> Config Class Initialized
INFO - 2023-11-09 16:10:59 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:10:59 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:10:59 --> Utf8 Class Initialized
INFO - 2023-11-09 16:10:59 --> URI Class Initialized
INFO - 2023-11-09 16:10:59 --> Router Class Initialized
INFO - 2023-11-09 16:10:59 --> Output Class Initialized
INFO - 2023-11-09 16:10:59 --> Security Class Initialized
DEBUG - 2023-11-09 16:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:10:59 --> Input Class Initialized
INFO - 2023-11-09 16:10:59 --> Language Class Initialized
ERROR - 2023-11-09 16:10:59 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:11:24 --> Config Class Initialized
INFO - 2023-11-09 16:11:24 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:24 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:24 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:24 --> URI Class Initialized
DEBUG - 2023-11-09 16:11:24 --> No URI present. Default controller set.
INFO - 2023-11-09 16:11:24 --> Router Class Initialized
INFO - 2023-11-09 16:11:24 --> Output Class Initialized
INFO - 2023-11-09 16:11:24 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:24 --> Input Class Initialized
INFO - 2023-11-09 16:11:24 --> Language Class Initialized
INFO - 2023-11-09 16:11:24 --> Loader Class Initialized
INFO - 2023-11-09 16:11:24 --> Helper loaded: url_helper
INFO - 2023-11-09 16:11:24 --> Helper loaded: file_helper
INFO - 2023-11-09 16:11:24 --> Database Driver Class Initialized
INFO - 2023-11-09 16:11:24 --> Email Class Initialized
DEBUG - 2023-11-09 16:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:11:24 --> Controller Class Initialized
INFO - 2023-11-09 16:11:24 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:11:24 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:11:24 --> Model "Home_model" initialized
INFO - 2023-11-09 16:11:24 --> Helper loaded: download_helper
INFO - 2023-11-09 16:11:24 --> Helper loaded: form_helper
INFO - 2023-11-09 16:11:24 --> Form Validation Class Initialized
INFO - 2023-11-09 20:41:24 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:41:24 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:41:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:41:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:41:24 --> Final output sent to browser
DEBUG - 2023-11-09 20:41:24 --> Total execution time: 0.1012
INFO - 2023-11-09 16:11:26 --> Config Class Initialized
INFO - 2023-11-09 16:11:26 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:26 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:26 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:26 --> URI Class Initialized
INFO - 2023-11-09 16:11:26 --> Router Class Initialized
INFO - 2023-11-09 16:11:26 --> Output Class Initialized
INFO - 2023-11-09 16:11:26 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:26 --> Input Class Initialized
INFO - 2023-11-09 16:11:26 --> Language Class Initialized
ERROR - 2023-11-09 16:11:26 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:11:26 --> Config Class Initialized
INFO - 2023-11-09 16:11:26 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:26 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:26 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:26 --> URI Class Initialized
INFO - 2023-11-09 16:11:26 --> Router Class Initialized
INFO - 2023-11-09 16:11:26 --> Output Class Initialized
INFO - 2023-11-09 16:11:26 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:26 --> Input Class Initialized
INFO - 2023-11-09 16:11:26 --> Language Class Initialized
ERROR - 2023-11-09 16:11:26 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:11:27 --> Config Class Initialized
INFO - 2023-11-09 16:11:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:27 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:27 --> URI Class Initialized
INFO - 2023-11-09 16:11:27 --> Router Class Initialized
INFO - 2023-11-09 16:11:28 --> Output Class Initialized
INFO - 2023-11-09 16:11:28 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:28 --> Input Class Initialized
INFO - 2023-11-09 16:11:28 --> Language Class Initialized
ERROR - 2023-11-09 16:11:28 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:11:28 --> Config Class Initialized
INFO - 2023-11-09 16:11:28 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:28 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:28 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:28 --> URI Class Initialized
INFO - 2023-11-09 16:11:28 --> Router Class Initialized
INFO - 2023-11-09 16:11:28 --> Output Class Initialized
INFO - 2023-11-09 16:11:28 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:28 --> Input Class Initialized
INFO - 2023-11-09 16:11:28 --> Language Class Initialized
ERROR - 2023-11-09 16:11:28 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:11:28 --> Config Class Initialized
INFO - 2023-11-09 16:11:28 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:11:28 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:11:28 --> Utf8 Class Initialized
INFO - 2023-11-09 16:11:28 --> URI Class Initialized
INFO - 2023-11-09 16:11:28 --> Router Class Initialized
INFO - 2023-11-09 16:11:28 --> Output Class Initialized
INFO - 2023-11-09 16:11:28 --> Security Class Initialized
DEBUG - 2023-11-09 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:11:28 --> Input Class Initialized
INFO - 2023-11-09 16:11:28 --> Language Class Initialized
ERROR - 2023-11-09 16:11:28 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 16:16:18 --> Config Class Initialized
INFO - 2023-11-09 16:16:18 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:16:18 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:16:18 --> Utf8 Class Initialized
INFO - 2023-11-09 16:16:18 --> URI Class Initialized
DEBUG - 2023-11-09 16:16:18 --> No URI present. Default controller set.
INFO - 2023-11-09 16:16:18 --> Router Class Initialized
INFO - 2023-11-09 16:16:18 --> Output Class Initialized
INFO - 2023-11-09 16:16:18 --> Security Class Initialized
DEBUG - 2023-11-09 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:16:18 --> Input Class Initialized
INFO - 2023-11-09 16:16:18 --> Language Class Initialized
INFO - 2023-11-09 16:16:18 --> Loader Class Initialized
INFO - 2023-11-09 16:16:18 --> Helper loaded: url_helper
INFO - 2023-11-09 16:16:18 --> Helper loaded: file_helper
INFO - 2023-11-09 16:16:18 --> Database Driver Class Initialized
INFO - 2023-11-09 16:16:18 --> Email Class Initialized
DEBUG - 2023-11-09 16:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:16:18 --> Controller Class Initialized
INFO - 2023-11-09 16:16:18 --> Model "Contact_model" initialized
INFO - 2023-11-09 16:16:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 16:16:18 --> Model "Home_model" initialized
INFO - 2023-11-09 16:16:18 --> Helper loaded: download_helper
INFO - 2023-11-09 16:16:18 --> Helper loaded: form_helper
INFO - 2023-11-09 16:16:18 --> Form Validation Class Initialized
INFO - 2023-11-09 20:46:18 --> Helper loaded: custom_helper
INFO - 2023-11-09 20:46:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 20:46:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 20:46:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 20:46:18 --> Final output sent to browser
DEBUG - 2023-11-09 20:46:18 --> Total execution time: 0.1761
INFO - 2023-11-09 17:00:01 --> Config Class Initialized
INFO - 2023-11-09 17:00:01 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:01 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:01 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:01 --> URI Class Initialized
INFO - 2023-11-09 17:00:01 --> Router Class Initialized
INFO - 2023-11-09 17:00:01 --> Output Class Initialized
INFO - 2023-11-09 17:00:01 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:01 --> Input Class Initialized
INFO - 2023-11-09 17:00:01 --> Language Class Initialized
INFO - 2023-11-09 17:00:01 --> Loader Class Initialized
INFO - 2023-11-09 17:00:01 --> Helper loaded: url_helper
INFO - 2023-11-09 17:00:01 --> Helper loaded: file_helper
INFO - 2023-11-09 17:00:01 --> Database Driver Class Initialized
INFO - 2023-11-09 17:00:01 --> Email Class Initialized
DEBUG - 2023-11-09 17:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:00:01 --> Controller Class Initialized
INFO - 2023-11-09 17:00:01 --> Model "Contact_model" initialized
INFO - 2023-11-09 17:00:01 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 17:00:01 --> Model "Home_model" initialized
INFO - 2023-11-09 17:00:01 --> Helper loaded: download_helper
INFO - 2023-11-09 17:00:01 --> Helper loaded: form_helper
INFO - 2023-11-09 17:00:01 --> Form Validation Class Initialized
INFO - 2023-11-09 21:30:01 --> Helper loaded: custom_helper
INFO - 2023-11-09 21:30:01 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 21:30:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 21:30:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-09 21:30:01 --> Final output sent to browser
DEBUG - 2023-11-09 21:30:01 --> Total execution time: 0.1799
INFO - 2023-11-09 17:00:03 --> Config Class Initialized
INFO - 2023-11-09 17:00:03 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:03 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:03 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:03 --> URI Class Initialized
INFO - 2023-11-09 17:00:03 --> Router Class Initialized
INFO - 2023-11-09 17:00:03 --> Output Class Initialized
INFO - 2023-11-09 17:00:03 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:03 --> Input Class Initialized
INFO - 2023-11-09 17:00:03 --> Language Class Initialized
ERROR - 2023-11-09 17:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:00:03 --> Config Class Initialized
INFO - 2023-11-09 17:00:03 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:03 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:03 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:03 --> URI Class Initialized
INFO - 2023-11-09 17:00:03 --> Router Class Initialized
INFO - 2023-11-09 17:00:03 --> Output Class Initialized
INFO - 2023-11-09 17:00:03 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:03 --> Input Class Initialized
INFO - 2023-11-09 17:00:03 --> Language Class Initialized
ERROR - 2023-11-09 17:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:00:03 --> Config Class Initialized
INFO - 2023-11-09 17:00:03 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:03 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:03 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:03 --> URI Class Initialized
INFO - 2023-11-09 17:00:03 --> Router Class Initialized
INFO - 2023-11-09 17:00:03 --> Output Class Initialized
INFO - 2023-11-09 17:00:03 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:03 --> Input Class Initialized
INFO - 2023-11-09 17:00:03 --> Language Class Initialized
ERROR - 2023-11-09 17:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:00:03 --> Config Class Initialized
INFO - 2023-11-09 17:00:03 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:03 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:03 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:03 --> URI Class Initialized
INFO - 2023-11-09 17:00:03 --> Router Class Initialized
INFO - 2023-11-09 17:00:03 --> Output Class Initialized
INFO - 2023-11-09 17:00:03 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:03 --> Input Class Initialized
INFO - 2023-11-09 17:00:03 --> Language Class Initialized
ERROR - 2023-11-09 17:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:00:04 --> Config Class Initialized
INFO - 2023-11-09 17:00:04 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:04 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:04 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:04 --> URI Class Initialized
INFO - 2023-11-09 17:00:04 --> Router Class Initialized
INFO - 2023-11-09 17:00:04 --> Output Class Initialized
INFO - 2023-11-09 17:00:04 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:04 --> Input Class Initialized
INFO - 2023-11-09 17:00:04 --> Language Class Initialized
ERROR - 2023-11-09 17:00:04 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:00:26 --> Config Class Initialized
INFO - 2023-11-09 17:00:26 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:00:26 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:00:26 --> Utf8 Class Initialized
INFO - 2023-11-09 17:00:26 --> URI Class Initialized
INFO - 2023-11-09 17:00:26 --> Router Class Initialized
INFO - 2023-11-09 17:00:26 --> Output Class Initialized
INFO - 2023-11-09 17:00:26 --> Security Class Initialized
DEBUG - 2023-11-09 17:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:00:26 --> Input Class Initialized
INFO - 2023-11-09 17:00:26 --> Language Class Initialized
INFO - 2023-11-09 17:00:26 --> Loader Class Initialized
INFO - 2023-11-09 17:00:26 --> Helper loaded: url_helper
INFO - 2023-11-09 17:00:26 --> Helper loaded: file_helper
INFO - 2023-11-09 17:00:26 --> Database Driver Class Initialized
INFO - 2023-11-09 17:00:26 --> Email Class Initialized
DEBUG - 2023-11-09 17:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:00:26 --> Controller Class Initialized
INFO - 2023-11-09 17:00:26 --> Model "Contact_model" initialized
INFO - 2023-11-09 17:00:26 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 17:00:26 --> Model "Home_model" initialized
INFO - 2023-11-09 17:00:26 --> Helper loaded: download_helper
INFO - 2023-11-09 17:00:26 --> Helper loaded: form_helper
INFO - 2023-11-09 17:00:26 --> Form Validation Class Initialized
INFO - 2023-11-09 17:19:19 --> Config Class Initialized
INFO - 2023-11-09 17:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:19 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:19 --> URI Class Initialized
INFO - 2023-11-09 17:19:19 --> Router Class Initialized
INFO - 2023-11-09 17:19:20 --> Output Class Initialized
INFO - 2023-11-09 17:19:20 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:20 --> Input Class Initialized
INFO - 2023-11-09 17:19:20 --> Language Class Initialized
INFO - 2023-11-09 17:19:20 --> Loader Class Initialized
INFO - 2023-11-09 17:19:20 --> Helper loaded: url_helper
INFO - 2023-11-09 17:19:20 --> Helper loaded: file_helper
INFO - 2023-11-09 17:19:20 --> Database Driver Class Initialized
INFO - 2023-11-09 17:19:20 --> Email Class Initialized
DEBUG - 2023-11-09 17:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:19:20 --> Controller Class Initialized
INFO - 2023-11-09 17:19:20 --> Model "Contact_model" initialized
INFO - 2023-11-09 17:19:20 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 17:19:20 --> Model "Home_model" initialized
INFO - 2023-11-09 17:19:20 --> Helper loaded: download_helper
INFO - 2023-11-09 17:19:20 --> Helper loaded: form_helper
INFO - 2023-11-09 17:19:20 --> Form Validation Class Initialized
INFO - 2023-11-09 21:49:21 --> Helper loaded: custom_helper
INFO - 2023-11-09 21:49:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 21:49:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 21:49:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-11-09 21:49:21 --> Final output sent to browser
DEBUG - 2023-11-09 21:49:21 --> Total execution time: 1.6065
INFO - 2023-11-09 17:19:22 --> Config Class Initialized
INFO - 2023-11-09 17:19:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:22 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:22 --> URI Class Initialized
INFO - 2023-11-09 17:19:22 --> Router Class Initialized
INFO - 2023-11-09 17:19:22 --> Output Class Initialized
INFO - 2023-11-09 17:19:22 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:22 --> Input Class Initialized
INFO - 2023-11-09 17:19:22 --> Language Class Initialized
ERROR - 2023-11-09 17:19:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:22 --> Config Class Initialized
INFO - 2023-11-09 17:19:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:22 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:22 --> URI Class Initialized
INFO - 2023-11-09 17:19:22 --> Router Class Initialized
INFO - 2023-11-09 17:19:22 --> Output Class Initialized
INFO - 2023-11-09 17:19:22 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:22 --> Input Class Initialized
INFO - 2023-11-09 17:19:22 --> Language Class Initialized
ERROR - 2023-11-09 17:19:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:24 --> Config Class Initialized
INFO - 2023-11-09 17:19:24 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:24 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:24 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:24 --> URI Class Initialized
INFO - 2023-11-09 17:19:24 --> Router Class Initialized
INFO - 2023-11-09 17:19:24 --> Output Class Initialized
INFO - 2023-11-09 17:19:24 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:24 --> Input Class Initialized
INFO - 2023-11-09 17:19:24 --> Language Class Initialized
INFO - 2023-11-09 17:19:24 --> Loader Class Initialized
INFO - 2023-11-09 17:19:24 --> Helper loaded: url_helper
INFO - 2023-11-09 17:19:24 --> Helper loaded: file_helper
INFO - 2023-11-09 17:19:24 --> Database Driver Class Initialized
INFO - 2023-11-09 17:19:25 --> Email Class Initialized
DEBUG - 2023-11-09 17:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:19:25 --> Controller Class Initialized
INFO - 2023-11-09 17:19:25 --> Model "Contact_model" initialized
INFO - 2023-11-09 17:19:25 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 17:19:25 --> Model "Home_model" initialized
INFO - 2023-11-09 17:19:25 --> Helper loaded: download_helper
INFO - 2023-11-09 17:19:25 --> Helper loaded: form_helper
INFO - 2023-11-09 17:19:25 --> Form Validation Class Initialized
INFO - 2023-11-09 21:49:25 --> Helper loaded: custom_helper
INFO - 2023-11-09 21:49:25 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 21:49:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 21:49:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-11-09 21:49:25 --> Final output sent to browser
DEBUG - 2023-11-09 21:49:25 --> Total execution time: 0.0839
INFO - 2023-11-09 17:19:26 --> Config Class Initialized
INFO - 2023-11-09 17:19:26 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:26 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:26 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:26 --> URI Class Initialized
INFO - 2023-11-09 17:19:26 --> Router Class Initialized
INFO - 2023-11-09 17:19:26 --> Output Class Initialized
INFO - 2023-11-09 17:19:26 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:26 --> Input Class Initialized
INFO - 2023-11-09 17:19:26 --> Language Class Initialized
ERROR - 2023-11-09 17:19:26 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 17:19:27 --> Config Class Initialized
INFO - 2023-11-09 17:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:19:27 --> Utf8 Class Initialized
INFO - 2023-11-09 17:19:27 --> URI Class Initialized
INFO - 2023-11-09 17:19:27 --> Router Class Initialized
INFO - 2023-11-09 17:19:27 --> Output Class Initialized
INFO - 2023-11-09 17:19:27 --> Security Class Initialized
DEBUG - 2023-11-09 17:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:19:27 --> Input Class Initialized
INFO - 2023-11-09 17:19:27 --> Language Class Initialized
ERROR - 2023-11-09 17:19:27 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:01:05 --> Config Class Initialized
INFO - 2023-11-09 18:01:05 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:01:05 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:01:05 --> Utf8 Class Initialized
INFO - 2023-11-09 18:01:05 --> URI Class Initialized
DEBUG - 2023-11-09 18:01:05 --> No URI present. Default controller set.
INFO - 2023-11-09 18:01:05 --> Router Class Initialized
INFO - 2023-11-09 18:01:05 --> Output Class Initialized
INFO - 2023-11-09 18:01:05 --> Security Class Initialized
DEBUG - 2023-11-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:01:05 --> Input Class Initialized
INFO - 2023-11-09 18:01:05 --> Language Class Initialized
INFO - 2023-11-09 18:01:05 --> Loader Class Initialized
INFO - 2023-11-09 18:01:05 --> Helper loaded: url_helper
INFO - 2023-11-09 18:01:05 --> Helper loaded: file_helper
INFO - 2023-11-09 18:01:05 --> Database Driver Class Initialized
INFO - 2023-11-09 18:01:05 --> Email Class Initialized
DEBUG - 2023-11-09 18:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:01:05 --> Controller Class Initialized
INFO - 2023-11-09 18:01:05 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:01:05 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:01:05 --> Model "Home_model" initialized
INFO - 2023-11-09 18:01:05 --> Helper loaded: download_helper
INFO - 2023-11-09 18:01:05 --> Helper loaded: form_helper
INFO - 2023-11-09 18:01:05 --> Form Validation Class Initialized
INFO - 2023-11-09 22:31:06 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:31:06 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:31:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:31:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:31:06 --> Final output sent to browser
DEBUG - 2023-11-09 22:31:06 --> Total execution time: 0.3650
INFO - 2023-11-09 18:03:13 --> Config Class Initialized
INFO - 2023-11-09 18:03:13 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:03:13 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:03:13 --> Utf8 Class Initialized
INFO - 2023-11-09 18:03:13 --> URI Class Initialized
DEBUG - 2023-11-09 18:03:13 --> No URI present. Default controller set.
INFO - 2023-11-09 18:03:13 --> Router Class Initialized
INFO - 2023-11-09 18:03:13 --> Output Class Initialized
INFO - 2023-11-09 18:03:13 --> Security Class Initialized
DEBUG - 2023-11-09 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:03:13 --> Input Class Initialized
INFO - 2023-11-09 18:03:13 --> Language Class Initialized
INFO - 2023-11-09 18:03:13 --> Loader Class Initialized
INFO - 2023-11-09 18:03:13 --> Helper loaded: url_helper
INFO - 2023-11-09 18:03:13 --> Helper loaded: file_helper
INFO - 2023-11-09 18:03:13 --> Database Driver Class Initialized
INFO - 2023-11-09 18:03:13 --> Email Class Initialized
DEBUG - 2023-11-09 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:03:13 --> Controller Class Initialized
INFO - 2023-11-09 18:03:13 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:03:13 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:03:13 --> Model "Home_model" initialized
INFO - 2023-11-09 18:03:13 --> Helper loaded: download_helper
INFO - 2023-11-09 18:03:13 --> Helper loaded: form_helper
INFO - 2023-11-09 18:03:13 --> Form Validation Class Initialized
INFO - 2023-11-09 22:33:13 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:33:13 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:33:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:33:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:33:13 --> Final output sent to browser
DEBUG - 2023-11-09 22:33:13 --> Total execution time: 0.1489
INFO - 2023-11-09 18:04:02 --> Config Class Initialized
INFO - 2023-11-09 18:04:02 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:04:02 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:04:02 --> Utf8 Class Initialized
INFO - 2023-11-09 18:04:02 --> URI Class Initialized
DEBUG - 2023-11-09 18:04:02 --> No URI present. Default controller set.
INFO - 2023-11-09 18:04:02 --> Router Class Initialized
INFO - 2023-11-09 18:04:02 --> Output Class Initialized
INFO - 2023-11-09 18:04:02 --> Security Class Initialized
DEBUG - 2023-11-09 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:04:02 --> Input Class Initialized
INFO - 2023-11-09 18:04:02 --> Language Class Initialized
INFO - 2023-11-09 18:04:02 --> Loader Class Initialized
INFO - 2023-11-09 18:04:02 --> Helper loaded: url_helper
INFO - 2023-11-09 18:04:02 --> Helper loaded: file_helper
INFO - 2023-11-09 18:04:02 --> Database Driver Class Initialized
INFO - 2023-11-09 18:04:02 --> Email Class Initialized
DEBUG - 2023-11-09 18:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:04:02 --> Controller Class Initialized
INFO - 2023-11-09 18:04:02 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:04:02 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:04:02 --> Model "Home_model" initialized
INFO - 2023-11-09 18:04:02 --> Helper loaded: download_helper
INFO - 2023-11-09 18:04:02 --> Helper loaded: form_helper
INFO - 2023-11-09 18:04:02 --> Form Validation Class Initialized
INFO - 2023-11-09 22:34:02 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:34:02 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:34:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:34:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:34:02 --> Final output sent to browser
DEBUG - 2023-11-09 22:34:02 --> Total execution time: 0.0872
INFO - 2023-11-09 18:04:16 --> Config Class Initialized
INFO - 2023-11-09 18:04:16 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:04:16 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:04:16 --> Utf8 Class Initialized
INFO - 2023-11-09 18:04:16 --> URI Class Initialized
DEBUG - 2023-11-09 18:04:16 --> No URI present. Default controller set.
INFO - 2023-11-09 18:04:16 --> Router Class Initialized
INFO - 2023-11-09 18:04:16 --> Output Class Initialized
INFO - 2023-11-09 18:04:16 --> Security Class Initialized
DEBUG - 2023-11-09 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:04:16 --> Input Class Initialized
INFO - 2023-11-09 18:04:16 --> Language Class Initialized
INFO - 2023-11-09 18:04:16 --> Loader Class Initialized
INFO - 2023-11-09 18:04:16 --> Helper loaded: url_helper
INFO - 2023-11-09 18:04:16 --> Helper loaded: file_helper
INFO - 2023-11-09 18:04:16 --> Database Driver Class Initialized
INFO - 2023-11-09 18:04:16 --> Email Class Initialized
DEBUG - 2023-11-09 18:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:04:16 --> Controller Class Initialized
INFO - 2023-11-09 18:04:16 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:04:16 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:04:16 --> Model "Home_model" initialized
INFO - 2023-11-09 18:04:16 --> Helper loaded: download_helper
INFO - 2023-11-09 18:04:16 --> Helper loaded: form_helper
INFO - 2023-11-09 18:04:16 --> Form Validation Class Initialized
INFO - 2023-11-09 22:34:16 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:34:16 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:34:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:34:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:34:16 --> Final output sent to browser
DEBUG - 2023-11-09 22:34:16 --> Total execution time: 0.0951
INFO - 2023-11-09 18:04:32 --> Config Class Initialized
INFO - 2023-11-09 18:04:32 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:04:32 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:04:32 --> Utf8 Class Initialized
INFO - 2023-11-09 18:04:32 --> URI Class Initialized
DEBUG - 2023-11-09 18:04:32 --> No URI present. Default controller set.
INFO - 2023-11-09 18:04:32 --> Router Class Initialized
INFO - 2023-11-09 18:04:32 --> Output Class Initialized
INFO - 2023-11-09 18:04:32 --> Security Class Initialized
DEBUG - 2023-11-09 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:04:32 --> Input Class Initialized
INFO - 2023-11-09 18:04:32 --> Language Class Initialized
INFO - 2023-11-09 18:04:32 --> Loader Class Initialized
INFO - 2023-11-09 18:04:32 --> Helper loaded: url_helper
INFO - 2023-11-09 18:04:32 --> Helper loaded: file_helper
INFO - 2023-11-09 18:04:32 --> Database Driver Class Initialized
INFO - 2023-11-09 18:04:32 --> Email Class Initialized
DEBUG - 2023-11-09 18:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:04:32 --> Controller Class Initialized
INFO - 2023-11-09 18:04:32 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:04:32 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:04:32 --> Model "Home_model" initialized
INFO - 2023-11-09 18:04:32 --> Helper loaded: download_helper
INFO - 2023-11-09 18:04:32 --> Helper loaded: form_helper
INFO - 2023-11-09 18:04:32 --> Form Validation Class Initialized
INFO - 2023-11-09 22:34:32 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:34:32 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:34:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:34:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:34:32 --> Final output sent to browser
DEBUG - 2023-11-09 22:34:33 --> Total execution time: 0.1083
INFO - 2023-11-09 18:05:01 --> Config Class Initialized
INFO - 2023-11-09 18:05:01 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:01 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:01 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:01 --> URI Class Initialized
DEBUG - 2023-11-09 18:05:01 --> No URI present. Default controller set.
INFO - 2023-11-09 18:05:01 --> Router Class Initialized
INFO - 2023-11-09 18:05:01 --> Output Class Initialized
INFO - 2023-11-09 18:05:01 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:01 --> Input Class Initialized
INFO - 2023-11-09 18:05:01 --> Language Class Initialized
INFO - 2023-11-09 18:05:01 --> Loader Class Initialized
INFO - 2023-11-09 18:05:01 --> Helper loaded: url_helper
INFO - 2023-11-09 18:05:01 --> Helper loaded: file_helper
INFO - 2023-11-09 18:05:01 --> Database Driver Class Initialized
INFO - 2023-11-09 18:05:01 --> Email Class Initialized
DEBUG - 2023-11-09 18:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:05:01 --> Controller Class Initialized
INFO - 2023-11-09 18:05:01 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:05:01 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:05:01 --> Model "Home_model" initialized
INFO - 2023-11-09 18:05:01 --> Helper loaded: download_helper
INFO - 2023-11-09 18:05:01 --> Helper loaded: form_helper
INFO - 2023-11-09 18:05:01 --> Form Validation Class Initialized
INFO - 2023-11-09 22:35:01 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:35:01 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:35:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:35:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:35:01 --> Final output sent to browser
DEBUG - 2023-11-09 22:35:01 --> Total execution time: 0.1137
INFO - 2023-11-09 18:05:12 --> Config Class Initialized
INFO - 2023-11-09 18:05:12 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:12 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:12 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:12 --> URI Class Initialized
INFO - 2023-11-09 18:05:12 --> Router Class Initialized
INFO - 2023-11-09 18:05:12 --> Output Class Initialized
INFO - 2023-11-09 18:05:12 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:12 --> Input Class Initialized
INFO - 2023-11-09 18:05:12 --> Language Class Initialized
INFO - 2023-11-09 18:05:12 --> Loader Class Initialized
INFO - 2023-11-09 18:05:12 --> Helper loaded: url_helper
INFO - 2023-11-09 18:05:12 --> Helper loaded: file_helper
INFO - 2023-11-09 18:05:12 --> Database Driver Class Initialized
INFO - 2023-11-09 18:05:12 --> Email Class Initialized
DEBUG - 2023-11-09 18:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:05:12 --> Controller Class Initialized
INFO - 2023-11-09 18:05:12 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:05:12 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:05:12 --> Model "Home_model" initialized
INFO - 2023-11-09 18:05:12 --> Helper loaded: download_helper
INFO - 2023-11-09 18:05:12 --> Helper loaded: form_helper
INFO - 2023-11-09 18:05:12 --> Form Validation Class Initialized
ERROR - 2023-11-09 22:35:12 --> Severity: Warning --> Undefined variable $services_names C:\xampp\htdocs\dw\application\controllers\HomeController.php 202
DEBUG - 2023-11-09 22:35:12 --> Phpmailer class already loaded. Second attempt ignored.
INFO - 2023-11-09 18:05:21 --> Config Class Initialized
INFO - 2023-11-09 18:05:21 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:21 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:21 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:21 --> URI Class Initialized
INFO - 2023-11-09 18:05:21 --> Router Class Initialized
INFO - 2023-11-09 18:05:21 --> Output Class Initialized
INFO - 2023-11-09 18:05:21 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:21 --> Input Class Initialized
INFO - 2023-11-09 18:05:21 --> Language Class Initialized
ERROR - 2023-11-09 18:05:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:21 --> Config Class Initialized
INFO - 2023-11-09 18:05:21 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:21 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:21 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:21 --> URI Class Initialized
INFO - 2023-11-09 18:05:21 --> Router Class Initialized
INFO - 2023-11-09 18:05:21 --> Output Class Initialized
INFO - 2023-11-09 18:05:21 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:21 --> Input Class Initialized
INFO - 2023-11-09 18:05:21 --> Language Class Initialized
ERROR - 2023-11-09 18:05:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:22 --> Config Class Initialized
INFO - 2023-11-09 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:22 --> URI Class Initialized
INFO - 2023-11-09 18:05:22 --> Router Class Initialized
INFO - 2023-11-09 18:05:22 --> Output Class Initialized
INFO - 2023-11-09 18:05:22 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:22 --> Input Class Initialized
INFO - 2023-11-09 18:05:22 --> Language Class Initialized
ERROR - 2023-11-09 18:05:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:22 --> Config Class Initialized
INFO - 2023-11-09 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:22 --> URI Class Initialized
INFO - 2023-11-09 18:05:22 --> Router Class Initialized
INFO - 2023-11-09 18:05:22 --> Output Class Initialized
INFO - 2023-11-09 18:05:22 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:22 --> Input Class Initialized
INFO - 2023-11-09 18:05:22 --> Language Class Initialized
ERROR - 2023-11-09 18:05:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:22 --> Config Class Initialized
INFO - 2023-11-09 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:22 --> URI Class Initialized
INFO - 2023-11-09 18:05:22 --> Router Class Initialized
INFO - 2023-11-09 18:05:22 --> Output Class Initialized
INFO - 2023-11-09 18:05:22 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:22 --> Input Class Initialized
INFO - 2023-11-09 18:05:22 --> Language Class Initialized
ERROR - 2023-11-09 18:05:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:22 --> Config Class Initialized
INFO - 2023-11-09 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:22 --> URI Class Initialized
INFO - 2023-11-09 18:05:22 --> Router Class Initialized
INFO - 2023-11-09 18:05:22 --> Output Class Initialized
INFO - 2023-11-09 18:05:22 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:22 --> Input Class Initialized
INFO - 2023-11-09 18:05:22 --> Language Class Initialized
ERROR - 2023-11-09 18:05:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:05:22 --> Config Class Initialized
INFO - 2023-11-09 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:05:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:05:22 --> URI Class Initialized
INFO - 2023-11-09 18:05:22 --> Router Class Initialized
INFO - 2023-11-09 18:05:22 --> Output Class Initialized
INFO - 2023-11-09 18:05:22 --> Security Class Initialized
DEBUG - 2023-11-09 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:05:22 --> Input Class Initialized
INFO - 2023-11-09 18:05:22 --> Language Class Initialized
ERROR - 2023-11-09 18:05:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:09:35 --> Config Class Initialized
INFO - 2023-11-09 18:09:35 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:09:35 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:09:35 --> Utf8 Class Initialized
INFO - 2023-11-09 18:09:35 --> URI Class Initialized
INFO - 2023-11-09 18:09:35 --> Router Class Initialized
INFO - 2023-11-09 18:09:35 --> Output Class Initialized
INFO - 2023-11-09 18:09:35 --> Security Class Initialized
DEBUG - 2023-11-09 18:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:09:35 --> Input Class Initialized
INFO - 2023-11-09 18:09:35 --> Language Class Initialized
INFO - 2023-11-09 18:09:35 --> Loader Class Initialized
INFO - 2023-11-09 18:09:35 --> Helper loaded: url_helper
INFO - 2023-11-09 18:09:35 --> Helper loaded: file_helper
INFO - 2023-11-09 18:09:35 --> Database Driver Class Initialized
INFO - 2023-11-09 18:09:35 --> Email Class Initialized
DEBUG - 2023-11-09 18:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:09:35 --> Controller Class Initialized
INFO - 2023-11-09 18:09:35 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:09:35 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:09:35 --> Model "Home_model" initialized
INFO - 2023-11-09 18:09:35 --> Helper loaded: download_helper
INFO - 2023-11-09 18:09:35 --> Helper loaded: form_helper
INFO - 2023-11-09 18:09:35 --> Form Validation Class Initialized
DEBUG - 2023-11-09 22:39:35 --> Phpmailer class already loaded. Second attempt ignored.
INFO - 2023-11-09 18:22:19 --> Config Class Initialized
INFO - 2023-11-09 18:22:19 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:22:19 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:22:19 --> Utf8 Class Initialized
INFO - 2023-11-09 18:22:19 --> URI Class Initialized
INFO - 2023-11-09 18:22:19 --> Router Class Initialized
INFO - 2023-11-09 18:22:19 --> Output Class Initialized
INFO - 2023-11-09 18:22:19 --> Security Class Initialized
DEBUG - 2023-11-09 18:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:22:19 --> Input Class Initialized
INFO - 2023-11-09 18:22:19 --> Language Class Initialized
INFO - 2023-11-09 18:22:19 --> Loader Class Initialized
INFO - 2023-11-09 18:22:19 --> Helper loaded: url_helper
INFO - 2023-11-09 18:22:19 --> Helper loaded: file_helper
INFO - 2023-11-09 18:22:19 --> Database Driver Class Initialized
INFO - 2023-11-09 18:22:19 --> Email Class Initialized
DEBUG - 2023-11-09 18:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:22:19 --> Controller Class Initialized
INFO - 2023-11-09 18:22:19 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:22:19 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:22:19 --> Model "Home_model" initialized
INFO - 2023-11-09 18:22:19 --> Helper loaded: download_helper
INFO - 2023-11-09 18:22:19 --> Helper loaded: form_helper
INFO - 2023-11-09 18:22:19 --> Form Validation Class Initialized
INFO - 2023-11-09 22:52:19 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:52:19 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:52:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-09 22:52:19 --> Final output sent to browser
DEBUG - 2023-11-09 22:52:19 --> Total execution time: 0.2268
INFO - 2023-11-09 18:22:21 --> Config Class Initialized
INFO - 2023-11-09 18:22:21 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:22:21 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:22:21 --> Utf8 Class Initialized
INFO - 2023-11-09 18:22:21 --> URI Class Initialized
INFO - 2023-11-09 18:22:21 --> Router Class Initialized
INFO - 2023-11-09 18:22:21 --> Output Class Initialized
INFO - 2023-11-09 18:22:21 --> Security Class Initialized
DEBUG - 2023-11-09 18:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:22:21 --> Input Class Initialized
INFO - 2023-11-09 18:22:21 --> Language Class Initialized
ERROR - 2023-11-09 18:22:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:22:21 --> Config Class Initialized
INFO - 2023-11-09 18:22:21 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:22:21 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:22:21 --> Utf8 Class Initialized
INFO - 2023-11-09 18:22:21 --> URI Class Initialized
INFO - 2023-11-09 18:22:21 --> Router Class Initialized
INFO - 2023-11-09 18:22:21 --> Output Class Initialized
INFO - 2023-11-09 18:22:21 --> Security Class Initialized
DEBUG - 2023-11-09 18:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:22:21 --> Input Class Initialized
INFO - 2023-11-09 18:22:21 --> Language Class Initialized
ERROR - 2023-11-09 18:22:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:22:22 --> Config Class Initialized
INFO - 2023-11-09 18:22:22 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:22:22 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:22:22 --> Utf8 Class Initialized
INFO - 2023-11-09 18:22:22 --> URI Class Initialized
INFO - 2023-11-09 18:22:22 --> Router Class Initialized
INFO - 2023-11-09 18:22:22 --> Output Class Initialized
INFO - 2023-11-09 18:22:22 --> Config Class Initialized
INFO - 2023-11-09 18:22:23 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:22:23 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:22:23 --> Utf8 Class Initialized
INFO - 2023-11-09 18:22:23 --> URI Class Initialized
INFO - 2023-11-09 18:22:23 --> Router Class Initialized
INFO - 2023-11-09 18:22:23 --> Output Class Initialized
INFO - 2023-11-09 18:22:23 --> Security Class Initialized
DEBUG - 2023-11-09 18:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:22:23 --> Input Class Initialized
INFO - 2023-11-09 18:22:23 --> Language Class Initialized
ERROR - 2023-11-09 18:22:23 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:22:23 --> Security Class Initialized
INFO - 2023-11-09 18:23:27 --> Config Class Initialized
INFO - 2023-11-09 18:23:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:23:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:23:27 --> Utf8 Class Initialized
INFO - 2023-11-09 18:23:27 --> URI Class Initialized
INFO - 2023-11-09 18:23:27 --> Router Class Initialized
INFO - 2023-11-09 18:23:27 --> Output Class Initialized
INFO - 2023-11-09 18:23:27 --> Security Class Initialized
DEBUG - 2023-11-09 18:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:23:27 --> Input Class Initialized
INFO - 2023-11-09 18:23:27 --> Language Class Initialized
INFO - 2023-11-09 18:23:27 --> Loader Class Initialized
INFO - 2023-11-09 18:23:27 --> Helper loaded: url_helper
INFO - 2023-11-09 18:23:27 --> Helper loaded: file_helper
INFO - 2023-11-09 18:23:27 --> Database Driver Class Initialized
INFO - 2023-11-09 18:23:27 --> Email Class Initialized
DEBUG - 2023-11-09 18:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:23:27 --> Controller Class Initialized
INFO - 2023-11-09 18:23:27 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:23:27 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:23:27 --> Model "Home_model" initialized
INFO - 2023-11-09 18:23:27 --> Helper loaded: download_helper
INFO - 2023-11-09 18:23:27 --> Helper loaded: form_helper
INFO - 2023-11-09 18:23:27 --> Form Validation Class Initialized
INFO - 2023-11-09 22:53:27 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:53:27 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:53:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:53:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-09 22:53:27 --> Final output sent to browser
DEBUG - 2023-11-09 22:53:27 --> Total execution time: 0.1322
INFO - 2023-11-09 18:23:29 --> Config Class Initialized
INFO - 2023-11-09 18:23:29 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:23:29 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:23:29 --> Utf8 Class Initialized
INFO - 2023-11-09 18:23:29 --> URI Class Initialized
INFO - 2023-11-09 18:23:29 --> Router Class Initialized
INFO - 2023-11-09 18:23:29 --> Output Class Initialized
INFO - 2023-11-09 18:23:29 --> Security Class Initialized
DEBUG - 2023-11-09 18:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:23:29 --> Input Class Initialized
INFO - 2023-11-09 18:23:29 --> Language Class Initialized
ERROR - 2023-11-09 18:23:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:25:52 --> Config Class Initialized
INFO - 2023-11-09 18:25:52 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:25:52 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:25:52 --> Utf8 Class Initialized
INFO - 2023-11-09 18:25:52 --> URI Class Initialized
INFO - 2023-11-09 18:25:52 --> Router Class Initialized
INFO - 2023-11-09 18:25:52 --> Output Class Initialized
INFO - 2023-11-09 18:25:52 --> Security Class Initialized
DEBUG - 2023-11-09 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:25:52 --> Input Class Initialized
INFO - 2023-11-09 18:25:52 --> Language Class Initialized
INFO - 2023-11-09 18:25:52 --> Loader Class Initialized
INFO - 2023-11-09 18:25:52 --> Helper loaded: url_helper
INFO - 2023-11-09 18:25:52 --> Helper loaded: file_helper
INFO - 2023-11-09 18:25:52 --> Database Driver Class Initialized
INFO - 2023-11-09 18:25:52 --> Email Class Initialized
DEBUG - 2023-11-09 18:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:25:52 --> Controller Class Initialized
INFO - 2023-11-09 18:25:52 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:25:52 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:25:52 --> Model "Home_model" initialized
INFO - 2023-11-09 18:25:52 --> Helper loaded: download_helper
INFO - 2023-11-09 18:25:52 --> Helper loaded: form_helper
INFO - 2023-11-09 18:25:52 --> Form Validation Class Initialized
INFO - 2023-11-09 22:55:52 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:55:52 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:55:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:55:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-09 22:55:52 --> Final output sent to browser
DEBUG - 2023-11-09 22:55:52 --> Total execution time: 0.1453
INFO - 2023-11-09 18:25:54 --> Config Class Initialized
INFO - 2023-11-09 18:25:54 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:25:54 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:25:54 --> Utf8 Class Initialized
INFO - 2023-11-09 18:25:54 --> URI Class Initialized
INFO - 2023-11-09 18:25:54 --> Router Class Initialized
INFO - 2023-11-09 18:25:54 --> Output Class Initialized
INFO - 2023-11-09 18:25:54 --> Security Class Initialized
DEBUG - 2023-11-09 18:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:25:54 --> Input Class Initialized
INFO - 2023-11-09 18:25:54 --> Language Class Initialized
ERROR - 2023-11-09 18:25:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:25:54 --> Config Class Initialized
INFO - 2023-11-09 18:25:54 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:25:54 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:25:54 --> Utf8 Class Initialized
INFO - 2023-11-09 18:25:54 --> URI Class Initialized
INFO - 2023-11-09 18:25:54 --> Router Class Initialized
INFO - 2023-11-09 18:25:54 --> Output Class Initialized
INFO - 2023-11-09 18:25:54 --> Security Class Initialized
DEBUG - 2023-11-09 18:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:25:54 --> Input Class Initialized
INFO - 2023-11-09 18:25:54 --> Language Class Initialized
ERROR - 2023-11-09 18:25:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:25:54 --> Config Class Initialized
INFO - 2023-11-09 18:25:54 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:25:54 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:25:54 --> Utf8 Class Initialized
INFO - 2023-11-09 18:25:54 --> URI Class Initialized
INFO - 2023-11-09 18:25:54 --> Router Class Initialized
INFO - 2023-11-09 18:25:54 --> Output Class Initialized
INFO - 2023-11-09 18:25:54 --> Security Class Initialized
DEBUG - 2023-11-09 18:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:25:54 --> Input Class Initialized
INFO - 2023-11-09 18:25:54 --> Language Class Initialized
ERROR - 2023-11-09 18:25:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:26:08 --> Config Class Initialized
INFO - 2023-11-09 18:26:08 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:26:08 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:26:08 --> Utf8 Class Initialized
INFO - 2023-11-09 18:26:08 --> URI Class Initialized
INFO - 2023-11-09 18:26:08 --> Router Class Initialized
INFO - 2023-11-09 18:26:08 --> Output Class Initialized
INFO - 2023-11-09 18:26:08 --> Security Class Initialized
DEBUG - 2023-11-09 18:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:26:08 --> Input Class Initialized
INFO - 2023-11-09 18:26:08 --> Language Class Initialized
INFO - 2023-11-09 18:26:08 --> Loader Class Initialized
INFO - 2023-11-09 18:26:08 --> Helper loaded: url_helper
INFO - 2023-11-09 18:26:08 --> Helper loaded: file_helper
INFO - 2023-11-09 18:26:08 --> Database Driver Class Initialized
INFO - 2023-11-09 18:26:08 --> Email Class Initialized
DEBUG - 2023-11-09 18:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:26:08 --> Controller Class Initialized
INFO - 2023-11-09 18:26:08 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:26:08 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:26:08 --> Model "Home_model" initialized
INFO - 2023-11-09 18:26:08 --> Helper loaded: download_helper
INFO - 2023-11-09 18:26:08 --> Helper loaded: form_helper
INFO - 2023-11-09 18:26:08 --> Form Validation Class Initialized
INFO - 2023-11-09 22:56:08 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:56:08 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:56:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:56:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-09 22:56:08 --> Final output sent to browser
DEBUG - 2023-11-09 22:56:08 --> Total execution time: 0.1327
INFO - 2023-11-09 18:29:17 --> Config Class Initialized
INFO - 2023-11-09 18:29:17 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:17 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:17 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:17 --> URI Class Initialized
DEBUG - 2023-11-09 18:29:17 --> No URI present. Default controller set.
INFO - 2023-11-09 18:29:17 --> Router Class Initialized
INFO - 2023-11-09 18:29:17 --> Output Class Initialized
INFO - 2023-11-09 18:29:17 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:17 --> Input Class Initialized
INFO - 2023-11-09 18:29:17 --> Language Class Initialized
INFO - 2023-11-09 18:29:17 --> Loader Class Initialized
INFO - 2023-11-09 18:29:17 --> Helper loaded: url_helper
INFO - 2023-11-09 18:29:17 --> Helper loaded: file_helper
INFO - 2023-11-09 18:29:17 --> Database Driver Class Initialized
INFO - 2023-11-09 18:29:17 --> Email Class Initialized
DEBUG - 2023-11-09 18:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:29:17 --> Controller Class Initialized
INFO - 2023-11-09 18:29:17 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:29:17 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:29:17 --> Model "Home_model" initialized
INFO - 2023-11-09 18:29:17 --> Helper loaded: download_helper
INFO - 2023-11-09 18:29:17 --> Helper loaded: form_helper
INFO - 2023-11-09 18:29:17 --> Form Validation Class Initialized
INFO - 2023-11-09 22:59:17 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:59:17 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:59:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:59:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 22:59:17 --> Final output sent to browser
DEBUG - 2023-11-09 22:59:17 --> Total execution time: 0.0978
INFO - 2023-11-09 18:29:25 --> Config Class Initialized
INFO - 2023-11-09 18:29:25 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:25 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:25 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:25 --> URI Class Initialized
INFO - 2023-11-09 18:29:25 --> Router Class Initialized
INFO - 2023-11-09 18:29:25 --> Output Class Initialized
INFO - 2023-11-09 18:29:25 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:25 --> Input Class Initialized
INFO - 2023-11-09 18:29:25 --> Language Class Initialized
INFO - 2023-11-09 18:29:25 --> Loader Class Initialized
INFO - 2023-11-09 18:29:25 --> Helper loaded: url_helper
INFO - 2023-11-09 18:29:25 --> Helper loaded: file_helper
INFO - 2023-11-09 18:29:25 --> Database Driver Class Initialized
INFO - 2023-11-09 18:29:25 --> Email Class Initialized
DEBUG - 2023-11-09 18:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:29:25 --> Controller Class Initialized
INFO - 2023-11-09 18:29:25 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:29:25 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:29:25 --> Model "Home_model" initialized
INFO - 2023-11-09 18:29:25 --> Helper loaded: download_helper
INFO - 2023-11-09 18:29:25 --> Helper loaded: form_helper
INFO - 2023-11-09 18:29:25 --> Form Validation Class Initialized
INFO - 2023-11-09 22:59:25 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:59:25 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:59:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:59:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-11-09 22:59:25 --> Final output sent to browser
DEBUG - 2023-11-09 22:59:25 --> Total execution time: 0.1270
INFO - 2023-11-09 18:29:30 --> Config Class Initialized
INFO - 2023-11-09 18:29:30 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:30 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:30 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:30 --> URI Class Initialized
INFO - 2023-11-09 18:29:30 --> Router Class Initialized
INFO - 2023-11-09 18:29:30 --> Output Class Initialized
INFO - 2023-11-09 18:29:30 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:30 --> Input Class Initialized
INFO - 2023-11-09 18:29:30 --> Language Class Initialized
INFO - 2023-11-09 18:29:30 --> Loader Class Initialized
INFO - 2023-11-09 18:29:30 --> Helper loaded: url_helper
INFO - 2023-11-09 18:29:30 --> Helper loaded: file_helper
INFO - 2023-11-09 18:29:30 --> Database Driver Class Initialized
INFO - 2023-11-09 18:29:30 --> Email Class Initialized
DEBUG - 2023-11-09 18:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:29:30 --> Controller Class Initialized
INFO - 2023-11-09 18:29:30 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:29:30 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:29:30 --> Model "Home_model" initialized
INFO - 2023-11-09 18:29:30 --> Helper loaded: download_helper
INFO - 2023-11-09 18:29:30 --> Helper loaded: form_helper
INFO - 2023-11-09 18:29:30 --> Form Validation Class Initialized
INFO - 2023-11-09 22:59:30 --> Helper loaded: custom_helper
INFO - 2023-11-09 22:59:30 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 22:59:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 22:59:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-09 22:59:30 --> Final output sent to browser
DEBUG - 2023-11-09 22:59:30 --> Total execution time: 0.2481
INFO - 2023-11-09 18:29:40 --> Config Class Initialized
INFO - 2023-11-09 18:29:40 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:40 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:40 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:40 --> URI Class Initialized
INFO - 2023-11-09 18:29:40 --> Router Class Initialized
INFO - 2023-11-09 18:29:40 --> Output Class Initialized
INFO - 2023-11-09 18:29:40 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:40 --> Input Class Initialized
INFO - 2023-11-09 18:29:40 --> Language Class Initialized
ERROR - 2023-11-09 18:29:40 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:29:41 --> Config Class Initialized
INFO - 2023-11-09 18:29:41 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:41 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:41 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:41 --> URI Class Initialized
INFO - 2023-11-09 18:29:41 --> Router Class Initialized
INFO - 2023-11-09 18:29:41 --> Output Class Initialized
INFO - 2023-11-09 18:29:41 --> Security Class Initialized
INFO - 2023-11-09 18:29:41 --> Config Class Initialized
INFO - 2023-11-09 18:29:41 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:41 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:41 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:41 --> URI Class Initialized
INFO - 2023-11-09 18:29:41 --> Router Class Initialized
INFO - 2023-11-09 18:29:41 --> Output Class Initialized
INFO - 2023-11-09 18:29:41 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:41 --> Input Class Initialized
INFO - 2023-11-09 18:29:41 --> Language Class Initialized
ERROR - 2023-11-09 18:29:41 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-09 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:42 --> Input Class Initialized
INFO - 2023-11-09 18:29:42 --> Language Class Initialized
ERROR - 2023-11-09 18:29:42 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:29:42 --> Config Class Initialized
INFO - 2023-11-09 18:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:42 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:42 --> URI Class Initialized
INFO - 2023-11-09 18:29:42 --> Router Class Initialized
INFO - 2023-11-09 18:29:42 --> Output Class Initialized
INFO - 2023-11-09 18:29:42 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:42 --> Input Class Initialized
INFO - 2023-11-09 18:29:42 --> Language Class Initialized
ERROR - 2023-11-09 18:29:42 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:29:42 --> Config Class Initialized
INFO - 2023-11-09 18:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:42 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:42 --> URI Class Initialized
INFO - 2023-11-09 18:29:42 --> Router Class Initialized
INFO - 2023-11-09 18:29:42 --> Output Class Initialized
INFO - 2023-11-09 18:29:42 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:42 --> Input Class Initialized
INFO - 2023-11-09 18:29:42 --> Language Class Initialized
ERROR - 2023-11-09 18:29:42 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:29:42 --> Config Class Initialized
INFO - 2023-11-09 18:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:42 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:42 --> URI Class Initialized
INFO - 2023-11-09 18:29:42 --> Router Class Initialized
INFO - 2023-11-09 18:29:42 --> Output Class Initialized
INFO - 2023-11-09 18:29:42 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:42 --> Input Class Initialized
INFO - 2023-11-09 18:29:42 --> Language Class Initialized
ERROR - 2023-11-09 18:29:42 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:29:42 --> Config Class Initialized
INFO - 2023-11-09 18:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:29:42 --> Utf8 Class Initialized
INFO - 2023-11-09 18:29:42 --> URI Class Initialized
INFO - 2023-11-09 18:29:42 --> Router Class Initialized
INFO - 2023-11-09 18:29:42 --> Output Class Initialized
INFO - 2023-11-09 18:29:42 --> Security Class Initialized
DEBUG - 2023-11-09 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:29:42 --> Input Class Initialized
INFO - 2023-11-09 18:29:42 --> Language Class Initialized
ERROR - 2023-11-09 18:29:42 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:30:32 --> Config Class Initialized
INFO - 2023-11-09 18:30:32 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:32 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:32 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:32 --> URI Class Initialized
INFO - 2023-11-09 18:30:32 --> Router Class Initialized
INFO - 2023-11-09 18:30:32 --> Output Class Initialized
INFO - 2023-11-09 18:30:32 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:32 --> Input Class Initialized
INFO - 2023-11-09 18:30:32 --> Language Class Initialized
INFO - 2023-11-09 18:30:32 --> Loader Class Initialized
INFO - 2023-11-09 18:30:32 --> Helper loaded: url_helper
INFO - 2023-11-09 18:30:32 --> Helper loaded: file_helper
INFO - 2023-11-09 18:30:32 --> Database Driver Class Initialized
INFO - 2023-11-09 18:30:32 --> Email Class Initialized
DEBUG - 2023-11-09 18:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:30:32 --> Controller Class Initialized
INFO - 2023-11-09 18:30:32 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:30:32 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:30:32 --> Model "Home_model" initialized
INFO - 2023-11-09 18:30:32 --> Helper loaded: download_helper
INFO - 2023-11-09 18:30:32 --> Helper loaded: form_helper
INFO - 2023-11-09 18:30:32 --> Form Validation Class Initialized
INFO - 2023-11-09 23:00:32 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:00:32 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:00:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:00:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-09 23:00:32 --> Final output sent to browser
DEBUG - 2023-11-09 23:00:32 --> Total execution time: 0.2085
INFO - 2023-11-09 18:30:34 --> Config Class Initialized
INFO - 2023-11-09 18:30:34 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:34 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:34 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:34 --> URI Class Initialized
INFO - 2023-11-09 18:30:34 --> Router Class Initialized
INFO - 2023-11-09 18:30:34 --> Output Class Initialized
INFO - 2023-11-09 18:30:34 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:34 --> Input Class Initialized
INFO - 2023-11-09 18:30:34 --> Language Class Initialized
ERROR - 2023-11-09 18:30:34 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:30:34 --> Config Class Initialized
INFO - 2023-11-09 18:30:34 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:34 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:34 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:34 --> URI Class Initialized
INFO - 2023-11-09 18:30:34 --> Router Class Initialized
INFO - 2023-11-09 18:30:34 --> Output Class Initialized
INFO - 2023-11-09 18:30:34 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:34 --> Input Class Initialized
INFO - 2023-11-09 18:30:34 --> Language Class Initialized
ERROR - 2023-11-09 18:30:34 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:30:57 --> Config Class Initialized
INFO - 2023-11-09 18:30:57 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:57 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:57 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:57 --> URI Class Initialized
INFO - 2023-11-09 18:30:57 --> Router Class Initialized
INFO - 2023-11-09 18:30:57 --> Output Class Initialized
INFO - 2023-11-09 18:30:57 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:57 --> Input Class Initialized
INFO - 2023-11-09 18:30:57 --> Language Class Initialized
INFO - 2023-11-09 18:30:57 --> Loader Class Initialized
INFO - 2023-11-09 18:30:57 --> Helper loaded: url_helper
INFO - 2023-11-09 18:30:57 --> Helper loaded: file_helper
INFO - 2023-11-09 18:30:57 --> Database Driver Class Initialized
INFO - 2023-11-09 18:30:57 --> Email Class Initialized
DEBUG - 2023-11-09 18:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:30:57 --> Controller Class Initialized
INFO - 2023-11-09 18:30:57 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:30:57 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:30:57 --> Model "Home_model" initialized
INFO - 2023-11-09 18:30:57 --> Helper loaded: download_helper
INFO - 2023-11-09 18:30:57 --> Helper loaded: form_helper
INFO - 2023-11-09 18:30:57 --> Form Validation Class Initialized
INFO - 2023-11-09 23:00:57 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:00:57 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:00:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:00:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-11-09 23:00:57 --> Final output sent to browser
DEBUG - 2023-11-09 23:00:57 --> Total execution time: 0.0759
INFO - 2023-11-09 18:30:58 --> Config Class Initialized
INFO - 2023-11-09 18:30:58 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:58 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:58 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:58 --> URI Class Initialized
INFO - 2023-11-09 18:30:58 --> Router Class Initialized
INFO - 2023-11-09 18:30:58 --> Output Class Initialized
INFO - 2023-11-09 18:30:58 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:58 --> Config Class Initialized
INFO - 2023-11-09 18:30:58 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:30:58 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:30:58 --> Utf8 Class Initialized
INFO - 2023-11-09 18:30:58 --> URI Class Initialized
INFO - 2023-11-09 18:30:58 --> Router Class Initialized
INFO - 2023-11-09 18:30:58 --> Output Class Initialized
INFO - 2023-11-09 18:30:58 --> Security Class Initialized
DEBUG - 2023-11-09 18:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:30:58 --> Input Class Initialized
INFO - 2023-11-09 18:30:58 --> Language Class Initialized
ERROR - 2023-11-09 18:30:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:31:00 --> Input Class Initialized
INFO - 2023-11-09 18:31:00 --> Language Class Initialized
ERROR - 2023-11-09 18:31:00 --> 404 Page Not Found: Assets/home
INFO - 2023-11-09 18:31:07 --> Config Class Initialized
INFO - 2023-11-09 18:31:07 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:31:07 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:31:07 --> Utf8 Class Initialized
INFO - 2023-11-09 18:31:07 --> URI Class Initialized
INFO - 2023-11-09 18:31:07 --> Router Class Initialized
INFO - 2023-11-09 18:31:07 --> Output Class Initialized
INFO - 2023-11-09 18:31:07 --> Security Class Initialized
DEBUG - 2023-11-09 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:31:07 --> Input Class Initialized
INFO - 2023-11-09 18:31:07 --> Language Class Initialized
INFO - 2023-11-09 18:31:07 --> Loader Class Initialized
INFO - 2023-11-09 18:31:07 --> Helper loaded: url_helper
INFO - 2023-11-09 18:31:07 --> Helper loaded: file_helper
INFO - 2023-11-09 18:31:07 --> Database Driver Class Initialized
INFO - 2023-11-09 18:31:07 --> Email Class Initialized
DEBUG - 2023-11-09 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:31:07 --> Controller Class Initialized
INFO - 2023-11-09 18:31:07 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:31:07 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:31:07 --> Model "Home_model" initialized
INFO - 2023-11-09 18:31:07 --> Helper loaded: download_helper
INFO - 2023-11-09 18:31:07 --> Helper loaded: form_helper
INFO - 2023-11-09 18:31:07 --> Form Validation Class Initialized
INFO - 2023-11-09 23:01:07 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:01:07 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:01:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:01:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-11-09 23:01:07 --> Final output sent to browser
DEBUG - 2023-11-09 23:01:07 --> Total execution time: 0.0833
INFO - 2023-11-09 18:34:41 --> Config Class Initialized
INFO - 2023-11-09 18:34:41 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:34:41 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:34:41 --> Utf8 Class Initialized
INFO - 2023-11-09 18:34:41 --> URI Class Initialized
INFO - 2023-11-09 18:34:41 --> Router Class Initialized
INFO - 2023-11-09 18:34:41 --> Output Class Initialized
INFO - 2023-11-09 18:34:41 --> Security Class Initialized
DEBUG - 2023-11-09 18:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:34:41 --> Input Class Initialized
INFO - 2023-11-09 18:34:41 --> Language Class Initialized
INFO - 2023-11-09 18:34:41 --> Loader Class Initialized
INFO - 2023-11-09 18:34:41 --> Helper loaded: url_helper
INFO - 2023-11-09 18:34:41 --> Helper loaded: file_helper
INFO - 2023-11-09 18:34:41 --> Database Driver Class Initialized
INFO - 2023-11-09 18:34:41 --> Email Class Initialized
DEBUG - 2023-11-09 18:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:34:41 --> Controller Class Initialized
INFO - 2023-11-09 18:34:41 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:34:41 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:34:41 --> Model "Home_model" initialized
INFO - 2023-11-09 18:34:41 --> Helper loaded: download_helper
INFO - 2023-11-09 18:34:41 --> Helper loaded: form_helper
INFO - 2023-11-09 18:34:41 --> Form Validation Class Initialized
INFO - 2023-11-09 23:04:41 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:04:41 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:04:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:04:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-11-09 23:04:41 --> Final output sent to browser
DEBUG - 2023-11-09 23:04:41 --> Total execution time: 0.1380
INFO - 2023-11-09 18:34:54 --> Config Class Initialized
INFO - 2023-11-09 18:34:54 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:34:54 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:34:54 --> Utf8 Class Initialized
INFO - 2023-11-09 18:34:54 --> URI Class Initialized
INFO - 2023-11-09 18:34:54 --> Router Class Initialized
INFO - 2023-11-09 18:34:54 --> Output Class Initialized
INFO - 2023-11-09 18:34:54 --> Security Class Initialized
DEBUG - 2023-11-09 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:34:54 --> Input Class Initialized
INFO - 2023-11-09 18:34:54 --> Language Class Initialized
INFO - 2023-11-09 18:34:54 --> Loader Class Initialized
INFO - 2023-11-09 18:34:54 --> Helper loaded: url_helper
INFO - 2023-11-09 18:34:54 --> Helper loaded: file_helper
INFO - 2023-11-09 18:34:54 --> Database Driver Class Initialized
INFO - 2023-11-09 18:34:54 --> Email Class Initialized
DEBUG - 2023-11-09 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:34:54 --> Controller Class Initialized
INFO - 2023-11-09 18:34:54 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:34:54 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:34:54 --> Model "Home_model" initialized
INFO - 2023-11-09 18:34:54 --> Helper loaded: download_helper
INFO - 2023-11-09 18:34:54 --> Helper loaded: form_helper
INFO - 2023-11-09 18:34:54 --> Form Validation Class Initialized
INFO - 2023-11-09 23:04:54 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:04:54 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:04:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:04:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-11-09 23:04:54 --> Final output sent to browser
DEBUG - 2023-11-09 23:04:54 --> Total execution time: 0.1090
INFO - 2023-11-09 18:37:47 --> Config Class Initialized
INFO - 2023-11-09 18:37:47 --> Hooks Class Initialized
DEBUG - 2023-11-09 18:37:47 --> UTF-8 Support Enabled
INFO - 2023-11-09 18:37:47 --> Utf8 Class Initialized
INFO - 2023-11-09 18:37:47 --> URI Class Initialized
DEBUG - 2023-11-09 18:37:47 --> No URI present. Default controller set.
INFO - 2023-11-09 18:37:47 --> Router Class Initialized
INFO - 2023-11-09 18:37:47 --> Output Class Initialized
INFO - 2023-11-09 18:37:47 --> Security Class Initialized
DEBUG - 2023-11-09 18:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 18:37:47 --> Input Class Initialized
INFO - 2023-11-09 18:37:47 --> Language Class Initialized
INFO - 2023-11-09 18:37:47 --> Loader Class Initialized
INFO - 2023-11-09 18:37:47 --> Helper loaded: url_helper
INFO - 2023-11-09 18:37:47 --> Helper loaded: file_helper
INFO - 2023-11-09 18:37:47 --> Database Driver Class Initialized
INFO - 2023-11-09 18:37:47 --> Email Class Initialized
DEBUG - 2023-11-09 18:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 18:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 18:37:47 --> Controller Class Initialized
INFO - 2023-11-09 18:37:47 --> Model "Contact_model" initialized
INFO - 2023-11-09 18:37:47 --> Model "CareerFormModel" initialized
INFO - 2023-11-09 18:37:47 --> Model "Home_model" initialized
INFO - 2023-11-09 18:37:47 --> Helper loaded: download_helper
INFO - 2023-11-09 18:37:47 --> Helper loaded: form_helper
INFO - 2023-11-09 18:37:47 --> Form Validation Class Initialized
INFO - 2023-11-09 23:07:47 --> Helper loaded: custom_helper
INFO - 2023-11-09 23:07:47 --> Model "Social_media_model" initialized
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-09 23:07:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-09 23:07:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-09 23:07:47 --> Final output sent to browser
DEBUG - 2023-11-09 23:07:47 --> Total execution time: 0.0881
