<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-12 17:00:45 --> Config Class Initialized
INFO - 2023-10-12 17:00:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:00:50 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:00:50 --> Utf8 Class Initialized
INFO - 2023-10-12 17:00:52 --> URI Class Initialized
DEBUG - 2023-10-12 17:00:54 --> No URI present. Default controller set.
INFO - 2023-10-12 17:00:54 --> Router Class Initialized
INFO - 2023-10-12 17:00:55 --> Output Class Initialized
INFO - 2023-10-12 17:00:56 --> Security Class Initialized
DEBUG - 2023-10-12 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:00:56 --> Input Class Initialized
INFO - 2023-10-12 17:00:57 --> Language Class Initialized
INFO - 2023-10-12 17:00:58 --> Loader Class Initialized
INFO - 2023-10-12 17:00:59 --> Helper loaded: url_helper
INFO - 2023-10-12 17:01:01 --> Helper loaded: file_helper
INFO - 2023-10-12 17:01:07 --> Database Driver Class Initialized
INFO - 2023-10-12 17:01:16 --> Email Class Initialized
DEBUG - 2023-10-12 17:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:01:18 --> Controller Class Initialized
INFO - 2023-10-12 17:01:18 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:01:18 --> Model "Home_model" initialized
INFO - 2023-10-12 17:01:18 --> Helper loaded: download_helper
INFO - 2023-10-12 17:01:18 --> Helper loaded: form_helper
INFO - 2023-10-12 17:01:19 --> Form Validation Class Initialized
INFO - 2023-10-12 17:01:24 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:01:25 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:01:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:01:26 --> Final output sent to browser
DEBUG - 2023-10-12 17:01:26 --> Total execution time: 46.2145
INFO - 2023-10-12 17:03:17 --> Config Class Initialized
INFO - 2023-10-12 17:03:17 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:03:17 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:03:17 --> Utf8 Class Initialized
INFO - 2023-10-12 17:03:17 --> URI Class Initialized
INFO - 2023-10-12 17:03:17 --> Router Class Initialized
INFO - 2023-10-12 17:03:17 --> Output Class Initialized
INFO - 2023-10-12 17:03:17 --> Security Class Initialized
DEBUG - 2023-10-12 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:03:17 --> Input Class Initialized
INFO - 2023-10-12 17:03:17 --> Language Class Initialized
ERROR - 2023-10-12 17:03:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:03:17 --> Config Class Initialized
INFO - 2023-10-12 17:03:17 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:03:17 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:03:17 --> Utf8 Class Initialized
INFO - 2023-10-12 17:03:17 --> URI Class Initialized
INFO - 2023-10-12 17:03:17 --> Router Class Initialized
INFO - 2023-10-12 17:03:17 --> Output Class Initialized
INFO - 2023-10-12 17:03:17 --> Security Class Initialized
DEBUG - 2023-10-12 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:03:17 --> Input Class Initialized
INFO - 2023-10-12 17:03:17 --> Language Class Initialized
ERROR - 2023-10-12 17:03:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:03:21 --> Config Class Initialized
INFO - 2023-10-12 17:03:21 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:03:21 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:03:21 --> Utf8 Class Initialized
INFO - 2023-10-12 17:03:21 --> URI Class Initialized
INFO - 2023-10-12 17:03:21 --> Router Class Initialized
INFO - 2023-10-12 17:03:21 --> Output Class Initialized
INFO - 2023-10-12 17:03:21 --> Config Class Initialized
INFO - 2023-10-12 17:03:21 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:03:21 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:03:21 --> Utf8 Class Initialized
INFO - 2023-10-12 17:03:21 --> URI Class Initialized
INFO - 2023-10-12 17:03:21 --> Router Class Initialized
INFO - 2023-10-12 17:03:21 --> Output Class Initialized
INFO - 2023-10-12 17:03:21 --> Security Class Initialized
DEBUG - 2023-10-12 17:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:03:21 --> Input Class Initialized
INFO - 2023-10-12 17:03:21 --> Language Class Initialized
ERROR - 2023-10-12 17:03:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:03:21 --> Security Class Initialized
DEBUG - 2023-10-12 17:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:03:21 --> Input Class Initialized
INFO - 2023-10-12 17:03:21 --> Language Class Initialized
ERROR - 2023-10-12 17:03:21 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:04:30 --> Config Class Initialized
INFO - 2023-10-12 17:04:30 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:30 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:30 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:30 --> URI Class Initialized
DEBUG - 2023-10-12 17:04:30 --> No URI present. Default controller set.
INFO - 2023-10-12 17:04:30 --> Router Class Initialized
INFO - 2023-10-12 17:04:30 --> Output Class Initialized
INFO - 2023-10-12 17:04:30 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:30 --> Input Class Initialized
INFO - 2023-10-12 17:04:30 --> Language Class Initialized
INFO - 2023-10-12 17:04:30 --> Loader Class Initialized
INFO - 2023-10-12 17:04:30 --> Helper loaded: url_helper
INFO - 2023-10-12 17:04:30 --> Helper loaded: file_helper
INFO - 2023-10-12 17:04:30 --> Database Driver Class Initialized
INFO - 2023-10-12 17:04:30 --> Email Class Initialized
DEBUG - 2023-10-12 17:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:04:30 --> Controller Class Initialized
INFO - 2023-10-12 17:04:30 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:04:30 --> Model "Home_model" initialized
INFO - 2023-10-12 17:04:30 --> Helper loaded: download_helper
INFO - 2023-10-12 17:04:30 --> Helper loaded: form_helper
INFO - 2023-10-12 17:04:30 --> Form Validation Class Initialized
INFO - 2023-10-12 17:04:31 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:04:31 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:04:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:04:31 --> Final output sent to browser
DEBUG - 2023-10-12 17:04:31 --> Total execution time: 0.5104
INFO - 2023-10-12 17:04:36 --> Config Class Initialized
INFO - 2023-10-12 17:04:36 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:36 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:36 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:36 --> URI Class Initialized
INFO - 2023-10-12 17:04:36 --> Router Class Initialized
INFO - 2023-10-12 17:04:36 --> Output Class Initialized
INFO - 2023-10-12 17:04:36 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:36 --> Input Class Initialized
INFO - 2023-10-12 17:04:36 --> Language Class Initialized
ERROR - 2023-10-12 17:04:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:04:37 --> Config Class Initialized
INFO - 2023-10-12 17:04:37 --> Config Class Initialized
INFO - 2023-10-12 17:04:38 --> Hooks Class Initialized
INFO - 2023-10-12 17:04:38 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:38 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:39 --> Utf8 Class Initialized
DEBUG - 2023-10-12 17:04:39 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:39 --> URI Class Initialized
INFO - 2023-10-12 17:04:39 --> Router Class Initialized
INFO - 2023-10-12 17:04:39 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:40 --> Output Class Initialized
INFO - 2023-10-12 17:04:40 --> URI Class Initialized
INFO - 2023-10-12 17:04:45 --> Router Class Initialized
INFO - 2023-10-12 17:04:45 --> Output Class Initialized
INFO - 2023-10-12 17:04:45 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:45 --> Input Class Initialized
INFO - 2023-10-12 17:04:45 --> Language Class Initialized
ERROR - 2023-10-12 17:04:45 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:04:45 --> Config Class Initialized
INFO - 2023-10-12 17:04:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:45 --> Config Class Initialized
INFO - 2023-10-12 17:04:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:45 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:45 --> URI Class Initialized
INFO - 2023-10-12 17:04:45 --> Router Class Initialized
INFO - 2023-10-12 17:04:45 --> Output Class Initialized
INFO - 2023-10-12 17:04:45 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:45 --> Input Class Initialized
INFO - 2023-10-12 17:04:45 --> Language Class Initialized
ERROR - 2023-10-12 17:04:45 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:04:45 --> Config Class Initialized
INFO - 2023-10-12 17:04:45 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:04:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:04:45 --> Utf8 Class Initialized
INFO - 2023-10-12 17:04:45 --> URI Class Initialized
INFO - 2023-10-12 17:04:46 --> Router Class Initialized
INFO - 2023-10-12 17:04:46 --> Output Class Initialized
INFO - 2023-10-12 17:04:46 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:46 --> Input Class Initialized
INFO - 2023-10-12 17:04:46 --> Language Class Initialized
ERROR - 2023-10-12 17:04:46 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:04:46 --> URI Class Initialized
INFO - 2023-10-12 17:04:46 --> Router Class Initialized
INFO - 2023-10-12 17:04:46 --> Output Class Initialized
INFO - 2023-10-12 17:04:47 --> Security Class Initialized
DEBUG - 2023-10-12 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:04:47 --> Input Class Initialized
INFO - 2023-10-12 17:04:48 --> Language Class Initialized
ERROR - 2023-10-12 17:04:48 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:06:11 --> Config Class Initialized
INFO - 2023-10-12 17:06:11 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:06:11 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:06:11 --> Utf8 Class Initialized
INFO - 2023-10-12 17:06:11 --> URI Class Initialized
DEBUG - 2023-10-12 17:06:11 --> No URI present. Default controller set.
INFO - 2023-10-12 17:06:11 --> Router Class Initialized
INFO - 2023-10-12 17:06:11 --> Output Class Initialized
INFO - 2023-10-12 17:06:11 --> Security Class Initialized
DEBUG - 2023-10-12 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:06:11 --> Input Class Initialized
INFO - 2023-10-12 17:06:11 --> Language Class Initialized
INFO - 2023-10-12 17:06:11 --> Loader Class Initialized
INFO - 2023-10-12 17:06:11 --> Helper loaded: url_helper
INFO - 2023-10-12 17:06:11 --> Helper loaded: file_helper
INFO - 2023-10-12 17:06:11 --> Database Driver Class Initialized
INFO - 2023-10-12 17:06:11 --> Email Class Initialized
DEBUG - 2023-10-12 17:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:06:11 --> Controller Class Initialized
INFO - 2023-10-12 17:06:11 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:06:11 --> Model "Home_model" initialized
INFO - 2023-10-12 17:06:11 --> Helper loaded: download_helper
INFO - 2023-10-12 17:06:11 --> Helper loaded: form_helper
INFO - 2023-10-12 17:06:11 --> Form Validation Class Initialized
INFO - 2023-10-12 17:06:11 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:06:11 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:06:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:06:11 --> Final output sent to browser
DEBUG - 2023-10-12 17:06:12 --> Total execution time: 0.2643
INFO - 2023-10-12 17:06:13 --> Config Class Initialized
INFO - 2023-10-12 17:06:13 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:06:13 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:06:13 --> Utf8 Class Initialized
INFO - 2023-10-12 17:06:13 --> URI Class Initialized
INFO - 2023-10-12 17:06:13 --> Router Class Initialized
INFO - 2023-10-12 17:06:13 --> Output Class Initialized
INFO - 2023-10-12 17:06:13 --> Security Class Initialized
DEBUG - 2023-10-12 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:06:13 --> Input Class Initialized
INFO - 2023-10-12 17:06:13 --> Language Class Initialized
ERROR - 2023-10-12 17:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:06:13 --> Config Class Initialized
INFO - 2023-10-12 17:06:13 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:06:13 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:06:13 --> Utf8 Class Initialized
INFO - 2023-10-12 17:06:13 --> URI Class Initialized
INFO - 2023-10-12 17:06:13 --> Router Class Initialized
INFO - 2023-10-12 17:06:13 --> Output Class Initialized
INFO - 2023-10-12 17:06:13 --> Security Class Initialized
DEBUG - 2023-10-12 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:06:13 --> Input Class Initialized
INFO - 2023-10-12 17:06:13 --> Language Class Initialized
ERROR - 2023-10-12 17:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:06:14 --> Config Class Initialized
INFO - 2023-10-12 17:06:14 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:06:14 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:06:14 --> Utf8 Class Initialized
INFO - 2023-10-12 17:06:14 --> URI Class Initialized
INFO - 2023-10-12 17:06:14 --> Router Class Initialized
INFO - 2023-10-12 17:06:14 --> Output Class Initialized
INFO - 2023-10-12 17:14:20 --> Config Class Initialized
INFO - 2023-10-12 17:14:20 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:14:20 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:14:20 --> Utf8 Class Initialized
INFO - 2023-10-12 17:14:21 --> URI Class Initialized
DEBUG - 2023-10-12 17:14:21 --> No URI present. Default controller set.
INFO - 2023-10-12 17:14:21 --> Router Class Initialized
INFO - 2023-10-12 17:14:21 --> Output Class Initialized
INFO - 2023-10-12 17:14:21 --> Security Class Initialized
DEBUG - 2023-10-12 17:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:14:21 --> Input Class Initialized
INFO - 2023-10-12 17:14:21 --> Language Class Initialized
INFO - 2023-10-12 17:14:21 --> Loader Class Initialized
INFO - 2023-10-12 17:14:21 --> Helper loaded: url_helper
INFO - 2023-10-12 17:14:21 --> Helper loaded: file_helper
INFO - 2023-10-12 17:14:21 --> Database Driver Class Initialized
INFO - 2023-10-12 17:14:21 --> Email Class Initialized
DEBUG - 2023-10-12 17:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:14:21 --> Controller Class Initialized
INFO - 2023-10-12 17:14:22 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:14:22 --> Model "Home_model" initialized
INFO - 2023-10-12 17:14:22 --> Helper loaded: download_helper
INFO - 2023-10-12 17:14:22 --> Helper loaded: form_helper
INFO - 2023-10-12 17:14:22 --> Form Validation Class Initialized
INFO - 2023-10-12 17:14:23 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:14:23 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:14:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:14:23 --> Final output sent to browser
DEBUG - 2023-10-12 17:14:23 --> Total execution time: 3.3954
INFO - 2023-10-12 17:29:07 --> Config Class Initialized
INFO - 2023-10-12 17:29:07 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:29:07 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:29:07 --> Utf8 Class Initialized
INFO - 2023-10-12 17:29:07 --> URI Class Initialized
DEBUG - 2023-10-12 17:29:07 --> No URI present. Default controller set.
INFO - 2023-10-12 17:29:07 --> Router Class Initialized
INFO - 2023-10-12 17:29:07 --> Output Class Initialized
INFO - 2023-10-12 17:29:07 --> Security Class Initialized
DEBUG - 2023-10-12 17:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:29:07 --> Input Class Initialized
INFO - 2023-10-12 17:29:07 --> Language Class Initialized
INFO - 2023-10-12 17:29:07 --> Loader Class Initialized
INFO - 2023-10-12 17:29:07 --> Helper loaded: url_helper
INFO - 2023-10-12 17:29:07 --> Helper loaded: file_helper
INFO - 2023-10-12 17:29:07 --> Database Driver Class Initialized
INFO - 2023-10-12 17:29:07 --> Email Class Initialized
DEBUG - 2023-10-12 17:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:29:07 --> Controller Class Initialized
INFO - 2023-10-12 17:29:08 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:29:08 --> Model "Home_model" initialized
INFO - 2023-10-12 17:29:08 --> Helper loaded: download_helper
INFO - 2023-10-12 17:29:08 --> Helper loaded: form_helper
INFO - 2023-10-12 17:29:08 --> Form Validation Class Initialized
INFO - 2023-10-12 17:29:08 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:29:08 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:29:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:29:08 --> Final output sent to browser
DEBUG - 2023-10-12 17:29:08 --> Total execution time: 0.1629
INFO - 2023-10-12 17:29:12 --> Config Class Initialized
INFO - 2023-10-12 17:29:12 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:29:12 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:29:12 --> Utf8 Class Initialized
INFO - 2023-10-12 17:29:12 --> URI Class Initialized
INFO - 2023-10-12 17:29:12 --> Router Class Initialized
INFO - 2023-10-12 17:29:12 --> Output Class Initialized
INFO - 2023-10-12 17:29:12 --> Security Class Initialized
DEBUG - 2023-10-12 17:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:29:12 --> Input Class Initialized
INFO - 2023-10-12 17:29:12 --> Language Class Initialized
ERROR - 2023-10-12 17:29:12 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:29:12 --> Config Class Initialized
INFO - 2023-10-12 17:29:12 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:29:12 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:29:12 --> Utf8 Class Initialized
INFO - 2023-10-12 17:29:12 --> URI Class Initialized
INFO - 2023-10-12 17:29:14 --> Config Class Initialized
INFO - 2023-10-12 17:29:14 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:29:14 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:29:14 --> Utf8 Class Initialized
INFO - 2023-10-12 17:29:14 --> URI Class Initialized
INFO - 2023-10-12 17:29:14 --> Router Class Initialized
INFO - 2023-10-12 17:29:14 --> Output Class Initialized
INFO - 2023-10-12 17:29:14 --> Security Class Initialized
DEBUG - 2023-10-12 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:29:14 --> Input Class Initialized
INFO - 2023-10-12 17:29:14 --> Language Class Initialized
ERROR - 2023-10-12 17:29:14 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:29:14 --> Config Class Initialized
INFO - 2023-10-12 17:29:14 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:29:14 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:29:14 --> Utf8 Class Initialized
INFO - 2023-10-12 17:29:14 --> URI Class Initialized
INFO - 2023-10-12 17:29:14 --> Router Class Initialized
INFO - 2023-10-12 17:29:14 --> Output Class Initialized
INFO - 2023-10-12 17:29:14 --> Security Class Initialized
DEBUG - 2023-10-12 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:29:14 --> Input Class Initialized
INFO - 2023-10-12 17:29:14 --> Language Class Initialized
ERROR - 2023-10-12 17:29:14 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:29:14 --> Router Class Initialized
INFO - 2023-10-12 17:29:16 --> Output Class Initialized
INFO - 2023-10-12 17:33:52 --> Config Class Initialized
INFO - 2023-10-12 17:33:52 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:33:52 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:33:52 --> Utf8 Class Initialized
INFO - 2023-10-12 17:33:52 --> URI Class Initialized
DEBUG - 2023-10-12 17:33:52 --> No URI present. Default controller set.
INFO - 2023-10-12 17:33:52 --> Router Class Initialized
INFO - 2023-10-12 17:33:52 --> Output Class Initialized
INFO - 2023-10-12 17:33:52 --> Security Class Initialized
DEBUG - 2023-10-12 17:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:33:52 --> Input Class Initialized
INFO - 2023-10-12 17:33:52 --> Language Class Initialized
INFO - 2023-10-12 17:33:52 --> Loader Class Initialized
INFO - 2023-10-12 17:33:52 --> Helper loaded: url_helper
INFO - 2023-10-12 17:33:52 --> Helper loaded: file_helper
INFO - 2023-10-12 17:33:52 --> Database Driver Class Initialized
INFO - 2023-10-12 17:33:52 --> Email Class Initialized
DEBUG - 2023-10-12 17:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:33:52 --> Controller Class Initialized
INFO - 2023-10-12 17:33:53 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:33:53 --> Model "Home_model" initialized
INFO - 2023-10-12 17:33:53 --> Helper loaded: download_helper
INFO - 2023-10-12 17:33:53 --> Helper loaded: form_helper
INFO - 2023-10-12 17:33:53 --> Form Validation Class Initialized
INFO - 2023-10-12 17:33:53 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:33:53 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:33:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:33:53 --> Final output sent to browser
DEBUG - 2023-10-12 17:33:53 --> Total execution time: 1.4039
INFO - 2023-10-12 17:33:55 --> Config Class Initialized
INFO - 2023-10-12 17:33:55 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:33:55 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:33:55 --> Utf8 Class Initialized
INFO - 2023-10-12 17:33:55 --> URI Class Initialized
INFO - 2023-10-12 17:33:55 --> Router Class Initialized
INFO - 2023-10-12 17:33:55 --> Output Class Initialized
INFO - 2023-10-12 17:33:55 --> Security Class Initialized
DEBUG - 2023-10-12 17:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:33:55 --> Input Class Initialized
INFO - 2023-10-12 17:33:55 --> Language Class Initialized
ERROR - 2023-10-12 17:33:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:34:00 --> Config Class Initialized
INFO - 2023-10-12 17:34:00 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:34:00 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:34:00 --> Utf8 Class Initialized
INFO - 2023-10-12 17:34:00 --> URI Class Initialized
INFO - 2023-10-12 17:34:00 --> Router Class Initialized
INFO - 2023-10-12 17:34:00 --> Output Class Initialized
INFO - 2023-10-12 17:34:00 --> Security Class Initialized
DEBUG - 2023-10-12 17:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:35:09 --> Config Class Initialized
INFO - 2023-10-12 17:35:09 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:35:09 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:35:09 --> Utf8 Class Initialized
INFO - 2023-10-12 17:35:09 --> URI Class Initialized
DEBUG - 2023-10-12 17:35:09 --> No URI present. Default controller set.
INFO - 2023-10-12 17:35:09 --> Router Class Initialized
INFO - 2023-10-12 17:35:09 --> Output Class Initialized
INFO - 2023-10-12 17:35:09 --> Security Class Initialized
DEBUG - 2023-10-12 17:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:35:09 --> Input Class Initialized
INFO - 2023-10-12 17:35:09 --> Language Class Initialized
INFO - 2023-10-12 17:35:09 --> Loader Class Initialized
INFO - 2023-10-12 17:35:09 --> Helper loaded: url_helper
INFO - 2023-10-12 17:35:09 --> Helper loaded: file_helper
INFO - 2023-10-12 17:35:09 --> Database Driver Class Initialized
INFO - 2023-10-12 17:35:09 --> Email Class Initialized
DEBUG - 2023-10-12 17:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:35:09 --> Controller Class Initialized
INFO - 2023-10-12 17:35:09 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:35:09 --> Model "Home_model" initialized
INFO - 2023-10-12 17:35:09 --> Helper loaded: download_helper
INFO - 2023-10-12 17:35:09 --> Helper loaded: form_helper
INFO - 2023-10-12 17:35:09 --> Form Validation Class Initialized
INFO - 2023-10-12 17:35:09 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:35:09 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:35:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:35:09 --> Final output sent to browser
DEBUG - 2023-10-12 17:35:09 --> Total execution time: 0.1008
INFO - 2023-10-12 17:35:13 --> Config Class Initialized
INFO - 2023-10-12 17:35:13 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:35:17 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:37:39 --> Config Class Initialized
INFO - 2023-10-12 17:37:39 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:37:39 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:37:39 --> Utf8 Class Initialized
INFO - 2023-10-12 17:37:39 --> URI Class Initialized
DEBUG - 2023-10-12 17:37:39 --> No URI present. Default controller set.
INFO - 2023-10-12 17:37:39 --> Router Class Initialized
INFO - 2023-10-12 17:37:39 --> Output Class Initialized
INFO - 2023-10-12 17:37:39 --> Security Class Initialized
DEBUG - 2023-10-12 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:37:39 --> Input Class Initialized
INFO - 2023-10-12 17:37:39 --> Language Class Initialized
INFO - 2023-10-12 17:37:39 --> Loader Class Initialized
INFO - 2023-10-12 17:37:39 --> Helper loaded: url_helper
INFO - 2023-10-12 17:37:39 --> Helper loaded: file_helper
INFO - 2023-10-12 17:37:39 --> Database Driver Class Initialized
INFO - 2023-10-12 17:37:39 --> Email Class Initialized
DEBUG - 2023-10-12 17:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:37:39 --> Controller Class Initialized
INFO - 2023-10-12 17:37:39 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:37:39 --> Model "Home_model" initialized
INFO - 2023-10-12 17:37:39 --> Helper loaded: download_helper
INFO - 2023-10-12 17:37:39 --> Helper loaded: form_helper
INFO - 2023-10-12 17:37:39 --> Form Validation Class Initialized
INFO - 2023-10-12 17:37:39 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:37:39 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:37:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:37:39 --> Final output sent to browser
DEBUG - 2023-10-12 17:37:39 --> Total execution time: 0.1353
INFO - 2023-10-12 17:37:42 --> Config Class Initialized
INFO - 2023-10-12 17:37:42 --> Hooks Class Initialized
INFO - 2023-10-12 17:37:42 --> Config Class Initialized
INFO - 2023-10-12 17:37:42 --> Config Class Initialized
DEBUG - 2023-10-12 17:37:42 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:37:43 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:37:43 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:37:43 --> Hooks Class Initialized
INFO - 2023-10-12 17:37:43 --> Utf8 Class Initialized
DEBUG - 2023-10-12 17:37:46 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:37:47 --> Config Class Initialized
INFO - 2023-10-12 17:37:47 --> Utf8 Class Initialized
INFO - 2023-10-12 17:37:47 --> URI Class Initialized
INFO - 2023-10-12 17:37:47 --> URI Class Initialized
INFO - 2023-10-12 17:37:47 --> Hooks Class Initialized
INFO - 2023-10-12 17:37:47 --> Utf8 Class Initialized
INFO - 2023-10-12 17:37:47 --> Router Class Initialized
INFO - 2023-10-12 17:37:47 --> Config Class Initialized
INFO - 2023-10-12 17:37:47 --> Router Class Initialized
INFO - 2023-10-12 17:37:47 --> Output Class Initialized
INFO - 2023-10-12 17:37:47 --> Security Class Initialized
DEBUG - 2023-10-12 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:37:47 --> Input Class Initialized
INFO - 2023-10-12 17:37:47 --> Language Class Initialized
ERROR - 2023-10-12 17:37:47 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:58:44 --> Config Class Initialized
INFO - 2023-10-12 17:58:44 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:58:47 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:58:47 --> Utf8 Class Initialized
DEBUG - 2023-10-12 17:58:47 --> No URI present. Default controller set.
INFO - 2023-10-12 17:58:47 --> Router Class Initialized
INFO - 2023-10-12 17:58:48 --> Output Class Initialized
INFO - 2023-10-12 17:58:48 --> Security Class Initialized
DEBUG - 2023-10-12 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:58:48 --> Input Class Initialized
INFO - 2023-10-12 17:58:48 --> Language Class Initialized
INFO - 2023-10-12 17:58:49 --> Loader Class Initialized
INFO - 2023-10-12 17:58:49 --> Helper loaded: url_helper
INFO - 2023-10-12 17:58:49 --> Helper loaded: file_helper
INFO - 2023-10-12 17:58:50 --> Database Driver Class Initialized
INFO - 2023-10-12 17:58:50 --> Email Class Initialized
DEBUG - 2023-10-12 17:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 17:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:58:51 --> Controller Class Initialized
INFO - 2023-10-12 17:58:51 --> Model "Contact_model" initialized
INFO - 2023-10-12 17:58:51 --> Model "Home_model" initialized
INFO - 2023-10-12 17:58:51 --> Helper loaded: download_helper
INFO - 2023-10-12 17:58:52 --> Helper loaded: form_helper
INFO - 2023-10-12 17:58:52 --> Form Validation Class Initialized
INFO - 2023-10-12 17:58:52 --> Helper loaded: custom_helper
INFO - 2023-10-12 17:58:52 --> Model "Social_media_model" initialized
INFO - 2023-10-12 17:58:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 17:58:53 --> Final output sent to browser
DEBUG - 2023-10-12 17:58:53 --> Total execution time: 8.5042
INFO - 2023-10-12 17:59:07 --> Config Class Initialized
INFO - 2023-10-12 17:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:07 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:07 --> URI Class Initialized
INFO - 2023-10-12 17:59:07 --> Config Class Initialized
INFO - 2023-10-12 17:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:07 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:07 --> URI Class Initialized
INFO - 2023-10-12 17:59:07 --> Router Class Initialized
INFO - 2023-10-12 17:59:07 --> Output Class Initialized
INFO - 2023-10-12 17:59:07 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:07 --> Input Class Initialized
INFO - 2023-10-12 17:59:07 --> Language Class Initialized
ERROR - 2023-10-12 17:59:07 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:07 --> Router Class Initialized
INFO - 2023-10-12 17:59:07 --> Output Class Initialized
INFO - 2023-10-12 17:59:08 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:08 --> Config Class Initialized
INFO - 2023-10-12 17:59:08 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:08 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:08 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:08 --> URI Class Initialized
INFO - 2023-10-12 17:59:08 --> Router Class Initialized
INFO - 2023-10-12 17:59:08 --> Output Class Initialized
INFO - 2023-10-12 17:59:08 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:08 --> Input Class Initialized
INFO - 2023-10-12 17:59:08 --> Language Class Initialized
ERROR - 2023-10-12 17:59:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:08 --> Input Class Initialized
INFO - 2023-10-12 17:59:08 --> Language Class Initialized
ERROR - 2023-10-12 17:59:08 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:09 --> Config Class Initialized
INFO - 2023-10-12 17:59:09 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:09 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:09 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:09 --> URI Class Initialized
INFO - 2023-10-12 17:59:09 --> Router Class Initialized
INFO - 2023-10-12 17:59:09 --> Output Class Initialized
INFO - 2023-10-12 17:59:09 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:09 --> Input Class Initialized
INFO - 2023-10-12 17:59:09 --> Language Class Initialized
ERROR - 2023-10-12 17:59:09 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:09 --> Config Class Initialized
INFO - 2023-10-12 17:59:09 --> Hooks Class Initialized
INFO - 2023-10-12 17:59:09 --> Config Class Initialized
INFO - 2023-10-12 17:59:09 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:10 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:10 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:10 --> URI Class Initialized
INFO - 2023-10-12 17:59:10 --> Router Class Initialized
INFO - 2023-10-12 17:59:10 --> Config Class Initialized
INFO - 2023-10-12 17:59:10 --> Config Class Initialized
INFO - 2023-10-12 17:59:10 --> Hooks Class Initialized
INFO - 2023-10-12 17:59:10 --> Output Class Initialized
INFO - 2023-10-12 17:59:10 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:10 --> Input Class Initialized
INFO - 2023-10-12 17:59:10 --> Language Class Initialized
ERROR - 2023-10-12 17:59:10 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:10 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:10 --> UTF-8 Support Enabled
DEBUG - 2023-10-12 17:59:10 --> UTF-8 Support Enabled
DEBUG - 2023-10-12 17:59:10 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:10 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:10 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:10 --> URI Class Initialized
INFO - 2023-10-12 17:59:10 --> Utf8 Class Initialized
DEBUG - 2023-10-12 17:59:11 --> No URI present. Default controller set.
INFO - 2023-10-12 17:59:11 --> Router Class Initialized
INFO - 2023-10-12 17:59:11 --> URI Class Initialized
INFO - 2023-10-12 17:59:11 --> URI Class Initialized
INFO - 2023-10-12 17:59:11 --> Router Class Initialized
INFO - 2023-10-12 17:59:11 --> Router Class Initialized
INFO - 2023-10-12 17:59:11 --> Output Class Initialized
INFO - 2023-10-12 17:59:11 --> Output Class Initialized
INFO - 2023-10-12 17:59:11 --> Output Class Initialized
INFO - 2023-10-12 17:59:11 --> Security Class Initialized
INFO - 2023-10-12 17:59:11 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:11 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-12 17:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:11 --> Input Class Initialized
INFO - 2023-10-12 17:59:11 --> Input Class Initialized
INFO - 2023-10-12 17:59:12 --> Language Class Initialized
INFO - 2023-10-12 17:59:12 --> Input Class Initialized
INFO - 2023-10-12 17:59:12 --> Language Class Initialized
INFO - 2023-10-12 17:59:12 --> Language Class Initialized
ERROR - 2023-10-12 17:59:12 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-12 17:59:12 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:15 --> Config Class Initialized
INFO - 2023-10-12 17:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:15 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:15 --> URI Class Initialized
INFO - 2023-10-12 17:59:15 --> Router Class Initialized
INFO - 2023-10-12 17:59:15 --> Output Class Initialized
INFO - 2023-10-12 17:59:15 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:15 --> Input Class Initialized
INFO - 2023-10-12 17:59:15 --> Language Class Initialized
ERROR - 2023-10-12 17:59:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:15 --> Config Class Initialized
INFO - 2023-10-12 17:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:15 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:15 --> URI Class Initialized
INFO - 2023-10-12 17:59:15 --> Router Class Initialized
INFO - 2023-10-12 17:59:15 --> Output Class Initialized
INFO - 2023-10-12 17:59:15 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:15 --> Input Class Initialized
INFO - 2023-10-12 17:59:15 --> Language Class Initialized
ERROR - 2023-10-12 17:59:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:16 --> Config Class Initialized
INFO - 2023-10-12 17:59:16 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:16 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:16 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:16 --> URI Class Initialized
INFO - 2023-10-12 17:59:16 --> Router Class Initialized
INFO - 2023-10-12 17:59:16 --> Output Class Initialized
INFO - 2023-10-12 17:59:16 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:16 --> Config Class Initialized
INFO - 2023-10-12 17:59:16 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:16 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:16 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:16 --> URI Class Initialized
INFO - 2023-10-12 17:59:16 --> Router Class Initialized
INFO - 2023-10-12 17:59:16 --> Output Class Initialized
INFO - 2023-10-12 17:59:16 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:16 --> Input Class Initialized
INFO - 2023-10-12 17:59:16 --> Language Class Initialized
ERROR - 2023-10-12 17:59:16 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:18 --> Config Class Initialized
INFO - 2023-10-12 17:59:18 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:59:18 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:18 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:18 --> URI Class Initialized
INFO - 2023-10-12 17:59:18 --> Router Class Initialized
INFO - 2023-10-12 17:59:18 --> Output Class Initialized
INFO - 2023-10-12 17:59:18 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:18 --> Input Class Initialized
INFO - 2023-10-12 17:59:18 --> Language Class Initialized
INFO - 2023-10-12 17:59:20 --> Input Class Initialized
INFO - 2023-10-12 17:59:20 --> Config Class Initialized
INFO - 2023-10-12 17:59:20 --> Hooks Class Initialized
ERROR - 2023-10-12 17:59:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:20 --> Language Class Initialized
ERROR - 2023-10-12 17:59:20 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-12 17:59:20 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:20 --> Config Class Initialized
INFO - 2023-10-12 17:59:20 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:20 --> URI Class Initialized
INFO - 2023-10-12 17:59:20 --> Hooks Class Initialized
INFO - 2023-10-12 17:59:20 --> Router Class Initialized
DEBUG - 2023-10-12 17:59:20 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:59:20 --> Output Class Initialized
INFO - 2023-10-12 17:59:20 --> Utf8 Class Initialized
INFO - 2023-10-12 17:59:20 --> Security Class Initialized
INFO - 2023-10-12 17:59:20 --> URI Class Initialized
DEBUG - 2023-10-12 17:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:20 --> Router Class Initialized
INFO - 2023-10-12 17:59:20 --> Input Class Initialized
INFO - 2023-10-12 17:59:20 --> Output Class Initialized
INFO - 2023-10-12 17:59:20 --> Language Class Initialized
ERROR - 2023-10-12 17:59:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 17:59:20 --> Security Class Initialized
DEBUG - 2023-10-12 17:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:59:20 --> Input Class Initialized
INFO - 2023-10-12 17:59:20 --> Language Class Initialized
ERROR - 2023-10-12 17:59:20 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 18:02:00 --> Config Class Initialized
INFO - 2023-10-12 18:02:00 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:02:00 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:02:00 --> Utf8 Class Initialized
INFO - 2023-10-12 18:02:00 --> URI Class Initialized
DEBUG - 2023-10-12 18:02:00 --> No URI present. Default controller set.
INFO - 2023-10-12 18:02:00 --> Router Class Initialized
INFO - 2023-10-12 18:02:00 --> Output Class Initialized
INFO - 2023-10-12 18:02:00 --> Security Class Initialized
DEBUG - 2023-10-12 18:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:02:00 --> Input Class Initialized
INFO - 2023-10-12 18:02:00 --> Language Class Initialized
INFO - 2023-10-12 18:02:00 --> Loader Class Initialized
INFO - 2023-10-12 18:02:00 --> Helper loaded: url_helper
INFO - 2023-10-12 18:02:00 --> Helper loaded: file_helper
INFO - 2023-10-12 18:02:00 --> Database Driver Class Initialized
INFO - 2023-10-12 18:02:00 --> Email Class Initialized
DEBUG - 2023-10-12 18:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 18:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 18:02:00 --> Controller Class Initialized
INFO - 2023-10-12 18:02:00 --> Model "Contact_model" initialized
INFO - 2023-10-12 18:02:00 --> Model "Home_model" initialized
INFO - 2023-10-12 18:02:00 --> Helper loaded: download_helper
INFO - 2023-10-12 18:02:00 --> Helper loaded: form_helper
INFO - 2023-10-12 18:02:00 --> Form Validation Class Initialized
INFO - 2023-10-12 18:02:00 --> Helper loaded: custom_helper
INFO - 2023-10-12 18:02:00 --> Model "Social_media_model" initialized
INFO - 2023-10-12 18:02:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 18:02:00 --> Final output sent to browser
DEBUG - 2023-10-12 18:02:00 --> Total execution time: 0.1627
INFO - 2023-10-12 18:02:04 --> Config Class Initialized
INFO - 2023-10-12 18:02:04 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:02:04 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:02:04 --> Utf8 Class Initialized
INFO - 2023-10-12 18:02:04 --> URI Class Initialized
INFO - 2023-10-12 18:02:04 --> Router Class Initialized
INFO - 2023-10-12 18:02:05 --> Output Class Initialized
INFO - 2023-10-12 18:02:05 --> Security Class Initialized
DEBUG - 2023-10-12 18:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:02:05 --> Input Class Initialized
INFO - 2023-10-12 18:02:05 --> Language Class Initialized
ERROR - 2023-10-12 18:02:05 --> 404 Page Not Found: Assets/home
INFO - 2023-10-12 18:02:23 --> Config Class Initialized
INFO - 2023-10-12 18:02:23 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:02:23 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:02:23 --> Utf8 Class Initialized
INFO - 2023-10-12 18:02:23 --> URI Class Initialized
DEBUG - 2023-10-12 18:02:23 --> No URI present. Default controller set.
INFO - 2023-10-12 18:02:23 --> Router Class Initialized
INFO - 2023-10-12 18:02:23 --> Output Class Initialized
INFO - 2023-10-12 18:02:23 --> Security Class Initialized
DEBUG - 2023-10-12 18:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:02:23 --> Input Class Initialized
INFO - 2023-10-12 18:02:23 --> Language Class Initialized
INFO - 2023-10-12 18:02:23 --> Loader Class Initialized
INFO - 2023-10-12 18:02:23 --> Helper loaded: url_helper
INFO - 2023-10-12 18:02:23 --> Helper loaded: file_helper
INFO - 2023-10-12 18:02:23 --> Database Driver Class Initialized
INFO - 2023-10-12 18:02:23 --> Email Class Initialized
DEBUG - 2023-10-12 18:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 18:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 18:02:23 --> Controller Class Initialized
INFO - 2023-10-12 18:02:23 --> Model "Contact_model" initialized
INFO - 2023-10-12 18:02:23 --> Model "Home_model" initialized
INFO - 2023-10-12 18:02:23 --> Helper loaded: download_helper
INFO - 2023-10-12 18:02:23 --> Helper loaded: form_helper
INFO - 2023-10-12 18:02:23 --> Form Validation Class Initialized
INFO - 2023-10-12 18:02:23 --> Helper loaded: custom_helper
INFO - 2023-10-12 18:02:23 --> Model "Social_media_model" initialized
INFO - 2023-10-12 18:02:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 18:02:23 --> Final output sent to browser
DEBUG - 2023-10-12 18:02:23 --> Total execution time: 0.1319
INFO - 2023-10-12 18:02:49 --> Config Class Initialized
INFO - 2023-10-12 18:02:49 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:02:49 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:02:49 --> Utf8 Class Initialized
INFO - 2023-10-12 18:02:49 --> URI Class Initialized
DEBUG - 2023-10-12 18:02:49 --> No URI present. Default controller set.
INFO - 2023-10-12 18:02:49 --> Router Class Initialized
INFO - 2023-10-12 18:02:49 --> Output Class Initialized
INFO - 2023-10-12 18:02:49 --> Security Class Initialized
DEBUG - 2023-10-12 18:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:02:49 --> Input Class Initialized
INFO - 2023-10-12 18:02:49 --> Language Class Initialized
INFO - 2023-10-12 18:02:49 --> Loader Class Initialized
INFO - 2023-10-12 18:02:49 --> Helper loaded: url_helper
INFO - 2023-10-12 18:02:49 --> Helper loaded: file_helper
INFO - 2023-10-12 18:02:49 --> Database Driver Class Initialized
INFO - 2023-10-12 18:02:49 --> Email Class Initialized
DEBUG - 2023-10-12 18:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 18:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 18:02:49 --> Controller Class Initialized
INFO - 2023-10-12 18:02:49 --> Model "Contact_model" initialized
INFO - 2023-10-12 18:02:49 --> Model "Home_model" initialized
INFO - 2023-10-12 18:02:49 --> Helper loaded: download_helper
INFO - 2023-10-12 18:02:49 --> Helper loaded: form_helper
INFO - 2023-10-12 18:02:49 --> Form Validation Class Initialized
INFO - 2023-10-12 18:02:49 --> Helper loaded: custom_helper
INFO - 2023-10-12 18:02:49 --> Model "Social_media_model" initialized
INFO - 2023-10-12 18:02:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 18:02:49 --> Final output sent to browser
DEBUG - 2023-10-12 18:02:49 --> Total execution time: 0.1492
INFO - 2023-10-12 18:26:48 --> Config Class Initialized
INFO - 2023-10-12 18:26:48 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:26:49 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:26:49 --> Utf8 Class Initialized
INFO - 2023-10-12 18:26:49 --> URI Class Initialized
DEBUG - 2023-10-12 18:26:49 --> No URI present. Default controller set.
INFO - 2023-10-12 18:26:49 --> Router Class Initialized
INFO - 2023-10-12 18:26:49 --> Output Class Initialized
INFO - 2023-10-12 18:26:49 --> Security Class Initialized
DEBUG - 2023-10-12 18:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:26:49 --> Input Class Initialized
INFO - 2023-10-12 18:26:49 --> Language Class Initialized
INFO - 2023-10-12 18:26:49 --> Loader Class Initialized
INFO - 2023-10-12 18:26:49 --> Helper loaded: url_helper
INFO - 2023-10-12 18:26:49 --> Helper loaded: file_helper
INFO - 2023-10-12 18:26:49 --> Database Driver Class Initialized
INFO - 2023-10-12 18:26:49 --> Email Class Initialized
DEBUG - 2023-10-12 18:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-12 18:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 18:26:49 --> Controller Class Initialized
INFO - 2023-10-12 18:26:49 --> Model "Contact_model" initialized
INFO - 2023-10-12 18:26:49 --> Model "Home_model" initialized
INFO - 2023-10-12 18:26:49 --> Helper loaded: download_helper
INFO - 2023-10-12 18:26:49 --> Helper loaded: form_helper
INFO - 2023-10-12 18:26:49 --> Form Validation Class Initialized
INFO - 2023-10-12 18:26:49 --> Helper loaded: custom_helper
INFO - 2023-10-12 18:26:49 --> Model "Social_media_model" initialized
INFO - 2023-10-12 18:26:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-12 18:26:49 --> Final output sent to browser
DEBUG - 2023-10-12 18:26:49 --> Total execution time: 0.1904
INFO - 2023-10-12 18:26:50 --> Config Class Initialized
INFO - 2023-10-12 18:26:50 --> Hooks Class Initialized
DEBUG - 2023-10-12 18:26:50 --> UTF-8 Support Enabled
INFO - 2023-10-12 18:26:50 --> Utf8 Class Initialized
INFO - 2023-10-12 18:26:50 --> URI Class Initialized
INFO - 2023-10-12 18:26:50 --> Router Class Initialized
INFO - 2023-10-12 18:26:50 --> Output Class Initialized
INFO - 2023-10-12 18:26:50 --> Security Class Initialized
DEBUG - 2023-10-12 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 18:26:50 --> Input Class Initialized
INFO - 2023-10-12 18:26:50 --> Language Class Initialized
ERROR - 2023-10-12 18:26:50 --> 404 Page Not Found: Assets/home
