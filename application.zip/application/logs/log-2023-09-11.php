<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-11 17:43:23 --> Config Class Initialized
INFO - 2023-09-11 17:43:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:43:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:43:23 --> Utf8 Class Initialized
INFO - 2023-09-11 17:43:23 --> URI Class Initialized
DEBUG - 2023-09-11 17:43:23 --> No URI present. Default controller set.
INFO - 2023-09-11 17:43:23 --> Router Class Initialized
INFO - 2023-09-11 17:43:23 --> Output Class Initialized
INFO - 2023-09-11 17:43:23 --> Security Class Initialized
DEBUG - 2023-09-11 17:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:43:23 --> Input Class Initialized
INFO - 2023-09-11 17:43:23 --> Language Class Initialized
INFO - 2023-09-11 17:43:24 --> Loader Class Initialized
INFO - 2023-09-11 17:43:24 --> Helper loaded: url_helper
INFO - 2023-09-11 17:43:24 --> Helper loaded: file_helper
INFO - 2023-09-11 17:43:24 --> Database Driver Class Initialized
INFO - 2023-09-11 17:43:24 --> Email Class Initialized
DEBUG - 2023-09-11 17:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 17:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 17:43:24 --> Controller Class Initialized
INFO - 2023-09-11 17:43:24 --> Model "Contact_model" initialized
INFO - 2023-09-11 17:43:24 --> Model "Home_model" initialized
INFO - 2023-09-11 17:43:24 --> Helper loaded: download_helper
INFO - 2023-09-11 17:43:24 --> Helper loaded: form_helper
INFO - 2023-09-11 17:43:24 --> Form Validation Class Initialized
INFO - 2023-09-11 17:43:24 --> Helper loaded: custom_helper
INFO - 2023-09-11 17:43:24 --> Model "Social_media_model" initialized
INFO - 2023-09-11 17:43:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 17:43:24 --> Final output sent to browser
DEBUG - 2023-09-11 17:43:24 --> Total execution time: 1.5060
INFO - 2023-09-11 17:45:25 --> Config Class Initialized
INFO - 2023-09-11 17:45:25 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:45:25 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:45:25 --> Utf8 Class Initialized
INFO - 2023-09-11 17:45:25 --> URI Class Initialized
INFO - 2023-09-11 17:45:25 --> Router Class Initialized
INFO - 2023-09-11 17:45:25 --> Output Class Initialized
INFO - 2023-09-11 17:45:25 --> Security Class Initialized
DEBUG - 2023-09-11 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:45:25 --> Input Class Initialized
INFO - 2023-09-11 17:45:25 --> Language Class Initialized
INFO - 2023-09-11 17:45:25 --> Loader Class Initialized
INFO - 2023-09-11 17:45:25 --> Helper loaded: url_helper
INFO - 2023-09-11 17:45:25 --> Helper loaded: file_helper
INFO - 2023-09-11 17:45:25 --> Database Driver Class Initialized
INFO - 2023-09-11 17:45:25 --> Email Class Initialized
DEBUG - 2023-09-11 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 17:45:25 --> Controller Class Initialized
INFO - 2023-09-11 17:45:25 --> Model "Contact_model" initialized
INFO - 2023-09-11 17:45:25 --> Model "Home_model" initialized
INFO - 2023-09-11 17:45:25 --> Helper loaded: download_helper
INFO - 2023-09-11 17:45:25 --> Helper loaded: form_helper
INFO - 2023-09-11 17:45:25 --> Form Validation Class Initialized
INFO - 2023-09-11 17:45:25 --> Helper loaded: custom_helper
INFO - 2023-09-11 17:45:25 --> Model "Social_media_model" initialized
INFO - 2023-09-11 17:45:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 17:45:25 --> Final output sent to browser
DEBUG - 2023-09-11 17:45:25 --> Total execution time: 0.0945
INFO - 2023-09-11 17:47:51 --> Config Class Initialized
INFO - 2023-09-11 17:47:51 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:51 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:51 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:51 --> URI Class Initialized
INFO - 2023-09-11 17:47:51 --> Router Class Initialized
INFO - 2023-09-11 17:47:51 --> Output Class Initialized
INFO - 2023-09-11 17:47:51 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:51 --> Input Class Initialized
INFO - 2023-09-11 17:47:51 --> Language Class Initialized
ERROR - 2023-09-11 17:47:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:52 --> Config Class Initialized
INFO - 2023-09-11 17:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:52 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:52 --> URI Class Initialized
INFO - 2023-09-11 17:47:52 --> Router Class Initialized
INFO - 2023-09-11 17:47:52 --> Output Class Initialized
INFO - 2023-09-11 17:47:52 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:52 --> Input Class Initialized
INFO - 2023-09-11 17:47:52 --> Language Class Initialized
ERROR - 2023-09-11 17:47:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 17:47:57 --> Config Class Initialized
INFO - 2023-09-11 17:47:57 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:47:57 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:47:57 --> Utf8 Class Initialized
INFO - 2023-09-11 17:47:57 --> URI Class Initialized
INFO - 2023-09-11 17:47:57 --> Router Class Initialized
INFO - 2023-09-11 17:47:57 --> Output Class Initialized
INFO - 2023-09-11 17:47:57 --> Security Class Initialized
DEBUG - 2023-09-11 17:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:47:57 --> Input Class Initialized
INFO - 2023-09-11 17:47:57 --> Language Class Initialized
INFO - 2023-09-11 17:47:57 --> Loader Class Initialized
INFO - 2023-09-11 17:47:57 --> Helper loaded: url_helper
INFO - 2023-09-11 17:47:57 --> Helper loaded: file_helper
INFO - 2023-09-11 17:47:57 --> Database Driver Class Initialized
INFO - 2023-09-11 17:47:57 --> Email Class Initialized
DEBUG - 2023-09-11 17:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 17:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 17:47:57 --> Controller Class Initialized
INFO - 2023-09-11 17:47:57 --> Model "Contact_model" initialized
INFO - 2023-09-11 17:47:57 --> Model "Home_model" initialized
INFO - 2023-09-11 17:47:57 --> Helper loaded: download_helper
INFO - 2023-09-11 17:47:57 --> Helper loaded: form_helper
INFO - 2023-09-11 17:47:57 --> Form Validation Class Initialized
INFO - 2023-09-11 17:54:16 --> Config Class Initialized
INFO - 2023-09-11 17:54:16 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:54:16 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:54:17 --> Utf8 Class Initialized
INFO - 2023-09-11 17:54:17 --> URI Class Initialized
INFO - 2023-09-11 17:54:17 --> Router Class Initialized
INFO - 2023-09-11 17:54:18 --> Output Class Initialized
INFO - 2023-09-11 17:54:18 --> Security Class Initialized
DEBUG - 2023-09-11 17:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:54:18 --> Input Class Initialized
INFO - 2023-09-11 17:54:18 --> Language Class Initialized
INFO - 2023-09-11 17:54:18 --> Loader Class Initialized
INFO - 2023-09-11 17:54:18 --> Helper loaded: url_helper
INFO - 2023-09-11 17:54:18 --> Helper loaded: file_helper
INFO - 2023-09-11 17:54:18 --> Database Driver Class Initialized
INFO - 2023-09-11 17:54:19 --> Email Class Initialized
DEBUG - 2023-09-11 17:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 17:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 17:54:19 --> Controller Class Initialized
INFO - 2023-09-11 17:54:19 --> Model "Contact_model" initialized
INFO - 2023-09-11 17:54:19 --> Model "Home_model" initialized
INFO - 2023-09-11 17:54:19 --> Helper loaded: download_helper
INFO - 2023-09-11 17:54:19 --> Helper loaded: form_helper
INFO - 2023-09-11 17:54:19 --> Form Validation Class Initialized
INFO - 2023-09-11 17:54:19 --> Helper loaded: custom_helper
INFO - 2023-09-11 17:54:20 --> Model "Social_media_model" initialized
INFO - 2023-09-11 17:54:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 17:54:20 --> Final output sent to browser
DEBUG - 2023-09-11 17:54:20 --> Total execution time: 3.8418
INFO - 2023-09-11 17:55:59 --> Config Class Initialized
INFO - 2023-09-11 17:55:59 --> Hooks Class Initialized
DEBUG - 2023-09-11 17:55:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 17:55:59 --> Utf8 Class Initialized
INFO - 2023-09-11 17:55:59 --> URI Class Initialized
INFO - 2023-09-11 17:55:59 --> Router Class Initialized
INFO - 2023-09-11 17:55:59 --> Output Class Initialized
INFO - 2023-09-11 17:55:59 --> Security Class Initialized
DEBUG - 2023-09-11 17:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 17:55:59 --> Input Class Initialized
INFO - 2023-09-11 17:55:59 --> Language Class Initialized
INFO - 2023-09-11 17:55:59 --> Loader Class Initialized
INFO - 2023-09-11 17:55:59 --> Helper loaded: url_helper
INFO - 2023-09-11 17:55:59 --> Helper loaded: file_helper
INFO - 2023-09-11 17:55:59 --> Database Driver Class Initialized
INFO - 2023-09-11 17:55:59 --> Email Class Initialized
DEBUG - 2023-09-11 17:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 17:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 17:56:00 --> Controller Class Initialized
INFO - 2023-09-11 17:56:00 --> Model "Contact_model" initialized
INFO - 2023-09-11 17:56:00 --> Model "Home_model" initialized
INFO - 2023-09-11 17:56:00 --> Helper loaded: download_helper
INFO - 2023-09-11 17:56:00 --> Helper loaded: form_helper
INFO - 2023-09-11 17:56:00 --> Form Validation Class Initialized
INFO - 2023-09-11 17:56:00 --> Helper loaded: custom_helper
INFO - 2023-09-11 17:56:00 --> Model "Social_media_model" initialized
INFO - 2023-09-11 17:56:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 17:56:00 --> Final output sent to browser
DEBUG - 2023-09-11 17:56:00 --> Total execution time: 0.9404
INFO - 2023-09-11 18:21:30 --> Config Class Initialized
INFO - 2023-09-11 18:21:30 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:21:30 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:21:30 --> Utf8 Class Initialized
INFO - 2023-09-11 18:21:30 --> URI Class Initialized
INFO - 2023-09-11 18:21:30 --> Router Class Initialized
INFO - 2023-09-11 18:21:30 --> Output Class Initialized
INFO - 2023-09-11 18:21:30 --> Security Class Initialized
DEBUG - 2023-09-11 18:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:21:30 --> Input Class Initialized
INFO - 2023-09-11 18:21:30 --> Language Class Initialized
INFO - 2023-09-11 18:21:30 --> Loader Class Initialized
INFO - 2023-09-11 18:21:30 --> Helper loaded: url_helper
INFO - 2023-09-11 18:21:30 --> Helper loaded: file_helper
INFO - 2023-09-11 18:21:30 --> Database Driver Class Initialized
INFO - 2023-09-11 18:21:30 --> Email Class Initialized
DEBUG - 2023-09-11 18:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:21:30 --> Controller Class Initialized
INFO - 2023-09-11 18:21:30 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:21:30 --> Model "Home_model" initialized
INFO - 2023-09-11 18:21:30 --> Helper loaded: download_helper
INFO - 2023-09-11 18:21:30 --> Helper loaded: form_helper
INFO - 2023-09-11 18:21:30 --> Form Validation Class Initialized
INFO - 2023-09-11 18:21:30 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:21:30 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:21:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 18:21:30 --> Final output sent to browser
DEBUG - 2023-09-11 18:21:31 --> Total execution time: 0.8117
INFO - 2023-09-11 18:24:24 --> Config Class Initialized
INFO - 2023-09-11 18:24:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:24:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:24:24 --> Utf8 Class Initialized
INFO - 2023-09-11 18:24:24 --> URI Class Initialized
INFO - 2023-09-11 18:24:24 --> Router Class Initialized
INFO - 2023-09-11 18:24:24 --> Output Class Initialized
INFO - 2023-09-11 18:24:24 --> Security Class Initialized
DEBUG - 2023-09-11 18:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:24:24 --> Input Class Initialized
INFO - 2023-09-11 18:24:24 --> Language Class Initialized
INFO - 2023-09-11 18:24:24 --> Loader Class Initialized
INFO - 2023-09-11 18:24:24 --> Helper loaded: url_helper
INFO - 2023-09-11 18:24:24 --> Helper loaded: file_helper
INFO - 2023-09-11 18:24:24 --> Database Driver Class Initialized
INFO - 2023-09-11 18:24:24 --> Email Class Initialized
DEBUG - 2023-09-11 18:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:24:24 --> Controller Class Initialized
INFO - 2023-09-11 18:24:24 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:24:24 --> Model "Home_model" initialized
INFO - 2023-09-11 18:24:24 --> Helper loaded: download_helper
INFO - 2023-09-11 18:24:24 --> Helper loaded: form_helper
INFO - 2023-09-11 18:24:24 --> Form Validation Class Initialized
INFO - 2023-09-11 18:24:24 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:24:24 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:24:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 18:24:24 --> Final output sent to browser
DEBUG - 2023-09-11 18:24:24 --> Total execution time: 0.4464
INFO - 2023-09-11 18:24:57 --> Config Class Initialized
INFO - 2023-09-11 18:24:57 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:24:57 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:24:57 --> Utf8 Class Initialized
INFO - 2023-09-11 18:24:57 --> URI Class Initialized
INFO - 2023-09-11 18:24:57 --> Router Class Initialized
INFO - 2023-09-11 18:24:57 --> Output Class Initialized
INFO - 2023-09-11 18:24:58 --> Security Class Initialized
DEBUG - 2023-09-11 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:24:58 --> Input Class Initialized
INFO - 2023-09-11 18:24:58 --> Language Class Initialized
INFO - 2023-09-11 18:24:58 --> Loader Class Initialized
INFO - 2023-09-11 18:24:58 --> Helper loaded: url_helper
INFO - 2023-09-11 18:24:58 --> Helper loaded: file_helper
INFO - 2023-09-11 18:24:58 --> Database Driver Class Initialized
INFO - 2023-09-11 18:24:58 --> Email Class Initialized
DEBUG - 2023-09-11 18:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:24:58 --> Controller Class Initialized
INFO - 2023-09-11 18:24:58 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:24:58 --> Model "Home_model" initialized
INFO - 2023-09-11 18:24:58 --> Helper loaded: download_helper
INFO - 2023-09-11 18:24:58 --> Helper loaded: form_helper
INFO - 2023-09-11 18:24:58 --> Form Validation Class Initialized
INFO - 2023-09-11 18:27:12 --> Config Class Initialized
INFO - 2023-09-11 18:27:12 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:27:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:27:12 --> Utf8 Class Initialized
INFO - 2023-09-11 18:27:12 --> URI Class Initialized
INFO - 2023-09-11 18:27:12 --> Router Class Initialized
INFO - 2023-09-11 18:27:12 --> Output Class Initialized
INFO - 2023-09-11 18:27:12 --> Security Class Initialized
DEBUG - 2023-09-11 18:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:27:12 --> Input Class Initialized
INFO - 2023-09-11 18:27:13 --> Language Class Initialized
INFO - 2023-09-11 18:27:13 --> Loader Class Initialized
INFO - 2023-09-11 18:27:13 --> Helper loaded: url_helper
INFO - 2023-09-11 18:27:13 --> Helper loaded: file_helper
INFO - 2023-09-11 18:27:13 --> Database Driver Class Initialized
INFO - 2023-09-11 18:27:13 --> Email Class Initialized
DEBUG - 2023-09-11 18:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:27:13 --> Controller Class Initialized
INFO - 2023-09-11 18:27:13 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:27:13 --> Model "Home_model" initialized
INFO - 2023-09-11 18:27:13 --> Helper loaded: download_helper
INFO - 2023-09-11 18:27:13 --> Helper loaded: form_helper
INFO - 2023-09-11 18:27:13 --> Form Validation Class Initialized
INFO - 2023-09-11 18:27:13 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:27:13 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:27:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-11 18:27:13 --> Final output sent to browser
DEBUG - 2023-09-11 18:27:13 --> Total execution time: 0.2953
INFO - 2023-09-11 18:27:35 --> Config Class Initialized
INFO - 2023-09-11 18:27:35 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:27:35 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:27:35 --> Utf8 Class Initialized
INFO - 2023-09-11 18:27:35 --> URI Class Initialized
INFO - 2023-09-11 18:27:35 --> Router Class Initialized
INFO - 2023-09-11 18:27:35 --> Output Class Initialized
INFO - 2023-09-11 18:27:35 --> Security Class Initialized
DEBUG - 2023-09-11 18:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:27:35 --> Input Class Initialized
INFO - 2023-09-11 18:27:35 --> Language Class Initialized
INFO - 2023-09-11 18:27:35 --> Loader Class Initialized
INFO - 2023-09-11 18:27:35 --> Helper loaded: url_helper
INFO - 2023-09-11 18:27:35 --> Helper loaded: file_helper
INFO - 2023-09-11 18:27:35 --> Database Driver Class Initialized
INFO - 2023-09-11 18:27:35 --> Email Class Initialized
DEBUG - 2023-09-11 18:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:27:35 --> Controller Class Initialized
INFO - 2023-09-11 18:27:35 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:27:35 --> Model "Home_model" initialized
INFO - 2023-09-11 18:27:35 --> Helper loaded: download_helper
INFO - 2023-09-11 18:27:35 --> Helper loaded: form_helper
INFO - 2023-09-11 18:27:35 --> Form Validation Class Initialized
INFO - 2023-09-11 18:27:45 --> Config Class Initialized
INFO - 2023-09-11 18:27:45 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:27:45 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:27:45 --> Utf8 Class Initialized
INFO - 2023-09-11 18:27:45 --> URI Class Initialized
DEBUG - 2023-09-11 18:27:45 --> No URI present. Default controller set.
INFO - 2023-09-11 18:27:45 --> Router Class Initialized
INFO - 2023-09-11 18:27:45 --> Output Class Initialized
INFO - 2023-09-11 18:27:45 --> Security Class Initialized
DEBUG - 2023-09-11 18:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:27:45 --> Input Class Initialized
INFO - 2023-09-11 18:27:45 --> Language Class Initialized
INFO - 2023-09-11 18:27:45 --> Loader Class Initialized
INFO - 2023-09-11 18:27:45 --> Helper loaded: url_helper
INFO - 2023-09-11 18:27:45 --> Helper loaded: file_helper
INFO - 2023-09-11 18:27:45 --> Database Driver Class Initialized
INFO - 2023-09-11 18:27:45 --> Email Class Initialized
DEBUG - 2023-09-11 18:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:27:45 --> Controller Class Initialized
INFO - 2023-09-11 18:27:45 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:27:45 --> Model "Home_model" initialized
INFO - 2023-09-11 18:27:45 --> Helper loaded: download_helper
INFO - 2023-09-11 18:27:45 --> Helper loaded: form_helper
INFO - 2023-09-11 18:27:45 --> Form Validation Class Initialized
INFO - 2023-09-11 18:27:45 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:27:45 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:27:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 18:27:45 --> Final output sent to browser
DEBUG - 2023-09-11 18:27:45 --> Total execution time: 0.4682
INFO - 2023-09-11 18:28:13 --> Config Class Initialized
INFO - 2023-09-11 18:28:13 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:28:13 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:28:13 --> Utf8 Class Initialized
INFO - 2023-09-11 18:28:13 --> URI Class Initialized
INFO - 2023-09-11 18:28:13 --> Router Class Initialized
INFO - 2023-09-11 18:28:13 --> Output Class Initialized
INFO - 2023-09-11 18:28:13 --> Security Class Initialized
DEBUG - 2023-09-11 18:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:28:13 --> Input Class Initialized
INFO - 2023-09-11 18:28:13 --> Language Class Initialized
INFO - 2023-09-11 18:28:13 --> Loader Class Initialized
INFO - 2023-09-11 18:28:13 --> Helper loaded: url_helper
INFO - 2023-09-11 18:28:14 --> Helper loaded: file_helper
INFO - 2023-09-11 18:28:14 --> Database Driver Class Initialized
INFO - 2023-09-11 18:28:14 --> Email Class Initialized
DEBUG - 2023-09-11 18:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:28:14 --> Controller Class Initialized
INFO - 2023-09-11 18:28:14 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:28:14 --> Model "Home_model" initialized
INFO - 2023-09-11 18:28:14 --> Helper loaded: download_helper
INFO - 2023-09-11 18:28:14 --> Helper loaded: form_helper
INFO - 2023-09-11 18:28:14 --> Form Validation Class Initialized
INFO - 2023-09-11 18:29:23 --> Config Class Initialized
INFO - 2023-09-11 18:29:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:23 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:23 --> URI Class Initialized
DEBUG - 2023-09-11 18:29:23 --> No URI present. Default controller set.
INFO - 2023-09-11 18:29:23 --> Router Class Initialized
INFO - 2023-09-11 18:29:23 --> Output Class Initialized
INFO - 2023-09-11 18:29:23 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:23 --> Input Class Initialized
INFO - 2023-09-11 18:29:23 --> Language Class Initialized
INFO - 2023-09-11 18:29:23 --> Loader Class Initialized
INFO - 2023-09-11 18:29:23 --> Helper loaded: url_helper
INFO - 2023-09-11 18:29:23 --> Helper loaded: file_helper
INFO - 2023-09-11 18:29:23 --> Database Driver Class Initialized
INFO - 2023-09-11 18:29:23 --> Email Class Initialized
DEBUG - 2023-09-11 18:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:29:23 --> Controller Class Initialized
INFO - 2023-09-11 18:29:23 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:29:23 --> Model "Home_model" initialized
INFO - 2023-09-11 18:29:23 --> Helper loaded: download_helper
INFO - 2023-09-11 18:29:23 --> Helper loaded: form_helper
INFO - 2023-09-11 18:29:23 --> Form Validation Class Initialized
INFO - 2023-09-11 18:29:24 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:29:24 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:29:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 18:29:24 --> Final output sent to browser
DEBUG - 2023-09-11 18:29:24 --> Total execution time: 0.8183
INFO - 2023-09-11 18:29:40 --> Config Class Initialized
INFO - 2023-09-11 18:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:40 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:40 --> URI Class Initialized
INFO - 2023-09-11 18:29:40 --> Router Class Initialized
INFO - 2023-09-11 18:29:40 --> Output Class Initialized
INFO - 2023-09-11 18:29:40 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:40 --> Input Class Initialized
INFO - 2023-09-11 18:29:40 --> Language Class Initialized
INFO - 2023-09-11 18:29:40 --> Loader Class Initialized
INFO - 2023-09-11 18:29:40 --> Helper loaded: url_helper
INFO - 2023-09-11 18:29:40 --> Helper loaded: file_helper
INFO - 2023-09-11 18:29:40 --> Database Driver Class Initialized
INFO - 2023-09-11 18:29:40 --> Email Class Initialized
DEBUG - 2023-09-11 18:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:29:40 --> Controller Class Initialized
INFO - 2023-09-11 18:29:40 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:29:40 --> Model "Home_model" initialized
INFO - 2023-09-11 18:29:40 --> Helper loaded: download_helper
INFO - 2023-09-11 18:29:40 --> Helper loaded: form_helper
INFO - 2023-09-11 18:29:40 --> Form Validation Class Initialized
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
INFO - 2023-09-11 18:29:49 --> Config Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
INFO - 2023-09-11 18:29:49 --> Hooks Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-11 18:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:49 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:49 --> URI Class Initialized
INFO - 2023-09-11 18:29:49 --> Router Class Initialized
INFO - 2023-09-11 18:29:49 --> Output Class Initialized
INFO - 2023-09-11 18:29:49 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:49 --> Input Class Initialized
INFO - 2023-09-11 18:29:49 --> Language Class Initialized
ERROR - 2023-09-11 18:29:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:29:53 --> Config Class Initialized
INFO - 2023-09-11 18:29:53 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:29:53 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:29:53 --> Utf8 Class Initialized
INFO - 2023-09-11 18:29:53 --> URI Class Initialized
INFO - 2023-09-11 18:29:53 --> Router Class Initialized
INFO - 2023-09-11 18:29:53 --> Output Class Initialized
INFO - 2023-09-11 18:29:53 --> Security Class Initialized
DEBUG - 2023-09-11 18:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:29:53 --> Input Class Initialized
INFO - 2023-09-11 18:29:53 --> Language Class Initialized
INFO - 2023-09-11 18:29:53 --> Loader Class Initialized
INFO - 2023-09-11 18:29:53 --> Helper loaded: url_helper
INFO - 2023-09-11 18:29:53 --> Helper loaded: file_helper
INFO - 2023-09-11 18:29:53 --> Database Driver Class Initialized
INFO - 2023-09-11 18:29:53 --> Email Class Initialized
DEBUG - 2023-09-11 18:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:29:53 --> Controller Class Initialized
INFO - 2023-09-11 18:29:53 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:29:53 --> Model "Home_model" initialized
INFO - 2023-09-11 18:29:53 --> Helper loaded: download_helper
INFO - 2023-09-11 18:29:53 --> Helper loaded: form_helper
INFO - 2023-09-11 18:29:53 --> Form Validation Class Initialized
INFO - 2023-09-11 18:30:11 --> Config Class Initialized
INFO - 2023-09-11 18:30:11 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:12 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:12 --> URI Class Initialized
INFO - 2023-09-11 18:30:12 --> Router Class Initialized
INFO - 2023-09-11 18:30:12 --> Output Class Initialized
INFO - 2023-09-11 18:30:12 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:12 --> Input Class Initialized
INFO - 2023-09-11 18:30:12 --> Language Class Initialized
INFO - 2023-09-11 18:30:12 --> Loader Class Initialized
INFO - 2023-09-11 18:30:12 --> Helper loaded: url_helper
INFO - 2023-09-11 18:30:12 --> Helper loaded: file_helper
INFO - 2023-09-11 18:30:12 --> Database Driver Class Initialized
INFO - 2023-09-11 18:30:12 --> Email Class Initialized
DEBUG - 2023-09-11 18:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:30:12 --> Controller Class Initialized
INFO - 2023-09-11 18:30:12 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:30:12 --> Model "Home_model" initialized
INFO - 2023-09-11 18:30:12 --> Helper loaded: download_helper
INFO - 2023-09-11 18:30:12 --> Helper loaded: form_helper
INFO - 2023-09-11 18:30:12 --> Form Validation Class Initialized
INFO - 2023-09-11 18:30:45 --> Config Class Initialized
INFO - 2023-09-11 18:30:45 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:45 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:45 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:45 --> URI Class Initialized
DEBUG - 2023-09-11 18:30:45 --> No URI present. Default controller set.
INFO - 2023-09-11 18:30:45 --> Router Class Initialized
INFO - 2023-09-11 18:30:45 --> Output Class Initialized
INFO - 2023-09-11 18:30:45 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:45 --> Input Class Initialized
INFO - 2023-09-11 18:30:45 --> Language Class Initialized
INFO - 2023-09-11 18:30:45 --> Loader Class Initialized
INFO - 2023-09-11 18:30:45 --> Helper loaded: url_helper
INFO - 2023-09-11 18:30:45 --> Helper loaded: file_helper
INFO - 2023-09-11 18:30:45 --> Database Driver Class Initialized
INFO - 2023-09-11 18:30:45 --> Email Class Initialized
DEBUG - 2023-09-11 18:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:30:45 --> Controller Class Initialized
INFO - 2023-09-11 18:30:45 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:30:45 --> Model "Home_model" initialized
INFO - 2023-09-11 18:30:45 --> Helper loaded: download_helper
INFO - 2023-09-11 18:30:45 --> Helper loaded: form_helper
INFO - 2023-09-11 18:30:45 --> Form Validation Class Initialized
INFO - 2023-09-11 18:30:45 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:30:45 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:30:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 18:30:46 --> Final output sent to browser
DEBUG - 2023-09-11 18:30:46 --> Total execution time: 0.7297
INFO - 2023-09-11 18:30:50 --> Config Class Initialized
INFO - 2023-09-11 18:30:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:50 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:50 --> URI Class Initialized
INFO - 2023-09-11 18:30:50 --> Router Class Initialized
INFO - 2023-09-11 18:30:50 --> Output Class Initialized
INFO - 2023-09-11 18:30:50 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:50 --> Input Class Initialized
INFO - 2023-09-11 18:30:50 --> Language Class Initialized
ERROR - 2023-09-11 18:30:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:50 --> Config Class Initialized
INFO - 2023-09-11 18:30:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:50 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:50 --> URI Class Initialized
INFO - 2023-09-11 18:30:50 --> Router Class Initialized
INFO - 2023-09-11 18:30:50 --> Output Class Initialized
INFO - 2023-09-11 18:30:50 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:50 --> Input Class Initialized
INFO - 2023-09-11 18:30:50 --> Language Class Initialized
ERROR - 2023-09-11 18:30:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:50 --> Config Class Initialized
INFO - 2023-09-11 18:30:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:50 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:50 --> URI Class Initialized
INFO - 2023-09-11 18:30:50 --> Router Class Initialized
INFO - 2023-09-11 18:30:50 --> Output Class Initialized
INFO - 2023-09-11 18:30:50 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:50 --> Input Class Initialized
INFO - 2023-09-11 18:30:50 --> Language Class Initialized
ERROR - 2023-09-11 18:30:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:51 --> Config Class Initialized
INFO - 2023-09-11 18:30:51 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:51 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:51 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:51 --> URI Class Initialized
INFO - 2023-09-11 18:30:51 --> Router Class Initialized
INFO - 2023-09-11 18:30:51 --> Output Class Initialized
INFO - 2023-09-11 18:30:51 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:51 --> Input Class Initialized
INFO - 2023-09-11 18:30:51 --> Language Class Initialized
ERROR - 2023-09-11 18:30:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:52 --> Config Class Initialized
INFO - 2023-09-11 18:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:52 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:52 --> URI Class Initialized
INFO - 2023-09-11 18:30:52 --> Router Class Initialized
INFO - 2023-09-11 18:30:52 --> Output Class Initialized
INFO - 2023-09-11 18:30:52 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:52 --> Input Class Initialized
INFO - 2023-09-11 18:30:52 --> Language Class Initialized
ERROR - 2023-09-11 18:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:52 --> Config Class Initialized
INFO - 2023-09-11 18:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:52 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:52 --> URI Class Initialized
INFO - 2023-09-11 18:30:52 --> Router Class Initialized
INFO - 2023-09-11 18:30:52 --> Output Class Initialized
INFO - 2023-09-11 18:30:52 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:52 --> Input Class Initialized
INFO - 2023-09-11 18:30:52 --> Language Class Initialized
ERROR - 2023-09-11 18:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:30:52 --> Config Class Initialized
INFO - 2023-09-11 18:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:30:52 --> Utf8 Class Initialized
INFO - 2023-09-11 18:30:52 --> URI Class Initialized
INFO - 2023-09-11 18:30:52 --> Router Class Initialized
INFO - 2023-09-11 18:30:52 --> Output Class Initialized
INFO - 2023-09-11 18:30:52 --> Security Class Initialized
DEBUG - 2023-09-11 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:30:52 --> Input Class Initialized
INFO - 2023-09-11 18:30:52 --> Language Class Initialized
ERROR - 2023-09-11 18:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:31:26 --> Config Class Initialized
INFO - 2023-09-11 18:31:26 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:31:26 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:31:26 --> Utf8 Class Initialized
INFO - 2023-09-11 18:31:26 --> URI Class Initialized
INFO - 2023-09-11 18:31:26 --> Router Class Initialized
INFO - 2023-09-11 18:31:26 --> Output Class Initialized
INFO - 2023-09-11 18:31:26 --> Security Class Initialized
DEBUG - 2023-09-11 18:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:31:26 --> Input Class Initialized
INFO - 2023-09-11 18:31:26 --> Language Class Initialized
INFO - 2023-09-11 18:31:26 --> Loader Class Initialized
INFO - 2023-09-11 18:31:26 --> Helper loaded: url_helper
INFO - 2023-09-11 18:31:26 --> Helper loaded: file_helper
INFO - 2023-09-11 18:31:26 --> Database Driver Class Initialized
INFO - 2023-09-11 18:31:26 --> Email Class Initialized
DEBUG - 2023-09-11 18:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:31:26 --> Controller Class Initialized
INFO - 2023-09-11 18:31:26 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:31:26 --> Model "Home_model" initialized
INFO - 2023-09-11 18:31:26 --> Helper loaded: download_helper
INFO - 2023-09-11 18:31:26 --> Helper loaded: form_helper
INFO - 2023-09-11 18:31:26 --> Form Validation Class Initialized
INFO - 2023-09-11 18:33:34 --> Config Class Initialized
INFO - 2023-09-11 18:33:34 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:33:34 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:34 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:34 --> URI Class Initialized
DEBUG - 2023-09-11 18:33:34 --> No URI present. Default controller set.
INFO - 2023-09-11 18:33:34 --> Router Class Initialized
INFO - 2023-09-11 18:33:34 --> Output Class Initialized
INFO - 2023-09-11 18:33:34 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:34 --> Input Class Initialized
INFO - 2023-09-11 18:33:34 --> Language Class Initialized
INFO - 2023-09-11 18:33:34 --> Loader Class Initialized
INFO - 2023-09-11 18:33:34 --> Helper loaded: url_helper
INFO - 2023-09-11 18:33:34 --> Helper loaded: file_helper
INFO - 2023-09-11 18:33:34 --> Database Driver Class Initialized
INFO - 2023-09-11 18:33:34 --> Email Class Initialized
DEBUG - 2023-09-11 18:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:33:34 --> Controller Class Initialized
INFO - 2023-09-11 18:33:34 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:33:34 --> Model "Home_model" initialized
INFO - 2023-09-11 18:33:34 --> Helper loaded: download_helper
INFO - 2023-09-11 18:33:34 --> Helper loaded: form_helper
INFO - 2023-09-11 18:33:34 --> Form Validation Class Initialized
INFO - 2023-09-11 18:33:34 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:33:34 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:33:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 18:33:34 --> Final output sent to browser
DEBUG - 2023-09-11 18:33:34 --> Total execution time: 0.4804
INFO - 2023-09-11 18:33:37 --> Config Class Initialized
INFO - 2023-09-11 18:33:37 --> Config Class Initialized
INFO - 2023-09-11 18:33:37 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:33:37 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:37 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:37 --> URI Class Initialized
INFO - 2023-09-11 18:33:37 --> Router Class Initialized
INFO - 2023-09-11 18:33:37 --> Output Class Initialized
INFO - 2023-09-11 18:33:38 --> Security Class Initialized
INFO - 2023-09-11 18:33:38 --> Hooks Class Initialized
INFO - 2023-09-11 18:33:38 --> Config Class Initialized
INFO - 2023-09-11 18:33:39 --> Config Class Initialized
INFO - 2023-09-11 18:33:39 --> Hooks Class Initialized
INFO - 2023-09-11 18:33:40 --> Config Class Initialized
DEBUG - 2023-09-11 18:33:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:40 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 18:33:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:40 --> Config Class Initialized
DEBUG - 2023-09-11 18:33:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:40 --> Hooks Class Initialized
INFO - 2023-09-11 18:33:40 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:40 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:40 --> Hooks Class Initialized
INFO - 2023-09-11 18:33:40 --> Utf8 Class Initialized
DEBUG - 2023-09-11 18:33:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:40 --> URI Class Initialized
INFO - 2023-09-11 18:33:40 --> Input Class Initialized
INFO - 2023-09-11 18:33:40 --> Language Class Initialized
DEBUG - 2023-09-11 18:33:40 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:40 --> URI Class Initialized
INFO - 2023-09-11 18:33:40 --> Router Class Initialized
INFO - 2023-09-11 18:33:40 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:40 --> URI Class Initialized
ERROR - 2023-09-11 18:33:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:40 --> Router Class Initialized
INFO - 2023-09-11 18:33:40 --> URI Class Initialized
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Router Class Initialized
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:41 --> Config Class Initialized
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:41 --> URI Class Initialized
INFO - 2023-09-11 18:33:41 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:33:41 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:41 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:41 --> URI Class Initialized
INFO - 2023-09-11 18:33:41 --> Router Class Initialized
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Router Class Initialized
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:41 --> Router Class Initialized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:41 --> Output Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
INFO - 2023-09-11 18:33:41 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Input Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
INFO - 2023-09-11 18:33:41 --> Language Class Initialized
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-11 18:33:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-11 18:33:59 --> Config Class Initialized
INFO - 2023-09-11 18:33:59 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:33:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:33:59 --> Utf8 Class Initialized
INFO - 2023-09-11 18:33:59 --> URI Class Initialized
INFO - 2023-09-11 18:33:59 --> Router Class Initialized
INFO - 2023-09-11 18:33:59 --> Output Class Initialized
INFO - 2023-09-11 18:33:59 --> Security Class Initialized
DEBUG - 2023-09-11 18:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:33:59 --> Input Class Initialized
INFO - 2023-09-11 18:33:59 --> Language Class Initialized
INFO - 2023-09-11 18:33:59 --> Loader Class Initialized
INFO - 2023-09-11 18:33:59 --> Helper loaded: url_helper
INFO - 2023-09-11 18:33:59 --> Helper loaded: file_helper
INFO - 2023-09-11 18:33:59 --> Database Driver Class Initialized
INFO - 2023-09-11 18:33:59 --> Email Class Initialized
DEBUG - 2023-09-11 18:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:33:59 --> Controller Class Initialized
INFO - 2023-09-11 18:33:59 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:33:59 --> Model "Home_model" initialized
INFO - 2023-09-11 18:33:59 --> Helper loaded: download_helper
INFO - 2023-09-11 18:33:59 --> Helper loaded: form_helper
INFO - 2023-09-11 18:33:59 --> Form Validation Class Initialized
INFO - 2023-09-11 18:54:36 --> Config Class Initialized
INFO - 2023-09-11 18:54:37 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:54:37 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:54:37 --> Utf8 Class Initialized
INFO - 2023-09-11 18:54:37 --> URI Class Initialized
DEBUG - 2023-09-11 18:54:37 --> No URI present. Default controller set.
INFO - 2023-09-11 18:54:37 --> Router Class Initialized
INFO - 2023-09-11 18:54:37 --> Output Class Initialized
INFO - 2023-09-11 18:54:37 --> Security Class Initialized
DEBUG - 2023-09-11 18:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:54:37 --> Input Class Initialized
INFO - 2023-09-11 18:54:37 --> Language Class Initialized
INFO - 2023-09-11 18:54:37 --> Loader Class Initialized
INFO - 2023-09-11 18:54:37 --> Helper loaded: url_helper
INFO - 2023-09-11 18:54:37 --> Helper loaded: file_helper
INFO - 2023-09-11 18:54:37 --> Database Driver Class Initialized
INFO - 2023-09-11 18:54:37 --> Email Class Initialized
DEBUG - 2023-09-11 18:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:54:37 --> Controller Class Initialized
INFO - 2023-09-11 18:54:38 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:54:38 --> Model "Home_model" initialized
INFO - 2023-09-11 18:54:38 --> Helper loaded: download_helper
INFO - 2023-09-11 18:54:38 --> Helper loaded: form_helper
INFO - 2023-09-11 18:54:38 --> Form Validation Class Initialized
INFO - 2023-09-11 18:54:38 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:54:38 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:54:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-11 18:54:38 --> Final output sent to browser
DEBUG - 2023-09-11 18:54:38 --> Total execution time: 1.2706
INFO - 2023-09-11 18:54:46 --> Config Class Initialized
INFO - 2023-09-11 18:54:46 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:54:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:54:46 --> Utf8 Class Initialized
INFO - 2023-09-11 18:54:46 --> URI Class Initialized
INFO - 2023-09-11 18:54:46 --> Router Class Initialized
INFO - 2023-09-11 18:54:46 --> Output Class Initialized
INFO - 2023-09-11 18:54:46 --> Security Class Initialized
DEBUG - 2023-09-11 18:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:54:46 --> Input Class Initialized
INFO - 2023-09-11 18:54:46 --> Language Class Initialized
INFO - 2023-09-11 18:54:46 --> Loader Class Initialized
INFO - 2023-09-11 18:54:46 --> Helper loaded: url_helper
INFO - 2023-09-11 18:54:46 --> Helper loaded: file_helper
INFO - 2023-09-11 18:54:46 --> Database Driver Class Initialized
INFO - 2023-09-11 18:54:46 --> Email Class Initialized
DEBUG - 2023-09-11 18:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:54:46 --> Controller Class Initialized
INFO - 2023-09-11 18:54:46 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:54:46 --> Model "Home_model" initialized
INFO - 2023-09-11 18:54:46 --> Helper loaded: download_helper
INFO - 2023-09-11 18:54:46 --> Helper loaded: form_helper
INFO - 2023-09-11 18:54:46 --> Form Validation Class Initialized
INFO - 2023-09-11 18:54:47 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:54:47 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:54:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:54:47 --> Final output sent to browser
DEBUG - 2023-09-11 18:54:47 --> Total execution time: 0.9156
INFO - 2023-09-11 18:55:10 --> Config Class Initialized
INFO - 2023-09-11 18:55:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:55:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:55:10 --> Utf8 Class Initialized
INFO - 2023-09-11 18:55:10 --> URI Class Initialized
INFO - 2023-09-11 18:55:10 --> Router Class Initialized
INFO - 2023-09-11 18:55:10 --> Output Class Initialized
INFO - 2023-09-11 18:55:10 --> Security Class Initialized
DEBUG - 2023-09-11 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:55:10 --> Input Class Initialized
INFO - 2023-09-11 18:55:10 --> Language Class Initialized
INFO - 2023-09-11 18:55:10 --> Loader Class Initialized
INFO - 2023-09-11 18:55:10 --> Helper loaded: url_helper
INFO - 2023-09-11 18:55:11 --> Helper loaded: file_helper
INFO - 2023-09-11 18:55:11 --> Database Driver Class Initialized
INFO - 2023-09-11 18:55:11 --> Email Class Initialized
DEBUG - 2023-09-11 18:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:55:11 --> Controller Class Initialized
INFO - 2023-09-11 18:55:11 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:55:11 --> Model "Home_model" initialized
INFO - 2023-09-11 18:55:11 --> Helper loaded: download_helper
INFO - 2023-09-11 18:55:11 --> Helper loaded: form_helper
INFO - 2023-09-11 18:55:11 --> Form Validation Class Initialized
INFO - 2023-09-11 18:55:11 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:55:11 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:55:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:55:11 --> Final output sent to browser
DEBUG - 2023-09-11 18:55:11 --> Total execution time: 0.9878
INFO - 2023-09-11 18:56:51 --> Config Class Initialized
INFO - 2023-09-11 18:56:51 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:56:51 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:56:51 --> Utf8 Class Initialized
INFO - 2023-09-11 18:56:51 --> URI Class Initialized
INFO - 2023-09-11 18:56:51 --> Router Class Initialized
INFO - 2023-09-11 18:56:52 --> Output Class Initialized
INFO - 2023-09-11 18:56:52 --> Security Class Initialized
DEBUG - 2023-09-11 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:56:52 --> Input Class Initialized
INFO - 2023-09-11 18:56:52 --> Language Class Initialized
INFO - 2023-09-11 18:56:52 --> Loader Class Initialized
INFO - 2023-09-11 18:56:52 --> Helper loaded: url_helper
INFO - 2023-09-11 18:56:52 --> Helper loaded: file_helper
INFO - 2023-09-11 18:56:52 --> Database Driver Class Initialized
INFO - 2023-09-11 18:56:52 --> Email Class Initialized
DEBUG - 2023-09-11 18:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:56:52 --> Controller Class Initialized
INFO - 2023-09-11 18:56:52 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:56:52 --> Model "Home_model" initialized
INFO - 2023-09-11 18:56:52 --> Helper loaded: download_helper
INFO - 2023-09-11 18:56:52 --> Helper loaded: form_helper
INFO - 2023-09-11 18:56:52 --> Form Validation Class Initialized
INFO - 2023-09-11 18:56:52 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:56:52 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:56:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:56:52 --> Final output sent to browser
DEBUG - 2023-09-11 18:56:52 --> Total execution time: 0.8973
INFO - 2023-09-11 18:57:32 --> Config Class Initialized
INFO - 2023-09-11 18:57:32 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:57:32 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:57:32 --> Utf8 Class Initialized
INFO - 2023-09-11 18:57:32 --> URI Class Initialized
INFO - 2023-09-11 18:57:32 --> Router Class Initialized
INFO - 2023-09-11 18:57:33 --> Output Class Initialized
INFO - 2023-09-11 18:57:33 --> Security Class Initialized
DEBUG - 2023-09-11 18:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:57:33 --> Input Class Initialized
INFO - 2023-09-11 18:57:33 --> Language Class Initialized
INFO - 2023-09-11 18:57:33 --> Loader Class Initialized
INFO - 2023-09-11 18:57:33 --> Helper loaded: url_helper
INFO - 2023-09-11 18:57:33 --> Helper loaded: file_helper
INFO - 2023-09-11 18:57:33 --> Database Driver Class Initialized
INFO - 2023-09-11 18:57:33 --> Email Class Initialized
DEBUG - 2023-09-11 18:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:57:33 --> Controller Class Initialized
INFO - 2023-09-11 18:57:33 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:57:33 --> Model "Home_model" initialized
INFO - 2023-09-11 18:57:33 --> Helper loaded: download_helper
INFO - 2023-09-11 18:57:33 --> Helper loaded: form_helper
INFO - 2023-09-11 18:57:33 --> Form Validation Class Initialized
INFO - 2023-09-11 18:57:33 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:57:33 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:57:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:57:33 --> Final output sent to browser
DEBUG - 2023-09-11 18:57:33 --> Total execution time: 0.9586
INFO - 2023-09-11 18:58:03 --> Config Class Initialized
INFO - 2023-09-11 18:58:03 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:58:03 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:58:03 --> Utf8 Class Initialized
INFO - 2023-09-11 18:58:03 --> URI Class Initialized
INFO - 2023-09-11 18:58:03 --> Router Class Initialized
INFO - 2023-09-11 18:58:03 --> Output Class Initialized
INFO - 2023-09-11 18:58:03 --> Security Class Initialized
DEBUG - 2023-09-11 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:58:03 --> Input Class Initialized
INFO - 2023-09-11 18:58:03 --> Language Class Initialized
INFO - 2023-09-11 18:58:03 --> Loader Class Initialized
INFO - 2023-09-11 18:58:03 --> Helper loaded: url_helper
INFO - 2023-09-11 18:58:03 --> Helper loaded: file_helper
INFO - 2023-09-11 18:58:03 --> Database Driver Class Initialized
INFO - 2023-09-11 18:58:03 --> Email Class Initialized
DEBUG - 2023-09-11 18:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:58:03 --> Controller Class Initialized
INFO - 2023-09-11 18:58:03 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:58:03 --> Model "Home_model" initialized
INFO - 2023-09-11 18:58:03 --> Helper loaded: download_helper
INFO - 2023-09-11 18:58:03 --> Helper loaded: form_helper
INFO - 2023-09-11 18:58:03 --> Form Validation Class Initialized
INFO - 2023-09-11 18:58:03 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:58:03 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:58:03 --> Final output sent to browser
DEBUG - 2023-09-11 18:58:04 --> Total execution time: 0.7131
INFO - 2023-09-11 18:58:24 --> Config Class Initialized
INFO - 2023-09-11 18:58:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:58:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:58:24 --> Utf8 Class Initialized
INFO - 2023-09-11 18:58:24 --> URI Class Initialized
INFO - 2023-09-11 18:58:24 --> Router Class Initialized
INFO - 2023-09-11 18:58:24 --> Output Class Initialized
INFO - 2023-09-11 18:58:24 --> Security Class Initialized
DEBUG - 2023-09-11 18:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:58:24 --> Input Class Initialized
INFO - 2023-09-11 18:58:24 --> Language Class Initialized
INFO - 2023-09-11 18:58:24 --> Loader Class Initialized
INFO - 2023-09-11 18:58:24 --> Helper loaded: url_helper
INFO - 2023-09-11 18:58:24 --> Helper loaded: file_helper
INFO - 2023-09-11 18:58:24 --> Database Driver Class Initialized
INFO - 2023-09-11 18:58:24 --> Email Class Initialized
DEBUG - 2023-09-11 18:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:58:24 --> Controller Class Initialized
INFO - 2023-09-11 18:58:24 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:58:24 --> Model "Home_model" initialized
INFO - 2023-09-11 18:58:24 --> Helper loaded: download_helper
INFO - 2023-09-11 18:58:24 --> Helper loaded: form_helper
INFO - 2023-09-11 18:58:24 --> Form Validation Class Initialized
INFO - 2023-09-11 18:58:24 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:58:25 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:58:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:58:25 --> Final output sent to browser
DEBUG - 2023-09-11 18:58:25 --> Total execution time: 0.8865
INFO - 2023-09-11 18:58:50 --> Config Class Initialized
INFO - 2023-09-11 18:58:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:58:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:58:50 --> Utf8 Class Initialized
INFO - 2023-09-11 18:58:50 --> URI Class Initialized
INFO - 2023-09-11 18:58:50 --> Router Class Initialized
INFO - 2023-09-11 18:58:50 --> Output Class Initialized
INFO - 2023-09-11 18:58:50 --> Security Class Initialized
DEBUG - 2023-09-11 18:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:58:50 --> Input Class Initialized
INFO - 2023-09-11 18:58:50 --> Language Class Initialized
INFO - 2023-09-11 18:58:50 --> Loader Class Initialized
INFO - 2023-09-11 18:58:50 --> Helper loaded: url_helper
INFO - 2023-09-11 18:58:50 --> Helper loaded: file_helper
INFO - 2023-09-11 18:58:50 --> Database Driver Class Initialized
INFO - 2023-09-11 18:58:50 --> Email Class Initialized
DEBUG - 2023-09-11 18:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:58:50 --> Controller Class Initialized
INFO - 2023-09-11 18:58:50 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:58:50 --> Model "Home_model" initialized
INFO - 2023-09-11 18:58:50 --> Helper loaded: download_helper
INFO - 2023-09-11 18:58:50 --> Helper loaded: form_helper
INFO - 2023-09-11 18:58:50 --> Form Validation Class Initialized
INFO - 2023-09-11 18:58:51 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:58:51 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:58:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:58:51 --> Final output sent to browser
DEBUG - 2023-09-11 18:58:51 --> Total execution time: 0.9844
INFO - 2023-09-11 18:59:17 --> Config Class Initialized
INFO - 2023-09-11 18:59:17 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:59:17 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:59:17 --> Utf8 Class Initialized
INFO - 2023-09-11 18:59:17 --> URI Class Initialized
INFO - 2023-09-11 18:59:17 --> Router Class Initialized
INFO - 2023-09-11 18:59:17 --> Output Class Initialized
INFO - 2023-09-11 18:59:17 --> Security Class Initialized
DEBUG - 2023-09-11 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:59:17 --> Input Class Initialized
INFO - 2023-09-11 18:59:17 --> Language Class Initialized
INFO - 2023-09-11 18:59:17 --> Loader Class Initialized
INFO - 2023-09-11 18:59:17 --> Helper loaded: url_helper
INFO - 2023-09-11 18:59:17 --> Helper loaded: file_helper
INFO - 2023-09-11 18:59:17 --> Database Driver Class Initialized
INFO - 2023-09-11 18:59:17 --> Email Class Initialized
DEBUG - 2023-09-11 18:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:59:17 --> Controller Class Initialized
INFO - 2023-09-11 18:59:17 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:59:17 --> Model "Home_model" initialized
INFO - 2023-09-11 18:59:17 --> Helper loaded: download_helper
INFO - 2023-09-11 18:59:17 --> Helper loaded: form_helper
INFO - 2023-09-11 18:59:17 --> Form Validation Class Initialized
INFO - 2023-09-11 18:59:17 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:59:17 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:59:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:59:17 --> Final output sent to browser
DEBUG - 2023-09-11 18:59:18 --> Total execution time: 0.3947
INFO - 2023-09-11 18:59:46 --> Config Class Initialized
INFO - 2023-09-11 18:59:46 --> Hooks Class Initialized
DEBUG - 2023-09-11 18:59:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 18:59:46 --> Utf8 Class Initialized
INFO - 2023-09-11 18:59:46 --> URI Class Initialized
INFO - 2023-09-11 18:59:46 --> Router Class Initialized
INFO - 2023-09-11 18:59:46 --> Output Class Initialized
INFO - 2023-09-11 18:59:46 --> Security Class Initialized
DEBUG - 2023-09-11 18:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 18:59:46 --> Input Class Initialized
INFO - 2023-09-11 18:59:46 --> Language Class Initialized
INFO - 2023-09-11 18:59:46 --> Loader Class Initialized
INFO - 2023-09-11 18:59:46 --> Helper loaded: url_helper
INFO - 2023-09-11 18:59:46 --> Helper loaded: file_helper
INFO - 2023-09-11 18:59:46 --> Database Driver Class Initialized
INFO - 2023-09-11 18:59:46 --> Email Class Initialized
DEBUG - 2023-09-11 18:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 18:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 18:59:46 --> Controller Class Initialized
INFO - 2023-09-11 18:59:46 --> Model "Contact_model" initialized
INFO - 2023-09-11 18:59:46 --> Model "Home_model" initialized
INFO - 2023-09-11 18:59:46 --> Helper loaded: download_helper
INFO - 2023-09-11 18:59:46 --> Helper loaded: form_helper
INFO - 2023-09-11 18:59:46 --> Form Validation Class Initialized
INFO - 2023-09-11 18:59:46 --> Helper loaded: custom_helper
INFO - 2023-09-11 18:59:46 --> Model "Social_media_model" initialized
INFO - 2023-09-11 18:59:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-11 18:59:46 --> Final output sent to browser
DEBUG - 2023-09-11 18:59:46 --> Total execution time: 0.3449
INFO - 2023-09-11 19:01:47 --> Config Class Initialized
INFO - 2023-09-11 19:01:47 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:01:47 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:01:47 --> Utf8 Class Initialized
INFO - 2023-09-11 19:01:47 --> URI Class Initialized
INFO - 2023-09-11 19:01:47 --> Router Class Initialized
INFO - 2023-09-11 19:01:47 --> Output Class Initialized
INFO - 2023-09-11 19:01:47 --> Security Class Initialized
DEBUG - 2023-09-11 19:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:01:47 --> Input Class Initialized
INFO - 2023-09-11 19:01:47 --> Language Class Initialized
INFO - 2023-09-11 19:01:47 --> Loader Class Initialized
INFO - 2023-09-11 19:01:47 --> Helper loaded: url_helper
INFO - 2023-09-11 19:01:47 --> Helper loaded: file_helper
INFO - 2023-09-11 19:01:47 --> Database Driver Class Initialized
INFO - 2023-09-11 19:01:47 --> Email Class Initialized
DEBUG - 2023-09-11 19:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:01:47 --> Controller Class Initialized
INFO - 2023-09-11 19:01:47 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:01:47 --> Model "Home_model" initialized
INFO - 2023-09-11 19:01:47 --> Helper loaded: download_helper
INFO - 2023-09-11 19:01:48 --> Helper loaded: form_helper
INFO - 2023-09-11 19:01:48 --> Form Validation Class Initialized
INFO - 2023-09-11 19:01:48 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:01:48 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:01:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/disclamer.php
INFO - 2023-09-11 19:01:48 --> Final output sent to browser
DEBUG - 2023-09-11 19:01:48 --> Total execution time: 0.6423
INFO - 2023-09-11 19:03:19 --> Config Class Initialized
INFO - 2023-09-11 19:03:19 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:03:19 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:03:19 --> Utf8 Class Initialized
INFO - 2023-09-11 19:03:19 --> URI Class Initialized
INFO - 2023-09-11 19:03:19 --> Router Class Initialized
INFO - 2023-09-11 19:03:19 --> Output Class Initialized
INFO - 2023-09-11 19:03:19 --> Security Class Initialized
DEBUG - 2023-09-11 19:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:03:19 --> Input Class Initialized
INFO - 2023-09-11 19:03:19 --> Language Class Initialized
INFO - 2023-09-11 19:03:19 --> Loader Class Initialized
INFO - 2023-09-11 19:03:19 --> Helper loaded: url_helper
INFO - 2023-09-11 19:03:19 --> Helper loaded: file_helper
INFO - 2023-09-11 19:03:19 --> Database Driver Class Initialized
INFO - 2023-09-11 19:03:19 --> Email Class Initialized
DEBUG - 2023-09-11 19:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:03:19 --> Controller Class Initialized
INFO - 2023-09-11 19:03:20 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:03:20 --> Model "Home_model" initialized
INFO - 2023-09-11 19:03:20 --> Helper loaded: download_helper
INFO - 2023-09-11 19:03:20 --> Helper loaded: form_helper
INFO - 2023-09-11 19:03:20 --> Form Validation Class Initialized
INFO - 2023-09-11 19:03:20 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:03:20 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:03:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/disclamer.php
INFO - 2023-09-11 19:03:20 --> Final output sent to browser
DEBUG - 2023-09-11 19:03:20 --> Total execution time: 0.8487
INFO - 2023-09-11 19:04:12 --> Config Class Initialized
INFO - 2023-09-11 19:04:12 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:04:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:04:12 --> Utf8 Class Initialized
INFO - 2023-09-11 19:04:12 --> URI Class Initialized
INFO - 2023-09-11 19:04:12 --> Router Class Initialized
INFO - 2023-09-11 19:04:12 --> Output Class Initialized
INFO - 2023-09-11 19:04:12 --> Security Class Initialized
DEBUG - 2023-09-11 19:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:04:12 --> Input Class Initialized
INFO - 2023-09-11 19:04:12 --> Language Class Initialized
INFO - 2023-09-11 19:04:12 --> Loader Class Initialized
INFO - 2023-09-11 19:04:12 --> Helper loaded: url_helper
INFO - 2023-09-11 19:04:12 --> Helper loaded: file_helper
INFO - 2023-09-11 19:04:12 --> Database Driver Class Initialized
INFO - 2023-09-11 19:04:12 --> Email Class Initialized
DEBUG - 2023-09-11 19:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:04:13 --> Controller Class Initialized
INFO - 2023-09-11 19:04:13 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:04:13 --> Model "Home_model" initialized
INFO - 2023-09-11 19:04:13 --> Helper loaded: download_helper
INFO - 2023-09-11 19:04:13 --> Helper loaded: form_helper
INFO - 2023-09-11 19:04:13 --> Form Validation Class Initialized
INFO - 2023-09-11 19:04:13 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:04:13 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:04:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/disclamer.php
INFO - 2023-09-11 19:04:13 --> Final output sent to browser
DEBUG - 2023-09-11 19:04:13 --> Total execution time: 1.0768
INFO - 2023-09-11 19:04:18 --> Config Class Initialized
INFO - 2023-09-11 19:04:18 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:04:18 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:04:18 --> Utf8 Class Initialized
INFO - 2023-09-11 19:04:18 --> URI Class Initialized
INFO - 2023-09-11 19:04:18 --> Router Class Initialized
INFO - 2023-09-11 19:04:18 --> Output Class Initialized
INFO - 2023-09-11 19:04:18 --> Security Class Initialized
DEBUG - 2023-09-11 19:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:04:18 --> Input Class Initialized
INFO - 2023-09-11 19:04:18 --> Language Class Initialized
INFO - 2023-09-11 19:04:18 --> Loader Class Initialized
INFO - 2023-09-11 19:04:18 --> Helper loaded: url_helper
INFO - 2023-09-11 19:04:18 --> Helper loaded: file_helper
INFO - 2023-09-11 19:04:18 --> Database Driver Class Initialized
INFO - 2023-09-11 19:04:18 --> Email Class Initialized
DEBUG - 2023-09-11 19:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:04:18 --> Controller Class Initialized
INFO - 2023-09-11 19:04:18 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:04:18 --> Model "Home_model" initialized
INFO - 2023-09-11 19:04:18 --> Helper loaded: download_helper
INFO - 2023-09-11 19:04:18 --> Helper loaded: form_helper
INFO - 2023-09-11 19:04:18 --> Form Validation Class Initialized
INFO - 2023-09-11 19:04:18 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:04:19 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:04:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:04:19 --> Final output sent to browser
DEBUG - 2023-09-11 19:04:19 --> Total execution time: 1.0282
INFO - 2023-09-11 19:05:10 --> Config Class Initialized
INFO - 2023-09-11 19:05:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:05:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:05:10 --> Utf8 Class Initialized
INFO - 2023-09-11 19:05:10 --> URI Class Initialized
INFO - 2023-09-11 19:05:10 --> Router Class Initialized
INFO - 2023-09-11 19:05:11 --> Output Class Initialized
INFO - 2023-09-11 19:05:11 --> Security Class Initialized
DEBUG - 2023-09-11 19:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:05:11 --> Input Class Initialized
INFO - 2023-09-11 19:05:11 --> Language Class Initialized
INFO - 2023-09-11 19:05:11 --> Loader Class Initialized
INFO - 2023-09-11 19:05:11 --> Helper loaded: url_helper
INFO - 2023-09-11 19:05:11 --> Helper loaded: file_helper
INFO - 2023-09-11 19:05:11 --> Database Driver Class Initialized
INFO - 2023-09-11 19:05:11 --> Email Class Initialized
DEBUG - 2023-09-11 19:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:05:11 --> Controller Class Initialized
INFO - 2023-09-11 19:05:11 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:05:11 --> Model "Home_model" initialized
INFO - 2023-09-11 19:05:11 --> Helper loaded: download_helper
INFO - 2023-09-11 19:05:11 --> Helper loaded: form_helper
INFO - 2023-09-11 19:05:11 --> Form Validation Class Initialized
INFO - 2023-09-11 19:05:11 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:05:11 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:05:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:05:11 --> Final output sent to browser
DEBUG - 2023-09-11 19:05:11 --> Total execution time: 0.5426
INFO - 2023-09-11 19:06:56 --> Config Class Initialized
INFO - 2023-09-11 19:06:56 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:06:56 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:06:56 --> Utf8 Class Initialized
INFO - 2023-09-11 19:06:56 --> URI Class Initialized
INFO - 2023-09-11 19:06:56 --> Router Class Initialized
INFO - 2023-09-11 19:06:56 --> Output Class Initialized
INFO - 2023-09-11 19:06:56 --> Security Class Initialized
DEBUG - 2023-09-11 19:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:06:56 --> Input Class Initialized
INFO - 2023-09-11 19:06:56 --> Language Class Initialized
INFO - 2023-09-11 19:06:56 --> Loader Class Initialized
INFO - 2023-09-11 19:06:56 --> Helper loaded: url_helper
INFO - 2023-09-11 19:06:57 --> Helper loaded: file_helper
INFO - 2023-09-11 19:06:57 --> Database Driver Class Initialized
INFO - 2023-09-11 19:06:57 --> Email Class Initialized
DEBUG - 2023-09-11 19:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:06:57 --> Controller Class Initialized
INFO - 2023-09-11 19:06:57 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:06:57 --> Model "Home_model" initialized
INFO - 2023-09-11 19:06:57 --> Helper loaded: download_helper
INFO - 2023-09-11 19:06:57 --> Helper loaded: form_helper
INFO - 2023-09-11 19:06:57 --> Form Validation Class Initialized
INFO - 2023-09-11 19:06:57 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:06:57 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:06:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:06:57 --> Final output sent to browser
DEBUG - 2023-09-11 19:06:57 --> Total execution time: 0.3351
INFO - 2023-09-11 19:07:02 --> Config Class Initialized
INFO - 2023-09-11 19:07:02 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:07:02 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:07:02 --> Utf8 Class Initialized
INFO - 2023-09-11 19:07:02 --> URI Class Initialized
INFO - 2023-09-11 19:07:02 --> Router Class Initialized
INFO - 2023-09-11 19:07:02 --> Output Class Initialized
INFO - 2023-09-11 19:07:02 --> Security Class Initialized
DEBUG - 2023-09-11 19:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:07:02 --> Input Class Initialized
INFO - 2023-09-11 19:07:02 --> Language Class Initialized
INFO - 2023-09-11 19:07:02 --> Loader Class Initialized
INFO - 2023-09-11 19:07:02 --> Helper loaded: url_helper
INFO - 2023-09-11 19:07:02 --> Helper loaded: file_helper
INFO - 2023-09-11 19:07:02 --> Database Driver Class Initialized
INFO - 2023-09-11 19:07:02 --> Email Class Initialized
DEBUG - 2023-09-11 19:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:07:03 --> Controller Class Initialized
INFO - 2023-09-11 19:07:03 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:07:03 --> Model "Home_model" initialized
INFO - 2023-09-11 19:07:03 --> Helper loaded: download_helper
INFO - 2023-09-11 19:07:03 --> Helper loaded: form_helper
INFO - 2023-09-11 19:07:03 --> Form Validation Class Initialized
INFO - 2023-09-11 19:07:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:07:03 --> Final output sent to browser
DEBUG - 2023-09-11 19:07:03 --> Total execution time: 0.2941
INFO - 2023-09-11 19:08:47 --> Config Class Initialized
INFO - 2023-09-11 19:08:47 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:08:47 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:08:47 --> Utf8 Class Initialized
INFO - 2023-09-11 19:08:47 --> URI Class Initialized
INFO - 2023-09-11 19:08:47 --> Router Class Initialized
INFO - 2023-09-11 19:08:47 --> Output Class Initialized
INFO - 2023-09-11 19:08:47 --> Security Class Initialized
DEBUG - 2023-09-11 19:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:08:48 --> Input Class Initialized
INFO - 2023-09-11 19:08:48 --> Language Class Initialized
INFO - 2023-09-11 19:08:48 --> Loader Class Initialized
INFO - 2023-09-11 19:08:48 --> Helper loaded: url_helper
INFO - 2023-09-11 19:08:48 --> Helper loaded: file_helper
INFO - 2023-09-11 19:08:48 --> Database Driver Class Initialized
INFO - 2023-09-11 19:08:48 --> Email Class Initialized
DEBUG - 2023-09-11 19:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:08:48 --> Controller Class Initialized
INFO - 2023-09-11 19:08:48 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:08:48 --> Model "Home_model" initialized
INFO - 2023-09-11 19:08:48 --> Helper loaded: download_helper
INFO - 2023-09-11 19:08:48 --> Helper loaded: form_helper
INFO - 2023-09-11 19:08:48 --> Form Validation Class Initialized
INFO - 2023-09-11 19:08:48 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:08:48 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:08:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:08:48 --> Final output sent to browser
DEBUG - 2023-09-11 19:08:48 --> Total execution time: 0.2859
INFO - 2023-09-11 19:09:01 --> Config Class Initialized
INFO - 2023-09-11 19:09:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:01 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:01 --> URI Class Initialized
INFO - 2023-09-11 19:09:01 --> Router Class Initialized
INFO - 2023-09-11 19:09:01 --> Output Class Initialized
INFO - 2023-09-11 19:09:01 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:01 --> Input Class Initialized
INFO - 2023-09-11 19:09:01 --> Language Class Initialized
INFO - 2023-09-11 19:09:01 --> Loader Class Initialized
INFO - 2023-09-11 19:09:01 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:01 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:01 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:01 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:01 --> Controller Class Initialized
INFO - 2023-09-11 19:09:01 --> Config Class Initialized
INFO - 2023-09-11 19:09:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:01 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:01 --> URI Class Initialized
INFO - 2023-09-11 19:09:02 --> Router Class Initialized
INFO - 2023-09-11 19:09:02 --> Output Class Initialized
INFO - 2023-09-11 19:09:02 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:02 --> Input Class Initialized
INFO - 2023-09-11 19:09:02 --> Language Class Initialized
INFO - 2023-09-11 19:09:02 --> Loader Class Initialized
INFO - 2023-09-11 19:09:02 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:02 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:02 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:02 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:02 --> Controller Class Initialized
INFO - 2023-09-11 19:09:02 --> Model "User_model" initialized
INFO - 2023-09-11 19:09:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-11 19:09:02 --> Final output sent to browser
DEBUG - 2023-09-11 19:09:02 --> Total execution time: 0.5109
INFO - 2023-09-11 19:09:06 --> Config Class Initialized
INFO - 2023-09-11 19:09:06 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:06 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:06 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:06 --> URI Class Initialized
INFO - 2023-09-11 19:09:06 --> Router Class Initialized
INFO - 2023-09-11 19:09:06 --> Output Class Initialized
INFO - 2023-09-11 19:09:06 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:06 --> Input Class Initialized
INFO - 2023-09-11 19:09:06 --> Language Class Initialized
ERROR - 2023-09-11 19:09:06 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-11 19:09:11 --> Config Class Initialized
INFO - 2023-09-11 19:09:11 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:11 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:11 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:11 --> URI Class Initialized
INFO - 2023-09-11 19:09:11 --> Router Class Initialized
INFO - 2023-09-11 19:09:11 --> Output Class Initialized
INFO - 2023-09-11 19:09:11 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:11 --> Input Class Initialized
INFO - 2023-09-11 19:09:11 --> Language Class Initialized
INFO - 2023-09-11 19:09:11 --> Loader Class Initialized
INFO - 2023-09-11 19:09:11 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:11 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:11 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:11 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:11 --> Controller Class Initialized
INFO - 2023-09-11 19:09:11 --> Model "User_model" initialized
INFO - 2023-09-11 19:09:11 --> Config Class Initialized
INFO - 2023-09-11 19:09:11 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:12 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:12 --> URI Class Initialized
INFO - 2023-09-11 19:09:12 --> Router Class Initialized
INFO - 2023-09-11 19:09:12 --> Output Class Initialized
INFO - 2023-09-11 19:09:12 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:12 --> Input Class Initialized
INFO - 2023-09-11 19:09:12 --> Language Class Initialized
INFO - 2023-09-11 19:09:12 --> Loader Class Initialized
INFO - 2023-09-11 19:09:12 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:12 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:12 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:12 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:12 --> Controller Class Initialized
INFO - 2023-09-11 19:09:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-11 19:09:12 --> Final output sent to browser
DEBUG - 2023-09-11 19:09:12 --> Total execution time: 0.5028
INFO - 2023-09-11 19:09:18 --> Config Class Initialized
INFO - 2023-09-11 19:09:18 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:18 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:18 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:18 --> URI Class Initialized
INFO - 2023-09-11 19:09:18 --> Router Class Initialized
INFO - 2023-09-11 19:09:18 --> Output Class Initialized
INFO - 2023-09-11 19:09:18 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:18 --> Input Class Initialized
INFO - 2023-09-11 19:09:18 --> Language Class Initialized
INFO - 2023-09-11 19:09:18 --> Loader Class Initialized
INFO - 2023-09-11 19:09:18 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:18 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:18 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:19 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:19 --> Controller Class Initialized
INFO - 2023-09-11 19:09:19 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:09:19 --> Helper loaded: form_helper
INFO - 2023-09-11 19:09:19 --> Form Validation Class Initialized
INFO - 2023-09-11 19:09:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:09:19 --> Final output sent to browser
DEBUG - 2023-09-11 19:09:19 --> Total execution time: 0.3768
INFO - 2023-09-11 19:09:23 --> Config Class Initialized
INFO - 2023-09-11 19:09:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:23 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:23 --> URI Class Initialized
INFO - 2023-09-11 19:09:23 --> Router Class Initialized
INFO - 2023-09-11 19:09:23 --> Output Class Initialized
INFO - 2023-09-11 19:09:23 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:23 --> Input Class Initialized
INFO - 2023-09-11 19:09:23 --> Language Class Initialized
INFO - 2023-09-11 19:09:23 --> Loader Class Initialized
INFO - 2023-09-11 19:09:23 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:23 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:23 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:23 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:23 --> Controller Class Initialized
INFO - 2023-09-11 19:09:23 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:09:23 --> Helper loaded: form_helper
INFO - 2023-09-11 19:09:23 --> Form Validation Class Initialized
INFO - 2023-09-11 19:09:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:09:23 --> Final output sent to browser
DEBUG - 2023-09-11 19:09:24 --> Total execution time: 0.4159
INFO - 2023-09-11 19:09:24 --> Config Class Initialized
INFO - 2023-09-11 19:09:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:09:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:09:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:09:24 --> URI Class Initialized
INFO - 2023-09-11 19:09:24 --> Router Class Initialized
INFO - 2023-09-11 19:09:24 --> Output Class Initialized
INFO - 2023-09-11 19:09:24 --> Security Class Initialized
DEBUG - 2023-09-11 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:09:24 --> Input Class Initialized
INFO - 2023-09-11 19:09:24 --> Language Class Initialized
INFO - 2023-09-11 19:09:24 --> Loader Class Initialized
INFO - 2023-09-11 19:09:24 --> Helper loaded: url_helper
INFO - 2023-09-11 19:09:24 --> Helper loaded: file_helper
INFO - 2023-09-11 19:09:25 --> Database Driver Class Initialized
INFO - 2023-09-11 19:09:25 --> Email Class Initialized
DEBUG - 2023-09-11 19:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:09:25 --> Controller Class Initialized
INFO - 2023-09-11 19:09:25 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:09:25 --> Helper loaded: form_helper
INFO - 2023-09-11 19:09:25 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:09:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-09-11 19:09:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:09:25 --> Final output sent to browser
DEBUG - 2023-09-11 19:09:25 --> Total execution time: 0.6081
INFO - 2023-09-11 19:10:49 --> Config Class Initialized
INFO - 2023-09-11 19:10:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:10:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:10:49 --> Utf8 Class Initialized
INFO - 2023-09-11 19:10:49 --> URI Class Initialized
INFO - 2023-09-11 19:10:49 --> Router Class Initialized
INFO - 2023-09-11 19:10:49 --> Output Class Initialized
INFO - 2023-09-11 19:10:49 --> Security Class Initialized
DEBUG - 2023-09-11 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:10:49 --> Input Class Initialized
INFO - 2023-09-11 19:10:49 --> Language Class Initialized
INFO - 2023-09-11 19:10:49 --> Loader Class Initialized
INFO - 2023-09-11 19:10:49 --> Helper loaded: url_helper
INFO - 2023-09-11 19:10:49 --> Helper loaded: file_helper
INFO - 2023-09-11 19:10:49 --> Database Driver Class Initialized
INFO - 2023-09-11 19:10:49 --> Email Class Initialized
DEBUG - 2023-09-11 19:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:10:49 --> Controller Class Initialized
INFO - 2023-09-11 19:10:49 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:10:49 --> Helper loaded: form_helper
INFO - 2023-09-11 19:10:49 --> Form Validation Class Initialized
INFO - 2023-09-11 19:10:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:10:49 --> Final output sent to browser
DEBUG - 2023-09-11 19:10:49 --> Total execution time: 0.3343
INFO - 2023-09-11 19:10:51 --> Config Class Initialized
INFO - 2023-09-11 19:10:51 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:10:51 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:10:51 --> Utf8 Class Initialized
INFO - 2023-09-11 19:10:51 --> URI Class Initialized
INFO - 2023-09-11 19:10:51 --> Router Class Initialized
INFO - 2023-09-11 19:10:51 --> Output Class Initialized
INFO - 2023-09-11 19:10:51 --> Security Class Initialized
DEBUG - 2023-09-11 19:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:10:51 --> Input Class Initialized
INFO - 2023-09-11 19:10:51 --> Language Class Initialized
INFO - 2023-09-11 19:10:51 --> Loader Class Initialized
INFO - 2023-09-11 19:10:51 --> Helper loaded: url_helper
INFO - 2023-09-11 19:10:51 --> Helper loaded: file_helper
INFO - 2023-09-11 19:10:51 --> Database Driver Class Initialized
INFO - 2023-09-11 19:10:51 --> Email Class Initialized
DEBUG - 2023-09-11 19:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:10:51 --> Controller Class Initialized
INFO - 2023-09-11 19:10:51 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:10:51 --> Helper loaded: form_helper
INFO - 2023-09-11 19:10:51 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:10:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-09-11 19:10:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:10:51 --> Final output sent to browser
DEBUG - 2023-09-11 19:10:51 --> Total execution time: 0.0520
INFO - 2023-09-11 19:10:59 --> Config Class Initialized
INFO - 2023-09-11 19:10:59 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:10:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:10:59 --> Utf8 Class Initialized
INFO - 2023-09-11 19:10:59 --> URI Class Initialized
INFO - 2023-09-11 19:10:59 --> Router Class Initialized
INFO - 2023-09-11 19:10:59 --> Output Class Initialized
INFO - 2023-09-11 19:11:00 --> Security Class Initialized
DEBUG - 2023-09-11 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:11:00 --> Input Class Initialized
INFO - 2023-09-11 19:11:00 --> Language Class Initialized
INFO - 2023-09-11 19:11:00 --> Loader Class Initialized
INFO - 2023-09-11 19:11:00 --> Helper loaded: url_helper
INFO - 2023-09-11 19:11:00 --> Helper loaded: file_helper
INFO - 2023-09-11 19:11:00 --> Database Driver Class Initialized
INFO - 2023-09-11 19:11:00 --> Email Class Initialized
DEBUG - 2023-09-11 19:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:11:00 --> Controller Class Initialized
INFO - 2023-09-11 19:11:00 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:11:00 --> Helper loaded: form_helper
INFO - 2023-09-11 19:11:00 --> Form Validation Class Initialized
INFO - 2023-09-11 19:11:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:11:00 --> Final output sent to browser
DEBUG - 2023-09-11 19:11:00 --> Total execution time: 0.3498
INFO - 2023-09-11 19:11:01 --> Config Class Initialized
INFO - 2023-09-11 19:11:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:11:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:11:01 --> Utf8 Class Initialized
INFO - 2023-09-11 19:11:01 --> URI Class Initialized
INFO - 2023-09-11 19:11:01 --> Router Class Initialized
INFO - 2023-09-11 19:11:01 --> Output Class Initialized
INFO - 2023-09-11 19:11:01 --> Security Class Initialized
DEBUG - 2023-09-11 19:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:11:01 --> Input Class Initialized
INFO - 2023-09-11 19:11:01 --> Language Class Initialized
ERROR - 2023-09-11 19:11:01 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-11 19:11:04 --> Config Class Initialized
INFO - 2023-09-11 19:11:04 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:11:04 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:11:04 --> Utf8 Class Initialized
INFO - 2023-09-11 19:11:04 --> URI Class Initialized
INFO - 2023-09-11 19:11:04 --> Router Class Initialized
INFO - 2023-09-11 19:11:04 --> Output Class Initialized
INFO - 2023-09-11 19:11:04 --> Security Class Initialized
DEBUG - 2023-09-11 19:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:11:04 --> Input Class Initialized
INFO - 2023-09-11 19:11:04 --> Language Class Initialized
INFO - 2023-09-11 19:11:04 --> Loader Class Initialized
INFO - 2023-09-11 19:11:04 --> Helper loaded: url_helper
INFO - 2023-09-11 19:11:04 --> Helper loaded: file_helper
INFO - 2023-09-11 19:11:04 --> Database Driver Class Initialized
INFO - 2023-09-11 19:11:04 --> Email Class Initialized
DEBUG - 2023-09-11 19:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:11:04 --> Controller Class Initialized
INFO - 2023-09-11 19:11:04 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:11:04 --> Helper loaded: form_helper
INFO - 2023-09-11 19:11:04 --> Form Validation Class Initialized
INFO - 2023-09-11 19:11:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:11:04 --> Final output sent to browser
DEBUG - 2023-09-11 19:11:04 --> Total execution time: 0.0700
INFO - 2023-09-11 19:11:05 --> Config Class Initialized
INFO - 2023-09-11 19:11:05 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:11:05 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:11:05 --> Utf8 Class Initialized
INFO - 2023-09-11 19:11:05 --> URI Class Initialized
INFO - 2023-09-11 19:11:05 --> Router Class Initialized
INFO - 2023-09-11 19:11:05 --> Output Class Initialized
INFO - 2023-09-11 19:11:05 --> Security Class Initialized
DEBUG - 2023-09-11 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:11:05 --> Input Class Initialized
INFO - 2023-09-11 19:11:05 --> Language Class Initialized
INFO - 2023-09-11 19:11:05 --> Loader Class Initialized
INFO - 2023-09-11 19:11:05 --> Helper loaded: url_helper
INFO - 2023-09-11 19:11:05 --> Helper loaded: file_helper
INFO - 2023-09-11 19:11:05 --> Database Driver Class Initialized
INFO - 2023-09-11 19:11:05 --> Email Class Initialized
DEBUG - 2023-09-11 19:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:11:05 --> Controller Class Initialized
INFO - 2023-09-11 19:11:05 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:11:05 --> Helper loaded: form_helper
INFO - 2023-09-11 19:11:05 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:11:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 106
INFO - 2023-09-11 19:11:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:11:05 --> Final output sent to browser
DEBUG - 2023-09-11 19:11:05 --> Total execution time: 0.0584
INFO - 2023-09-11 19:17:12 --> Config Class Initialized
INFO - 2023-09-11 19:17:12 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:12 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:12 --> URI Class Initialized
INFO - 2023-09-11 19:17:12 --> Router Class Initialized
INFO - 2023-09-11 19:17:12 --> Output Class Initialized
INFO - 2023-09-11 19:17:12 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:12 --> Input Class Initialized
INFO - 2023-09-11 19:17:12 --> Language Class Initialized
INFO - 2023-09-11 19:17:12 --> Loader Class Initialized
INFO - 2023-09-11 19:17:12 --> Helper loaded: url_helper
INFO - 2023-09-11 19:17:12 --> Helper loaded: file_helper
INFO - 2023-09-11 19:17:12 --> Database Driver Class Initialized
INFO - 2023-09-11 19:17:12 --> Email Class Initialized
DEBUG - 2023-09-11 19:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:17:12 --> Controller Class Initialized
INFO - 2023-09-11 19:17:12 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:17:12 --> Helper loaded: form_helper
INFO - 2023-09-11 19:17:12 --> Form Validation Class Initialized
INFO - 2023-09-11 19:17:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:17:12 --> Final output sent to browser
DEBUG - 2023-09-11 19:17:12 --> Total execution time: 0.2785
INFO - 2023-09-11 19:17:13 --> Config Class Initialized
INFO - 2023-09-11 19:17:13 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:13 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:13 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:13 --> URI Class Initialized
INFO - 2023-09-11 19:17:13 --> Router Class Initialized
INFO - 2023-09-11 19:17:13 --> Output Class Initialized
INFO - 2023-09-11 19:17:13 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:13 --> Input Class Initialized
INFO - 2023-09-11 19:17:13 --> Language Class Initialized
INFO - 2023-09-11 19:17:13 --> Loader Class Initialized
INFO - 2023-09-11 19:17:13 --> Helper loaded: url_helper
INFO - 2023-09-11 19:17:13 --> Helper loaded: file_helper
INFO - 2023-09-11 19:17:13 --> Database Driver Class Initialized
INFO - 2023-09-11 19:17:13 --> Email Class Initialized
DEBUG - 2023-09-11 19:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:17:13 --> Controller Class Initialized
INFO - 2023-09-11 19:17:13 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:17:13 --> Helper loaded: form_helper
INFO - 2023-09-11 19:17:13 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-09-11 19:17:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-09-11 19:17:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:17:13 --> Final output sent to browser
DEBUG - 2023-09-11 19:17:13 --> Total execution time: 0.0580
INFO - 2023-09-11 19:17:21 --> Config Class Initialized
INFO - 2023-09-11 19:17:21 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:21 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:22 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:22 --> URI Class Initialized
INFO - 2023-09-11 19:17:22 --> Router Class Initialized
INFO - 2023-09-11 19:17:22 --> Output Class Initialized
INFO - 2023-09-11 19:17:22 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:22 --> Input Class Initialized
INFO - 2023-09-11 19:17:22 --> Language Class Initialized
INFO - 2023-09-11 19:17:22 --> Loader Class Initialized
INFO - 2023-09-11 19:17:22 --> Helper loaded: url_helper
INFO - 2023-09-11 19:17:22 --> Helper loaded: file_helper
INFO - 2023-09-11 19:17:22 --> Database Driver Class Initialized
INFO - 2023-09-11 19:17:22 --> Email Class Initialized
DEBUG - 2023-09-11 19:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:17:22 --> Controller Class Initialized
INFO - 2023-09-11 19:17:22 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:17:22 --> Helper loaded: form_helper
INFO - 2023-09-11 19:17:22 --> Form Validation Class Initialized
INFO - 2023-09-11 19:17:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:17:22 --> Final output sent to browser
DEBUG - 2023-09-11 19:17:22 --> Total execution time: 0.2706
INFO - 2023-09-11 19:17:23 --> Config Class Initialized
INFO - 2023-09-11 19:17:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:23 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:23 --> URI Class Initialized
INFO - 2023-09-11 19:17:23 --> Router Class Initialized
INFO - 2023-09-11 19:17:23 --> Output Class Initialized
INFO - 2023-09-11 19:17:23 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:23 --> Input Class Initialized
INFO - 2023-09-11 19:17:23 --> Language Class Initialized
ERROR - 2023-09-11 19:17:23 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-11 19:17:24 --> Config Class Initialized
INFO - 2023-09-11 19:17:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:24 --> URI Class Initialized
INFO - 2023-09-11 19:17:24 --> Router Class Initialized
INFO - 2023-09-11 19:17:24 --> Output Class Initialized
INFO - 2023-09-11 19:17:24 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:24 --> Input Class Initialized
INFO - 2023-09-11 19:17:24 --> Language Class Initialized
INFO - 2023-09-11 19:17:24 --> Loader Class Initialized
INFO - 2023-09-11 19:17:24 --> Helper loaded: url_helper
INFO - 2023-09-11 19:17:24 --> Helper loaded: file_helper
INFO - 2023-09-11 19:17:24 --> Database Driver Class Initialized
INFO - 2023-09-11 19:17:24 --> Email Class Initialized
DEBUG - 2023-09-11 19:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:17:24 --> Controller Class Initialized
INFO - 2023-09-11 19:17:24 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:17:24 --> Helper loaded: form_helper
INFO - 2023-09-11 19:17:24 --> Form Validation Class Initialized
INFO - 2023-09-11 19:17:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:17:24 --> Final output sent to browser
DEBUG - 2023-09-11 19:17:24 --> Total execution time: 0.0480
INFO - 2023-09-11 19:17:24 --> Config Class Initialized
INFO - 2023-09-11 19:17:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:17:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:17:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:17:24 --> URI Class Initialized
INFO - 2023-09-11 19:17:24 --> Router Class Initialized
INFO - 2023-09-11 19:17:24 --> Output Class Initialized
INFO - 2023-09-11 19:17:24 --> Security Class Initialized
DEBUG - 2023-09-11 19:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:17:24 --> Input Class Initialized
INFO - 2023-09-11 19:17:24 --> Language Class Initialized
INFO - 2023-09-11 19:17:24 --> Loader Class Initialized
INFO - 2023-09-11 19:17:24 --> Helper loaded: url_helper
INFO - 2023-09-11 19:17:24 --> Helper loaded: file_helper
INFO - 2023-09-11 19:17:24 --> Database Driver Class Initialized
INFO - 2023-09-11 19:17:24 --> Email Class Initialized
DEBUG - 2023-09-11 19:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:17:24 --> Controller Class Initialized
INFO - 2023-09-11 19:17:24 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:17:24 --> Helper loaded: form_helper
INFO - 2023-09-11 19:17:24 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-09-11 19:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-09-11 19:17:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:17:24 --> Final output sent to browser
DEBUG - 2023-09-11 19:17:24 --> Total execution time: 0.0525
INFO - 2023-09-11 19:20:13 --> Config Class Initialized
INFO - 2023-09-11 19:20:13 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:13 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:13 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:13 --> URI Class Initialized
INFO - 2023-09-11 19:20:13 --> Router Class Initialized
INFO - 2023-09-11 19:20:13 --> Output Class Initialized
INFO - 2023-09-11 19:20:13 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:13 --> Input Class Initialized
INFO - 2023-09-11 19:20:13 --> Language Class Initialized
INFO - 2023-09-11 19:20:13 --> Loader Class Initialized
INFO - 2023-09-11 19:20:13 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:13 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:13 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:13 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:13 --> Controller Class Initialized
INFO - 2023-09-11 19:20:13 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:13 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:13 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-11 19:20:13 --> Config Class Initialized
INFO - 2023-09-11 19:20:13 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:13 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:13 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:13 --> URI Class Initialized
INFO - 2023-09-11 19:20:13 --> Router Class Initialized
INFO - 2023-09-11 19:20:13 --> Output Class Initialized
INFO - 2023-09-11 19:20:13 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:13 --> Input Class Initialized
INFO - 2023-09-11 19:20:13 --> Language Class Initialized
INFO - 2023-09-11 19:20:13 --> Loader Class Initialized
INFO - 2023-09-11 19:20:13 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:13 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:13 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:13 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:13 --> Controller Class Initialized
INFO - 2023-09-11 19:20:13 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:13 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:13 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:20:13 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:13 --> Total execution time: 0.0936
INFO - 2023-09-11 19:20:16 --> Config Class Initialized
INFO - 2023-09-11 19:20:16 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:16 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:16 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:16 --> URI Class Initialized
INFO - 2023-09-11 19:20:16 --> Router Class Initialized
INFO - 2023-09-11 19:20:16 --> Output Class Initialized
INFO - 2023-09-11 19:20:16 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:16 --> Input Class Initialized
INFO - 2023-09-11 19:20:16 --> Language Class Initialized
INFO - 2023-09-11 19:20:16 --> Loader Class Initialized
INFO - 2023-09-11 19:20:16 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:16 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:16 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:16 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:16 --> Controller Class Initialized
INFO - 2023-09-11 19:20:16 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:16 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:16 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:20:16 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:16 --> Total execution time: 0.0488
INFO - 2023-09-11 19:20:17 --> Config Class Initialized
INFO - 2023-09-11 19:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:17 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:17 --> URI Class Initialized
INFO - 2023-09-11 19:20:17 --> Router Class Initialized
INFO - 2023-09-11 19:20:17 --> Output Class Initialized
INFO - 2023-09-11 19:20:17 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:17 --> Input Class Initialized
INFO - 2023-09-11 19:20:17 --> Language Class Initialized
INFO - 2023-09-11 19:20:17 --> Loader Class Initialized
INFO - 2023-09-11 19:20:17 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:17 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:17 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:17 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:17 --> Controller Class Initialized
INFO - 2023-09-11 19:20:17 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:17 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:17 --> Form Validation Class Initialized
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-09-11 19:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-09-11 19:20:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-11 19:20:17 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:17 --> Total execution time: 0.0481
INFO - 2023-09-11 19:20:27 --> Config Class Initialized
INFO - 2023-09-11 19:20:27 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:27 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:27 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:27 --> URI Class Initialized
INFO - 2023-09-11 19:20:27 --> Router Class Initialized
INFO - 2023-09-11 19:20:27 --> Output Class Initialized
INFO - 2023-09-11 19:20:27 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:27 --> Input Class Initialized
INFO - 2023-09-11 19:20:27 --> Language Class Initialized
INFO - 2023-09-11 19:20:27 --> Loader Class Initialized
INFO - 2023-09-11 19:20:27 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:27 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:27 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:27 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:27 --> Controller Class Initialized
INFO - 2023-09-11 19:20:27 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:27 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:27 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:20:27 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:27 --> Total execution time: 0.3099
INFO - 2023-09-11 19:20:34 --> Config Class Initialized
INFO - 2023-09-11 19:20:34 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:34 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:34 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:34 --> URI Class Initialized
INFO - 2023-09-11 19:20:34 --> Router Class Initialized
INFO - 2023-09-11 19:20:34 --> Output Class Initialized
INFO - 2023-09-11 19:20:34 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:34 --> Input Class Initialized
INFO - 2023-09-11 19:20:34 --> Language Class Initialized
INFO - 2023-09-11 19:20:34 --> Loader Class Initialized
INFO - 2023-09-11 19:20:34 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:34 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:34 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:34 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:34 --> Controller Class Initialized
INFO - 2023-09-11 19:20:34 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:34 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:34 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:34 --> Config Class Initialized
INFO - 2023-09-11 19:20:34 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:34 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:34 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:34 --> URI Class Initialized
INFO - 2023-09-11 19:20:34 --> Router Class Initialized
INFO - 2023-09-11 19:20:34 --> Output Class Initialized
INFO - 2023-09-11 19:20:34 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:34 --> Input Class Initialized
INFO - 2023-09-11 19:20:34 --> Language Class Initialized
INFO - 2023-09-11 19:20:34 --> Loader Class Initialized
INFO - 2023-09-11 19:20:34 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:34 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:34 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:34 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:34 --> Controller Class Initialized
INFO - 2023-09-11 19:20:34 --> Model "Blog_model" initialized
INFO - 2023-09-11 19:20:34 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:34 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-11 19:20:34 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:34 --> Total execution time: 0.0461
INFO - 2023-09-11 19:20:38 --> Config Class Initialized
INFO - 2023-09-11 19:20:38 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:20:38 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:20:38 --> Utf8 Class Initialized
INFO - 2023-09-11 19:20:38 --> URI Class Initialized
INFO - 2023-09-11 19:20:38 --> Router Class Initialized
INFO - 2023-09-11 19:20:38 --> Output Class Initialized
INFO - 2023-09-11 19:20:38 --> Security Class Initialized
DEBUG - 2023-09-11 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:20:38 --> Input Class Initialized
INFO - 2023-09-11 19:20:38 --> Language Class Initialized
INFO - 2023-09-11 19:20:38 --> Loader Class Initialized
INFO - 2023-09-11 19:20:38 --> Helper loaded: url_helper
INFO - 2023-09-11 19:20:38 --> Helper loaded: file_helper
INFO - 2023-09-11 19:20:38 --> Database Driver Class Initialized
INFO - 2023-09-11 19:20:38 --> Email Class Initialized
DEBUG - 2023-09-11 19:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:20:38 --> Controller Class Initialized
INFO - 2023-09-11 19:20:38 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:20:38 --> Model "Home_model" initialized
INFO - 2023-09-11 19:20:38 --> Helper loaded: download_helper
INFO - 2023-09-11 19:20:38 --> Helper loaded: form_helper
INFO - 2023-09-11 19:20:38 --> Form Validation Class Initialized
INFO - 2023-09-11 19:20:38 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:20:38 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:20:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:20:38 --> Final output sent to browser
DEBUG - 2023-09-11 19:20:38 --> Total execution time: 0.0538
INFO - 2023-09-11 19:21:17 --> Config Class Initialized
INFO - 2023-09-11 19:21:17 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:21:17 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:21:17 --> Utf8 Class Initialized
INFO - 2023-09-11 19:21:17 --> URI Class Initialized
INFO - 2023-09-11 19:21:17 --> Router Class Initialized
INFO - 2023-09-11 19:21:17 --> Output Class Initialized
INFO - 2023-09-11 19:21:17 --> Security Class Initialized
DEBUG - 2023-09-11 19:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:21:17 --> Input Class Initialized
INFO - 2023-09-11 19:21:17 --> Language Class Initialized
INFO - 2023-09-11 19:21:17 --> Loader Class Initialized
INFO - 2023-09-11 19:21:17 --> Helper loaded: url_helper
INFO - 2023-09-11 19:21:17 --> Helper loaded: file_helper
INFO - 2023-09-11 19:21:17 --> Database Driver Class Initialized
INFO - 2023-09-11 19:21:17 --> Email Class Initialized
DEBUG - 2023-09-11 19:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:21:17 --> Controller Class Initialized
INFO - 2023-09-11 19:21:17 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:21:17 --> Model "Home_model" initialized
INFO - 2023-09-11 19:21:17 --> Helper loaded: download_helper
INFO - 2023-09-11 19:21:17 --> Helper loaded: form_helper
INFO - 2023-09-11 19:21:17 --> Form Validation Class Initialized
INFO - 2023-09-11 19:21:17 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:21:17 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:21:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-11 19:21:17 --> Final output sent to browser
DEBUG - 2023-09-11 19:21:17 --> Total execution time: 0.3486
INFO - 2023-09-11 19:21:24 --> Config Class Initialized
INFO - 2023-09-11 19:21:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:21:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:21:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:21:24 --> URI Class Initialized
INFO - 2023-09-11 19:21:24 --> Router Class Initialized
INFO - 2023-09-11 19:21:24 --> Output Class Initialized
INFO - 2023-09-11 19:21:24 --> Security Class Initialized
DEBUG - 2023-09-11 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:21:24 --> Input Class Initialized
INFO - 2023-09-11 19:21:24 --> Language Class Initialized
INFO - 2023-09-11 19:21:24 --> Loader Class Initialized
INFO - 2023-09-11 19:21:24 --> Helper loaded: url_helper
INFO - 2023-09-11 19:21:24 --> Helper loaded: file_helper
INFO - 2023-09-11 19:21:24 --> Database Driver Class Initialized
INFO - 2023-09-11 19:21:24 --> Email Class Initialized
DEBUG - 2023-09-11 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:21:24 --> Controller Class Initialized
INFO - 2023-09-11 19:21:24 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:21:24 --> Model "Home_model" initialized
INFO - 2023-09-11 19:21:24 --> Helper loaded: download_helper
INFO - 2023-09-11 19:21:24 --> Helper loaded: form_helper
INFO - 2023-09-11 19:21:24 --> Form Validation Class Initialized
INFO - 2023-09-11 19:21:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:21:24 --> Final output sent to browser
DEBUG - 2023-09-11 19:21:24 --> Total execution time: 0.0499
INFO - 2023-09-11 19:24:41 --> Config Class Initialized
INFO - 2023-09-11 19:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:41 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:41 --> URI Class Initialized
INFO - 2023-09-11 19:24:41 --> Router Class Initialized
INFO - 2023-09-11 19:24:41 --> Output Class Initialized
INFO - 2023-09-11 19:24:41 --> Security Class Initialized
DEBUG - 2023-09-11 19:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:41 --> Input Class Initialized
INFO - 2023-09-11 19:24:41 --> Language Class Initialized
INFO - 2023-09-11 19:24:41 --> Loader Class Initialized
INFO - 2023-09-11 19:24:41 --> Helper loaded: url_helper
INFO - 2023-09-11 19:24:41 --> Helper loaded: file_helper
INFO - 2023-09-11 19:24:41 --> Database Driver Class Initialized
INFO - 2023-09-11 19:24:41 --> Email Class Initialized
DEBUG - 2023-09-11 19:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:24:41 --> Controller Class Initialized
INFO - 2023-09-11 19:24:41 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:24:41 --> Model "Home_model" initialized
INFO - 2023-09-11 19:24:41 --> Helper loaded: download_helper
INFO - 2023-09-11 19:24:41 --> Helper loaded: form_helper
INFO - 2023-09-11 19:24:41 --> Form Validation Class Initialized
INFO - 2023-09-11 19:24:41 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:24:41 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:24:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:24:41 --> Final output sent to browser
DEBUG - 2023-09-11 19:24:41 --> Total execution time: 0.2651
INFO - 2023-09-11 19:24:42 --> Config Class Initialized
INFO - 2023-09-11 19:24:42 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:24:42 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:42 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:42 --> URI Class Initialized
INFO - 2023-09-11 19:24:42 --> Router Class Initialized
INFO - 2023-09-11 19:24:42 --> Output Class Initialized
INFO - 2023-09-11 19:24:42 --> Security Class Initialized
DEBUG - 2023-09-11 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:42 --> Input Class Initialized
INFO - 2023-09-11 19:24:42 --> Language Class Initialized
ERROR - 2023-09-11 19:24:42 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:24:42 --> Config Class Initialized
INFO - 2023-09-11 19:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:43 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:43 --> URI Class Initialized
INFO - 2023-09-11 19:24:43 --> Router Class Initialized
INFO - 2023-09-11 19:24:43 --> Output Class Initialized
INFO - 2023-09-11 19:24:43 --> Security Class Initialized
DEBUG - 2023-09-11 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:43 --> Input Class Initialized
INFO - 2023-09-11 19:24:43 --> Language Class Initialized
ERROR - 2023-09-11 19:24:43 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:24:43 --> Config Class Initialized
INFO - 2023-09-11 19:24:43 --> Config Class Initialized
INFO - 2023-09-11 19:24:43 --> Config Class Initialized
INFO - 2023-09-11 19:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:43 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:43 --> URI Class Initialized
INFO - 2023-09-11 19:24:43 --> Router Class Initialized
INFO - 2023-09-11 19:24:43 --> Output Class Initialized
INFO - 2023-09-11 19:24:43 --> Security Class Initialized
DEBUG - 2023-09-11 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:43 --> Input Class Initialized
INFO - 2023-09-11 19:24:43 --> Language Class Initialized
ERROR - 2023-09-11 19:24:43 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:24:43 --> Hooks Class Initialized
INFO - 2023-09-11 19:24:43 --> Config Class Initialized
DEBUG - 2023-09-11 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:43 --> Hooks Class Initialized
INFO - 2023-09-11 19:24:43 --> Hooks Class Initialized
INFO - 2023-09-11 19:24:43 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:24:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 19:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:24:43 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:43 --> URI Class Initialized
INFO - 2023-09-11 19:24:43 --> URI Class Initialized
INFO - 2023-09-11 19:24:43 --> Utf8 Class Initialized
INFO - 2023-09-11 19:24:43 --> Router Class Initialized
INFO - 2023-09-11 19:24:43 --> Router Class Initialized
INFO - 2023-09-11 19:24:43 --> Output Class Initialized
INFO - 2023-09-11 19:24:44 --> Output Class Initialized
INFO - 2023-09-11 19:24:44 --> URI Class Initialized
INFO - 2023-09-11 19:24:44 --> Router Class Initialized
INFO - 2023-09-11 19:24:44 --> Security Class Initialized
INFO - 2023-09-11 19:24:44 --> Output Class Initialized
DEBUG - 2023-09-11 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:44 --> Security Class Initialized
DEBUG - 2023-09-11 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:44 --> Input Class Initialized
INFO - 2023-09-11 19:24:44 --> Input Class Initialized
INFO - 2023-09-11 19:24:44 --> Language Class Initialized
INFO - 2023-09-11 19:24:44 --> Security Class Initialized
ERROR - 2023-09-11 19:24:44 --> 404 Page Not Found: Blog-detail/assets
DEBUG - 2023-09-11 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:24:44 --> Language Class Initialized
ERROR - 2023-09-11 19:24:44 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:24:44 --> Input Class Initialized
INFO - 2023-09-11 19:24:44 --> Language Class Initialized
ERROR - 2023-09-11 19:24:44 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:26:46 --> Config Class Initialized
INFO - 2023-09-11 19:26:47 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:26:47 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:47 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:47 --> URI Class Initialized
INFO - 2023-09-11 19:26:47 --> Router Class Initialized
INFO - 2023-09-11 19:26:47 --> Output Class Initialized
INFO - 2023-09-11 19:26:47 --> Security Class Initialized
DEBUG - 2023-09-11 19:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:47 --> Input Class Initialized
INFO - 2023-09-11 19:26:47 --> Language Class Initialized
INFO - 2023-09-11 19:26:47 --> Loader Class Initialized
INFO - 2023-09-11 19:26:47 --> Helper loaded: url_helper
INFO - 2023-09-11 19:26:47 --> Helper loaded: file_helper
INFO - 2023-09-11 19:26:47 --> Database Driver Class Initialized
INFO - 2023-09-11 19:26:47 --> Email Class Initialized
DEBUG - 2023-09-11 19:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:26:47 --> Controller Class Initialized
INFO - 2023-09-11 19:26:47 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:26:47 --> Model "Home_model" initialized
INFO - 2023-09-11 19:26:47 --> Helper loaded: download_helper
INFO - 2023-09-11 19:26:47 --> Helper loaded: form_helper
INFO - 2023-09-11 19:26:47 --> Form Validation Class Initialized
INFO - 2023-09-11 19:26:47 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:26:47 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:26:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:26:47 --> Final output sent to browser
DEBUG - 2023-09-11 19:26:47 --> Total execution time: 0.3722
INFO - 2023-09-11 19:26:48 --> Config Class Initialized
INFO - 2023-09-11 19:26:48 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:26:48 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:48 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:48 --> URI Class Initialized
INFO - 2023-09-11 19:26:48 --> Router Class Initialized
INFO - 2023-09-11 19:26:48 --> Output Class Initialized
INFO - 2023-09-11 19:26:48 --> Security Class Initialized
DEBUG - 2023-09-11 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:48 --> Input Class Initialized
INFO - 2023-09-11 19:26:48 --> Language Class Initialized
ERROR - 2023-09-11 19:26:48 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:26:48 --> Config Class Initialized
INFO - 2023-09-11 19:26:49 --> Config Class Initialized
INFO - 2023-09-11 19:26:49 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:49 --> Hooks Class Initialized
INFO - 2023-09-11 19:26:49 --> Config Class Initialized
INFO - 2023-09-11 19:26:49 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:49 --> Config Class Initialized
INFO - 2023-09-11 19:26:49 --> Hooks Class Initialized
INFO - 2023-09-11 19:26:49 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:49 --> URI Class Initialized
DEBUG - 2023-09-11 19:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:49 --> Hooks Class Initialized
INFO - 2023-09-11 19:26:49 --> Config Class Initialized
INFO - 2023-09-11 19:26:49 --> URI Class Initialized
INFO - 2023-09-11 19:26:49 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:49 --> Router Class Initialized
DEBUG - 2023-09-11 19:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:49 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:49 --> URI Class Initialized
INFO - 2023-09-11 19:26:49 --> Router Class Initialized
INFO - 2023-09-11 19:26:49 --> Output Class Initialized
INFO - 2023-09-11 19:26:49 --> Security Class Initialized
DEBUG - 2023-09-11 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:49 --> Input Class Initialized
INFO - 2023-09-11 19:26:49 --> Language Class Initialized
ERROR - 2023-09-11 19:26:49 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:26:49 --> URI Class Initialized
INFO - 2023-09-11 19:26:49 --> Router Class Initialized
INFO - 2023-09-11 19:26:49 --> Router Class Initialized
INFO - 2023-09-11 19:26:49 --> Hooks Class Initialized
INFO - 2023-09-11 19:26:49 --> Output Class Initialized
DEBUG - 2023-09-11 19:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:26:49 --> Output Class Initialized
INFO - 2023-09-11 19:26:49 --> Security Class Initialized
INFO - 2023-09-11 19:26:49 --> Security Class Initialized
DEBUG - 2023-09-11 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:49 --> Output Class Initialized
INFO - 2023-09-11 19:26:49 --> Input Class Initialized
INFO - 2023-09-11 19:26:49 --> Language Class Initialized
DEBUG - 2023-09-11 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:49 --> Utf8 Class Initialized
INFO - 2023-09-11 19:26:49 --> Input Class Initialized
INFO - 2023-09-11 19:26:49 --> URI Class Initialized
INFO - 2023-09-11 19:26:49 --> Router Class Initialized
ERROR - 2023-09-11 19:26:49 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:26:49 --> Security Class Initialized
INFO - 2023-09-11 19:26:49 --> Language Class Initialized
DEBUG - 2023-09-11 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:49 --> Output Class Initialized
INFO - 2023-09-11 19:26:49 --> Input Class Initialized
INFO - 2023-09-11 19:26:49 --> Security Class Initialized
INFO - 2023-09-11 19:26:49 --> Language Class Initialized
ERROR - 2023-09-11 19:26:49 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:26:49 --> 404 Page Not Found: Blog-detail/assets
DEBUG - 2023-09-11 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:26:49 --> Input Class Initialized
INFO - 2023-09-11 19:29:44 --> Config Class Initialized
INFO - 2023-09-11 19:29:44 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:29:44 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:44 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:44 --> URI Class Initialized
INFO - 2023-09-11 19:29:44 --> Router Class Initialized
INFO - 2023-09-11 19:29:44 --> Output Class Initialized
INFO - 2023-09-11 19:29:44 --> Security Class Initialized
DEBUG - 2023-09-11 19:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:44 --> Input Class Initialized
INFO - 2023-09-11 19:29:44 --> Language Class Initialized
INFO - 2023-09-11 19:29:44 --> Loader Class Initialized
INFO - 2023-09-11 19:29:44 --> Helper loaded: url_helper
INFO - 2023-09-11 19:29:44 --> Helper loaded: file_helper
INFO - 2023-09-11 19:29:44 --> Database Driver Class Initialized
INFO - 2023-09-11 19:29:44 --> Email Class Initialized
DEBUG - 2023-09-11 19:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:29:44 --> Controller Class Initialized
INFO - 2023-09-11 19:29:44 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:29:44 --> Model "Home_model" initialized
INFO - 2023-09-11 19:29:44 --> Helper loaded: download_helper
INFO - 2023-09-11 19:29:44 --> Helper loaded: form_helper
INFO - 2023-09-11 19:29:44 --> Form Validation Class Initialized
INFO - 2023-09-11 19:29:44 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:29:44 --> Model "Social_media_model" initialized
ERROR - 2023-09-11 19:29:44 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\dw\application\views\home\blog_detail.php 67
INFO - 2023-09-11 19:29:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:29:44 --> Final output sent to browser
DEBUG - 2023-09-11 19:29:44 --> Total execution time: 0.4939
INFO - 2023-09-11 19:29:45 --> Config Class Initialized
INFO - 2023-09-11 19:29:45 --> Hooks Class Initialized
INFO - 2023-09-11 19:29:46 --> Config Class Initialized
INFO - 2023-09-11 19:29:46 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:29:46 --> Config Class Initialized
INFO - 2023-09-11 19:29:46 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
INFO - 2023-09-11 19:29:46 --> Config Class Initialized
INFO - 2023-09-11 19:29:46 --> Config Class Initialized
INFO - 2023-09-11 19:29:46 --> Config Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Hooks Class Initialized
INFO - 2023-09-11 19:29:46 --> Hooks Class Initialized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
INFO - 2023-09-11 19:29:46 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 19:29:46 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:46 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
INFO - 2023-09-11 19:29:46 --> URI Class Initialized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
INFO - 2023-09-11 19:29:46 --> Router Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
INFO - 2023-09-11 19:29:46 --> Output Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Security Class Initialized
DEBUG - 2023-09-11 19:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
INFO - 2023-09-11 19:29:46 --> Input Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
INFO - 2023-09-11 19:29:46 --> Language Class Initialized
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:29:46 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:29:59 --> Config Class Initialized
INFO - 2023-09-11 19:29:59 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:29:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:29:59 --> Utf8 Class Initialized
INFO - 2023-09-11 19:29:59 --> URI Class Initialized
INFO - 2023-09-11 19:29:59 --> Router Class Initialized
INFO - 2023-09-11 19:29:59 --> Output Class Initialized
INFO - 2023-09-11 19:29:59 --> Security Class Initialized
DEBUG - 2023-09-11 19:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:29:59 --> Input Class Initialized
INFO - 2023-09-11 19:29:59 --> Language Class Initialized
INFO - 2023-09-11 19:29:59 --> Loader Class Initialized
INFO - 2023-09-11 19:29:59 --> Helper loaded: url_helper
INFO - 2023-09-11 19:29:59 --> Helper loaded: file_helper
INFO - 2023-09-11 19:29:59 --> Database Driver Class Initialized
INFO - 2023-09-11 19:29:59 --> Email Class Initialized
DEBUG - 2023-09-11 19:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:29:59 --> Controller Class Initialized
INFO - 2023-09-11 19:29:59 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:29:59 --> Model "Home_model" initialized
INFO - 2023-09-11 19:29:59 --> Helper loaded: download_helper
INFO - 2023-09-11 19:29:59 --> Helper loaded: form_helper
INFO - 2023-09-11 19:29:59 --> Form Validation Class Initialized
INFO - 2023-09-11 19:29:59 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:29:59 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:29:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:29:59 --> Final output sent to browser
DEBUG - 2023-09-11 19:29:59 --> Total execution time: 0.3774
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
INFO - 2023-09-11 19:30:00 --> Router Class Initialized
INFO - 2023-09-11 19:30:00 --> Output Class Initialized
INFO - 2023-09-11 19:30:00 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:00 --> Input Class Initialized
INFO - 2023-09-11 19:30:00 --> Language Class Initialized
ERROR - 2023-09-11 19:30:00 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
INFO - 2023-09-11 19:30:00 --> Router Class Initialized
INFO - 2023-09-11 19:30:00 --> Output Class Initialized
INFO - 2023-09-11 19:30:00 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:00 --> Input Class Initialized
INFO - 2023-09-11 19:30:00 --> Language Class Initialized
ERROR - 2023-09-11 19:30:00 --> 404 Page Not Found: Blog-detail/assets
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Config Class Initialized
INFO - 2023-09-11 19:30:00 --> Router Class Initialized
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
INFO - 2023-09-11 19:30:00 --> Router Class Initialized
INFO - 2023-09-11 19:30:00 --> Output Class Initialized
INFO - 2023-09-11 19:30:00 --> Output Class Initialized
INFO - 2023-09-11 19:30:00 --> Security Class Initialized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
DEBUG - 2023-09-11 19:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:00 --> Security Class Initialized
INFO - 2023-09-11 19:30:00 --> Router Class Initialized
INFO - 2023-09-11 19:30:00 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:00 --> URI Class Initialized
INFO - 2023-09-11 19:30:00 --> Input Class Initialized
INFO - 2023-09-11 19:30:01 --> Router Class Initialized
INFO - 2023-09-11 19:30:01 --> Language Class Initialized
DEBUG - 2023-09-11 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:01 --> Output Class Initialized
INFO - 2023-09-11 19:30:01 --> Output Class Initialized
INFO - 2023-09-11 19:30:01 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-11 19:30:01 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:01 --> Security Class Initialized
INFO - 2023-09-11 19:30:01 --> Input Class Initialized
DEBUG - 2023-09-11 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:01 --> Language Class Initialized
INFO - 2023-09-11 19:30:01 --> Input Class Initialized
INFO - 2023-09-11 19:30:01 --> Language Class Initialized
ERROR - 2023-09-11 19:30:01 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:01 --> Input Class Initialized
INFO - 2023-09-11 19:30:01 --> Language Class Initialized
ERROR - 2023-09-11 19:30:01 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:30:01 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:22 --> Config Class Initialized
INFO - 2023-09-11 19:30:22 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:30:22 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:22 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:22 --> URI Class Initialized
INFO - 2023-09-11 19:30:22 --> Router Class Initialized
INFO - 2023-09-11 19:30:22 --> Output Class Initialized
INFO - 2023-09-11 19:30:22 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:22 --> Input Class Initialized
INFO - 2023-09-11 19:30:22 --> Language Class Initialized
INFO - 2023-09-11 19:30:22 --> Loader Class Initialized
INFO - 2023-09-11 19:30:22 --> Helper loaded: url_helper
INFO - 2023-09-11 19:30:22 --> Helper loaded: file_helper
INFO - 2023-09-11 19:30:22 --> Database Driver Class Initialized
INFO - 2023-09-11 19:30:22 --> Email Class Initialized
DEBUG - 2023-09-11 19:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:30:22 --> Controller Class Initialized
INFO - 2023-09-11 19:30:22 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:30:22 --> Model "Home_model" initialized
INFO - 2023-09-11 19:30:22 --> Helper loaded: download_helper
INFO - 2023-09-11 19:30:22 --> Helper loaded: form_helper
INFO - 2023-09-11 19:30:22 --> Form Validation Class Initialized
INFO - 2023-09-11 19:30:22 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:30:22 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:30:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:30:22 --> Final output sent to browser
DEBUG - 2023-09-11 19:30:23 --> Total execution time: 0.5789
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
INFO - 2023-09-11 19:30:24 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
INFO - 2023-09-11 19:30:24 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:30:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
DEBUG - 2023-09-11 19:30:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
INFO - 2023-09-11 19:30:24 --> Config Class Initialized
DEBUG - 2023-09-11 19:30:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:24 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> Hooks Class Initialized
INFO - 2023-09-11 19:30:25 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
DEBUG - 2023-09-11 19:30:25 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:25 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
DEBUG - 2023-09-11 19:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 19:30:25 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
INFO - 2023-09-11 19:30:25 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> Utf8 Class Initialized
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
INFO - 2023-09-11 19:30:25 --> URI Class Initialized
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
INFO - 2023-09-11 19:30:25 --> Router Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
INFO - 2023-09-11 19:30:25 --> Output Class Initialized
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:25 --> Security Class Initialized
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
DEBUG - 2023-09-11 19:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:30:25 --> Input Class Initialized
INFO - 2023-09-11 19:30:25 --> Language Class Initialized
ERROR - 2023-09-11 19:30:25 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:08 --> Config Class Initialized
INFO - 2023-09-11 19:31:08 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:08 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:08 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:08 --> URI Class Initialized
INFO - 2023-09-11 19:31:08 --> Router Class Initialized
INFO - 2023-09-11 19:31:08 --> Output Class Initialized
INFO - 2023-09-11 19:31:08 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:08 --> Input Class Initialized
INFO - 2023-09-11 19:31:08 --> Language Class Initialized
INFO - 2023-09-11 19:31:08 --> Loader Class Initialized
INFO - 2023-09-11 19:31:08 --> Helper loaded: url_helper
INFO - 2023-09-11 19:31:08 --> Helper loaded: file_helper
INFO - 2023-09-11 19:31:08 --> Database Driver Class Initialized
INFO - 2023-09-11 19:31:08 --> Email Class Initialized
DEBUG - 2023-09-11 19:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:31:08 --> Controller Class Initialized
INFO - 2023-09-11 19:31:08 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:31:08 --> Model "Home_model" initialized
INFO - 2023-09-11 19:31:08 --> Helper loaded: download_helper
INFO - 2023-09-11 19:31:08 --> Helper loaded: form_helper
INFO - 2023-09-11 19:31:08 --> Form Validation Class Initialized
INFO - 2023-09-11 19:31:08 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:31:08 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:31:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:31:08 --> Final output sent to browser
DEBUG - 2023-09-11 19:31:08 --> Total execution time: 0.4815
INFO - 2023-09-11 19:31:09 --> Config Class Initialized
INFO - 2023-09-11 19:31:09 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:09 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:09 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:09 --> URI Class Initialized
INFO - 2023-09-11 19:31:09 --> Router Class Initialized
INFO - 2023-09-11 19:31:09 --> Output Class Initialized
INFO - 2023-09-11 19:31:09 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:09 --> Input Class Initialized
INFO - 2023-09-11 19:31:09 --> Language Class Initialized
ERROR - 2023-09-11 19:31:09 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:09 --> Config Class Initialized
INFO - 2023-09-11 19:31:09 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:09 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:09 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:09 --> URI Class Initialized
INFO - 2023-09-11 19:31:09 --> Router Class Initialized
INFO - 2023-09-11 19:31:09 --> Output Class Initialized
INFO - 2023-09-11 19:31:09 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:09 --> Input Class Initialized
INFO - 2023-09-11 19:31:09 --> Language Class Initialized
ERROR - 2023-09-11 19:31:09 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:10 --> Config Class Initialized
INFO - 2023-09-11 19:31:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:10 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:10 --> URI Class Initialized
INFO - 2023-09-11 19:31:10 --> Router Class Initialized
INFO - 2023-09-11 19:31:10 --> Output Class Initialized
INFO - 2023-09-11 19:31:10 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:10 --> Input Class Initialized
INFO - 2023-09-11 19:31:10 --> Language Class Initialized
ERROR - 2023-09-11 19:31:10 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:10 --> Config Class Initialized
INFO - 2023-09-11 19:31:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:10 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:10 --> URI Class Initialized
INFO - 2023-09-11 19:31:10 --> Router Class Initialized
INFO - 2023-09-11 19:31:10 --> Output Class Initialized
INFO - 2023-09-11 19:31:10 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:10 --> Input Class Initialized
INFO - 2023-09-11 19:31:10 --> Language Class Initialized
ERROR - 2023-09-11 19:31:10 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:10 --> Config Class Initialized
INFO - 2023-09-11 19:31:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:10 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:10 --> URI Class Initialized
INFO - 2023-09-11 19:31:10 --> Router Class Initialized
INFO - 2023-09-11 19:31:10 --> Output Class Initialized
INFO - 2023-09-11 19:31:10 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:10 --> Input Class Initialized
INFO - 2023-09-11 19:31:10 --> Language Class Initialized
ERROR - 2023-09-11 19:31:10 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:36 --> Config Class Initialized
INFO - 2023-09-11 19:31:36 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:36 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:36 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:36 --> URI Class Initialized
INFO - 2023-09-11 19:31:36 --> Router Class Initialized
INFO - 2023-09-11 19:31:36 --> Output Class Initialized
INFO - 2023-09-11 19:31:36 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:36 --> Input Class Initialized
INFO - 2023-09-11 19:31:36 --> Language Class Initialized
INFO - 2023-09-11 19:31:36 --> Loader Class Initialized
INFO - 2023-09-11 19:31:36 --> Helper loaded: url_helper
INFO - 2023-09-11 19:31:36 --> Helper loaded: file_helper
INFO - 2023-09-11 19:31:36 --> Database Driver Class Initialized
INFO - 2023-09-11 19:31:36 --> Email Class Initialized
DEBUG - 2023-09-11 19:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:31:36 --> Controller Class Initialized
INFO - 2023-09-11 19:31:36 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:31:36 --> Model "Home_model" initialized
INFO - 2023-09-11 19:31:36 --> Helper loaded: download_helper
INFO - 2023-09-11 19:31:36 --> Helper loaded: form_helper
INFO - 2023-09-11 19:31:36 --> Form Validation Class Initialized
INFO - 2023-09-11 19:31:36 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:31:36 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:31:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:31:36 --> Final output sent to browser
DEBUG - 2023-09-11 19:31:36 --> Total execution time: 0.3769
INFO - 2023-09-11 19:31:37 --> Config Class Initialized
INFO - 2023-09-11 19:31:37 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:37 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:37 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:37 --> URI Class Initialized
INFO - 2023-09-11 19:31:37 --> Router Class Initialized
INFO - 2023-09-11 19:31:37 --> Output Class Initialized
INFO - 2023-09-11 19:31:37 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:37 --> Input Class Initialized
INFO - 2023-09-11 19:31:37 --> Language Class Initialized
ERROR - 2023-09-11 19:31:37 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:37 --> Config Class Initialized
INFO - 2023-09-11 19:31:37 --> Config Class Initialized
INFO - 2023-09-11 19:31:37 --> Hooks Class Initialized
INFO - 2023-09-11 19:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:38 --> Config Class Initialized
INFO - 2023-09-11 19:31:38 --> Hooks Class Initialized
INFO - 2023-09-11 19:31:38 --> Config Class Initialized
INFO - 2023-09-11 19:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:38 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:38 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:31:38 --> URI Class Initialized
INFO - 2023-09-11 19:31:38 --> Router Class Initialized
INFO - 2023-09-11 19:31:38 --> URI Class Initialized
INFO - 2023-09-11 19:31:38 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:38 --> Output Class Initialized
INFO - 2023-09-11 19:31:38 --> Security Class Initialized
INFO - 2023-09-11 19:31:38 --> Router Class Initialized
INFO - 2023-09-11 19:31:38 --> Utf8 Class Initialized
INFO - 2023-09-11 19:31:38 --> URI Class Initialized
INFO - 2023-09-11 19:31:38 --> URI Class Initialized
DEBUG - 2023-09-11 19:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:38 --> Output Class Initialized
INFO - 2023-09-11 19:31:38 --> Input Class Initialized
INFO - 2023-09-11 19:31:38 --> Security Class Initialized
INFO - 2023-09-11 19:31:38 --> Language Class Initialized
INFO - 2023-09-11 19:31:38 --> Router Class Initialized
DEBUG - 2023-09-11 19:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:38 --> Output Class Initialized
INFO - 2023-09-11 19:31:38 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-11 19:31:38 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:38 --> Input Class Initialized
INFO - 2023-09-11 19:31:38 --> Router Class Initialized
INFO - 2023-09-11 19:31:38 --> Input Class Initialized
INFO - 2023-09-11 19:31:38 --> Language Class Initialized
ERROR - 2023-09-11 19:31:38 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:38 --> Language Class Initialized
ERROR - 2023-09-11 19:31:38 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:31:38 --> Output Class Initialized
INFO - 2023-09-11 19:31:38 --> Security Class Initialized
DEBUG - 2023-09-11 19:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:31:38 --> Input Class Initialized
INFO - 2023-09-11 19:31:38 --> Language Class Initialized
ERROR - 2023-09-11 19:31:38 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:32:57 --> Config Class Initialized
INFO - 2023-09-11 19:32:57 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:32:57 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:32:57 --> Utf8 Class Initialized
INFO - 2023-09-11 19:32:57 --> URI Class Initialized
INFO - 2023-09-11 19:32:57 --> Router Class Initialized
INFO - 2023-09-11 19:32:57 --> Output Class Initialized
INFO - 2023-09-11 19:32:57 --> Security Class Initialized
DEBUG - 2023-09-11 19:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:32:57 --> Input Class Initialized
INFO - 2023-09-11 19:32:57 --> Language Class Initialized
INFO - 2023-09-11 19:32:57 --> Loader Class Initialized
INFO - 2023-09-11 19:32:57 --> Helper loaded: url_helper
INFO - 2023-09-11 19:32:57 --> Helper loaded: file_helper
INFO - 2023-09-11 19:32:57 --> Database Driver Class Initialized
INFO - 2023-09-11 19:32:57 --> Email Class Initialized
DEBUG - 2023-09-11 19:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:32:57 --> Controller Class Initialized
INFO - 2023-09-11 19:32:57 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:32:57 --> Model "Home_model" initialized
INFO - 2023-09-11 19:32:57 --> Helper loaded: download_helper
INFO - 2023-09-11 19:32:57 --> Helper loaded: form_helper
INFO - 2023-09-11 19:32:57 --> Form Validation Class Initialized
INFO - 2023-09-11 19:32:57 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:32:57 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:32:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:32:57 --> Final output sent to browser
DEBUG - 2023-09-11 19:32:57 --> Total execution time: 0.4284
INFO - 2023-09-11 19:32:59 --> Config Class Initialized
INFO - 2023-09-11 19:32:59 --> Hooks Class Initialized
INFO - 2023-09-11 19:32:59 --> Config Class Initialized
INFO - 2023-09-11 19:32:59 --> Config Class Initialized
DEBUG - 2023-09-11 19:32:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:32:59 --> Hooks Class Initialized
INFO - 2023-09-11 19:32:59 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:32:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:32:59 --> Utf8 Class Initialized
INFO - 2023-09-11 19:32:59 --> Utf8 Class Initialized
INFO - 2023-09-11 19:32:59 --> URI Class Initialized
DEBUG - 2023-09-11 19:32:59 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:32:59 --> Utf8 Class Initialized
INFO - 2023-09-11 19:32:59 --> Router Class Initialized
INFO - 2023-09-11 19:32:59 --> URI Class Initialized
INFO - 2023-09-11 19:32:59 --> Output Class Initialized
INFO - 2023-09-11 19:32:59 --> URI Class Initialized
INFO - 2023-09-11 19:32:59 --> Router Class Initialized
INFO - 2023-09-11 19:32:59 --> Security Class Initialized
INFO - 2023-09-11 19:32:59 --> Output Class Initialized
INFO - 2023-09-11 19:32:59 --> Router Class Initialized
INFO - 2023-09-11 19:32:59 --> Security Class Initialized
DEBUG - 2023-09-11 19:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 19:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:32:59 --> Output Class Initialized
INFO - 2023-09-11 19:32:59 --> Input Class Initialized
INFO - 2023-09-11 19:32:59 --> Input Class Initialized
INFO - 2023-09-11 19:32:59 --> Language Class Initialized
INFO - 2023-09-11 19:32:59 --> Language Class Initialized
ERROR - 2023-09-11 19:32:59 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:32:59 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:32:59 --> Security Class Initialized
DEBUG - 2023-09-11 19:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:32:59 --> Input Class Initialized
INFO - 2023-09-11 19:32:59 --> Language Class Initialized
ERROR - 2023-09-11 19:33:00 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:34:33 --> Config Class Initialized
INFO - 2023-09-11 19:34:33 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:34:33 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:34:33 --> Utf8 Class Initialized
INFO - 2023-09-11 19:34:33 --> URI Class Initialized
INFO - 2023-09-11 19:34:33 --> Router Class Initialized
INFO - 2023-09-11 19:34:33 --> Output Class Initialized
INFO - 2023-09-11 19:34:33 --> Security Class Initialized
DEBUG - 2023-09-11 19:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:34:33 --> Input Class Initialized
INFO - 2023-09-11 19:34:33 --> Language Class Initialized
INFO - 2023-09-11 19:34:33 --> Loader Class Initialized
INFO - 2023-09-11 19:34:33 --> Helper loaded: url_helper
INFO - 2023-09-11 19:34:33 --> Helper loaded: file_helper
INFO - 2023-09-11 19:34:33 --> Database Driver Class Initialized
INFO - 2023-09-11 19:34:33 --> Email Class Initialized
DEBUG - 2023-09-11 19:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:34:33 --> Controller Class Initialized
INFO - 2023-09-11 19:34:33 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:34:33 --> Model "Home_model" initialized
INFO - 2023-09-11 19:34:33 --> Helper loaded: download_helper
INFO - 2023-09-11 19:34:33 --> Helper loaded: form_helper
INFO - 2023-09-11 19:34:33 --> Form Validation Class Initialized
INFO - 2023-09-11 19:34:33 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:34:33 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:34:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:34:33 --> Final output sent to browser
DEBUG - 2023-09-11 19:34:33 --> Total execution time: 0.3585
INFO - 2023-09-11 19:34:35 --> Config Class Initialized
INFO - 2023-09-11 19:34:35 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:34:35 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:34:35 --> Utf8 Class Initialized
INFO - 2023-09-11 19:34:35 --> Config Class Initialized
INFO - 2023-09-11 19:34:35 --> Config Class Initialized
INFO - 2023-09-11 19:34:35 --> URI Class Initialized
INFO - 2023-09-11 19:34:35 --> Hooks Class Initialized
INFO - 2023-09-11 19:34:35 --> Router Class Initialized
INFO - 2023-09-11 19:34:35 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:34:35 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:34:35 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:34:35 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:34:35 --> URI Class Initialized
INFO - 2023-09-11 19:34:35 --> Output Class Initialized
INFO - 2023-09-11 19:34:35 --> Security Class Initialized
DEBUG - 2023-09-11 19:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:34:35 --> Utf8 Class Initialized
INFO - 2023-09-11 19:34:35 --> URI Class Initialized
INFO - 2023-09-11 19:34:35 --> Router Class Initialized
INFO - 2023-09-11 19:34:35 --> Router Class Initialized
INFO - 2023-09-11 19:34:35 --> Output Class Initialized
INFO - 2023-09-11 19:34:35 --> Input Class Initialized
INFO - 2023-09-11 19:34:36 --> Security Class Initialized
DEBUG - 2023-09-11 19:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:34:36 --> Output Class Initialized
INFO - 2023-09-11 19:34:36 --> Security Class Initialized
INFO - 2023-09-11 19:34:36 --> Language Class Initialized
ERROR - 2023-09-11 19:34:36 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:34:36 --> Input Class Initialized
DEBUG - 2023-09-11 19:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:34:36 --> Language Class Initialized
INFO - 2023-09-11 19:34:36 --> Input Class Initialized
ERROR - 2023-09-11 19:34:36 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:34:36 --> Language Class Initialized
ERROR - 2023-09-11 19:34:36 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:35:21 --> Config Class Initialized
INFO - 2023-09-11 19:35:21 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:35:21 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:21 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:21 --> URI Class Initialized
INFO - 2023-09-11 19:35:21 --> Router Class Initialized
INFO - 2023-09-11 19:35:21 --> Output Class Initialized
INFO - 2023-09-11 19:35:21 --> Security Class Initialized
DEBUG - 2023-09-11 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:21 --> Input Class Initialized
INFO - 2023-09-11 19:35:21 --> Language Class Initialized
INFO - 2023-09-11 19:35:21 --> Loader Class Initialized
INFO - 2023-09-11 19:35:21 --> Helper loaded: url_helper
INFO - 2023-09-11 19:35:21 --> Helper loaded: file_helper
INFO - 2023-09-11 19:35:21 --> Database Driver Class Initialized
INFO - 2023-09-11 19:35:21 --> Email Class Initialized
DEBUG - 2023-09-11 19:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:35:21 --> Controller Class Initialized
INFO - 2023-09-11 19:35:21 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:35:21 --> Model "Home_model" initialized
INFO - 2023-09-11 19:35:22 --> Helper loaded: download_helper
INFO - 2023-09-11 19:35:22 --> Helper loaded: form_helper
INFO - 2023-09-11 19:35:22 --> Form Validation Class Initialized
INFO - 2023-09-11 19:35:22 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:35:22 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:35:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:35:22 --> Final output sent to browser
DEBUG - 2023-09-11 19:35:22 --> Total execution time: 0.4053
INFO - 2023-09-11 19:35:23 --> Config Class Initialized
INFO - 2023-09-11 19:35:23 --> Config Class Initialized
INFO - 2023-09-11 19:35:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:35:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:23 --> Hooks Class Initialized
INFO - 2023-09-11 19:35:23 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:23 --> Config Class Initialized
INFO - 2023-09-11 19:35:24 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:35:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:24 --> URI Class Initialized
DEBUG - 2023-09-11 19:35:24 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:24 --> Router Class Initialized
INFO - 2023-09-11 19:35:24 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:24 --> Output Class Initialized
INFO - 2023-09-11 19:35:24 --> Security Class Initialized
INFO - 2023-09-11 19:35:24 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:24 --> URI Class Initialized
INFO - 2023-09-11 19:35:24 --> URI Class Initialized
INFO - 2023-09-11 19:35:24 --> Router Class Initialized
INFO - 2023-09-11 19:35:24 --> Input Class Initialized
INFO - 2023-09-11 19:35:24 --> Output Class Initialized
INFO - 2023-09-11 19:35:24 --> Security Class Initialized
INFO - 2023-09-11 19:35:24 --> Language Class Initialized
ERROR - 2023-09-11 19:35:24 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:35:24 --> Router Class Initialized
DEBUG - 2023-09-11 19:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:24 --> Output Class Initialized
INFO - 2023-09-11 19:35:24 --> Input Class Initialized
INFO - 2023-09-11 19:35:24 --> Security Class Initialized
INFO - 2023-09-11 19:35:24 --> Language Class Initialized
DEBUG - 2023-09-11 19:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:24 --> Input Class Initialized
ERROR - 2023-09-11 19:35:24 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:35:24 --> Language Class Initialized
ERROR - 2023-09-11 19:35:24 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-11 19:35:52 --> Config Class Initialized
INFO - 2023-09-11 19:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-11 19:35:53 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:53 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:53 --> URI Class Initialized
INFO - 2023-09-11 19:35:53 --> Router Class Initialized
INFO - 2023-09-11 19:35:53 --> Output Class Initialized
INFO - 2023-09-11 19:35:53 --> Security Class Initialized
DEBUG - 2023-09-11 19:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:53 --> Input Class Initialized
INFO - 2023-09-11 19:35:53 --> Language Class Initialized
INFO - 2023-09-11 19:35:53 --> Loader Class Initialized
INFO - 2023-09-11 19:35:53 --> Helper loaded: url_helper
INFO - 2023-09-11 19:35:53 --> Helper loaded: file_helper
INFO - 2023-09-11 19:35:53 --> Database Driver Class Initialized
INFO - 2023-09-11 19:35:53 --> Email Class Initialized
DEBUG - 2023-09-11 19:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-11 19:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 19:35:53 --> Controller Class Initialized
INFO - 2023-09-11 19:35:53 --> Model "Contact_model" initialized
INFO - 2023-09-11 19:35:53 --> Model "Home_model" initialized
INFO - 2023-09-11 19:35:53 --> Helper loaded: download_helper
INFO - 2023-09-11 19:35:53 --> Helper loaded: form_helper
INFO - 2023-09-11 19:35:53 --> Form Validation Class Initialized
INFO - 2023-09-11 19:35:53 --> Helper loaded: custom_helper
INFO - 2023-09-11 19:35:53 --> Model "Social_media_model" initialized
INFO - 2023-09-11 19:35:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-11 19:35:53 --> Final output sent to browser
DEBUG - 2023-09-11 19:35:53 --> Total execution time: 0.4198
INFO - 2023-09-11 19:35:55 --> Config Class Initialized
INFO - 2023-09-11 19:35:55 --> Hooks Class Initialized
INFO - 2023-09-11 19:35:55 --> Config Class Initialized
INFO - 2023-09-11 19:35:55 --> Hooks Class Initialized
INFO - 2023-09-11 19:35:55 --> Config Class Initialized
DEBUG - 2023-09-11 19:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 19:35:55 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:55 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:55 --> Hooks Class Initialized
INFO - 2023-09-11 19:35:55 --> Utf8 Class Initialized
DEBUG - 2023-09-11 19:35:55 --> UTF-8 Support Enabled
INFO - 2023-09-11 19:35:55 --> URI Class Initialized
INFO - 2023-09-11 19:35:55 --> Utf8 Class Initialized
INFO - 2023-09-11 19:35:55 --> Router Class Initialized
INFO - 2023-09-11 19:35:55 --> URI Class Initialized
INFO - 2023-09-11 19:35:55 --> URI Class Initialized
INFO - 2023-09-11 19:35:55 --> Router Class Initialized
INFO - 2023-09-11 19:35:55 --> Output Class Initialized
INFO - 2023-09-11 19:35:55 --> Output Class Initialized
INFO - 2023-09-11 19:35:55 --> Security Class Initialized
INFO - 2023-09-11 19:35:55 --> Security Class Initialized
DEBUG - 2023-09-11 19:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:55 --> Input Class Initialized
INFO - 2023-09-11 19:35:55 --> Router Class Initialized
INFO - 2023-09-11 19:35:55 --> Language Class Initialized
DEBUG - 2023-09-11 19:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:55 --> Output Class Initialized
INFO - 2023-09-11 19:35:55 --> Input Class Initialized
INFO - 2023-09-11 19:35:55 --> Security Class Initialized
DEBUG - 2023-09-11 19:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 19:35:55 --> Language Class Initialized
INFO - 2023-09-11 19:35:56 --> Input Class Initialized
INFO - 2023-09-11 19:35:56 --> Language Class Initialized
ERROR - 2023-09-11 19:35:56 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:35:56 --> 404 Page Not Found: Blog-detail/assets
ERROR - 2023-09-11 19:35:56 --> 404 Page Not Found: Blog-detail/assets
