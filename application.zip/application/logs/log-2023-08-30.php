<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-30 18:56:22 --> Config Class Initialized
INFO - 2023-08-30 18:56:22 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:22 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:22 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:22 --> URI Class Initialized
INFO - 2023-08-30 18:56:22 --> Router Class Initialized
INFO - 2023-08-30 18:56:22 --> Output Class Initialized
INFO - 2023-08-30 18:56:22 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:22 --> Input Class Initialized
INFO - 2023-08-30 18:56:22 --> Language Class Initialized
INFO - 2023-08-30 18:56:22 --> Loader Class Initialized
INFO - 2023-08-30 18:56:22 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:22 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:22 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:22 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:22 --> Controller Class Initialized
INFO - 2023-08-30 18:56:22 --> Model "User_model" initialized
INFO - 2023-08-30 18:56:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-30 18:56:22 --> Final output sent to browser
DEBUG - 2023-08-30 18:56:22 --> Total execution time: 0.0816
INFO - 2023-08-30 18:56:27 --> Config Class Initialized
INFO - 2023-08-30 18:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:27 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:27 --> URI Class Initialized
INFO - 2023-08-30 18:56:27 --> Router Class Initialized
INFO - 2023-08-30 18:56:27 --> Output Class Initialized
INFO - 2023-08-30 18:56:27 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:27 --> Input Class Initialized
INFO - 2023-08-30 18:56:27 --> Language Class Initialized
ERROR - 2023-08-30 18:56:27 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-30 18:56:29 --> Config Class Initialized
INFO - 2023-08-30 18:56:29 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:29 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:29 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:29 --> URI Class Initialized
INFO - 2023-08-30 18:56:29 --> Router Class Initialized
INFO - 2023-08-30 18:56:29 --> Output Class Initialized
INFO - 2023-08-30 18:56:29 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:29 --> Input Class Initialized
INFO - 2023-08-30 18:56:29 --> Language Class Initialized
INFO - 2023-08-30 18:56:29 --> Loader Class Initialized
INFO - 2023-08-30 18:56:29 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:29 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:29 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:29 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:29 --> Controller Class Initialized
INFO - 2023-08-30 18:56:29 --> Model "User_model" initialized
INFO - 2023-08-30 18:56:29 --> Config Class Initialized
INFO - 2023-08-30 18:56:29 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:29 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:29 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:29 --> URI Class Initialized
INFO - 2023-08-30 18:56:29 --> Router Class Initialized
INFO - 2023-08-30 18:56:29 --> Output Class Initialized
INFO - 2023-08-30 18:56:29 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:29 --> Input Class Initialized
INFO - 2023-08-30 18:56:29 --> Language Class Initialized
INFO - 2023-08-30 18:56:29 --> Loader Class Initialized
INFO - 2023-08-30 18:56:29 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:29 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:29 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:29 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:29 --> Controller Class Initialized
INFO - 2023-08-30 18:56:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-30 18:56:29 --> Final output sent to browser
DEBUG - 2023-08-30 18:56:29 --> Total execution time: 0.0722
INFO - 2023-08-30 18:56:35 --> Config Class Initialized
INFO - 2023-08-30 18:56:35 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:35 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:35 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:35 --> URI Class Initialized
INFO - 2023-08-30 18:56:35 --> Router Class Initialized
INFO - 2023-08-30 18:56:35 --> Output Class Initialized
INFO - 2023-08-30 18:56:35 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:35 --> Input Class Initialized
INFO - 2023-08-30 18:56:35 --> Language Class Initialized
INFO - 2023-08-30 18:56:35 --> Loader Class Initialized
INFO - 2023-08-30 18:56:35 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:35 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:35 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:35 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:35 --> Controller Class Initialized
INFO - 2023-08-30 18:56:35 --> Model "Gallery_model" initialized
INFO - 2023-08-30 18:56:35 --> Helper loaded: form_helper
INFO - 2023-08-30 18:56:35 --> Form Validation Class Initialized
INFO - 2023-08-30 18:56:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-30 18:56:35 --> Final output sent to browser
DEBUG - 2023-08-30 18:56:35 --> Total execution time: 0.0937
INFO - 2023-08-30 18:56:38 --> Config Class Initialized
INFO - 2023-08-30 18:56:38 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:38 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:38 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:38 --> URI Class Initialized
INFO - 2023-08-30 18:56:38 --> Router Class Initialized
INFO - 2023-08-30 18:56:38 --> Output Class Initialized
INFO - 2023-08-30 18:56:38 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:38 --> Input Class Initialized
INFO - 2023-08-30 18:56:38 --> Language Class Initialized
INFO - 2023-08-30 18:56:38 --> Loader Class Initialized
INFO - 2023-08-30 18:56:38 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:38 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:38 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:38 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:38 --> Controller Class Initialized
INFO - 2023-08-30 18:56:38 --> Model "Services_model" initialized
INFO - 2023-08-30 18:56:38 --> Helper loaded: form_helper
INFO - 2023-08-30 18:56:38 --> Form Validation Class Initialized
INFO - 2023-08-30 18:56:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 18:56:38 --> Final output sent to browser
DEBUG - 2023-08-30 18:56:38 --> Total execution time: 0.1205
INFO - 2023-08-30 18:56:48 --> Config Class Initialized
INFO - 2023-08-30 18:56:48 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:48 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:48 --> URI Class Initialized
INFO - 2023-08-30 18:56:48 --> Router Class Initialized
INFO - 2023-08-30 18:56:48 --> Output Class Initialized
INFO - 2023-08-30 18:56:48 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:48 --> Input Class Initialized
INFO - 2023-08-30 18:56:48 --> Language Class Initialized
INFO - 2023-08-30 18:56:48 --> Loader Class Initialized
INFO - 2023-08-30 18:56:48 --> Helper loaded: url_helper
INFO - 2023-08-30 18:56:48 --> Helper loaded: file_helper
INFO - 2023-08-30 18:56:48 --> Database Driver Class Initialized
INFO - 2023-08-30 18:56:48 --> Email Class Initialized
DEBUG - 2023-08-30 18:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 18:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 18:56:48 --> Controller Class Initialized
INFO - 2023-08-30 18:56:48 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 18:56:48 --> Helper loaded: form_helper
INFO - 2023-08-30 18:56:49 --> Form Validation Class Initialized
INFO - 2023-08-30 18:56:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 18:56:49 --> Final output sent to browser
DEBUG - 2023-08-30 18:56:49 --> Total execution time: 0.1048
INFO - 2023-08-30 18:56:50 --> Config Class Initialized
INFO - 2023-08-30 18:56:50 --> Hooks Class Initialized
DEBUG - 2023-08-30 18:56:50 --> UTF-8 Support Enabled
INFO - 2023-08-30 18:56:50 --> Utf8 Class Initialized
INFO - 2023-08-30 18:56:50 --> URI Class Initialized
INFO - 2023-08-30 18:56:50 --> Router Class Initialized
INFO - 2023-08-30 18:56:50 --> Output Class Initialized
INFO - 2023-08-30 18:56:50 --> Security Class Initialized
DEBUG - 2023-08-30 18:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 18:56:50 --> Input Class Initialized
INFO - 2023-08-30 18:56:50 --> Language Class Initialized
ERROR - 2023-08-30 18:56:50 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-08-30 19:36:44 --> Config Class Initialized
INFO - 2023-08-30 19:36:44 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:44 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:44 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:44 --> URI Class Initialized
DEBUG - 2023-08-30 19:36:44 --> No URI present. Default controller set.
INFO - 2023-08-30 19:36:44 --> Router Class Initialized
INFO - 2023-08-30 19:36:44 --> Output Class Initialized
INFO - 2023-08-30 19:36:44 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:44 --> Input Class Initialized
INFO - 2023-08-30 19:36:44 --> Language Class Initialized
INFO - 2023-08-30 19:36:44 --> Loader Class Initialized
INFO - 2023-08-30 19:36:44 --> Helper loaded: url_helper
INFO - 2023-08-30 19:36:44 --> Helper loaded: file_helper
INFO - 2023-08-30 19:36:45 --> Database Driver Class Initialized
INFO - 2023-08-30 19:36:45 --> Email Class Initialized
DEBUG - 2023-08-30 19:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 19:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 19:36:45 --> Controller Class Initialized
INFO - 2023-08-30 19:36:45 --> Model "Contact_model" initialized
INFO - 2023-08-30 19:36:45 --> Model "Home_model" initialized
INFO - 2023-08-30 19:36:45 --> Helper loaded: download_helper
INFO - 2023-08-30 19:36:45 --> Helper loaded: form_helper
INFO - 2023-08-30 19:36:45 --> Form Validation Class Initialized
INFO - 2023-08-30 19:36:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 19:36:45 --> Final output sent to browser
DEBUG - 2023-08-30 19:36:45 --> Total execution time: 1.7782
INFO - 2023-08-30 19:36:47 --> Config Class Initialized
INFO - 2023-08-30 19:36:47 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:47 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:47 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:47 --> URI Class Initialized
INFO - 2023-08-30 19:36:47 --> Router Class Initialized
INFO - 2023-08-30 19:36:47 --> Output Class Initialized
INFO - 2023-08-30 19:36:47 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:47 --> Input Class Initialized
INFO - 2023-08-30 19:36:47 --> Language Class Initialized
ERROR - 2023-08-30 19:36:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 19:36:47 --> Config Class Initialized
INFO - 2023-08-30 19:36:47 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:47 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:47 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:47 --> URI Class Initialized
INFO - 2023-08-30 19:36:47 --> Router Class Initialized
INFO - 2023-08-30 19:36:47 --> Output Class Initialized
INFO - 2023-08-30 19:36:47 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:47 --> Input Class Initialized
INFO - 2023-08-30 19:36:47 --> Language Class Initialized
ERROR - 2023-08-30 19:36:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 19:36:56 --> Config Class Initialized
INFO - 2023-08-30 19:36:56 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:56 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:56 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:56 --> URI Class Initialized
INFO - 2023-08-30 19:36:56 --> Router Class Initialized
INFO - 2023-08-30 19:36:57 --> Output Class Initialized
INFO - 2023-08-30 19:36:57 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:57 --> Input Class Initialized
INFO - 2023-08-30 19:36:57 --> Language Class Initialized
INFO - 2023-08-30 19:36:57 --> Loader Class Initialized
INFO - 2023-08-30 19:36:57 --> Helper loaded: url_helper
INFO - 2023-08-30 19:36:57 --> Helper loaded: file_helper
INFO - 2023-08-30 19:36:57 --> Database Driver Class Initialized
INFO - 2023-08-30 19:36:57 --> Email Class Initialized
DEBUG - 2023-08-30 19:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 19:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 19:36:57 --> Controller Class Initialized
INFO - 2023-08-30 19:36:57 --> Model "Contact_model" initialized
INFO - 2023-08-30 19:36:57 --> Model "Home_model" initialized
INFO - 2023-08-30 19:36:57 --> Helper loaded: download_helper
INFO - 2023-08-30 19:36:57 --> Helper loaded: form_helper
INFO - 2023-08-30 19:36:57 --> Form Validation Class Initialized
INFO - 2023-08-30 19:36:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-30 19:36:57 --> Final output sent to browser
DEBUG - 2023-08-30 19:36:57 --> Total execution time: 0.4493
INFO - 2023-08-30 19:36:58 --> Config Class Initialized
INFO - 2023-08-30 19:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:58 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:58 --> URI Class Initialized
INFO - 2023-08-30 19:36:58 --> Router Class Initialized
INFO - 2023-08-30 19:36:58 --> Output Class Initialized
INFO - 2023-08-30 19:36:58 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:58 --> Input Class Initialized
INFO - 2023-08-30 19:36:58 --> Language Class Initialized
ERROR - 2023-08-30 19:36:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 19:36:58 --> Config Class Initialized
INFO - 2023-08-30 19:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:58 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:58 --> URI Class Initialized
INFO - 2023-08-30 19:36:58 --> Router Class Initialized
INFO - 2023-08-30 19:36:58 --> Output Class Initialized
INFO - 2023-08-30 19:36:58 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:58 --> Input Class Initialized
INFO - 2023-08-30 19:36:58 --> Language Class Initialized
ERROR - 2023-08-30 19:36:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 19:36:59 --> Config Class Initialized
INFO - 2023-08-30 19:36:59 --> Hooks Class Initialized
DEBUG - 2023-08-30 19:36:59 --> UTF-8 Support Enabled
INFO - 2023-08-30 19:36:59 --> Utf8 Class Initialized
INFO - 2023-08-30 19:36:59 --> URI Class Initialized
INFO - 2023-08-30 19:36:59 --> Router Class Initialized
INFO - 2023-08-30 19:36:59 --> Output Class Initialized
INFO - 2023-08-30 19:36:59 --> Security Class Initialized
DEBUG - 2023-08-30 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 19:36:59 --> Input Class Initialized
INFO - 2023-08-30 19:36:59 --> Language Class Initialized
ERROR - 2023-08-30 19:36:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:52:14 --> Config Class Initialized
INFO - 2023-08-30 20:52:14 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:52:14 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:52:14 --> Utf8 Class Initialized
INFO - 2023-08-30 20:52:14 --> URI Class Initialized
DEBUG - 2023-08-30 20:52:14 --> No URI present. Default controller set.
INFO - 2023-08-30 20:52:14 --> Router Class Initialized
INFO - 2023-08-30 20:52:14 --> Output Class Initialized
INFO - 2023-08-30 20:52:14 --> Security Class Initialized
DEBUG - 2023-08-30 20:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:52:14 --> Input Class Initialized
INFO - 2023-08-30 20:52:14 --> Language Class Initialized
INFO - 2023-08-30 20:52:14 --> Loader Class Initialized
INFO - 2023-08-30 20:52:14 --> Helper loaded: url_helper
INFO - 2023-08-30 20:52:14 --> Helper loaded: file_helper
INFO - 2023-08-30 20:52:14 --> Database Driver Class Initialized
INFO - 2023-08-30 20:52:14 --> Email Class Initialized
DEBUG - 2023-08-30 20:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 20:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 20:52:14 --> Controller Class Initialized
INFO - 2023-08-30 20:52:14 --> Model "Contact_model" initialized
INFO - 2023-08-30 20:52:14 --> Model "Home_model" initialized
INFO - 2023-08-30 20:52:14 --> Helper loaded: download_helper
INFO - 2023-08-30 20:52:14 --> Helper loaded: form_helper
INFO - 2023-08-30 20:52:14 --> Form Validation Class Initialized
INFO - 2023-08-30 20:52:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 20:52:14 --> Final output sent to browser
DEBUG - 2023-08-30 20:52:14 --> Total execution time: 0.2989
INFO - 2023-08-30 20:52:15 --> Config Class Initialized
INFO - 2023-08-30 20:52:15 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:52:15 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:52:15 --> Utf8 Class Initialized
INFO - 2023-08-30 20:52:15 --> URI Class Initialized
INFO - 2023-08-30 20:52:15 --> Router Class Initialized
INFO - 2023-08-30 20:52:15 --> Output Class Initialized
INFO - 2023-08-30 20:52:15 --> Security Class Initialized
DEBUG - 2023-08-30 20:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:52:15 --> Input Class Initialized
INFO - 2023-08-30 20:52:15 --> Language Class Initialized
ERROR - 2023-08-30 20:52:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:52:16 --> Config Class Initialized
INFO - 2023-08-30 20:52:16 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:52:16 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:52:16 --> Utf8 Class Initialized
INFO - 2023-08-30 20:52:16 --> URI Class Initialized
INFO - 2023-08-30 20:52:16 --> Router Class Initialized
INFO - 2023-08-30 20:52:16 --> Output Class Initialized
INFO - 2023-08-30 20:52:16 --> Security Class Initialized
DEBUG - 2023-08-30 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:52:16 --> Input Class Initialized
INFO - 2023-08-30 20:52:16 --> Language Class Initialized
ERROR - 2023-08-30 20:52:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:05 --> Config Class Initialized
INFO - 2023-08-30 20:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:05 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:05 --> URI Class Initialized
DEBUG - 2023-08-30 20:54:05 --> No URI present. Default controller set.
INFO - 2023-08-30 20:54:05 --> Router Class Initialized
INFO - 2023-08-30 20:54:05 --> Output Class Initialized
INFO - 2023-08-30 20:54:05 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:05 --> Input Class Initialized
INFO - 2023-08-30 20:54:05 --> Language Class Initialized
INFO - 2023-08-30 20:54:06 --> Loader Class Initialized
INFO - 2023-08-30 20:54:06 --> Helper loaded: url_helper
INFO - 2023-08-30 20:54:06 --> Helper loaded: file_helper
INFO - 2023-08-30 20:54:06 --> Database Driver Class Initialized
INFO - 2023-08-30 20:54:06 --> Email Class Initialized
DEBUG - 2023-08-30 20:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 20:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 20:54:06 --> Controller Class Initialized
INFO - 2023-08-30 20:54:06 --> Model "Contact_model" initialized
INFO - 2023-08-30 20:54:06 --> Model "Home_model" initialized
INFO - 2023-08-30 20:54:06 --> Helper loaded: download_helper
INFO - 2023-08-30 20:54:06 --> Helper loaded: form_helper
INFO - 2023-08-30 20:54:06 --> Form Validation Class Initialized
INFO - 2023-08-30 20:54:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 20:54:06 --> Final output sent to browser
DEBUG - 2023-08-30 20:54:06 --> Total execution time: 0.6292
INFO - 2023-08-30 20:54:07 --> Config Class Initialized
INFO - 2023-08-30 20:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:07 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:07 --> URI Class Initialized
INFO - 2023-08-30 20:54:07 --> Router Class Initialized
INFO - 2023-08-30 20:54:07 --> Output Class Initialized
INFO - 2023-08-30 20:54:07 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:07 --> Input Class Initialized
INFO - 2023-08-30 20:54:07 --> Language Class Initialized
ERROR - 2023-08-30 20:54:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:07 --> Config Class Initialized
INFO - 2023-08-30 20:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:07 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:07 --> URI Class Initialized
INFO - 2023-08-30 20:54:07 --> Router Class Initialized
INFO - 2023-08-30 20:54:07 --> Output Class Initialized
INFO - 2023-08-30 20:54:07 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:07 --> Input Class Initialized
INFO - 2023-08-30 20:54:07 --> Language Class Initialized
ERROR - 2023-08-30 20:54:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:07 --> Config Class Initialized
INFO - 2023-08-30 20:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:07 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:07 --> URI Class Initialized
INFO - 2023-08-30 20:54:07 --> Router Class Initialized
INFO - 2023-08-30 20:54:07 --> Output Class Initialized
INFO - 2023-08-30 20:54:07 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:07 --> Input Class Initialized
INFO - 2023-08-30 20:54:07 --> Language Class Initialized
ERROR - 2023-08-30 20:54:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:07 --> Config Class Initialized
INFO - 2023-08-30 20:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:07 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:07 --> URI Class Initialized
INFO - 2023-08-30 20:54:07 --> Router Class Initialized
INFO - 2023-08-30 20:54:07 --> Output Class Initialized
INFO - 2023-08-30 20:54:07 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:07 --> Input Class Initialized
INFO - 2023-08-30 20:54:07 --> Language Class Initialized
ERROR - 2023-08-30 20:54:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:07 --> Config Class Initialized
INFO - 2023-08-30 20:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:08 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:08 --> URI Class Initialized
INFO - 2023-08-30 20:54:08 --> Router Class Initialized
INFO - 2023-08-30 20:54:08 --> Output Class Initialized
INFO - 2023-08-30 20:54:08 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:08 --> Input Class Initialized
INFO - 2023-08-30 20:54:08 --> Language Class Initialized
ERROR - 2023-08-30 20:54:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:08 --> Config Class Initialized
INFO - 2023-08-30 20:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:08 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:08 --> URI Class Initialized
INFO - 2023-08-30 20:54:08 --> Router Class Initialized
INFO - 2023-08-30 20:54:08 --> Output Class Initialized
INFO - 2023-08-30 20:54:08 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:08 --> Input Class Initialized
INFO - 2023-08-30 20:54:08 --> Language Class Initialized
ERROR - 2023-08-30 20:54:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:08 --> Config Class Initialized
INFO - 2023-08-30 20:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:08 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:08 --> URI Class Initialized
INFO - 2023-08-30 20:54:08 --> Router Class Initialized
INFO - 2023-08-30 20:54:08 --> Output Class Initialized
INFO - 2023-08-30 20:54:08 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:08 --> Input Class Initialized
INFO - 2023-08-30 20:54:08 --> Language Class Initialized
ERROR - 2023-08-30 20:54:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:08 --> Config Class Initialized
INFO - 2023-08-30 20:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:08 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:08 --> URI Class Initialized
INFO - 2023-08-30 20:54:08 --> Router Class Initialized
INFO - 2023-08-30 20:54:08 --> Output Class Initialized
INFO - 2023-08-30 20:54:08 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:08 --> Input Class Initialized
INFO - 2023-08-30 20:54:08 --> Language Class Initialized
ERROR - 2023-08-30 20:54:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:09 --> Config Class Initialized
INFO - 2023-08-30 20:54:09 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:09 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:09 --> URI Class Initialized
INFO - 2023-08-30 20:54:09 --> Router Class Initialized
INFO - 2023-08-30 20:54:09 --> Output Class Initialized
INFO - 2023-08-30 20:54:09 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:09 --> Input Class Initialized
INFO - 2023-08-30 20:54:09 --> Language Class Initialized
ERROR - 2023-08-30 20:54:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:52 --> Config Class Initialized
INFO - 2023-08-30 20:54:52 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:52 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:52 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:52 --> URI Class Initialized
DEBUG - 2023-08-30 20:54:52 --> No URI present. Default controller set.
INFO - 2023-08-30 20:54:52 --> Router Class Initialized
INFO - 2023-08-30 20:54:52 --> Output Class Initialized
INFO - 2023-08-30 20:54:52 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:52 --> Input Class Initialized
INFO - 2023-08-30 20:54:52 --> Language Class Initialized
INFO - 2023-08-30 20:54:52 --> Loader Class Initialized
INFO - 2023-08-30 20:54:52 --> Helper loaded: url_helper
INFO - 2023-08-30 20:54:52 --> Helper loaded: file_helper
INFO - 2023-08-30 20:54:53 --> Database Driver Class Initialized
INFO - 2023-08-30 20:54:53 --> Email Class Initialized
DEBUG - 2023-08-30 20:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 20:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 20:54:53 --> Controller Class Initialized
INFO - 2023-08-30 20:54:53 --> Model "Contact_model" initialized
INFO - 2023-08-30 20:54:53 --> Model "Home_model" initialized
INFO - 2023-08-30 20:54:53 --> Helper loaded: download_helper
INFO - 2023-08-30 20:54:53 --> Helper loaded: form_helper
INFO - 2023-08-30 20:54:53 --> Form Validation Class Initialized
INFO - 2023-08-30 20:54:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 20:54:53 --> Final output sent to browser
DEBUG - 2023-08-30 20:54:53 --> Total execution time: 0.4757
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:54 --> URI Class Initialized
INFO - 2023-08-30 20:54:54 --> Router Class Initialized
INFO - 2023-08-30 20:54:54 --> Output Class Initialized
INFO - 2023-08-30 20:54:54 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:54 --> Input Class Initialized
INFO - 2023-08-30 20:54:54 --> Language Class Initialized
ERROR - 2023-08-30 20:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:54 --> URI Class Initialized
INFO - 2023-08-30 20:54:54 --> Router Class Initialized
INFO - 2023-08-30 20:54:54 --> Output Class Initialized
INFO - 2023-08-30 20:54:54 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:54 --> Input Class Initialized
INFO - 2023-08-30 20:54:54 --> Language Class Initialized
ERROR - 2023-08-30 20:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:54 --> URI Class Initialized
INFO - 2023-08-30 20:54:54 --> Router Class Initialized
INFO - 2023-08-30 20:54:54 --> Output Class Initialized
INFO - 2023-08-30 20:54:54 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:54 --> Input Class Initialized
INFO - 2023-08-30 20:54:54 --> Language Class Initialized
ERROR - 2023-08-30 20:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:54 --> URI Class Initialized
INFO - 2023-08-30 20:54:54 --> Router Class Initialized
INFO - 2023-08-30 20:54:54 --> Output Class Initialized
INFO - 2023-08-30 20:54:54 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:54 --> Input Class Initialized
INFO - 2023-08-30 20:54:54 --> Language Class Initialized
ERROR - 2023-08-30 20:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:54 --> URI Class Initialized
INFO - 2023-08-30 20:54:54 --> Router Class Initialized
INFO - 2023-08-30 20:54:54 --> Output Class Initialized
INFO - 2023-08-30 20:54:54 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:54 --> Input Class Initialized
INFO - 2023-08-30 20:54:54 --> Language Class Initialized
ERROR - 2023-08-30 20:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:54 --> Config Class Initialized
INFO - 2023-08-30 20:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:54 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:55 --> URI Class Initialized
INFO - 2023-08-30 20:54:55 --> Router Class Initialized
INFO - 2023-08-30 20:54:55 --> Output Class Initialized
INFO - 2023-08-30 20:54:55 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:55 --> Input Class Initialized
INFO - 2023-08-30 20:54:55 --> Language Class Initialized
ERROR - 2023-08-30 20:54:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:55 --> Config Class Initialized
INFO - 2023-08-30 20:54:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:55 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:55 --> URI Class Initialized
INFO - 2023-08-30 20:54:55 --> Router Class Initialized
INFO - 2023-08-30 20:54:55 --> Output Class Initialized
INFO - 2023-08-30 20:54:55 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:55 --> Input Class Initialized
INFO - 2023-08-30 20:54:55 --> Language Class Initialized
ERROR - 2023-08-30 20:54:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:54:55 --> Config Class Initialized
INFO - 2023-08-30 20:54:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:54:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:54:55 --> Utf8 Class Initialized
INFO - 2023-08-30 20:54:55 --> URI Class Initialized
INFO - 2023-08-30 20:54:55 --> Router Class Initialized
INFO - 2023-08-30 20:54:55 --> Output Class Initialized
INFO - 2023-08-30 20:54:55 --> Security Class Initialized
DEBUG - 2023-08-30 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:54:55 --> Input Class Initialized
INFO - 2023-08-30 20:54:55 --> Language Class Initialized
ERROR - 2023-08-30 20:54:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:35 --> Config Class Initialized
INFO - 2023-08-30 20:59:35 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:35 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:35 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:35 --> URI Class Initialized
DEBUG - 2023-08-30 20:59:35 --> No URI present. Default controller set.
INFO - 2023-08-30 20:59:35 --> Router Class Initialized
INFO - 2023-08-30 20:59:35 --> Output Class Initialized
INFO - 2023-08-30 20:59:35 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:35 --> Input Class Initialized
INFO - 2023-08-30 20:59:35 --> Language Class Initialized
INFO - 2023-08-30 20:59:35 --> Loader Class Initialized
INFO - 2023-08-30 20:59:35 --> Helper loaded: url_helper
INFO - 2023-08-30 20:59:35 --> Helper loaded: file_helper
INFO - 2023-08-30 20:59:35 --> Database Driver Class Initialized
INFO - 2023-08-30 20:59:35 --> Email Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 20:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 20:59:36 --> Controller Class Initialized
INFO - 2023-08-30 20:59:36 --> Model "Contact_model" initialized
INFO - 2023-08-30 20:59:36 --> Model "Home_model" initialized
INFO - 2023-08-30 20:59:36 --> Helper loaded: download_helper
INFO - 2023-08-30 20:59:36 --> Helper loaded: form_helper
INFO - 2023-08-30 20:59:36 --> Form Validation Class Initialized
INFO - 2023-08-30 20:59:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 20:59:36 --> Final output sent to browser
DEBUG - 2023-08-30 20:59:36 --> Total execution time: 0.1836
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:36 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:36 --> URI Class Initialized
INFO - 2023-08-30 20:59:36 --> Router Class Initialized
INFO - 2023-08-30 20:59:36 --> Output Class Initialized
INFO - 2023-08-30 20:59:36 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:36 --> Input Class Initialized
INFO - 2023-08-30 20:59:36 --> Language Class Initialized
ERROR - 2023-08-30 20:59:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:36 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:36 --> URI Class Initialized
INFO - 2023-08-30 20:59:36 --> Router Class Initialized
INFO - 2023-08-30 20:59:36 --> Output Class Initialized
INFO - 2023-08-30 20:59:36 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:36 --> Input Class Initialized
INFO - 2023-08-30 20:59:36 --> Language Class Initialized
ERROR - 2023-08-30 20:59:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:36 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:36 --> URI Class Initialized
INFO - 2023-08-30 20:59:36 --> Router Class Initialized
INFO - 2023-08-30 20:59:36 --> Output Class Initialized
INFO - 2023-08-30 20:59:36 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:36 --> Input Class Initialized
INFO - 2023-08-30 20:59:36 --> Language Class Initialized
ERROR - 2023-08-30 20:59:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:36 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:36 --> URI Class Initialized
INFO - 2023-08-30 20:59:36 --> Router Class Initialized
INFO - 2023-08-30 20:59:36 --> Output Class Initialized
INFO - 2023-08-30 20:59:36 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:36 --> Input Class Initialized
INFO - 2023-08-30 20:59:36 --> Language Class Initialized
ERROR - 2023-08-30 20:59:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:36 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:36 --> URI Class Initialized
INFO - 2023-08-30 20:59:36 --> Router Class Initialized
INFO - 2023-08-30 20:59:36 --> Output Class Initialized
INFO - 2023-08-30 20:59:36 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:36 --> Input Class Initialized
INFO - 2023-08-30 20:59:36 --> Language Class Initialized
ERROR - 2023-08-30 20:59:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:36 --> Config Class Initialized
INFO - 2023-08-30 20:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:37 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:37 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:37 --> URI Class Initialized
INFO - 2023-08-30 20:59:37 --> Router Class Initialized
INFO - 2023-08-30 20:59:37 --> Output Class Initialized
INFO - 2023-08-30 20:59:37 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:37 --> Input Class Initialized
INFO - 2023-08-30 20:59:37 --> Language Class Initialized
ERROR - 2023-08-30 20:59:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 20:59:37 --> Config Class Initialized
INFO - 2023-08-30 20:59:37 --> Hooks Class Initialized
DEBUG - 2023-08-30 20:59:37 --> UTF-8 Support Enabled
INFO - 2023-08-30 20:59:37 --> Utf8 Class Initialized
INFO - 2023-08-30 20:59:37 --> URI Class Initialized
INFO - 2023-08-30 20:59:37 --> Router Class Initialized
INFO - 2023-08-30 20:59:38 --> Output Class Initialized
INFO - 2023-08-30 20:59:38 --> Security Class Initialized
DEBUG - 2023-08-30 20:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 20:59:38 --> Input Class Initialized
INFO - 2023-08-30 20:59:38 --> Language Class Initialized
ERROR - 2023-08-30 20:59:38 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:50 --> Config Class Initialized
INFO - 2023-08-30 22:04:50 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:50 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:50 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:50 --> URI Class Initialized
DEBUG - 2023-08-30 22:04:50 --> No URI present. Default controller set.
INFO - 2023-08-30 22:04:50 --> Router Class Initialized
INFO - 2023-08-30 22:04:51 --> Output Class Initialized
INFO - 2023-08-30 22:04:51 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:51 --> Input Class Initialized
INFO - 2023-08-30 22:04:51 --> Language Class Initialized
INFO - 2023-08-30 22:04:51 --> Loader Class Initialized
INFO - 2023-08-30 22:04:51 --> Helper loaded: url_helper
INFO - 2023-08-30 22:04:51 --> Helper loaded: file_helper
INFO - 2023-08-30 22:04:51 --> Database Driver Class Initialized
INFO - 2023-08-30 22:04:51 --> Email Class Initialized
DEBUG - 2023-08-30 22:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 22:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 22:04:51 --> Controller Class Initialized
INFO - 2023-08-30 22:04:51 --> Model "Contact_model" initialized
INFO - 2023-08-30 22:04:52 --> Model "Home_model" initialized
INFO - 2023-08-30 22:04:52 --> Helper loaded: download_helper
INFO - 2023-08-30 22:04:52 --> Helper loaded: form_helper
INFO - 2023-08-30 22:04:52 --> Form Validation Class Initialized
INFO - 2023-08-30 22:04:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 22:04:52 --> Final output sent to browser
DEBUG - 2023-08-30 22:04:52 --> Total execution time: 2.2697
INFO - 2023-08-30 22:04:53 --> Config Class Initialized
INFO - 2023-08-30 22:04:53 --> Config Class Initialized
INFO - 2023-08-30 22:04:53 --> Hooks Class Initialized
INFO - 2023-08-30 22:04:53 --> Config Class Initialized
INFO - 2023-08-30 22:04:53 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:53 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:53 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:53 --> URI Class Initialized
INFO - 2023-08-30 22:04:53 --> Router Class Initialized
INFO - 2023-08-30 22:04:53 --> Output Class Initialized
INFO - 2023-08-30 22:04:53 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:53 --> Input Class Initialized
INFO - 2023-08-30 22:04:53 --> Language Class Initialized
DEBUG - 2023-08-30 22:04:53 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:53 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:53 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:53 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:53 --> URI Class Initialized
INFO - 2023-08-30 22:04:53 --> Router Class Initialized
INFO - 2023-08-30 22:04:53 --> Output Class Initialized
INFO - 2023-08-30 22:04:53 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:53 --> Input Class Initialized
INFO - 2023-08-30 22:04:53 --> Language Class Initialized
ERROR - 2023-08-30 22:04:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Config Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
DEBUG - 2023-08-30 22:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
INFO - 2023-08-30 22:04:54 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
INFO - 2023-08-30 22:04:54 --> URI Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Router Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
INFO - 2023-08-30 22:04:54 --> Output Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
INFO - 2023-08-30 22:04:54 --> Input Class Initialized
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:54 --> Language Class Initialized
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-30 22:04:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:55 --> Config Class Initialized
INFO - 2023-08-30 22:04:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:55 --> Config Class Initialized
INFO - 2023-08-30 22:04:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:04:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:04:55 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:55 --> URI Class Initialized
INFO - 2023-08-30 22:04:55 --> Router Class Initialized
INFO - 2023-08-30 22:04:55 --> Output Class Initialized
INFO - 2023-08-30 22:04:55 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:55 --> Input Class Initialized
INFO - 2023-08-30 22:04:55 --> Language Class Initialized
ERROR - 2023-08-30 22:04:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:04:55 --> Utf8 Class Initialized
INFO - 2023-08-30 22:04:55 --> URI Class Initialized
INFO - 2023-08-30 22:04:55 --> Router Class Initialized
INFO - 2023-08-30 22:04:55 --> Output Class Initialized
INFO - 2023-08-30 22:04:55 --> Security Class Initialized
DEBUG - 2023-08-30 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:04:55 --> Input Class Initialized
INFO - 2023-08-30 22:04:55 --> Language Class Initialized
ERROR - 2023-08-30 22:04:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:05:06 --> Config Class Initialized
INFO - 2023-08-30 22:05:06 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:05:06 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:06 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:06 --> URI Class Initialized
INFO - 2023-08-30 22:05:06 --> Router Class Initialized
INFO - 2023-08-30 22:05:06 --> Output Class Initialized
INFO - 2023-08-30 22:05:06 --> Security Class Initialized
DEBUG - 2023-08-30 22:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:06 --> Input Class Initialized
INFO - 2023-08-30 22:05:06 --> Language Class Initialized
ERROR - 2023-08-30 22:05:06 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:05:07 --> Config Class Initialized
INFO - 2023-08-30 22:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:05:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:07 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:07 --> URI Class Initialized
INFO - 2023-08-30 22:05:07 --> Router Class Initialized
INFO - 2023-08-30 22:05:07 --> Output Class Initialized
INFO - 2023-08-30 22:05:07 --> Security Class Initialized
DEBUG - 2023-08-30 22:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:07 --> Input Class Initialized
INFO - 2023-08-30 22:05:07 --> Language Class Initialized
ERROR - 2023-08-30 22:05:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:05:07 --> Config Class Initialized
INFO - 2023-08-30 22:05:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:08 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:09 --> Config Class Initialized
INFO - 2023-08-30 22:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:09 --> URI Class Initialized
INFO - 2023-08-30 22:05:09 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:09 --> Config Class Initialized
INFO - 2023-08-30 22:05:09 --> URI Class Initialized
INFO - 2023-08-30 22:05:09 --> Config Class Initialized
INFO - 2023-08-30 22:05:09 --> Config Class Initialized
INFO - 2023-08-30 22:05:09 --> Hooks Class Initialized
INFO - 2023-08-30 22:05:09 --> Router Class Initialized
INFO - 2023-08-30 22:05:09 --> Router Class Initialized
INFO - 2023-08-30 22:05:09 --> Output Class Initialized
INFO - 2023-08-30 22:05:09 --> Security Class Initialized
DEBUG - 2023-08-30 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:09 --> Input Class Initialized
INFO - 2023-08-30 22:05:09 --> Language Class Initialized
ERROR - 2023-08-30 22:05:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:05:09 --> Hooks Class Initialized
INFO - 2023-08-30 22:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:05:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-30 22:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:09 --> Output Class Initialized
DEBUG - 2023-08-30 22:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:05:09 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:09 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:09 --> Security Class Initialized
INFO - 2023-08-30 22:05:09 --> Utf8 Class Initialized
INFO - 2023-08-30 22:05:09 --> URI Class Initialized
INFO - 2023-08-30 22:05:09 --> Router Class Initialized
INFO - 2023-08-30 22:05:09 --> URI Class Initialized
INFO - 2023-08-30 22:05:09 --> Router Class Initialized
INFO - 2023-08-30 22:05:09 --> Output Class Initialized
INFO - 2023-08-30 22:05:09 --> Security Class Initialized
DEBUG - 2023-08-30 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:09 --> Input Class Initialized
INFO - 2023-08-30 22:05:09 --> Language Class Initialized
ERROR - 2023-08-30 22:05:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:05:09 --> URI Class Initialized
DEBUG - 2023-08-30 22:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:10 --> Router Class Initialized
INFO - 2023-08-30 22:05:10 --> Output Class Initialized
INFO - 2023-08-30 22:05:10 --> Security Class Initialized
INFO - 2023-08-30 22:05:10 --> Output Class Initialized
INFO - 2023-08-30 22:05:10 --> Input Class Initialized
INFO - 2023-08-30 22:05:10 --> Language Class Initialized
ERROR - 2023-08-30 22:05:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:05:10 --> Security Class Initialized
DEBUG - 2023-08-30 22:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-30 22:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:05:10 --> Input Class Initialized
INFO - 2023-08-30 22:05:10 --> Input Class Initialized
INFO - 2023-08-30 22:05:10 --> Language Class Initialized
INFO - 2023-08-30 22:05:10 --> Language Class Initialized
ERROR - 2023-08-30 22:05:10 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-30 22:05:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:05 --> Config Class Initialized
INFO - 2023-08-30 22:06:05 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:05 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:05 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:05 --> URI Class Initialized
DEBUG - 2023-08-30 22:06:05 --> No URI present. Default controller set.
INFO - 2023-08-30 22:06:05 --> Router Class Initialized
INFO - 2023-08-30 22:06:05 --> Output Class Initialized
INFO - 2023-08-30 22:06:05 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:05 --> Input Class Initialized
INFO - 2023-08-30 22:06:05 --> Language Class Initialized
INFO - 2023-08-30 22:06:05 --> Loader Class Initialized
INFO - 2023-08-30 22:06:05 --> Helper loaded: url_helper
INFO - 2023-08-30 22:06:05 --> Helper loaded: file_helper
INFO - 2023-08-30 22:06:05 --> Database Driver Class Initialized
INFO - 2023-08-30 22:06:05 --> Email Class Initialized
DEBUG - 2023-08-30 22:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 22:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 22:06:05 --> Controller Class Initialized
INFO - 2023-08-30 22:06:05 --> Model "Contact_model" initialized
INFO - 2023-08-30 22:06:05 --> Model "Home_model" initialized
INFO - 2023-08-30 22:06:05 --> Helper loaded: download_helper
INFO - 2023-08-30 22:06:05 --> Helper loaded: form_helper
INFO - 2023-08-30 22:06:05 --> Form Validation Class Initialized
INFO - 2023-08-30 22:06:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 22:06:05 --> Final output sent to browser
DEBUG - 2023-08-30 22:06:06 --> Total execution time: 0.8231
INFO - 2023-08-30 22:06:07 --> Config Class Initialized
INFO - 2023-08-30 22:06:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:07 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:07 --> URI Class Initialized
INFO - 2023-08-30 22:06:07 --> Router Class Initialized
INFO - 2023-08-30 22:06:07 --> Output Class Initialized
INFO - 2023-08-30 22:06:07 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:07 --> Input Class Initialized
INFO - 2023-08-30 22:06:07 --> Language Class Initialized
ERROR - 2023-08-30 22:06:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:07 --> Config Class Initialized
INFO - 2023-08-30 22:06:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:07 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:07 --> URI Class Initialized
INFO - 2023-08-30 22:06:07 --> Router Class Initialized
INFO - 2023-08-30 22:06:07 --> Output Class Initialized
INFO - 2023-08-30 22:06:07 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:07 --> Input Class Initialized
INFO - 2023-08-30 22:06:07 --> Language Class Initialized
ERROR - 2023-08-30 22:06:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:06:07 --> Config Class Initialized
INFO - 2023-08-30 22:06:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:07 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:07 --> URI Class Initialized
INFO - 2023-08-30 22:06:07 --> Router Class Initialized
INFO - 2023-08-30 22:06:07 --> Output Class Initialized
INFO - 2023-08-30 22:06:07 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:07 --> Input Class Initialized
INFO - 2023-08-30 22:06:07 --> Language Class Initialized
ERROR - 2023-08-30 22:06:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:06:07 --> Config Class Initialized
INFO - 2023-08-30 22:06:07 --> Hooks Class Initialized
INFO - 2023-08-30 22:06:07 --> Config Class Initialized
INFO - 2023-08-30 22:06:07 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:07 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:07 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:07 --> URI Class Initialized
INFO - 2023-08-30 22:06:07 --> Router Class Initialized
INFO - 2023-08-30 22:06:07 --> Output Class Initialized
INFO - 2023-08-30 22:06:07 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:07 --> Input Class Initialized
INFO - 2023-08-30 22:06:07 --> Language Class Initialized
ERROR - 2023-08-30 22:06:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:08 --> Config Class Initialized
INFO - 2023-08-30 22:06:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:08 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:08 --> URI Class Initialized
INFO - 2023-08-30 22:06:08 --> Router Class Initialized
INFO - 2023-08-30 22:06:08 --> Output Class Initialized
INFO - 2023-08-30 22:06:08 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:08 --> Input Class Initialized
INFO - 2023-08-30 22:06:08 --> Language Class Initialized
ERROR - 2023-08-30 22:06:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:08 --> Config Class Initialized
INFO - 2023-08-30 22:06:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:08 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:08 --> URI Class Initialized
INFO - 2023-08-30 22:06:08 --> Router Class Initialized
INFO - 2023-08-30 22:06:08 --> Output Class Initialized
INFO - 2023-08-30 22:06:08 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:08 --> Input Class Initialized
INFO - 2023-08-30 22:06:08 --> Language Class Initialized
ERROR - 2023-08-30 22:06:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-30 22:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:08 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:09 --> URI Class Initialized
INFO - 2023-08-30 22:06:09 --> Router Class Initialized
INFO - 2023-08-30 22:06:09 --> Output Class Initialized
INFO - 2023-08-30 22:06:09 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:09 --> Input Class Initialized
INFO - 2023-08-30 22:06:09 --> Language Class Initialized
ERROR - 2023-08-30 22:06:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:09 --> Config Class Initialized
INFO - 2023-08-30 22:06:09 --> Hooks Class Initialized
INFO - 2023-08-30 22:06:09 --> Config Class Initialized
DEBUG - 2023-08-30 22:06:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:09 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:09 --> URI Class Initialized
INFO - 2023-08-30 22:06:09 --> Router Class Initialized
INFO - 2023-08-30 22:06:09 --> Output Class Initialized
INFO - 2023-08-30 22:06:09 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:09 --> Input Class Initialized
INFO - 2023-08-30 22:06:09 --> Language Class Initialized
ERROR - 2023-08-30 22:06:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:06:09 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:06:09 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:06:10 --> Utf8 Class Initialized
INFO - 2023-08-30 22:06:10 --> URI Class Initialized
INFO - 2023-08-30 22:06:10 --> Router Class Initialized
INFO - 2023-08-30 22:06:10 --> Output Class Initialized
INFO - 2023-08-30 22:06:10 --> Security Class Initialized
DEBUG - 2023-08-30 22:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:06:10 --> Input Class Initialized
INFO - 2023-08-30 22:06:10 --> Language Class Initialized
ERROR - 2023-08-30 22:06:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-30 22:07:32 --> Config Class Initialized
INFO - 2023-08-30 22:07:32 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:07:32 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:07:32 --> Utf8 Class Initialized
INFO - 2023-08-30 22:07:32 --> URI Class Initialized
DEBUG - 2023-08-30 22:07:32 --> No URI present. Default controller set.
INFO - 2023-08-30 22:07:32 --> Router Class Initialized
INFO - 2023-08-30 22:07:32 --> Output Class Initialized
INFO - 2023-08-30 22:07:32 --> Security Class Initialized
DEBUG - 2023-08-30 22:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:07:32 --> Input Class Initialized
INFO - 2023-08-30 22:07:32 --> Language Class Initialized
INFO - 2023-08-30 22:07:32 --> Loader Class Initialized
INFO - 2023-08-30 22:07:32 --> Helper loaded: url_helper
INFO - 2023-08-30 22:07:32 --> Helper loaded: file_helper
INFO - 2023-08-30 22:07:32 --> Database Driver Class Initialized
INFO - 2023-08-30 22:07:32 --> Email Class Initialized
DEBUG - 2023-08-30 22:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 22:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 22:07:32 --> Controller Class Initialized
INFO - 2023-08-30 22:07:32 --> Model "Contact_model" initialized
INFO - 2023-08-30 22:07:32 --> Model "Home_model" initialized
INFO - 2023-08-30 22:07:32 --> Helper loaded: download_helper
INFO - 2023-08-30 22:07:32 --> Helper loaded: form_helper
INFO - 2023-08-30 22:07:32 --> Form Validation Class Initialized
INFO - 2023-08-30 22:07:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 22:07:32 --> Final output sent to browser
DEBUG - 2023-08-30 22:07:33 --> Total execution time: 0.4826
INFO - 2023-08-30 22:07:33 --> Config Class Initialized
INFO - 2023-08-30 22:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:07:33 --> Utf8 Class Initialized
INFO - 2023-08-30 22:07:33 --> URI Class Initialized
INFO - 2023-08-30 22:07:33 --> Router Class Initialized
INFO - 2023-08-30 22:07:33 --> Output Class Initialized
INFO - 2023-08-30 22:07:33 --> Security Class Initialized
DEBUG - 2023-08-30 22:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:07:33 --> Input Class Initialized
INFO - 2023-08-30 22:07:33 --> Language Class Initialized
ERROR - 2023-08-30 22:07:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:07:33 --> Config Class Initialized
INFO - 2023-08-30 22:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:07:33 --> Utf8 Class Initialized
INFO - 2023-08-30 22:07:33 --> URI Class Initialized
INFO - 2023-08-30 22:07:33 --> Router Class Initialized
INFO - 2023-08-30 22:07:33 --> Output Class Initialized
INFO - 2023-08-30 22:07:33 --> Security Class Initialized
DEBUG - 2023-08-30 22:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:07:33 --> Input Class Initialized
INFO - 2023-08-30 22:07:33 --> Language Class Initialized
ERROR - 2023-08-30 22:07:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:09:19 --> Config Class Initialized
INFO - 2023-08-30 22:09:19 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:09:19 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:09:19 --> Utf8 Class Initialized
INFO - 2023-08-30 22:09:19 --> URI Class Initialized
DEBUG - 2023-08-30 22:09:19 --> No URI present. Default controller set.
INFO - 2023-08-30 22:09:19 --> Router Class Initialized
INFO - 2023-08-30 22:09:20 --> Output Class Initialized
INFO - 2023-08-30 22:09:20 --> Security Class Initialized
DEBUG - 2023-08-30 22:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:09:20 --> Input Class Initialized
INFO - 2023-08-30 22:09:20 --> Language Class Initialized
INFO - 2023-08-30 22:09:20 --> Loader Class Initialized
INFO - 2023-08-30 22:09:20 --> Helper loaded: url_helper
INFO - 2023-08-30 22:09:20 --> Helper loaded: file_helper
INFO - 2023-08-30 22:09:20 --> Database Driver Class Initialized
INFO - 2023-08-30 22:09:20 --> Email Class Initialized
DEBUG - 2023-08-30 22:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 22:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 22:09:20 --> Controller Class Initialized
INFO - 2023-08-30 22:09:20 --> Model "Contact_model" initialized
INFO - 2023-08-30 22:09:20 --> Model "Home_model" initialized
INFO - 2023-08-30 22:09:20 --> Helper loaded: download_helper
INFO - 2023-08-30 22:09:20 --> Helper loaded: form_helper
INFO - 2023-08-30 22:09:20 --> Form Validation Class Initialized
INFO - 2023-08-30 22:09:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-30 22:09:20 --> Final output sent to browser
DEBUG - 2023-08-30 22:09:20 --> Total execution time: 0.8822
INFO - 2023-08-30 22:09:22 --> Config Class Initialized
INFO - 2023-08-30 22:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:09:22 --> Utf8 Class Initialized
INFO - 2023-08-30 22:09:22 --> URI Class Initialized
INFO - 2023-08-30 22:09:22 --> Router Class Initialized
INFO - 2023-08-30 22:09:22 --> Output Class Initialized
INFO - 2023-08-30 22:09:22 --> Security Class Initialized
DEBUG - 2023-08-30 22:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:09:22 --> Input Class Initialized
INFO - 2023-08-30 22:09:22 --> Language Class Initialized
ERROR - 2023-08-30 22:09:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-30 22:09:22 --> Config Class Initialized
INFO - 2023-08-30 22:09:22 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:09:22 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:09:22 --> Utf8 Class Initialized
INFO - 2023-08-30 22:09:22 --> URI Class Initialized
INFO - 2023-08-30 22:09:22 --> Router Class Initialized
INFO - 2023-08-30 22:09:22 --> Output Class Initialized
INFO - 2023-08-30 22:09:22 --> Security Class Initialized
DEBUG - 2023-08-30 22:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:09:22 --> Input Class Initialized
INFO - 2023-08-30 22:09:22 --> Language Class Initialized
ERROR - 2023-08-30 22:09:22 --> 404 Page Not Found: Assets/images
