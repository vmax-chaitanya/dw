<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-30 11:24:55 --> Config Class Initialized
INFO - 2023-08-30 11:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:24:55 --> Utf8 Class Initialized
INFO - 2023-08-30 11:24:55 --> URI Class Initialized
INFO - 2023-08-30 11:24:55 --> Router Class Initialized
INFO - 2023-08-30 11:24:55 --> Output Class Initialized
INFO - 2023-08-30 11:24:55 --> Security Class Initialized
DEBUG - 2023-08-30 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:24:55 --> Input Class Initialized
INFO - 2023-08-30 11:24:55 --> Language Class Initialized
INFO - 2023-08-30 11:24:55 --> Loader Class Initialized
INFO - 2023-08-30 11:24:55 --> Helper loaded: url_helper
INFO - 2023-08-30 11:24:55 --> Helper loaded: file_helper
INFO - 2023-08-30 11:24:55 --> Database Driver Class Initialized
INFO - 2023-08-30 11:24:55 --> Email Class Initialized
DEBUG - 2023-08-30 11:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:24:55 --> Controller Class Initialized
INFO - 2023-08-30 11:24:55 --> Config Class Initialized
INFO - 2023-08-30 11:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:24:55 --> Utf8 Class Initialized
INFO - 2023-08-30 11:24:55 --> URI Class Initialized
INFO - 2023-08-30 11:24:55 --> Router Class Initialized
INFO - 2023-08-30 11:24:55 --> Output Class Initialized
INFO - 2023-08-30 11:24:55 --> Security Class Initialized
DEBUG - 2023-08-30 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:24:55 --> Input Class Initialized
INFO - 2023-08-30 11:24:55 --> Language Class Initialized
INFO - 2023-08-30 11:24:55 --> Loader Class Initialized
INFO - 2023-08-30 11:24:55 --> Helper loaded: url_helper
INFO - 2023-08-30 11:24:55 --> Helper loaded: file_helper
INFO - 2023-08-30 11:24:55 --> Database Driver Class Initialized
INFO - 2023-08-30 11:24:55 --> Email Class Initialized
DEBUG - 2023-08-30 11:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:24:55 --> Controller Class Initialized
INFO - 2023-08-30 11:24:55 --> Model "User_model" initialized
INFO - 2023-08-30 11:24:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-30 11:24:55 --> Final output sent to browser
DEBUG - 2023-08-30 11:24:55 --> Total execution time: 0.0618
INFO - 2023-08-30 11:24:56 --> Config Class Initialized
INFO - 2023-08-30 11:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:24:56 --> Utf8 Class Initialized
INFO - 2023-08-30 11:24:56 --> URI Class Initialized
INFO - 2023-08-30 11:24:56 --> Router Class Initialized
INFO - 2023-08-30 11:24:56 --> Output Class Initialized
INFO - 2023-08-30 11:24:56 --> Security Class Initialized
DEBUG - 2023-08-30 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:24:56 --> Input Class Initialized
INFO - 2023-08-30 11:24:56 --> Language Class Initialized
ERROR - 2023-08-30 11:24:56 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-30 11:25:08 --> Config Class Initialized
INFO - 2023-08-30 11:25:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:08 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:08 --> URI Class Initialized
INFO - 2023-08-30 11:25:08 --> Router Class Initialized
INFO - 2023-08-30 11:25:08 --> Output Class Initialized
INFO - 2023-08-30 11:25:08 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:08 --> Input Class Initialized
INFO - 2023-08-30 11:25:08 --> Language Class Initialized
INFO - 2023-08-30 11:25:08 --> Loader Class Initialized
INFO - 2023-08-30 11:25:08 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:08 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:08 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:08 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:08 --> Controller Class Initialized
INFO - 2023-08-30 11:25:08 --> Model "User_model" initialized
INFO - 2023-08-30 11:25:08 --> Config Class Initialized
INFO - 2023-08-30 11:25:08 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:08 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:08 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:08 --> URI Class Initialized
INFO - 2023-08-30 11:25:08 --> Router Class Initialized
INFO - 2023-08-30 11:25:08 --> Output Class Initialized
INFO - 2023-08-30 11:25:08 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:08 --> Input Class Initialized
INFO - 2023-08-30 11:25:08 --> Language Class Initialized
INFO - 2023-08-30 11:25:08 --> Loader Class Initialized
INFO - 2023-08-30 11:25:08 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:08 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:08 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:08 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:08 --> Controller Class Initialized
INFO - 2023-08-30 11:25:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-30 11:25:08 --> Final output sent to browser
DEBUG - 2023-08-30 11:25:08 --> Total execution time: 0.0417
INFO - 2023-08-30 11:25:11 --> Config Class Initialized
INFO - 2023-08-30 11:25:11 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:11 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:11 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:11 --> URI Class Initialized
INFO - 2023-08-30 11:25:11 --> Router Class Initialized
INFO - 2023-08-30 11:25:11 --> Output Class Initialized
INFO - 2023-08-30 11:25:11 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:11 --> Input Class Initialized
INFO - 2023-08-30 11:25:11 --> Language Class Initialized
INFO - 2023-08-30 11:25:11 --> Loader Class Initialized
INFO - 2023-08-30 11:25:11 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:11 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:11 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:11 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:11 --> Controller Class Initialized
INFO - 2023-08-30 11:25:11 --> Model "Services_model" initialized
INFO - 2023-08-30 11:25:11 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:11 --> Form Validation Class Initialized
INFO - 2023-08-30 11:25:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:25:11 --> Final output sent to browser
DEBUG - 2023-08-30 11:25:11 --> Total execution time: 0.0884
INFO - 2023-08-30 11:25:14 --> Config Class Initialized
INFO - 2023-08-30 11:25:14 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:14 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:14 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:14 --> URI Class Initialized
INFO - 2023-08-30 11:25:14 --> Router Class Initialized
INFO - 2023-08-30 11:25:14 --> Output Class Initialized
INFO - 2023-08-30 11:25:14 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:14 --> Input Class Initialized
INFO - 2023-08-30 11:25:14 --> Language Class Initialized
INFO - 2023-08-30 11:25:14 --> Loader Class Initialized
INFO - 2023-08-30 11:25:14 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:14 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:14 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:14 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:14 --> Controller Class Initialized
INFO - 2023-08-30 11:25:14 --> Model "Services_model" initialized
INFO - 2023-08-30 11:25:14 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:14 --> Form Validation Class Initialized
INFO - 2023-08-30 11:25:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:25:14 --> Final output sent to browser
DEBUG - 2023-08-30 11:25:14 --> Total execution time: 0.0478
INFO - 2023-08-30 11:25:22 --> Config Class Initialized
INFO - 2023-08-30 11:25:22 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:22 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:22 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:22 --> URI Class Initialized
INFO - 2023-08-30 11:25:22 --> Router Class Initialized
INFO - 2023-08-30 11:25:22 --> Output Class Initialized
INFO - 2023-08-30 11:25:22 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:22 --> Input Class Initialized
INFO - 2023-08-30 11:25:22 --> Language Class Initialized
INFO - 2023-08-30 11:25:22 --> Loader Class Initialized
INFO - 2023-08-30 11:25:22 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:22 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:22 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:22 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:22 --> Controller Class Initialized
INFO - 2023-08-30 11:25:22 --> Model "Services_model" initialized
INFO - 2023-08-30 11:25:22 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:22 --> Form Validation Class Initialized
INFO - 2023-08-30 11:25:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-30 11:25:22 --> Final output sent to browser
DEBUG - 2023-08-30 11:25:22 --> Total execution time: 0.0591
INFO - 2023-08-30 11:25:22 --> Config Class Initialized
INFO - 2023-08-30 11:25:22 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:22 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:22 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:22 --> URI Class Initialized
INFO - 2023-08-30 11:25:22 --> Router Class Initialized
INFO - 2023-08-30 11:25:22 --> Output Class Initialized
INFO - 2023-08-30 11:25:22 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:22 --> Input Class Initialized
INFO - 2023-08-30 11:25:22 --> Language Class Initialized
ERROR - 2023-08-30 11:25:22 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-30 11:25:32 --> Config Class Initialized
INFO - 2023-08-30 11:25:32 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:32 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:32 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:32 --> URI Class Initialized
INFO - 2023-08-30 11:25:32 --> Router Class Initialized
INFO - 2023-08-30 11:25:32 --> Output Class Initialized
INFO - 2023-08-30 11:25:32 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:32 --> Input Class Initialized
INFO - 2023-08-30 11:25:32 --> Language Class Initialized
INFO - 2023-08-30 11:25:32 --> Loader Class Initialized
INFO - 2023-08-30 11:25:32 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:32 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:32 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:32 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:32 --> Controller Class Initialized
INFO - 2023-08-30 11:25:32 --> Model "Services_model" initialized
INFO - 2023-08-30 11:25:32 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:32 --> Form Validation Class Initialized
INFO - 2023-08-30 11:25:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-30 11:25:32 --> Config Class Initialized
INFO - 2023-08-30 11:25:32 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:32 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:32 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:32 --> URI Class Initialized
INFO - 2023-08-30 11:25:32 --> Router Class Initialized
INFO - 2023-08-30 11:25:32 --> Output Class Initialized
INFO - 2023-08-30 11:25:32 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:32 --> Input Class Initialized
INFO - 2023-08-30 11:25:32 --> Language Class Initialized
INFO - 2023-08-30 11:25:32 --> Loader Class Initialized
INFO - 2023-08-30 11:25:32 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:32 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:32 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:32 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:32 --> Controller Class Initialized
INFO - 2023-08-30 11:25:32 --> Model "Services_model" initialized
INFO - 2023-08-30 11:25:32 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:32 --> Form Validation Class Initialized
INFO - 2023-08-30 11:25:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:25:32 --> Final output sent to browser
DEBUG - 2023-08-30 11:25:32 --> Total execution time: 0.0495
INFO - 2023-08-30 11:25:36 --> Config Class Initialized
INFO - 2023-08-30 11:25:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:25:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:25:36 --> Utf8 Class Initialized
INFO - 2023-08-30 11:25:36 --> URI Class Initialized
INFO - 2023-08-30 11:25:36 --> Router Class Initialized
INFO - 2023-08-30 11:25:36 --> Output Class Initialized
INFO - 2023-08-30 11:25:36 --> Security Class Initialized
DEBUG - 2023-08-30 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:25:36 --> Input Class Initialized
INFO - 2023-08-30 11:25:36 --> Language Class Initialized
INFO - 2023-08-30 11:25:36 --> Loader Class Initialized
INFO - 2023-08-30 11:25:36 --> Helper loaded: url_helper
INFO - 2023-08-30 11:25:36 --> Helper loaded: file_helper
INFO - 2023-08-30 11:25:36 --> Database Driver Class Initialized
INFO - 2023-08-30 11:25:36 --> Email Class Initialized
DEBUG - 2023-08-30 11:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:25:36 --> Controller Class Initialized
INFO - 2023-08-30 11:25:36 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:25:36 --> Helper loaded: form_helper
INFO - 2023-08-30 11:25:36 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:25:36 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `services_cards`
WHERE `type` = 1
INFO - 2023-08-30 11:25:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-30 11:26:15 --> Config Class Initialized
INFO - 2023-08-30 11:26:15 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:26:15 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:26:15 --> Utf8 Class Initialized
INFO - 2023-08-30 11:26:15 --> URI Class Initialized
INFO - 2023-08-30 11:26:15 --> Router Class Initialized
INFO - 2023-08-30 11:26:15 --> Output Class Initialized
INFO - 2023-08-30 11:26:15 --> Security Class Initialized
DEBUG - 2023-08-30 11:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:26:15 --> Input Class Initialized
INFO - 2023-08-30 11:26:15 --> Language Class Initialized
INFO - 2023-08-30 11:26:15 --> Loader Class Initialized
INFO - 2023-08-30 11:26:15 --> Helper loaded: url_helper
INFO - 2023-08-30 11:26:15 --> Helper loaded: file_helper
INFO - 2023-08-30 11:26:15 --> Database Driver Class Initialized
INFO - 2023-08-30 11:26:15 --> Email Class Initialized
DEBUG - 2023-08-30 11:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:26:15 --> Controller Class Initialized
INFO - 2023-08-30 11:26:15 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:26:15 --> Helper loaded: form_helper
INFO - 2023-08-30 11:26:15 --> Form Validation Class Initialized
INFO - 2023-08-30 11:27:06 --> Config Class Initialized
INFO - 2023-08-30 11:27:06 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:27:06 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:27:06 --> Utf8 Class Initialized
INFO - 2023-08-30 11:27:06 --> URI Class Initialized
INFO - 2023-08-30 11:27:06 --> Router Class Initialized
INFO - 2023-08-30 11:27:06 --> Output Class Initialized
INFO - 2023-08-30 11:27:06 --> Security Class Initialized
DEBUG - 2023-08-30 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:27:06 --> Input Class Initialized
INFO - 2023-08-30 11:27:06 --> Language Class Initialized
INFO - 2023-08-30 11:27:06 --> Loader Class Initialized
INFO - 2023-08-30 11:27:06 --> Helper loaded: url_helper
INFO - 2023-08-30 11:27:06 --> Helper loaded: file_helper
INFO - 2023-08-30 11:27:06 --> Database Driver Class Initialized
INFO - 2023-08-30 11:27:06 --> Email Class Initialized
DEBUG - 2023-08-30 11:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:27:06 --> Controller Class Initialized
INFO - 2023-08-30 11:27:06 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:27:06 --> Helper loaded: form_helper
INFO - 2023-08-30 11:27:06 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:27:06 --> Severity: Warning --> Undefined variable $service_cards C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
ERROR - 2023-08-30 11:27:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
INFO - 2023-08-30 11:27:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:27:06 --> Final output sent to browser
DEBUG - 2023-08-30 11:27:06 --> Total execution time: 0.0520
INFO - 2023-08-30 11:27:06 --> Config Class Initialized
INFO - 2023-08-30 11:27:06 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:27:06 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:27:06 --> Utf8 Class Initialized
INFO - 2023-08-30 11:27:06 --> URI Class Initialized
INFO - 2023-08-30 11:27:06 --> Router Class Initialized
INFO - 2023-08-30 11:27:06 --> Output Class Initialized
INFO - 2023-08-30 11:27:06 --> Security Class Initialized
DEBUG - 2023-08-30 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:27:06 --> Input Class Initialized
INFO - 2023-08-30 11:27:06 --> Language Class Initialized
ERROR - 2023-08-30 11:27:06 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-08-30 11:27:24 --> Config Class Initialized
INFO - 2023-08-30 11:27:24 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:27:24 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:27:24 --> Utf8 Class Initialized
INFO - 2023-08-30 11:27:24 --> URI Class Initialized
INFO - 2023-08-30 11:27:24 --> Router Class Initialized
INFO - 2023-08-30 11:27:24 --> Output Class Initialized
INFO - 2023-08-30 11:27:24 --> Security Class Initialized
DEBUG - 2023-08-30 11:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:27:24 --> Input Class Initialized
INFO - 2023-08-30 11:27:24 --> Language Class Initialized
INFO - 2023-08-30 11:27:24 --> Loader Class Initialized
INFO - 2023-08-30 11:27:24 --> Helper loaded: url_helper
INFO - 2023-08-30 11:27:24 --> Helper loaded: file_helper
INFO - 2023-08-30 11:27:24 --> Database Driver Class Initialized
INFO - 2023-08-30 11:27:24 --> Email Class Initialized
DEBUG - 2023-08-30 11:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:27:24 --> Controller Class Initialized
INFO - 2023-08-30 11:27:24 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:27:24 --> Helper loaded: form_helper
INFO - 2023-08-30 11:27:24 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:27:24 --> Severity: Warning --> Undefined variable $service_cards C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
ERROR - 2023-08-30 11:27:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
INFO - 2023-08-30 11:27:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:27:24 --> Final output sent to browser
DEBUG - 2023-08-30 11:27:24 --> Total execution time: 0.0718
INFO - 2023-08-30 11:27:26 --> Config Class Initialized
INFO - 2023-08-30 11:27:26 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:27:26 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:27:26 --> Utf8 Class Initialized
INFO - 2023-08-30 11:27:26 --> URI Class Initialized
INFO - 2023-08-30 11:27:26 --> Router Class Initialized
INFO - 2023-08-30 11:27:26 --> Output Class Initialized
INFO - 2023-08-30 11:27:26 --> Security Class Initialized
DEBUG - 2023-08-30 11:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:27:26 --> Input Class Initialized
INFO - 2023-08-30 11:27:26 --> Language Class Initialized
INFO - 2023-08-30 11:27:26 --> Loader Class Initialized
INFO - 2023-08-30 11:27:26 --> Helper loaded: url_helper
INFO - 2023-08-30 11:27:26 --> Helper loaded: file_helper
INFO - 2023-08-30 11:27:26 --> Database Driver Class Initialized
INFO - 2023-08-30 11:27:26 --> Email Class Initialized
DEBUG - 2023-08-30 11:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:27:26 --> Controller Class Initialized
INFO - 2023-08-30 11:27:26 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:27:26 --> Helper loaded: form_helper
INFO - 2023-08-30 11:27:26 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:27:26 --> Severity: Warning --> Undefined variable $service_cards C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
ERROR - 2023-08-30 11:27:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
INFO - 2023-08-30 11:27:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:27:26 --> Final output sent to browser
DEBUG - 2023-08-30 11:27:26 --> Total execution time: 0.0724
INFO - 2023-08-30 11:28:02 --> Config Class Initialized
INFO - 2023-08-30 11:28:02 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:02 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:02 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:02 --> URI Class Initialized
INFO - 2023-08-30 11:28:02 --> Router Class Initialized
INFO - 2023-08-30 11:28:02 --> Output Class Initialized
INFO - 2023-08-30 11:28:02 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:02 --> Input Class Initialized
INFO - 2023-08-30 11:28:02 --> Language Class Initialized
INFO - 2023-08-30 11:28:02 --> Loader Class Initialized
INFO - 2023-08-30 11:28:02 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:02 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:02 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:02 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:02 --> Controller Class Initialized
INFO - 2023-08-30 11:28:02 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:28:02 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:02 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:28:02 --> Severity: Warning --> Undefined variable $service_cards C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
ERROR - 2023-08-30 11:28:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
INFO - 2023-08-30 11:28:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:28:02 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:02 --> Total execution time: 0.0644
INFO - 2023-08-30 11:28:18 --> Config Class Initialized
INFO - 2023-08-30 11:28:18 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:18 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:18 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:18 --> URI Class Initialized
INFO - 2023-08-30 11:28:18 --> Router Class Initialized
INFO - 2023-08-30 11:28:18 --> Output Class Initialized
INFO - 2023-08-30 11:28:18 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:18 --> Input Class Initialized
INFO - 2023-08-30 11:28:18 --> Language Class Initialized
INFO - 2023-08-30 11:28:18 --> Loader Class Initialized
INFO - 2023-08-30 11:28:18 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:18 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:18 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:18 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:18 --> Controller Class Initialized
INFO - 2023-08-30 11:28:18 --> Model "Services_model" initialized
INFO - 2023-08-30 11:28:18 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:18 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:28:18 --> Severity: Warning --> Undefined variable $service_cards_type_1 C:\xampp\htdocs\dw\application\views\admin\services_list.php 67
ERROR - 2023-08-30 11:28:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_list.php 67
INFO - 2023-08-30 11:28:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:28:18 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:18 --> Total execution time: 0.0612
INFO - 2023-08-30 11:28:20 --> Config Class Initialized
INFO - 2023-08-30 11:28:20 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:20 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:20 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:20 --> URI Class Initialized
INFO - 2023-08-30 11:28:20 --> Router Class Initialized
INFO - 2023-08-30 11:28:20 --> Output Class Initialized
INFO - 2023-08-30 11:28:20 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:20 --> Input Class Initialized
INFO - 2023-08-30 11:28:20 --> Language Class Initialized
INFO - 2023-08-30 11:28:20 --> Loader Class Initialized
INFO - 2023-08-30 11:28:20 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:20 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:20 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:20 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:20 --> Controller Class Initialized
INFO - 2023-08-30 11:28:20 --> Model "Services_model" initialized
INFO - 2023-08-30 11:28:20 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:20 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:28:20 --> Severity: Warning --> Undefined variable $service_cards_type_1 C:\xampp\htdocs\dw\application\views\admin\services_list.php 67
ERROR - 2023-08-30 11:28:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_list.php 67
INFO - 2023-08-30 11:28:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:28:20 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:20 --> Total execution time: 0.0488
INFO - 2023-08-30 11:28:29 --> Config Class Initialized
INFO - 2023-08-30 11:28:29 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:29 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:29 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:29 --> URI Class Initialized
INFO - 2023-08-30 11:28:29 --> Router Class Initialized
INFO - 2023-08-30 11:28:29 --> Output Class Initialized
INFO - 2023-08-30 11:28:29 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:29 --> Input Class Initialized
INFO - 2023-08-30 11:28:29 --> Language Class Initialized
INFO - 2023-08-30 11:28:29 --> Loader Class Initialized
INFO - 2023-08-30 11:28:29 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:29 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:29 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:29 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:29 --> Controller Class Initialized
INFO - 2023-08-30 11:28:29 --> Model "Services_model" initialized
INFO - 2023-08-30 11:28:29 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:29 --> Form Validation Class Initialized
INFO - 2023-08-30 11:28:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 11:28:29 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:29 --> Total execution time: 0.0485
INFO - 2023-08-30 11:28:32 --> Config Class Initialized
INFO - 2023-08-30 11:28:32 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:32 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:32 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:32 --> URI Class Initialized
INFO - 2023-08-30 11:28:32 --> Router Class Initialized
INFO - 2023-08-30 11:28:32 --> Output Class Initialized
INFO - 2023-08-30 11:28:32 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:32 --> Input Class Initialized
INFO - 2023-08-30 11:28:32 --> Language Class Initialized
INFO - 2023-08-30 11:28:32 --> Loader Class Initialized
INFO - 2023-08-30 11:28:32 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:32 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:32 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:32 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:32 --> Controller Class Initialized
INFO - 2023-08-30 11:28:32 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:28:32 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:32 --> Form Validation Class Initialized
ERROR - 2023-08-30 11:28:32 --> Severity: Warning --> Undefined variable $service_cards C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
ERROR - 2023-08-30 11:28:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\services_cards_list.php 67
INFO - 2023-08-30 11:28:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:28:32 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:32 --> Total execution time: 0.0491
INFO - 2023-08-30 11:28:52 --> Config Class Initialized
INFO - 2023-08-30 11:28:52 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:28:52 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:28:52 --> Utf8 Class Initialized
INFO - 2023-08-30 11:28:52 --> URI Class Initialized
INFO - 2023-08-30 11:28:52 --> Router Class Initialized
INFO - 2023-08-30 11:28:52 --> Output Class Initialized
INFO - 2023-08-30 11:28:52 --> Security Class Initialized
DEBUG - 2023-08-30 11:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:28:52 --> Input Class Initialized
INFO - 2023-08-30 11:28:52 --> Language Class Initialized
INFO - 2023-08-30 11:28:52 --> Loader Class Initialized
INFO - 2023-08-30 11:28:52 --> Helper loaded: url_helper
INFO - 2023-08-30 11:28:52 --> Helper loaded: file_helper
INFO - 2023-08-30 11:28:52 --> Database Driver Class Initialized
INFO - 2023-08-30 11:28:52 --> Email Class Initialized
DEBUG - 2023-08-30 11:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:28:52 --> Controller Class Initialized
INFO - 2023-08-30 11:28:52 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:28:52 --> Helper loaded: form_helper
INFO - 2023-08-30 11:28:52 --> Form Validation Class Initialized
INFO - 2023-08-30 11:28:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:28:52 --> Final output sent to browser
DEBUG - 2023-08-30 11:28:52 --> Total execution time: 0.0656
INFO - 2023-08-30 11:29:36 --> Config Class Initialized
INFO - 2023-08-30 11:29:36 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:29:36 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:29:36 --> Utf8 Class Initialized
INFO - 2023-08-30 11:29:36 --> URI Class Initialized
INFO - 2023-08-30 11:29:36 --> Router Class Initialized
INFO - 2023-08-30 11:29:36 --> Output Class Initialized
INFO - 2023-08-30 11:29:36 --> Security Class Initialized
DEBUG - 2023-08-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:29:36 --> Input Class Initialized
INFO - 2023-08-30 11:29:36 --> Language Class Initialized
INFO - 2023-08-30 11:29:36 --> Loader Class Initialized
INFO - 2023-08-30 11:29:36 --> Helper loaded: url_helper
INFO - 2023-08-30 11:29:36 --> Helper loaded: file_helper
INFO - 2023-08-30 11:29:36 --> Database Driver Class Initialized
INFO - 2023-08-30 11:29:36 --> Email Class Initialized
DEBUG - 2023-08-30 11:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:29:36 --> Controller Class Initialized
INFO - 2023-08-30 11:29:36 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:29:36 --> Helper loaded: form_helper
INFO - 2023-08-30 11:29:36 --> Form Validation Class Initialized
INFO - 2023-08-30 11:29:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:29:36 --> Final output sent to browser
DEBUG - 2023-08-30 11:29:36 --> Total execution time: 0.0487
INFO - 2023-08-30 11:30:02 --> Config Class Initialized
INFO - 2023-08-30 11:30:02 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:02 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:02 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:02 --> URI Class Initialized
INFO - 2023-08-30 11:30:02 --> Router Class Initialized
INFO - 2023-08-30 11:30:02 --> Output Class Initialized
INFO - 2023-08-30 11:30:02 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:02 --> Input Class Initialized
INFO - 2023-08-30 11:30:02 --> Language Class Initialized
INFO - 2023-08-30 11:30:02 --> Loader Class Initialized
INFO - 2023-08-30 11:30:02 --> Helper loaded: url_helper
INFO - 2023-08-30 11:30:02 --> Helper loaded: file_helper
INFO - 2023-08-30 11:30:02 --> Database Driver Class Initialized
INFO - 2023-08-30 11:30:02 --> Email Class Initialized
DEBUG - 2023-08-30 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:30:02 --> Controller Class Initialized
INFO - 2023-08-30 11:30:02 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:30:02 --> Helper loaded: form_helper
INFO - 2023-08-30 11:30:02 --> Form Validation Class Initialized
INFO - 2023-08-30 11:30:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:30:02 --> Final output sent to browser
DEBUG - 2023-08-30 11:30:02 --> Total execution time: 0.0481
INFO - 2023-08-30 11:30:05 --> Config Class Initialized
INFO - 2023-08-30 11:30:05 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:05 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:05 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:05 --> URI Class Initialized
INFO - 2023-08-30 11:30:05 --> Router Class Initialized
INFO - 2023-08-30 11:30:05 --> Output Class Initialized
INFO - 2023-08-30 11:30:05 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:05 --> Input Class Initialized
INFO - 2023-08-30 11:30:05 --> Language Class Initialized
INFO - 2023-08-30 11:30:05 --> Loader Class Initialized
INFO - 2023-08-30 11:30:05 --> Helper loaded: url_helper
INFO - 2023-08-30 11:30:05 --> Helper loaded: file_helper
INFO - 2023-08-30 11:30:05 --> Database Driver Class Initialized
INFO - 2023-08-30 11:30:05 --> Email Class Initialized
DEBUG - 2023-08-30 11:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:30:05 --> Controller Class Initialized
INFO - 2023-08-30 11:30:05 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:30:05 --> Helper loaded: form_helper
INFO - 2023-08-30 11:30:05 --> Form Validation Class Initialized
INFO - 2023-08-30 11:30:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:30:05 --> Final output sent to browser
DEBUG - 2023-08-30 11:30:05 --> Total execution time: 0.0474
INFO - 2023-08-30 11:30:13 --> Config Class Initialized
INFO - 2023-08-30 11:30:13 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:13 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:13 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:13 --> URI Class Initialized
INFO - 2023-08-30 11:30:13 --> Router Class Initialized
INFO - 2023-08-30 11:30:13 --> Output Class Initialized
INFO - 2023-08-30 11:30:13 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:13 --> Input Class Initialized
INFO - 2023-08-30 11:30:13 --> Language Class Initialized
INFO - 2023-08-30 11:30:13 --> Loader Class Initialized
INFO - 2023-08-30 11:30:13 --> Helper loaded: url_helper
INFO - 2023-08-30 11:30:13 --> Helper loaded: file_helper
INFO - 2023-08-30 11:30:13 --> Database Driver Class Initialized
INFO - 2023-08-30 11:30:14 --> Email Class Initialized
DEBUG - 2023-08-30 11:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:30:14 --> Controller Class Initialized
INFO - 2023-08-30 11:30:14 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:30:14 --> Helper loaded: form_helper
INFO - 2023-08-30 11:30:14 --> Form Validation Class Initialized
INFO - 2023-08-30 11:30:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:30:14 --> Final output sent to browser
DEBUG - 2023-08-30 11:30:14 --> Total execution time: 0.0625
INFO - 2023-08-30 11:30:44 --> Config Class Initialized
INFO - 2023-08-30 11:30:44 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:44 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:44 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:44 --> URI Class Initialized
INFO - 2023-08-30 11:30:44 --> Router Class Initialized
INFO - 2023-08-30 11:30:44 --> Output Class Initialized
INFO - 2023-08-30 11:30:44 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:44 --> Input Class Initialized
INFO - 2023-08-30 11:30:44 --> Language Class Initialized
INFO - 2023-08-30 11:30:44 --> Loader Class Initialized
INFO - 2023-08-30 11:30:44 --> Helper loaded: url_helper
INFO - 2023-08-30 11:30:44 --> Helper loaded: file_helper
INFO - 2023-08-30 11:30:44 --> Database Driver Class Initialized
INFO - 2023-08-30 11:30:44 --> Email Class Initialized
DEBUG - 2023-08-30 11:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 11:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 11:30:44 --> Controller Class Initialized
INFO - 2023-08-30 11:30:44 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 11:30:44 --> Helper loaded: form_helper
INFO - 2023-08-30 11:30:44 --> Form Validation Class Initialized
INFO - 2023-08-30 11:30:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 11:30:44 --> Final output sent to browser
DEBUG - 2023-08-30 11:30:44 --> Total execution time: 0.0473
INFO - 2023-08-30 11:30:55 --> Config Class Initialized
INFO - 2023-08-30 11:30:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:55 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:55 --> URI Class Initialized
INFO - 2023-08-30 11:30:55 --> Router Class Initialized
INFO - 2023-08-30 11:30:55 --> Output Class Initialized
INFO - 2023-08-30 11:30:55 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:55 --> Input Class Initialized
INFO - 2023-08-30 11:30:55 --> Language Class Initialized
ERROR - 2023-08-30 11:30:55 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-30 11:30:55 --> Config Class Initialized
INFO - 2023-08-30 11:30:55 --> Hooks Class Initialized
DEBUG - 2023-08-30 11:30:55 --> UTF-8 Support Enabled
INFO - 2023-08-30 11:30:55 --> Utf8 Class Initialized
INFO - 2023-08-30 11:30:55 --> URI Class Initialized
INFO - 2023-08-30 11:30:55 --> Router Class Initialized
INFO - 2023-08-30 11:30:55 --> Output Class Initialized
INFO - 2023-08-30 11:30:55 --> Security Class Initialized
DEBUG - 2023-08-30 11:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 11:30:55 --> Input Class Initialized
INFO - 2023-08-30 11:30:55 --> Language Class Initialized
ERROR - 2023-08-30 11:30:55 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-30 12:07:18 --> Config Class Initialized
INFO - 2023-08-30 12:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:18 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:18 --> URI Class Initialized
INFO - 2023-08-30 12:07:18 --> Router Class Initialized
INFO - 2023-08-30 12:07:18 --> Output Class Initialized
INFO - 2023-08-30 12:07:18 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:18 --> Input Class Initialized
INFO - 2023-08-30 12:07:18 --> Language Class Initialized
INFO - 2023-08-30 12:07:18 --> Loader Class Initialized
INFO - 2023-08-30 12:07:18 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:18 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:18 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:18 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:18 --> Controller Class Initialized
INFO - 2023-08-30 12:07:18 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 12:07:18 --> Helper loaded: form_helper
INFO - 2023-08-30 12:07:18 --> Form Validation Class Initialized
INFO - 2023-08-30 12:07:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 12:07:18 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:18 --> Total execution time: 0.0726
INFO - 2023-08-30 12:07:20 --> Config Class Initialized
INFO - 2023-08-30 12:07:20 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:20 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:20 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:20 --> URI Class Initialized
INFO - 2023-08-30 12:07:20 --> Router Class Initialized
INFO - 2023-08-30 12:07:20 --> Output Class Initialized
INFO - 2023-08-30 12:07:20 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:20 --> Input Class Initialized
INFO - 2023-08-30 12:07:20 --> Language Class Initialized
INFO - 2023-08-30 12:07:20 --> Loader Class Initialized
INFO - 2023-08-30 12:07:20 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:20 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:20 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:20 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:20 --> Controller Class Initialized
INFO - 2023-08-30 12:07:20 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 12:07:20 --> Helper loaded: form_helper
INFO - 2023-08-30 12:07:20 --> Form Validation Class Initialized
INFO - 2023-08-30 12:07:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 12:07:20 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:20 --> Total execution time: 0.0608
INFO - 2023-08-30 12:07:27 --> Config Class Initialized
INFO - 2023-08-30 12:07:27 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:27 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:27 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:27 --> URI Class Initialized
INFO - 2023-08-30 12:07:27 --> Router Class Initialized
INFO - 2023-08-30 12:07:27 --> Output Class Initialized
INFO - 2023-08-30 12:07:27 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:27 --> Input Class Initialized
INFO - 2023-08-30 12:07:27 --> Language Class Initialized
INFO - 2023-08-30 12:07:27 --> Loader Class Initialized
INFO - 2023-08-30 12:07:27 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:27 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:27 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:27 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:27 --> Controller Class Initialized
INFO - 2023-08-30 12:07:27 --> Config Class Initialized
INFO - 2023-08-30 12:07:27 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:27 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:27 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:27 --> URI Class Initialized
INFO - 2023-08-30 12:07:27 --> Router Class Initialized
INFO - 2023-08-30 12:07:27 --> Output Class Initialized
INFO - 2023-08-30 12:07:27 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:27 --> Input Class Initialized
INFO - 2023-08-30 12:07:27 --> Language Class Initialized
INFO - 2023-08-30 12:07:27 --> Loader Class Initialized
INFO - 2023-08-30 12:07:27 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:27 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:27 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:27 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:27 --> Controller Class Initialized
INFO - 2023-08-30 12:07:27 --> Model "User_model" initialized
INFO - 2023-08-30 12:07:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-30 12:07:27 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:27 --> Total execution time: 0.0387
INFO - 2023-08-30 12:07:33 --> Config Class Initialized
INFO - 2023-08-30 12:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:33 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:33 --> URI Class Initialized
INFO - 2023-08-30 12:07:33 --> Router Class Initialized
INFO - 2023-08-30 12:07:33 --> Output Class Initialized
INFO - 2023-08-30 12:07:33 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:33 --> Input Class Initialized
INFO - 2023-08-30 12:07:33 --> Language Class Initialized
INFO - 2023-08-30 12:07:33 --> Loader Class Initialized
INFO - 2023-08-30 12:07:33 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:33 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:33 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:33 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:33 --> Controller Class Initialized
INFO - 2023-08-30 12:07:33 --> Model "User_model" initialized
INFO - 2023-08-30 12:07:33 --> Config Class Initialized
INFO - 2023-08-30 12:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:33 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:33 --> URI Class Initialized
INFO - 2023-08-30 12:07:33 --> Router Class Initialized
INFO - 2023-08-30 12:07:33 --> Output Class Initialized
INFO - 2023-08-30 12:07:33 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:33 --> Input Class Initialized
INFO - 2023-08-30 12:07:33 --> Language Class Initialized
INFO - 2023-08-30 12:07:33 --> Loader Class Initialized
INFO - 2023-08-30 12:07:33 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:33 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:33 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:33 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:34 --> Controller Class Initialized
INFO - 2023-08-30 12:07:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-30 12:07:34 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:34 --> Total execution time: 0.0559
INFO - 2023-08-30 12:07:35 --> Config Class Initialized
INFO - 2023-08-30 12:07:35 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:35 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:35 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:35 --> URI Class Initialized
INFO - 2023-08-30 12:07:35 --> Router Class Initialized
INFO - 2023-08-30 12:07:35 --> Output Class Initialized
INFO - 2023-08-30 12:07:35 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:35 --> Input Class Initialized
INFO - 2023-08-30 12:07:35 --> Language Class Initialized
INFO - 2023-08-30 12:07:35 --> Loader Class Initialized
INFO - 2023-08-30 12:07:35 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:35 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:35 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:35 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:35 --> Controller Class Initialized
INFO - 2023-08-30 12:07:35 --> Model "Services_model" initialized
INFO - 2023-08-30 12:07:35 --> Helper loaded: form_helper
INFO - 2023-08-30 12:07:35 --> Form Validation Class Initialized
INFO - 2023-08-30 12:07:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-30 12:07:35 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:35 --> Total execution time: 0.0464
INFO - 2023-08-30 12:07:39 --> Config Class Initialized
INFO - 2023-08-30 12:07:39 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:39 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:39 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:39 --> URI Class Initialized
INFO - 2023-08-30 12:07:39 --> Router Class Initialized
INFO - 2023-08-30 12:07:39 --> Output Class Initialized
INFO - 2023-08-30 12:07:39 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:39 --> Input Class Initialized
INFO - 2023-08-30 12:07:39 --> Language Class Initialized
INFO - 2023-08-30 12:07:39 --> Loader Class Initialized
INFO - 2023-08-30 12:07:39 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:39 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:39 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:39 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:39 --> Controller Class Initialized
INFO - 2023-08-30 12:07:39 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 12:07:39 --> Helper loaded: form_helper
INFO - 2023-08-30 12:07:39 --> Form Validation Class Initialized
INFO - 2023-08-30 12:07:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 12:07:39 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:39 --> Total execution time: 0.0491
INFO - 2023-08-30 12:07:57 --> Config Class Initialized
INFO - 2023-08-30 12:07:57 --> Hooks Class Initialized
DEBUG - 2023-08-30 12:07:57 --> UTF-8 Support Enabled
INFO - 2023-08-30 12:07:57 --> Utf8 Class Initialized
INFO - 2023-08-30 12:07:57 --> URI Class Initialized
INFO - 2023-08-30 12:07:57 --> Router Class Initialized
INFO - 2023-08-30 12:07:57 --> Output Class Initialized
INFO - 2023-08-30 12:07:57 --> Security Class Initialized
DEBUG - 2023-08-30 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 12:07:57 --> Input Class Initialized
INFO - 2023-08-30 12:07:57 --> Language Class Initialized
INFO - 2023-08-30 12:07:57 --> Loader Class Initialized
INFO - 2023-08-30 12:07:57 --> Helper loaded: url_helper
INFO - 2023-08-30 12:07:57 --> Helper loaded: file_helper
INFO - 2023-08-30 12:07:57 --> Database Driver Class Initialized
INFO - 2023-08-30 12:07:57 --> Email Class Initialized
DEBUG - 2023-08-30 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 12:07:57 --> Controller Class Initialized
INFO - 2023-08-30 12:07:57 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 12:07:57 --> Helper loaded: form_helper
INFO - 2023-08-30 12:07:57 --> Form Validation Class Initialized
INFO - 2023-08-30 12:07:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 12:07:57 --> Final output sent to browser
DEBUG - 2023-08-30 12:07:57 --> Total execution time: 0.0681
INFO - 2023-08-30 13:09:27 --> Config Class Initialized
INFO - 2023-08-30 13:09:27 --> Hooks Class Initialized
DEBUG - 2023-08-30 13:09:27 --> UTF-8 Support Enabled
INFO - 2023-08-30 13:09:27 --> Utf8 Class Initialized
INFO - 2023-08-30 13:09:27 --> URI Class Initialized
INFO - 2023-08-30 13:09:27 --> Router Class Initialized
INFO - 2023-08-30 13:09:27 --> Output Class Initialized
INFO - 2023-08-30 13:09:27 --> Security Class Initialized
DEBUG - 2023-08-30 13:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 13:09:27 --> Input Class Initialized
INFO - 2023-08-30 13:09:27 --> Language Class Initialized
INFO - 2023-08-30 13:09:27 --> Loader Class Initialized
INFO - 2023-08-30 13:09:27 --> Helper loaded: url_helper
INFO - 2023-08-30 13:09:27 --> Helper loaded: file_helper
INFO - 2023-08-30 13:09:27 --> Database Driver Class Initialized
INFO - 2023-08-30 13:09:27 --> Email Class Initialized
DEBUG - 2023-08-30 13:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 13:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 13:09:27 --> Controller Class Initialized
INFO - 2023-08-30 13:09:27 --> Model "Services_cards_model" initialized
INFO - 2023-08-30 13:09:27 --> Helper loaded: form_helper
INFO - 2023-08-30 13:09:27 --> Form Validation Class Initialized
INFO - 2023-08-30 13:09:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-08-30 13:09:27 --> Final output sent to browser
DEBUG - 2023-08-30 13:09:27 --> Total execution time: 0.0693
INFO - 2023-08-30 13:09:27 --> Config Class Initialized
INFO - 2023-08-30 13:09:27 --> Hooks Class Initialized
DEBUG - 2023-08-30 13:09:27 --> UTF-8 Support Enabled
INFO - 2023-08-30 13:09:27 --> Utf8 Class Initialized
INFO - 2023-08-30 13:09:27 --> URI Class Initialized
INFO - 2023-08-30 13:09:27 --> Router Class Initialized
INFO - 2023-08-30 13:09:27 --> Output Class Initialized
INFO - 2023-08-30 13:09:27 --> Security Class Initialized
DEBUG - 2023-08-30 13:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 13:09:27 --> Input Class Initialized
INFO - 2023-08-30 13:09:27 --> Language Class Initialized
ERROR - 2023-08-30 13:09:27 --> 404 Page Not Found: admin/Services_cards/images
