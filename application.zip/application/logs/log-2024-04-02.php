<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-02 06:13:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:13:32 --> No URI present. Default controller set.
DEBUG - 2024-04-02 06:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:43:33 --> Total execution time: 0.2032
DEBUG - 2024-04-02 06:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:13:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:43:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:43:57 --> Total execution time: 0.1654
DEBUG - 2024-04-02 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:44:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:44:04 --> Total execution time: 0.1650
DEBUG - 2024-04-02 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:44:39 --> Total execution time: 0.1511
DEBUG - 2024-04-02 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:44:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:44:39 --> Total execution time: 0.0791
DEBUG - 2024-04-02 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:44:52 --> Total execution time: 0.1578
DEBUG - 2024-04-02 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:44:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:44:52 --> Total execution time: 0.1237
DEBUG - 2024-04-02 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:45:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:45:31 --> Total execution time: 0.1606
DEBUG - 2024-04-02 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:45:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:45:39 --> Total execution time: 0.1348
DEBUG - 2024-04-02 06:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:46:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:46:38 --> Total execution time: 0.1614
DEBUG - 2024-04-02 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:46:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:46:39 --> Total execution time: 0.0944
DEBUG - 2024-04-02 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:00 --> Total execution time: 0.1023
DEBUG - 2024-04-02 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:00 --> Total execution time: 0.1134
DEBUG - 2024-04-02 06:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:29 --> Total execution time: 0.1265
DEBUG - 2024-04-02 06:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:29 --> Total execution time: 0.1370
DEBUG - 2024-04-02 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:46 --> Total execution time: 0.1264
DEBUG - 2024-04-02 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:47:46 --> Total execution time: 0.1720
DEBUG - 2024-04-02 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:48:24 --> Total execution time: 0.1301
DEBUG - 2024-04-02 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:48:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:48:24 --> Total execution time: 0.1043
DEBUG - 2024-04-02 06:18:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:48:40 --> Total execution time: 0.1350
DEBUG - 2024-04-02 06:18:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:48:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:48:40 --> Total execution time: 0.1774
DEBUG - 2024-04-02 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:35 --> Total execution time: 0.1455
DEBUG - 2024-04-02 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:35 --> Total execution time: 0.0977
DEBUG - 2024-04-02 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 06:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.2514
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.2047
DEBUG - 2024-04-02 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.3423
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.3838
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.4362
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.2769
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:49:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:49:47 --> Total execution time: 0.1998
DEBUG - 2024-04-02 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:22 --> Total execution time: 0.1000
DEBUG - 2024-04-02 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:22 --> Total execution time: 0.2249
DEBUG - 2024-04-02 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 09:50:22 --> Total execution time: 0.1635
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:22 --> Total execution time: 0.4812
DEBUG - 2024-04-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:23 --> Total execution time: 0.0871
DEBUG - 2024-04-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:23 --> Total execution time: 0.1082
DEBUG - 2024-04-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:23 --> Total execution time: 0.1182
DEBUG - 2024-04-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:23 --> Total execution time: 0.1291
DEBUG - 2024-04-02 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:50:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:50:23 --> Total execution time: 0.1869
DEBUG - 2024-04-02 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:15 --> Total execution time: 0.1479
DEBUG - 2024-04-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:15 --> Total execution time: 0.1897
DEBUG - 2024-04-02 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:15 --> Total execution time: 0.2821
DEBUG - 2024-04-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:16 --> Total execution time: 0.0684
DEBUG - 2024-04-02 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:16 --> Total execution time: 0.1867
DEBUG - 2024-04-02 06:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:16 --> Total execution time: 0.1633
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:16 --> Total execution time: 0.1857
DEBUG - 2024-04-02 06:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:52:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:52:16 --> Total execution time: 0.3792
DEBUG - 2024-04-02 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:15 --> Total execution time: 0.1432
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:16 --> Total execution time: 0.3756
DEBUG - 2024-04-02 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:16 --> Total execution time: 0.0813
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:16 --> Total execution time: 0.0805
DEBUG - 2024-04-02 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:17 --> Total execution time: 0.1954
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:17 --> Total execution time: 0.9283
DEBUG - 2024-04-02 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:17 --> Total execution time: 0.4223
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:17 --> Total execution time: 0.4027
DEBUG - 2024-04-02 06:25:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:34 --> Total execution time: 0.1768
DEBUG - 2024-04-02 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:35 --> Total execution time: 0.2682
DEBUG - 2024-04-02 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 1.1312
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 0.4491
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 0.3018
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 0.3455
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 0.3301
DEBUG - 2024-04-02 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:55:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:55:36 --> Total execution time: 0.4274
DEBUG - 2024-04-02 06:26:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:03 --> Total execution time: 0.1691
DEBUG - 2024-04-02 06:26:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:03 --> Total execution time: 0.1031
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:03 --> Total execution time: 0.1107
DEBUG - 2024-04-02 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:04 --> Total execution time: 0.1012
DEBUG - 2024-04-02 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:04 --> Total execution time: 0.1670
DEBUG - 2024-04-02 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:26:04 --> UTF-8 Support Enabled
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:04 --> Total execution time: 0.0881
DEBUG - 2024-04-02 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:04 --> Total execution time: 0.1991
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:56:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:56:04 --> Total execution time: 0.2587
DEBUG - 2024-04-02 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:10 --> Total execution time: 0.1845
DEBUG - 2024-04-02 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:10 --> Total execution time: 0.1990
DEBUG - 2024-04-02 06:29:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:29:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.5664
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.1408
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.1242
DEBUG - 2024-04-02 06:29:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.1235
DEBUG - 2024-04-02 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.2752
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 09:59:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 09:59:11 --> Total execution time: 0.3109
DEBUG - 2024-04-02 06:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 09:59:15 --> Total execution time: 0.1036
DEBUG - 2024-04-02 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 09:59:25 --> Total execution time: 0.0883
DEBUG - 2024-04-02 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:41 --> Total execution time: 0.1155
DEBUG - 2024-04-02 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 0.9827
DEBUG - 2024-04-02 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 0.9268
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 1.6869
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 1.7424
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 0.9297
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 1.1895
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:00:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:00:43 --> Total execution time: 0.2334
DEBUG - 2024-04-02 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:00:48 --> Total execution time: 0.0609
DEBUG - 2024-04-02 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:47 --> Total execution time: 0.1077
DEBUG - 2024-04-02 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:47 --> Total execution time: 0.0955
DEBUG - 2024-04-02 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.5083
DEBUG - 2024-04-02 06:31:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:31:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.0850
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.1107
DEBUG - 2024-04-02 06:31:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.0704
DEBUG - 2024-04-02 06:31:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.3214
DEBUG - 2024-04-02 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:01:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:01:48 --> Total execution time: 0.3974
DEBUG - 2024-04-02 06:31:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:01:53 --> Total execution time: 0.0899
DEBUG - 2024-04-02 06:32:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:36 --> Total execution time: 0.1547
DEBUG - 2024-04-02 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:32:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 0.6458
DEBUG - 2024-04-02 06:32:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 06:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 0.6700
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 0.8710
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 0.9163
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 1.2580
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:38 --> Total execution time: 1.5202
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:02:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:02:39 --> Total execution time: 0.4423
DEBUG - 2024-04-02 06:32:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:02:56 --> Total execution time: 0.0828
DEBUG - 2024-04-02 06:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:25 --> Total execution time: 0.1010
DEBUG - 2024-04-02 06:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:41 --> Total execution time: 0.1072
DEBUG - 2024-04-02 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:42 --> Total execution time: 0.1087
DEBUG - 2024-04-02 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:42 --> Total execution time: 0.1234
DEBUG - 2024-04-02 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:42 --> Total execution time: 0.1176
DEBUG - 2024-04-02 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:43 --> Total execution time: 0.2892
DEBUG - 2024-04-02 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:43 --> Total execution time: 0.0747
DEBUG - 2024-04-02 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:43 --> Total execution time: 0.0940
DEBUG - 2024-04-02 06:33:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:44 --> Total execution time: 0.1677
DEBUG - 2024-04-02 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:45 --> Total execution time: 0.1088
DEBUG - 2024-04-02 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:47 --> Total execution time: 0.1116
DEBUG - 2024-04-02 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:47 --> Total execution time: 0.0882
DEBUG - 2024-04-02 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:33:47 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.1913
DEBUG - 2024-04-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.0844
DEBUG - 2024-04-02 06:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 06:33:48 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.2225
DEBUG - 2024-04-02 06:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.2928
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.2618
DEBUG - 2024-04-02 06:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:03:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:03:48 --> Total execution time: 0.5036
DEBUG - 2024-04-02 06:33:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:51 --> Total execution time: 0.0794
DEBUG - 2024-04-02 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:03:52 --> Total execution time: 0.1365
DEBUG - 2024-04-02 06:34:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:14 --> Total execution time: 0.1230
DEBUG - 2024-04-02 06:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:15 --> Total execution time: 0.1365
DEBUG - 2024-04-02 06:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:16 --> Total execution time: 0.1084
DEBUG - 2024-04-02 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:16 --> Total execution time: 0.1632
DEBUG - 2024-04-02 06:34:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:17 --> Total execution time: 0.1397
DEBUG - 2024-04-02 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:18 --> Total execution time: 0.1045
DEBUG - 2024-04-02 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:18 --> Total execution time: 0.0599
DEBUG - 2024-04-02 06:34:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:19 --> Total execution time: 0.1147
DEBUG - 2024-04-02 06:34:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:04:20 --> Total execution time: 0.1520
DEBUG - 2024-04-02 06:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:25 --> Total execution time: 0.1389
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:25 --> Total execution time: 0.0858
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:25 --> Total execution time: 0.5415
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:25 --> Total execution time: 0.4542
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:26 --> Total execution time: 0.3487
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:26 --> Total execution time: 0.2880
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:26 --> Total execution time: 0.2357
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:04:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:04:26 --> Total execution time: 0.3743
DEBUG - 2024-04-02 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:08 --> Total execution time: 0.1346
DEBUG - 2024-04-02 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.3642
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.3234
DEBUG - 2024-04-02 06:35:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.7589
DEBUG - 2024-04-02 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.4998
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.5179
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 1.9754
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:10 --> Total execution time: 0.2388
DEBUG - 2024-04-02 06:35:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:05:12 --> Total execution time: 0.0880
DEBUG - 2024-04-02 06:35:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:05:15 --> Total execution time: 0.0988
DEBUG - 2024-04-02 06:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:05:16 --> Total execution time: 0.1172
DEBUG - 2024-04-02 06:35:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:05:17 --> Total execution time: 0.1519
DEBUG - 2024-04-02 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:31 --> Total execution time: 0.0967
DEBUG - 2024-04-02 06:35:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:37 --> Total execution time: 0.1736
DEBUG - 2024-04-02 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:05:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:05:40 --> Total execution time: 0.1985
DEBUG - 2024-04-02 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:05:45 --> Total execution time: 0.1117
DEBUG - 2024-04-02 06:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:10:56 --> Severity: error --> Exception: Too few arguments to function HomeController::generate_captcha(), 0 passed in C:\xampp\htdocs\dw\application\controllers\HomeController.php on line 82 and exactly 1 expected C:\xampp\htdocs\dw\application\controllers\HomeController.php 653
DEBUG - 2024-04-02 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:10:58 --> Severity: error --> Exception: Too few arguments to function HomeController::generate_captcha(), 0 passed in C:\xampp\htdocs\dw\application\controllers\HomeController.php on line 82 and exactly 1 expected C:\xampp\htdocs\dw\application\controllers\HomeController.php 653
DEBUG - 2024-04-02 06:41:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:27 --> Total execution time: 0.1143
DEBUG - 2024-04-02 06:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:34 --> Total execution time: 0.1178
DEBUG - 2024-04-02 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:36 --> Total execution time: 0.1487
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.1135
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.0999
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.0802
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.2631
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.1888
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.2805
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:39 --> Total execution time: 0.1935
DEBUG - 2024-04-02 06:41:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:50 --> Total execution time: 0.1590
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:11:51 --> Total execution time: 0.0914
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:51 --> Total execution time: 0.1348
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 10:11:51 --> Total execution time: 0.1275
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:51 --> Total execution time: 0.1695
DEBUG - 2024-04-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:52 --> Total execution time: 0.3547
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:52 --> Total execution time: 0.3578
DEBUG - 2024-04-02 06:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:52 --> Total execution time: 0.2980
DEBUG - 2024-04-02 06:41:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:11:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:11:54 --> Total execution time: 0.0700
DEBUG - 2024-04-02 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:00 --> Total execution time: 0.1192
DEBUG - 2024-04-02 06:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:47 --> Total execution time: 0.1148
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.0878
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.1155
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.1456
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.2160
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.1808
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:48 --> Total execution time: 0.1254
DEBUG - 2024-04-02 06:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:49 --> Total execution time: 0.2225
DEBUG - 2024-04-02 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:51 --> Total execution time: 0.0717
DEBUG - 2024-04-02 06:42:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:12:53 --> Total execution time: 0.1621
DEBUG - 2024-04-02 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:19 --> Total execution time: 0.1428
DEBUG - 2024-04-02 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.1973
DEBUG - 2024-04-02 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.1999
DEBUG - 2024-04-02 06:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.1750
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.6389
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.6776
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 1.2975
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:13:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:13:21 --> Total execution time: 0.2865
DEBUG - 2024-04-02 06:43:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:23 --> Total execution time: 0.0850
DEBUG - 2024-04-02 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:24 --> Total execution time: 0.0958
DEBUG - 2024-04-02 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:32 --> Total execution time: 0.0920
DEBUG - 2024-04-02 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:32 --> Total execution time: 0.1369
DEBUG - 2024-04-02 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:33 --> Total execution time: 0.1388
DEBUG - 2024-04-02 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:34 --> Total execution time: 0.1107
DEBUG - 2024-04-02 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:35 --> Total execution time: 0.1015
DEBUG - 2024-04-02 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:13:35 --> Total execution time: 0.1563
DEBUG - 2024-04-02 06:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:22:25 --> Total execution time: 0.1187
DEBUG - 2024-04-02 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:23:40 --> Total execution time: 0.1008
DEBUG - 2024-04-02 06:54:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:24:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:24:16 --> Total execution time: 0.1807
DEBUG - 2024-04-02 06:55:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 06:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 06:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:25:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:25:24 --> Total execution time: 0.1289
DEBUG - 2024-04-02 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:30:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:30:52 --> Total execution time: 0.1794
DEBUG - 2024-04-02 07:02:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:32:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:32:38 --> Total execution time: 0.1261
DEBUG - 2024-04-02 07:03:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:33:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:33:17 --> Total execution time: 0.1461
DEBUG - 2024-04-02 07:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:34:38 --> Total execution time: 0.1792
DEBUG - 2024-04-02 07:05:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:35:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:35:00 --> Total execution time: 0.1560
DEBUG - 2024-04-02 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:35:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:35:18 --> Total execution time: 0.1678
DEBUG - 2024-04-02 07:05:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:35:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:35:41 --> Total execution time: 0.1254
DEBUG - 2024-04-02 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:35:49 --> Total execution time: 0.1708
DEBUG - 2024-04-02 07:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:00 --> Total execution time: 0.0958
DEBUG - 2024-04-02 07:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:01 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 07:06:01 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.0799
DEBUG - 2024-04-02 07:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.3228
DEBUG - 2024-04-02 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.3017
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.3000
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.1347
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:01 --> Total execution time: 0.2178
DEBUG - 2024-04-02 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:37 --> Total execution time: 0.1465
DEBUG - 2024-04-02 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:37 --> Total execution time: 0.1096
DEBUG - 2024-04-02 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:38 --> Total execution time: 0.3105
DEBUG - 2024-04-02 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:38 --> Total execution time: 0.6823
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:38 --> Total execution time: 0.3852
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:38 --> Total execution time: 0.3148
DEBUG - 2024-04-02 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:38 --> Total execution time: 0.3339
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:39 --> Total execution time: 0.8709
DEBUG - 2024-04-02 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:49 --> Total execution time: 0.1414
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:50 --> Total execution time: 0.0740
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:50 --> Total execution time: 0.3155
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:50 --> Total execution time: 0.0803
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 10:36:50 --> Total execution time: 0.1396
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:36:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:51 --> Total execution time: 0.2248
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:51 --> Total execution time: 0.0994
DEBUG - 2024-04-02 07:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:36:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:36:51 --> Total execution time: 0.2851
DEBUG - 2024-04-02 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:36:55 --> Total execution time: 0.1130
DEBUG - 2024-04-02 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:37:00 --> Total execution time: 0.1380
DEBUG - 2024-04-02 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:37:01 --> Total execution time: 0.1101
DEBUG - 2024-04-02 07:07:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:20 --> Total execution time: 0.1961
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.0993
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.1243
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.1000
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.2570
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.4579
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:21 --> Total execution time: 0.5951
DEBUG - 2024-04-02 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:22 --> Total execution time: 0.4195
DEBUG - 2024-04-02 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:38 --> Total execution time: 0.1297
DEBUG - 2024-04-02 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:38 --> Total execution time: 0.0777
DEBUG - 2024-04-02 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:38 --> Total execution time: 0.0816
DEBUG - 2024-04-02 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:39 --> Total execution time: 0.0954
DEBUG - 2024-04-02 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:39 --> Total execution time: 0.6143
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:39 --> Total execution time: 0.4652
DEBUG - 2024-04-02 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:39 --> Total execution time: 0.5473
DEBUG - 2024-04-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:39 --> Total execution time: 0.4081
DEBUG - 2024-04-02 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:48 --> Total execution time: 0.1659
DEBUG - 2024-04-02 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:48 --> Total execution time: 0.1024
DEBUG - 2024-04-02 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:48 --> Total execution time: 0.2561
DEBUG - 2024-04-02 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:49 --> Total execution time: 0.2537
DEBUG - 2024-04-02 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:49 --> Total execution time: 0.2301
DEBUG - 2024-04-02 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:49 --> Total execution time: 0.2571
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:49 --> Total execution time: 0.2171
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:37:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:37:49 --> Total execution time: 0.2534
DEBUG - 2024-04-02 07:07:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:37:51 --> Total execution time: 0.0709
DEBUG - 2024-04-02 07:07:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:37:52 --> Total execution time: 0.1148
DEBUG - 2024-04-02 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:14 --> Total execution time: 0.1510
DEBUG - 2024-04-02 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.0686
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.1968
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.0694
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.2406
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.2948
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.3349
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:15 --> Total execution time: 0.9299
DEBUG - 2024-04-02 07:08:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:29 --> Total execution time: 0.1182
DEBUG - 2024-04-02 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:29 --> Total execution time: 0.0951
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:29 --> Total execution time: 0.1342
DEBUG - 2024-04-02 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:29 --> Total execution time: 0.1804
DEBUG - 2024-04-02 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:08:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:30 --> Total execution time: 0.3017
DEBUG - 2024-04-02 07:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-02 07:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:30 --> Total execution time: 0.5187
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:30 --> Total execution time: 0.5658
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:38:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:38:30 --> Total execution time: 0.6768
DEBUG - 2024-04-02 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:21 --> Total execution time: 0.1277
DEBUG - 2024-04-02 07:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:22 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 07:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:22 --> Total execution time: 0.3754
DEBUG - 2024-04-02 07:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:22 --> Total execution time: 0.3969
DEBUG - 2024-04-02 07:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:22 --> Total execution time: 0.2011
DEBUG - 2024-04-02 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:22 --> Total execution time: 0.2322
DEBUG - 2024-04-02 07:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:23 --> Total execution time: 0.0767
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:23 --> Total execution time: 0.1106
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:23 --> Total execution time: 0.4433
DEBUG - 2024-04-02 07:09:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:30 --> Total execution time: 0.2272
DEBUG - 2024-04-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:30 --> Total execution time: 0.0771
DEBUG - 2024-04-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:30 --> Total execution time: 0.2325
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:30 --> Total execution time: 0.1067
DEBUG - 2024-04-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:31 --> Total execution time: 0.0820
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:31 --> Total execution time: 0.1126
DEBUG - 2024-04-02 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:31 --> Total execution time: 0.0736
DEBUG - 2024-04-02 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:31 --> Total execution time: 0.0682
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:49 --> Total execution time: 0.1316
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:49 --> Total execution time: 0.0745
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:49 --> Total execution time: 0.1249
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:49 --> Total execution time: 0.1782
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:50 --> Total execution time: 0.2317
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:50 --> Total execution time: 0.4391
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:50 --> Total execution time: 0.4182
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:39:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:39:50 --> Total execution time: 0.5161
DEBUG - 2024-04-02 07:09:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:52 --> Total execution time: 0.1200
DEBUG - 2024-04-02 07:09:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:53 --> Total execution time: 0.0968
DEBUG - 2024-04-02 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:54 --> Total execution time: 0.1149
DEBUG - 2024-04-02 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:56 --> Total execution time: 0.1595
DEBUG - 2024-04-02 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:56 --> Total execution time: 0.1185
DEBUG - 2024-04-02 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:56 --> Total execution time: 0.1092
DEBUG - 2024-04-02 07:09:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:57 --> Total execution time: 0.1029
DEBUG - 2024-04-02 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:58 --> Total execution time: 0.1409
DEBUG - 2024-04-02 07:09:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:39:59 --> Total execution time: 0.1030
DEBUG - 2024-04-02 07:09:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:00 --> Total execution time: 0.1546
DEBUG - 2024-04-02 07:10:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:00 --> Total execution time: 0.1481
DEBUG - 2024-04-02 07:10:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:01 --> Total execution time: 0.0926
DEBUG - 2024-04-02 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:09 --> Total execution time: 0.1336
DEBUG - 2024-04-02 07:10:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:10 --> Total execution time: 0.1061
DEBUG - 2024-04-02 07:10:11 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:11 --> Total execution time: 0.1416
DEBUG - 2024-04-02 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:13 --> Total execution time: 0.1230
DEBUG - 2024-04-02 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:14 --> Total execution time: 0.1364
DEBUG - 2024-04-02 07:10:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:15 --> Total execution time: 0.1106
DEBUG - 2024-04-02 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:40:16 --> Total execution time: 0.1052
DEBUG - 2024-04-02 07:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:30 --> Total execution time: 0.1686
DEBUG - 2024-04-02 07:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 1.7222
DEBUG - 2024-04-02 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 0.7939
DEBUG - 2024-04-02 07:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 1.0152
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 0.9473
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 1.1151
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 1.5455
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:42:32 --> Total execution time: 0.3233
DEBUG - 2024-04-02 07:13:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:21 --> Total execution time: 0.1554
DEBUG - 2024-04-02 07:13:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:13:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:22 --> Total execution time: 0.3694
DEBUG - 2024-04-02 07:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:13:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-02 07:13:23 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.0945
DEBUG - 2024-04-02 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.0927
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.1047
DEBUG - 2024-04-02 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.9236
DEBUG - 2024-04-02 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.0827
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:43:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:43:23 --> Total execution time: 0.0928
DEBUG - 2024-04-02 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:00 --> Total execution time: 0.1118
DEBUG - 2024-04-02 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:00 --> Total execution time: 0.1719
DEBUG - 2024-04-02 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:14:01 --> UTF-8 Support Enabled
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.2371
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.2361
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.2302
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.3177
DEBUG - 2024-04-02 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.2816
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:01 --> Total execution time: 0.1090
DEBUG - 2024-04-02 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:48 --> Total execution time: 0.0824
DEBUG - 2024-04-02 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:49 --> Total execution time: 0.0618
DEBUG - 2024-04-02 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:50 --> Total execution time: 0.0725
DEBUG - 2024-04-02 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:51 --> Total execution time: 0.0725
DEBUG - 2024-04-02 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:51 --> Total execution time: 0.0637
DEBUG - 2024-04-02 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:52 --> Total execution time: 0.0561
DEBUG - 2024-04-02 07:14:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:44:53 --> Total execution time: 0.0591
DEBUG - 2024-04-02 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:57 --> Total execution time: 0.0670
DEBUG - 2024-04-02 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:57 --> Total execution time: 0.0805
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:44:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:44:57 --> Total execution time: 0.1233
DEBUG - 2024-04-02 07:15:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:45:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:45:03 --> Total execution time: 0.0749
DEBUG - 2024-04-02 07:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:45:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:45:12 --> Total execution time: 0.0866
DEBUG - 2024-04-02 07:15:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:45:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:45:16 --> Total execution time: 0.1096
DEBUG - 2024-04-02 07:17:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:23 --> No URI present. Default controller set.
DEBUG - 2024-04-02 07:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:24 --> Total execution time: 1.6359
DEBUG - 2024-04-02 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:46 --> Total execution time: 0.1034
DEBUG - 2024-04-02 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 07:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:47 --> Total execution time: 0.1832
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:47 --> Total execution time: 0.1501
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:47 --> Total execution time: 0.2799
DEBUG - 2024-04-02 07:17:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:47:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:47:49 --> Total execution time: 0.2302
DEBUG - 2024-04-02 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:21:31 --> No URI present. Default controller set.
DEBUG - 2024-04-02 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\index.php 186
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:51:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:51:31 --> Total execution time: 0.0938
DEBUG - 2024-04-02 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:25:57 --> No URI present. Default controller set.
DEBUG - 2024-04-02 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:55:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:55:57 --> Total execution time: 0.0767
DEBUG - 2024-04-02 07:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:56:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:56:09 --> Total execution time: 0.0916
DEBUG - 2024-04-02 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:56:14 --> Total execution time: 0.0910
DEBUG - 2024-04-02 07:26:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:56:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:56:17 --> Total execution time: 0.0957
DEBUG - 2024-04-02 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:26:32 --> No URI present. Default controller set.
DEBUG - 2024-04-02 07:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:56:32 --> Total execution time: 0.0717
DEBUG - 2024-04-02 07:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:27:14 --> No URI present. Default controller set.
DEBUG - 2024-04-02 07:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-02 10:57:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-02 10:57:14 --> Total execution time: 0.0798
DEBUG - 2024-04-02 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:57:19 --> Total execution time: 0.0472
DEBUG - 2024-04-02 07:27:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:57:20 --> Total execution time: 0.0624
DEBUG - 2024-04-02 07:27:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-02 07:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-02 07:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-02 10:57:21 --> Total execution time: 0.0548
