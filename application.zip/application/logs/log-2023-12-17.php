<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-17 06:08:33 --> Config Class Initialized
INFO - 2023-12-17 06:08:33 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:08:33 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:08:33 --> Utf8 Class Initialized
INFO - 2023-12-17 06:08:33 --> URI Class Initialized
DEBUG - 2023-12-17 06:08:33 --> No URI present. Default controller set.
INFO - 2023-12-17 06:08:33 --> Router Class Initialized
INFO - 2023-12-17 06:08:33 --> Output Class Initialized
INFO - 2023-12-17 06:08:33 --> Security Class Initialized
DEBUG - 2023-12-17 06:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:08:33 --> Input Class Initialized
INFO - 2023-12-17 06:08:33 --> Language Class Initialized
INFO - 2023-12-17 06:08:33 --> Loader Class Initialized
INFO - 2023-12-17 06:08:33 --> Helper loaded: url_helper
INFO - 2023-12-17 06:08:33 --> Helper loaded: file_helper
INFO - 2023-12-17 06:08:33 --> Database Driver Class Initialized
ERROR - 2023-12-17 06:08:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'dw' C:\xampp\htdocs\dw\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-17 06:08:33 --> Unable to connect to the database
INFO - 2023-12-17 06:08:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-17 06:15:44 --> Config Class Initialized
INFO - 2023-12-17 06:15:44 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:15:44 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:15:44 --> Utf8 Class Initialized
INFO - 2023-12-17 06:15:44 --> URI Class Initialized
DEBUG - 2023-12-17 06:15:44 --> No URI present. Default controller set.
INFO - 2023-12-17 06:15:44 --> Router Class Initialized
INFO - 2023-12-17 06:15:44 --> Output Class Initialized
INFO - 2023-12-17 06:15:44 --> Security Class Initialized
DEBUG - 2023-12-17 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:15:44 --> Input Class Initialized
INFO - 2023-12-17 06:15:44 --> Language Class Initialized
INFO - 2023-12-17 06:15:44 --> Loader Class Initialized
INFO - 2023-12-17 06:15:44 --> Helper loaded: url_helper
INFO - 2023-12-17 06:15:44 --> Helper loaded: file_helper
INFO - 2023-12-17 06:15:44 --> Database Driver Class Initialized
INFO - 2023-12-17 06:15:44 --> Email Class Initialized
DEBUG - 2023-12-17 06:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:15:44 --> Controller Class Initialized
INFO - 2023-12-17 06:15:44 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:15:44 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:15:44 --> Model "Home_model" initialized
INFO - 2023-12-17 06:15:44 --> Helper loaded: download_helper
INFO - 2023-12-17 06:15:44 --> Helper loaded: form_helper
INFO - 2023-12-17 06:15:44 --> Form Validation Class Initialized
INFO - 2023-12-17 10:45:44 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:45:44 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:45:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:45:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-12-17 10:45:44 --> Final output sent to browser
DEBUG - 2023-12-17 10:45:44 --> Total execution time: 0.2307
INFO - 2023-12-17 06:15:54 --> Config Class Initialized
INFO - 2023-12-17 06:15:54 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:15:54 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:15:54 --> Utf8 Class Initialized
INFO - 2023-12-17 06:15:54 --> URI Class Initialized
DEBUG - 2023-12-17 06:15:54 --> No URI present. Default controller set.
INFO - 2023-12-17 06:15:54 --> Router Class Initialized
INFO - 2023-12-17 06:15:54 --> Output Class Initialized
INFO - 2023-12-17 06:15:54 --> Security Class Initialized
DEBUG - 2023-12-17 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:15:54 --> Input Class Initialized
INFO - 2023-12-17 06:15:54 --> Language Class Initialized
INFO - 2023-12-17 06:15:54 --> Loader Class Initialized
INFO - 2023-12-17 06:15:54 --> Helper loaded: url_helper
INFO - 2023-12-17 06:15:54 --> Helper loaded: file_helper
INFO - 2023-12-17 06:15:54 --> Database Driver Class Initialized
INFO - 2023-12-17 06:15:54 --> Email Class Initialized
DEBUG - 2023-12-17 06:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:15:54 --> Controller Class Initialized
INFO - 2023-12-17 06:15:54 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:15:54 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:15:54 --> Model "Home_model" initialized
INFO - 2023-12-17 06:15:54 --> Helper loaded: download_helper
INFO - 2023-12-17 06:15:54 --> Helper loaded: form_helper
INFO - 2023-12-17 06:15:54 --> Form Validation Class Initialized
INFO - 2023-12-17 10:45:54 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:45:54 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:45:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:45:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-12-17 10:45:54 --> Final output sent to browser
DEBUG - 2023-12-17 10:45:54 --> Total execution time: 0.0918
INFO - 2023-12-17 06:17:10 --> Config Class Initialized
INFO - 2023-12-17 06:17:10 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:10 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:10 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:10 --> URI Class Initialized
INFO - 2023-12-17 06:17:10 --> Router Class Initialized
INFO - 2023-12-17 06:17:10 --> Output Class Initialized
INFO - 2023-12-17 06:17:10 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:10 --> Input Class Initialized
INFO - 2023-12-17 06:17:10 --> Language Class Initialized
INFO - 2023-12-17 06:17:10 --> Loader Class Initialized
INFO - 2023-12-17 06:17:10 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:10 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:10 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:10 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:10 --> Controller Class Initialized
INFO - 2023-12-17 06:17:10 --> Model "User_model" initialized
INFO - 2023-12-17 06:17:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-12-17 06:17:10 --> Final output sent to browser
DEBUG - 2023-12-17 06:17:10 --> Total execution time: 0.0894
INFO - 2023-12-17 06:17:11 --> Config Class Initialized
INFO - 2023-12-17 06:17:11 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:11 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:11 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:11 --> URI Class Initialized
INFO - 2023-12-17 06:17:11 --> Router Class Initialized
INFO - 2023-12-17 06:17:11 --> Output Class Initialized
INFO - 2023-12-17 06:17:11 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:11 --> Input Class Initialized
INFO - 2023-12-17 06:17:11 --> Language Class Initialized
INFO - 2023-12-17 06:17:11 --> Loader Class Initialized
INFO - 2023-12-17 06:17:11 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:11 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:11 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:11 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:11 --> Controller Class Initialized
INFO - 2023-12-17 06:17:11 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:17:11 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:17:11 --> Model "Home_model" initialized
INFO - 2023-12-17 06:17:11 --> Helper loaded: download_helper
INFO - 2023-12-17 06:17:11 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:11 --> Form Validation Class Initialized
INFO - 2023-12-17 10:47:11 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:47:11 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:47:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:47:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:47:11 --> Final output sent to browser
DEBUG - 2023-12-17 10:47:11 --> Total execution time: 0.0857
INFO - 2023-12-17 06:17:43 --> Config Class Initialized
INFO - 2023-12-17 06:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:43 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:43 --> URI Class Initialized
INFO - 2023-12-17 06:17:43 --> Router Class Initialized
INFO - 2023-12-17 06:17:43 --> Output Class Initialized
INFO - 2023-12-17 06:17:43 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:43 --> Input Class Initialized
INFO - 2023-12-17 06:17:43 --> Language Class Initialized
INFO - 2023-12-17 06:17:43 --> Loader Class Initialized
INFO - 2023-12-17 06:17:43 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:43 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:43 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:43 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:43 --> Controller Class Initialized
INFO - 2023-12-17 06:17:43 --> Model "User_model" initialized
INFO - 2023-12-17 06:17:43 --> Config Class Initialized
INFO - 2023-12-17 06:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:43 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:43 --> URI Class Initialized
INFO - 2023-12-17 06:17:43 --> Router Class Initialized
INFO - 2023-12-17 06:17:43 --> Output Class Initialized
INFO - 2023-12-17 06:17:43 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:43 --> Input Class Initialized
INFO - 2023-12-17 06:17:43 --> Language Class Initialized
INFO - 2023-12-17 06:17:43 --> Loader Class Initialized
INFO - 2023-12-17 06:17:43 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:43 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:43 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:43 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:43 --> Controller Class Initialized
INFO - 2023-12-17 06:17:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-12-17 06:17:43 --> Final output sent to browser
DEBUG - 2023-12-17 06:17:43 --> Total execution time: 0.0629
INFO - 2023-12-17 06:17:50 --> Config Class Initialized
INFO - 2023-12-17 06:17:50 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:50 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:50 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:50 --> URI Class Initialized
INFO - 2023-12-17 06:17:50 --> Router Class Initialized
INFO - 2023-12-17 06:17:50 --> Output Class Initialized
INFO - 2023-12-17 06:17:50 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:50 --> Input Class Initialized
INFO - 2023-12-17 06:17:50 --> Language Class Initialized
INFO - 2023-12-17 06:17:50 --> Loader Class Initialized
INFO - 2023-12-17 06:17:50 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:50 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:50 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:50 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:50 --> Controller Class Initialized
INFO - 2023-12-17 06:17:50 --> Model "Blog_model" initialized
INFO - 2023-12-17 06:17:50 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:50 --> Form Validation Class Initialized
INFO - 2023-12-17 06:17:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-12-17 06:17:50 --> Final output sent to browser
DEBUG - 2023-12-17 06:17:50 --> Total execution time: 0.1859
INFO - 2023-12-17 06:17:50 --> Config Class Initialized
INFO - 2023-12-17 06:17:50 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:50 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:50 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:50 --> URI Class Initialized
INFO - 2023-12-17 06:17:50 --> Router Class Initialized
INFO - 2023-12-17 06:17:50 --> Output Class Initialized
INFO - 2023-12-17 06:17:50 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:50 --> Input Class Initialized
INFO - 2023-12-17 06:17:50 --> Language Class Initialized
INFO - 2023-12-17 06:17:50 --> Loader Class Initialized
INFO - 2023-12-17 06:17:50 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:50 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:50 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:50 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:50 --> Controller Class Initialized
INFO - 2023-12-17 06:17:50 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:17:50 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:17:50 --> Model "Home_model" initialized
INFO - 2023-12-17 06:17:50 --> Helper loaded: download_helper
INFO - 2023-12-17 06:17:50 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:50 --> Form Validation Class Initialized
INFO - 2023-12-17 10:47:50 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:47:50 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:47:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:47:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:47:51 --> Final output sent to browser
DEBUG - 2023-12-17 10:47:51 --> Total execution time: 0.1124
INFO - 2023-12-17 06:17:52 --> Config Class Initialized
INFO - 2023-12-17 06:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:52 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:52 --> URI Class Initialized
INFO - 2023-12-17 06:17:52 --> Router Class Initialized
INFO - 2023-12-17 06:17:52 --> Output Class Initialized
INFO - 2023-12-17 06:17:52 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:52 --> Input Class Initialized
INFO - 2023-12-17 06:17:52 --> Language Class Initialized
INFO - 2023-12-17 06:17:52 --> Loader Class Initialized
INFO - 2023-12-17 06:17:52 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:52 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:52 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:52 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:52 --> Controller Class Initialized
INFO - 2023-12-17 06:17:52 --> Model "Gallery_model" initialized
INFO - 2023-12-17 06:17:52 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:52 --> Form Validation Class Initialized
INFO - 2023-12-17 06:17:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-12-17 06:17:52 --> Final output sent to browser
DEBUG - 2023-12-17 06:17:52 --> Total execution time: 0.0932
INFO - 2023-12-17 06:17:53 --> Config Class Initialized
INFO - 2023-12-17 06:17:53 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:53 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:53 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:53 --> URI Class Initialized
INFO - 2023-12-17 06:17:53 --> Router Class Initialized
INFO - 2023-12-17 06:17:53 --> Output Class Initialized
INFO - 2023-12-17 06:17:53 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:53 --> Input Class Initialized
INFO - 2023-12-17 06:17:53 --> Language Class Initialized
INFO - 2023-12-17 06:17:53 --> Loader Class Initialized
INFO - 2023-12-17 06:17:53 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:53 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:53 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:53 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:53 --> Controller Class Initialized
INFO - 2023-12-17 06:17:53 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:17:53 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:17:53 --> Model "Home_model" initialized
INFO - 2023-12-17 06:17:53 --> Helper loaded: download_helper
INFO - 2023-12-17 06:17:53 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:53 --> Form Validation Class Initialized
INFO - 2023-12-17 10:47:53 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:47:53 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:47:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:47:53 --> Final output sent to browser
DEBUG - 2023-12-17 10:47:53 --> Total execution time: 0.0976
INFO - 2023-12-17 06:17:58 --> Config Class Initialized
INFO - 2023-12-17 06:17:58 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:17:58 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:17:58 --> Utf8 Class Initialized
INFO - 2023-12-17 06:17:58 --> URI Class Initialized
INFO - 2023-12-17 06:17:58 --> Router Class Initialized
INFO - 2023-12-17 06:17:58 --> Output Class Initialized
INFO - 2023-12-17 06:17:58 --> Security Class Initialized
DEBUG - 2023-12-17 06:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:17:58 --> Input Class Initialized
INFO - 2023-12-17 06:17:58 --> Language Class Initialized
INFO - 2023-12-17 06:17:59 --> Loader Class Initialized
INFO - 2023-12-17 06:17:59 --> Helper loaded: url_helper
INFO - 2023-12-17 06:17:59 --> Helper loaded: file_helper
INFO - 2023-12-17 06:17:59 --> Database Driver Class Initialized
INFO - 2023-12-17 06:17:59 --> Email Class Initialized
DEBUG - 2023-12-17 06:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:17:59 --> Controller Class Initialized
INFO - 2023-12-17 06:17:59 --> Model "Services_model" initialized
INFO - 2023-12-17 06:17:59 --> Model "ServicesCategoriesModel" initialized
INFO - 2023-12-17 06:17:59 --> Helper loaded: form_helper
INFO - 2023-12-17 06:17:59 --> Form Validation Class Initialized
INFO - 2023-12-17 06:17:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-12-17 06:17:59 --> Final output sent to browser
DEBUG - 2023-12-17 06:17:59 --> Total execution time: 0.1705
INFO - 2023-12-17 06:18:01 --> Config Class Initialized
INFO - 2023-12-17 06:18:01 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:01 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:01 --> URI Class Initialized
INFO - 2023-12-17 06:18:01 --> Router Class Initialized
INFO - 2023-12-17 06:18:01 --> Output Class Initialized
INFO - 2023-12-17 06:18:01 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:01 --> Input Class Initialized
INFO - 2023-12-17 06:18:01 --> Language Class Initialized
INFO - 2023-12-17 06:18:01 --> Loader Class Initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:01 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:01 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:01 --> Controller Class Initialized
INFO - 2023-12-17 06:18:01 --> Model "Training_model" initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:01 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-12-17 06:18:01 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:01 --> Total execution time: 0.1163
INFO - 2023-12-17 06:18:01 --> Config Class Initialized
INFO - 2023-12-17 06:18:01 --> Hooks Class Initialized
INFO - 2023-12-17 06:18:01 --> Config Class Initialized
INFO - 2023-12-17 06:18:01 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:01 --> Utf8 Class Initialized
DEBUG - 2023-12-17 06:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:01 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:01 --> URI Class Initialized
INFO - 2023-12-17 06:18:01 --> Router Class Initialized
INFO - 2023-12-17 06:18:01 --> Config Class Initialized
INFO - 2023-12-17 06:18:01 --> Hooks Class Initialized
INFO - 2023-12-17 06:18:01 --> Output Class Initialized
INFO - 2023-12-17 06:18:01 --> URI Class Initialized
DEBUG - 2023-12-17 06:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:01 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:01 --> Security Class Initialized
INFO - 2023-12-17 06:18:01 --> URI Class Initialized
DEBUG - 2023-12-17 06:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:01 --> Input Class Initialized
INFO - 2023-12-17 06:18:01 --> Router Class Initialized
INFO - 2023-12-17 06:18:01 --> Language Class Initialized
INFO - 2023-12-17 06:18:01 --> Router Class Initialized
INFO - 2023-12-17 06:18:01 --> Output Class Initialized
INFO - 2023-12-17 06:18:01 --> Output Class Initialized
INFO - 2023-12-17 06:18:01 --> Loader Class Initialized
INFO - 2023-12-17 06:18:01 --> Security Class Initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: url_helper
DEBUG - 2023-12-17 06:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:01 --> Input Class Initialized
INFO - 2023-12-17 06:18:01 --> Language Class Initialized
INFO - 2023-12-17 06:18:01 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:01 --> Input Class Initialized
INFO - 2023-12-17 06:18:01 --> Loader Class Initialized
INFO - 2023-12-17 06:18:01 --> Language Class Initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:01 --> Loader Class Initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:01 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:01 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:01 --> Email Class Initialized
INFO - 2023-12-17 06:18:01 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:01 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:01 --> Email Class Initialized
INFO - 2023-12-17 06:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:01 --> Controller Class Initialized
INFO - 2023-12-17 06:18:01 --> Model "Contact_model" initialized
DEBUG - 2023-12-17 06:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:01 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:18:01 --> Model "Home_model" initialized
DEBUG - 2023-12-17 06:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:01 --> Helper loaded: download_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:01 --> Form Validation Class Initialized
INFO - 2023-12-17 10:48:01 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:48:01 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:48:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:48:01 --> Final output sent to browser
DEBUG - 2023-12-17 10:48:01 --> Total execution time: 0.1303
INFO - 2023-12-17 06:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:01 --> Controller Class Initialized
INFO - 2023-12-17 06:18:01 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:01 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:18:01 --> Model "Home_model" initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: download_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:01 --> Form Validation Class Initialized
INFO - 2023-12-17 10:48:01 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:48:01 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:48:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:48:01 --> Final output sent to browser
DEBUG - 2023-12-17 10:48:01 --> Total execution time: 0.1529
INFO - 2023-12-17 06:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:01 --> Controller Class Initialized
INFO - 2023-12-17 06:18:01 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:01 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:18:01 --> Model "Home_model" initialized
INFO - 2023-12-17 06:18:01 --> Helper loaded: download_helper
INFO - 2023-12-17 06:18:01 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:01 --> Form Validation Class Initialized
INFO - 2023-12-17 10:48:01 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:48:01 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:48:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:48:01 --> Final output sent to browser
DEBUG - 2023-12-17 10:48:01 --> Total execution time: 0.2243
INFO - 2023-12-17 06:18:03 --> Config Class Initialized
INFO - 2023-12-17 06:18:03 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:03 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:03 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:03 --> URI Class Initialized
INFO - 2023-12-17 06:18:03 --> Router Class Initialized
INFO - 2023-12-17 06:18:03 --> Output Class Initialized
INFO - 2023-12-17 06:18:03 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:03 --> Input Class Initialized
INFO - 2023-12-17 06:18:03 --> Language Class Initialized
INFO - 2023-12-17 06:18:03 --> Loader Class Initialized
INFO - 2023-12-17 06:18:03 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:03 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:03 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:03 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:03 --> Controller Class Initialized
INFO - 2023-12-17 06:18:03 --> Model "Certification_courses_model" initialized
INFO - 2023-12-17 06:18:03 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:03 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-12-17 06:18:03 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:03 --> Total execution time: 0.0786
INFO - 2023-12-17 06:18:06 --> Config Class Initialized
INFO - 2023-12-17 06:18:06 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:06 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:06 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:06 --> URI Class Initialized
INFO - 2023-12-17 06:18:06 --> Router Class Initialized
INFO - 2023-12-17 06:18:06 --> Output Class Initialized
INFO - 2023-12-17 06:18:06 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:06 --> Input Class Initialized
INFO - 2023-12-17 06:18:06 --> Language Class Initialized
INFO - 2023-12-17 06:18:06 --> Loader Class Initialized
INFO - 2023-12-17 06:18:06 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:06 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:06 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:06 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:06 --> Controller Class Initialized
INFO - 2023-12-17 06:18:06 --> Model "Testimonials_model" initialized
INFO - 2023-12-17 06:18:06 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:06 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/testimonials_list.php
INFO - 2023-12-17 06:18:06 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:06 --> Total execution time: 0.2084
INFO - 2023-12-17 06:18:34 --> Config Class Initialized
INFO - 2023-12-17 06:18:34 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:34 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:34 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:34 --> URI Class Initialized
INFO - 2023-12-17 06:18:34 --> Router Class Initialized
INFO - 2023-12-17 06:18:34 --> Output Class Initialized
INFO - 2023-12-17 06:18:34 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:34 --> Input Class Initialized
INFO - 2023-12-17 06:18:34 --> Language Class Initialized
INFO - 2023-12-17 06:18:34 --> Loader Class Initialized
INFO - 2023-12-17 06:18:34 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:34 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:34 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:34 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:34 --> Controller Class Initialized
INFO - 2023-12-17 06:18:34 --> Model "User_model" initialized
INFO - 2023-12-17 06:18:34 --> Config Class Initialized
INFO - 2023-12-17 06:18:34 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:34 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:34 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:34 --> URI Class Initialized
INFO - 2023-12-17 06:18:34 --> Router Class Initialized
INFO - 2023-12-17 06:18:34 --> Output Class Initialized
INFO - 2023-12-17 06:18:34 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:34 --> Input Class Initialized
INFO - 2023-12-17 06:18:34 --> Language Class Initialized
INFO - 2023-12-17 06:18:34 --> Loader Class Initialized
INFO - 2023-12-17 06:18:34 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:34 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:34 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:34 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:35 --> Controller Class Initialized
INFO - 2023-12-17 06:18:35 --> Model "User_model" initialized
INFO - 2023-12-17 06:18:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-12-17 06:18:35 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:35 --> Total execution time: 0.0879
INFO - 2023-12-17 06:18:39 --> Config Class Initialized
INFO - 2023-12-17 06:18:39 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:39 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:39 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:39 --> URI Class Initialized
INFO - 2023-12-17 06:18:39 --> Router Class Initialized
INFO - 2023-12-17 06:18:39 --> Output Class Initialized
INFO - 2023-12-17 06:18:39 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:39 --> Input Class Initialized
INFO - 2023-12-17 06:18:39 --> Language Class Initialized
INFO - 2023-12-17 06:18:39 --> Loader Class Initialized
INFO - 2023-12-17 06:18:39 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:39 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:39 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:39 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:39 --> Controller Class Initialized
INFO - 2023-12-17 06:18:39 --> Model "User_model" initialized
INFO - 2023-12-17 06:18:39 --> Config Class Initialized
INFO - 2023-12-17 06:18:39 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:39 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:39 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:39 --> URI Class Initialized
INFO - 2023-12-17 06:18:39 --> Router Class Initialized
INFO - 2023-12-17 06:18:39 --> Output Class Initialized
INFO - 2023-12-17 06:18:39 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:39 --> Input Class Initialized
INFO - 2023-12-17 06:18:39 --> Language Class Initialized
INFO - 2023-12-17 06:18:39 --> Loader Class Initialized
INFO - 2023-12-17 06:18:39 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:39 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:39 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:39 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:39 --> Controller Class Initialized
INFO - 2023-12-17 06:18:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-12-17 06:18:39 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:39 --> Total execution time: 0.0404
INFO - 2023-12-17 06:18:44 --> Config Class Initialized
INFO - 2023-12-17 06:18:44 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:44 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:44 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:44 --> URI Class Initialized
INFO - 2023-12-17 06:18:44 --> Router Class Initialized
INFO - 2023-12-17 06:18:44 --> Output Class Initialized
INFO - 2023-12-17 06:18:44 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:44 --> Input Class Initialized
INFO - 2023-12-17 06:18:44 --> Language Class Initialized
INFO - 2023-12-17 06:18:44 --> Loader Class Initialized
INFO - 2023-12-17 06:18:44 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:44 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:44 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:44 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:44 --> Controller Class Initialized
INFO - 2023-12-17 06:18:44 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:44 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:44 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:18:44 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:44 --> Total execution time: 0.0907
INFO - 2023-12-17 06:18:44 --> Config Class Initialized
INFO - 2023-12-17 06:18:44 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:44 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:44 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:44 --> URI Class Initialized
INFO - 2023-12-17 06:18:44 --> Router Class Initialized
INFO - 2023-12-17 06:18:44 --> Output Class Initialized
INFO - 2023-12-17 06:18:44 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:44 --> Input Class Initialized
INFO - 2023-12-17 06:18:44 --> Language Class Initialized
INFO - 2023-12-17 06:18:44 --> Loader Class Initialized
INFO - 2023-12-17 06:18:44 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:44 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:44 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:44 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:44 --> Controller Class Initialized
INFO - 2023-12-17 06:18:44 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:44 --> Model "CareerFormModel" initialized
INFO - 2023-12-17 06:18:44 --> Model "Home_model" initialized
INFO - 2023-12-17 06:18:44 --> Helper loaded: download_helper
INFO - 2023-12-17 06:18:44 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:44 --> Form Validation Class Initialized
INFO - 2023-12-17 10:48:44 --> Helper loaded: custom_helper
INFO - 2023-12-17 10:48:44 --> Model "Social_media_model" initialized
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2023-12-17 10:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
INFO - 2023-12-17 10:48:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/404.php
INFO - 2023-12-17 10:48:44 --> Final output sent to browser
DEBUG - 2023-12-17 10:48:44 --> Total execution time: 0.0668
INFO - 2023-12-17 06:18:48 --> Config Class Initialized
INFO - 2023-12-17 06:18:48 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:48 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:48 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:48 --> URI Class Initialized
INFO - 2023-12-17 06:18:48 --> Router Class Initialized
INFO - 2023-12-17 06:18:48 --> Output Class Initialized
INFO - 2023-12-17 06:18:48 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:48 --> Input Class Initialized
INFO - 2023-12-17 06:18:48 --> Language Class Initialized
INFO - 2023-12-17 06:18:48 --> Loader Class Initialized
INFO - 2023-12-17 06:18:48 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:48 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:48 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:48 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:48 --> Controller Class Initialized
INFO - 2023-12-17 06:18:48 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:48 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:48 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:18:48 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:48 --> Total execution time: 0.2034
INFO - 2023-12-17 06:18:48 --> Config Class Initialized
INFO - 2023-12-17 06:18:48 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:49 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:49 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:49 --> URI Class Initialized
INFO - 2023-12-17 06:18:49 --> Router Class Initialized
INFO - 2023-12-17 06:18:49 --> Output Class Initialized
INFO - 2023-12-17 06:18:49 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:49 --> Input Class Initialized
INFO - 2023-12-17 06:18:49 --> Language Class Initialized
INFO - 2023-12-17 06:18:49 --> Loader Class Initialized
INFO - 2023-12-17 06:18:49 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:49 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:49 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:49 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:49 --> Controller Class Initialized
INFO - 2023-12-17 06:18:49 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:49 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:49 --> Form Validation Class Initialized
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 55
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 58
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 61
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 64
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 68
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 71
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 73
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 75
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 86
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
ERROR - 2023-12-17 06:18:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
INFO - 2023-12-17 06:18:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:18:49 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:49 --> Total execution time: 0.1191
INFO - 2023-12-17 06:18:53 --> Config Class Initialized
INFO - 2023-12-17 06:18:53 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:53 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:53 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:53 --> URI Class Initialized
INFO - 2023-12-17 06:18:53 --> Router Class Initialized
INFO - 2023-12-17 06:18:53 --> Output Class Initialized
INFO - 2023-12-17 06:18:53 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:53 --> Input Class Initialized
INFO - 2023-12-17 06:18:53 --> Language Class Initialized
INFO - 2023-12-17 06:18:53 --> Loader Class Initialized
INFO - 2023-12-17 06:18:53 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:53 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:53 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:53 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:53 --> Controller Class Initialized
INFO - 2023-12-17 06:18:53 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:53 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:53 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:53 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:53 --> Total execution time: 0.1252
INFO - 2023-12-17 06:18:55 --> Config Class Initialized
INFO - 2023-12-17 06:18:55 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:55 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:55 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:55 --> URI Class Initialized
INFO - 2023-12-17 06:18:55 --> Router Class Initialized
INFO - 2023-12-17 06:18:55 --> Output Class Initialized
INFO - 2023-12-17 06:18:55 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:55 --> Input Class Initialized
INFO - 2023-12-17 06:18:55 --> Language Class Initialized
INFO - 2023-12-17 06:18:55 --> Loader Class Initialized
INFO - 2023-12-17 06:18:55 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:55 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:55 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:55 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:55 --> Controller Class Initialized
INFO - 2023-12-17 06:18:55 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:55 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:55 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:18:55 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:55 --> Total execution time: 0.0900
INFO - 2023-12-17 06:18:57 --> Config Class Initialized
INFO - 2023-12-17 06:18:57 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:57 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:57 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:57 --> URI Class Initialized
INFO - 2023-12-17 06:18:57 --> Router Class Initialized
INFO - 2023-12-17 06:18:57 --> Output Class Initialized
INFO - 2023-12-17 06:18:57 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:57 --> Input Class Initialized
INFO - 2023-12-17 06:18:57 --> Language Class Initialized
INFO - 2023-12-17 06:18:57 --> Loader Class Initialized
INFO - 2023-12-17 06:18:57 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:57 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:57 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:57 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:57 --> Controller Class Initialized
INFO - 2023-12-17 06:18:57 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:57 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:57 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:18:57 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:57 --> Total execution time: 0.1382
INFO - 2023-12-17 06:18:57 --> Config Class Initialized
INFO - 2023-12-17 06:18:57 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:57 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:57 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:57 --> URI Class Initialized
INFO - 2023-12-17 06:18:57 --> Router Class Initialized
INFO - 2023-12-17 06:18:57 --> Output Class Initialized
INFO - 2023-12-17 06:18:57 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:57 --> Input Class Initialized
INFO - 2023-12-17 06:18:57 --> Language Class Initialized
INFO - 2023-12-17 06:18:57 --> Loader Class Initialized
INFO - 2023-12-17 06:18:57 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:57 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:57 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:57 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:57 --> Controller Class Initialized
INFO - 2023-12-17 06:18:58 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:58 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:58 --> Form Validation Class Initialized
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 55
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 58
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 61
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 64
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 68
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 71
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 73
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 75
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 86
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
ERROR - 2023-12-17 06:18:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
INFO - 2023-12-17 06:18:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:18:58 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:58 --> Total execution time: 0.0637
INFO - 2023-12-17 06:18:59 --> Config Class Initialized
INFO - 2023-12-17 06:18:59 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:59 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:59 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:59 --> URI Class Initialized
INFO - 2023-12-17 06:18:59 --> Router Class Initialized
INFO - 2023-12-17 06:18:59 --> Output Class Initialized
INFO - 2023-12-17 06:18:59 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:59 --> Input Class Initialized
INFO - 2023-12-17 06:18:59 --> Language Class Initialized
INFO - 2023-12-17 06:18:59 --> Loader Class Initialized
INFO - 2023-12-17 06:18:59 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:59 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:59 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:59 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:59 --> Controller Class Initialized
INFO - 2023-12-17 06:18:59 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:59 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:59 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:59 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:59 --> Total execution time: 0.0926
INFO - 2023-12-17 06:18:59 --> Config Class Initialized
INFO - 2023-12-17 06:18:59 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:18:59 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:18:59 --> Utf8 Class Initialized
INFO - 2023-12-17 06:18:59 --> URI Class Initialized
INFO - 2023-12-17 06:18:59 --> Router Class Initialized
INFO - 2023-12-17 06:18:59 --> Output Class Initialized
INFO - 2023-12-17 06:18:59 --> Security Class Initialized
DEBUG - 2023-12-17 06:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:18:59 --> Input Class Initialized
INFO - 2023-12-17 06:18:59 --> Language Class Initialized
INFO - 2023-12-17 06:18:59 --> Loader Class Initialized
INFO - 2023-12-17 06:18:59 --> Helper loaded: url_helper
INFO - 2023-12-17 06:18:59 --> Helper loaded: file_helper
INFO - 2023-12-17 06:18:59 --> Database Driver Class Initialized
INFO - 2023-12-17 06:18:59 --> Email Class Initialized
DEBUG - 2023-12-17 06:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:18:59 --> Controller Class Initialized
INFO - 2023-12-17 06:18:59 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:18:59 --> Helper loaded: form_helper
INFO - 2023-12-17 06:18:59 --> Form Validation Class Initialized
INFO - 2023-12-17 06:18:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:18:59 --> Final output sent to browser
DEBUG - 2023-12-17 06:18:59 --> Total execution time: 0.1025
INFO - 2023-12-17 06:19:01 --> Config Class Initialized
INFO - 2023-12-17 06:19:01 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:01 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:01 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:01 --> URI Class Initialized
INFO - 2023-12-17 06:19:01 --> Router Class Initialized
INFO - 2023-12-17 06:19:01 --> Output Class Initialized
INFO - 2023-12-17 06:19:01 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:01 --> Input Class Initialized
INFO - 2023-12-17 06:19:01 --> Language Class Initialized
INFO - 2023-12-17 06:19:01 --> Loader Class Initialized
INFO - 2023-12-17 06:19:01 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:01 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:01 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:01 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:01 --> Controller Class Initialized
INFO - 2023-12-17 06:19:01 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:02 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:02 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:19:02 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:02 --> Total execution time: 0.1314
INFO - 2023-12-17 06:19:02 --> Config Class Initialized
INFO - 2023-12-17 06:19:02 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:02 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:02 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:02 --> URI Class Initialized
INFO - 2023-12-17 06:19:02 --> Router Class Initialized
INFO - 2023-12-17 06:19:02 --> Output Class Initialized
INFO - 2023-12-17 06:19:02 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:02 --> Input Class Initialized
INFO - 2023-12-17 06:19:02 --> Language Class Initialized
INFO - 2023-12-17 06:19:02 --> Loader Class Initialized
INFO - 2023-12-17 06:19:02 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:02 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:02 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:02 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:02 --> Controller Class Initialized
INFO - 2023-12-17 06:19:02 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:02 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:02 --> Form Validation Class Initialized
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 55
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 58
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 61
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 64
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 68
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 71
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 73
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 75
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 86
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
ERROR - 2023-12-17 06:19:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
INFO - 2023-12-17 06:19:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:19:02 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:02 --> Total execution time: 0.1761
INFO - 2023-12-17 06:19:04 --> Config Class Initialized
INFO - 2023-12-17 06:19:04 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:04 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:04 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:04 --> URI Class Initialized
INFO - 2023-12-17 06:19:04 --> Router Class Initialized
INFO - 2023-12-17 06:19:04 --> Output Class Initialized
INFO - 2023-12-17 06:19:04 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:04 --> Input Class Initialized
INFO - 2023-12-17 06:19:04 --> Language Class Initialized
INFO - 2023-12-17 06:19:04 --> Loader Class Initialized
INFO - 2023-12-17 06:19:04 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:04 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:04 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:04 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:04 --> Controller Class Initialized
INFO - 2023-12-17 06:19:04 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:04 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:04 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:19:04 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:04 --> Total execution time: 0.1754
INFO - 2023-12-17 06:19:06 --> Config Class Initialized
INFO - 2023-12-17 06:19:06 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:06 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:06 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:06 --> URI Class Initialized
INFO - 2023-12-17 06:19:06 --> Router Class Initialized
INFO - 2023-12-17 06:19:06 --> Output Class Initialized
INFO - 2023-12-17 06:19:06 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:06 --> Input Class Initialized
INFO - 2023-12-17 06:19:06 --> Language Class Initialized
INFO - 2023-12-17 06:19:06 --> Loader Class Initialized
INFO - 2023-12-17 06:19:06 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:06 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:06 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:06 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:06 --> Controller Class Initialized
INFO - 2023-12-17 06:19:06 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:06 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:06 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:19:06 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:06 --> Total execution time: 0.0855
INFO - 2023-12-17 06:19:08 --> Config Class Initialized
INFO - 2023-12-17 06:19:08 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:08 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:08 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:08 --> URI Class Initialized
INFO - 2023-12-17 06:19:08 --> Router Class Initialized
INFO - 2023-12-17 06:19:08 --> Output Class Initialized
INFO - 2023-12-17 06:19:08 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:08 --> Input Class Initialized
INFO - 2023-12-17 06:19:08 --> Language Class Initialized
INFO - 2023-12-17 06:19:08 --> Loader Class Initialized
INFO - 2023-12-17 06:19:08 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:08 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:08 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:08 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:08 --> Controller Class Initialized
INFO - 2023-12-17 06:19:08 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:08 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:08 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:19:08 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:08 --> Total execution time: 0.2025
INFO - 2023-12-17 06:19:09 --> Config Class Initialized
INFO - 2023-12-17 06:19:09 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:09 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:09 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:09 --> URI Class Initialized
INFO - 2023-12-17 06:19:09 --> Router Class Initialized
INFO - 2023-12-17 06:19:09 --> Output Class Initialized
INFO - 2023-12-17 06:19:09 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:09 --> Input Class Initialized
INFO - 2023-12-17 06:19:09 --> Language Class Initialized
INFO - 2023-12-17 06:19:09 --> Loader Class Initialized
INFO - 2023-12-17 06:19:09 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:09 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:09 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:09 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:09 --> Controller Class Initialized
INFO - 2023-12-17 06:19:09 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:09 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:09 --> Form Validation Class Initialized
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 55
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 58
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 61
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 64
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 68
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 71
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 73
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 75
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 86
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
ERROR - 2023-12-17 06:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\contact_view.php 94
INFO - 2023-12-17 06:19:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_view.php
INFO - 2023-12-17 06:19:09 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:09 --> Total execution time: 0.0636
INFO - 2023-12-17 06:19:11 --> Config Class Initialized
INFO - 2023-12-17 06:19:11 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:11 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:11 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:11 --> URI Class Initialized
INFO - 2023-12-17 06:19:11 --> Router Class Initialized
INFO - 2023-12-17 06:19:11 --> Output Class Initialized
INFO - 2023-12-17 06:19:11 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:11 --> Input Class Initialized
INFO - 2023-12-17 06:19:11 --> Language Class Initialized
INFO - 2023-12-17 06:19:11 --> Loader Class Initialized
INFO - 2023-12-17 06:19:11 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:11 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:11 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:11 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:11 --> Controller Class Initialized
INFO - 2023-12-17 06:19:11 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:11 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:11 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:11 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:11 --> Total execution time: 0.2265
INFO - 2023-12-17 06:19:14 --> Config Class Initialized
INFO - 2023-12-17 06:19:14 --> Hooks Class Initialized
DEBUG - 2023-12-17 06:19:14 --> UTF-8 Support Enabled
INFO - 2023-12-17 06:19:14 --> Utf8 Class Initialized
INFO - 2023-12-17 06:19:14 --> URI Class Initialized
INFO - 2023-12-17 06:19:14 --> Router Class Initialized
INFO - 2023-12-17 06:19:14 --> Output Class Initialized
INFO - 2023-12-17 06:19:14 --> Security Class Initialized
DEBUG - 2023-12-17 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 06:19:14 --> Input Class Initialized
INFO - 2023-12-17 06:19:14 --> Language Class Initialized
INFO - 2023-12-17 06:19:14 --> Loader Class Initialized
INFO - 2023-12-17 06:19:14 --> Helper loaded: url_helper
INFO - 2023-12-17 06:19:14 --> Helper loaded: file_helper
INFO - 2023-12-17 06:19:14 --> Database Driver Class Initialized
INFO - 2023-12-17 06:19:14 --> Email Class Initialized
DEBUG - 2023-12-17 06:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-17 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 06:19:14 --> Controller Class Initialized
INFO - 2023-12-17 06:19:14 --> Model "Contact_model" initialized
INFO - 2023-12-17 06:19:14 --> Helper loaded: form_helper
INFO - 2023-12-17 06:19:14 --> Form Validation Class Initialized
INFO - 2023-12-17 06:19:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-12-17 06:19:14 --> Final output sent to browser
DEBUG - 2023-12-17 06:19:14 --> Total execution time: 0.0940
