<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-13 05:30:44 --> Config Class Initialized
INFO - 2023-08-13 05:30:44 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:30:44 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:30:44 --> Utf8 Class Initialized
INFO - 2023-08-13 05:30:44 --> URI Class Initialized
INFO - 2023-08-13 05:31:11 --> Config Class Initialized
INFO - 2023-08-13 05:31:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:31:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:31:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:31:11 --> URI Class Initialized
INFO - 2023-08-13 05:31:51 --> Config Class Initialized
INFO - 2023-08-13 05:31:51 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:31:51 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:31:51 --> Utf8 Class Initialized
INFO - 2023-08-13 05:31:51 --> URI Class Initialized
INFO - 2023-08-13 05:31:51 --> Router Class Initialized
INFO - 2023-08-13 05:31:51 --> Output Class Initialized
INFO - 2023-08-13 05:31:51 --> Security Class Initialized
DEBUG - 2023-08-13 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:31:51 --> Input Class Initialized
INFO - 2023-08-13 05:31:51 --> Language Class Initialized
ERROR - 2023-08-13 05:31:51 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:34:24 --> Config Class Initialized
INFO - 2023-08-13 05:34:24 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:34:24 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:34:24 --> Utf8 Class Initialized
INFO - 2023-08-13 05:34:24 --> URI Class Initialized
INFO - 2023-08-13 05:34:24 --> Router Class Initialized
INFO - 2023-08-13 05:34:24 --> Output Class Initialized
INFO - 2023-08-13 05:34:24 --> Security Class Initialized
DEBUG - 2023-08-13 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:34:24 --> Input Class Initialized
INFO - 2023-08-13 05:34:24 --> Language Class Initialized
ERROR - 2023-08-13 05:34:24 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:35:11 --> Config Class Initialized
INFO - 2023-08-13 05:35:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:11 --> URI Class Initialized
INFO - 2023-08-13 05:35:11 --> Router Class Initialized
INFO - 2023-08-13 05:35:11 --> Output Class Initialized
INFO - 2023-08-13 05:35:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:11 --> Input Class Initialized
INFO - 2023-08-13 05:35:11 --> Language Class Initialized
ERROR - 2023-08-13 05:35:11 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:35:12 --> Config Class Initialized
INFO - 2023-08-13 05:35:12 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:12 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:12 --> URI Class Initialized
INFO - 2023-08-13 05:35:12 --> Router Class Initialized
INFO - 2023-08-13 05:35:12 --> Output Class Initialized
INFO - 2023-08-13 05:35:12 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:12 --> Input Class Initialized
INFO - 2023-08-13 05:35:12 --> Language Class Initialized
ERROR - 2023-08-13 05:35:12 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:35:12 --> Config Class Initialized
INFO - 2023-08-13 05:35:12 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:12 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:12 --> URI Class Initialized
INFO - 2023-08-13 05:35:12 --> Router Class Initialized
INFO - 2023-08-13 05:35:12 --> Output Class Initialized
INFO - 2023-08-13 05:35:12 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:12 --> Input Class Initialized
INFO - 2023-08-13 05:35:12 --> Language Class Initialized
ERROR - 2023-08-13 05:35:12 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:35:13 --> Config Class Initialized
INFO - 2023-08-13 05:35:13 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:13 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:13 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:13 --> URI Class Initialized
INFO - 2023-08-13 05:35:13 --> Router Class Initialized
INFO - 2023-08-13 05:35:13 --> Output Class Initialized
INFO - 2023-08-13 05:35:13 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:13 --> Input Class Initialized
INFO - 2023-08-13 05:35:13 --> Language Class Initialized
ERROR - 2023-08-13 05:35:13 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 25
INFO - 2023-08-13 05:35:39 --> Config Class Initialized
INFO - 2023-08-13 05:35:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:39 --> URI Class Initialized
INFO - 2023-08-13 05:35:39 --> Router Class Initialized
INFO - 2023-08-13 05:35:39 --> Output Class Initialized
INFO - 2023-08-13 05:35:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:39 --> Input Class Initialized
INFO - 2023-08-13 05:35:39 --> Language Class Initialized
INFO - 2023-08-13 05:35:39 --> Loader Class Initialized
INFO - 2023-08-13 05:35:39 --> Helper loaded: url_helper
INFO - 2023-08-13 05:35:39 --> Helper loaded: file_helper
INFO - 2023-08-13 05:35:39 --> Database Driver Class Initialized
INFO - 2023-08-13 05:35:39 --> Email Class Initialized
DEBUG - 2023-08-13 05:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:35:39 --> Controller Class Initialized
INFO - 2023-08-13 05:35:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:35:39 --> Final output sent to browser
DEBUG - 2023-08-13 05:35:39 --> Total execution time: 0.1920
INFO - 2023-08-13 05:35:40 --> Config Class Initialized
INFO - 2023-08-13 05:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:40 --> URI Class Initialized
INFO - 2023-08-13 05:35:40 --> Router Class Initialized
INFO - 2023-08-13 05:35:40 --> Output Class Initialized
INFO - 2023-08-13 05:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:40 --> Input Class Initialized
INFO - 2023-08-13 05:35:40 --> Language Class Initialized
ERROR - 2023-08-13 05:35:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:35:40 --> Config Class Initialized
INFO - 2023-08-13 05:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:40 --> URI Class Initialized
INFO - 2023-08-13 05:35:40 --> Router Class Initialized
INFO - 2023-08-13 05:35:40 --> Output Class Initialized
INFO - 2023-08-13 05:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:40 --> Input Class Initialized
INFO - 2023-08-13 05:35:40 --> Language Class Initialized
ERROR - 2023-08-13 05:35:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:35:40 --> Config Class Initialized
INFO - 2023-08-13 05:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:40 --> URI Class Initialized
INFO - 2023-08-13 05:35:40 --> Router Class Initialized
INFO - 2023-08-13 05:35:40 --> Output Class Initialized
INFO - 2023-08-13 05:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:40 --> Input Class Initialized
INFO - 2023-08-13 05:35:40 --> Language Class Initialized
ERROR - 2023-08-13 05:35:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:35:40 --> Config Class Initialized
INFO - 2023-08-13 05:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:40 --> URI Class Initialized
INFO - 2023-08-13 05:35:40 --> Router Class Initialized
INFO - 2023-08-13 05:35:40 --> Output Class Initialized
INFO - 2023-08-13 05:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:40 --> Input Class Initialized
INFO - 2023-08-13 05:35:40 --> Language Class Initialized
ERROR - 2023-08-13 05:35:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:35:41 --> Config Class Initialized
INFO - 2023-08-13 05:35:41 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:41 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:41 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:41 --> URI Class Initialized
INFO - 2023-08-13 05:35:41 --> Router Class Initialized
INFO - 2023-08-13 05:35:41 --> Output Class Initialized
INFO - 2023-08-13 05:35:41 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:41 --> Input Class Initialized
INFO - 2023-08-13 05:35:41 --> Language Class Initialized
ERROR - 2023-08-13 05:35:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:35:41 --> Config Class Initialized
INFO - 2023-08-13 05:35:41 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:35:41 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:35:41 --> Utf8 Class Initialized
INFO - 2023-08-13 05:35:41 --> URI Class Initialized
INFO - 2023-08-13 05:35:41 --> Router Class Initialized
INFO - 2023-08-13 05:35:41 --> Output Class Initialized
INFO - 2023-08-13 05:35:41 --> Security Class Initialized
DEBUG - 2023-08-13 05:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:35:41 --> Input Class Initialized
INFO - 2023-08-13 05:35:41 --> Language Class Initialized
ERROR - 2023-08-13 05:35:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:36:57 --> Config Class Initialized
INFO - 2023-08-13 05:36:57 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:36:57 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:36:57 --> Utf8 Class Initialized
INFO - 2023-08-13 05:36:57 --> URI Class Initialized
INFO - 2023-08-13 05:36:57 --> Router Class Initialized
INFO - 2023-08-13 05:36:57 --> Output Class Initialized
INFO - 2023-08-13 05:36:57 --> Security Class Initialized
DEBUG - 2023-08-13 05:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:36:57 --> Input Class Initialized
INFO - 2023-08-13 05:36:57 --> Language Class Initialized
INFO - 2023-08-13 05:36:57 --> Loader Class Initialized
INFO - 2023-08-13 05:36:57 --> Helper loaded: url_helper
INFO - 2023-08-13 05:36:57 --> Helper loaded: file_helper
INFO - 2023-08-13 05:36:57 --> Database Driver Class Initialized
INFO - 2023-08-13 05:36:57 --> Email Class Initialized
DEBUG - 2023-08-13 05:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:36:57 --> Controller Class Initialized
ERROR - 2023-08-13 05:36:57 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2023-08-13 05:36:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
INFO - 2023-08-13 05:36:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:36:57 --> Final output sent to browser
DEBUG - 2023-08-13 05:36:57 --> Total execution time: 0.4786
INFO - 2023-08-13 05:36:58 --> Config Class Initialized
INFO - 2023-08-13 05:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:36:58 --> Utf8 Class Initialized
INFO - 2023-08-13 05:36:58 --> URI Class Initialized
INFO - 2023-08-13 05:36:58 --> Router Class Initialized
INFO - 2023-08-13 05:36:58 --> Output Class Initialized
INFO - 2023-08-13 05:36:58 --> Security Class Initialized
DEBUG - 2023-08-13 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:36:58 --> Input Class Initialized
INFO - 2023-08-13 05:36:58 --> Language Class Initialized
ERROR - 2023-08-13 05:36:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:36:58 --> Config Class Initialized
INFO - 2023-08-13 05:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:36:58 --> Utf8 Class Initialized
INFO - 2023-08-13 05:36:58 --> URI Class Initialized
INFO - 2023-08-13 05:36:58 --> Router Class Initialized
INFO - 2023-08-13 05:36:58 --> Output Class Initialized
INFO - 2023-08-13 05:36:58 --> Security Class Initialized
DEBUG - 2023-08-13 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:36:58 --> Input Class Initialized
INFO - 2023-08-13 05:36:58 --> Language Class Initialized
ERROR - 2023-08-13 05:36:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:36:58 --> Config Class Initialized
INFO - 2023-08-13 05:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:36:58 --> Utf8 Class Initialized
INFO - 2023-08-13 05:36:58 --> URI Class Initialized
INFO - 2023-08-13 05:36:58 --> Router Class Initialized
INFO - 2023-08-13 05:36:58 --> Output Class Initialized
INFO - 2023-08-13 05:36:58 --> Security Class Initialized
DEBUG - 2023-08-13 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:36:58 --> Input Class Initialized
INFO - 2023-08-13 05:36:58 --> Language Class Initialized
ERROR - 2023-08-13 05:36:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:36:58 --> Config Class Initialized
INFO - 2023-08-13 05:36:58 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:36:58 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:36:58 --> Utf8 Class Initialized
INFO - 2023-08-13 05:36:58 --> URI Class Initialized
INFO - 2023-08-13 05:36:58 --> Router Class Initialized
INFO - 2023-08-13 05:36:58 --> Output Class Initialized
INFO - 2023-08-13 05:36:59 --> Security Class Initialized
DEBUG - 2023-08-13 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:36:59 --> Input Class Initialized
INFO - 2023-08-13 05:36:59 --> Language Class Initialized
ERROR - 2023-08-13 05:36:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:37:47 --> Config Class Initialized
INFO - 2023-08-13 05:37:47 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:37:47 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:37:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:37:47 --> URI Class Initialized
INFO - 2023-08-13 05:37:47 --> Router Class Initialized
INFO - 2023-08-13 05:37:47 --> Output Class Initialized
INFO - 2023-08-13 05:37:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:37:47 --> Input Class Initialized
INFO - 2023-08-13 05:37:47 --> Language Class Initialized
INFO - 2023-08-13 05:37:47 --> Loader Class Initialized
INFO - 2023-08-13 05:37:47 --> Helper loaded: url_helper
INFO - 2023-08-13 05:37:47 --> Helper loaded: file_helper
INFO - 2023-08-13 05:37:47 --> Database Driver Class Initialized
INFO - 2023-08-13 05:37:47 --> Email Class Initialized
DEBUG - 2023-08-13 05:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:37:47 --> Controller Class Initialized
ERROR - 2023-08-13 05:37:47 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2023-08-13 05:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
INFO - 2023-08-13 05:37:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:37:47 --> Final output sent to browser
DEBUG - 2023-08-13 05:37:47 --> Total execution time: 0.1982
INFO - 2023-08-13 05:37:47 --> Config Class Initialized
INFO - 2023-08-13 05:37:47 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:37:47 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:37:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:37:47 --> URI Class Initialized
INFO - 2023-08-13 05:37:47 --> Router Class Initialized
INFO - 2023-08-13 05:37:47 --> Output Class Initialized
INFO - 2023-08-13 05:37:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:37:47 --> Input Class Initialized
INFO - 2023-08-13 05:37:47 --> Language Class Initialized
ERROR - 2023-08-13 05:37:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:37:48 --> Config Class Initialized
INFO - 2023-08-13 05:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:37:48 --> Utf8 Class Initialized
INFO - 2023-08-13 05:37:48 --> URI Class Initialized
INFO - 2023-08-13 05:37:48 --> Router Class Initialized
INFO - 2023-08-13 05:37:48 --> Output Class Initialized
INFO - 2023-08-13 05:37:48 --> Security Class Initialized
DEBUG - 2023-08-13 05:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:37:48 --> Input Class Initialized
INFO - 2023-08-13 05:37:48 --> Language Class Initialized
ERROR - 2023-08-13 05:37:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:37:48 --> Config Class Initialized
INFO - 2023-08-13 05:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:37:48 --> Utf8 Class Initialized
INFO - 2023-08-13 05:37:48 --> URI Class Initialized
INFO - 2023-08-13 05:37:48 --> Router Class Initialized
INFO - 2023-08-13 05:37:48 --> Output Class Initialized
INFO - 2023-08-13 05:37:48 --> Security Class Initialized
DEBUG - 2023-08-13 05:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:37:48 --> Input Class Initialized
INFO - 2023-08-13 05:37:48 --> Language Class Initialized
ERROR - 2023-08-13 05:37:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:37:48 --> Config Class Initialized
INFO - 2023-08-13 05:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:37:48 --> Utf8 Class Initialized
INFO - 2023-08-13 05:37:48 --> URI Class Initialized
INFO - 2023-08-13 05:37:48 --> Router Class Initialized
INFO - 2023-08-13 05:37:48 --> Output Class Initialized
INFO - 2023-08-13 05:37:48 --> Security Class Initialized
DEBUG - 2023-08-13 05:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:37:48 --> Input Class Initialized
INFO - 2023-08-13 05:37:48 --> Language Class Initialized
ERROR - 2023-08-13 05:37:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:25 --> Config Class Initialized
INFO - 2023-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:25 --> URI Class Initialized
INFO - 2023-08-13 05:38:25 --> Router Class Initialized
INFO - 2023-08-13 05:38:25 --> Output Class Initialized
INFO - 2023-08-13 05:38:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:25 --> Input Class Initialized
INFO - 2023-08-13 05:38:25 --> Language Class Initialized
INFO - 2023-08-13 05:38:25 --> Loader Class Initialized
INFO - 2023-08-13 05:38:25 --> Helper loaded: url_helper
INFO - 2023-08-13 05:38:25 --> Helper loaded: file_helper
INFO - 2023-08-13 05:38:25 --> Database Driver Class Initialized
INFO - 2023-08-13 05:38:25 --> Email Class Initialized
DEBUG - 2023-08-13 05:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:38:25 --> Controller Class Initialized
ERROR - 2023-08-13 05:38:25 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\dw\application\views\home\index.php 8
ERROR - 2023-08-13 05:38:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\index.php 8
INFO - 2023-08-13 05:38:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:38:25 --> Final output sent to browser
DEBUG - 2023-08-13 05:38:25 --> Total execution time: 0.0990
INFO - 2023-08-13 05:38:25 --> Config Class Initialized
INFO - 2023-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:25 --> URI Class Initialized
INFO - 2023-08-13 05:38:25 --> Router Class Initialized
INFO - 2023-08-13 05:38:25 --> Output Class Initialized
INFO - 2023-08-13 05:38:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:25 --> Input Class Initialized
INFO - 2023-08-13 05:38:25 --> Language Class Initialized
ERROR - 2023-08-13 05:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:25 --> Config Class Initialized
INFO - 2023-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:25 --> URI Class Initialized
INFO - 2023-08-13 05:38:25 --> Router Class Initialized
INFO - 2023-08-13 05:38:25 --> Output Class Initialized
INFO - 2023-08-13 05:38:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:25 --> Input Class Initialized
INFO - 2023-08-13 05:38:25 --> Language Class Initialized
ERROR - 2023-08-13 05:38:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:38:25 --> Config Class Initialized
INFO - 2023-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:25 --> URI Class Initialized
INFO - 2023-08-13 05:38:25 --> Router Class Initialized
INFO - 2023-08-13 05:38:25 --> Output Class Initialized
INFO - 2023-08-13 05:38:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:25 --> Input Class Initialized
INFO - 2023-08-13 05:38:25 --> Language Class Initialized
ERROR - 2023-08-13 05:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:25 --> Config Class Initialized
INFO - 2023-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:26 --> URI Class Initialized
INFO - 2023-08-13 05:38:26 --> Router Class Initialized
INFO - 2023-08-13 05:38:26 --> Output Class Initialized
INFO - 2023-08-13 05:38:26 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:26 --> Input Class Initialized
INFO - 2023-08-13 05:38:26 --> Language Class Initialized
ERROR - 2023-08-13 05:38:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:26 --> Config Class Initialized
INFO - 2023-08-13 05:38:26 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:26 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:26 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:26 --> URI Class Initialized
INFO - 2023-08-13 05:38:26 --> Router Class Initialized
INFO - 2023-08-13 05:38:26 --> Output Class Initialized
INFO - 2023-08-13 05:38:26 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:26 --> Input Class Initialized
INFO - 2023-08-13 05:38:26 --> Language Class Initialized
ERROR - 2023-08-13 05:38:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:38:32 --> Config Class Initialized
INFO - 2023-08-13 05:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:32 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:32 --> URI Class Initialized
INFO - 2023-08-13 05:38:32 --> Router Class Initialized
INFO - 2023-08-13 05:38:32 --> Output Class Initialized
INFO - 2023-08-13 05:38:32 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:32 --> Input Class Initialized
INFO - 2023-08-13 05:38:32 --> Language Class Initialized
INFO - 2023-08-13 05:38:32 --> Loader Class Initialized
INFO - 2023-08-13 05:38:32 --> Helper loaded: url_helper
INFO - 2023-08-13 05:38:32 --> Helper loaded: file_helper
INFO - 2023-08-13 05:38:32 --> Database Driver Class Initialized
INFO - 2023-08-13 05:38:32 --> Email Class Initialized
DEBUG - 2023-08-13 05:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:38:32 --> Controller Class Initialized
ERROR - 2023-08-13 05:38:32 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\dw\application\views\home\index.php 8
ERROR - 2023-08-13 05:38:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\index.php 8
INFO - 2023-08-13 05:38:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:38:32 --> Final output sent to browser
DEBUG - 2023-08-13 05:38:32 --> Total execution time: 0.0597
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:38:33 --> Config Class Initialized
INFO - 2023-08-13 05:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:38:33 --> Utf8 Class Initialized
INFO - 2023-08-13 05:38:33 --> URI Class Initialized
INFO - 2023-08-13 05:38:33 --> Router Class Initialized
INFO - 2023-08-13 05:38:33 --> Output Class Initialized
INFO - 2023-08-13 05:38:33 --> Security Class Initialized
DEBUG - 2023-08-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:38:33 --> Input Class Initialized
INFO - 2023-08-13 05:38:33 --> Language Class Initialized
ERROR - 2023-08-13 05:38:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:39:11 --> Config Class Initialized
INFO - 2023-08-13 05:39:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:39:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:11 --> URI Class Initialized
INFO - 2023-08-13 05:39:11 --> Router Class Initialized
INFO - 2023-08-13 05:39:11 --> Output Class Initialized
INFO - 2023-08-13 05:39:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:11 --> Input Class Initialized
INFO - 2023-08-13 05:39:11 --> Language Class Initialized
INFO - 2023-08-13 05:39:11 --> Loader Class Initialized
INFO - 2023-08-13 05:39:11 --> Helper loaded: url_helper
INFO - 2023-08-13 05:39:11 --> Helper loaded: file_helper
INFO - 2023-08-13 05:39:11 --> Database Driver Class Initialized
INFO - 2023-08-13 05:39:11 --> Email Class Initialized
DEBUG - 2023-08-13 05:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:39:11 --> Controller Class Initialized
INFO - 2023-08-13 05:39:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:39:11 --> Final output sent to browser
DEBUG - 2023-08-13 05:39:12 --> Total execution time: 0.4421
INFO - 2023-08-13 05:39:12 --> Config Class Initialized
INFO - 2023-08-13 05:39:12 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:12 --> Config Class Initialized
INFO - 2023-08-13 05:39:12 --> Config Class Initialized
INFO - 2023-08-13 05:39:12 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:12 --> Config Class Initialized
INFO - 2023-08-13 05:39:12 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:12 --> Utf8 Class Initialized
DEBUG - 2023-08-13 05:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:12 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:12 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:12 --> URI Class Initialized
INFO - 2023-08-13 05:39:12 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:12 --> URI Class Initialized
INFO - 2023-08-13 05:39:12 --> Router Class Initialized
INFO - 2023-08-13 05:39:12 --> Router Class Initialized
INFO - 2023-08-13 05:39:12 --> URI Class Initialized
INFO - 2023-08-13 05:39:12 --> Router Class Initialized
DEBUG - 2023-08-13 05:39:12 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:12 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:12 --> Output Class Initialized
INFO - 2023-08-13 05:39:12 --> Security Class Initialized
INFO - 2023-08-13 05:39:12 --> Output Class Initialized
DEBUG - 2023-08-13 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:12 --> Security Class Initialized
INFO - 2023-08-13 05:39:12 --> Input Class Initialized
INFO - 2023-08-13 05:39:12 --> Output Class Initialized
INFO - 2023-08-13 05:39:12 --> URI Class Initialized
INFO - 2023-08-13 05:39:12 --> Language Class Initialized
DEBUG - 2023-08-13 05:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:39:12 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:39:12 --> Security Class Initialized
INFO - 2023-08-13 05:39:12 --> Input Class Initialized
INFO - 2023-08-13 05:39:12 --> Router Class Initialized
INFO - 2023-08-13 05:39:12 --> Language Class Initialized
INFO - 2023-08-13 05:39:12 --> Output Class Initialized
DEBUG - 2023-08-13 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:12 --> Security Class Initialized
INFO - 2023-08-13 05:39:12 --> Input Class Initialized
INFO - 2023-08-13 05:39:12 --> Language Class Initialized
ERROR - 2023-08-13 05:39:12 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-13 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:12 --> Input Class Initialized
ERROR - 2023-08-13 05:39:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:39:12 --> Language Class Initialized
ERROR - 2023-08-13 05:39:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:39:24 --> Config Class Initialized
INFO - 2023-08-13 05:39:24 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:39:24 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:24 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:24 --> URI Class Initialized
INFO - 2023-08-13 05:39:24 --> Router Class Initialized
INFO - 2023-08-13 05:39:24 --> Output Class Initialized
INFO - 2023-08-13 05:39:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:25 --> Input Class Initialized
INFO - 2023-08-13 05:39:25 --> Language Class Initialized
INFO - 2023-08-13 05:39:25 --> Loader Class Initialized
INFO - 2023-08-13 05:39:25 --> Helper loaded: url_helper
INFO - 2023-08-13 05:39:25 --> Helper loaded: file_helper
INFO - 2023-08-13 05:39:25 --> Database Driver Class Initialized
INFO - 2023-08-13 05:39:25 --> Email Class Initialized
DEBUG - 2023-08-13 05:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:39:25 --> Controller Class Initialized
INFO - 2023-08-13 05:39:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:39:25 --> Final output sent to browser
DEBUG - 2023-08-13 05:39:25 --> Total execution time: 0.2868
INFO - 2023-08-13 05:39:25 --> Config Class Initialized
INFO - 2023-08-13 05:39:25 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:25 --> Config Class Initialized
INFO - 2023-08-13 05:39:25 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:25 --> Config Class Initialized
DEBUG - 2023-08-13 05:39:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-13 05:39:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:26 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:26 --> Config Class Initialized
INFO - 2023-08-13 05:39:26 --> URI Class Initialized
INFO - 2023-08-13 05:39:26 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:26 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:26 --> Hooks Class Initialized
INFO - 2023-08-13 05:39:26 --> Router Class Initialized
DEBUG - 2023-08-13 05:39:26 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:26 --> URI Class Initialized
INFO - 2023-08-13 05:39:26 --> Utf8 Class Initialized
DEBUG - 2023-08-13 05:39:26 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:39:26 --> URI Class Initialized
INFO - 2023-08-13 05:39:26 --> Output Class Initialized
INFO - 2023-08-13 05:39:26 --> Router Class Initialized
INFO - 2023-08-13 05:39:26 --> Router Class Initialized
INFO - 2023-08-13 05:39:26 --> Utf8 Class Initialized
INFO - 2023-08-13 05:39:26 --> Output Class Initialized
INFO - 2023-08-13 05:39:26 --> Security Class Initialized
INFO - 2023-08-13 05:39:26 --> Output Class Initialized
DEBUG - 2023-08-13 05:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:26 --> Input Class Initialized
INFO - 2023-08-13 05:39:26 --> Security Class Initialized
DEBUG - 2023-08-13 05:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:26 --> URI Class Initialized
INFO - 2023-08-13 05:39:26 --> Input Class Initialized
INFO - 2023-08-13 05:39:26 --> Security Class Initialized
INFO - 2023-08-13 05:39:26 --> Language Class Initialized
INFO - 2023-08-13 05:39:26 --> Router Class Initialized
ERROR - 2023-08-13 05:39:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:39:26 --> Output Class Initialized
DEBUG - 2023-08-13 05:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:39:26 --> Language Class Initialized
INFO - 2023-08-13 05:39:26 --> Input Class Initialized
ERROR - 2023-08-13 05:39:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:39:26 --> Security Class Initialized
INFO - 2023-08-13 05:39:26 --> Language Class Initialized
DEBUG - 2023-08-13 05:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:39:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:39:26 --> Input Class Initialized
INFO - 2023-08-13 05:39:26 --> Language Class Initialized
ERROR - 2023-08-13 05:39:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:17 --> Config Class Initialized
INFO - 2023-08-13 05:43:17 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:43:17 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:17 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:17 --> URI Class Initialized
INFO - 2023-08-13 05:43:17 --> Router Class Initialized
INFO - 2023-08-13 05:43:17 --> Output Class Initialized
INFO - 2023-08-13 05:43:17 --> Security Class Initialized
DEBUG - 2023-08-13 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:17 --> Input Class Initialized
INFO - 2023-08-13 05:43:17 --> Language Class Initialized
INFO - 2023-08-13 05:43:17 --> Loader Class Initialized
INFO - 2023-08-13 05:43:18 --> Helper loaded: url_helper
INFO - 2023-08-13 05:43:18 --> Helper loaded: file_helper
INFO - 2023-08-13 05:43:18 --> Database Driver Class Initialized
INFO - 2023-08-13 05:43:18 --> Email Class Initialized
DEBUG - 2023-08-13 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:43:18 --> Controller Class Initialized
INFO - 2023-08-13 05:43:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:43:18 --> Final output sent to browser
DEBUG - 2023-08-13 05:43:18 --> Total execution time: 0.4745
INFO - 2023-08-13 05:43:18 --> Config Class Initialized
INFO - 2023-08-13 05:43:18 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:43:18 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:18 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:18 --> URI Class Initialized
INFO - 2023-08-13 05:43:18 --> Router Class Initialized
INFO - 2023-08-13 05:43:18 --> Output Class Initialized
INFO - 2023-08-13 05:43:18 --> Security Class Initialized
DEBUG - 2023-08-13 05:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:18 --> Input Class Initialized
INFO - 2023-08-13 05:43:18 --> Language Class Initialized
ERROR - 2023-08-13 05:43:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:43:19 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:19 --> Utf8 Class Initialized
DEBUG - 2023-08-13 05:43:19 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:19 --> URI Class Initialized
INFO - 2023-08-13 05:43:19 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:19 --> URI Class Initialized
INFO - 2023-08-13 05:43:19 --> Router Class Initialized
INFO - 2023-08-13 05:43:19 --> Router Class Initialized
INFO - 2023-08-13 05:43:19 --> Output Class Initialized
INFO - 2023-08-13 05:43:19 --> Output Class Initialized
INFO - 2023-08-13 05:43:19 --> Security Class Initialized
INFO - 2023-08-13 05:43:19 --> Security Class Initialized
DEBUG - 2023-08-13 05:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-13 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:19 --> Input Class Initialized
INFO - 2023-08-13 05:43:19 --> Language Class Initialized
INFO - 2023-08-13 05:43:19 --> Input Class Initialized
ERROR - 2023-08-13 05:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:19 --> Language Class Initialized
ERROR - 2023-08-13 05:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
DEBUG - 2023-08-13 05:43:19 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:19 --> Config Class Initialized
INFO - 2023-08-13 05:43:19 --> Utf8 Class Initialized
DEBUG - 2023-08-13 05:43:19 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:19 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:19 --> URI Class Initialized
INFO - 2023-08-13 05:43:19 --> Router Class Initialized
INFO - 2023-08-13 05:43:19 --> Output Class Initialized
INFO - 2023-08-13 05:43:19 --> Security Class Initialized
DEBUG - 2023-08-13 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:19 --> Input Class Initialized
INFO - 2023-08-13 05:43:19 --> Language Class Initialized
ERROR - 2023-08-13 05:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:19 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> Config Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:20 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:43:20 --> Output Class Initialized
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:20 --> Config Class Initialized
INFO - 2023-08-13 05:43:20 --> Security Class Initialized
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
DEBUG - 2023-08-13 05:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:43:20 --> Input Class Initialized
INFO - 2023-08-13 05:43:20 --> Hooks Class Initialized
INFO - 2023-08-13 05:43:20 --> Language Class Initialized
DEBUG - 2023-08-13 05:43:20 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:43:20 --> Utf8 Class Initialized
ERROR - 2023-08-13 05:43:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:43:20 --> URI Class Initialized
INFO - 2023-08-13 05:43:20 --> Router Class Initialized
INFO - 2023-08-13 05:43:21 --> Output Class Initialized
INFO - 2023-08-13 05:43:21 --> Security Class Initialized
DEBUG - 2023-08-13 05:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:43:21 --> Input Class Initialized
INFO - 2023-08-13 05:43:21 --> Language Class Initialized
ERROR - 2023-08-13 05:43:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:09 --> Config Class Initialized
INFO - 2023-08-13 05:45:09 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:09 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:10 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:10 --> URI Class Initialized
INFO - 2023-08-13 05:45:10 --> Router Class Initialized
INFO - 2023-08-13 05:45:10 --> Output Class Initialized
INFO - 2023-08-13 05:45:10 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:10 --> Input Class Initialized
INFO - 2023-08-13 05:45:10 --> Language Class Initialized
INFO - 2023-08-13 05:45:10 --> Loader Class Initialized
INFO - 2023-08-13 05:45:10 --> Helper loaded: url_helper
INFO - 2023-08-13 05:45:10 --> Helper loaded: file_helper
INFO - 2023-08-13 05:45:10 --> Database Driver Class Initialized
INFO - 2023-08-13 05:45:10 --> Email Class Initialized
DEBUG - 2023-08-13 05:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:45:10 --> Controller Class Initialized
INFO - 2023-08-13 05:45:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:45:10 --> Final output sent to browser
DEBUG - 2023-08-13 05:45:10 --> Total execution time: 0.2688
INFO - 2023-08-13 05:45:10 --> Config Class Initialized
INFO - 2023-08-13 05:45:10 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:11 --> Config Class Initialized
INFO - 2023-08-13 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:11 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:11 --> URI Class Initialized
INFO - 2023-08-13 05:45:11 --> Router Class Initialized
INFO - 2023-08-13 05:45:11 --> Output Class Initialized
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:11 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:11 --> Input Class Initialized
INFO - 2023-08-13 05:45:11 --> Language Class Initialized
ERROR - 2023-08-13 05:45:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
INFO - 2023-08-13 05:45:15 --> Loader Class Initialized
INFO - 2023-08-13 05:45:15 --> Helper loaded: url_helper
INFO - 2023-08-13 05:45:15 --> Helper loaded: file_helper
INFO - 2023-08-13 05:45:15 --> Database Driver Class Initialized
INFO - 2023-08-13 05:45:15 --> Email Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:45:15 --> Controller Class Initialized
INFO - 2023-08-13 05:45:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:45:15 --> Final output sent to browser
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-13 05:45:15 --> Total execution time: 0.1410
INFO - 2023-08-13 05:45:15 --> Config Class Initialized
INFO - 2023-08-13 05:45:15 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:15 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:15 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:15 --> URI Class Initialized
INFO - 2023-08-13 05:45:15 --> Router Class Initialized
INFO - 2023-08-13 05:45:15 --> Output Class Initialized
INFO - 2023-08-13 05:45:15 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:15 --> Input Class Initialized
INFO - 2023-08-13 05:45:15 --> Language Class Initialized
ERROR - 2023-08-13 05:45:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:45:16 --> Config Class Initialized
INFO - 2023-08-13 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:16 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:16 --> URI Class Initialized
INFO - 2023-08-13 05:45:16 --> Router Class Initialized
INFO - 2023-08-13 05:45:16 --> Output Class Initialized
INFO - 2023-08-13 05:45:16 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:16 --> Input Class Initialized
INFO - 2023-08-13 05:45:16 --> Language Class Initialized
ERROR - 2023-08-13 05:45:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:45:16 --> Config Class Initialized
INFO - 2023-08-13 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:45:16 --> Utf8 Class Initialized
INFO - 2023-08-13 05:45:16 --> URI Class Initialized
INFO - 2023-08-13 05:45:16 --> Router Class Initialized
INFO - 2023-08-13 05:45:16 --> Output Class Initialized
INFO - 2023-08-13 05:45:16 --> Security Class Initialized
DEBUG - 2023-08-13 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:45:16 --> Input Class Initialized
INFO - 2023-08-13 05:45:16 --> Language Class Initialized
ERROR - 2023-08-13 05:45:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:47:37 --> Config Class Initialized
INFO - 2023-08-13 05:47:37 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:47:37 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:47:37 --> Utf8 Class Initialized
INFO - 2023-08-13 05:47:37 --> URI Class Initialized
INFO - 2023-08-13 05:47:37 --> Router Class Initialized
INFO - 2023-08-13 05:47:37 --> Output Class Initialized
INFO - 2023-08-13 05:47:37 --> Security Class Initialized
DEBUG - 2023-08-13 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:47:37 --> Input Class Initialized
INFO - 2023-08-13 05:47:37 --> Language Class Initialized
INFO - 2023-08-13 05:47:37 --> Loader Class Initialized
INFO - 2023-08-13 05:47:37 --> Helper loaded: url_helper
INFO - 2023-08-13 05:47:37 --> Helper loaded: file_helper
INFO - 2023-08-13 05:47:37 --> Database Driver Class Initialized
INFO - 2023-08-13 05:47:37 --> Email Class Initialized
DEBUG - 2023-08-13 05:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:47:37 --> Controller Class Initialized
INFO - 2023-08-13 05:47:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:47:38 --> Final output sent to browser
DEBUG - 2023-08-13 05:47:38 --> Total execution time: 0.4518
INFO - 2023-08-13 05:47:38 --> Config Class Initialized
INFO - 2023-08-13 05:47:38 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:47:38 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:47:38 --> Utf8 Class Initialized
INFO - 2023-08-13 05:47:38 --> URI Class Initialized
INFO - 2023-08-13 05:47:38 --> Router Class Initialized
INFO - 2023-08-13 05:47:38 --> Output Class Initialized
INFO - 2023-08-13 05:47:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:47:39 --> Input Class Initialized
INFO - 2023-08-13 05:47:39 --> Language Class Initialized
ERROR - 2023-08-13 05:47:39 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:47:39 --> Config Class Initialized
INFO - 2023-08-13 05:47:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:47:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:47:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:47:39 --> URI Class Initialized
INFO - 2023-08-13 05:47:39 --> Router Class Initialized
INFO - 2023-08-13 05:47:39 --> Output Class Initialized
INFO - 2023-08-13 05:47:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:47:39 --> Input Class Initialized
INFO - 2023-08-13 05:47:39 --> Language Class Initialized
ERROR - 2023-08-13 05:47:39 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:47:39 --> Config Class Initialized
INFO - 2023-08-13 05:47:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:47:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:47:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:47:39 --> URI Class Initialized
INFO - 2023-08-13 05:47:39 --> Router Class Initialized
INFO - 2023-08-13 05:47:39 --> Output Class Initialized
INFO - 2023-08-13 05:47:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:47:39 --> Input Class Initialized
INFO - 2023-08-13 05:47:39 --> Language Class Initialized
ERROR - 2023-08-13 05:47:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:47:39 --> Config Class Initialized
INFO - 2023-08-13 05:47:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:47:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:47:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:47:39 --> URI Class Initialized
INFO - 2023-08-13 05:47:39 --> Router Class Initialized
INFO - 2023-08-13 05:47:39 --> Output Class Initialized
INFO - 2023-08-13 05:47:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:47:39 --> Input Class Initialized
INFO - 2023-08-13 05:47:39 --> Language Class Initialized
ERROR - 2023-08-13 05:47:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:51:30 --> Config Class Initialized
INFO - 2023-08-13 05:51:30 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:30 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:30 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:30 --> URI Class Initialized
INFO - 2023-08-13 05:51:30 --> Router Class Initialized
INFO - 2023-08-13 05:51:30 --> Output Class Initialized
INFO - 2023-08-13 05:51:30 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:30 --> Input Class Initialized
INFO - 2023-08-13 05:51:30 --> Language Class Initialized
INFO - 2023-08-13 05:51:30 --> Loader Class Initialized
INFO - 2023-08-13 05:51:30 --> Helper loaded: url_helper
INFO - 2023-08-13 05:51:30 --> Helper loaded: file_helper
INFO - 2023-08-13 05:51:30 --> Database Driver Class Initialized
INFO - 2023-08-13 05:51:30 --> Email Class Initialized
DEBUG - 2023-08-13 05:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:51:30 --> Controller Class Initialized
INFO - 2023-08-13 05:51:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-13 05:51:30 --> Final output sent to browser
DEBUG - 2023-08-13 05:51:31 --> Total execution time: 0.1743
INFO - 2023-08-13 05:51:31 --> Config Class Initialized
INFO - 2023-08-13 05:51:31 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:31 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:31 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:31 --> URI Class Initialized
INFO - 2023-08-13 05:51:31 --> Router Class Initialized
INFO - 2023-08-13 05:51:31 --> Output Class Initialized
INFO - 2023-08-13 05:51:31 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:31 --> Input Class Initialized
INFO - 2023-08-13 05:51:31 --> Language Class Initialized
ERROR - 2023-08-13 05:51:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:51:31 --> Config Class Initialized
INFO - 2023-08-13 05:51:31 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:31 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:31 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:31 --> URI Class Initialized
INFO - 2023-08-13 05:51:31 --> Router Class Initialized
INFO - 2023-08-13 05:51:31 --> Output Class Initialized
INFO - 2023-08-13 05:51:31 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:31 --> Input Class Initialized
INFO - 2023-08-13 05:51:31 --> Language Class Initialized
ERROR - 2023-08-13 05:51:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:51:31 --> Config Class Initialized
INFO - 2023-08-13 05:51:31 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:31 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:31 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:31 --> URI Class Initialized
INFO - 2023-08-13 05:51:31 --> Router Class Initialized
INFO - 2023-08-13 05:51:31 --> Output Class Initialized
INFO - 2023-08-13 05:51:31 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:31 --> Input Class Initialized
INFO - 2023-08-13 05:51:31 --> Language Class Initialized
ERROR - 2023-08-13 05:51:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:51:31 --> Config Class Initialized
INFO - 2023-08-13 05:51:31 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:31 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:31 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:31 --> URI Class Initialized
INFO - 2023-08-13 05:51:32 --> Router Class Initialized
INFO - 2023-08-13 05:51:32 --> Output Class Initialized
INFO - 2023-08-13 05:51:32 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:32 --> Input Class Initialized
INFO - 2023-08-13 05:51:32 --> Language Class Initialized
ERROR - 2023-08-13 05:51:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:51:32 --> Config Class Initialized
INFO - 2023-08-13 05:51:32 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:32 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:32 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:32 --> URI Class Initialized
INFO - 2023-08-13 05:51:32 --> Router Class Initialized
INFO - 2023-08-13 05:51:32 --> Output Class Initialized
INFO - 2023-08-13 05:51:32 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:32 --> Input Class Initialized
INFO - 2023-08-13 05:51:32 --> Language Class Initialized
ERROR - 2023-08-13 05:51:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:51:46 --> Config Class Initialized
INFO - 2023-08-13 05:51:46 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:46 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:47 --> URI Class Initialized
INFO - 2023-08-13 05:51:47 --> Router Class Initialized
INFO - 2023-08-13 05:51:47 --> Output Class Initialized
INFO - 2023-08-13 05:51:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:47 --> Input Class Initialized
INFO - 2023-08-13 05:51:47 --> Language Class Initialized
INFO - 2023-08-13 05:51:47 --> Loader Class Initialized
INFO - 2023-08-13 05:51:47 --> Helper loaded: url_helper
INFO - 2023-08-13 05:51:47 --> Helper loaded: file_helper
INFO - 2023-08-13 05:51:47 --> Database Driver Class Initialized
INFO - 2023-08-13 05:51:47 --> Email Class Initialized
DEBUG - 2023-08-13 05:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:51:47 --> Controller Class Initialized
INFO - 2023-08-13 05:51:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-13 05:51:47 --> Final output sent to browser
DEBUG - 2023-08-13 05:51:47 --> Total execution time: 0.7279
INFO - 2023-08-13 05:51:47 --> Config Class Initialized
INFO - 2023-08-13 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:47 --> URI Class Initialized
INFO - 2023-08-13 05:51:47 --> Router Class Initialized
INFO - 2023-08-13 05:51:47 --> Output Class Initialized
INFO - 2023-08-13 05:51:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:47 --> Input Class Initialized
INFO - 2023-08-13 05:51:47 --> Language Class Initialized
ERROR - 2023-08-13 05:51:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:51:48 --> Config Class Initialized
INFO - 2023-08-13 05:51:48 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:51:48 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:51:48 --> Utf8 Class Initialized
INFO - 2023-08-13 05:51:48 --> URI Class Initialized
INFO - 2023-08-13 05:51:48 --> Router Class Initialized
INFO - 2023-08-13 05:51:48 --> Output Class Initialized
INFO - 2023-08-13 05:51:48 --> Security Class Initialized
DEBUG - 2023-08-13 05:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:51:48 --> Input Class Initialized
INFO - 2023-08-13 05:51:48 --> Language Class Initialized
ERROR - 2023-08-13 05:51:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:55:23 --> Config Class Initialized
INFO - 2023-08-13 05:55:23 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:55:23 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:23 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:23 --> URI Class Initialized
INFO - 2023-08-13 05:55:23 --> Router Class Initialized
INFO - 2023-08-13 05:55:23 --> Output Class Initialized
INFO - 2023-08-13 05:55:23 --> Security Class Initialized
DEBUG - 2023-08-13 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:55:24 --> Input Class Initialized
INFO - 2023-08-13 05:55:24 --> Language Class Initialized
INFO - 2023-08-13 05:55:24 --> Loader Class Initialized
INFO - 2023-08-13 05:55:24 --> Helper loaded: url_helper
INFO - 2023-08-13 05:55:24 --> Helper loaded: file_helper
INFO - 2023-08-13 05:55:24 --> Database Driver Class Initialized
INFO - 2023-08-13 05:55:24 --> Email Class Initialized
DEBUG - 2023-08-13 05:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:55:24 --> Controller Class Initialized
INFO - 2023-08-13 05:55:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-13 05:55:24 --> Final output sent to browser
DEBUG - 2023-08-13 05:55:24 --> Total execution time: 0.3550
INFO - 2023-08-13 05:55:25 --> Config Class Initialized
INFO - 2023-08-13 05:55:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:25 --> Config Class Initialized
INFO - 2023-08-13 05:55:25 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:25 --> Config Class Initialized
INFO - 2023-08-13 05:55:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:25 --> URI Class Initialized
INFO - 2023-08-13 05:55:25 --> Hooks Class Initialized
INFO - 2023-08-13 05:55:25 --> Config Class Initialized
INFO - 2023-08-13 05:55:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:25 --> URI Class Initialized
INFO - 2023-08-13 05:55:25 --> Router Class Initialized
DEBUG - 2023-08-13 05:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:25 --> Router Class Initialized
INFO - 2023-08-13 05:55:25 --> Output Class Initialized
INFO - 2023-08-13 05:55:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:55:25 --> Input Class Initialized
INFO - 2023-08-13 05:55:25 --> Language Class Initialized
ERROR - 2023-08-13 05:55:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:55:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:25 --> Hooks Class Initialized
INFO - 2023-08-13 05:55:25 --> URI Class Initialized
INFO - 2023-08-13 05:55:25 --> Output Class Initialized
INFO - 2023-08-13 05:55:25 --> Router Class Initialized
INFO - 2023-08-13 05:55:25 --> Security Class Initialized
DEBUG - 2023-08-13 05:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-13 05:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:25 --> Output Class Initialized
INFO - 2023-08-13 05:55:25 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:25 --> Input Class Initialized
INFO - 2023-08-13 05:55:25 --> Security Class Initialized
INFO - 2023-08-13 05:55:25 --> Language Class Initialized
DEBUG - 2023-08-13 05:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-13 05:55:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-13 05:55:25 --> URI Class Initialized
INFO - 2023-08-13 05:55:25 --> Input Class Initialized
INFO - 2023-08-13 05:55:25 --> Language Class Initialized
INFO - 2023-08-13 05:55:25 --> Router Class Initialized
INFO - 2023-08-13 05:55:25 --> Output Class Initialized
ERROR - 2023-08-13 05:55:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:55:26 --> Security Class Initialized
DEBUG - 2023-08-13 05:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:55:26 --> Input Class Initialized
INFO - 2023-08-13 05:55:26 --> Language Class Initialized
ERROR - 2023-08-13 05:55:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-13 05:55:59 --> Config Class Initialized
INFO - 2023-08-13 05:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:55:59 --> Utf8 Class Initialized
INFO - 2023-08-13 05:55:59 --> URI Class Initialized
INFO - 2023-08-13 05:56:39 --> Config Class Initialized
INFO - 2023-08-13 05:56:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:56:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:56:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:56:39 --> URI Class Initialized
INFO - 2023-08-13 05:56:39 --> Router Class Initialized
INFO - 2023-08-13 05:56:39 --> Output Class Initialized
INFO - 2023-08-13 05:56:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:56:39 --> Input Class Initialized
INFO - 2023-08-13 05:56:39 --> Language Class Initialized
ERROR - 2023-08-13 05:56:39 --> 404 Page Not Found: DW/admin
INFO - 2023-08-13 05:56:51 --> Config Class Initialized
INFO - 2023-08-13 05:56:51 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:56:51 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:56:51 --> Utf8 Class Initialized
INFO - 2023-08-13 05:56:51 --> URI Class Initialized
INFO - 2023-08-13 05:56:51 --> Router Class Initialized
INFO - 2023-08-13 05:56:51 --> Output Class Initialized
INFO - 2023-08-13 05:56:51 --> Security Class Initialized
DEBUG - 2023-08-13 05:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:56:51 --> Input Class Initialized
INFO - 2023-08-13 05:56:51 --> Language Class Initialized
ERROR - 2023-08-13 05:56:51 --> 404 Page Not Found: DW/admin
INFO - 2023-08-13 05:56:54 --> Config Class Initialized
INFO - 2023-08-13 05:56:54 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:56:54 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:56:55 --> Utf8 Class Initialized
INFO - 2023-08-13 05:56:55 --> URI Class Initialized
INFO - 2023-08-13 05:56:55 --> Router Class Initialized
INFO - 2023-08-13 05:56:55 --> Output Class Initialized
INFO - 2023-08-13 05:56:55 --> Security Class Initialized
DEBUG - 2023-08-13 05:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:56:55 --> Input Class Initialized
INFO - 2023-08-13 05:56:55 --> Language Class Initialized
ERROR - 2023-08-13 05:56:55 --> 404 Page Not Found: DW/admin
INFO - 2023-08-13 05:57:27 --> Config Class Initialized
INFO - 2023-08-13 05:57:27 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:27 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:27 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:27 --> URI Class Initialized
INFO - 2023-08-13 05:57:27 --> Router Class Initialized
INFO - 2023-08-13 05:57:27 --> Output Class Initialized
INFO - 2023-08-13 05:57:27 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:27 --> Input Class Initialized
INFO - 2023-08-13 05:57:27 --> Language Class Initialized
ERROR - 2023-08-13 05:57:27 --> 404 Page Not Found: DW/admin
INFO - 2023-08-13 05:57:38 --> Config Class Initialized
INFO - 2023-08-13 05:57:38 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:38 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:38 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:38 --> URI Class Initialized
INFO - 2023-08-13 05:57:38 --> Router Class Initialized
INFO - 2023-08-13 05:57:38 --> Output Class Initialized
INFO - 2023-08-13 05:57:38 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:38 --> Input Class Initialized
INFO - 2023-08-13 05:57:38 --> Language Class Initialized
INFO - 2023-08-13 05:57:38 --> Loader Class Initialized
INFO - 2023-08-13 05:57:38 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:38 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:38 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:38 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:38 --> Controller Class Initialized
INFO - 2023-08-13 05:57:38 --> Model "Blog_model" initialized
INFO - 2023-08-13 05:57:38 --> Helper loaded: form_helper
INFO - 2023-08-13 05:57:38 --> Form Validation Class Initialized
INFO - 2023-08-13 05:57:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-13 05:57:38 --> Final output sent to browser
DEBUG - 2023-08-13 05:57:38 --> Total execution time: 0.3970
INFO - 2023-08-13 05:57:38 --> Config Class Initialized
INFO - 2023-08-13 05:57:38 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:38 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:39 --> URI Class Initialized
INFO - 2023-08-13 05:57:39 --> Router Class Initialized
INFO - 2023-08-13 05:57:39 --> Output Class Initialized
INFO - 2023-08-13 05:57:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:39 --> Input Class Initialized
INFO - 2023-08-13 05:57:39 --> Language Class Initialized
ERROR - 2023-08-13 05:57:39 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-13 05:57:39 --> Config Class Initialized
INFO - 2023-08-13 05:57:39 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:39 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:39 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:39 --> URI Class Initialized
INFO - 2023-08-13 05:57:39 --> Router Class Initialized
INFO - 2023-08-13 05:57:39 --> Output Class Initialized
INFO - 2023-08-13 05:57:39 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:39 --> Input Class Initialized
INFO - 2023-08-13 05:57:39 --> Language Class Initialized
ERROR - 2023-08-13 05:57:39 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-13 05:57:47 --> Config Class Initialized
INFO - 2023-08-13 05:57:47 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:47 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:47 --> URI Class Initialized
INFO - 2023-08-13 05:57:47 --> Router Class Initialized
INFO - 2023-08-13 05:57:47 --> Output Class Initialized
INFO - 2023-08-13 05:57:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:47 --> Input Class Initialized
INFO - 2023-08-13 05:57:47 --> Language Class Initialized
INFO - 2023-08-13 05:57:47 --> Loader Class Initialized
INFO - 2023-08-13 05:57:47 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:47 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:47 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:47 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:47 --> Controller Class Initialized
INFO - 2023-08-13 05:57:47 --> Config Class Initialized
INFO - 2023-08-13 05:57:47 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:47 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:47 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:47 --> URI Class Initialized
INFO - 2023-08-13 05:57:47 --> Router Class Initialized
INFO - 2023-08-13 05:57:47 --> Output Class Initialized
INFO - 2023-08-13 05:57:47 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:47 --> Input Class Initialized
INFO - 2023-08-13 05:57:47 --> Language Class Initialized
INFO - 2023-08-13 05:57:47 --> Loader Class Initialized
INFO - 2023-08-13 05:57:47 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:47 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:47 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:47 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:47 --> Controller Class Initialized
INFO - 2023-08-13 05:57:47 --> Model "User_model" initialized
INFO - 2023-08-13 05:57:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-13 05:57:47 --> Final output sent to browser
DEBUG - 2023-08-13 05:57:47 --> Total execution time: 0.2656
INFO - 2023-08-13 05:57:49 --> Config Class Initialized
INFO - 2023-08-13 05:57:49 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:49 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:49 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:49 --> URI Class Initialized
INFO - 2023-08-13 05:57:49 --> Router Class Initialized
INFO - 2023-08-13 05:57:49 --> Output Class Initialized
INFO - 2023-08-13 05:57:49 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:49 --> Input Class Initialized
INFO - 2023-08-13 05:57:49 --> Language Class Initialized
INFO - 2023-08-13 05:57:49 --> Loader Class Initialized
INFO - 2023-08-13 05:57:49 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:49 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:49 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:49 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:50 --> Controller Class Initialized
INFO - 2023-08-13 05:57:50 --> Model "User_model" initialized
INFO - 2023-08-13 05:57:50 --> Config Class Initialized
INFO - 2023-08-13 05:57:50 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:50 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:50 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:50 --> URI Class Initialized
INFO - 2023-08-13 05:57:50 --> Router Class Initialized
INFO - 2023-08-13 05:57:50 --> Output Class Initialized
INFO - 2023-08-13 05:57:50 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:50 --> Input Class Initialized
INFO - 2023-08-13 05:57:50 --> Language Class Initialized
INFO - 2023-08-13 05:57:50 --> Loader Class Initialized
INFO - 2023-08-13 05:57:50 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:50 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:50 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:50 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:50 --> Controller Class Initialized
INFO - 2023-08-13 05:57:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-13 05:57:50 --> Final output sent to browser
DEBUG - 2023-08-13 05:57:50 --> Total execution time: 0.2418
INFO - 2023-08-13 05:57:54 --> Config Class Initialized
INFO - 2023-08-13 05:57:54 --> Hooks Class Initialized
DEBUG - 2023-08-13 05:57:54 --> UTF-8 Support Enabled
INFO - 2023-08-13 05:57:54 --> Utf8 Class Initialized
INFO - 2023-08-13 05:57:54 --> URI Class Initialized
INFO - 2023-08-13 05:57:54 --> Router Class Initialized
INFO - 2023-08-13 05:57:54 --> Output Class Initialized
INFO - 2023-08-13 05:57:54 --> Security Class Initialized
DEBUG - 2023-08-13 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 05:57:54 --> Input Class Initialized
INFO - 2023-08-13 05:57:54 --> Language Class Initialized
INFO - 2023-08-13 05:57:54 --> Loader Class Initialized
INFO - 2023-08-13 05:57:54 --> Helper loaded: url_helper
INFO - 2023-08-13 05:57:54 --> Helper loaded: file_helper
INFO - 2023-08-13 05:57:54 --> Database Driver Class Initialized
INFO - 2023-08-13 05:57:54 --> Email Class Initialized
DEBUG - 2023-08-13 05:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-13 05:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 05:57:54 --> Controller Class Initialized
INFO - 2023-08-13 05:57:54 --> Model "Banner_model" initialized
INFO - 2023-08-13 05:57:54 --> Helper loaded: form_helper
INFO - 2023-08-13 05:57:54 --> Form Validation Class Initialized
INFO - 2023-08-13 05:57:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-13 05:57:54 --> Final output sent to browser
DEBUG - 2023-08-13 05:57:54 --> Total execution time: 0.3098
