<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-13 19:03:13 --> Config Class Initialized
INFO - 2023-09-13 19:03:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:03:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:03:13 --> Utf8 Class Initialized
INFO - 2023-09-13 19:03:13 --> URI Class Initialized
DEBUG - 2023-09-13 19:03:13 --> No URI present. Default controller set.
INFO - 2023-09-13 19:03:13 --> Router Class Initialized
INFO - 2023-09-13 19:03:13 --> Output Class Initialized
INFO - 2023-09-13 19:03:13 --> Security Class Initialized
DEBUG - 2023-09-13 19:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:03:13 --> Input Class Initialized
INFO - 2023-09-13 19:03:13 --> Language Class Initialized
INFO - 2023-09-13 19:03:13 --> Loader Class Initialized
INFO - 2023-09-13 19:03:13 --> Helper loaded: url_helper
INFO - 2023-09-13 19:03:13 --> Helper loaded: file_helper
INFO - 2023-09-13 19:03:13 --> Database Driver Class Initialized
INFO - 2023-09-13 19:03:13 --> Email Class Initialized
DEBUG - 2023-09-13 19:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:03:13 --> Controller Class Initialized
INFO - 2023-09-13 19:03:13 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:03:13 --> Model "Home_model" initialized
INFO - 2023-09-13 19:03:13 --> Helper loaded: download_helper
INFO - 2023-09-13 19:03:13 --> Helper loaded: form_helper
INFO - 2023-09-13 19:03:13 --> Form Validation Class Initialized
INFO - 2023-09-13 19:03:14 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:03:14 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:03:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:03:14 --> Final output sent to browser
DEBUG - 2023-09-13 19:03:14 --> Total execution time: 0.6208
INFO - 2023-09-13 19:03:59 --> Config Class Initialized
INFO - 2023-09-13 19:03:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:03:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:03:59 --> Utf8 Class Initialized
INFO - 2023-09-13 19:03:59 --> URI Class Initialized
DEBUG - 2023-09-13 19:03:59 --> No URI present. Default controller set.
INFO - 2023-09-13 19:03:59 --> Router Class Initialized
INFO - 2023-09-13 19:03:59 --> Output Class Initialized
INFO - 2023-09-13 19:03:59 --> Security Class Initialized
DEBUG - 2023-09-13 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:03:59 --> Input Class Initialized
INFO - 2023-09-13 19:03:59 --> Language Class Initialized
INFO - 2023-09-13 19:03:59 --> Loader Class Initialized
INFO - 2023-09-13 19:03:59 --> Helper loaded: url_helper
INFO - 2023-09-13 19:03:59 --> Helper loaded: file_helper
INFO - 2023-09-13 19:03:59 --> Database Driver Class Initialized
INFO - 2023-09-13 19:03:59 --> Email Class Initialized
DEBUG - 2023-09-13 19:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:03:59 --> Controller Class Initialized
INFO - 2023-09-13 19:03:59 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:03:59 --> Model "Home_model" initialized
INFO - 2023-09-13 19:03:59 --> Helper loaded: download_helper
INFO - 2023-09-13 19:03:59 --> Helper loaded: form_helper
INFO - 2023-09-13 19:03:59 --> Form Validation Class Initialized
INFO - 2023-09-13 19:03:59 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:03:59 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:03:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:03:59 --> Final output sent to browser
DEBUG - 2023-09-13 19:03:59 --> Total execution time: 0.3039
INFO - 2023-09-13 19:04:04 --> Config Class Initialized
INFO - 2023-09-13 19:04:04 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:04:04 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:04:04 --> Utf8 Class Initialized
INFO - 2023-09-13 19:04:04 --> URI Class Initialized
DEBUG - 2023-09-13 19:04:04 --> No URI present. Default controller set.
INFO - 2023-09-13 19:04:04 --> Router Class Initialized
INFO - 2023-09-13 19:04:04 --> Output Class Initialized
INFO - 2023-09-13 19:04:04 --> Security Class Initialized
DEBUG - 2023-09-13 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:04:04 --> Input Class Initialized
INFO - 2023-09-13 19:04:04 --> Language Class Initialized
INFO - 2023-09-13 19:04:04 --> Loader Class Initialized
INFO - 2023-09-13 19:04:04 --> Helper loaded: url_helper
INFO - 2023-09-13 19:04:04 --> Helper loaded: file_helper
INFO - 2023-09-13 19:04:04 --> Database Driver Class Initialized
INFO - 2023-09-13 19:04:04 --> Email Class Initialized
DEBUG - 2023-09-13 19:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:04:04 --> Controller Class Initialized
INFO - 2023-09-13 19:04:04 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:04:04 --> Model "Home_model" initialized
INFO - 2023-09-13 19:04:04 --> Helper loaded: download_helper
INFO - 2023-09-13 19:04:04 --> Helper loaded: form_helper
INFO - 2023-09-13 19:04:04 --> Form Validation Class Initialized
INFO - 2023-09-13 19:04:04 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:04:04 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:04:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:04:04 --> Final output sent to browser
DEBUG - 2023-09-13 19:04:04 --> Total execution time: 0.0569
INFO - 2023-09-13 19:04:36 --> Config Class Initialized
INFO - 2023-09-13 19:04:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:04:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:04:36 --> Utf8 Class Initialized
INFO - 2023-09-13 19:04:36 --> URI Class Initialized
DEBUG - 2023-09-13 19:04:36 --> No URI present. Default controller set.
INFO - 2023-09-13 19:04:36 --> Router Class Initialized
INFO - 2023-09-13 19:04:36 --> Output Class Initialized
INFO - 2023-09-13 19:04:36 --> Security Class Initialized
DEBUG - 2023-09-13 19:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:04:36 --> Input Class Initialized
INFO - 2023-09-13 19:04:36 --> Language Class Initialized
INFO - 2023-09-13 19:04:36 --> Loader Class Initialized
INFO - 2023-09-13 19:04:36 --> Helper loaded: url_helper
INFO - 2023-09-13 19:04:36 --> Helper loaded: file_helper
INFO - 2023-09-13 19:04:36 --> Database Driver Class Initialized
INFO - 2023-09-13 19:04:36 --> Email Class Initialized
DEBUG - 2023-09-13 19:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:04:36 --> Controller Class Initialized
INFO - 2023-09-13 19:04:36 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:04:36 --> Model "Home_model" initialized
INFO - 2023-09-13 19:04:36 --> Helper loaded: download_helper
INFO - 2023-09-13 19:04:36 --> Helper loaded: form_helper
INFO - 2023-09-13 19:04:36 --> Form Validation Class Initialized
INFO - 2023-09-13 19:04:36 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:04:36 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:04:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:04:36 --> Final output sent to browser
DEBUG - 2023-09-13 19:04:36 --> Total execution time: 0.5136
INFO - 2023-09-13 19:05:27 --> Config Class Initialized
INFO - 2023-09-13 19:05:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:05:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:05:27 --> Utf8 Class Initialized
INFO - 2023-09-13 19:05:27 --> URI Class Initialized
DEBUG - 2023-09-13 19:05:27 --> No URI present. Default controller set.
INFO - 2023-09-13 19:05:27 --> Router Class Initialized
INFO - 2023-09-13 19:05:27 --> Output Class Initialized
INFO - 2023-09-13 19:05:27 --> Security Class Initialized
DEBUG - 2023-09-13 19:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:05:27 --> Input Class Initialized
INFO - 2023-09-13 19:05:27 --> Language Class Initialized
INFO - 2023-09-13 19:05:27 --> Loader Class Initialized
INFO - 2023-09-13 19:05:27 --> Helper loaded: url_helper
INFO - 2023-09-13 19:05:27 --> Helper loaded: file_helper
INFO - 2023-09-13 19:05:27 --> Database Driver Class Initialized
INFO - 2023-09-13 19:05:27 --> Email Class Initialized
DEBUG - 2023-09-13 19:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:05:27 --> Controller Class Initialized
INFO - 2023-09-13 19:05:27 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:05:27 --> Model "Home_model" initialized
INFO - 2023-09-13 19:05:27 --> Helper loaded: download_helper
INFO - 2023-09-13 19:05:27 --> Helper loaded: form_helper
INFO - 2023-09-13 19:05:27 --> Form Validation Class Initialized
INFO - 2023-09-13 19:05:27 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:05:27 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:05:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:05:28 --> Final output sent to browser
DEBUG - 2023-09-13 19:05:28 --> Total execution time: 1.2597
INFO - 2023-09-13 19:06:03 --> Config Class Initialized
INFO - 2023-09-13 19:06:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:03 --> URI Class Initialized
DEBUG - 2023-09-13 19:06:03 --> No URI present. Default controller set.
INFO - 2023-09-13 19:06:03 --> Router Class Initialized
INFO - 2023-09-13 19:06:03 --> Output Class Initialized
INFO - 2023-09-13 19:06:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:03 --> Input Class Initialized
INFO - 2023-09-13 19:06:03 --> Language Class Initialized
INFO - 2023-09-13 19:06:03 --> Loader Class Initialized
INFO - 2023-09-13 19:06:03 --> Helper loaded: url_helper
INFO - 2023-09-13 19:06:03 --> Helper loaded: file_helper
INFO - 2023-09-13 19:06:03 --> Database Driver Class Initialized
INFO - 2023-09-13 19:06:03 --> Email Class Initialized
DEBUG - 2023-09-13 19:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:06:03 --> Controller Class Initialized
INFO - 2023-09-13 19:06:03 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:06:03 --> Model "Home_model" initialized
INFO - 2023-09-13 19:06:03 --> Helper loaded: download_helper
INFO - 2023-09-13 19:06:03 --> Helper loaded: form_helper
INFO - 2023-09-13 19:06:03 --> Form Validation Class Initialized
INFO - 2023-09-13 19:06:03 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:06:03 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:06:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:06:03 --> Final output sent to browser
DEBUG - 2023-09-13 19:06:04 --> Total execution time: 0.1417
INFO - 2023-09-13 19:06:21 --> Config Class Initialized
INFO - 2023-09-13 19:06:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:21 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:21 --> URI Class Initialized
INFO - 2023-09-13 19:06:21 --> Router Class Initialized
INFO - 2023-09-13 19:06:21 --> Output Class Initialized
INFO - 2023-09-13 19:06:21 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:21 --> Input Class Initialized
INFO - 2023-09-13 19:06:21 --> Language Class Initialized
ERROR - 2023-09-13 19:06:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:06:21 --> Config Class Initialized
INFO - 2023-09-13 19:06:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:21 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:21 --> URI Class Initialized
INFO - 2023-09-13 19:06:21 --> Router Class Initialized
INFO - 2023-09-13 19:06:21 --> Output Class Initialized
INFO - 2023-09-13 19:06:21 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:21 --> Input Class Initialized
INFO - 2023-09-13 19:06:21 --> Language Class Initialized
ERROR - 2023-09-13 19:06:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:06:21 --> Config Class Initialized
INFO - 2023-09-13 19:06:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:21 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:21 --> URI Class Initialized
INFO - 2023-09-13 19:06:21 --> Router Class Initialized
INFO - 2023-09-13 19:06:21 --> Output Class Initialized
INFO - 2023-09-13 19:06:21 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:21 --> Input Class Initialized
INFO - 2023-09-13 19:06:21 --> Language Class Initialized
ERROR - 2023-09-13 19:06:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:06:22 --> Config Class Initialized
INFO - 2023-09-13 19:06:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:22 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:22 --> URI Class Initialized
INFO - 2023-09-13 19:06:22 --> Router Class Initialized
INFO - 2023-09-13 19:06:22 --> Output Class Initialized
INFO - 2023-09-13 19:06:22 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:22 --> Input Class Initialized
INFO - 2023-09-13 19:06:22 --> Language Class Initialized
ERROR - 2023-09-13 19:06:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:06:22 --> Config Class Initialized
INFO - 2023-09-13 19:06:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:22 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:22 --> URI Class Initialized
INFO - 2023-09-13 19:06:22 --> Router Class Initialized
INFO - 2023-09-13 19:06:22 --> Output Class Initialized
INFO - 2023-09-13 19:06:22 --> Security Class Initialized
INFO - 2023-09-13 19:06:22 --> Config Class Initialized
INFO - 2023-09-13 19:06:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:22 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:22 --> URI Class Initialized
INFO - 2023-09-13 19:06:22 --> Router Class Initialized
INFO - 2023-09-13 19:06:22 --> Output Class Initialized
INFO - 2023-09-13 19:06:22 --> Config Class Initialized
INFO - 2023-09-13 19:06:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:22 --> Input Class Initialized
INFO - 2023-09-13 19:06:22 --> Language Class Initialized
ERROR - 2023-09-13 19:06:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:06:22 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:22 --> Input Class Initialized
INFO - 2023-09-13 19:06:22 --> Language Class Initialized
ERROR - 2023-09-13 19:06:22 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-13 19:06:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:06:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:06:23 --> URI Class Initialized
INFO - 2023-09-13 19:06:23 --> Router Class Initialized
INFO - 2023-09-13 19:06:23 --> Output Class Initialized
INFO - 2023-09-13 19:06:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:06:23 --> Input Class Initialized
INFO - 2023-09-13 19:06:23 --> Language Class Initialized
ERROR - 2023-09-13 19:06:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:08:41 --> Config Class Initialized
INFO - 2023-09-13 19:08:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:08:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:08:41 --> Utf8 Class Initialized
INFO - 2023-09-13 19:08:41 --> URI Class Initialized
DEBUG - 2023-09-13 19:08:41 --> No URI present. Default controller set.
INFO - 2023-09-13 19:08:41 --> Router Class Initialized
INFO - 2023-09-13 19:08:41 --> Output Class Initialized
INFO - 2023-09-13 19:08:41 --> Security Class Initialized
DEBUG - 2023-09-13 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:08:41 --> Input Class Initialized
INFO - 2023-09-13 19:08:42 --> Language Class Initialized
INFO - 2023-09-13 19:08:42 --> Loader Class Initialized
INFO - 2023-09-13 19:08:42 --> Helper loaded: url_helper
INFO - 2023-09-13 19:08:42 --> Helper loaded: file_helper
INFO - 2023-09-13 19:08:42 --> Database Driver Class Initialized
INFO - 2023-09-13 19:08:42 --> Email Class Initialized
DEBUG - 2023-09-13 19:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:08:42 --> Controller Class Initialized
INFO - 2023-09-13 19:08:42 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:08:42 --> Model "Home_model" initialized
INFO - 2023-09-13 19:08:42 --> Helper loaded: download_helper
INFO - 2023-09-13 19:08:42 --> Helper loaded: form_helper
INFO - 2023-09-13 19:08:42 --> Form Validation Class Initialized
INFO - 2023-09-13 19:08:42 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:08:42 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:08:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:08:42 --> Final output sent to browser
DEBUG - 2023-09-13 19:08:42 --> Total execution time: 3.2952
INFO - 2023-09-13 19:08:47 --> Config Class Initialized
INFO - 2023-09-13 19:08:47 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:08:47 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:08:47 --> Utf8 Class Initialized
INFO - 2023-09-13 19:08:47 --> URI Class Initialized
INFO - 2023-09-13 19:08:47 --> Router Class Initialized
INFO - 2023-09-13 19:08:47 --> Output Class Initialized
INFO - 2023-09-13 19:08:47 --> Security Class Initialized
DEBUG - 2023-09-13 19:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:08:47 --> Input Class Initialized
INFO - 2023-09-13 19:08:47 --> Language Class Initialized
ERROR - 2023-09-13 19:08:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:08:48 --> Config Class Initialized
INFO - 2023-09-13 19:08:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:08:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:08:48 --> Utf8 Class Initialized
INFO - 2023-09-13 19:08:48 --> URI Class Initialized
INFO - 2023-09-13 19:08:48 --> Router Class Initialized
INFO - 2023-09-13 19:08:48 --> Output Class Initialized
INFO - 2023-09-13 19:08:48 --> Security Class Initialized
DEBUG - 2023-09-13 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:08:48 --> Input Class Initialized
INFO - 2023-09-13 19:08:48 --> Language Class Initialized
ERROR - 2023-09-13 19:08:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:08:50 --> Config Class Initialized
INFO - 2023-09-13 19:08:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:08:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:08:50 --> Utf8 Class Initialized
INFO - 2023-09-13 19:08:50 --> URI Class Initialized
INFO - 2023-09-13 19:08:50 --> Router Class Initialized
INFO - 2023-09-13 19:08:50 --> Output Class Initialized
INFO - 2023-09-13 19:08:50 --> Security Class Initialized
DEBUG - 2023-09-13 19:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:08:50 --> Input Class Initialized
INFO - 2023-09-13 19:08:50 --> Language Class Initialized
ERROR - 2023-09-13 19:08:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:09:12 --> Config Class Initialized
INFO - 2023-09-13 19:09:12 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:09:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:09:13 --> Utf8 Class Initialized
INFO - 2023-09-13 19:09:13 --> URI Class Initialized
INFO - 2023-09-13 19:09:13 --> Router Class Initialized
INFO - 2023-09-13 19:09:13 --> Output Class Initialized
INFO - 2023-09-13 19:09:13 --> Security Class Initialized
DEBUG - 2023-09-13 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:09:13 --> Input Class Initialized
INFO - 2023-09-13 19:09:13 --> Language Class Initialized
ERROR - 2023-09-13 19:09:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:09:50 --> Config Class Initialized
INFO - 2023-09-13 19:09:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:09:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:09:50 --> Utf8 Class Initialized
INFO - 2023-09-13 19:09:50 --> URI Class Initialized
INFO - 2023-09-13 19:09:50 --> Router Class Initialized
INFO - 2023-09-13 19:09:50 --> Output Class Initialized
INFO - 2023-09-13 19:09:50 --> Security Class Initialized
DEBUG - 2023-09-13 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:09:50 --> Input Class Initialized
INFO - 2023-09-13 19:09:50 --> Language Class Initialized
ERROR - 2023-09-13 19:09:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:09:52 --> Config Class Initialized
INFO - 2023-09-13 19:09:52 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:09:52 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:09:52 --> Utf8 Class Initialized
INFO - 2023-09-13 19:09:52 --> URI Class Initialized
INFO - 2023-09-13 19:09:52 --> Router Class Initialized
INFO - 2023-09-13 19:09:52 --> Output Class Initialized
INFO - 2023-09-13 19:09:52 --> Security Class Initialized
DEBUG - 2023-09-13 19:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:09:52 --> Input Class Initialized
INFO - 2023-09-13 19:09:52 --> Language Class Initialized
ERROR - 2023-09-13 19:09:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:09:53 --> Config Class Initialized
INFO - 2023-09-13 19:09:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:09:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:09:53 --> Utf8 Class Initialized
INFO - 2023-09-13 19:09:53 --> URI Class Initialized
INFO - 2023-09-13 19:09:53 --> Router Class Initialized
INFO - 2023-09-13 19:09:53 --> Output Class Initialized
INFO - 2023-09-13 19:09:53 --> Security Class Initialized
DEBUG - 2023-09-13 19:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:09:53 --> Input Class Initialized
INFO - 2023-09-13 19:09:53 --> Language Class Initialized
ERROR - 2023-09-13 19:09:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:09:56 --> Config Class Initialized
INFO - 2023-09-13 19:09:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:09:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:09:56 --> Utf8 Class Initialized
INFO - 2023-09-13 19:09:56 --> URI Class Initialized
DEBUG - 2023-09-13 19:09:56 --> No URI present. Default controller set.
INFO - 2023-09-13 19:09:56 --> Router Class Initialized
INFO - 2023-09-13 19:09:56 --> Output Class Initialized
INFO - 2023-09-13 19:09:56 --> Security Class Initialized
DEBUG - 2023-09-13 19:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:09:56 --> Input Class Initialized
INFO - 2023-09-13 19:09:56 --> Language Class Initialized
INFO - 2023-09-13 19:09:56 --> Loader Class Initialized
INFO - 2023-09-13 19:09:56 --> Helper loaded: url_helper
INFO - 2023-09-13 19:09:56 --> Helper loaded: file_helper
INFO - 2023-09-13 19:09:56 --> Database Driver Class Initialized
INFO - 2023-09-13 19:09:56 --> Email Class Initialized
DEBUG - 2023-09-13 19:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:09:56 --> Controller Class Initialized
INFO - 2023-09-13 19:09:56 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:09:56 --> Model "Home_model" initialized
INFO - 2023-09-13 19:09:56 --> Helper loaded: download_helper
INFO - 2023-09-13 19:09:56 --> Helper loaded: form_helper
INFO - 2023-09-13 19:09:56 --> Form Validation Class Initialized
INFO - 2023-09-13 19:09:56 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:09:56 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:09:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:09:57 --> Final output sent to browser
DEBUG - 2023-09-13 19:09:57 --> Total execution time: 0.2342
INFO - 2023-09-13 19:10:23 --> Config Class Initialized
INFO - 2023-09-13 19:10:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:10:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:10:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:10:23 --> URI Class Initialized
DEBUG - 2023-09-13 19:10:23 --> No URI present. Default controller set.
INFO - 2023-09-13 19:10:23 --> Router Class Initialized
INFO - 2023-09-13 19:10:23 --> Output Class Initialized
INFO - 2023-09-13 19:10:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:10:23 --> Input Class Initialized
INFO - 2023-09-13 19:10:23 --> Language Class Initialized
INFO - 2023-09-13 19:10:23 --> Loader Class Initialized
INFO - 2023-09-13 19:10:23 --> Helper loaded: url_helper
INFO - 2023-09-13 19:10:23 --> Helper loaded: file_helper
INFO - 2023-09-13 19:10:23 --> Database Driver Class Initialized
INFO - 2023-09-13 19:10:23 --> Email Class Initialized
DEBUG - 2023-09-13 19:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:10:23 --> Controller Class Initialized
INFO - 2023-09-13 19:10:23 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:10:23 --> Model "Home_model" initialized
INFO - 2023-09-13 19:10:23 --> Helper loaded: download_helper
INFO - 2023-09-13 19:10:23 --> Helper loaded: form_helper
INFO - 2023-09-13 19:10:23 --> Form Validation Class Initialized
INFO - 2023-09-13 19:10:23 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:10:23 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:10:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:10:23 --> Final output sent to browser
DEBUG - 2023-09-13 19:10:23 --> Total execution time: 0.2458
INFO - 2023-09-13 19:10:46 --> Config Class Initialized
INFO - 2023-09-13 19:10:46 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:10:46 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:10:46 --> Utf8 Class Initialized
INFO - 2023-09-13 19:10:46 --> URI Class Initialized
DEBUG - 2023-09-13 19:10:46 --> No URI present. Default controller set.
INFO - 2023-09-13 19:10:46 --> Router Class Initialized
INFO - 2023-09-13 19:10:46 --> Output Class Initialized
INFO - 2023-09-13 19:10:46 --> Security Class Initialized
DEBUG - 2023-09-13 19:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:10:46 --> Input Class Initialized
INFO - 2023-09-13 19:10:46 --> Language Class Initialized
INFO - 2023-09-13 19:10:46 --> Loader Class Initialized
INFO - 2023-09-13 19:10:46 --> Helper loaded: url_helper
INFO - 2023-09-13 19:10:46 --> Helper loaded: file_helper
INFO - 2023-09-13 19:10:46 --> Database Driver Class Initialized
INFO - 2023-09-13 19:10:46 --> Email Class Initialized
DEBUG - 2023-09-13 19:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:10:46 --> Controller Class Initialized
INFO - 2023-09-13 19:10:46 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:10:46 --> Model "Home_model" initialized
INFO - 2023-09-13 19:10:46 --> Helper loaded: download_helper
INFO - 2023-09-13 19:10:46 --> Helper loaded: form_helper
INFO - 2023-09-13 19:10:46 --> Form Validation Class Initialized
INFO - 2023-09-13 19:10:46 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:10:46 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:10:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:10:46 --> Final output sent to browser
DEBUG - 2023-09-13 19:10:46 --> Total execution time: 0.4716
INFO - 2023-09-13 19:11:22 --> Config Class Initialized
INFO - 2023-09-13 19:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:11:22 --> Utf8 Class Initialized
INFO - 2023-09-13 19:11:22 --> URI Class Initialized
DEBUG - 2023-09-13 19:11:22 --> No URI present. Default controller set.
INFO - 2023-09-13 19:11:22 --> Router Class Initialized
INFO - 2023-09-13 19:11:22 --> Output Class Initialized
INFO - 2023-09-13 19:11:22 --> Security Class Initialized
DEBUG - 2023-09-13 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:11:22 --> Input Class Initialized
INFO - 2023-09-13 19:11:22 --> Language Class Initialized
INFO - 2023-09-13 19:11:22 --> Loader Class Initialized
INFO - 2023-09-13 19:11:22 --> Helper loaded: url_helper
INFO - 2023-09-13 19:11:22 --> Helper loaded: file_helper
INFO - 2023-09-13 19:11:22 --> Database Driver Class Initialized
INFO - 2023-09-13 19:11:22 --> Email Class Initialized
DEBUG - 2023-09-13 19:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:11:22 --> Controller Class Initialized
INFO - 2023-09-13 19:11:22 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:11:22 --> Model "Home_model" initialized
INFO - 2023-09-13 19:11:22 --> Helper loaded: download_helper
INFO - 2023-09-13 19:11:22 --> Helper loaded: form_helper
INFO - 2023-09-13 19:11:22 --> Form Validation Class Initialized
INFO - 2023-09-13 19:11:22 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:11:22 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:11:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 19:11:22 --> Final output sent to browser
DEBUG - 2023-09-13 19:11:22 --> Total execution time: 0.2472
INFO - 2023-09-13 19:21:20 --> Config Class Initialized
INFO - 2023-09-13 19:21:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:21:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:21:20 --> Utf8 Class Initialized
INFO - 2023-09-13 19:21:20 --> URI Class Initialized
INFO - 2023-09-13 19:21:20 --> Router Class Initialized
INFO - 2023-09-13 19:21:20 --> Output Class Initialized
INFO - 2023-09-13 19:21:20 --> Security Class Initialized
DEBUG - 2023-09-13 19:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:21:20 --> Input Class Initialized
INFO - 2023-09-13 19:21:20 --> Language Class Initialized
INFO - 2023-09-13 19:21:20 --> Loader Class Initialized
INFO - 2023-09-13 19:21:20 --> Helper loaded: url_helper
INFO - 2023-09-13 19:21:20 --> Helper loaded: file_helper
INFO - 2023-09-13 19:21:20 --> Database Driver Class Initialized
INFO - 2023-09-13 19:21:20 --> Email Class Initialized
DEBUG - 2023-09-13 19:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:21:20 --> Controller Class Initialized
INFO - 2023-09-13 19:21:20 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:21:20 --> Model "Home_model" initialized
INFO - 2023-09-13 19:21:20 --> Helper loaded: download_helper
INFO - 2023-09-13 19:21:20 --> Helper loaded: form_helper
INFO - 2023-09-13 19:21:20 --> Form Validation Class Initialized
INFO - 2023-09-13 19:21:20 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:21:20 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:21:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:21:20 --> Final output sent to browser
DEBUG - 2023-09-13 19:21:20 --> Total execution time: 0.4970
INFO - 2023-09-13 19:22:07 --> Config Class Initialized
INFO - 2023-09-13 19:22:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:07 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:07 --> URI Class Initialized
INFO - 2023-09-13 19:22:07 --> Router Class Initialized
INFO - 2023-09-13 19:22:07 --> Output Class Initialized
INFO - 2023-09-13 19:22:07 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:07 --> Input Class Initialized
INFO - 2023-09-13 19:22:07 --> Language Class Initialized
INFO - 2023-09-13 19:22:07 --> Loader Class Initialized
INFO - 2023-09-13 19:22:07 --> Helper loaded: url_helper
INFO - 2023-09-13 19:22:07 --> Helper loaded: file_helper
INFO - 2023-09-13 19:22:07 --> Database Driver Class Initialized
INFO - 2023-09-13 19:22:07 --> Email Class Initialized
DEBUG - 2023-09-13 19:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:22:07 --> Controller Class Initialized
INFO - 2023-09-13 19:22:07 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:22:07 --> Model "Home_model" initialized
INFO - 2023-09-13 19:22:07 --> Helper loaded: download_helper
INFO - 2023-09-13 19:22:07 --> Helper loaded: form_helper
INFO - 2023-09-13 19:22:07 --> Form Validation Class Initialized
INFO - 2023-09-13 19:22:07 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:22:07 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:22:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-13 19:22:08 --> Final output sent to browser
DEBUG - 2023-09-13 19:22:08 --> Total execution time: 0.5633
INFO - 2023-09-13 19:22:19 --> Config Class Initialized
INFO - 2023-09-13 19:22:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:19 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:19 --> URI Class Initialized
INFO - 2023-09-13 19:22:19 --> Router Class Initialized
INFO - 2023-09-13 19:22:19 --> Output Class Initialized
INFO - 2023-09-13 19:22:19 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:19 --> Input Class Initialized
INFO - 2023-09-13 19:22:19 --> Language Class Initialized
INFO - 2023-09-13 19:22:19 --> Loader Class Initialized
INFO - 2023-09-13 19:22:19 --> Helper loaded: url_helper
INFO - 2023-09-13 19:22:19 --> Helper loaded: file_helper
INFO - 2023-09-13 19:22:19 --> Database Driver Class Initialized
INFO - 2023-09-13 19:22:19 --> Email Class Initialized
DEBUG - 2023-09-13 19:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:22:19 --> Controller Class Initialized
INFO - 2023-09-13 19:22:19 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:22:19 --> Model "Home_model" initialized
INFO - 2023-09-13 19:22:19 --> Helper loaded: download_helper
INFO - 2023-09-13 19:22:19 --> Helper loaded: form_helper
INFO - 2023-09-13 19:22:19 --> Form Validation Class Initialized
INFO - 2023-09-13 19:22:19 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:22:19 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:22:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-13 19:22:19 --> Final output sent to browser
DEBUG - 2023-09-13 19:22:19 --> Total execution time: 0.5012
INFO - 2023-09-13 19:22:23 --> Config Class Initialized
INFO - 2023-09-13 19:22:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:23 --> URI Class Initialized
INFO - 2023-09-13 19:22:23 --> Router Class Initialized
INFO - 2023-09-13 19:22:23 --> Output Class Initialized
INFO - 2023-09-13 19:22:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:23 --> Input Class Initialized
INFO - 2023-09-13 19:22:23 --> Language Class Initialized
INFO - 2023-09-13 19:22:23 --> Loader Class Initialized
INFO - 2023-09-13 19:22:23 --> Helper loaded: url_helper
INFO - 2023-09-13 19:22:23 --> Helper loaded: file_helper
INFO - 2023-09-13 19:22:23 --> Database Driver Class Initialized
INFO - 2023-09-13 19:22:23 --> Email Class Initialized
DEBUG - 2023-09-13 19:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:22:23 --> Controller Class Initialized
INFO - 2023-09-13 19:22:23 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:22:23 --> Model "Home_model" initialized
INFO - 2023-09-13 19:22:23 --> Helper loaded: download_helper
INFO - 2023-09-13 19:22:23 --> Helper loaded: form_helper
INFO - 2023-09-13 19:22:23 --> Form Validation Class Initialized
INFO - 2023-09-13 19:22:23 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:22:23 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:22:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 19:22:23 --> Final output sent to browser
DEBUG - 2023-09-13 19:22:23 --> Total execution time: 0.1210
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:22:33 --> Config Class Initialized
INFO - 2023-09-13 19:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:22:33 --> Utf8 Class Initialized
INFO - 2023-09-13 19:22:33 --> URI Class Initialized
INFO - 2023-09-13 19:22:33 --> Router Class Initialized
INFO - 2023-09-13 19:22:33 --> Output Class Initialized
INFO - 2023-09-13 19:22:33 --> Security Class Initialized
DEBUG - 2023-09-13 19:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:22:33 --> Input Class Initialized
INFO - 2023-09-13 19:22:33 --> Language Class Initialized
ERROR - 2023-09-13 19:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:53 --> Config Class Initialized
INFO - 2023-09-13 19:23:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:53 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:53 --> URI Class Initialized
INFO - 2023-09-13 19:23:53 --> Router Class Initialized
INFO - 2023-09-13 19:23:53 --> Output Class Initialized
INFO - 2023-09-13 19:23:53 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:53 --> Input Class Initialized
INFO - 2023-09-13 19:23:53 --> Language Class Initialized
INFO - 2023-09-13 19:23:53 --> Loader Class Initialized
INFO - 2023-09-13 19:23:53 --> Helper loaded: url_helper
INFO - 2023-09-13 19:23:53 --> Helper loaded: file_helper
INFO - 2023-09-13 19:23:53 --> Database Driver Class Initialized
INFO - 2023-09-13 19:23:53 --> Email Class Initialized
DEBUG - 2023-09-13 19:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:23:53 --> Controller Class Initialized
INFO - 2023-09-13 19:23:53 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:23:53 --> Model "Home_model" initialized
INFO - 2023-09-13 19:23:53 --> Helper loaded: download_helper
INFO - 2023-09-13 19:23:53 --> Helper loaded: form_helper
INFO - 2023-09-13 19:23:53 --> Form Validation Class Initialized
INFO - 2023-09-13 19:23:53 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:23:53 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:23:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-13 19:23:53 --> Final output sent to browser
DEBUG - 2023-09-13 19:23:53 --> Total execution time: 0.0673
INFO - 2023-09-13 19:23:54 --> Config Class Initialized
INFO - 2023-09-13 19:23:54 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:54 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:54 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:54 --> URI Class Initialized
INFO - 2023-09-13 19:23:54 --> Router Class Initialized
INFO - 2023-09-13 19:23:54 --> Output Class Initialized
INFO - 2023-09-13 19:23:54 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:54 --> Input Class Initialized
INFO - 2023-09-13 19:23:54 --> Language Class Initialized
INFO - 2023-09-13 19:23:54 --> Loader Class Initialized
INFO - 2023-09-13 19:23:54 --> Helper loaded: url_helper
INFO - 2023-09-13 19:23:54 --> Helper loaded: file_helper
INFO - 2023-09-13 19:23:54 --> Database Driver Class Initialized
INFO - 2023-09-13 19:23:54 --> Email Class Initialized
DEBUG - 2023-09-13 19:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:23:54 --> Controller Class Initialized
INFO - 2023-09-13 19:23:54 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:23:54 --> Model "Home_model" initialized
INFO - 2023-09-13 19:23:54 --> Helper loaded: download_helper
INFO - 2023-09-13 19:23:54 --> Helper loaded: form_helper
INFO - 2023-09-13 19:23:54 --> Form Validation Class Initialized
INFO - 2023-09-13 19:23:54 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:23:54 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:23:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-13 19:23:54 --> Final output sent to browser
DEBUG - 2023-09-13 19:23:54 --> Total execution time: 0.0583
INFO - 2023-09-13 19:23:54 --> Config Class Initialized
INFO - 2023-09-13 19:23:54 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:54 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:54 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:54 --> URI Class Initialized
INFO - 2023-09-13 19:23:54 --> Router Class Initialized
INFO - 2023-09-13 19:23:54 --> Output Class Initialized
INFO - 2023-09-13 19:23:54 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:54 --> Input Class Initialized
INFO - 2023-09-13 19:23:54 --> Language Class Initialized
ERROR - 2023-09-13 19:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:54 --> Config Class Initialized
INFO - 2023-09-13 19:23:54 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:54 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:54 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:54 --> URI Class Initialized
INFO - 2023-09-13 19:23:54 --> Router Class Initialized
INFO - 2023-09-13 19:23:54 --> Output Class Initialized
INFO - 2023-09-13 19:23:54 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:54 --> Input Class Initialized
INFO - 2023-09-13 19:23:54 --> Language Class Initialized
ERROR - 2023-09-13 19:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:54 --> Config Class Initialized
INFO - 2023-09-13 19:23:54 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:54 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:54 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:54 --> URI Class Initialized
INFO - 2023-09-13 19:23:54 --> Router Class Initialized
INFO - 2023-09-13 19:23:54 --> Output Class Initialized
INFO - 2023-09-13 19:23:54 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:54 --> Input Class Initialized
INFO - 2023-09-13 19:23:54 --> Language Class Initialized
ERROR - 2023-09-13 19:23:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:55 --> Config Class Initialized
INFO - 2023-09-13 19:23:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:55 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:55 --> URI Class Initialized
INFO - 2023-09-13 19:23:55 --> Router Class Initialized
INFO - 2023-09-13 19:23:55 --> Output Class Initialized
INFO - 2023-09-13 19:23:55 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:55 --> Input Class Initialized
INFO - 2023-09-13 19:23:55 --> Language Class Initialized
ERROR - 2023-09-13 19:23:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:55 --> Config Class Initialized
INFO - 2023-09-13 19:23:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:55 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:55 --> URI Class Initialized
INFO - 2023-09-13 19:23:55 --> Router Class Initialized
INFO - 2023-09-13 19:23:55 --> Output Class Initialized
INFO - 2023-09-13 19:23:55 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:55 --> Input Class Initialized
INFO - 2023-09-13 19:23:55 --> Language Class Initialized
INFO - 2023-09-13 19:23:55 --> Loader Class Initialized
INFO - 2023-09-13 19:23:55 --> Helper loaded: url_helper
INFO - 2023-09-13 19:23:55 --> Helper loaded: file_helper
INFO - 2023-09-13 19:23:55 --> Database Driver Class Initialized
INFO - 2023-09-13 19:23:55 --> Email Class Initialized
DEBUG - 2023-09-13 19:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:23:55 --> Controller Class Initialized
INFO - 2023-09-13 19:23:55 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:23:55 --> Model "Home_model" initialized
INFO - 2023-09-13 19:23:55 --> Helper loaded: download_helper
INFO - 2023-09-13 19:23:55 --> Helper loaded: form_helper
INFO - 2023-09-13 19:23:55 --> Form Validation Class Initialized
INFO - 2023-09-13 19:23:55 --> Config Class Initialized
INFO - 2023-09-13 19:23:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:55 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:55 --> URI Class Initialized
INFO - 2023-09-13 19:23:55 --> Router Class Initialized
INFO - 2023-09-13 19:23:55 --> Output Class Initialized
INFO - 2023-09-13 19:23:55 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:55 --> Input Class Initialized
INFO - 2023-09-13 19:23:55 --> Language Class Initialized
ERROR - 2023-09-13 19:23:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:56 --> Config Class Initialized
INFO - 2023-09-13 19:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:56 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:56 --> URI Class Initialized
INFO - 2023-09-13 19:23:56 --> Router Class Initialized
INFO - 2023-09-13 19:23:56 --> Output Class Initialized
INFO - 2023-09-13 19:23:56 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:56 --> Input Class Initialized
INFO - 2023-09-13 19:23:56 --> Language Class Initialized
ERROR - 2023-09-13 19:23:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:56 --> Config Class Initialized
INFO - 2023-09-13 19:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:56 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:56 --> URI Class Initialized
INFO - 2023-09-13 19:23:56 --> Router Class Initialized
INFO - 2023-09-13 19:23:56 --> Output Class Initialized
INFO - 2023-09-13 19:23:56 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:56 --> Input Class Initialized
INFO - 2023-09-13 19:23:56 --> Language Class Initialized
ERROR - 2023-09-13 19:23:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:56 --> Config Class Initialized
INFO - 2023-09-13 19:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:56 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:56 --> URI Class Initialized
INFO - 2023-09-13 19:23:56 --> Router Class Initialized
INFO - 2023-09-13 19:23:56 --> Output Class Initialized
INFO - 2023-09-13 19:23:56 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:56 --> Input Class Initialized
INFO - 2023-09-13 19:23:56 --> Language Class Initialized
ERROR - 2023-09-13 19:23:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:56 --> Config Class Initialized
INFO - 2023-09-13 19:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:56 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:56 --> URI Class Initialized
INFO - 2023-09-13 19:23:56 --> Router Class Initialized
INFO - 2023-09-13 19:23:56 --> Output Class Initialized
INFO - 2023-09-13 19:23:56 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:56 --> Input Class Initialized
INFO - 2023-09-13 19:23:56 --> Language Class Initialized
ERROR - 2023-09-13 19:23:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:56 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:23:56 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:23:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:23:56 --> Final output sent to browser
DEBUG - 2023-09-13 19:23:56 --> Total execution time: 1.1319
INFO - 2023-09-13 19:23:56 --> Config Class Initialized
INFO - 2023-09-13 19:23:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:57 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:57 --> URI Class Initialized
INFO - 2023-09-13 19:23:57 --> Router Class Initialized
INFO - 2023-09-13 19:23:57 --> Config Class Initialized
INFO - 2023-09-13 19:23:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:57 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:57 --> URI Class Initialized
INFO - 2023-09-13 19:23:57 --> Router Class Initialized
INFO - 2023-09-13 19:23:57 --> Output Class Initialized
INFO - 2023-09-13 19:23:57 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:57 --> Input Class Initialized
INFO - 2023-09-13 19:23:57 --> Language Class Initialized
ERROR - 2023-09-13 19:23:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:57 --> Config Class Initialized
INFO - 2023-09-13 19:23:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:57 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:57 --> URI Class Initialized
INFO - 2023-09-13 19:23:57 --> Router Class Initialized
INFO - 2023-09-13 19:23:57 --> Output Class Initialized
INFO - 2023-09-13 19:23:57 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:57 --> Input Class Initialized
INFO - 2023-09-13 19:23:57 --> Language Class Initialized
ERROR - 2023-09-13 19:23:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:57 --> Output Class Initialized
INFO - 2023-09-13 19:23:57 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:58 --> Config Class Initialized
INFO - 2023-09-13 19:23:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:58 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:58 --> URI Class Initialized
INFO - 2023-09-13 19:23:58 --> Router Class Initialized
INFO - 2023-09-13 19:23:58 --> Output Class Initialized
INFO - 2023-09-13 19:23:58 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:58 --> Input Class Initialized
INFO - 2023-09-13 19:23:58 --> Language Class Initialized
ERROR - 2023-09-13 19:23:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:58 --> Input Class Initialized
INFO - 2023-09-13 19:23:58 --> Config Class Initialized
INFO - 2023-09-13 19:23:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:58 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:58 --> URI Class Initialized
INFO - 2023-09-13 19:23:58 --> Router Class Initialized
INFO - 2023-09-13 19:23:58 --> Output Class Initialized
INFO - 2023-09-13 19:23:58 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:58 --> Input Class Initialized
INFO - 2023-09-13 19:23:58 --> Language Class Initialized
ERROR - 2023-09-13 19:23:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:58 --> Language Class Initialized
ERROR - 2023-09-13 19:23:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:58 --> Config Class Initialized
INFO - 2023-09-13 19:23:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:58 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:58 --> URI Class Initialized
INFO - 2023-09-13 19:23:58 --> Router Class Initialized
INFO - 2023-09-13 19:23:58 --> Output Class Initialized
INFO - 2023-09-13 19:23:58 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:58 --> Input Class Initialized
INFO - 2023-09-13 19:23:58 --> Language Class Initialized
ERROR - 2023-09-13 19:23:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:59 --> Config Class Initialized
INFO - 2023-09-13 19:23:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:59 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:59 --> URI Class Initialized
INFO - 2023-09-13 19:23:59 --> Router Class Initialized
INFO - 2023-09-13 19:23:59 --> Output Class Initialized
INFO - 2023-09-13 19:23:59 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:59 --> Input Class Initialized
INFO - 2023-09-13 19:23:59 --> Language Class Initialized
ERROR - 2023-09-13 19:23:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:59 --> Config Class Initialized
INFO - 2023-09-13 19:23:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:59 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:59 --> URI Class Initialized
INFO - 2023-09-13 19:23:59 --> Router Class Initialized
INFO - 2023-09-13 19:23:59 --> Output Class Initialized
INFO - 2023-09-13 19:23:59 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:59 --> Input Class Initialized
INFO - 2023-09-13 19:23:59 --> Language Class Initialized
ERROR - 2023-09-13 19:23:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:23:59 --> Config Class Initialized
INFO - 2023-09-13 19:23:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:23:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:23:59 --> Utf8 Class Initialized
INFO - 2023-09-13 19:23:59 --> URI Class Initialized
INFO - 2023-09-13 19:23:59 --> Router Class Initialized
INFO - 2023-09-13 19:23:59 --> Output Class Initialized
INFO - 2023-09-13 19:23:59 --> Security Class Initialized
DEBUG - 2023-09-13 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:23:59 --> Input Class Initialized
INFO - 2023-09-13 19:23:59 --> Language Class Initialized
ERROR - 2023-09-13 19:23:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:24:19 --> Config Class Initialized
INFO - 2023-09-13 19:24:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:24:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:24:19 --> Utf8 Class Initialized
INFO - 2023-09-13 19:24:19 --> URI Class Initialized
INFO - 2023-09-13 19:24:19 --> Router Class Initialized
INFO - 2023-09-13 19:24:19 --> Output Class Initialized
INFO - 2023-09-13 19:24:19 --> Security Class Initialized
DEBUG - 2023-09-13 19:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:24:19 --> Input Class Initialized
INFO - 2023-09-13 19:24:19 --> Language Class Initialized
INFO - 2023-09-13 19:24:19 --> Loader Class Initialized
INFO - 2023-09-13 19:24:19 --> Helper loaded: url_helper
INFO - 2023-09-13 19:24:19 --> Helper loaded: file_helper
INFO - 2023-09-13 19:24:19 --> Database Driver Class Initialized
INFO - 2023-09-13 19:24:19 --> Email Class Initialized
DEBUG - 2023-09-13 19:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:24:19 --> Controller Class Initialized
INFO - 2023-09-13 19:24:19 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:24:19 --> Model "Home_model" initialized
INFO - 2023-09-13 19:24:19 --> Helper loaded: download_helper
INFO - 2023-09-13 19:24:19 --> Helper loaded: form_helper
INFO - 2023-09-13 19:24:19 --> Form Validation Class Initialized
INFO - 2023-09-13 19:24:19 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:24:19 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:24:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:24:19 --> Final output sent to browser
DEBUG - 2023-09-13 19:24:19 --> Total execution time: 0.2184
INFO - 2023-09-13 19:25:22 --> Config Class Initialized
INFO - 2023-09-13 19:25:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:25:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:25:22 --> Utf8 Class Initialized
INFO - 2023-09-13 19:25:22 --> URI Class Initialized
INFO - 2023-09-13 19:25:22 --> Router Class Initialized
INFO - 2023-09-13 19:25:22 --> Output Class Initialized
INFO - 2023-09-13 19:25:22 --> Security Class Initialized
DEBUG - 2023-09-13 19:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:25:22 --> Input Class Initialized
INFO - 2023-09-13 19:25:22 --> Language Class Initialized
INFO - 2023-09-13 19:25:22 --> Loader Class Initialized
INFO - 2023-09-13 19:25:22 --> Helper loaded: url_helper
INFO - 2023-09-13 19:25:22 --> Helper loaded: file_helper
INFO - 2023-09-13 19:25:22 --> Database Driver Class Initialized
INFO - 2023-09-13 19:25:22 --> Email Class Initialized
DEBUG - 2023-09-13 19:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:25:22 --> Controller Class Initialized
INFO - 2023-09-13 19:25:22 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:25:22 --> Model "Home_model" initialized
INFO - 2023-09-13 19:25:22 --> Helper loaded: download_helper
INFO - 2023-09-13 19:25:22 --> Helper loaded: form_helper
INFO - 2023-09-13 19:25:22 --> Form Validation Class Initialized
INFO - 2023-09-13 19:25:22 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:25:22 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:25:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:25:22 --> Final output sent to browser
DEBUG - 2023-09-13 19:25:22 --> Total execution time: 0.1483
INFO - 2023-09-13 19:29:05 --> Config Class Initialized
INFO - 2023-09-13 19:29:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:29:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:29:05 --> Utf8 Class Initialized
INFO - 2023-09-13 19:29:05 --> URI Class Initialized
INFO - 2023-09-13 19:29:05 --> Router Class Initialized
INFO - 2023-09-13 19:29:05 --> Output Class Initialized
INFO - 2023-09-13 19:29:05 --> Security Class Initialized
DEBUG - 2023-09-13 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:29:05 --> Input Class Initialized
INFO - 2023-09-13 19:29:05 --> Language Class Initialized
INFO - 2023-09-13 19:29:05 --> Loader Class Initialized
INFO - 2023-09-13 19:29:05 --> Helper loaded: url_helper
INFO - 2023-09-13 19:29:05 --> Helper loaded: file_helper
INFO - 2023-09-13 19:29:05 --> Database Driver Class Initialized
INFO - 2023-09-13 19:29:05 --> Email Class Initialized
DEBUG - 2023-09-13 19:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:29:05 --> Controller Class Initialized
INFO - 2023-09-13 19:29:05 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:29:05 --> Model "Home_model" initialized
INFO - 2023-09-13 19:29:05 --> Helper loaded: download_helper
INFO - 2023-09-13 19:29:05 --> Helper loaded: form_helper
INFO - 2023-09-13 19:29:05 --> Form Validation Class Initialized
INFO - 2023-09-13 19:29:06 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:29:06 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:29:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:29:06 --> Final output sent to browser
DEBUG - 2023-09-13 19:29:06 --> Total execution time: 0.1366
INFO - 2023-09-13 19:30:51 --> Config Class Initialized
INFO - 2023-09-13 19:30:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:30:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:30:51 --> Utf8 Class Initialized
INFO - 2023-09-13 19:30:51 --> URI Class Initialized
INFO - 2023-09-13 19:30:51 --> Router Class Initialized
INFO - 2023-09-13 19:30:51 --> Output Class Initialized
INFO - 2023-09-13 19:30:51 --> Security Class Initialized
DEBUG - 2023-09-13 19:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:30:51 --> Input Class Initialized
INFO - 2023-09-13 19:30:51 --> Language Class Initialized
INFO - 2023-09-13 19:30:51 --> Loader Class Initialized
INFO - 2023-09-13 19:30:51 --> Helper loaded: url_helper
INFO - 2023-09-13 19:30:51 --> Helper loaded: file_helper
INFO - 2023-09-13 19:30:51 --> Database Driver Class Initialized
INFO - 2023-09-13 19:30:51 --> Email Class Initialized
DEBUG - 2023-09-13 19:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:30:51 --> Controller Class Initialized
INFO - 2023-09-13 19:30:51 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:30:51 --> Model "Home_model" initialized
INFO - 2023-09-13 19:30:51 --> Helper loaded: download_helper
INFO - 2023-09-13 19:30:51 --> Helper loaded: form_helper
INFO - 2023-09-13 19:30:51 --> Form Validation Class Initialized
INFO - 2023-09-13 19:30:51 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:30:51 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:30:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:30:51 --> Final output sent to browser
DEBUG - 2023-09-13 19:30:51 --> Total execution time: 0.1928
INFO - 2023-09-13 19:36:18 --> Config Class Initialized
INFO - 2023-09-13 19:36:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:36:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:36:18 --> Utf8 Class Initialized
INFO - 2023-09-13 19:36:18 --> URI Class Initialized
INFO - 2023-09-13 19:36:18 --> Router Class Initialized
INFO - 2023-09-13 19:36:18 --> Output Class Initialized
INFO - 2023-09-13 19:36:18 --> Security Class Initialized
DEBUG - 2023-09-13 19:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:36:18 --> Input Class Initialized
INFO - 2023-09-13 19:36:18 --> Language Class Initialized
INFO - 2023-09-13 19:36:18 --> Loader Class Initialized
INFO - 2023-09-13 19:36:18 --> Helper loaded: url_helper
INFO - 2023-09-13 19:36:18 --> Helper loaded: file_helper
INFO - 2023-09-13 19:36:18 --> Database Driver Class Initialized
INFO - 2023-09-13 19:36:18 --> Email Class Initialized
DEBUG - 2023-09-13 19:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:36:18 --> Controller Class Initialized
INFO - 2023-09-13 19:36:18 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:36:18 --> Model "Home_model" initialized
INFO - 2023-09-13 19:36:18 --> Helper loaded: download_helper
INFO - 2023-09-13 19:36:19 --> Helper loaded: form_helper
INFO - 2023-09-13 19:36:19 --> Form Validation Class Initialized
INFO - 2023-09-13 19:36:19 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:36:19 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:36:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:36:19 --> Final output sent to browser
DEBUG - 2023-09-13 19:36:19 --> Total execution time: 0.8167
INFO - 2023-09-13 19:38:23 --> Config Class Initialized
INFO - 2023-09-13 19:38:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:23 --> URI Class Initialized
INFO - 2023-09-13 19:38:23 --> Router Class Initialized
INFO - 2023-09-13 19:38:23 --> Output Class Initialized
INFO - 2023-09-13 19:38:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:23 --> Input Class Initialized
INFO - 2023-09-13 19:38:23 --> Language Class Initialized
ERROR - 2023-09-13 19:38:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:23 --> Config Class Initialized
INFO - 2023-09-13 19:38:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:23 --> URI Class Initialized
INFO - 2023-09-13 19:38:23 --> Router Class Initialized
INFO - 2023-09-13 19:38:23 --> Output Class Initialized
INFO - 2023-09-13 19:38:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:23 --> Input Class Initialized
INFO - 2023-09-13 19:38:23 --> Language Class Initialized
ERROR - 2023-09-13 19:38:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:24 --> Config Class Initialized
INFO - 2023-09-13 19:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:24 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:24 --> URI Class Initialized
INFO - 2023-09-13 19:38:24 --> Router Class Initialized
INFO - 2023-09-13 19:38:24 --> Output Class Initialized
INFO - 2023-09-13 19:38:24 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:24 --> Input Class Initialized
INFO - 2023-09-13 19:38:24 --> Language Class Initialized
ERROR - 2023-09-13 19:38:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:24 --> Config Class Initialized
INFO - 2023-09-13 19:38:24 --> Config Class Initialized
INFO - 2023-09-13 19:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:24 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:24 --> URI Class Initialized
INFO - 2023-09-13 19:38:24 --> Router Class Initialized
INFO - 2023-09-13 19:38:24 --> Output Class Initialized
INFO - 2023-09-13 19:38:24 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:24 --> Input Class Initialized
INFO - 2023-09-13 19:38:24 --> Language Class Initialized
ERROR - 2023-09-13 19:38:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:24 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:24 --> URI Class Initialized
INFO - 2023-09-13 19:38:25 --> Router Class Initialized
INFO - 2023-09-13 19:38:25 --> Output Class Initialized
INFO - 2023-09-13 19:38:25 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:25 --> Input Class Initialized
INFO - 2023-09-13 19:38:25 --> Language Class Initialized
ERROR - 2023-09-13 19:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:25 --> Config Class Initialized
INFO - 2023-09-13 19:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:25 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:25 --> URI Class Initialized
INFO - 2023-09-13 19:38:25 --> Router Class Initialized
INFO - 2023-09-13 19:38:25 --> Output Class Initialized
INFO - 2023-09-13 19:38:25 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:25 --> Input Class Initialized
INFO - 2023-09-13 19:38:25 --> Language Class Initialized
ERROR - 2023-09-13 19:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:38:25 --> Config Class Initialized
INFO - 2023-09-13 19:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:38:25 --> Utf8 Class Initialized
INFO - 2023-09-13 19:38:25 --> URI Class Initialized
INFO - 2023-09-13 19:38:25 --> Router Class Initialized
INFO - 2023-09-13 19:38:25 --> Output Class Initialized
INFO - 2023-09-13 19:38:25 --> Security Class Initialized
DEBUG - 2023-09-13 19:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:38:25 --> Input Class Initialized
INFO - 2023-09-13 19:38:25 --> Language Class Initialized
ERROR - 2023-09-13 19:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:37 --> Config Class Initialized
INFO - 2023-09-13 19:40:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:37 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:37 --> URI Class Initialized
INFO - 2023-09-13 19:40:37 --> Router Class Initialized
INFO - 2023-09-13 19:40:37 --> Output Class Initialized
INFO - 2023-09-13 19:40:37 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:37 --> Input Class Initialized
INFO - 2023-09-13 19:40:37 --> Language Class Initialized
INFO - 2023-09-13 19:40:37 --> Loader Class Initialized
INFO - 2023-09-13 19:40:37 --> Helper loaded: url_helper
INFO - 2023-09-13 19:40:37 --> Helper loaded: file_helper
INFO - 2023-09-13 19:40:37 --> Database Driver Class Initialized
INFO - 2023-09-13 19:40:37 --> Email Class Initialized
DEBUG - 2023-09-13 19:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:40:37 --> Controller Class Initialized
INFO - 2023-09-13 19:40:37 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:40:37 --> Model "Home_model" initialized
INFO - 2023-09-13 19:40:37 --> Helper loaded: download_helper
INFO - 2023-09-13 19:40:37 --> Helper loaded: form_helper
INFO - 2023-09-13 19:40:37 --> Form Validation Class Initialized
INFO - 2023-09-13 19:40:37 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:40:37 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:40:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:40:38 --> Final output sent to browser
DEBUG - 2023-09-13 19:40:38 --> Total execution time: 0.1329
INFO - 2023-09-13 19:40:39 --> Config Class Initialized
INFO - 2023-09-13 19:40:39 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:39 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:39 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:39 --> URI Class Initialized
INFO - 2023-09-13 19:40:39 --> Router Class Initialized
INFO - 2023-09-13 19:40:39 --> Output Class Initialized
INFO - 2023-09-13 19:40:39 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:39 --> Input Class Initialized
INFO - 2023-09-13 19:40:39 --> Language Class Initialized
ERROR - 2023-09-13 19:40:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:40 --> Config Class Initialized
INFO - 2023-09-13 19:40:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:40 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:40 --> URI Class Initialized
INFO - 2023-09-13 19:40:40 --> Router Class Initialized
INFO - 2023-09-13 19:40:40 --> Output Class Initialized
INFO - 2023-09-13 19:40:40 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:40 --> Input Class Initialized
INFO - 2023-09-13 19:40:40 --> Language Class Initialized
ERROR - 2023-09-13 19:40:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:41 --> Config Class Initialized
INFO - 2023-09-13 19:40:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:41 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:41 --> URI Class Initialized
INFO - 2023-09-13 19:40:41 --> Router Class Initialized
INFO - 2023-09-13 19:40:41 --> Output Class Initialized
INFO - 2023-09-13 19:40:41 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:41 --> Input Class Initialized
INFO - 2023-09-13 19:40:41 --> Language Class Initialized
ERROR - 2023-09-13 19:40:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:41 --> Config Class Initialized
INFO - 2023-09-13 19:40:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:41 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:41 --> URI Class Initialized
INFO - 2023-09-13 19:40:41 --> Router Class Initialized
INFO - 2023-09-13 19:40:41 --> Output Class Initialized
INFO - 2023-09-13 19:40:41 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:41 --> Input Class Initialized
INFO - 2023-09-13 19:40:41 --> Language Class Initialized
ERROR - 2023-09-13 19:40:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:42 --> Config Class Initialized
INFO - 2023-09-13 19:40:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:42 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:42 --> URI Class Initialized
INFO - 2023-09-13 19:40:42 --> Router Class Initialized
INFO - 2023-09-13 19:40:42 --> Output Class Initialized
INFO - 2023-09-13 19:40:42 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:42 --> Input Class Initialized
INFO - 2023-09-13 19:40:42 --> Language Class Initialized
ERROR - 2023-09-13 19:40:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:42 --> Config Class Initialized
INFO - 2023-09-13 19:40:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:42 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:42 --> URI Class Initialized
INFO - 2023-09-13 19:40:42 --> Router Class Initialized
INFO - 2023-09-13 19:40:42 --> Output Class Initialized
INFO - 2023-09-13 19:40:42 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:42 --> Input Class Initialized
INFO - 2023-09-13 19:40:42 --> Language Class Initialized
ERROR - 2023-09-13 19:40:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:40:42 --> Config Class Initialized
INFO - 2023-09-13 19:40:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:40:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:40:42 --> Utf8 Class Initialized
INFO - 2023-09-13 19:40:42 --> URI Class Initialized
INFO - 2023-09-13 19:40:42 --> Router Class Initialized
INFO - 2023-09-13 19:40:42 --> Output Class Initialized
INFO - 2023-09-13 19:40:42 --> Security Class Initialized
DEBUG - 2023-09-13 19:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:40:42 --> Input Class Initialized
INFO - 2023-09-13 19:40:42 --> Language Class Initialized
ERROR - 2023-09-13 19:40:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:41:47 --> Config Class Initialized
INFO - 2023-09-13 19:41:47 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:41:47 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:41:47 --> Utf8 Class Initialized
INFO - 2023-09-13 19:41:47 --> URI Class Initialized
INFO - 2023-09-13 19:41:47 --> Router Class Initialized
INFO - 2023-09-13 19:41:47 --> Output Class Initialized
INFO - 2023-09-13 19:41:47 --> Security Class Initialized
DEBUG - 2023-09-13 19:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:41:47 --> Input Class Initialized
INFO - 2023-09-13 19:41:47 --> Language Class Initialized
INFO - 2023-09-13 19:41:47 --> Loader Class Initialized
INFO - 2023-09-13 19:41:47 --> Helper loaded: url_helper
INFO - 2023-09-13 19:41:47 --> Helper loaded: file_helper
INFO - 2023-09-13 19:41:47 --> Database Driver Class Initialized
INFO - 2023-09-13 19:41:47 --> Email Class Initialized
DEBUG - 2023-09-13 19:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:41:47 --> Controller Class Initialized
INFO - 2023-09-13 19:41:47 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:41:47 --> Model "Home_model" initialized
INFO - 2023-09-13 19:41:47 --> Helper loaded: download_helper
INFO - 2023-09-13 19:41:47 --> Helper loaded: form_helper
INFO - 2023-09-13 19:41:47 --> Form Validation Class Initialized
INFO - 2023-09-13 19:41:48 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:41:48 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:41:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:41:48 --> Final output sent to browser
DEBUG - 2023-09-13 19:41:48 --> Total execution time: 0.1554
INFO - 2023-09-13 19:55:03 --> Config Class Initialized
INFO - 2023-09-13 19:55:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:03 --> URI Class Initialized
INFO - 2023-09-13 19:55:04 --> Router Class Initialized
INFO - 2023-09-13 19:55:04 --> Output Class Initialized
INFO - 2023-09-13 19:55:04 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:04 --> Input Class Initialized
INFO - 2023-09-13 19:55:04 --> Language Class Initialized
INFO - 2023-09-13 19:55:04 --> Loader Class Initialized
INFO - 2023-09-13 19:55:04 --> Helper loaded: url_helper
INFO - 2023-09-13 19:55:04 --> Helper loaded: file_helper
INFO - 2023-09-13 19:55:04 --> Database Driver Class Initialized
INFO - 2023-09-13 19:55:04 --> Email Class Initialized
DEBUG - 2023-09-13 19:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:55:04 --> Controller Class Initialized
INFO - 2023-09-13 19:55:04 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:55:04 --> Model "Home_model" initialized
INFO - 2023-09-13 19:55:05 --> Helper loaded: download_helper
INFO - 2023-09-13 19:55:05 --> Helper loaded: form_helper
INFO - 2023-09-13 19:55:05 --> Form Validation Class Initialized
INFO - 2023-09-13 19:55:05 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:55:05 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:55:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:55:05 --> Final output sent to browser
DEBUG - 2023-09-13 19:55:05 --> Total execution time: 1.7786
INFO - 2023-09-13 19:55:07 --> Config Class Initialized
INFO - 2023-09-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:07 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:07 --> URI Class Initialized
INFO - 2023-09-13 19:55:07 --> Router Class Initialized
INFO - 2023-09-13 19:55:07 --> Output Class Initialized
INFO - 2023-09-13 19:55:07 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:07 --> Input Class Initialized
INFO - 2023-09-13 19:55:07 --> Language Class Initialized
ERROR - 2023-09-13 19:55:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:55:11 --> Config Class Initialized
INFO - 2023-09-13 19:55:11 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:11 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:11 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:11 --> URI Class Initialized
INFO - 2023-09-13 19:55:11 --> Router Class Initialized
INFO - 2023-09-13 19:55:11 --> Output Class Initialized
INFO - 2023-09-13 19:55:11 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:11 --> Input Class Initialized
INFO - 2023-09-13 19:55:11 --> Language Class Initialized
INFO - 2023-09-13 19:55:11 --> Loader Class Initialized
INFO - 2023-09-13 19:55:11 --> Helper loaded: url_helper
INFO - 2023-09-13 19:55:11 --> Helper loaded: file_helper
INFO - 2023-09-13 19:55:11 --> Database Driver Class Initialized
INFO - 2023-09-13 19:55:11 --> Email Class Initialized
DEBUG - 2023-09-13 19:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:55:11 --> Controller Class Initialized
INFO - 2023-09-13 19:55:11 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:55:11 --> Model "Home_model" initialized
INFO - 2023-09-13 19:55:11 --> Helper loaded: download_helper
INFO - 2023-09-13 19:55:11 --> Helper loaded: form_helper
INFO - 2023-09-13 19:55:11 --> Form Validation Class Initialized
INFO - 2023-09-13 19:55:11 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:55:11 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:55:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:55:11 --> Final output sent to browser
DEBUG - 2023-09-13 19:55:11 --> Total execution time: 0.0634
INFO - 2023-09-13 19:55:12 --> Config Class Initialized
INFO - 2023-09-13 19:55:12 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:12 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:12 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:12 --> URI Class Initialized
INFO - 2023-09-13 19:55:12 --> Router Class Initialized
INFO - 2023-09-13 19:55:12 --> Output Class Initialized
INFO - 2023-09-13 19:55:12 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:12 --> Input Class Initialized
INFO - 2023-09-13 19:55:12 --> Language Class Initialized
ERROR - 2023-09-13 19:55:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:55:16 --> Config Class Initialized
INFO - 2023-09-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:16 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:16 --> URI Class Initialized
INFO - 2023-09-13 19:55:16 --> Router Class Initialized
INFO - 2023-09-13 19:55:16 --> Output Class Initialized
INFO - 2023-09-13 19:55:16 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:16 --> Input Class Initialized
INFO - 2023-09-13 19:55:16 --> Language Class Initialized
INFO - 2023-09-13 19:55:16 --> Loader Class Initialized
INFO - 2023-09-13 19:55:16 --> Helper loaded: url_helper
INFO - 2023-09-13 19:55:16 --> Helper loaded: file_helper
INFO - 2023-09-13 19:55:16 --> Database Driver Class Initialized
INFO - 2023-09-13 19:55:16 --> Email Class Initialized
DEBUG - 2023-09-13 19:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:55:16 --> Controller Class Initialized
INFO - 2023-09-13 19:55:16 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:55:16 --> Model "Home_model" initialized
INFO - 2023-09-13 19:55:16 --> Helper loaded: download_helper
INFO - 2023-09-13 19:55:16 --> Helper loaded: form_helper
INFO - 2023-09-13 19:55:16 --> Form Validation Class Initialized
INFO - 2023-09-13 19:55:16 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:55:16 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:55:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:55:16 --> Final output sent to browser
DEBUG - 2023-09-13 19:55:17 --> Total execution time: 0.2121
INFO - 2023-09-13 19:55:17 --> Config Class Initialized
INFO - 2023-09-13 19:55:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:17 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:17 --> URI Class Initialized
INFO - 2023-09-13 19:55:17 --> Router Class Initialized
INFO - 2023-09-13 19:55:17 --> Output Class Initialized
INFO - 2023-09-13 19:55:17 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:17 --> Input Class Initialized
INFO - 2023-09-13 19:55:17 --> Language Class Initialized
ERROR - 2023-09-13 19:55:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:55:20 --> Config Class Initialized
INFO - 2023-09-13 19:55:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:20 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:20 --> URI Class Initialized
INFO - 2023-09-13 19:55:20 --> Router Class Initialized
INFO - 2023-09-13 19:55:20 --> Output Class Initialized
INFO - 2023-09-13 19:55:20 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:20 --> Input Class Initialized
INFO - 2023-09-13 19:55:20 --> Language Class Initialized
INFO - 2023-09-13 19:55:20 --> Loader Class Initialized
INFO - 2023-09-13 19:55:20 --> Helper loaded: url_helper
INFO - 2023-09-13 19:55:20 --> Helper loaded: file_helper
INFO - 2023-09-13 19:55:20 --> Database Driver Class Initialized
INFO - 2023-09-13 19:55:20 --> Email Class Initialized
DEBUG - 2023-09-13 19:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:55:20 --> Controller Class Initialized
INFO - 2023-09-13 19:55:20 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:55:20 --> Model "Home_model" initialized
INFO - 2023-09-13 19:55:20 --> Helper loaded: download_helper
INFO - 2023-09-13 19:55:20 --> Helper loaded: form_helper
INFO - 2023-09-13 19:55:20 --> Form Validation Class Initialized
INFO - 2023-09-13 19:55:20 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:55:20 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:55:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 19:55:20 --> Final output sent to browser
DEBUG - 2023-09-13 19:55:20 --> Total execution time: 0.2205
INFO - 2023-09-13 19:55:30 --> Config Class Initialized
INFO - 2023-09-13 19:55:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:30 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:30 --> URI Class Initialized
INFO - 2023-09-13 19:55:30 --> Router Class Initialized
INFO - 2023-09-13 19:55:30 --> Output Class Initialized
INFO - 2023-09-13 19:55:30 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:30 --> Input Class Initialized
INFO - 2023-09-13 19:55:30 --> Language Class Initialized
INFO - 2023-09-13 19:55:30 --> Loader Class Initialized
INFO - 2023-09-13 19:55:30 --> Helper loaded: url_helper
INFO - 2023-09-13 19:55:30 --> Helper loaded: file_helper
INFO - 2023-09-13 19:55:30 --> Database Driver Class Initialized
INFO - 2023-09-13 19:55:30 --> Email Class Initialized
DEBUG - 2023-09-13 19:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:55:30 --> Controller Class Initialized
INFO - 2023-09-13 19:55:30 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:55:30 --> Model "Home_model" initialized
INFO - 2023-09-13 19:55:30 --> Helper loaded: download_helper
INFO - 2023-09-13 19:55:30 --> Helper loaded: form_helper
INFO - 2023-09-13 19:55:30 --> Form Validation Class Initialized
INFO - 2023-09-13 19:55:30 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:55:30 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:55:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:55:30 --> Final output sent to browser
DEBUG - 2023-09-13 19:55:30 --> Total execution time: 1.1238
INFO - 2023-09-13 19:55:32 --> Config Class Initialized
INFO - 2023-09-13 19:55:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:55:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:55:32 --> Utf8 Class Initialized
INFO - 2023-09-13 19:55:32 --> URI Class Initialized
INFO - 2023-09-13 19:55:32 --> Router Class Initialized
INFO - 2023-09-13 19:55:32 --> Output Class Initialized
INFO - 2023-09-13 19:55:32 --> Security Class Initialized
DEBUG - 2023-09-13 19:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:55:32 --> Input Class Initialized
INFO - 2023-09-13 19:55:32 --> Language Class Initialized
ERROR - 2023-09-13 19:55:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:56:01 --> Config Class Initialized
INFO - 2023-09-13 19:56:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:56:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:56:01 --> Utf8 Class Initialized
INFO - 2023-09-13 19:56:01 --> URI Class Initialized
INFO - 2023-09-13 19:56:01 --> Router Class Initialized
INFO - 2023-09-13 19:56:01 --> Output Class Initialized
INFO - 2023-09-13 19:56:01 --> Security Class Initialized
DEBUG - 2023-09-13 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:56:01 --> Input Class Initialized
INFO - 2023-09-13 19:56:01 --> Language Class Initialized
INFO - 2023-09-13 19:56:01 --> Loader Class Initialized
INFO - 2023-09-13 19:56:01 --> Helper loaded: url_helper
INFO - 2023-09-13 19:56:01 --> Helper loaded: file_helper
INFO - 2023-09-13 19:56:01 --> Database Driver Class Initialized
INFO - 2023-09-13 19:56:01 --> Email Class Initialized
DEBUG - 2023-09-13 19:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:56:01 --> Controller Class Initialized
INFO - 2023-09-13 19:56:01 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:56:01 --> Model "Home_model" initialized
INFO - 2023-09-13 19:56:01 --> Helper loaded: download_helper
INFO - 2023-09-13 19:56:01 --> Helper loaded: form_helper
INFO - 2023-09-13 19:56:01 --> Form Validation Class Initialized
INFO - 2023-09-13 19:56:01 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:56:01 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:56:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 19:56:01 --> Final output sent to browser
DEBUG - 2023-09-13 19:56:01 --> Total execution time: 0.1138
INFO - 2023-09-13 19:56:08 --> Config Class Initialized
INFO - 2023-09-13 19:56:08 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:56:08 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:56:08 --> Utf8 Class Initialized
INFO - 2023-09-13 19:56:08 --> URI Class Initialized
INFO - 2023-09-13 19:56:08 --> Router Class Initialized
INFO - 2023-09-13 19:56:08 --> Output Class Initialized
INFO - 2023-09-13 19:56:08 --> Security Class Initialized
DEBUG - 2023-09-13 19:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:56:08 --> Input Class Initialized
INFO - 2023-09-13 19:56:08 --> Language Class Initialized
INFO - 2023-09-13 19:56:08 --> Loader Class Initialized
INFO - 2023-09-13 19:56:08 --> Helper loaded: url_helper
INFO - 2023-09-13 19:56:08 --> Helper loaded: file_helper
INFO - 2023-09-13 19:56:08 --> Database Driver Class Initialized
INFO - 2023-09-13 19:56:08 --> Email Class Initialized
DEBUG - 2023-09-13 19:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:56:08 --> Controller Class Initialized
INFO - 2023-09-13 19:56:08 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:56:08 --> Model "Home_model" initialized
INFO - 2023-09-13 19:56:08 --> Helper loaded: download_helper
INFO - 2023-09-13 19:56:08 --> Helper loaded: form_helper
INFO - 2023-09-13 19:56:08 --> Form Validation Class Initialized
INFO - 2023-09-13 19:56:08 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:56:08 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:56:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-13 19:56:08 --> Final output sent to browser
DEBUG - 2023-09-13 19:56:08 --> Total execution time: 0.0974
INFO - 2023-09-13 19:56:23 --> Config Class Initialized
INFO - 2023-09-13 19:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:56:23 --> Utf8 Class Initialized
INFO - 2023-09-13 19:56:23 --> URI Class Initialized
INFO - 2023-09-13 19:56:23 --> Router Class Initialized
INFO - 2023-09-13 19:56:23 --> Output Class Initialized
INFO - 2023-09-13 19:56:23 --> Security Class Initialized
DEBUG - 2023-09-13 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:56:23 --> Input Class Initialized
INFO - 2023-09-13 19:56:23 --> Language Class Initialized
INFO - 2023-09-13 19:56:23 --> Loader Class Initialized
INFO - 2023-09-13 19:56:23 --> Helper loaded: url_helper
INFO - 2023-09-13 19:56:23 --> Helper loaded: file_helper
INFO - 2023-09-13 19:56:23 --> Database Driver Class Initialized
INFO - 2023-09-13 19:56:23 --> Email Class Initialized
DEBUG - 2023-09-13 19:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:56:23 --> Controller Class Initialized
INFO - 2023-09-13 19:56:23 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:56:23 --> Model "Home_model" initialized
INFO - 2023-09-13 19:56:23 --> Helper loaded: download_helper
INFO - 2023-09-13 19:56:23 --> Helper loaded: form_helper
INFO - 2023-09-13 19:56:23 --> Form Validation Class Initialized
INFO - 2023-09-13 19:56:24 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:56:24 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:56:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 19:56:24 --> Final output sent to browser
DEBUG - 2023-09-13 19:56:24 --> Total execution time: 0.2813
INFO - 2023-09-13 19:56:54 --> Config Class Initialized
INFO - 2023-09-13 19:56:54 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:56:54 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:56:54 --> Utf8 Class Initialized
INFO - 2023-09-13 19:56:54 --> URI Class Initialized
INFO - 2023-09-13 19:56:54 --> Router Class Initialized
INFO - 2023-09-13 19:56:54 --> Output Class Initialized
INFO - 2023-09-13 19:56:54 --> Security Class Initialized
DEBUG - 2023-09-13 19:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:56:54 --> Input Class Initialized
INFO - 2023-09-13 19:56:54 --> Language Class Initialized
INFO - 2023-09-13 19:56:54 --> Loader Class Initialized
INFO - 2023-09-13 19:56:54 --> Helper loaded: url_helper
INFO - 2023-09-13 19:56:54 --> Helper loaded: file_helper
INFO - 2023-09-13 19:56:54 --> Database Driver Class Initialized
INFO - 2023-09-13 19:56:54 --> Email Class Initialized
DEBUG - 2023-09-13 19:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 19:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 19:56:54 --> Controller Class Initialized
INFO - 2023-09-13 19:56:54 --> Model "Contact_model" initialized
INFO - 2023-09-13 19:56:54 --> Model "Home_model" initialized
INFO - 2023-09-13 19:56:54 --> Helper loaded: download_helper
INFO - 2023-09-13 19:56:54 --> Helper loaded: form_helper
INFO - 2023-09-13 19:56:54 --> Form Validation Class Initialized
INFO - 2023-09-13 19:56:54 --> Helper loaded: custom_helper
INFO - 2023-09-13 19:56:54 --> Model "Social_media_model" initialized
INFO - 2023-09-13 19:56:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 19:56:54 --> Final output sent to browser
DEBUG - 2023-09-13 19:56:55 --> Total execution time: 0.2071
INFO - 2023-09-13 19:57:02 --> Config Class Initialized
INFO - 2023-09-13 19:57:02 --> Config Class Initialized
INFO - 2023-09-13 19:57:02 --> Hooks Class Initialized
INFO - 2023-09-13 19:57:02 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 19:57:02 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:02 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:02 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:02 --> URI Class Initialized
INFO - 2023-09-13 19:57:02 --> URI Class Initialized
INFO - 2023-09-13 19:57:02 --> Router Class Initialized
INFO - 2023-09-13 19:57:02 --> Router Class Initialized
INFO - 2023-09-13 19:57:02 --> Output Class Initialized
INFO - 2023-09-13 19:57:02 --> Output Class Initialized
INFO - 2023-09-13 19:57:02 --> Security Class Initialized
INFO - 2023-09-13 19:57:02 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 19:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:02 --> Input Class Initialized
INFO - 2023-09-13 19:57:02 --> Input Class Initialized
INFO - 2023-09-13 19:57:02 --> Language Class Initialized
INFO - 2023-09-13 19:57:02 --> Language Class Initialized
ERROR - 2023-09-13 19:57:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-13 19:57:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:57:03 --> Config Class Initialized
INFO - 2023-09-13 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:03 --> URI Class Initialized
INFO - 2023-09-13 19:57:03 --> Router Class Initialized
INFO - 2023-09-13 19:57:03 --> Output Class Initialized
INFO - 2023-09-13 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:03 --> Input Class Initialized
INFO - 2023-09-13 19:57:03 --> Language Class Initialized
ERROR - 2023-09-13 19:57:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:57:03 --> Config Class Initialized
INFO - 2023-09-13 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:03 --> URI Class Initialized
INFO - 2023-09-13 19:57:03 --> Router Class Initialized
INFO - 2023-09-13 19:57:03 --> Output Class Initialized
INFO - 2023-09-13 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:03 --> Input Class Initialized
INFO - 2023-09-13 19:57:03 --> Language Class Initialized
ERROR - 2023-09-13 19:57:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:57:03 --> Config Class Initialized
INFO - 2023-09-13 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:03 --> URI Class Initialized
INFO - 2023-09-13 19:57:03 --> Router Class Initialized
INFO - 2023-09-13 19:57:03 --> Output Class Initialized
INFO - 2023-09-13 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:03 --> Input Class Initialized
INFO - 2023-09-13 19:57:03 --> Language Class Initialized
ERROR - 2023-09-13 19:57:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:57:03 --> Config Class Initialized
INFO - 2023-09-13 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:03 --> URI Class Initialized
INFO - 2023-09-13 19:57:03 --> Router Class Initialized
INFO - 2023-09-13 19:57:03 --> Output Class Initialized
INFO - 2023-09-13 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:03 --> Input Class Initialized
INFO - 2023-09-13 19:57:03 --> Language Class Initialized
ERROR - 2023-09-13 19:57:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 19:57:03 --> Config Class Initialized
INFO - 2023-09-13 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-13 19:57:03 --> URI Class Initialized
INFO - 2023-09-13 19:57:03 --> Router Class Initialized
INFO - 2023-09-13 19:57:03 --> Output Class Initialized
INFO - 2023-09-13 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-13 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 19:57:03 --> Input Class Initialized
INFO - 2023-09-13 19:57:03 --> Language Class Initialized
ERROR - 2023-09-13 19:57:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:37 --> Config Class Initialized
INFO - 2023-09-13 20:00:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:37 --> URI Class Initialized
INFO - 2023-09-13 20:00:37 --> Router Class Initialized
INFO - 2023-09-13 20:00:37 --> Output Class Initialized
INFO - 2023-09-13 20:00:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:37 --> Input Class Initialized
INFO - 2023-09-13 20:00:37 --> Language Class Initialized
INFO - 2023-09-13 20:00:37 --> Loader Class Initialized
INFO - 2023-09-13 20:00:37 --> Helper loaded: url_helper
INFO - 2023-09-13 20:00:37 --> Helper loaded: file_helper
INFO - 2023-09-13 20:00:37 --> Database Driver Class Initialized
INFO - 2023-09-13 20:00:37 --> Email Class Initialized
DEBUG - 2023-09-13 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:00:37 --> Controller Class Initialized
INFO - 2023-09-13 20:00:37 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:00:37 --> Model "Home_model" initialized
INFO - 2023-09-13 20:00:37 --> Helper loaded: download_helper
INFO - 2023-09-13 20:00:37 --> Helper loaded: form_helper
INFO - 2023-09-13 20:00:37 --> Form Validation Class Initialized
INFO - 2023-09-13 20:00:37 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:00:37 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:00:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:00:38 --> Final output sent to browser
DEBUG - 2023-09-13 20:00:38 --> Total execution time: 0.1510
INFO - 2023-09-13 20:00:52 --> Config Class Initialized
INFO - 2023-09-13 20:00:52 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:52 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:52 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:52 --> URI Class Initialized
INFO - 2023-09-13 20:00:52 --> Router Class Initialized
INFO - 2023-09-13 20:00:52 --> Output Class Initialized
INFO - 2023-09-13 20:00:52 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:52 --> Input Class Initialized
INFO - 2023-09-13 20:00:52 --> Language Class Initialized
ERROR - 2023-09-13 20:00:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:00:53 --> Config Class Initialized
INFO - 2023-09-13 20:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:00:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:00:53 --> URI Class Initialized
INFO - 2023-09-13 20:00:53 --> Router Class Initialized
INFO - 2023-09-13 20:00:53 --> Output Class Initialized
INFO - 2023-09-13 20:00:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:00:53 --> Input Class Initialized
INFO - 2023-09-13 20:00:53 --> Language Class Initialized
ERROR - 2023-09-13 20:00:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:02:35 --> Config Class Initialized
INFO - 2023-09-13 20:02:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:35 --> URI Class Initialized
INFO - 2023-09-13 20:02:35 --> Router Class Initialized
INFO - 2023-09-13 20:02:35 --> Output Class Initialized
INFO - 2023-09-13 20:02:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:02:35 --> Input Class Initialized
INFO - 2023-09-13 20:02:35 --> Language Class Initialized
INFO - 2023-09-13 20:02:35 --> Loader Class Initialized
INFO - 2023-09-13 20:02:35 --> Helper loaded: url_helper
INFO - 2023-09-13 20:02:35 --> Helper loaded: file_helper
INFO - 2023-09-13 20:02:35 --> Database Driver Class Initialized
INFO - 2023-09-13 20:02:35 --> Email Class Initialized
DEBUG - 2023-09-13 20:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:02:35 --> Controller Class Initialized
INFO - 2023-09-13 20:02:35 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:02:35 --> Model "Home_model" initialized
INFO - 2023-09-13 20:02:35 --> Helper loaded: download_helper
INFO - 2023-09-13 20:02:35 --> Helper loaded: form_helper
INFO - 2023-09-13 20:02:35 --> Form Validation Class Initialized
INFO - 2023-09-13 20:02:35 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:02:35 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:02:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:02:35 --> Final output sent to browser
DEBUG - 2023-09-13 20:02:35 --> Total execution time: 0.0744
INFO - 2023-09-13 20:02:57 --> Config Class Initialized
INFO - 2023-09-13 20:02:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:57 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:57 --> URI Class Initialized
INFO - 2023-09-13 20:02:57 --> Router Class Initialized
INFO - 2023-09-13 20:02:57 --> Output Class Initialized
INFO - 2023-09-13 20:02:57 --> Security Class Initialized
DEBUG - 2023-09-13 20:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:02:57 --> Input Class Initialized
INFO - 2023-09-13 20:02:57 --> Language Class Initialized
ERROR - 2023-09-13 20:02:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:02:58 --> Config Class Initialized
INFO - 2023-09-13 20:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:58 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:58 --> URI Class Initialized
INFO - 2023-09-13 20:02:58 --> Router Class Initialized
INFO - 2023-09-13 20:02:58 --> Output Class Initialized
INFO - 2023-09-13 20:02:58 --> Security Class Initialized
DEBUG - 2023-09-13 20:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:02:58 --> Input Class Initialized
INFO - 2023-09-13 20:02:58 --> Language Class Initialized
ERROR - 2023-09-13 20:02:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:02:58 --> Config Class Initialized
INFO - 2023-09-13 20:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:59 --> Config Class Initialized
INFO - 2023-09-13 20:02:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:59 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:59 --> URI Class Initialized
INFO - 2023-09-13 20:02:59 --> Router Class Initialized
INFO - 2023-09-13 20:02:59 --> Output Class Initialized
INFO - 2023-09-13 20:02:59 --> Security Class Initialized
DEBUG - 2023-09-13 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:02:59 --> Input Class Initialized
INFO - 2023-09-13 20:02:59 --> Language Class Initialized
ERROR - 2023-09-13 20:02:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:02:59 --> Config Class Initialized
INFO - 2023-09-13 20:02:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:02:59 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:59 --> URI Class Initialized
INFO - 2023-09-13 20:02:59 --> Router Class Initialized
INFO - 2023-09-13 20:02:59 --> Output Class Initialized
INFO - 2023-09-13 20:02:59 --> Security Class Initialized
DEBUG - 2023-09-13 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:02:59 --> Input Class Initialized
INFO - 2023-09-13 20:02:59 --> Language Class Initialized
ERROR - 2023-09-13 20:02:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:02:59 --> Utf8 Class Initialized
INFO - 2023-09-13 20:02:59 --> URI Class Initialized
INFO - 2023-09-13 20:02:59 --> Router Class Initialized
INFO - 2023-09-13 20:03:00 --> Output Class Initialized
INFO - 2023-09-13 20:03:00 --> Security Class Initialized
DEBUG - 2023-09-13 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:03:00 --> Input Class Initialized
INFO - 2023-09-13 20:03:00 --> Language Class Initialized
ERROR - 2023-09-13 20:03:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:03:00 --> Config Class Initialized
INFO - 2023-09-13 20:03:00 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:03:00 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:03:00 --> Utf8 Class Initialized
INFO - 2023-09-13 20:03:00 --> URI Class Initialized
INFO - 2023-09-13 20:03:00 --> Router Class Initialized
INFO - 2023-09-13 20:03:00 --> Output Class Initialized
INFO - 2023-09-13 20:03:00 --> Security Class Initialized
DEBUG - 2023-09-13 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:03:00 --> Input Class Initialized
INFO - 2023-09-13 20:03:00 --> Language Class Initialized
ERROR - 2023-09-13 20:03:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:03:01 --> Config Class Initialized
INFO - 2023-09-13 20:03:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:03:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:03:01 --> Utf8 Class Initialized
INFO - 2023-09-13 20:03:01 --> URI Class Initialized
INFO - 2023-09-13 20:03:01 --> Router Class Initialized
INFO - 2023-09-13 20:03:01 --> Output Class Initialized
INFO - 2023-09-13 20:03:01 --> Security Class Initialized
DEBUG - 2023-09-13 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:03:01 --> Input Class Initialized
INFO - 2023-09-13 20:03:01 --> Language Class Initialized
ERROR - 2023-09-13 20:03:01 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:53 --> Config Class Initialized
INFO - 2023-09-13 20:04:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:53 --> URI Class Initialized
INFO - 2023-09-13 20:04:53 --> Router Class Initialized
INFO - 2023-09-13 20:04:53 --> Output Class Initialized
INFO - 2023-09-13 20:04:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:53 --> Input Class Initialized
INFO - 2023-09-13 20:04:53 --> Language Class Initialized
INFO - 2023-09-13 20:04:53 --> Loader Class Initialized
INFO - 2023-09-13 20:04:53 --> Helper loaded: url_helper
INFO - 2023-09-13 20:04:53 --> Helper loaded: file_helper
INFO - 2023-09-13 20:04:53 --> Database Driver Class Initialized
INFO - 2023-09-13 20:04:53 --> Email Class Initialized
DEBUG - 2023-09-13 20:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:04:53 --> Controller Class Initialized
INFO - 2023-09-13 20:04:53 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:04:53 --> Model "Home_model" initialized
INFO - 2023-09-13 20:04:53 --> Helper loaded: download_helper
INFO - 2023-09-13 20:04:53 --> Helper loaded: form_helper
INFO - 2023-09-13 20:04:53 --> Form Validation Class Initialized
INFO - 2023-09-13 20:04:53 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:04:53 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:04:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:04:53 --> Final output sent to browser
DEBUG - 2023-09-13 20:04:53 --> Total execution time: 0.1106
INFO - 2023-09-13 20:04:55 --> Config Class Initialized
INFO - 2023-09-13 20:04:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:55 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:55 --> URI Class Initialized
INFO - 2023-09-13 20:04:55 --> Router Class Initialized
INFO - 2023-09-13 20:04:55 --> Output Class Initialized
INFO - 2023-09-13 20:04:55 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:55 --> Input Class Initialized
INFO - 2023-09-13 20:04:55 --> Language Class Initialized
ERROR - 2023-09-13 20:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:55 --> Config Class Initialized
INFO - 2023-09-13 20:04:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:55 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:55 --> URI Class Initialized
INFO - 2023-09-13 20:04:55 --> Router Class Initialized
INFO - 2023-09-13 20:04:55 --> Output Class Initialized
INFO - 2023-09-13 20:04:55 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:55 --> Input Class Initialized
INFO - 2023-09-13 20:04:55 --> Language Class Initialized
ERROR - 2023-09-13 20:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:57 --> Config Class Initialized
INFO - 2023-09-13 20:04:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:57 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:57 --> URI Class Initialized
INFO - 2023-09-13 20:04:57 --> Router Class Initialized
INFO - 2023-09-13 20:04:57 --> Output Class Initialized
INFO - 2023-09-13 20:04:57 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:57 --> Input Class Initialized
INFO - 2023-09-13 20:04:57 --> Language Class Initialized
ERROR - 2023-09-13 20:04:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:57 --> Config Class Initialized
INFO - 2023-09-13 20:04:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:57 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:57 --> URI Class Initialized
INFO - 2023-09-13 20:04:57 --> Router Class Initialized
INFO - 2023-09-13 20:04:57 --> Output Class Initialized
INFO - 2023-09-13 20:04:57 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:57 --> Input Class Initialized
INFO - 2023-09-13 20:04:57 --> Language Class Initialized
ERROR - 2023-09-13 20:04:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:57 --> Config Class Initialized
INFO - 2023-09-13 20:04:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:57 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:57 --> URI Class Initialized
INFO - 2023-09-13 20:04:57 --> Router Class Initialized
INFO - 2023-09-13 20:04:57 --> Output Class Initialized
INFO - 2023-09-13 20:04:57 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:57 --> Input Class Initialized
INFO - 2023-09-13 20:04:57 --> Language Class Initialized
ERROR - 2023-09-13 20:04:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:58 --> Config Class Initialized
INFO - 2023-09-13 20:04:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:58 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:58 --> URI Class Initialized
INFO - 2023-09-13 20:04:58 --> Router Class Initialized
INFO - 2023-09-13 20:04:58 --> Output Class Initialized
INFO - 2023-09-13 20:04:58 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:58 --> Input Class Initialized
INFO - 2023-09-13 20:04:58 --> Language Class Initialized
ERROR - 2023-09-13 20:04:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:04:58 --> Config Class Initialized
INFO - 2023-09-13 20:04:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:04:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:04:58 --> Utf8 Class Initialized
INFO - 2023-09-13 20:04:58 --> URI Class Initialized
INFO - 2023-09-13 20:04:58 --> Router Class Initialized
INFO - 2023-09-13 20:04:58 --> Output Class Initialized
INFO - 2023-09-13 20:04:58 --> Security Class Initialized
DEBUG - 2023-09-13 20:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:04:58 --> Input Class Initialized
INFO - 2023-09-13 20:04:58 --> Language Class Initialized
ERROR - 2023-09-13 20:04:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:30 --> Config Class Initialized
INFO - 2023-09-13 20:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:30 --> URI Class Initialized
INFO - 2023-09-13 20:05:30 --> Router Class Initialized
INFO - 2023-09-13 20:05:30 --> Output Class Initialized
INFO - 2023-09-13 20:05:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:30 --> Input Class Initialized
INFO - 2023-09-13 20:05:30 --> Language Class Initialized
ERROR - 2023-09-13 20:05:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:30 --> Config Class Initialized
INFO - 2023-09-13 20:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:30 --> URI Class Initialized
INFO - 2023-09-13 20:05:30 --> Router Class Initialized
INFO - 2023-09-13 20:05:30 --> Output Class Initialized
INFO - 2023-09-13 20:05:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:30 --> Input Class Initialized
INFO - 2023-09-13 20:05:30 --> Language Class Initialized
ERROR - 2023-09-13 20:05:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:30 --> Config Class Initialized
INFO - 2023-09-13 20:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:30 --> URI Class Initialized
INFO - 2023-09-13 20:05:30 --> Router Class Initialized
INFO - 2023-09-13 20:05:30 --> Output Class Initialized
INFO - 2023-09-13 20:05:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:30 --> Input Class Initialized
INFO - 2023-09-13 20:05:30 --> Language Class Initialized
ERROR - 2023-09-13 20:05:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:30 --> Config Class Initialized
INFO - 2023-09-13 20:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:30 --> URI Class Initialized
INFO - 2023-09-13 20:05:30 --> Router Class Initialized
INFO - 2023-09-13 20:05:30 --> Output Class Initialized
INFO - 2023-09-13 20:05:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:30 --> Input Class Initialized
INFO - 2023-09-13 20:05:30 --> Language Class Initialized
ERROR - 2023-09-13 20:05:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:30 --> Config Class Initialized
INFO - 2023-09-13 20:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:30 --> URI Class Initialized
INFO - 2023-09-13 20:05:30 --> Router Class Initialized
INFO - 2023-09-13 20:05:30 --> Output Class Initialized
INFO - 2023-09-13 20:05:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:30 --> Input Class Initialized
INFO - 2023-09-13 20:05:30 --> Language Class Initialized
ERROR - 2023-09-13 20:05:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:31 --> Config Class Initialized
INFO - 2023-09-13 20:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:31 --> URI Class Initialized
INFO - 2023-09-13 20:05:31 --> Router Class Initialized
INFO - 2023-09-13 20:05:31 --> Output Class Initialized
INFO - 2023-09-13 20:05:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:31 --> Input Class Initialized
INFO - 2023-09-13 20:05:31 --> Language Class Initialized
ERROR - 2023-09-13 20:05:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:05:31 --> Config Class Initialized
INFO - 2023-09-13 20:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:05:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:05:32 --> URI Class Initialized
INFO - 2023-09-13 20:05:32 --> Router Class Initialized
INFO - 2023-09-13 20:05:32 --> Output Class Initialized
INFO - 2023-09-13 20:05:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:05:32 --> Input Class Initialized
INFO - 2023-09-13 20:05:32 --> Language Class Initialized
ERROR - 2023-09-13 20:05:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:07:26 --> Config Class Initialized
INFO - 2023-09-13 20:07:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:07:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:07:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:07:26 --> URI Class Initialized
INFO - 2023-09-13 20:07:26 --> Router Class Initialized
INFO - 2023-09-13 20:07:26 --> Output Class Initialized
INFO - 2023-09-13 20:07:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:07:26 --> Input Class Initialized
INFO - 2023-09-13 20:07:26 --> Language Class Initialized
INFO - 2023-09-13 20:07:26 --> Loader Class Initialized
INFO - 2023-09-13 20:07:26 --> Helper loaded: url_helper
INFO - 2023-09-13 20:07:26 --> Helper loaded: file_helper
INFO - 2023-09-13 20:07:26 --> Database Driver Class Initialized
INFO - 2023-09-13 20:07:26 --> Email Class Initialized
DEBUG - 2023-09-13 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:07:26 --> Controller Class Initialized
INFO - 2023-09-13 20:07:26 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:07:26 --> Model "Home_model" initialized
INFO - 2023-09-13 20:07:26 --> Helper loaded: download_helper
INFO - 2023-09-13 20:07:26 --> Helper loaded: form_helper
INFO - 2023-09-13 20:07:26 --> Form Validation Class Initialized
INFO - 2023-09-13 20:07:26 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:07:26 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:07:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:07:26 --> Final output sent to browser
DEBUG - 2023-09-13 20:07:26 --> Total execution time: 0.0896
INFO - 2023-09-13 20:07:48 --> Config Class Initialized
INFO - 2023-09-13 20:07:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:07:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:07:48 --> Utf8 Class Initialized
INFO - 2023-09-13 20:07:48 --> URI Class Initialized
INFO - 2023-09-13 20:07:48 --> Router Class Initialized
INFO - 2023-09-13 20:07:48 --> Output Class Initialized
INFO - 2023-09-13 20:07:48 --> Security Class Initialized
DEBUG - 2023-09-13 20:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:07:48 --> Input Class Initialized
INFO - 2023-09-13 20:07:48 --> Language Class Initialized
INFO - 2023-09-13 20:07:48 --> Loader Class Initialized
INFO - 2023-09-13 20:07:48 --> Helper loaded: url_helper
INFO - 2023-09-13 20:07:48 --> Helper loaded: file_helper
INFO - 2023-09-13 20:07:48 --> Database Driver Class Initialized
INFO - 2023-09-13 20:07:48 --> Email Class Initialized
DEBUG - 2023-09-13 20:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:07:48 --> Controller Class Initialized
INFO - 2023-09-13 20:07:48 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:07:48 --> Model "Home_model" initialized
INFO - 2023-09-13 20:07:48 --> Helper loaded: download_helper
INFO - 2023-09-13 20:07:48 --> Helper loaded: form_helper
INFO - 2023-09-13 20:07:48 --> Form Validation Class Initialized
INFO - 2023-09-13 20:07:48 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:07:48 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:07:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-13 20:07:48 --> Final output sent to browser
DEBUG - 2023-09-13 20:07:48 --> Total execution time: 0.2783
INFO - 2023-09-13 20:08:13 --> Config Class Initialized
INFO - 2023-09-13 20:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:13 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:13 --> URI Class Initialized
INFO - 2023-09-13 20:08:13 --> Router Class Initialized
INFO - 2023-09-13 20:08:13 --> Output Class Initialized
INFO - 2023-09-13 20:08:13 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:13 --> Input Class Initialized
INFO - 2023-09-13 20:08:13 --> Language Class Initialized
INFO - 2023-09-13 20:08:13 --> Loader Class Initialized
INFO - 2023-09-13 20:08:13 --> Helper loaded: url_helper
INFO - 2023-09-13 20:08:13 --> Helper loaded: file_helper
INFO - 2023-09-13 20:08:13 --> Database Driver Class Initialized
INFO - 2023-09-13 20:08:13 --> Email Class Initialized
DEBUG - 2023-09-13 20:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:08:13 --> Controller Class Initialized
INFO - 2023-09-13 20:08:13 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:08:13 --> Model "Home_model" initialized
INFO - 2023-09-13 20:08:13 --> Helper loaded: download_helper
INFO - 2023-09-13 20:08:13 --> Helper loaded: form_helper
INFO - 2023-09-13 20:08:13 --> Form Validation Class Initialized
INFO - 2023-09-13 20:08:13 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:08:13 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:08:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 20:08:13 --> Final output sent to browser
DEBUG - 2023-09-13 20:08:13 --> Total execution time: 0.1761
INFO - 2023-09-13 20:08:23 --> Config Class Initialized
INFO - 2023-09-13 20:08:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:23 --> URI Class Initialized
INFO - 2023-09-13 20:08:23 --> Router Class Initialized
INFO - 2023-09-13 20:08:23 --> Output Class Initialized
INFO - 2023-09-13 20:08:23 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:23 --> Input Class Initialized
INFO - 2023-09-13 20:08:23 --> Language Class Initialized
ERROR - 2023-09-13 20:08:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:08:24 --> Config Class Initialized
INFO - 2023-09-13 20:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:08:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:08:24 --> URI Class Initialized
INFO - 2023-09-13 20:08:24 --> Router Class Initialized
INFO - 2023-09-13 20:08:24 --> Output Class Initialized
INFO - 2023-09-13 20:08:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:08:24 --> Input Class Initialized
INFO - 2023-09-13 20:08:24 --> Language Class Initialized
ERROR - 2023-09-13 20:08:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:33 --> Config Class Initialized
INFO - 2023-09-13 20:11:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:33 --> URI Class Initialized
INFO - 2023-09-13 20:11:33 --> Router Class Initialized
INFO - 2023-09-13 20:11:33 --> Output Class Initialized
INFO - 2023-09-13 20:11:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:33 --> Input Class Initialized
INFO - 2023-09-13 20:11:33 --> Language Class Initialized
INFO - 2023-09-13 20:11:33 --> Loader Class Initialized
INFO - 2023-09-13 20:11:33 --> Helper loaded: url_helper
INFO - 2023-09-13 20:11:33 --> Helper loaded: file_helper
INFO - 2023-09-13 20:11:33 --> Database Driver Class Initialized
INFO - 2023-09-13 20:11:33 --> Email Class Initialized
DEBUG - 2023-09-13 20:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:11:33 --> Controller Class Initialized
INFO - 2023-09-13 20:11:33 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:11:33 --> Model "Home_model" initialized
INFO - 2023-09-13 20:11:33 --> Helper loaded: download_helper
INFO - 2023-09-13 20:11:33 --> Helper loaded: form_helper
INFO - 2023-09-13 20:11:33 --> Form Validation Class Initialized
INFO - 2023-09-13 20:11:33 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:11:33 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:11:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 20:11:33 --> Final output sent to browser
DEBUG - 2023-09-13 20:11:33 --> Total execution time: 0.1289
INFO - 2023-09-13 20:11:34 --> Config Class Initialized
INFO - 2023-09-13 20:11:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:34 --> URI Class Initialized
INFO - 2023-09-13 20:11:34 --> Router Class Initialized
INFO - 2023-09-13 20:11:34 --> Output Class Initialized
INFO - 2023-09-13 20:11:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:34 --> Input Class Initialized
INFO - 2023-09-13 20:11:34 --> Language Class Initialized
ERROR - 2023-09-13 20:11:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:34 --> Config Class Initialized
INFO - 2023-09-13 20:11:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:34 --> URI Class Initialized
INFO - 2023-09-13 20:11:34 --> Router Class Initialized
INFO - 2023-09-13 20:11:34 --> Output Class Initialized
INFO - 2023-09-13 20:11:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:34 --> Input Class Initialized
INFO - 2023-09-13 20:11:34 --> Language Class Initialized
ERROR - 2023-09-13 20:11:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:36 --> Config Class Initialized
INFO - 2023-09-13 20:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:36 --> URI Class Initialized
INFO - 2023-09-13 20:11:36 --> Router Class Initialized
INFO - 2023-09-13 20:11:36 --> Output Class Initialized
INFO - 2023-09-13 20:11:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:36 --> Input Class Initialized
INFO - 2023-09-13 20:11:36 --> Language Class Initialized
ERROR - 2023-09-13 20:11:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:36 --> Config Class Initialized
INFO - 2023-09-13 20:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:36 --> URI Class Initialized
INFO - 2023-09-13 20:11:36 --> Router Class Initialized
INFO - 2023-09-13 20:11:36 --> Output Class Initialized
INFO - 2023-09-13 20:11:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:36 --> Input Class Initialized
INFO - 2023-09-13 20:11:36 --> Language Class Initialized
ERROR - 2023-09-13 20:11:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:36 --> Config Class Initialized
INFO - 2023-09-13 20:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:36 --> URI Class Initialized
INFO - 2023-09-13 20:11:36 --> Router Class Initialized
INFO - 2023-09-13 20:11:36 --> Output Class Initialized
INFO - 2023-09-13 20:11:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:36 --> Input Class Initialized
INFO - 2023-09-13 20:11:36 --> Language Class Initialized
ERROR - 2023-09-13 20:11:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:36 --> Config Class Initialized
INFO - 2023-09-13 20:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:36 --> URI Class Initialized
INFO - 2023-09-13 20:11:36 --> Router Class Initialized
INFO - 2023-09-13 20:11:36 --> Output Class Initialized
INFO - 2023-09-13 20:11:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:36 --> Input Class Initialized
INFO - 2023-09-13 20:11:36 --> Language Class Initialized
ERROR - 2023-09-13 20:11:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:42 --> Config Class Initialized
INFO - 2023-09-13 20:11:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:42 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:42 --> URI Class Initialized
INFO - 2023-09-13 20:11:42 --> Router Class Initialized
INFO - 2023-09-13 20:11:42 --> Output Class Initialized
INFO - 2023-09-13 20:11:42 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:42 --> Input Class Initialized
INFO - 2023-09-13 20:11:42 --> Language Class Initialized
INFO - 2023-09-13 20:11:42 --> Loader Class Initialized
INFO - 2023-09-13 20:11:42 --> Helper loaded: url_helper
INFO - 2023-09-13 20:11:42 --> Helper loaded: file_helper
INFO - 2023-09-13 20:11:42 --> Database Driver Class Initialized
INFO - 2023-09-13 20:11:42 --> Email Class Initialized
DEBUG - 2023-09-13 20:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:11:42 --> Controller Class Initialized
INFO - 2023-09-13 20:11:42 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:11:42 --> Model "Home_model" initialized
INFO - 2023-09-13 20:11:42 --> Helper loaded: download_helper
INFO - 2023-09-13 20:11:42 --> Helper loaded: form_helper
INFO - 2023-09-13 20:11:42 --> Form Validation Class Initialized
INFO - 2023-09-13 20:11:42 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:11:42 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:11:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 20:11:42 --> Final output sent to browser
DEBUG - 2023-09-13 20:11:42 --> Total execution time: 0.0580
INFO - 2023-09-13 20:11:44 --> Config Class Initialized
INFO - 2023-09-13 20:11:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:44 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:44 --> URI Class Initialized
INFO - 2023-09-13 20:11:44 --> Router Class Initialized
INFO - 2023-09-13 20:11:44 --> Output Class Initialized
INFO - 2023-09-13 20:11:44 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:44 --> Input Class Initialized
INFO - 2023-09-13 20:11:44 --> Language Class Initialized
ERROR - 2023-09-13 20:11:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:44 --> Config Class Initialized
INFO - 2023-09-13 20:11:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:44 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:44 --> URI Class Initialized
INFO - 2023-09-13 20:11:44 --> Router Class Initialized
INFO - 2023-09-13 20:11:44 --> Output Class Initialized
INFO - 2023-09-13 20:11:44 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:44 --> Input Class Initialized
INFO - 2023-09-13 20:11:44 --> Language Class Initialized
ERROR - 2023-09-13 20:11:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:44 --> Config Class Initialized
INFO - 2023-09-13 20:11:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:44 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:44 --> URI Class Initialized
INFO - 2023-09-13 20:11:44 --> Router Class Initialized
INFO - 2023-09-13 20:11:44 --> Output Class Initialized
INFO - 2023-09-13 20:11:44 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:44 --> Input Class Initialized
INFO - 2023-09-13 20:11:44 --> Language Class Initialized
ERROR - 2023-09-13 20:11:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:45 --> Config Class Initialized
INFO - 2023-09-13 20:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:45 --> URI Class Initialized
INFO - 2023-09-13 20:11:45 --> Router Class Initialized
INFO - 2023-09-13 20:11:45 --> Output Class Initialized
INFO - 2023-09-13 20:11:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:45 --> Input Class Initialized
INFO - 2023-09-13 20:11:45 --> Language Class Initialized
ERROR - 2023-09-13 20:11:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:45 --> Config Class Initialized
INFO - 2023-09-13 20:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:45 --> URI Class Initialized
INFO - 2023-09-13 20:11:45 --> Router Class Initialized
INFO - 2023-09-13 20:11:45 --> Output Class Initialized
INFO - 2023-09-13 20:11:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:45 --> Input Class Initialized
INFO - 2023-09-13 20:11:45 --> Language Class Initialized
ERROR - 2023-09-13 20:11:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:45 --> Config Class Initialized
INFO - 2023-09-13 20:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:45 --> URI Class Initialized
INFO - 2023-09-13 20:11:45 --> Router Class Initialized
INFO - 2023-09-13 20:11:45 --> Output Class Initialized
INFO - 2023-09-13 20:11:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:45 --> Input Class Initialized
INFO - 2023-09-13 20:11:45 --> Language Class Initialized
ERROR - 2023-09-13 20:11:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:11:45 --> Config Class Initialized
INFO - 2023-09-13 20:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:11:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:11:45 --> URI Class Initialized
INFO - 2023-09-13 20:11:45 --> Router Class Initialized
INFO - 2023-09-13 20:11:45 --> Output Class Initialized
INFO - 2023-09-13 20:11:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:11:45 --> Input Class Initialized
INFO - 2023-09-13 20:11:45 --> Language Class Initialized
ERROR - 2023-09-13 20:11:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:21 --> Config Class Initialized
INFO - 2023-09-13 20:12:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:21 --> URI Class Initialized
INFO - 2023-09-13 20:12:21 --> Router Class Initialized
INFO - 2023-09-13 20:12:21 --> Output Class Initialized
INFO - 2023-09-13 20:12:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:21 --> Input Class Initialized
INFO - 2023-09-13 20:12:21 --> Language Class Initialized
INFO - 2023-09-13 20:12:21 --> Loader Class Initialized
INFO - 2023-09-13 20:12:21 --> Helper loaded: url_helper
INFO - 2023-09-13 20:12:21 --> Helper loaded: file_helper
INFO - 2023-09-13 20:12:21 --> Database Driver Class Initialized
INFO - 2023-09-13 20:12:21 --> Email Class Initialized
DEBUG - 2023-09-13 20:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:12:21 --> Controller Class Initialized
INFO - 2023-09-13 20:12:21 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:12:21 --> Model "Home_model" initialized
INFO - 2023-09-13 20:12:21 --> Helper loaded: download_helper
INFO - 2023-09-13 20:12:21 --> Helper loaded: form_helper
INFO - 2023-09-13 20:12:21 --> Form Validation Class Initialized
INFO - 2023-09-13 20:12:21 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:12:21 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:12:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 20:12:21 --> Final output sent to browser
DEBUG - 2023-09-13 20:12:21 --> Total execution time: 0.1559
INFO - 2023-09-13 20:12:33 --> Config Class Initialized
INFO - 2023-09-13 20:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:33 --> URI Class Initialized
INFO - 2023-09-13 20:12:33 --> Router Class Initialized
INFO - 2023-09-13 20:12:33 --> Output Class Initialized
INFO - 2023-09-13 20:12:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:33 --> Input Class Initialized
INFO - 2023-09-13 20:12:33 --> Language Class Initialized
ERROR - 2023-09-13 20:12:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:33 --> Config Class Initialized
INFO - 2023-09-13 20:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:33 --> URI Class Initialized
INFO - 2023-09-13 20:12:33 --> Router Class Initialized
INFO - 2023-09-13 20:12:33 --> Output Class Initialized
INFO - 2023-09-13 20:12:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:33 --> Input Class Initialized
INFO - 2023-09-13 20:12:33 --> Language Class Initialized
ERROR - 2023-09-13 20:12:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:33 --> Config Class Initialized
INFO - 2023-09-13 20:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:33 --> URI Class Initialized
INFO - 2023-09-13 20:12:33 --> Router Class Initialized
INFO - 2023-09-13 20:12:33 --> Output Class Initialized
INFO - 2023-09-13 20:12:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:33 --> Input Class Initialized
INFO - 2023-09-13 20:12:33 --> Language Class Initialized
ERROR - 2023-09-13 20:12:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:33 --> Config Class Initialized
INFO - 2023-09-13 20:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:33 --> URI Class Initialized
INFO - 2023-09-13 20:12:33 --> Router Class Initialized
INFO - 2023-09-13 20:12:33 --> Output Class Initialized
INFO - 2023-09-13 20:12:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:33 --> Input Class Initialized
INFO - 2023-09-13 20:12:33 --> Language Class Initialized
ERROR - 2023-09-13 20:12:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:34 --> Config Class Initialized
INFO - 2023-09-13 20:12:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:34 --> URI Class Initialized
INFO - 2023-09-13 20:12:34 --> Router Class Initialized
INFO - 2023-09-13 20:12:34 --> Output Class Initialized
INFO - 2023-09-13 20:12:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:34 --> Input Class Initialized
INFO - 2023-09-13 20:12:34 --> Language Class Initialized
ERROR - 2023-09-13 20:12:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:34 --> Config Class Initialized
INFO - 2023-09-13 20:12:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:34 --> URI Class Initialized
INFO - 2023-09-13 20:12:34 --> Router Class Initialized
INFO - 2023-09-13 20:12:34 --> Output Class Initialized
INFO - 2023-09-13 20:12:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:34 --> Input Class Initialized
INFO - 2023-09-13 20:12:34 --> Language Class Initialized
ERROR - 2023-09-13 20:12:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:12:34 --> Config Class Initialized
INFO - 2023-09-13 20:12:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:12:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:12:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:12:34 --> URI Class Initialized
INFO - 2023-09-13 20:12:34 --> Router Class Initialized
INFO - 2023-09-13 20:12:34 --> Output Class Initialized
INFO - 2023-09-13 20:12:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:12:34 --> Input Class Initialized
INFO - 2023-09-13 20:12:34 --> Language Class Initialized
ERROR - 2023-09-13 20:12:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:13:41 --> Config Class Initialized
INFO - 2023-09-13 20:13:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:13:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:13:41 --> Utf8 Class Initialized
INFO - 2023-09-13 20:13:41 --> URI Class Initialized
INFO - 2023-09-13 20:13:41 --> Router Class Initialized
INFO - 2023-09-13 20:13:41 --> Output Class Initialized
INFO - 2023-09-13 20:13:41 --> Security Class Initialized
DEBUG - 2023-09-13 20:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:13:41 --> Input Class Initialized
INFO - 2023-09-13 20:13:41 --> Language Class Initialized
INFO - 2023-09-13 20:13:41 --> Loader Class Initialized
INFO - 2023-09-13 20:13:41 --> Helper loaded: url_helper
INFO - 2023-09-13 20:13:41 --> Helper loaded: file_helper
INFO - 2023-09-13 20:13:41 --> Database Driver Class Initialized
INFO - 2023-09-13 20:13:41 --> Email Class Initialized
DEBUG - 2023-09-13 20:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:13:41 --> Controller Class Initialized
INFO - 2023-09-13 20:13:41 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:13:41 --> Model "Home_model" initialized
INFO - 2023-09-13 20:13:41 --> Helper loaded: download_helper
INFO - 2023-09-13 20:13:41 --> Helper loaded: form_helper
INFO - 2023-09-13 20:13:41 --> Form Validation Class Initialized
INFO - 2023-09-13 20:13:41 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:13:41 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:13:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-13 20:13:41 --> Final output sent to browser
DEBUG - 2023-09-13 20:13:41 --> Total execution time: 0.0533
INFO - 2023-09-13 20:13:58 --> Config Class Initialized
INFO - 2023-09-13 20:13:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:13:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:13:58 --> Utf8 Class Initialized
INFO - 2023-09-13 20:13:58 --> URI Class Initialized
DEBUG - 2023-09-13 20:13:58 --> No URI present. Default controller set.
INFO - 2023-09-13 20:13:58 --> Router Class Initialized
INFO - 2023-09-13 20:13:58 --> Output Class Initialized
INFO - 2023-09-13 20:13:58 --> Security Class Initialized
DEBUG - 2023-09-13 20:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:13:58 --> Input Class Initialized
INFO - 2023-09-13 20:13:58 --> Language Class Initialized
INFO - 2023-09-13 20:13:58 --> Loader Class Initialized
INFO - 2023-09-13 20:13:58 --> Helper loaded: url_helper
INFO - 2023-09-13 20:13:58 --> Helper loaded: file_helper
INFO - 2023-09-13 20:13:58 --> Database Driver Class Initialized
INFO - 2023-09-13 20:13:58 --> Email Class Initialized
DEBUG - 2023-09-13 20:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:13:58 --> Controller Class Initialized
INFO - 2023-09-13 20:13:58 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:13:58 --> Model "Home_model" initialized
INFO - 2023-09-13 20:13:58 --> Helper loaded: download_helper
INFO - 2023-09-13 20:13:58 --> Helper loaded: form_helper
INFO - 2023-09-13 20:13:58 --> Form Validation Class Initialized
INFO - 2023-09-13 20:13:58 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:13:58 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:13:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:13:58 --> Final output sent to browser
DEBUG - 2023-09-13 20:13:58 --> Total execution time: 0.5488
INFO - 2023-09-13 20:14:09 --> Config Class Initialized
INFO - 2023-09-13 20:14:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:09 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:09 --> URI Class Initialized
INFO - 2023-09-13 20:14:09 --> Router Class Initialized
INFO - 2023-09-13 20:14:09 --> Output Class Initialized
INFO - 2023-09-13 20:14:09 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:09 --> Input Class Initialized
INFO - 2023-09-13 20:14:09 --> Language Class Initialized
ERROR - 2023-09-13 20:14:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:09 --> Config Class Initialized
INFO - 2023-09-13 20:14:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:09 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:09 --> URI Class Initialized
INFO - 2023-09-13 20:14:09 --> Router Class Initialized
INFO - 2023-09-13 20:14:09 --> Output Class Initialized
INFO - 2023-09-13 20:14:09 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:09 --> Input Class Initialized
INFO - 2023-09-13 20:14:09 --> Language Class Initialized
ERROR - 2023-09-13 20:14:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:10 --> Config Class Initialized
INFO - 2023-09-13 20:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:10 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:10 --> URI Class Initialized
INFO - 2023-09-13 20:14:10 --> Router Class Initialized
INFO - 2023-09-13 20:14:10 --> Output Class Initialized
INFO - 2023-09-13 20:14:10 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:10 --> Input Class Initialized
INFO - 2023-09-13 20:14:10 --> Language Class Initialized
ERROR - 2023-09-13 20:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:10 --> Config Class Initialized
INFO - 2023-09-13 20:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:10 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:10 --> URI Class Initialized
INFO - 2023-09-13 20:14:10 --> Router Class Initialized
INFO - 2023-09-13 20:14:10 --> Output Class Initialized
INFO - 2023-09-13 20:14:10 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:10 --> Input Class Initialized
INFO - 2023-09-13 20:14:10 --> Language Class Initialized
ERROR - 2023-09-13 20:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:10 --> Config Class Initialized
INFO - 2023-09-13 20:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:10 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:10 --> URI Class Initialized
INFO - 2023-09-13 20:14:10 --> Router Class Initialized
INFO - 2023-09-13 20:14:10 --> Output Class Initialized
INFO - 2023-09-13 20:14:10 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:10 --> Input Class Initialized
INFO - 2023-09-13 20:14:10 --> Language Class Initialized
ERROR - 2023-09-13 20:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:10 --> Config Class Initialized
INFO - 2023-09-13 20:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:10 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:10 --> URI Class Initialized
INFO - 2023-09-13 20:14:10 --> Router Class Initialized
INFO - 2023-09-13 20:14:10 --> Output Class Initialized
INFO - 2023-09-13 20:14:10 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:10 --> Input Class Initialized
INFO - 2023-09-13 20:14:10 --> Language Class Initialized
ERROR - 2023-09-13 20:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:14:10 --> Config Class Initialized
INFO - 2023-09-13 20:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:14:10 --> Utf8 Class Initialized
INFO - 2023-09-13 20:14:10 --> URI Class Initialized
INFO - 2023-09-13 20:14:10 --> Router Class Initialized
INFO - 2023-09-13 20:14:10 --> Output Class Initialized
INFO - 2023-09-13 20:14:10 --> Security Class Initialized
DEBUG - 2023-09-13 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:14:10 --> Input Class Initialized
INFO - 2023-09-13 20:14:10 --> Language Class Initialized
ERROR - 2023-09-13 20:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:05 --> Config Class Initialized
INFO - 2023-09-13 20:15:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:05 --> URI Class Initialized
DEBUG - 2023-09-13 20:15:05 --> No URI present. Default controller set.
INFO - 2023-09-13 20:15:05 --> Router Class Initialized
INFO - 2023-09-13 20:15:05 --> Output Class Initialized
INFO - 2023-09-13 20:15:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:05 --> Input Class Initialized
INFO - 2023-09-13 20:15:05 --> Language Class Initialized
INFO - 2023-09-13 20:15:05 --> Loader Class Initialized
INFO - 2023-09-13 20:15:05 --> Helper loaded: url_helper
INFO - 2023-09-13 20:15:05 --> Helper loaded: file_helper
INFO - 2023-09-13 20:15:05 --> Database Driver Class Initialized
INFO - 2023-09-13 20:15:05 --> Email Class Initialized
DEBUG - 2023-09-13 20:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:15:05 --> Controller Class Initialized
INFO - 2023-09-13 20:15:05 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:15:05 --> Model "Home_model" initialized
INFO - 2023-09-13 20:15:05 --> Helper loaded: download_helper
INFO - 2023-09-13 20:15:05 --> Helper loaded: form_helper
INFO - 2023-09-13 20:15:05 --> Form Validation Class Initialized
INFO - 2023-09-13 20:15:05 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:15:05 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:15:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:15:05 --> Final output sent to browser
DEBUG - 2023-09-13 20:15:05 --> Total execution time: 0.0581
INFO - 2023-09-13 20:15:20 --> Config Class Initialized
INFO - 2023-09-13 20:15:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:20 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:20 --> URI Class Initialized
INFO - 2023-09-13 20:15:20 --> Router Class Initialized
INFO - 2023-09-13 20:15:20 --> Output Class Initialized
INFO - 2023-09-13 20:15:20 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:20 --> Input Class Initialized
INFO - 2023-09-13 20:15:20 --> Language Class Initialized
ERROR - 2023-09-13 20:15:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:21 --> Config Class Initialized
INFO - 2023-09-13 20:15:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:21 --> URI Class Initialized
INFO - 2023-09-13 20:15:21 --> Router Class Initialized
INFO - 2023-09-13 20:15:21 --> Output Class Initialized
INFO - 2023-09-13 20:15:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:21 --> Input Class Initialized
INFO - 2023-09-13 20:15:21 --> Language Class Initialized
ERROR - 2023-09-13 20:15:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:21 --> Config Class Initialized
INFO - 2023-09-13 20:15:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:21 --> URI Class Initialized
INFO - 2023-09-13 20:15:21 --> Router Class Initialized
INFO - 2023-09-13 20:15:21 --> Output Class Initialized
INFO - 2023-09-13 20:15:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:21 --> Input Class Initialized
INFO - 2023-09-13 20:15:21 --> Language Class Initialized
ERROR - 2023-09-13 20:15:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:22 --> Config Class Initialized
INFO - 2023-09-13 20:15:22 --> Config Class Initialized
INFO - 2023-09-13 20:15:22 --> Hooks Class Initialized
INFO - 2023-09-13 20:15:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:22 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:22 --> URI Class Initialized
INFO - 2023-09-13 20:15:22 --> Router Class Initialized
INFO - 2023-09-13 20:15:22 --> Output Class Initialized
INFO - 2023-09-13 20:15:22 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:23 --> URI Class Initialized
INFO - 2023-09-13 20:15:23 --> Router Class Initialized
INFO - 2023-09-13 20:15:23 --> Output Class Initialized
INFO - 2023-09-13 20:15:23 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:23 --> Input Class Initialized
INFO - 2023-09-13 20:15:23 --> Language Class Initialized
ERROR - 2023-09-13 20:15:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:23 --> Input Class Initialized
INFO - 2023-09-13 20:15:23 --> Language Class Initialized
ERROR - 2023-09-13 20:15:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:23 --> Config Class Initialized
INFO - 2023-09-13 20:15:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:23 --> URI Class Initialized
INFO - 2023-09-13 20:15:23 --> Router Class Initialized
INFO - 2023-09-13 20:15:23 --> Output Class Initialized
INFO - 2023-09-13 20:15:23 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:23 --> Input Class Initialized
INFO - 2023-09-13 20:15:23 --> Language Class Initialized
ERROR - 2023-09-13 20:15:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:15:23 --> Config Class Initialized
INFO - 2023-09-13 20:15:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:15:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:15:23 --> URI Class Initialized
INFO - 2023-09-13 20:15:24 --> Router Class Initialized
INFO - 2023-09-13 20:15:24 --> Output Class Initialized
INFO - 2023-09-13 20:15:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:15:24 --> Input Class Initialized
INFO - 2023-09-13 20:15:24 --> Language Class Initialized
ERROR - 2023-09-13 20:15:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:32 --> Config Class Initialized
INFO - 2023-09-13 20:16:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:32 --> URI Class Initialized
DEBUG - 2023-09-13 20:16:32 --> No URI present. Default controller set.
INFO - 2023-09-13 20:16:32 --> Router Class Initialized
INFO - 2023-09-13 20:16:32 --> Output Class Initialized
INFO - 2023-09-13 20:16:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:32 --> Input Class Initialized
INFO - 2023-09-13 20:16:32 --> Language Class Initialized
INFO - 2023-09-13 20:16:32 --> Loader Class Initialized
INFO - 2023-09-13 20:16:32 --> Helper loaded: url_helper
INFO - 2023-09-13 20:16:32 --> Helper loaded: file_helper
INFO - 2023-09-13 20:16:32 --> Database Driver Class Initialized
INFO - 2023-09-13 20:16:32 --> Email Class Initialized
DEBUG - 2023-09-13 20:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:16:32 --> Controller Class Initialized
INFO - 2023-09-13 20:16:32 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:16:32 --> Model "Home_model" initialized
INFO - 2023-09-13 20:16:32 --> Helper loaded: download_helper
INFO - 2023-09-13 20:16:32 --> Helper loaded: form_helper
INFO - 2023-09-13 20:16:32 --> Form Validation Class Initialized
INFO - 2023-09-13 20:16:32 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:16:32 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:16:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:16:32 --> Final output sent to browser
DEBUG - 2023-09-13 20:16:32 --> Total execution time: 0.2564
INFO - 2023-09-13 20:16:35 --> Config Class Initialized
INFO - 2023-09-13 20:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:35 --> URI Class Initialized
INFO - 2023-09-13 20:16:35 --> Router Class Initialized
INFO - 2023-09-13 20:16:35 --> Output Class Initialized
INFO - 2023-09-13 20:16:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:35 --> Input Class Initialized
INFO - 2023-09-13 20:16:35 --> Language Class Initialized
ERROR - 2023-09-13 20:16:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:35 --> Config Class Initialized
INFO - 2023-09-13 20:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:35 --> URI Class Initialized
INFO - 2023-09-13 20:16:35 --> Router Class Initialized
INFO - 2023-09-13 20:16:35 --> Output Class Initialized
INFO - 2023-09-13 20:16:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:35 --> Input Class Initialized
INFO - 2023-09-13 20:16:35 --> Language Class Initialized
ERROR - 2023-09-13 20:16:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:35 --> Config Class Initialized
INFO - 2023-09-13 20:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:35 --> URI Class Initialized
INFO - 2023-09-13 20:16:35 --> Router Class Initialized
INFO - 2023-09-13 20:16:35 --> Output Class Initialized
INFO - 2023-09-13 20:16:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:35 --> Input Class Initialized
INFO - 2023-09-13 20:16:35 --> Language Class Initialized
ERROR - 2023-09-13 20:16:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:35 --> Config Class Initialized
INFO - 2023-09-13 20:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:35 --> URI Class Initialized
INFO - 2023-09-13 20:16:35 --> Router Class Initialized
INFO - 2023-09-13 20:16:35 --> Output Class Initialized
INFO - 2023-09-13 20:16:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:35 --> Input Class Initialized
INFO - 2023-09-13 20:16:35 --> Language Class Initialized
ERROR - 2023-09-13 20:16:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:35 --> Config Class Initialized
INFO - 2023-09-13 20:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:35 --> URI Class Initialized
INFO - 2023-09-13 20:16:35 --> Router Class Initialized
INFO - 2023-09-13 20:16:35 --> Output Class Initialized
INFO - 2023-09-13 20:16:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:35 --> Input Class Initialized
INFO - 2023-09-13 20:16:35 --> Language Class Initialized
ERROR - 2023-09-13 20:16:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:16:36 --> Config Class Initialized
INFO - 2023-09-13 20:16:36 --> Hooks Class Initialized
INFO - 2023-09-13 20:16:37 --> Config Class Initialized
INFO - 2023-09-13 20:16:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:37 --> URI Class Initialized
INFO - 2023-09-13 20:16:37 --> Router Class Initialized
INFO - 2023-09-13 20:16:37 --> Output Class Initialized
INFO - 2023-09-13 20:16:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:37 --> Input Class Initialized
INFO - 2023-09-13 20:16:37 --> Language Class Initialized
ERROR - 2023-09-13 20:16:37 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-13 20:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:16:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:16:37 --> URI Class Initialized
INFO - 2023-09-13 20:16:37 --> Router Class Initialized
INFO - 2023-09-13 20:16:37 --> Output Class Initialized
INFO - 2023-09-13 20:16:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:16:37 --> Input Class Initialized
INFO - 2023-09-13 20:16:37 --> Language Class Initialized
ERROR - 2023-09-13 20:16:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:05 --> Config Class Initialized
INFO - 2023-09-13 20:20:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:05 --> URI Class Initialized
INFO - 2023-09-13 20:20:05 --> Router Class Initialized
INFO - 2023-09-13 20:20:05 --> Output Class Initialized
INFO - 2023-09-13 20:20:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:05 --> Input Class Initialized
INFO - 2023-09-13 20:20:05 --> Language Class Initialized
ERROR - 2023-09-13 20:20:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:05 --> Config Class Initialized
INFO - 2023-09-13 20:20:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:05 --> URI Class Initialized
INFO - 2023-09-13 20:20:05 --> Router Class Initialized
INFO - 2023-09-13 20:20:05 --> Output Class Initialized
INFO - 2023-09-13 20:20:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:05 --> Input Class Initialized
INFO - 2023-09-13 20:20:05 --> Language Class Initialized
ERROR - 2023-09-13 20:20:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:05 --> Config Class Initialized
INFO - 2023-09-13 20:20:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:05 --> URI Class Initialized
INFO - 2023-09-13 20:20:05 --> Router Class Initialized
INFO - 2023-09-13 20:20:05 --> Output Class Initialized
INFO - 2023-09-13 20:20:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:05 --> Input Class Initialized
INFO - 2023-09-13 20:20:05 --> Language Class Initialized
ERROR - 2023-09-13 20:20:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:05 --> Config Class Initialized
INFO - 2023-09-13 20:20:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:05 --> URI Class Initialized
INFO - 2023-09-13 20:20:05 --> Router Class Initialized
INFO - 2023-09-13 20:20:05 --> Output Class Initialized
INFO - 2023-09-13 20:20:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:05 --> Input Class Initialized
INFO - 2023-09-13 20:20:05 --> Language Class Initialized
ERROR - 2023-09-13 20:20:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:06 --> Config Class Initialized
INFO - 2023-09-13 20:20:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:06 --> URI Class Initialized
INFO - 2023-09-13 20:20:06 --> Router Class Initialized
INFO - 2023-09-13 20:20:06 --> Output Class Initialized
INFO - 2023-09-13 20:20:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:06 --> Input Class Initialized
INFO - 2023-09-13 20:20:06 --> Language Class Initialized
ERROR - 2023-09-13 20:20:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:06 --> Config Class Initialized
INFO - 2023-09-13 20:20:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:06 --> URI Class Initialized
INFO - 2023-09-13 20:20:06 --> Router Class Initialized
INFO - 2023-09-13 20:20:06 --> Output Class Initialized
INFO - 2023-09-13 20:20:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:06 --> Input Class Initialized
INFO - 2023-09-13 20:20:06 --> Language Class Initialized
ERROR - 2023-09-13 20:20:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:06 --> Config Class Initialized
INFO - 2023-09-13 20:20:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:06 --> URI Class Initialized
INFO - 2023-09-13 20:20:06 --> Router Class Initialized
INFO - 2023-09-13 20:20:06 --> Output Class Initialized
INFO - 2023-09-13 20:20:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:06 --> Input Class Initialized
INFO - 2023-09-13 20:20:06 --> Language Class Initialized
ERROR - 2023-09-13 20:20:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:48 --> Config Class Initialized
INFO - 2023-09-13 20:20:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:48 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:48 --> URI Class Initialized
DEBUG - 2023-09-13 20:20:48 --> No URI present. Default controller set.
INFO - 2023-09-13 20:20:48 --> Router Class Initialized
INFO - 2023-09-13 20:20:48 --> Output Class Initialized
INFO - 2023-09-13 20:20:48 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:48 --> Input Class Initialized
INFO - 2023-09-13 20:20:48 --> Language Class Initialized
INFO - 2023-09-13 20:20:48 --> Loader Class Initialized
INFO - 2023-09-13 20:20:48 --> Helper loaded: url_helper
INFO - 2023-09-13 20:20:48 --> Helper loaded: file_helper
INFO - 2023-09-13 20:20:48 --> Database Driver Class Initialized
INFO - 2023-09-13 20:20:48 --> Email Class Initialized
DEBUG - 2023-09-13 20:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:20:48 --> Controller Class Initialized
INFO - 2023-09-13 20:20:48 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:20:48 --> Model "Home_model" initialized
INFO - 2023-09-13 20:20:48 --> Helper loaded: download_helper
INFO - 2023-09-13 20:20:48 --> Helper loaded: form_helper
INFO - 2023-09-13 20:20:48 --> Form Validation Class Initialized
INFO - 2023-09-13 20:20:48 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:20:48 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:20:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:20:48 --> Final output sent to browser
DEBUG - 2023-09-13 20:20:48 --> Total execution time: 0.1425
INFO - 2023-09-13 20:20:50 --> Config Class Initialized
INFO - 2023-09-13 20:20:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:50 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:50 --> URI Class Initialized
INFO - 2023-09-13 20:20:50 --> Router Class Initialized
INFO - 2023-09-13 20:20:50 --> Output Class Initialized
INFO - 2023-09-13 20:20:50 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:50 --> Config Class Initialized
INFO - 2023-09-13 20:20:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:20:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:20:50 --> Utf8 Class Initialized
INFO - 2023-09-13 20:20:50 --> URI Class Initialized
INFO - 2023-09-13 20:20:50 --> Router Class Initialized
INFO - 2023-09-13 20:20:50 --> Output Class Initialized
INFO - 2023-09-13 20:20:50 --> Security Class Initialized
DEBUG - 2023-09-13 20:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:20:50 --> Input Class Initialized
INFO - 2023-09-13 20:20:50 --> Language Class Initialized
ERROR - 2023-09-13 20:20:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:20:50 --> Input Class Initialized
INFO - 2023-09-13 20:20:50 --> Language Class Initialized
ERROR - 2023-09-13 20:20:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:13 --> Config Class Initialized
INFO - 2023-09-13 20:21:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:13 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:13 --> URI Class Initialized
INFO - 2023-09-13 20:21:13 --> Router Class Initialized
INFO - 2023-09-13 20:21:13 --> Output Class Initialized
INFO - 2023-09-13 20:21:13 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:13 --> Input Class Initialized
INFO - 2023-09-13 20:21:13 --> Language Class Initialized
ERROR - 2023-09-13 20:21:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:14 --> Config Class Initialized
INFO - 2023-09-13 20:21:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:14 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:14 --> URI Class Initialized
INFO - 2023-09-13 20:21:14 --> Router Class Initialized
INFO - 2023-09-13 20:21:14 --> Output Class Initialized
INFO - 2023-09-13 20:21:14 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:14 --> Input Class Initialized
INFO - 2023-09-13 20:21:14 --> Language Class Initialized
ERROR - 2023-09-13 20:21:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:14 --> Config Class Initialized
INFO - 2023-09-13 20:21:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:15 --> URI Class Initialized
INFO - 2023-09-13 20:21:15 --> Router Class Initialized
INFO - 2023-09-13 20:21:15 --> Output Class Initialized
INFO - 2023-09-13 20:21:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:15 --> Input Class Initialized
INFO - 2023-09-13 20:21:15 --> Language Class Initialized
ERROR - 2023-09-13 20:21:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:15 --> Config Class Initialized
INFO - 2023-09-13 20:21:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:15 --> URI Class Initialized
INFO - 2023-09-13 20:21:15 --> Router Class Initialized
INFO - 2023-09-13 20:21:16 --> Output Class Initialized
INFO - 2023-09-13 20:21:16 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:16 --> Input Class Initialized
INFO - 2023-09-13 20:21:16 --> Language Class Initialized
ERROR - 2023-09-13 20:21:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:16 --> Config Class Initialized
INFO - 2023-09-13 20:21:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:16 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:16 --> URI Class Initialized
INFO - 2023-09-13 20:21:16 --> Router Class Initialized
INFO - 2023-09-13 20:21:16 --> Output Class Initialized
INFO - 2023-09-13 20:21:16 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:16 --> Input Class Initialized
INFO - 2023-09-13 20:21:16 --> Language Class Initialized
ERROR - 2023-09-13 20:21:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:17 --> Config Class Initialized
INFO - 2023-09-13 20:21:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:17 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:17 --> URI Class Initialized
INFO - 2023-09-13 20:21:17 --> Router Class Initialized
INFO - 2023-09-13 20:21:17 --> Output Class Initialized
INFO - 2023-09-13 20:21:17 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:17 --> Input Class Initialized
INFO - 2023-09-13 20:21:17 --> Language Class Initialized
ERROR - 2023-09-13 20:21:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:21:17 --> Config Class Initialized
INFO - 2023-09-13 20:21:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:21:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:21:17 --> Utf8 Class Initialized
INFO - 2023-09-13 20:21:17 --> URI Class Initialized
INFO - 2023-09-13 20:21:17 --> Router Class Initialized
INFO - 2023-09-13 20:21:17 --> Output Class Initialized
INFO - 2023-09-13 20:21:17 --> Security Class Initialized
DEBUG - 2023-09-13 20:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:21:17 --> Input Class Initialized
INFO - 2023-09-13 20:21:17 --> Language Class Initialized
ERROR - 2023-09-13 20:21:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:19 --> Config Class Initialized
INFO - 2023-09-13 20:23:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:19 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:19 --> URI Class Initialized
DEBUG - 2023-09-13 20:23:19 --> No URI present. Default controller set.
INFO - 2023-09-13 20:23:19 --> Router Class Initialized
INFO - 2023-09-13 20:23:19 --> Output Class Initialized
INFO - 2023-09-13 20:23:19 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:19 --> Input Class Initialized
INFO - 2023-09-13 20:23:19 --> Language Class Initialized
INFO - 2023-09-13 20:23:19 --> Loader Class Initialized
INFO - 2023-09-13 20:23:19 --> Helper loaded: url_helper
INFO - 2023-09-13 20:23:19 --> Helper loaded: file_helper
INFO - 2023-09-13 20:23:19 --> Database Driver Class Initialized
INFO - 2023-09-13 20:23:19 --> Email Class Initialized
DEBUG - 2023-09-13 20:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:23:19 --> Controller Class Initialized
INFO - 2023-09-13 20:23:19 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:23:19 --> Model "Home_model" initialized
INFO - 2023-09-13 20:23:19 --> Helper loaded: download_helper
INFO - 2023-09-13 20:23:19 --> Helper loaded: form_helper
INFO - 2023-09-13 20:23:19 --> Form Validation Class Initialized
INFO - 2023-09-13 20:23:19 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:23:19 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:23:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:23:19 --> Final output sent to browser
DEBUG - 2023-09-13 20:23:19 --> Total execution time: 0.1060
INFO - 2023-09-13 20:23:32 --> Config Class Initialized
INFO - 2023-09-13 20:23:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:32 --> URI Class Initialized
INFO - 2023-09-13 20:23:32 --> Router Class Initialized
INFO - 2023-09-13 20:23:32 --> Output Class Initialized
INFO - 2023-09-13 20:23:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:32 --> Input Class Initialized
INFO - 2023-09-13 20:23:32 --> Language Class Initialized
ERROR - 2023-09-13 20:23:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:32 --> Config Class Initialized
INFO - 2023-09-13 20:23:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:32 --> URI Class Initialized
INFO - 2023-09-13 20:23:32 --> Router Class Initialized
INFO - 2023-09-13 20:23:32 --> Output Class Initialized
INFO - 2023-09-13 20:23:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:32 --> Input Class Initialized
INFO - 2023-09-13 20:23:32 --> Language Class Initialized
ERROR - 2023-09-13 20:23:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:32 --> Config Class Initialized
INFO - 2023-09-13 20:23:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:32 --> URI Class Initialized
INFO - 2023-09-13 20:23:32 --> Router Class Initialized
INFO - 2023-09-13 20:23:32 --> Output Class Initialized
INFO - 2023-09-13 20:23:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:32 --> Input Class Initialized
INFO - 2023-09-13 20:23:32 --> Language Class Initialized
ERROR - 2023-09-13 20:23:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:33 --> Config Class Initialized
INFO - 2023-09-13 20:23:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:33 --> URI Class Initialized
INFO - 2023-09-13 20:23:34 --> Router Class Initialized
INFO - 2023-09-13 20:23:34 --> Output Class Initialized
INFO - 2023-09-13 20:23:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:34 --> Input Class Initialized
INFO - 2023-09-13 20:23:34 --> Language Class Initialized
ERROR - 2023-09-13 20:23:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:34 --> Config Class Initialized
INFO - 2023-09-13 20:23:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:34 --> URI Class Initialized
INFO - 2023-09-13 20:23:34 --> Router Class Initialized
INFO - 2023-09-13 20:23:34 --> Output Class Initialized
INFO - 2023-09-13 20:23:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:34 --> Input Class Initialized
INFO - 2023-09-13 20:23:34 --> Language Class Initialized
ERROR - 2023-09-13 20:23:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:35 --> Config Class Initialized
INFO - 2023-09-13 20:23:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:35 --> URI Class Initialized
INFO - 2023-09-13 20:23:35 --> Router Class Initialized
INFO - 2023-09-13 20:23:35 --> Output Class Initialized
INFO - 2023-09-13 20:23:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:35 --> Input Class Initialized
INFO - 2023-09-13 20:23:35 --> Language Class Initialized
ERROR - 2023-09-13 20:23:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:23:36 --> Config Class Initialized
INFO - 2023-09-13 20:23:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:23:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:23:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:23:36 --> URI Class Initialized
INFO - 2023-09-13 20:23:36 --> Router Class Initialized
INFO - 2023-09-13 20:23:36 --> Output Class Initialized
INFO - 2023-09-13 20:23:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:23:36 --> Input Class Initialized
INFO - 2023-09-13 20:23:36 --> Language Class Initialized
ERROR - 2023-09-13 20:23:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:12 --> Config Class Initialized
INFO - 2023-09-13 20:24:12 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:12 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:12 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:12 --> URI Class Initialized
DEBUG - 2023-09-13 20:24:12 --> No URI present. Default controller set.
INFO - 2023-09-13 20:24:12 --> Router Class Initialized
INFO - 2023-09-13 20:24:12 --> Output Class Initialized
INFO - 2023-09-13 20:24:12 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:12 --> Input Class Initialized
INFO - 2023-09-13 20:24:12 --> Language Class Initialized
INFO - 2023-09-13 20:24:12 --> Loader Class Initialized
INFO - 2023-09-13 20:24:12 --> Helper loaded: url_helper
INFO - 2023-09-13 20:24:12 --> Helper loaded: file_helper
INFO - 2023-09-13 20:24:12 --> Database Driver Class Initialized
INFO - 2023-09-13 20:24:12 --> Email Class Initialized
DEBUG - 2023-09-13 20:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:24:12 --> Controller Class Initialized
INFO - 2023-09-13 20:24:12 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:24:12 --> Model "Home_model" initialized
INFO - 2023-09-13 20:24:12 --> Helper loaded: download_helper
INFO - 2023-09-13 20:24:12 --> Helper loaded: form_helper
INFO - 2023-09-13 20:24:12 --> Form Validation Class Initialized
INFO - 2023-09-13 20:24:12 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:24:12 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:24:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:24:12 --> Final output sent to browser
DEBUG - 2023-09-13 20:24:12 --> Total execution time: 0.4969
INFO - 2023-09-13 20:24:15 --> Config Class Initialized
INFO - 2023-09-13 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:15 --> URI Class Initialized
INFO - 2023-09-13 20:24:15 --> Router Class Initialized
INFO - 2023-09-13 20:24:15 --> Output Class Initialized
INFO - 2023-09-13 20:24:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:15 --> Input Class Initialized
INFO - 2023-09-13 20:24:15 --> Language Class Initialized
ERROR - 2023-09-13 20:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:15 --> Config Class Initialized
INFO - 2023-09-13 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:15 --> URI Class Initialized
INFO - 2023-09-13 20:24:15 --> Router Class Initialized
INFO - 2023-09-13 20:24:15 --> Output Class Initialized
INFO - 2023-09-13 20:24:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:15 --> Input Class Initialized
INFO - 2023-09-13 20:24:15 --> Language Class Initialized
ERROR - 2023-09-13 20:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:15 --> Config Class Initialized
INFO - 2023-09-13 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:15 --> URI Class Initialized
INFO - 2023-09-13 20:24:15 --> Router Class Initialized
INFO - 2023-09-13 20:24:15 --> Output Class Initialized
INFO - 2023-09-13 20:24:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:15 --> Input Class Initialized
INFO - 2023-09-13 20:24:15 --> Language Class Initialized
ERROR - 2023-09-13 20:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:15 --> Config Class Initialized
INFO - 2023-09-13 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:15 --> URI Class Initialized
INFO - 2023-09-13 20:24:15 --> Router Class Initialized
INFO - 2023-09-13 20:24:15 --> Output Class Initialized
INFO - 2023-09-13 20:24:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:15 --> Input Class Initialized
INFO - 2023-09-13 20:24:15 --> Language Class Initialized
ERROR - 2023-09-13 20:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:15 --> Config Class Initialized
INFO - 2023-09-13 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:15 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:15 --> URI Class Initialized
INFO - 2023-09-13 20:24:15 --> Router Class Initialized
INFO - 2023-09-13 20:24:15 --> Output Class Initialized
INFO - 2023-09-13 20:24:15 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:15 --> Input Class Initialized
INFO - 2023-09-13 20:24:15 --> Language Class Initialized
ERROR - 2023-09-13 20:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:17 --> Config Class Initialized
INFO - 2023-09-13 20:24:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:17 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:17 --> URI Class Initialized
INFO - 2023-09-13 20:24:17 --> Router Class Initialized
INFO - 2023-09-13 20:24:17 --> Output Class Initialized
INFO - 2023-09-13 20:24:17 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:17 --> Input Class Initialized
INFO - 2023-09-13 20:24:17 --> Language Class Initialized
ERROR - 2023-09-13 20:24:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:17 --> Config Class Initialized
INFO - 2023-09-13 20:24:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:17 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:17 --> URI Class Initialized
INFO - 2023-09-13 20:24:17 --> Router Class Initialized
INFO - 2023-09-13 20:24:17 --> Output Class Initialized
INFO - 2023-09-13 20:24:17 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:17 --> Input Class Initialized
INFO - 2023-09-13 20:24:17 --> Language Class Initialized
ERROR - 2023-09-13 20:24:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:41 --> Config Class Initialized
INFO - 2023-09-13 20:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:41 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:41 --> URI Class Initialized
INFO - 2023-09-13 20:24:41 --> Router Class Initialized
INFO - 2023-09-13 20:24:41 --> Output Class Initialized
INFO - 2023-09-13 20:24:41 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:41 --> Input Class Initialized
INFO - 2023-09-13 20:24:41 --> Language Class Initialized
ERROR - 2023-09-13 20:24:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:41 --> Config Class Initialized
INFO - 2023-09-13 20:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:41 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:41 --> URI Class Initialized
INFO - 2023-09-13 20:24:41 --> Router Class Initialized
INFO - 2023-09-13 20:24:41 --> Output Class Initialized
INFO - 2023-09-13 20:24:41 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:42 --> Config Class Initialized
INFO - 2023-09-13 20:24:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:42 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:42 --> URI Class Initialized
INFO - 2023-09-13 20:24:42 --> Router Class Initialized
INFO - 2023-09-13 20:24:42 --> Output Class Initialized
INFO - 2023-09-13 20:24:42 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:42 --> Input Class Initialized
INFO - 2023-09-13 20:24:42 --> Language Class Initialized
ERROR - 2023-09-13 20:24:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:42 --> Input Class Initialized
INFO - 2023-09-13 20:24:42 --> Language Class Initialized
ERROR - 2023-09-13 20:24:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:43 --> Config Class Initialized
INFO - 2023-09-13 20:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:43 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:43 --> URI Class Initialized
INFO - 2023-09-13 20:24:43 --> Router Class Initialized
INFO - 2023-09-13 20:24:43 --> Output Class Initialized
INFO - 2023-09-13 20:24:43 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:43 --> Input Class Initialized
INFO - 2023-09-13 20:24:43 --> Language Class Initialized
ERROR - 2023-09-13 20:24:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:43 --> Config Class Initialized
INFO - 2023-09-13 20:24:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:44 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:44 --> URI Class Initialized
INFO - 2023-09-13 20:24:44 --> Router Class Initialized
INFO - 2023-09-13 20:24:44 --> Output Class Initialized
INFO - 2023-09-13 20:24:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:45 --> Input Class Initialized
INFO - 2023-09-13 20:24:45 --> Language Class Initialized
ERROR - 2023-09-13 20:24:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:45 --> Config Class Initialized
INFO - 2023-09-13 20:24:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:45 --> URI Class Initialized
INFO - 2023-09-13 20:24:45 --> Router Class Initialized
INFO - 2023-09-13 20:24:45 --> Output Class Initialized
INFO - 2023-09-13 20:24:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:45 --> Input Class Initialized
INFO - 2023-09-13 20:24:45 --> Language Class Initialized
ERROR - 2023-09-13 20:24:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:24:45 --> Config Class Initialized
INFO - 2023-09-13 20:24:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:24:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:24:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:24:45 --> URI Class Initialized
INFO - 2023-09-13 20:24:45 --> Router Class Initialized
INFO - 2023-09-13 20:24:45 --> Output Class Initialized
INFO - 2023-09-13 20:24:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:24:45 --> Input Class Initialized
INFO - 2023-09-13 20:24:45 --> Language Class Initialized
ERROR - 2023-09-13 20:24:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:18 --> Config Class Initialized
INFO - 2023-09-13 20:25:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:18 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:18 --> URI Class Initialized
DEBUG - 2023-09-13 20:25:18 --> No URI present. Default controller set.
INFO - 2023-09-13 20:25:18 --> Router Class Initialized
INFO - 2023-09-13 20:25:18 --> Output Class Initialized
INFO - 2023-09-13 20:25:18 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:18 --> Input Class Initialized
INFO - 2023-09-13 20:25:18 --> Language Class Initialized
INFO - 2023-09-13 20:25:18 --> Loader Class Initialized
INFO - 2023-09-13 20:25:18 --> Helper loaded: url_helper
INFO - 2023-09-13 20:25:18 --> Helper loaded: file_helper
INFO - 2023-09-13 20:25:18 --> Database Driver Class Initialized
INFO - 2023-09-13 20:25:18 --> Email Class Initialized
DEBUG - 2023-09-13 20:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:25:18 --> Controller Class Initialized
INFO - 2023-09-13 20:25:18 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:25:18 --> Model "Home_model" initialized
INFO - 2023-09-13 20:25:18 --> Helper loaded: download_helper
INFO - 2023-09-13 20:25:18 --> Helper loaded: form_helper
INFO - 2023-09-13 20:25:18 --> Form Validation Class Initialized
INFO - 2023-09-13 20:25:18 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:25:18 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:25:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:25:18 --> Final output sent to browser
DEBUG - 2023-09-13 20:25:18 --> Total execution time: 0.1008
INFO - 2023-09-13 20:25:21 --> Config Class Initialized
INFO - 2023-09-13 20:25:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:21 --> URI Class Initialized
INFO - 2023-09-13 20:25:21 --> Router Class Initialized
INFO - 2023-09-13 20:25:21 --> Output Class Initialized
INFO - 2023-09-13 20:25:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:21 --> Input Class Initialized
INFO - 2023-09-13 20:25:21 --> Language Class Initialized
ERROR - 2023-09-13 20:25:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:21 --> Config Class Initialized
INFO - 2023-09-13 20:25:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:21 --> URI Class Initialized
INFO - 2023-09-13 20:25:21 --> Router Class Initialized
INFO - 2023-09-13 20:25:21 --> Output Class Initialized
INFO - 2023-09-13 20:25:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:21 --> Input Class Initialized
INFO - 2023-09-13 20:25:21 --> Language Class Initialized
ERROR - 2023-09-13 20:25:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:25 --> Config Class Initialized
INFO - 2023-09-13 20:25:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:25 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:25 --> URI Class Initialized
INFO - 2023-09-13 20:25:25 --> Router Class Initialized
INFO - 2023-09-13 20:25:25 --> Output Class Initialized
INFO - 2023-09-13 20:25:25 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:25 --> Input Class Initialized
INFO - 2023-09-13 20:25:25 --> Language Class Initialized
ERROR - 2023-09-13 20:25:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:26 --> Config Class Initialized
INFO - 2023-09-13 20:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:26 --> URI Class Initialized
INFO - 2023-09-13 20:25:26 --> Router Class Initialized
INFO - 2023-09-13 20:25:26 --> Output Class Initialized
INFO - 2023-09-13 20:25:26 --> Security Class Initialized
INFO - 2023-09-13 20:25:26 --> Config Class Initialized
INFO - 2023-09-13 20:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:26 --> URI Class Initialized
INFO - 2023-09-13 20:25:26 --> Router Class Initialized
INFO - 2023-09-13 20:25:26 --> Output Class Initialized
INFO - 2023-09-13 20:25:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:26 --> Input Class Initialized
INFO - 2023-09-13 20:25:26 --> Language Class Initialized
ERROR - 2023-09-13 20:25:26 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-13 20:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:26 --> Input Class Initialized
INFO - 2023-09-13 20:25:26 --> Language Class Initialized
ERROR - 2023-09-13 20:25:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:26 --> Config Class Initialized
INFO - 2023-09-13 20:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:26 --> URI Class Initialized
INFO - 2023-09-13 20:25:26 --> Router Class Initialized
INFO - 2023-09-13 20:25:26 --> Output Class Initialized
INFO - 2023-09-13 20:25:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:26 --> Input Class Initialized
INFO - 2023-09-13 20:25:26 --> Language Class Initialized
ERROR - 2023-09-13 20:25:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:27 --> Config Class Initialized
INFO - 2023-09-13 20:25:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:27 --> URI Class Initialized
INFO - 2023-09-13 20:25:27 --> Router Class Initialized
INFO - 2023-09-13 20:25:27 --> Output Class Initialized
INFO - 2023-09-13 20:25:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:27 --> Input Class Initialized
INFO - 2023-09-13 20:25:27 --> Language Class Initialized
ERROR - 2023-09-13 20:25:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:47 --> Config Class Initialized
INFO - 2023-09-13 20:25:47 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:47 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:47 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:47 --> URI Class Initialized
INFO - 2023-09-13 20:25:47 --> Router Class Initialized
INFO - 2023-09-13 20:25:47 --> Output Class Initialized
INFO - 2023-09-13 20:25:47 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:47 --> Input Class Initialized
INFO - 2023-09-13 20:25:47 --> Language Class Initialized
INFO - 2023-09-13 20:25:47 --> Loader Class Initialized
INFO - 2023-09-13 20:25:47 --> Helper loaded: url_helper
INFO - 2023-09-13 20:25:47 --> Helper loaded: file_helper
INFO - 2023-09-13 20:25:47 --> Database Driver Class Initialized
INFO - 2023-09-13 20:25:47 --> Email Class Initialized
DEBUG - 2023-09-13 20:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:25:47 --> Controller Class Initialized
INFO - 2023-09-13 20:25:47 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:25:47 --> Model "Home_model" initialized
INFO - 2023-09-13 20:25:47 --> Helper loaded: download_helper
INFO - 2023-09-13 20:25:47 --> Helper loaded: form_helper
INFO - 2023-09-13 20:25:47 --> Form Validation Class Initialized
INFO - 2023-09-13 20:25:47 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:25:47 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:25:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-13 20:25:47 --> Final output sent to browser
DEBUG - 2023-09-13 20:25:47 --> Total execution time: 0.2476
INFO - 2023-09-13 20:25:48 --> Config Class Initialized
INFO - 2023-09-13 20:25:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:48 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:48 --> URI Class Initialized
INFO - 2023-09-13 20:25:48 --> Router Class Initialized
INFO - 2023-09-13 20:25:48 --> Output Class Initialized
INFO - 2023-09-13 20:25:48 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:48 --> Input Class Initialized
INFO - 2023-09-13 20:25:48 --> Language Class Initialized
ERROR - 2023-09-13 20:25:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:48 --> Config Class Initialized
INFO - 2023-09-13 20:25:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:48 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:48 --> URI Class Initialized
INFO - 2023-09-13 20:25:48 --> Router Class Initialized
INFO - 2023-09-13 20:25:48 --> Output Class Initialized
INFO - 2023-09-13 20:25:48 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:48 --> Input Class Initialized
INFO - 2023-09-13 20:25:48 --> Language Class Initialized
ERROR - 2023-09-13 20:25:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:49 --> Config Class Initialized
INFO - 2023-09-13 20:25:49 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:49 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:49 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:49 --> URI Class Initialized
INFO - 2023-09-13 20:25:49 --> Router Class Initialized
INFO - 2023-09-13 20:25:49 --> Output Class Initialized
INFO - 2023-09-13 20:25:49 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:49 --> Input Class Initialized
INFO - 2023-09-13 20:25:49 --> Language Class Initialized
ERROR - 2023-09-13 20:25:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:49 --> Config Class Initialized
INFO - 2023-09-13 20:25:49 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:49 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:49 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:49 --> URI Class Initialized
INFO - 2023-09-13 20:25:49 --> Router Class Initialized
INFO - 2023-09-13 20:25:49 --> Output Class Initialized
INFO - 2023-09-13 20:25:49 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:49 --> Input Class Initialized
INFO - 2023-09-13 20:25:49 --> Language Class Initialized
ERROR - 2023-09-13 20:25:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:49 --> Config Class Initialized
INFO - 2023-09-13 20:25:49 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:49 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:49 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:49 --> URI Class Initialized
INFO - 2023-09-13 20:25:49 --> Router Class Initialized
INFO - 2023-09-13 20:25:49 --> Output Class Initialized
INFO - 2023-09-13 20:25:49 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:49 --> Input Class Initialized
INFO - 2023-09-13 20:25:49 --> Language Class Initialized
ERROR - 2023-09-13 20:25:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:49 --> Config Class Initialized
INFO - 2023-09-13 20:25:49 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:49 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:49 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:49 --> URI Class Initialized
INFO - 2023-09-13 20:25:49 --> Router Class Initialized
INFO - 2023-09-13 20:25:49 --> Output Class Initialized
INFO - 2023-09-13 20:25:49 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:49 --> Input Class Initialized
INFO - 2023-09-13 20:25:49 --> Language Class Initialized
ERROR - 2023-09-13 20:25:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:25:50 --> Config Class Initialized
INFO - 2023-09-13 20:25:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:25:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:25:50 --> Utf8 Class Initialized
INFO - 2023-09-13 20:25:50 --> URI Class Initialized
INFO - 2023-09-13 20:25:50 --> Router Class Initialized
INFO - 2023-09-13 20:25:50 --> Output Class Initialized
INFO - 2023-09-13 20:25:50 --> Security Class Initialized
DEBUG - 2023-09-13 20:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:25:50 --> Input Class Initialized
INFO - 2023-09-13 20:25:50 --> Language Class Initialized
ERROR - 2023-09-13 20:25:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:04 --> Config Class Initialized
INFO - 2023-09-13 20:26:04 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:04 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:04 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:04 --> URI Class Initialized
INFO - 2023-09-13 20:26:04 --> Router Class Initialized
INFO - 2023-09-13 20:26:04 --> Output Class Initialized
INFO - 2023-09-13 20:26:04 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:04 --> Input Class Initialized
INFO - 2023-09-13 20:26:04 --> Language Class Initialized
INFO - 2023-09-13 20:26:04 --> Loader Class Initialized
INFO - 2023-09-13 20:26:04 --> Helper loaded: url_helper
INFO - 2023-09-13 20:26:04 --> Helper loaded: file_helper
INFO - 2023-09-13 20:26:04 --> Database Driver Class Initialized
INFO - 2023-09-13 20:26:04 --> Email Class Initialized
DEBUG - 2023-09-13 20:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:26:04 --> Controller Class Initialized
INFO - 2023-09-13 20:26:04 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:26:04 --> Model "Home_model" initialized
INFO - 2023-09-13 20:26:04 --> Helper loaded: download_helper
INFO - 2023-09-13 20:26:04 --> Helper loaded: form_helper
INFO - 2023-09-13 20:26:04 --> Form Validation Class Initialized
INFO - 2023-09-13 20:26:04 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:26:04 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:26:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-13 20:26:04 --> Final output sent to browser
DEBUG - 2023-09-13 20:26:04 --> Total execution time: 0.0463
INFO - 2023-09-13 20:26:05 --> Config Class Initialized
INFO - 2023-09-13 20:26:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:05 --> URI Class Initialized
INFO - 2023-09-13 20:26:05 --> Router Class Initialized
INFO - 2023-09-13 20:26:05 --> Output Class Initialized
INFO - 2023-09-13 20:26:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:05 --> Input Class Initialized
INFO - 2023-09-13 20:26:05 --> Language Class Initialized
ERROR - 2023-09-13 20:26:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:05 --> Config Class Initialized
INFO - 2023-09-13 20:26:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:05 --> URI Class Initialized
INFO - 2023-09-13 20:26:05 --> Router Class Initialized
INFO - 2023-09-13 20:26:05 --> Output Class Initialized
INFO - 2023-09-13 20:26:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:05 --> Input Class Initialized
INFO - 2023-09-13 20:26:05 --> Language Class Initialized
ERROR - 2023-09-13 20:26:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:05 --> Config Class Initialized
INFO - 2023-09-13 20:26:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:05 --> URI Class Initialized
INFO - 2023-09-13 20:26:05 --> Router Class Initialized
INFO - 2023-09-13 20:26:05 --> Output Class Initialized
INFO - 2023-09-13 20:26:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:05 --> Input Class Initialized
INFO - 2023-09-13 20:26:05 --> Language Class Initialized
ERROR - 2023-09-13 20:26:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:05 --> Config Class Initialized
INFO - 2023-09-13 20:26:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:05 --> URI Class Initialized
INFO - 2023-09-13 20:26:05 --> Router Class Initialized
INFO - 2023-09-13 20:26:05 --> Output Class Initialized
INFO - 2023-09-13 20:26:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:05 --> Input Class Initialized
INFO - 2023-09-13 20:26:05 --> Language Class Initialized
ERROR - 2023-09-13 20:26:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:06 --> Config Class Initialized
INFO - 2023-09-13 20:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:06 --> URI Class Initialized
INFO - 2023-09-13 20:26:06 --> Router Class Initialized
INFO - 2023-09-13 20:26:06 --> Output Class Initialized
INFO - 2023-09-13 20:26:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:06 --> Input Class Initialized
INFO - 2023-09-13 20:26:06 --> Language Class Initialized
ERROR - 2023-09-13 20:26:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:06 --> Config Class Initialized
INFO - 2023-09-13 20:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:06 --> URI Class Initialized
INFO - 2023-09-13 20:26:06 --> Router Class Initialized
INFO - 2023-09-13 20:26:06 --> Output Class Initialized
INFO - 2023-09-13 20:26:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:06 --> Input Class Initialized
INFO - 2023-09-13 20:26:06 --> Language Class Initialized
ERROR - 2023-09-13 20:26:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:06 --> Config Class Initialized
INFO - 2023-09-13 20:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:06 --> URI Class Initialized
INFO - 2023-09-13 20:26:06 --> Router Class Initialized
INFO - 2023-09-13 20:26:06 --> Output Class Initialized
INFO - 2023-09-13 20:26:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:06 --> Input Class Initialized
INFO - 2023-09-13 20:26:06 --> Language Class Initialized
ERROR - 2023-09-13 20:26:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:16 --> Config Class Initialized
INFO - 2023-09-13 20:26:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:16 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:16 --> URI Class Initialized
INFO - 2023-09-13 20:26:16 --> Router Class Initialized
INFO - 2023-09-13 20:26:16 --> Output Class Initialized
INFO - 2023-09-13 20:26:16 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:16 --> Input Class Initialized
INFO - 2023-09-13 20:26:16 --> Language Class Initialized
INFO - 2023-09-13 20:26:16 --> Loader Class Initialized
INFO - 2023-09-13 20:26:16 --> Helper loaded: url_helper
INFO - 2023-09-13 20:26:16 --> Helper loaded: file_helper
INFO - 2023-09-13 20:26:16 --> Database Driver Class Initialized
INFO - 2023-09-13 20:26:16 --> Email Class Initialized
DEBUG - 2023-09-13 20:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:26:16 --> Controller Class Initialized
INFO - 2023-09-13 20:26:16 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:26:16 --> Model "Home_model" initialized
INFO - 2023-09-13 20:26:16 --> Helper loaded: download_helper
INFO - 2023-09-13 20:26:16 --> Helper loaded: form_helper
INFO - 2023-09-13 20:26:16 --> Form Validation Class Initialized
INFO - 2023-09-13 20:26:16 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:26:16 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:26:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-13 20:26:16 --> Final output sent to browser
DEBUG - 2023-09-13 20:26:17 --> Total execution time: 0.1857
INFO - 2023-09-13 20:26:18 --> Config Class Initialized
INFO - 2023-09-13 20:26:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:18 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:18 --> URI Class Initialized
INFO - 2023-09-13 20:26:18 --> Router Class Initialized
INFO - 2023-09-13 20:26:18 --> Output Class Initialized
INFO - 2023-09-13 20:26:18 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:18 --> Input Class Initialized
INFO - 2023-09-13 20:26:18 --> Language Class Initialized
ERROR - 2023-09-13 20:26:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:18 --> Config Class Initialized
INFO - 2023-09-13 20:26:18 --> Config Class Initialized
INFO - 2023-09-13 20:26:18 --> Hooks Class Initialized
INFO - 2023-09-13 20:26:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 20:26:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:18 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:18 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:18 --> URI Class Initialized
INFO - 2023-09-13 20:26:18 --> URI Class Initialized
INFO - 2023-09-13 20:26:18 --> Router Class Initialized
INFO - 2023-09-13 20:26:18 --> Router Class Initialized
INFO - 2023-09-13 20:26:18 --> Output Class Initialized
INFO - 2023-09-13 20:26:18 --> Output Class Initialized
INFO - 2023-09-13 20:26:18 --> Security Class Initialized
INFO - 2023-09-13 20:26:18 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 20:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:18 --> Input Class Initialized
INFO - 2023-09-13 20:26:18 --> Input Class Initialized
INFO - 2023-09-13 20:26:18 --> Language Class Initialized
INFO - 2023-09-13 20:26:18 --> Language Class Initialized
ERROR - 2023-09-13 20:26:18 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-13 20:26:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:19 --> Config Class Initialized
INFO - 2023-09-13 20:26:19 --> Hooks Class Initialized
INFO - 2023-09-13 20:26:19 --> Config Class Initialized
INFO - 2023-09-13 20:26:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:19 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:19 --> URI Class Initialized
INFO - 2023-09-13 20:26:19 --> Router Class Initialized
INFO - 2023-09-13 20:26:19 --> Output Class Initialized
INFO - 2023-09-13 20:26:19 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:19 --> Input Class Initialized
INFO - 2023-09-13 20:26:19 --> Language Class Initialized
ERROR - 2023-09-13 20:26:19 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-13 20:26:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:19 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:19 --> URI Class Initialized
INFO - 2023-09-13 20:26:19 --> Router Class Initialized
INFO - 2023-09-13 20:26:19 --> Output Class Initialized
INFO - 2023-09-13 20:26:19 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:19 --> Input Class Initialized
INFO - 2023-09-13 20:26:19 --> Language Class Initialized
ERROR - 2023-09-13 20:26:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:20 --> Config Class Initialized
INFO - 2023-09-13 20:26:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:20 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:20 --> URI Class Initialized
INFO - 2023-09-13 20:26:20 --> Router Class Initialized
INFO - 2023-09-13 20:26:20 --> Output Class Initialized
INFO - 2023-09-13 20:26:20 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:20 --> Input Class Initialized
INFO - 2023-09-13 20:26:20 --> Language Class Initialized
ERROR - 2023-09-13 20:26:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:20 --> Config Class Initialized
INFO - 2023-09-13 20:26:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:20 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:20 --> URI Class Initialized
INFO - 2023-09-13 20:26:20 --> Router Class Initialized
INFO - 2023-09-13 20:26:20 --> Output Class Initialized
INFO - 2023-09-13 20:26:20 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:20 --> Input Class Initialized
INFO - 2023-09-13 20:26:20 --> Language Class Initialized
ERROR - 2023-09-13 20:26:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:26 --> Config Class Initialized
INFO - 2023-09-13 20:26:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:26 --> URI Class Initialized
INFO - 2023-09-13 20:26:26 --> Router Class Initialized
INFO - 2023-09-13 20:26:26 --> Output Class Initialized
INFO - 2023-09-13 20:26:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:26 --> Input Class Initialized
INFO - 2023-09-13 20:26:26 --> Language Class Initialized
INFO - 2023-09-13 20:26:26 --> Loader Class Initialized
INFO - 2023-09-13 20:26:26 --> Helper loaded: url_helper
INFO - 2023-09-13 20:26:26 --> Helper loaded: file_helper
INFO - 2023-09-13 20:26:26 --> Database Driver Class Initialized
INFO - 2023-09-13 20:26:26 --> Email Class Initialized
DEBUG - 2023-09-13 20:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:26:26 --> Controller Class Initialized
INFO - 2023-09-13 20:26:26 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:26:26 --> Model "Home_model" initialized
INFO - 2023-09-13 20:26:26 --> Helper loaded: download_helper
INFO - 2023-09-13 20:26:26 --> Helper loaded: form_helper
INFO - 2023-09-13 20:26:26 --> Form Validation Class Initialized
INFO - 2023-09-13 20:26:26 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:26:26 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:26:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:26:26 --> Final output sent to browser
DEBUG - 2023-09-13 20:26:26 --> Total execution time: 0.1443
INFO - 2023-09-13 20:26:27 --> Config Class Initialized
INFO - 2023-09-13 20:26:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:27 --> URI Class Initialized
INFO - 2023-09-13 20:26:27 --> Router Class Initialized
INFO - 2023-09-13 20:26:27 --> Output Class Initialized
INFO - 2023-09-13 20:26:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:27 --> Input Class Initialized
INFO - 2023-09-13 20:26:27 --> Language Class Initialized
ERROR - 2023-09-13 20:26:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:29 --> Config Class Initialized
INFO - 2023-09-13 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:29 --> URI Class Initialized
INFO - 2023-09-13 20:26:29 --> Router Class Initialized
INFO - 2023-09-13 20:26:29 --> Output Class Initialized
INFO - 2023-09-13 20:26:29 --> Config Class Initialized
INFO - 2023-09-13 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:29 --> Config Class Initialized
INFO - 2023-09-13 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:29 --> URI Class Initialized
INFO - 2023-09-13 20:26:29 --> Router Class Initialized
INFO - 2023-09-13 20:26:29 --> Config Class Initialized
INFO - 2023-09-13 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:29 --> URI Class Initialized
INFO - 2023-09-13 20:26:29 --> Router Class Initialized
INFO - 2023-09-13 20:26:29 --> Output Class Initialized
INFO - 2023-09-13 20:26:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:29 --> Input Class Initialized
INFO - 2023-09-13 20:26:29 --> Language Class Initialized
ERROR - 2023-09-13 20:26:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:29 --> Input Class Initialized
INFO - 2023-09-13 20:26:29 --> Language Class Initialized
ERROR - 2023-09-13 20:26:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:29 --> URI Class Initialized
INFO - 2023-09-13 20:26:29 --> Router Class Initialized
INFO - 2023-09-13 20:26:29 --> Output Class Initialized
INFO - 2023-09-13 20:26:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:29 --> Input Class Initialized
INFO - 2023-09-13 20:26:29 --> Language Class Initialized
ERROR - 2023-09-13 20:26:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:29 --> Output Class Initialized
INFO - 2023-09-13 20:26:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:29 --> Input Class Initialized
INFO - 2023-09-13 20:26:29 --> Language Class Initialized
ERROR - 2023-09-13 20:26:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:30 --> Config Class Initialized
INFO - 2023-09-13 20:26:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:30 --> URI Class Initialized
INFO - 2023-09-13 20:26:30 --> Router Class Initialized
INFO - 2023-09-13 20:26:30 --> Output Class Initialized
INFO - 2023-09-13 20:26:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:30 --> Input Class Initialized
INFO - 2023-09-13 20:26:30 --> Language Class Initialized
ERROR - 2023-09-13 20:26:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:26:30 --> Config Class Initialized
INFO - 2023-09-13 20:26:30 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:26:30 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:26:30 --> Utf8 Class Initialized
INFO - 2023-09-13 20:26:30 --> URI Class Initialized
INFO - 2023-09-13 20:26:30 --> Router Class Initialized
INFO - 2023-09-13 20:26:30 --> Output Class Initialized
INFO - 2023-09-13 20:26:30 --> Security Class Initialized
DEBUG - 2023-09-13 20:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:26:30 --> Input Class Initialized
INFO - 2023-09-13 20:26:30 --> Language Class Initialized
ERROR - 2023-09-13 20:26:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:36 --> Config Class Initialized
INFO - 2023-09-13 20:28:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:36 --> URI Class Initialized
INFO - 2023-09-13 20:28:36 --> Router Class Initialized
INFO - 2023-09-13 20:28:36 --> Output Class Initialized
INFO - 2023-09-13 20:28:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:36 --> Input Class Initialized
INFO - 2023-09-13 20:28:36 --> Language Class Initialized
INFO - 2023-09-13 20:28:36 --> Loader Class Initialized
INFO - 2023-09-13 20:28:36 --> Helper loaded: url_helper
INFO - 2023-09-13 20:28:36 --> Helper loaded: file_helper
INFO - 2023-09-13 20:28:36 --> Database Driver Class Initialized
INFO - 2023-09-13 20:28:36 --> Email Class Initialized
DEBUG - 2023-09-13 20:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:28:36 --> Controller Class Initialized
INFO - 2023-09-13 20:28:36 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:28:36 --> Model "Home_model" initialized
INFO - 2023-09-13 20:28:36 --> Helper loaded: download_helper
INFO - 2023-09-13 20:28:36 --> Helper loaded: form_helper
INFO - 2023-09-13 20:28:36 --> Form Validation Class Initialized
INFO - 2023-09-13 20:28:36 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:28:36 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:28:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:28:36 --> Final output sent to browser
DEBUG - 2023-09-13 20:28:36 --> Total execution time: 0.3268
INFO - 2023-09-13 20:28:39 --> Config Class Initialized
INFO - 2023-09-13 20:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:39 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:39 --> URI Class Initialized
INFO - 2023-09-13 20:28:39 --> Router Class Initialized
INFO - 2023-09-13 20:28:39 --> Output Class Initialized
INFO - 2023-09-13 20:28:39 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:39 --> Input Class Initialized
INFO - 2023-09-13 20:28:39 --> Language Class Initialized
ERROR - 2023-09-13 20:28:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:39 --> Config Class Initialized
INFO - 2023-09-13 20:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:39 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:39 --> URI Class Initialized
INFO - 2023-09-13 20:28:39 --> Router Class Initialized
INFO - 2023-09-13 20:28:39 --> Output Class Initialized
INFO - 2023-09-13 20:28:39 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:39 --> Input Class Initialized
INFO - 2023-09-13 20:28:39 --> Language Class Initialized
ERROR - 2023-09-13 20:28:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:39 --> Config Class Initialized
INFO - 2023-09-13 20:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:39 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:39 --> URI Class Initialized
INFO - 2023-09-13 20:28:39 --> Router Class Initialized
INFO - 2023-09-13 20:28:39 --> Output Class Initialized
INFO - 2023-09-13 20:28:39 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:39 --> Input Class Initialized
INFO - 2023-09-13 20:28:39 --> Language Class Initialized
ERROR - 2023-09-13 20:28:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:39 --> Config Class Initialized
INFO - 2023-09-13 20:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:39 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:39 --> URI Class Initialized
INFO - 2023-09-13 20:28:39 --> Router Class Initialized
INFO - 2023-09-13 20:28:39 --> Output Class Initialized
INFO - 2023-09-13 20:28:39 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:39 --> Input Class Initialized
INFO - 2023-09-13 20:28:39 --> Language Class Initialized
ERROR - 2023-09-13 20:28:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:40 --> Config Class Initialized
INFO - 2023-09-13 20:28:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:40 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:40 --> URI Class Initialized
INFO - 2023-09-13 20:28:40 --> Router Class Initialized
INFO - 2023-09-13 20:28:40 --> Output Class Initialized
INFO - 2023-09-13 20:28:40 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:40 --> Input Class Initialized
INFO - 2023-09-13 20:28:40 --> Language Class Initialized
ERROR - 2023-09-13 20:28:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:41 --> Config Class Initialized
INFO - 2023-09-13 20:28:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:41 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:41 --> URI Class Initialized
INFO - 2023-09-13 20:28:41 --> Router Class Initialized
INFO - 2023-09-13 20:28:41 --> Output Class Initialized
INFO - 2023-09-13 20:28:41 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:41 --> Input Class Initialized
INFO - 2023-09-13 20:28:41 --> Language Class Initialized
ERROR - 2023-09-13 20:28:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:28:41 --> Config Class Initialized
INFO - 2023-09-13 20:28:41 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:28:41 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:28:41 --> Utf8 Class Initialized
INFO - 2023-09-13 20:28:41 --> URI Class Initialized
INFO - 2023-09-13 20:28:41 --> Router Class Initialized
INFO - 2023-09-13 20:28:41 --> Output Class Initialized
INFO - 2023-09-13 20:28:41 --> Security Class Initialized
DEBUG - 2023-09-13 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:28:41 --> Input Class Initialized
INFO - 2023-09-13 20:28:41 --> Language Class Initialized
ERROR - 2023-09-13 20:28:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:33 --> Config Class Initialized
INFO - 2023-09-13 20:29:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:33 --> URI Class Initialized
INFO - 2023-09-13 20:29:33 --> Router Class Initialized
INFO - 2023-09-13 20:29:33 --> Output Class Initialized
INFO - 2023-09-13 20:29:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:33 --> Input Class Initialized
INFO - 2023-09-13 20:29:33 --> Language Class Initialized
INFO - 2023-09-13 20:29:33 --> Loader Class Initialized
INFO - 2023-09-13 20:29:33 --> Helper loaded: url_helper
INFO - 2023-09-13 20:29:33 --> Helper loaded: file_helper
INFO - 2023-09-13 20:29:33 --> Database Driver Class Initialized
INFO - 2023-09-13 20:29:33 --> Email Class Initialized
DEBUG - 2023-09-13 20:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:29:33 --> Controller Class Initialized
INFO - 2023-09-13 20:29:33 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:29:33 --> Model "Home_model" initialized
INFO - 2023-09-13 20:29:33 --> Helper loaded: download_helper
INFO - 2023-09-13 20:29:33 --> Helper loaded: form_helper
INFO - 2023-09-13 20:29:33 --> Form Validation Class Initialized
INFO - 2023-09-13 20:29:33 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:29:33 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:29:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:29:33 --> Final output sent to browser
DEBUG - 2023-09-13 20:29:33 --> Total execution time: 0.2869
INFO - 2023-09-13 20:29:34 --> Config Class Initialized
INFO - 2023-09-13 20:29:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:34 --> URI Class Initialized
INFO - 2023-09-13 20:29:34 --> Router Class Initialized
INFO - 2023-09-13 20:29:34 --> Output Class Initialized
INFO - 2023-09-13 20:29:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:34 --> Input Class Initialized
INFO - 2023-09-13 20:29:34 --> Language Class Initialized
ERROR - 2023-09-13 20:29:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:35 --> Config Class Initialized
INFO - 2023-09-13 20:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:35 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:35 --> URI Class Initialized
INFO - 2023-09-13 20:29:35 --> Router Class Initialized
INFO - 2023-09-13 20:29:35 --> Output Class Initialized
INFO - 2023-09-13 20:29:35 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:35 --> Input Class Initialized
INFO - 2023-09-13 20:29:35 --> Language Class Initialized
ERROR - 2023-09-13 20:29:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:37 --> Config Class Initialized
INFO - 2023-09-13 20:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:37 --> URI Class Initialized
INFO - 2023-09-13 20:29:37 --> Router Class Initialized
INFO - 2023-09-13 20:29:37 --> Output Class Initialized
INFO - 2023-09-13 20:29:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:37 --> Input Class Initialized
INFO - 2023-09-13 20:29:37 --> Language Class Initialized
ERROR - 2023-09-13 20:29:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:37 --> Config Class Initialized
INFO - 2023-09-13 20:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:37 --> URI Class Initialized
INFO - 2023-09-13 20:29:37 --> Router Class Initialized
INFO - 2023-09-13 20:29:37 --> Output Class Initialized
INFO - 2023-09-13 20:29:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:37 --> Input Class Initialized
INFO - 2023-09-13 20:29:37 --> Language Class Initialized
ERROR - 2023-09-13 20:29:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:37 --> Config Class Initialized
INFO - 2023-09-13 20:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:37 --> URI Class Initialized
INFO - 2023-09-13 20:29:37 --> Router Class Initialized
INFO - 2023-09-13 20:29:37 --> Output Class Initialized
INFO - 2023-09-13 20:29:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:37 --> Input Class Initialized
INFO - 2023-09-13 20:29:37 --> Language Class Initialized
ERROR - 2023-09-13 20:29:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:37 --> Config Class Initialized
INFO - 2023-09-13 20:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:37 --> URI Class Initialized
INFO - 2023-09-13 20:29:37 --> Router Class Initialized
INFO - 2023-09-13 20:29:37 --> Output Class Initialized
INFO - 2023-09-13 20:29:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:37 --> Input Class Initialized
INFO - 2023-09-13 20:29:37 --> Language Class Initialized
ERROR - 2023-09-13 20:29:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:29:38 --> Config Class Initialized
INFO - 2023-09-13 20:29:38 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:29:38 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:29:38 --> Utf8 Class Initialized
INFO - 2023-09-13 20:29:38 --> URI Class Initialized
INFO - 2023-09-13 20:29:38 --> Router Class Initialized
INFO - 2023-09-13 20:29:38 --> Output Class Initialized
INFO - 2023-09-13 20:29:38 --> Security Class Initialized
DEBUG - 2023-09-13 20:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:29:38 --> Input Class Initialized
INFO - 2023-09-13 20:29:38 --> Language Class Initialized
ERROR - 2023-09-13 20:29:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:01 --> Config Class Initialized
INFO - 2023-09-13 20:30:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:01 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:01 --> URI Class Initialized
INFO - 2023-09-13 20:30:01 --> Router Class Initialized
INFO - 2023-09-13 20:30:01 --> Output Class Initialized
INFO - 2023-09-13 20:30:01 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:01 --> Input Class Initialized
INFO - 2023-09-13 20:30:01 --> Language Class Initialized
INFO - 2023-09-13 20:30:01 --> Loader Class Initialized
INFO - 2023-09-13 20:30:01 --> Helper loaded: url_helper
INFO - 2023-09-13 20:30:01 --> Helper loaded: file_helper
INFO - 2023-09-13 20:30:01 --> Database Driver Class Initialized
INFO - 2023-09-13 20:30:01 --> Email Class Initialized
DEBUG - 2023-09-13 20:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:30:01 --> Controller Class Initialized
INFO - 2023-09-13 20:30:01 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:30:01 --> Model "Home_model" initialized
INFO - 2023-09-13 20:30:01 --> Helper loaded: download_helper
INFO - 2023-09-13 20:30:01 --> Helper loaded: form_helper
INFO - 2023-09-13 20:30:01 --> Form Validation Class Initialized
INFO - 2023-09-13 20:30:01 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:30:01 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:30:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-13 20:30:01 --> Final output sent to browser
DEBUG - 2023-09-13 20:30:01 --> Total execution time: 0.1309
INFO - 2023-09-13 20:30:03 --> Config Class Initialized
INFO - 2023-09-13 20:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:03 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:03 --> URI Class Initialized
INFO - 2023-09-13 20:30:03 --> Router Class Initialized
INFO - 2023-09-13 20:30:03 --> Output Class Initialized
INFO - 2023-09-13 20:30:03 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:03 --> Input Class Initialized
INFO - 2023-09-13 20:30:03 --> Language Class Initialized
ERROR - 2023-09-13 20:30:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:03 --> Config Class Initialized
INFO - 2023-09-13 20:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:03 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:03 --> URI Class Initialized
INFO - 2023-09-13 20:30:03 --> Router Class Initialized
INFO - 2023-09-13 20:30:03 --> Output Class Initialized
INFO - 2023-09-13 20:30:03 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:03 --> Input Class Initialized
INFO - 2023-09-13 20:30:03 --> Language Class Initialized
ERROR - 2023-09-13 20:30:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:04 --> Config Class Initialized
INFO - 2023-09-13 20:30:04 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:04 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:04 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:04 --> URI Class Initialized
INFO - 2023-09-13 20:30:04 --> Router Class Initialized
INFO - 2023-09-13 20:30:04 --> Output Class Initialized
INFO - 2023-09-13 20:30:04 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:04 --> Input Class Initialized
INFO - 2023-09-13 20:30:04 --> Language Class Initialized
ERROR - 2023-09-13 20:30:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:04 --> Config Class Initialized
INFO - 2023-09-13 20:30:04 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:04 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:04 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:04 --> URI Class Initialized
INFO - 2023-09-13 20:30:04 --> Router Class Initialized
INFO - 2023-09-13 20:30:04 --> Output Class Initialized
INFO - 2023-09-13 20:30:04 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:04 --> Input Class Initialized
INFO - 2023-09-13 20:30:04 --> Language Class Initialized
ERROR - 2023-09-13 20:30:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:05 --> Config Class Initialized
INFO - 2023-09-13 20:30:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:05 --> URI Class Initialized
INFO - 2023-09-13 20:30:05 --> Router Class Initialized
INFO - 2023-09-13 20:30:05 --> Output Class Initialized
INFO - 2023-09-13 20:30:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:05 --> Input Class Initialized
INFO - 2023-09-13 20:30:05 --> Language Class Initialized
ERROR - 2023-09-13 20:30:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:05 --> Config Class Initialized
INFO - 2023-09-13 20:30:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:06 --> URI Class Initialized
INFO - 2023-09-13 20:30:06 --> Router Class Initialized
INFO - 2023-09-13 20:30:06 --> Output Class Initialized
INFO - 2023-09-13 20:30:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:06 --> Input Class Initialized
INFO - 2023-09-13 20:30:06 --> Language Class Initialized
ERROR - 2023-09-13 20:30:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:06 --> Config Class Initialized
INFO - 2023-09-13 20:30:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:06 --> URI Class Initialized
INFO - 2023-09-13 20:30:06 --> Router Class Initialized
INFO - 2023-09-13 20:30:06 --> Output Class Initialized
INFO - 2023-09-13 20:30:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:06 --> Input Class Initialized
INFO - 2023-09-13 20:30:06 --> Language Class Initialized
ERROR - 2023-09-13 20:30:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:08 --> Config Class Initialized
INFO - 2023-09-13 20:30:08 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:08 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:08 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:08 --> URI Class Initialized
INFO - 2023-09-13 20:30:08 --> Router Class Initialized
INFO - 2023-09-13 20:30:08 --> Output Class Initialized
INFO - 2023-09-13 20:30:08 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:08 --> Input Class Initialized
INFO - 2023-09-13 20:30:08 --> Language Class Initialized
INFO - 2023-09-13 20:30:08 --> Loader Class Initialized
INFO - 2023-09-13 20:30:08 --> Helper loaded: url_helper
INFO - 2023-09-13 20:30:08 --> Helper loaded: file_helper
INFO - 2023-09-13 20:30:08 --> Database Driver Class Initialized
INFO - 2023-09-13 20:30:08 --> Email Class Initialized
DEBUG - 2023-09-13 20:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:30:08 --> Controller Class Initialized
INFO - 2023-09-13 20:30:08 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:30:08 --> Model "Home_model" initialized
INFO - 2023-09-13 20:30:08 --> Helper loaded: download_helper
INFO - 2023-09-13 20:30:08 --> Helper loaded: form_helper
INFO - 2023-09-13 20:30:08 --> Form Validation Class Initialized
INFO - 2023-09-13 20:30:09 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:30:09 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:30:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:30:09 --> Final output sent to browser
DEBUG - 2023-09-13 20:30:09 --> Total execution time: 0.1817
INFO - 2023-09-13 20:30:09 --> Config Class Initialized
INFO - 2023-09-13 20:30:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:09 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:09 --> URI Class Initialized
INFO - 2023-09-13 20:30:09 --> Router Class Initialized
INFO - 2023-09-13 20:30:09 --> Output Class Initialized
INFO - 2023-09-13 20:30:09 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:09 --> Input Class Initialized
INFO - 2023-09-13 20:30:09 --> Language Class Initialized
ERROR - 2023-09-13 20:30:09 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:30:09 --> Config Class Initialized
INFO - 2023-09-13 20:30:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:09 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:09 --> URI Class Initialized
INFO - 2023-09-13 20:30:09 --> Router Class Initialized
INFO - 2023-09-13 20:30:09 --> Output Class Initialized
INFO - 2023-09-13 20:30:09 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:09 --> Input Class Initialized
INFO - 2023-09-13 20:30:09 --> Language Class Initialized
ERROR - 2023-09-13 20:30:09 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:30:09 --> Config Class Initialized
INFO - 2023-09-13 20:30:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:09 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:09 --> URI Class Initialized
INFO - 2023-09-13 20:30:09 --> Router Class Initialized
INFO - 2023-09-13 20:30:09 --> Output Class Initialized
INFO - 2023-09-13 20:30:09 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:09 --> Input Class Initialized
INFO - 2023-09-13 20:30:09 --> Language Class Initialized
ERROR - 2023-09-13 20:30:09 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:30:26 --> Config Class Initialized
INFO - 2023-09-13 20:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:26 --> URI Class Initialized
INFO - 2023-09-13 20:30:26 --> Router Class Initialized
INFO - 2023-09-13 20:30:26 --> Output Class Initialized
INFO - 2023-09-13 20:30:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:26 --> Input Class Initialized
INFO - 2023-09-13 20:30:26 --> Language Class Initialized
ERROR - 2023-09-13 20:30:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:26 --> Config Class Initialized
INFO - 2023-09-13 20:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:26 --> URI Class Initialized
INFO - 2023-09-13 20:30:26 --> Router Class Initialized
INFO - 2023-09-13 20:30:26 --> Output Class Initialized
INFO - 2023-09-13 20:30:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:26 --> Input Class Initialized
INFO - 2023-09-13 20:30:26 --> Language Class Initialized
ERROR - 2023-09-13 20:30:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:27 --> Config Class Initialized
INFO - 2023-09-13 20:30:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:27 --> URI Class Initialized
INFO - 2023-09-13 20:30:27 --> Router Class Initialized
INFO - 2023-09-13 20:30:27 --> Output Class Initialized
INFO - 2023-09-13 20:30:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:27 --> Input Class Initialized
INFO - 2023-09-13 20:30:27 --> Language Class Initialized
ERROR - 2023-09-13 20:30:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:27 --> Config Class Initialized
INFO - 2023-09-13 20:30:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:27 --> URI Class Initialized
INFO - 2023-09-13 20:30:27 --> Router Class Initialized
INFO - 2023-09-13 20:30:27 --> Output Class Initialized
INFO - 2023-09-13 20:30:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:27 --> Input Class Initialized
INFO - 2023-09-13 20:30:27 --> Language Class Initialized
ERROR - 2023-09-13 20:30:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:28 --> Config Class Initialized
INFO - 2023-09-13 20:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:28 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:28 --> URI Class Initialized
INFO - 2023-09-13 20:30:29 --> Router Class Initialized
INFO - 2023-09-13 20:30:29 --> Output Class Initialized
INFO - 2023-09-13 20:30:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:29 --> Input Class Initialized
INFO - 2023-09-13 20:30:29 --> Language Class Initialized
ERROR - 2023-09-13 20:30:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:29 --> Config Class Initialized
INFO - 2023-09-13 20:30:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:29 --> URI Class Initialized
INFO - 2023-09-13 20:30:29 --> Router Class Initialized
INFO - 2023-09-13 20:30:29 --> Output Class Initialized
INFO - 2023-09-13 20:30:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:29 --> Input Class Initialized
INFO - 2023-09-13 20:30:29 --> Language Class Initialized
ERROR - 2023-09-13 20:30:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:30:29 --> Config Class Initialized
INFO - 2023-09-13 20:30:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:30:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:30:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:30:29 --> URI Class Initialized
INFO - 2023-09-13 20:30:29 --> Router Class Initialized
INFO - 2023-09-13 20:30:29 --> Output Class Initialized
INFO - 2023-09-13 20:30:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:30:29 --> Input Class Initialized
INFO - 2023-09-13 20:30:29 --> Language Class Initialized
ERROR - 2023-09-13 20:30:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:04 --> Config Class Initialized
INFO - 2023-09-13 20:31:04 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:04 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:04 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:04 --> URI Class Initialized
INFO - 2023-09-13 20:31:04 --> Router Class Initialized
INFO - 2023-09-13 20:31:04 --> Output Class Initialized
INFO - 2023-09-13 20:31:04 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:04 --> Input Class Initialized
INFO - 2023-09-13 20:31:04 --> Language Class Initialized
INFO - 2023-09-13 20:31:04 --> Loader Class Initialized
INFO - 2023-09-13 20:31:04 --> Helper loaded: url_helper
INFO - 2023-09-13 20:31:04 --> Helper loaded: file_helper
INFO - 2023-09-13 20:31:04 --> Database Driver Class Initialized
INFO - 2023-09-13 20:31:04 --> Email Class Initialized
DEBUG - 2023-09-13 20:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:31:04 --> Controller Class Initialized
INFO - 2023-09-13 20:31:04 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:31:04 --> Model "Home_model" initialized
INFO - 2023-09-13 20:31:04 --> Helper loaded: download_helper
INFO - 2023-09-13 20:31:04 --> Helper loaded: form_helper
INFO - 2023-09-13 20:31:04 --> Form Validation Class Initialized
INFO - 2023-09-13 20:31:04 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:31:04 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:31:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:31:04 --> Final output sent to browser
DEBUG - 2023-09-13 20:31:04 --> Total execution time: 0.1553
INFO - 2023-09-13 20:31:05 --> Config Class Initialized
INFO - 2023-09-13 20:31:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:05 --> URI Class Initialized
INFO - 2023-09-13 20:31:05 --> Router Class Initialized
INFO - 2023-09-13 20:31:05 --> Output Class Initialized
INFO - 2023-09-13 20:31:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:05 --> Input Class Initialized
INFO - 2023-09-13 20:31:05 --> Language Class Initialized
ERROR - 2023-09-13 20:31:05 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:31:05 --> Config Class Initialized
INFO - 2023-09-13 20:31:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:05 --> URI Class Initialized
INFO - 2023-09-13 20:31:05 --> Router Class Initialized
INFO - 2023-09-13 20:31:05 --> Output Class Initialized
INFO - 2023-09-13 20:31:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:05 --> Input Class Initialized
INFO - 2023-09-13 20:31:05 --> Language Class Initialized
ERROR - 2023-09-13 20:31:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:05 --> Config Class Initialized
INFO - 2023-09-13 20:31:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:05 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:05 --> URI Class Initialized
INFO - 2023-09-13 20:31:05 --> Router Class Initialized
INFO - 2023-09-13 20:31:05 --> Output Class Initialized
INFO - 2023-09-13 20:31:05 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:05 --> Input Class Initialized
INFO - 2023-09-13 20:31:05 --> Language Class Initialized
ERROR - 2023-09-13 20:31:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:06 --> Config Class Initialized
INFO - 2023-09-13 20:31:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:06 --> URI Class Initialized
INFO - 2023-09-13 20:31:06 --> Router Class Initialized
INFO - 2023-09-13 20:31:06 --> Output Class Initialized
INFO - 2023-09-13 20:31:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:06 --> Input Class Initialized
INFO - 2023-09-13 20:31:06 --> Language Class Initialized
ERROR - 2023-09-13 20:31:06 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:31:06 --> Config Class Initialized
INFO - 2023-09-13 20:31:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:06 --> URI Class Initialized
INFO - 2023-09-13 20:31:06 --> Router Class Initialized
INFO - 2023-09-13 20:31:06 --> Output Class Initialized
INFO - 2023-09-13 20:31:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:06 --> Input Class Initialized
INFO - 2023-09-13 20:31:06 --> Language Class Initialized
ERROR - 2023-09-13 20:31:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:06 --> Config Class Initialized
INFO - 2023-09-13 20:31:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:06 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:06 --> URI Class Initialized
INFO - 2023-09-13 20:31:06 --> Router Class Initialized
INFO - 2023-09-13 20:31:06 --> Output Class Initialized
INFO - 2023-09-13 20:31:06 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:06 --> Input Class Initialized
INFO - 2023-09-13 20:31:06 --> Language Class Initialized
ERROR - 2023-09-13 20:31:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:07 --> Config Class Initialized
INFO - 2023-09-13 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:07 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:07 --> URI Class Initialized
INFO - 2023-09-13 20:31:07 --> Router Class Initialized
INFO - 2023-09-13 20:31:07 --> Output Class Initialized
INFO - 2023-09-13 20:31:07 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:07 --> Input Class Initialized
INFO - 2023-09-13 20:31:07 --> Language Class Initialized
ERROR - 2023-09-13 20:31:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:07 --> Config Class Initialized
INFO - 2023-09-13 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:07 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:07 --> URI Class Initialized
INFO - 2023-09-13 20:31:07 --> Router Class Initialized
INFO - 2023-09-13 20:31:07 --> Output Class Initialized
INFO - 2023-09-13 20:31:07 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:07 --> Input Class Initialized
INFO - 2023-09-13 20:31:07 --> Language Class Initialized
ERROR - 2023-09-13 20:31:07 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:31:07 --> Config Class Initialized
INFO - 2023-09-13 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:07 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:07 --> URI Class Initialized
INFO - 2023-09-13 20:31:07 --> Router Class Initialized
INFO - 2023-09-13 20:31:07 --> Output Class Initialized
INFO - 2023-09-13 20:31:07 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:07 --> Input Class Initialized
INFO - 2023-09-13 20:31:07 --> Language Class Initialized
ERROR - 2023-09-13 20:31:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:31:07 --> Config Class Initialized
INFO - 2023-09-13 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:31:07 --> Utf8 Class Initialized
INFO - 2023-09-13 20:31:07 --> URI Class Initialized
INFO - 2023-09-13 20:31:07 --> Router Class Initialized
INFO - 2023-09-13 20:31:07 --> Output Class Initialized
INFO - 2023-09-13 20:31:07 --> Security Class Initialized
DEBUG - 2023-09-13 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:31:07 --> Input Class Initialized
INFO - 2023-09-13 20:31:07 --> Language Class Initialized
ERROR - 2023-09-13 20:31:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:32:24 --> Config Class Initialized
INFO - 2023-09-13 20:32:24 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:32:24 --> Utf8 Class Initialized
INFO - 2023-09-13 20:32:24 --> URI Class Initialized
INFO - 2023-09-13 20:32:24 --> Router Class Initialized
INFO - 2023-09-13 20:32:24 --> Output Class Initialized
INFO - 2023-09-13 20:32:24 --> Security Class Initialized
DEBUG - 2023-09-13 20:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:32:24 --> Input Class Initialized
INFO - 2023-09-13 20:32:24 --> Language Class Initialized
INFO - 2023-09-13 20:32:24 --> Loader Class Initialized
INFO - 2023-09-13 20:32:24 --> Helper loaded: url_helper
INFO - 2023-09-13 20:32:24 --> Helper loaded: file_helper
INFO - 2023-09-13 20:32:24 --> Database Driver Class Initialized
INFO - 2023-09-13 20:32:24 --> Email Class Initialized
DEBUG - 2023-09-13 20:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:32:24 --> Controller Class Initialized
INFO - 2023-09-13 20:32:24 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:32:24 --> Model "Home_model" initialized
INFO - 2023-09-13 20:32:24 --> Helper loaded: download_helper
INFO - 2023-09-13 20:32:24 --> Helper loaded: form_helper
INFO - 2023-09-13 20:32:24 --> Form Validation Class Initialized
INFO - 2023-09-13 20:32:24 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:32:24 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:32:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:32:24 --> Final output sent to browser
DEBUG - 2023-09-13 20:32:24 --> Total execution time: 0.1529
INFO - 2023-09-13 20:32:26 --> Config Class Initialized
INFO - 2023-09-13 20:32:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:32:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:32:26 --> Utf8 Class Initialized
INFO - 2023-09-13 20:32:26 --> URI Class Initialized
INFO - 2023-09-13 20:32:26 --> Router Class Initialized
INFO - 2023-09-13 20:32:26 --> Output Class Initialized
INFO - 2023-09-13 20:32:26 --> Security Class Initialized
DEBUG - 2023-09-13 20:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:32:26 --> Input Class Initialized
INFO - 2023-09-13 20:32:26 --> Language Class Initialized
ERROR - 2023-09-13 20:32:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:32:27 --> Config Class Initialized
INFO - 2023-09-13 20:32:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:32:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:32:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:32:27 --> URI Class Initialized
INFO - 2023-09-13 20:32:27 --> Router Class Initialized
INFO - 2023-09-13 20:32:27 --> Output Class Initialized
INFO - 2023-09-13 20:32:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:32:27 --> Input Class Initialized
INFO - 2023-09-13 20:32:27 --> Language Class Initialized
ERROR - 2023-09-13 20:32:27 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:32:27 --> Config Class Initialized
INFO - 2023-09-13 20:32:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:32:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:32:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:32:27 --> URI Class Initialized
INFO - 2023-09-13 20:32:27 --> Router Class Initialized
INFO - 2023-09-13 20:32:27 --> Output Class Initialized
INFO - 2023-09-13 20:32:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:32:27 --> Input Class Initialized
INFO - 2023-09-13 20:32:27 --> Language Class Initialized
ERROR - 2023-09-13 20:32:27 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:32:27 --> Config Class Initialized
INFO - 2023-09-13 20:32:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:32:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:32:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:32:27 --> URI Class Initialized
INFO - 2023-09-13 20:32:27 --> Router Class Initialized
INFO - 2023-09-13 20:32:27 --> Output Class Initialized
INFO - 2023-09-13 20:32:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:32:27 --> Input Class Initialized
INFO - 2023-09-13 20:32:27 --> Language Class Initialized
ERROR - 2023-09-13 20:32:27 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:33:25 --> Config Class Initialized
INFO - 2023-09-13 20:33:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:33:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:33:25 --> Utf8 Class Initialized
INFO - 2023-09-13 20:33:25 --> URI Class Initialized
INFO - 2023-09-13 20:33:25 --> Router Class Initialized
INFO - 2023-09-13 20:33:25 --> Output Class Initialized
INFO - 2023-09-13 20:33:25 --> Security Class Initialized
DEBUG - 2023-09-13 20:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:33:25 --> Input Class Initialized
INFO - 2023-09-13 20:33:25 --> Language Class Initialized
INFO - 2023-09-13 20:33:25 --> Loader Class Initialized
INFO - 2023-09-13 20:33:25 --> Helper loaded: url_helper
INFO - 2023-09-13 20:33:25 --> Helper loaded: file_helper
INFO - 2023-09-13 20:33:25 --> Database Driver Class Initialized
INFO - 2023-09-13 20:33:25 --> Email Class Initialized
DEBUG - 2023-09-13 20:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:33:25 --> Controller Class Initialized
INFO - 2023-09-13 20:33:25 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:33:25 --> Model "Home_model" initialized
INFO - 2023-09-13 20:33:25 --> Helper loaded: download_helper
INFO - 2023-09-13 20:33:25 --> Helper loaded: form_helper
INFO - 2023-09-13 20:33:25 --> Form Validation Class Initialized
INFO - 2023-09-13 20:33:25 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:33:25 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:33:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:33:25 --> Final output sent to browser
DEBUG - 2023-09-13 20:33:25 --> Total execution time: 0.2003
INFO - 2023-09-13 20:33:27 --> Config Class Initialized
INFO - 2023-09-13 20:33:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:33:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:33:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:33:27 --> URI Class Initialized
INFO - 2023-09-13 20:33:27 --> Router Class Initialized
INFO - 2023-09-13 20:33:27 --> Output Class Initialized
INFO - 2023-09-13 20:33:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:33:27 --> Input Class Initialized
INFO - 2023-09-13 20:33:27 --> Language Class Initialized
ERROR - 2023-09-13 20:33:27 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:33:27 --> Config Class Initialized
INFO - 2023-09-13 20:33:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:33:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:33:27 --> Utf8 Class Initialized
INFO - 2023-09-13 20:33:27 --> URI Class Initialized
INFO - 2023-09-13 20:33:27 --> Router Class Initialized
INFO - 2023-09-13 20:33:27 --> Output Class Initialized
INFO - 2023-09-13 20:33:27 --> Security Class Initialized
DEBUG - 2023-09-13 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:33:27 --> Input Class Initialized
INFO - 2023-09-13 20:33:27 --> Language Class Initialized
ERROR - 2023-09-13 20:33:27 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-13 20:36:08 --> Config Class Initialized
INFO - 2023-09-13 20:36:08 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:08 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:08 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:08 --> URI Class Initialized
INFO - 2023-09-13 20:36:08 --> Router Class Initialized
INFO - 2023-09-13 20:36:08 --> Output Class Initialized
INFO - 2023-09-13 20:36:08 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:08 --> Input Class Initialized
INFO - 2023-09-13 20:36:08 --> Language Class Initialized
INFO - 2023-09-13 20:36:09 --> Loader Class Initialized
INFO - 2023-09-13 20:36:09 --> Helper loaded: url_helper
INFO - 2023-09-13 20:36:09 --> Helper loaded: file_helper
INFO - 2023-09-13 20:36:09 --> Database Driver Class Initialized
INFO - 2023-09-13 20:36:09 --> Email Class Initialized
DEBUG - 2023-09-13 20:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:36:09 --> Controller Class Initialized
INFO - 2023-09-13 20:36:09 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:36:09 --> Model "Home_model" initialized
INFO - 2023-09-13 20:36:09 --> Helper loaded: download_helper
INFO - 2023-09-13 20:36:09 --> Helper loaded: form_helper
INFO - 2023-09-13 20:36:09 --> Form Validation Class Initialized
INFO - 2023-09-13 20:36:09 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:36:09 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:36:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:36:09 --> Final output sent to browser
DEBUG - 2023-09-13 20:36:09 --> Total execution time: 0.2763
INFO - 2023-09-13 20:36:13 --> Config Class Initialized
INFO - 2023-09-13 20:36:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:13 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:13 --> URI Class Initialized
INFO - 2023-09-13 20:36:13 --> Router Class Initialized
INFO - 2023-09-13 20:36:13 --> Output Class Initialized
INFO - 2023-09-13 20:36:13 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:13 --> Input Class Initialized
INFO - 2023-09-13 20:36:13 --> Language Class Initialized
INFO - 2023-09-13 20:36:13 --> Loader Class Initialized
INFO - 2023-09-13 20:36:13 --> Helper loaded: url_helper
INFO - 2023-09-13 20:36:13 --> Helper loaded: file_helper
INFO - 2023-09-13 20:36:13 --> Database Driver Class Initialized
INFO - 2023-09-13 20:36:13 --> Email Class Initialized
DEBUG - 2023-09-13 20:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:36:13 --> Controller Class Initialized
INFO - 2023-09-13 20:36:13 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:36:13 --> Model "Home_model" initialized
INFO - 2023-09-13 20:36:13 --> Helper loaded: download_helper
INFO - 2023-09-13 20:36:13 --> Helper loaded: form_helper
INFO - 2023-09-13 20:36:13 --> Form Validation Class Initialized
INFO - 2023-09-13 20:36:13 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:36:13 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:36:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:36:13 --> Final output sent to browser
DEBUG - 2023-09-13 20:36:13 --> Total execution time: 0.0628
INFO - 2023-09-13 20:36:31 --> Config Class Initialized
INFO - 2023-09-13 20:36:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:31 --> URI Class Initialized
INFO - 2023-09-13 20:36:31 --> Router Class Initialized
INFO - 2023-09-13 20:36:31 --> Output Class Initialized
INFO - 2023-09-13 20:36:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:31 --> Input Class Initialized
INFO - 2023-09-13 20:36:31 --> Language Class Initialized
ERROR - 2023-09-13 20:36:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:31 --> Config Class Initialized
INFO - 2023-09-13 20:36:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:31 --> URI Class Initialized
INFO - 2023-09-13 20:36:31 --> Router Class Initialized
INFO - 2023-09-13 20:36:31 --> Output Class Initialized
INFO - 2023-09-13 20:36:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:31 --> Input Class Initialized
INFO - 2023-09-13 20:36:31 --> Language Class Initialized
ERROR - 2023-09-13 20:36:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:31 --> Config Class Initialized
INFO - 2023-09-13 20:36:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:31 --> URI Class Initialized
INFO - 2023-09-13 20:36:31 --> Router Class Initialized
INFO - 2023-09-13 20:36:31 --> Output Class Initialized
INFO - 2023-09-13 20:36:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:31 --> Input Class Initialized
INFO - 2023-09-13 20:36:31 --> Language Class Initialized
ERROR - 2023-09-13 20:36:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:31 --> Config Class Initialized
INFO - 2023-09-13 20:36:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:31 --> URI Class Initialized
INFO - 2023-09-13 20:36:31 --> Router Class Initialized
INFO - 2023-09-13 20:36:31 --> Output Class Initialized
INFO - 2023-09-13 20:36:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:31 --> Input Class Initialized
INFO - 2023-09-13 20:36:31 --> Language Class Initialized
ERROR - 2023-09-13 20:36:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:32 --> Config Class Initialized
INFO - 2023-09-13 20:36:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:32 --> URI Class Initialized
INFO - 2023-09-13 20:36:32 --> Router Class Initialized
INFO - 2023-09-13 20:36:32 --> Output Class Initialized
INFO - 2023-09-13 20:36:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:32 --> Input Class Initialized
INFO - 2023-09-13 20:36:32 --> Language Class Initialized
ERROR - 2023-09-13 20:36:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:32 --> Config Class Initialized
INFO - 2023-09-13 20:36:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:32 --> URI Class Initialized
INFO - 2023-09-13 20:36:32 --> Router Class Initialized
INFO - 2023-09-13 20:36:32 --> Output Class Initialized
INFO - 2023-09-13 20:36:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:32 --> Input Class Initialized
INFO - 2023-09-13 20:36:32 --> Language Class Initialized
ERROR - 2023-09-13 20:36:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:36:32 --> Config Class Initialized
INFO - 2023-09-13 20:36:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:36:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:36:32 --> Utf8 Class Initialized
INFO - 2023-09-13 20:36:32 --> URI Class Initialized
INFO - 2023-09-13 20:36:32 --> Router Class Initialized
INFO - 2023-09-13 20:36:32 --> Output Class Initialized
INFO - 2023-09-13 20:36:32 --> Security Class Initialized
DEBUG - 2023-09-13 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:36:32 --> Input Class Initialized
INFO - 2023-09-13 20:36:32 --> Language Class Initialized
ERROR - 2023-09-13 20:36:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:37:36 --> Config Class Initialized
INFO - 2023-09-13 20:37:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:37:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:37:36 --> Utf8 Class Initialized
INFO - 2023-09-13 20:37:36 --> URI Class Initialized
INFO - 2023-09-13 20:37:36 --> Router Class Initialized
INFO - 2023-09-13 20:37:36 --> Output Class Initialized
INFO - 2023-09-13 20:37:36 --> Security Class Initialized
DEBUG - 2023-09-13 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:37:36 --> Input Class Initialized
INFO - 2023-09-13 20:37:36 --> Language Class Initialized
INFO - 2023-09-13 20:37:36 --> Loader Class Initialized
INFO - 2023-09-13 20:37:36 --> Helper loaded: url_helper
INFO - 2023-09-13 20:37:36 --> Helper loaded: file_helper
INFO - 2023-09-13 20:37:36 --> Database Driver Class Initialized
INFO - 2023-09-13 20:37:36 --> Email Class Initialized
DEBUG - 2023-09-13 20:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:37:36 --> Controller Class Initialized
INFO - 2023-09-13 20:37:36 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:37:36 --> Model "Home_model" initialized
INFO - 2023-09-13 20:37:36 --> Helper loaded: download_helper
INFO - 2023-09-13 20:37:36 --> Helper loaded: form_helper
INFO - 2023-09-13 20:37:36 --> Form Validation Class Initialized
INFO - 2023-09-13 20:37:36 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:37:36 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:37:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:37:36 --> Final output sent to browser
DEBUG - 2023-09-13 20:37:36 --> Total execution time: 0.0519
INFO - 2023-09-13 20:37:43 --> Config Class Initialized
INFO - 2023-09-13 20:37:43 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:37:43 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:37:43 --> Utf8 Class Initialized
INFO - 2023-09-13 20:37:43 --> URI Class Initialized
DEBUG - 2023-09-13 20:37:43 --> No URI present. Default controller set.
INFO - 2023-09-13 20:37:43 --> Router Class Initialized
INFO - 2023-09-13 20:37:43 --> Output Class Initialized
INFO - 2023-09-13 20:37:43 --> Security Class Initialized
DEBUG - 2023-09-13 20:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:37:43 --> Input Class Initialized
INFO - 2023-09-13 20:37:43 --> Language Class Initialized
INFO - 2023-09-13 20:37:43 --> Loader Class Initialized
INFO - 2023-09-13 20:37:43 --> Helper loaded: url_helper
INFO - 2023-09-13 20:37:43 --> Helper loaded: file_helper
INFO - 2023-09-13 20:37:43 --> Database Driver Class Initialized
INFO - 2023-09-13 20:37:43 --> Email Class Initialized
DEBUG - 2023-09-13 20:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:37:43 --> Controller Class Initialized
INFO - 2023-09-13 20:37:43 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:37:43 --> Model "Home_model" initialized
INFO - 2023-09-13 20:37:43 --> Helper loaded: download_helper
INFO - 2023-09-13 20:37:43 --> Helper loaded: form_helper
INFO - 2023-09-13 20:37:43 --> Form Validation Class Initialized
INFO - 2023-09-13 20:37:43 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:37:43 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:37:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:37:43 --> Final output sent to browser
DEBUG - 2023-09-13 20:37:43 --> Total execution time: 0.0713
INFO - 2023-09-13 20:37:56 --> Config Class Initialized
INFO - 2023-09-13 20:37:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:37:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:37:56 --> Utf8 Class Initialized
INFO - 2023-09-13 20:37:56 --> URI Class Initialized
INFO - 2023-09-13 20:37:56 --> Router Class Initialized
INFO - 2023-09-13 20:37:56 --> Output Class Initialized
INFO - 2023-09-13 20:37:56 --> Security Class Initialized
DEBUG - 2023-09-13 20:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:37:56 --> Input Class Initialized
INFO - 2023-09-13 20:37:56 --> Language Class Initialized
INFO - 2023-09-13 20:37:56 --> Loader Class Initialized
INFO - 2023-09-13 20:37:56 --> Helper loaded: url_helper
INFO - 2023-09-13 20:37:56 --> Helper loaded: file_helper
INFO - 2023-09-13 20:37:56 --> Database Driver Class Initialized
INFO - 2023-09-13 20:37:56 --> Email Class Initialized
DEBUG - 2023-09-13 20:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:37:56 --> Controller Class Initialized
INFO - 2023-09-13 20:37:56 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:37:56 --> Model "Home_model" initialized
INFO - 2023-09-13 20:37:56 --> Helper loaded: download_helper
INFO - 2023-09-13 20:37:56 --> Helper loaded: form_helper
INFO - 2023-09-13 20:37:56 --> Form Validation Class Initialized
INFO - 2023-09-13 20:37:56 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:37:56 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:37:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-13 20:37:56 --> Final output sent to browser
DEBUG - 2023-09-13 20:37:56 --> Total execution time: 0.1160
INFO - 2023-09-13 20:37:59 --> Config Class Initialized
INFO - 2023-09-13 20:37:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:37:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:37:59 --> Utf8 Class Initialized
INFO - 2023-09-13 20:37:59 --> URI Class Initialized
INFO - 2023-09-13 20:37:59 --> Router Class Initialized
INFO - 2023-09-13 20:37:59 --> Output Class Initialized
INFO - 2023-09-13 20:37:59 --> Security Class Initialized
DEBUG - 2023-09-13 20:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:37:59 --> Input Class Initialized
INFO - 2023-09-13 20:37:59 --> Language Class Initialized
INFO - 2023-09-13 20:37:59 --> Loader Class Initialized
INFO - 2023-09-13 20:37:59 --> Helper loaded: url_helper
INFO - 2023-09-13 20:37:59 --> Helper loaded: file_helper
INFO - 2023-09-13 20:37:59 --> Database Driver Class Initialized
INFO - 2023-09-13 20:37:59 --> Email Class Initialized
DEBUG - 2023-09-13 20:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:37:59 --> Controller Class Initialized
INFO - 2023-09-13 20:37:59 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:37:59 --> Model "Home_model" initialized
INFO - 2023-09-13 20:37:59 --> Helper loaded: download_helper
INFO - 2023-09-13 20:37:59 --> Helper loaded: form_helper
INFO - 2023-09-13 20:37:59 --> Form Validation Class Initialized
INFO - 2023-09-13 20:37:59 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:37:59 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:37:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-13 20:37:59 --> Final output sent to browser
DEBUG - 2023-09-13 20:37:59 --> Total execution time: 0.0706
INFO - 2023-09-13 20:38:01 --> Config Class Initialized
INFO - 2023-09-13 20:38:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:38:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:38:01 --> Utf8 Class Initialized
INFO - 2023-09-13 20:38:01 --> URI Class Initialized
DEBUG - 2023-09-13 20:38:01 --> No URI present. Default controller set.
INFO - 2023-09-13 20:38:01 --> Router Class Initialized
INFO - 2023-09-13 20:38:01 --> Output Class Initialized
INFO - 2023-09-13 20:38:01 --> Security Class Initialized
DEBUG - 2023-09-13 20:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:38:01 --> Input Class Initialized
INFO - 2023-09-13 20:38:01 --> Language Class Initialized
INFO - 2023-09-13 20:38:01 --> Loader Class Initialized
INFO - 2023-09-13 20:38:01 --> Helper loaded: url_helper
INFO - 2023-09-13 20:38:01 --> Helper loaded: file_helper
INFO - 2023-09-13 20:38:01 --> Database Driver Class Initialized
INFO - 2023-09-13 20:38:01 --> Email Class Initialized
DEBUG - 2023-09-13 20:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:38:01 --> Controller Class Initialized
INFO - 2023-09-13 20:38:01 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:38:01 --> Model "Home_model" initialized
INFO - 2023-09-13 20:38:01 --> Helper loaded: download_helper
INFO - 2023-09-13 20:38:01 --> Helper loaded: form_helper
INFO - 2023-09-13 20:38:01 --> Form Validation Class Initialized
INFO - 2023-09-13 20:38:01 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:38:01 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:38:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:38:01 --> Final output sent to browser
DEBUG - 2023-09-13 20:38:01 --> Total execution time: 0.0740
INFO - 2023-09-13 20:42:02 --> Config Class Initialized
INFO - 2023-09-13 20:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:42:02 --> Utf8 Class Initialized
INFO - 2023-09-13 20:42:02 --> URI Class Initialized
INFO - 2023-09-13 20:42:02 --> Router Class Initialized
INFO - 2023-09-13 20:42:02 --> Output Class Initialized
INFO - 2023-09-13 20:42:02 --> Security Class Initialized
DEBUG - 2023-09-13 20:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:42:02 --> Input Class Initialized
INFO - 2023-09-13 20:42:02 --> Language Class Initialized
INFO - 2023-09-13 20:42:02 --> Loader Class Initialized
INFO - 2023-09-13 20:42:02 --> Helper loaded: url_helper
INFO - 2023-09-13 20:42:02 --> Helper loaded: file_helper
INFO - 2023-09-13 20:42:02 --> Database Driver Class Initialized
INFO - 2023-09-13 20:42:02 --> Email Class Initialized
DEBUG - 2023-09-13 20:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:42:02 --> Controller Class Initialized
INFO - 2023-09-13 20:42:02 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:42:02 --> Model "Home_model" initialized
INFO - 2023-09-13 20:42:02 --> Helper loaded: download_helper
INFO - 2023-09-13 20:42:02 --> Helper loaded: form_helper
INFO - 2023-09-13 20:42:02 --> Form Validation Class Initialized
INFO - 2023-09-13 20:42:02 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:42:02 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:42:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-13 20:42:02 --> Final output sent to browser
DEBUG - 2023-09-13 20:42:02 --> Total execution time: 0.2563
INFO - 2023-09-13 20:44:07 --> Config Class Initialized
INFO - 2023-09-13 20:44:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:07 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:07 --> URI Class Initialized
DEBUG - 2023-09-13 20:44:08 --> No URI present. Default controller set.
INFO - 2023-09-13 20:44:08 --> Router Class Initialized
INFO - 2023-09-13 20:44:08 --> Output Class Initialized
INFO - 2023-09-13 20:44:08 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:08 --> Input Class Initialized
INFO - 2023-09-13 20:44:08 --> Language Class Initialized
INFO - 2023-09-13 20:44:08 --> Loader Class Initialized
INFO - 2023-09-13 20:44:08 --> Helper loaded: url_helper
INFO - 2023-09-13 20:44:08 --> Helper loaded: file_helper
INFO - 2023-09-13 20:44:08 --> Database Driver Class Initialized
INFO - 2023-09-13 20:44:08 --> Email Class Initialized
DEBUG - 2023-09-13 20:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:44:08 --> Controller Class Initialized
INFO - 2023-09-13 20:44:08 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:44:08 --> Model "Home_model" initialized
INFO - 2023-09-13 20:44:08 --> Helper loaded: download_helper
INFO - 2023-09-13 20:44:08 --> Helper loaded: form_helper
INFO - 2023-09-13 20:44:08 --> Form Validation Class Initialized
INFO - 2023-09-13 20:44:08 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:44:08 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:44:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:44:08 --> Final output sent to browser
DEBUG - 2023-09-13 20:44:08 --> Total execution time: 0.8858
INFO - 2023-09-13 20:44:19 --> Config Class Initialized
INFO - 2023-09-13 20:44:19 --> Config Class Initialized
INFO - 2023-09-13 20:44:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:19 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:19 --> URI Class Initialized
INFO - 2023-09-13 20:44:19 --> Router Class Initialized
INFO - 2023-09-13 20:44:19 --> Output Class Initialized
INFO - 2023-09-13 20:44:19 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:19 --> Input Class Initialized
INFO - 2023-09-13 20:44:19 --> Language Class Initialized
ERROR - 2023-09-13 20:44:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:44:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:20 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:20 --> URI Class Initialized
INFO - 2023-09-13 20:44:20 --> Router Class Initialized
INFO - 2023-09-13 20:44:20 --> Output Class Initialized
INFO - 2023-09-13 20:44:20 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:20 --> Input Class Initialized
INFO - 2023-09-13 20:44:20 --> Language Class Initialized
ERROR - 2023-09-13 20:44:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:44:20 --> Config Class Initialized
INFO - 2023-09-13 20:44:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:20 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:20 --> URI Class Initialized
INFO - 2023-09-13 20:44:20 --> Router Class Initialized
INFO - 2023-09-13 20:44:20 --> Output Class Initialized
INFO - 2023-09-13 20:44:20 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:20 --> Input Class Initialized
INFO - 2023-09-13 20:44:20 --> Language Class Initialized
ERROR - 2023-09-13 20:44:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:44:21 --> Config Class Initialized
INFO - 2023-09-13 20:44:21 --> Hooks Class Initialized
INFO - 2023-09-13 20:44:21 --> Config Class Initialized
INFO - 2023-09-13 20:44:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:21 --> URI Class Initialized
INFO - 2023-09-13 20:44:21 --> Router Class Initialized
INFO - 2023-09-13 20:44:21 --> Output Class Initialized
INFO - 2023-09-13 20:44:21 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:21 --> Input Class Initialized
INFO - 2023-09-13 20:44:21 --> Language Class Initialized
ERROR - 2023-09-13 20:44:21 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-13 20:44:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:21 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:22 --> URI Class Initialized
INFO - 2023-09-13 20:44:22 --> Router Class Initialized
INFO - 2023-09-13 20:44:22 --> Output Class Initialized
INFO - 2023-09-13 20:44:22 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:22 --> Input Class Initialized
INFO - 2023-09-13 20:44:22 --> Language Class Initialized
ERROR - 2023-09-13 20:44:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:44:23 --> Config Class Initialized
INFO - 2023-09-13 20:44:23 --> Config Class Initialized
INFO - 2023-09-13 20:44:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:23 --> URI Class Initialized
INFO - 2023-09-13 20:44:23 --> Router Class Initialized
INFO - 2023-09-13 20:44:23 --> Output Class Initialized
INFO - 2023-09-13 20:44:23 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:23 --> Input Class Initialized
INFO - 2023-09-13 20:44:23 --> Language Class Initialized
ERROR - 2023-09-13 20:44:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:44:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:44:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:44:23 --> Utf8 Class Initialized
INFO - 2023-09-13 20:44:23 --> URI Class Initialized
INFO - 2023-09-13 20:44:23 --> Router Class Initialized
INFO - 2023-09-13 20:44:23 --> Output Class Initialized
INFO - 2023-09-13 20:44:23 --> Security Class Initialized
DEBUG - 2023-09-13 20:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:44:23 --> Input Class Initialized
INFO - 2023-09-13 20:44:23 --> Language Class Initialized
ERROR - 2023-09-13 20:44:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:48 --> Config Class Initialized
INFO - 2023-09-13 20:45:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:48 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:49 --> URI Class Initialized
DEBUG - 2023-09-13 20:45:49 --> No URI present. Default controller set.
INFO - 2023-09-13 20:45:49 --> Router Class Initialized
INFO - 2023-09-13 20:45:49 --> Output Class Initialized
INFO - 2023-09-13 20:45:49 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:49 --> Input Class Initialized
INFO - 2023-09-13 20:45:49 --> Language Class Initialized
INFO - 2023-09-13 20:45:49 --> Loader Class Initialized
INFO - 2023-09-13 20:45:49 --> Helper loaded: url_helper
INFO - 2023-09-13 20:45:49 --> Helper loaded: file_helper
INFO - 2023-09-13 20:45:49 --> Database Driver Class Initialized
INFO - 2023-09-13 20:45:49 --> Email Class Initialized
DEBUG - 2023-09-13 20:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:45:49 --> Controller Class Initialized
INFO - 2023-09-13 20:45:49 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:45:49 --> Model "Home_model" initialized
INFO - 2023-09-13 20:45:49 --> Helper loaded: download_helper
INFO - 2023-09-13 20:45:49 --> Helper loaded: form_helper
INFO - 2023-09-13 20:45:49 --> Form Validation Class Initialized
INFO - 2023-09-13 20:45:49 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:45:49 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:45:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:45:49 --> Final output sent to browser
DEBUG - 2023-09-13 20:45:49 --> Total execution time: 1.0916
INFO - 2023-09-13 20:45:51 --> Config Class Initialized
INFO - 2023-09-13 20:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:51 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:51 --> URI Class Initialized
INFO - 2023-09-13 20:45:51 --> Router Class Initialized
INFO - 2023-09-13 20:45:51 --> Output Class Initialized
INFO - 2023-09-13 20:45:51 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:51 --> Input Class Initialized
INFO - 2023-09-13 20:45:51 --> Language Class Initialized
ERROR - 2023-09-13 20:45:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:51 --> Config Class Initialized
INFO - 2023-09-13 20:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:51 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:51 --> URI Class Initialized
INFO - 2023-09-13 20:45:51 --> Router Class Initialized
INFO - 2023-09-13 20:45:51 --> Output Class Initialized
INFO - 2023-09-13 20:45:51 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:51 --> Input Class Initialized
INFO - 2023-09-13 20:45:51 --> Language Class Initialized
ERROR - 2023-09-13 20:45:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:51 --> Config Class Initialized
INFO - 2023-09-13 20:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:51 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:51 --> URI Class Initialized
INFO - 2023-09-13 20:45:51 --> Router Class Initialized
INFO - 2023-09-13 20:45:51 --> Output Class Initialized
INFO - 2023-09-13 20:45:51 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:51 --> Input Class Initialized
INFO - 2023-09-13 20:45:51 --> Language Class Initialized
ERROR - 2023-09-13 20:45:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:52 --> Config Class Initialized
INFO - 2023-09-13 20:45:52 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:52 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:52 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:52 --> URI Class Initialized
INFO - 2023-09-13 20:45:52 --> Router Class Initialized
INFO - 2023-09-13 20:45:52 --> Output Class Initialized
INFO - 2023-09-13 20:45:52 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:52 --> Input Class Initialized
INFO - 2023-09-13 20:45:52 --> Language Class Initialized
ERROR - 2023-09-13 20:45:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:52 --> Config Class Initialized
INFO - 2023-09-13 20:45:52 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:52 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:52 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:52 --> URI Class Initialized
INFO - 2023-09-13 20:45:52 --> Router Class Initialized
INFO - 2023-09-13 20:45:52 --> Output Class Initialized
INFO - 2023-09-13 20:45:52 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:52 --> Input Class Initialized
INFO - 2023-09-13 20:45:52 --> Language Class Initialized
ERROR - 2023-09-13 20:45:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:53 --> Config Class Initialized
INFO - 2023-09-13 20:45:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:53 --> URI Class Initialized
INFO - 2023-09-13 20:45:53 --> Router Class Initialized
INFO - 2023-09-13 20:45:53 --> Output Class Initialized
INFO - 2023-09-13 20:45:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:53 --> Input Class Initialized
INFO - 2023-09-13 20:45:53 --> Language Class Initialized
ERROR - 2023-09-13 20:45:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:45:53 --> Config Class Initialized
INFO - 2023-09-13 20:45:53 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:45:53 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:45:53 --> Utf8 Class Initialized
INFO - 2023-09-13 20:45:53 --> URI Class Initialized
INFO - 2023-09-13 20:45:53 --> Router Class Initialized
INFO - 2023-09-13 20:45:53 --> Output Class Initialized
INFO - 2023-09-13 20:45:53 --> Security Class Initialized
DEBUG - 2023-09-13 20:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:45:53 --> Input Class Initialized
INFO - 2023-09-13 20:45:53 --> Language Class Initialized
ERROR - 2023-09-13 20:45:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:29 --> Config Class Initialized
INFO - 2023-09-13 20:46:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:29 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:29 --> URI Class Initialized
DEBUG - 2023-09-13 20:46:29 --> No URI present. Default controller set.
INFO - 2023-09-13 20:46:29 --> Router Class Initialized
INFO - 2023-09-13 20:46:29 --> Output Class Initialized
INFO - 2023-09-13 20:46:29 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:29 --> Input Class Initialized
INFO - 2023-09-13 20:46:29 --> Language Class Initialized
INFO - 2023-09-13 20:46:29 --> Loader Class Initialized
INFO - 2023-09-13 20:46:29 --> Helper loaded: url_helper
INFO - 2023-09-13 20:46:29 --> Helper loaded: file_helper
INFO - 2023-09-13 20:46:29 --> Database Driver Class Initialized
INFO - 2023-09-13 20:46:29 --> Email Class Initialized
DEBUG - 2023-09-13 20:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-13 20:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:46:29 --> Controller Class Initialized
INFO - 2023-09-13 20:46:29 --> Model "Contact_model" initialized
INFO - 2023-09-13 20:46:29 --> Model "Home_model" initialized
INFO - 2023-09-13 20:46:29 --> Helper loaded: download_helper
INFO - 2023-09-13 20:46:29 --> Helper loaded: form_helper
INFO - 2023-09-13 20:46:29 --> Form Validation Class Initialized
INFO - 2023-09-13 20:46:29 --> Helper loaded: custom_helper
INFO - 2023-09-13 20:46:29 --> Model "Social_media_model" initialized
INFO - 2023-09-13 20:46:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-13 20:46:30 --> Final output sent to browser
DEBUG - 2023-09-13 20:46:30 --> Total execution time: 0.2961
INFO - 2023-09-13 20:46:31 --> Config Class Initialized
INFO - 2023-09-13 20:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:31 --> URI Class Initialized
INFO - 2023-09-13 20:46:31 --> Router Class Initialized
INFO - 2023-09-13 20:46:31 --> Output Class Initialized
INFO - 2023-09-13 20:46:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:31 --> Input Class Initialized
INFO - 2023-09-13 20:46:31 --> Language Class Initialized
ERROR - 2023-09-13 20:46:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:31 --> Config Class Initialized
INFO - 2023-09-13 20:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:31 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:31 --> URI Class Initialized
INFO - 2023-09-13 20:46:31 --> Router Class Initialized
INFO - 2023-09-13 20:46:31 --> Output Class Initialized
INFO - 2023-09-13 20:46:31 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:31 --> Input Class Initialized
INFO - 2023-09-13 20:46:31 --> Language Class Initialized
ERROR - 2023-09-13 20:46:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:33 --> Config Class Initialized
INFO - 2023-09-13 20:46:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:33 --> URI Class Initialized
INFO - 2023-09-13 20:46:33 --> Router Class Initialized
INFO - 2023-09-13 20:46:33 --> Output Class Initialized
INFO - 2023-09-13 20:46:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:33 --> Input Class Initialized
INFO - 2023-09-13 20:46:33 --> Language Class Initialized
ERROR - 2023-09-13 20:46:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:33 --> Config Class Initialized
INFO - 2023-09-13 20:46:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:33 --> URI Class Initialized
INFO - 2023-09-13 20:46:33 --> Router Class Initialized
INFO - 2023-09-13 20:46:33 --> Output Class Initialized
INFO - 2023-09-13 20:46:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:33 --> Input Class Initialized
INFO - 2023-09-13 20:46:33 --> Language Class Initialized
ERROR - 2023-09-13 20:46:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:33 --> Config Class Initialized
INFO - 2023-09-13 20:46:33 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:33 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:33 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:33 --> URI Class Initialized
INFO - 2023-09-13 20:46:33 --> Router Class Initialized
INFO - 2023-09-13 20:46:33 --> Output Class Initialized
INFO - 2023-09-13 20:46:33 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:33 --> Input Class Initialized
INFO - 2023-09-13 20:46:33 --> Language Class Initialized
ERROR - 2023-09-13 20:46:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-13 20:46:34 --> Config Class Initialized
INFO - 2023-09-13 20:46:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:46:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:46:34 --> Utf8 Class Initialized
INFO - 2023-09-13 20:46:34 --> URI Class Initialized
INFO - 2023-09-13 20:46:34 --> Router Class Initialized
INFO - 2023-09-13 20:46:34 --> Output Class Initialized
INFO - 2023-09-13 20:46:34 --> Security Class Initialized
DEBUG - 2023-09-13 20:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:46:34 --> Input Class Initialized
INFO - 2023-09-13 20:46:34 --> Language Class Initialized
ERROR - 2023-09-13 20:46:34 --> 404 Page Not Found: Assets/home
