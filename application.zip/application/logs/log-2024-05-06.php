<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-05-06 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 08:51:17 --> No URI present. Default controller set.
DEBUG - 2024-05-06 08:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 08:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:21:18 --> create_captcha(): GD extension is not loaded.
ERROR - 2024-05-06 12:21:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\dw\application\controllers\HomeController.php 825
ERROR - 2024-05-06 12:21:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\dw\application\controllers\HomeController.php 835
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:21:19 --> Total execution time: 2.3131
DEBUG - 2024-05-06 08:59:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 08:59:52 --> No URI present. Default controller set.
DEBUG - 2024-05-06 08:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:29:52 --> create_captcha(): GD extension is not loaded.
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\dw\application\controllers\HomeController.php 825
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\dw\application\controllers\HomeController.php 835
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:29:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:29:52 --> Total execution time: 0.1573
DEBUG - 2024-05-06 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:02:44 --> No URI present. Default controller set.
DEBUG - 2024-05-06 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:32:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:32:44 --> Total execution time: 0.1173
DEBUG - 2024-05-06 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:33:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:33:06 --> Total execution time: 0.1531
DEBUG - 2024-05-06 09:04:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:31 --> Total execution time: 0.1514
DEBUG - 2024-05-06 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:38 --> Total execution time: 0.1418
DEBUG - 2024-05-06 09:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:41 --> Total execution time: 0.1499
DEBUG - 2024-05-06 09:04:46 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:46 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:46 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:46 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:47 --> Total execution time: 0.1113
DEBUG - 2024-05-06 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:53 --> Total execution time: 0.1036
DEBUG - 2024-05-06 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:54 --> Total execution time: 0.0819
DEBUG - 2024-05-06 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:54 --> Total execution time: 0.1004
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:54 --> Total execution time: 0.1509
DEBUG - 2024-05-06 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:34:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:34:59 --> Total execution time: 0.1261
DEBUG - 2024-05-06 09:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:35:06 --> Total execution time: 0.1398
DEBUG - 2024-05-06 09:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-05-06 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-06 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:35:06 --> Total execution time: 0.0992
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:35:06 --> Total execution time: 0.1338
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:35:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:35:06 --> Total execution time: 0.1861
DEBUG - 2024-05-06 09:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:35:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:35:10 --> Total execution time: 0.1093
DEBUG - 2024-05-06 09:06:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:36:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:36:53 --> Total execution time: 0.1778
DEBUG - 2024-05-06 09:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:36:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:36:59 --> Total execution time: 0.1349
DEBUG - 2024-05-06 09:09:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:39:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:39:53 --> Total execution time: 0.0799
DEBUG - 2024-05-06 09:10:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:13 --> Total execution time: 0.0790
DEBUG - 2024-05-06 09:10:14 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:40:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:40:14 --> Total execution time: 0.0801
DEBUG - 2024-05-06 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:27 --> Total execution time: 0.0791
DEBUG - 2024-05-06 09:10:41 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:41 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:41 --> Total execution time: 0.1786
DEBUG - 2024-05-06 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:45 --> Total execution time: 0.0773
DEBUG - 2024-05-06 09:10:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:10:48 --> Total execution time: 0.0887
DEBUG - 2024-05-06 09:10:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:40:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:40:49 --> Total execution time: 0.0985
DEBUG - 2024-05-06 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:40:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:40:57 --> Total execution time: 0.0577
DEBUG - 2024-05-06 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:40:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:40:58 --> Total execution time: 0.0847
DEBUG - 2024-05-06 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:31 --> Total execution time: 0.1378
DEBUG - 2024-05-06 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:32 --> Total execution time: 0.0883
DEBUG - 2024-05-06 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:32 --> Total execution time: 0.0999
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:32 --> Total execution time: 0.1959
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:34 --> Total execution time: 0.0827
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:34 --> Total execution time: 0.0814
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-05-06 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:34 --> Total execution time: 0.2443
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.1786
DEBUG - 2024-05-06 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-06 09:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-05-06 09:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.3547
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-05-06 09:12:35 --> UTF-8 Support Enabled
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-06 09:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.4083
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-06 09:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.5085
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.4351
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.2886
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.3266
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:35 --> Total execution time: 0.2600
DEBUG - 2024-05-06 09:12:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:36 --> Total execution time: 0.1554
DEBUG - 2024-05-06 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:38 --> Total execution time: 0.0785
DEBUG - 2024-05-06 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:38 --> Total execution time: 0.0898
DEBUG - 2024-05-06 09:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:38 --> Total execution time: 0.1347
DEBUG - 2024-05-06 09:12:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:42:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:42:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:42:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:42:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:42:40 --> Total execution time: 0.1363
DEBUG - 2024-05-06 09:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:02 --> Total execution time: 0.1350
DEBUG - 2024-05-06 09:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:02 --> Total execution time: 0.1676
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:02 --> Total execution time: 0.1876
DEBUG - 2024-05-06 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:03 --> Total execution time: 0.2245
DEBUG - 2024-05-06 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:58 --> Total execution time: 0.1356
DEBUG - 2024-05-06 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-06 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-06 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-06 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-05-06 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:58 --> Total execution time: 0.0850
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:58 --> Total execution time: 0.1272
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-06 12:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-06 12:48:58 --> Total execution time: 0.1867
