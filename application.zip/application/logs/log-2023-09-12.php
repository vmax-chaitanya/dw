<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-12 16:25:16 --> Config Class Initialized
INFO - 2023-09-12 16:25:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:16 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:16 --> URI Class Initialized
DEBUG - 2023-09-12 16:25:16 --> No URI present. Default controller set.
INFO - 2023-09-12 16:25:16 --> Router Class Initialized
INFO - 2023-09-12 16:25:16 --> Output Class Initialized
INFO - 2023-09-12 16:25:16 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:16 --> Input Class Initialized
INFO - 2023-09-12 16:25:16 --> Language Class Initialized
INFO - 2023-09-12 16:25:17 --> Loader Class Initialized
INFO - 2023-09-12 16:25:17 --> Helper loaded: url_helper
INFO - 2023-09-12 16:25:17 --> Helper loaded: file_helper
INFO - 2023-09-12 16:25:17 --> Database Driver Class Initialized
INFO - 2023-09-12 16:25:17 --> Email Class Initialized
DEBUG - 2023-09-12 16:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:25:17 --> Controller Class Initialized
INFO - 2023-09-12 16:25:17 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:25:17 --> Model "Home_model" initialized
INFO - 2023-09-12 16:25:17 --> Helper loaded: download_helper
INFO - 2023-09-12 16:25:17 --> Helper loaded: form_helper
INFO - 2023-09-12 16:25:17 --> Form Validation Class Initialized
INFO - 2023-09-12 16:25:17 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:25:17 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:25:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 16:25:18 --> Final output sent to browser
DEBUG - 2023-09-12 16:25:18 --> Total execution time: 1.5912
INFO - 2023-09-12 16:25:29 --> Config Class Initialized
INFO - 2023-09-12 16:25:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:29 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:29 --> URI Class Initialized
INFO - 2023-09-12 16:25:29 --> Router Class Initialized
INFO - 2023-09-12 16:25:29 --> Output Class Initialized
INFO - 2023-09-12 16:25:29 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:29 --> Input Class Initialized
INFO - 2023-09-12 16:25:29 --> Language Class Initialized
INFO - 2023-09-12 16:25:29 --> Loader Class Initialized
INFO - 2023-09-12 16:25:29 --> Helper loaded: url_helper
INFO - 2023-09-12 16:25:29 --> Helper loaded: file_helper
INFO - 2023-09-12 16:25:29 --> Database Driver Class Initialized
INFO - 2023-09-12 16:25:29 --> Email Class Initialized
DEBUG - 2023-09-12 16:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:25:29 --> Controller Class Initialized
INFO - 2023-09-12 16:25:29 --> Config Class Initialized
INFO - 2023-09-12 16:25:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:29 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:29 --> URI Class Initialized
INFO - 2023-09-12 16:25:29 --> Router Class Initialized
INFO - 2023-09-12 16:25:29 --> Output Class Initialized
INFO - 2023-09-12 16:25:29 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:29 --> Input Class Initialized
INFO - 2023-09-12 16:25:29 --> Language Class Initialized
INFO - 2023-09-12 16:25:29 --> Loader Class Initialized
INFO - 2023-09-12 16:25:29 --> Helper loaded: url_helper
INFO - 2023-09-12 16:25:29 --> Helper loaded: file_helper
INFO - 2023-09-12 16:25:29 --> Database Driver Class Initialized
INFO - 2023-09-12 16:25:29 --> Email Class Initialized
DEBUG - 2023-09-12 16:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:25:29 --> Controller Class Initialized
INFO - 2023-09-12 16:25:29 --> Model "User_model" initialized
INFO - 2023-09-12 16:25:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-12 16:25:29 --> Final output sent to browser
DEBUG - 2023-09-12 16:25:29 --> Total execution time: 0.1308
INFO - 2023-09-12 16:25:30 --> Config Class Initialized
INFO - 2023-09-12 16:25:30 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:30 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:30 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:30 --> URI Class Initialized
INFO - 2023-09-12 16:25:30 --> Router Class Initialized
INFO - 2023-09-12 16:25:30 --> Output Class Initialized
INFO - 2023-09-12 16:25:30 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:30 --> Input Class Initialized
INFO - 2023-09-12 16:25:30 --> Language Class Initialized
ERROR - 2023-09-12 16:25:30 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-12 16:25:37 --> Config Class Initialized
INFO - 2023-09-12 16:25:37 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:37 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:37 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:37 --> URI Class Initialized
INFO - 2023-09-12 16:25:37 --> Router Class Initialized
INFO - 2023-09-12 16:25:37 --> Output Class Initialized
INFO - 2023-09-12 16:25:37 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:37 --> Input Class Initialized
INFO - 2023-09-12 16:25:37 --> Language Class Initialized
INFO - 2023-09-12 16:25:37 --> Loader Class Initialized
INFO - 2023-09-12 16:25:37 --> Helper loaded: url_helper
INFO - 2023-09-12 16:25:37 --> Helper loaded: file_helper
INFO - 2023-09-12 16:25:37 --> Database Driver Class Initialized
INFO - 2023-09-12 16:25:37 --> Email Class Initialized
DEBUG - 2023-09-12 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:25:37 --> Controller Class Initialized
INFO - 2023-09-12 16:25:37 --> Model "User_model" initialized
INFO - 2023-09-12 16:25:37 --> Config Class Initialized
INFO - 2023-09-12 16:25:37 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:25:37 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:25:37 --> Utf8 Class Initialized
INFO - 2023-09-12 16:25:37 --> URI Class Initialized
INFO - 2023-09-12 16:25:37 --> Router Class Initialized
INFO - 2023-09-12 16:25:37 --> Output Class Initialized
INFO - 2023-09-12 16:25:37 --> Security Class Initialized
DEBUG - 2023-09-12 16:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:25:37 --> Input Class Initialized
INFO - 2023-09-12 16:25:37 --> Language Class Initialized
INFO - 2023-09-12 16:25:38 --> Loader Class Initialized
INFO - 2023-09-12 16:25:38 --> Helper loaded: url_helper
INFO - 2023-09-12 16:25:38 --> Helper loaded: file_helper
INFO - 2023-09-12 16:25:38 --> Database Driver Class Initialized
INFO - 2023-09-12 16:25:38 --> Email Class Initialized
DEBUG - 2023-09-12 16:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:25:38 --> Controller Class Initialized
INFO - 2023-09-12 16:25:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-12 16:25:38 --> Final output sent to browser
DEBUG - 2023-09-12 16:25:38 --> Total execution time: 0.1932
INFO - 2023-09-12 16:26:01 --> Config Class Initialized
INFO - 2023-09-12 16:26:01 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:01 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:01 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:01 --> URI Class Initialized
INFO - 2023-09-12 16:26:01 --> Router Class Initialized
INFO - 2023-09-12 16:26:01 --> Output Class Initialized
INFO - 2023-09-12 16:26:01 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:01 --> Input Class Initialized
INFO - 2023-09-12 16:26:01 --> Language Class Initialized
INFO - 2023-09-12 16:26:01 --> Loader Class Initialized
INFO - 2023-09-12 16:26:01 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:01 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:01 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:01 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:01 --> Controller Class Initialized
INFO - 2023-09-12 16:26:01 --> Model "Blog_model" initialized
INFO - 2023-09-12 16:26:01 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:01 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-12 16:26:02 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:02 --> Total execution time: 0.6184
INFO - 2023-09-12 16:26:04 --> Config Class Initialized
INFO - 2023-09-12 16:26:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:04 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:04 --> URI Class Initialized
INFO - 2023-09-12 16:26:04 --> Router Class Initialized
INFO - 2023-09-12 16:26:04 --> Output Class Initialized
INFO - 2023-09-12 16:26:04 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:04 --> Input Class Initialized
INFO - 2023-09-12 16:26:04 --> Language Class Initialized
INFO - 2023-09-12 16:26:04 --> Loader Class Initialized
INFO - 2023-09-12 16:26:04 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:04 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:04 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:04 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:04 --> Controller Class Initialized
INFO - 2023-09-12 16:26:04 --> Model "Blog_model" initialized
INFO - 2023-09-12 16:26:04 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:04 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-12 16:26:04 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:04 --> Total execution time: 0.3247
INFO - 2023-09-12 16:26:06 --> Config Class Initialized
INFO - 2023-09-12 16:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:06 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:06 --> URI Class Initialized
INFO - 2023-09-12 16:26:06 --> Router Class Initialized
INFO - 2023-09-12 16:26:06 --> Output Class Initialized
INFO - 2023-09-12 16:26:06 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:06 --> Input Class Initialized
INFO - 2023-09-12 16:26:06 --> Language Class Initialized
INFO - 2023-09-12 16:26:06 --> Loader Class Initialized
INFO - 2023-09-12 16:26:06 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:06 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:06 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:06 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:06 --> Controller Class Initialized
INFO - 2023-09-12 16:26:06 --> Model "Blog_model" initialized
INFO - 2023-09-12 16:26:06 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:06 --> Form Validation Class Initialized
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-09-12 16:26:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-09-12 16:26:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-12 16:26:06 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:06 --> Total execution time: 0.4039
INFO - 2023-09-12 16:26:16 --> Config Class Initialized
INFO - 2023-09-12 16:26:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:16 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:16 --> URI Class Initialized
INFO - 2023-09-12 16:26:16 --> Router Class Initialized
INFO - 2023-09-12 16:26:16 --> Output Class Initialized
INFO - 2023-09-12 16:26:16 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:16 --> Input Class Initialized
INFO - 2023-09-12 16:26:16 --> Language Class Initialized
INFO - 2023-09-12 16:26:16 --> Loader Class Initialized
INFO - 2023-09-12 16:26:16 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:16 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:16 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:16 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:16 --> Controller Class Initialized
INFO - 2023-09-12 16:26:16 --> Model "Blog_model" initialized
INFO - 2023-09-12 16:26:16 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:16 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-12 16:26:16 --> Config Class Initialized
INFO - 2023-09-12 16:26:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:16 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:16 --> URI Class Initialized
INFO - 2023-09-12 16:26:16 --> Router Class Initialized
INFO - 2023-09-12 16:26:16 --> Output Class Initialized
INFO - 2023-09-12 16:26:16 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:16 --> Input Class Initialized
INFO - 2023-09-12 16:26:16 --> Language Class Initialized
INFO - 2023-09-12 16:26:16 --> Loader Class Initialized
INFO - 2023-09-12 16:26:16 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:16 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:16 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:16 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:16 --> Controller Class Initialized
INFO - 2023-09-12 16:26:16 --> Model "Blog_model" initialized
INFO - 2023-09-12 16:26:16 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:16 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-12 16:26:16 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:16 --> Total execution time: 0.0434
INFO - 2023-09-12 16:26:20 --> Config Class Initialized
INFO - 2023-09-12 16:26:20 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:20 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:20 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:20 --> URI Class Initialized
INFO - 2023-09-12 16:26:20 --> Router Class Initialized
INFO - 2023-09-12 16:26:20 --> Output Class Initialized
INFO - 2023-09-12 16:26:20 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:20 --> Input Class Initialized
INFO - 2023-09-12 16:26:20 --> Language Class Initialized
INFO - 2023-09-12 16:26:20 --> Loader Class Initialized
INFO - 2023-09-12 16:26:20 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:20 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:20 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:20 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:20 --> Controller Class Initialized
INFO - 2023-09-12 16:26:20 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:26:20 --> Model "Home_model" initialized
INFO - 2023-09-12 16:26:20 --> Helper loaded: download_helper
INFO - 2023-09-12 16:26:20 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:20 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:20 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:26:20 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:26:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 16:26:20 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:20 --> Total execution time: 0.1866
INFO - 2023-09-12 16:26:25 --> Config Class Initialized
INFO - 2023-09-12 16:26:25 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:25 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:25 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:25 --> URI Class Initialized
INFO - 2023-09-12 16:26:25 --> Router Class Initialized
INFO - 2023-09-12 16:26:25 --> Output Class Initialized
INFO - 2023-09-12 16:26:25 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:25 --> Input Class Initialized
INFO - 2023-09-12 16:26:25 --> Language Class Initialized
INFO - 2023-09-12 16:26:25 --> Loader Class Initialized
INFO - 2023-09-12 16:26:25 --> Helper loaded: url_helper
INFO - 2023-09-12 16:26:25 --> Helper loaded: file_helper
INFO - 2023-09-12 16:26:25 --> Database Driver Class Initialized
INFO - 2023-09-12 16:26:25 --> Email Class Initialized
DEBUG - 2023-09-12 16:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:26:25 --> Controller Class Initialized
INFO - 2023-09-12 16:26:25 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:26:25 --> Model "Home_model" initialized
INFO - 2023-09-12 16:26:25 --> Helper loaded: download_helper
INFO - 2023-09-12 16:26:25 --> Helper loaded: form_helper
INFO - 2023-09-12 16:26:25 --> Form Validation Class Initialized
INFO - 2023-09-12 16:26:25 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:26:25 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:26:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-12 16:26:25 --> Final output sent to browser
DEBUG - 2023-09-12 16:26:25 --> Total execution time: 0.1105
INFO - 2023-09-12 16:26:26 --> Config Class Initialized
INFO - 2023-09-12 16:26:26 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:26 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:26 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:26 --> URI Class Initialized
INFO - 2023-09-12 16:26:26 --> Router Class Initialized
INFO - 2023-09-12 16:26:26 --> Output Class Initialized
INFO - 2023-09-12 16:26:26 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:26 --> Input Class Initialized
INFO - 2023-09-12 16:26:26 --> Language Class Initialized
ERROR - 2023-09-12 16:26:26 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 16:26:26 --> Config Class Initialized
INFO - 2023-09-12 16:26:26 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:26 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:26 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:26 --> URI Class Initialized
INFO - 2023-09-12 16:26:26 --> Router Class Initialized
INFO - 2023-09-12 16:26:26 --> Output Class Initialized
INFO - 2023-09-12 16:26:26 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:26 --> Input Class Initialized
INFO - 2023-09-12 16:26:26 --> Language Class Initialized
ERROR - 2023-09-12 16:26:26 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 16:26:26 --> Config Class Initialized
INFO - 2023-09-12 16:26:26 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:26:26 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:26:26 --> Utf8 Class Initialized
INFO - 2023-09-12 16:26:26 --> URI Class Initialized
INFO - 2023-09-12 16:26:26 --> Router Class Initialized
INFO - 2023-09-12 16:26:26 --> Output Class Initialized
INFO - 2023-09-12 16:26:26 --> Security Class Initialized
DEBUG - 2023-09-12 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:26:26 --> Input Class Initialized
INFO - 2023-09-12 16:26:26 --> Language Class Initialized
ERROR - 2023-09-12 16:26:26 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 16:27:38 --> Config Class Initialized
INFO - 2023-09-12 16:27:38 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:27:38 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:27:38 --> Utf8 Class Initialized
INFO - 2023-09-12 16:27:38 --> URI Class Initialized
INFO - 2023-09-12 16:27:38 --> Router Class Initialized
INFO - 2023-09-12 16:27:38 --> Output Class Initialized
INFO - 2023-09-12 16:27:38 --> Security Class Initialized
DEBUG - 2023-09-12 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:27:38 --> Input Class Initialized
INFO - 2023-09-12 16:27:38 --> Language Class Initialized
INFO - 2023-09-12 16:27:38 --> Loader Class Initialized
INFO - 2023-09-12 16:27:38 --> Helper loaded: url_helper
INFO - 2023-09-12 16:27:38 --> Helper loaded: file_helper
INFO - 2023-09-12 16:27:38 --> Database Driver Class Initialized
INFO - 2023-09-12 16:27:38 --> Email Class Initialized
DEBUG - 2023-09-12 16:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:27:38 --> Controller Class Initialized
INFO - 2023-09-12 16:27:38 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:27:38 --> Model "Home_model" initialized
INFO - 2023-09-12 16:27:38 --> Helper loaded: download_helper
INFO - 2023-09-12 16:27:38 --> Helper loaded: form_helper
INFO - 2023-09-12 16:27:38 --> Form Validation Class Initialized
INFO - 2023-09-12 16:27:38 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:27:38 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:27:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 16:27:38 --> Final output sent to browser
DEBUG - 2023-09-12 16:27:38 --> Total execution time: 0.1106
INFO - 2023-09-12 16:35:39 --> Config Class Initialized
INFO - 2023-09-12 16:35:39 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:35:39 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:35:39 --> Utf8 Class Initialized
INFO - 2023-09-12 16:35:39 --> URI Class Initialized
INFO - 2023-09-12 16:35:39 --> Router Class Initialized
INFO - 2023-09-12 16:35:39 --> Output Class Initialized
INFO - 2023-09-12 16:35:39 --> Security Class Initialized
DEBUG - 2023-09-12 16:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:35:40 --> Input Class Initialized
INFO - 2023-09-12 16:35:40 --> Language Class Initialized
INFO - 2023-09-12 16:35:40 --> Loader Class Initialized
INFO - 2023-09-12 16:35:40 --> Helper loaded: url_helper
INFO - 2023-09-12 16:35:40 --> Helper loaded: file_helper
INFO - 2023-09-12 16:35:40 --> Database Driver Class Initialized
INFO - 2023-09-12 16:35:40 --> Email Class Initialized
DEBUG - 2023-09-12 16:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:35:40 --> Controller Class Initialized
INFO - 2023-09-12 16:35:40 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:35:40 --> Model "Home_model" initialized
INFO - 2023-09-12 16:35:40 --> Helper loaded: download_helper
INFO - 2023-09-12 16:35:40 --> Helper loaded: form_helper
INFO - 2023-09-12 16:35:40 --> Form Validation Class Initialized
INFO - 2023-09-12 16:35:40 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:35:40 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:35:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 16:35:40 --> Final output sent to browser
DEBUG - 2023-09-12 16:35:40 --> Total execution time: 0.3308
INFO - 2023-09-12 16:37:41 --> Config Class Initialized
INFO - 2023-09-12 16:37:41 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:37:41 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:37:41 --> Utf8 Class Initialized
INFO - 2023-09-12 16:37:41 --> URI Class Initialized
INFO - 2023-09-12 16:37:41 --> Router Class Initialized
INFO - 2023-09-12 16:37:41 --> Output Class Initialized
INFO - 2023-09-12 16:37:41 --> Security Class Initialized
DEBUG - 2023-09-12 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:37:41 --> Input Class Initialized
INFO - 2023-09-12 16:37:41 --> Language Class Initialized
INFO - 2023-09-12 16:37:41 --> Loader Class Initialized
INFO - 2023-09-12 16:37:41 --> Helper loaded: url_helper
INFO - 2023-09-12 16:37:41 --> Helper loaded: file_helper
INFO - 2023-09-12 16:37:41 --> Database Driver Class Initialized
INFO - 2023-09-12 16:37:41 --> Email Class Initialized
DEBUG - 2023-09-12 16:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:37:41 --> Controller Class Initialized
INFO - 2023-09-12 16:37:41 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:37:41 --> Model "Home_model" initialized
INFO - 2023-09-12 16:37:41 --> Helper loaded: download_helper
INFO - 2023-09-12 16:37:41 --> Helper loaded: form_helper
INFO - 2023-09-12 16:37:41 --> Form Validation Class Initialized
INFO - 2023-09-12 16:37:41 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:37:41 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:37:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 16:37:41 --> Final output sent to browser
DEBUG - 2023-09-12 16:37:41 --> Total execution time: 0.1546
INFO - 2023-09-12 16:37:51 --> Config Class Initialized
INFO - 2023-09-12 16:37:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:37:51 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:37:51 --> Utf8 Class Initialized
INFO - 2023-09-12 16:37:51 --> URI Class Initialized
INFO - 2023-09-12 16:37:51 --> Router Class Initialized
INFO - 2023-09-12 16:37:51 --> Output Class Initialized
INFO - 2023-09-12 16:37:51 --> Security Class Initialized
DEBUG - 2023-09-12 16:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:37:51 --> Input Class Initialized
INFO - 2023-09-12 16:37:51 --> Language Class Initialized
INFO - 2023-09-12 16:37:51 --> Loader Class Initialized
INFO - 2023-09-12 16:37:51 --> Helper loaded: url_helper
INFO - 2023-09-12 16:37:51 --> Helper loaded: file_helper
INFO - 2023-09-12 16:37:51 --> Database Driver Class Initialized
INFO - 2023-09-12 16:37:51 --> Email Class Initialized
DEBUG - 2023-09-12 16:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:37:51 --> Controller Class Initialized
INFO - 2023-09-12 16:37:51 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:37:51 --> Model "Home_model" initialized
INFO - 2023-09-12 16:37:51 --> Helper loaded: download_helper
INFO - 2023-09-12 16:37:51 --> Helper loaded: form_helper
INFO - 2023-09-12 16:37:51 --> Form Validation Class Initialized
INFO - 2023-09-12 16:37:51 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:37:51 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:37:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/disclamer.php
INFO - 2023-09-12 16:37:51 --> Final output sent to browser
DEBUG - 2023-09-12 16:37:51 --> Total execution time: 0.1250
INFO - 2023-09-12 16:37:57 --> Config Class Initialized
INFO - 2023-09-12 16:37:57 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:37:57 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:37:57 --> Utf8 Class Initialized
INFO - 2023-09-12 16:37:57 --> URI Class Initialized
INFO - 2023-09-12 16:37:57 --> Router Class Initialized
INFO - 2023-09-12 16:37:57 --> Output Class Initialized
INFO - 2023-09-12 16:37:57 --> Security Class Initialized
DEBUG - 2023-09-12 16:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:37:57 --> Input Class Initialized
INFO - 2023-09-12 16:37:57 --> Language Class Initialized
INFO - 2023-09-12 16:37:57 --> Loader Class Initialized
INFO - 2023-09-12 16:37:57 --> Helper loaded: url_helper
INFO - 2023-09-12 16:37:57 --> Helper loaded: file_helper
INFO - 2023-09-12 16:37:58 --> Database Driver Class Initialized
INFO - 2023-09-12 16:37:58 --> Email Class Initialized
DEBUG - 2023-09-12 16:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:37:58 --> Controller Class Initialized
INFO - 2023-09-12 16:37:58 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:37:58 --> Model "Home_model" initialized
INFO - 2023-09-12 16:37:58 --> Helper loaded: download_helper
INFO - 2023-09-12 16:37:58 --> Helper loaded: form_helper
INFO - 2023-09-12 16:37:58 --> Form Validation Class Initialized
INFO - 2023-09-12 16:37:58 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:37:58 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:37:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/privacy_policy.php
INFO - 2023-09-12 16:37:58 --> Final output sent to browser
DEBUG - 2023-09-12 16:37:58 --> Total execution time: 0.1304
INFO - 2023-09-12 16:40:05 --> Config Class Initialized
INFO - 2023-09-12 16:40:05 --> Hooks Class Initialized
DEBUG - 2023-09-12 16:40:05 --> UTF-8 Support Enabled
INFO - 2023-09-12 16:40:05 --> Utf8 Class Initialized
INFO - 2023-09-12 16:40:05 --> URI Class Initialized
DEBUG - 2023-09-12 16:40:05 --> No URI present. Default controller set.
INFO - 2023-09-12 16:40:05 --> Router Class Initialized
INFO - 2023-09-12 16:40:05 --> Output Class Initialized
INFO - 2023-09-12 16:40:05 --> Security Class Initialized
DEBUG - 2023-09-12 16:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 16:40:05 --> Input Class Initialized
INFO - 2023-09-12 16:40:05 --> Language Class Initialized
INFO - 2023-09-12 16:40:06 --> Loader Class Initialized
INFO - 2023-09-12 16:40:06 --> Helper loaded: url_helper
INFO - 2023-09-12 16:40:06 --> Helper loaded: file_helper
INFO - 2023-09-12 16:40:06 --> Database Driver Class Initialized
INFO - 2023-09-12 16:40:06 --> Email Class Initialized
DEBUG - 2023-09-12 16:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 16:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 16:40:06 --> Controller Class Initialized
INFO - 2023-09-12 16:40:06 --> Model "Contact_model" initialized
INFO - 2023-09-12 16:40:06 --> Model "Home_model" initialized
INFO - 2023-09-12 16:40:06 --> Helper loaded: download_helper
INFO - 2023-09-12 16:40:06 --> Helper loaded: form_helper
INFO - 2023-09-12 16:40:06 --> Form Validation Class Initialized
INFO - 2023-09-12 16:40:06 --> Helper loaded: custom_helper
INFO - 2023-09-12 16:40:06 --> Model "Social_media_model" initialized
INFO - 2023-09-12 16:40:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 16:40:06 --> Final output sent to browser
DEBUG - 2023-09-12 16:40:06 --> Total execution time: 0.3194
INFO - 2023-09-12 17:59:24 --> Config Class Initialized
INFO - 2023-09-12 17:59:24 --> Hooks Class Initialized
DEBUG - 2023-09-12 17:59:24 --> UTF-8 Support Enabled
INFO - 2023-09-12 17:59:24 --> Utf8 Class Initialized
INFO - 2023-09-12 17:59:24 --> URI Class Initialized
DEBUG - 2023-09-12 17:59:24 --> No URI present. Default controller set.
INFO - 2023-09-12 17:59:24 --> Router Class Initialized
INFO - 2023-09-12 17:59:24 --> Output Class Initialized
INFO - 2023-09-12 17:59:24 --> Security Class Initialized
DEBUG - 2023-09-12 17:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 17:59:24 --> Input Class Initialized
INFO - 2023-09-12 17:59:25 --> Language Class Initialized
INFO - 2023-09-12 17:59:25 --> Loader Class Initialized
INFO - 2023-09-12 17:59:25 --> Helper loaded: url_helper
INFO - 2023-09-12 17:59:25 --> Helper loaded: file_helper
INFO - 2023-09-12 17:59:25 --> Database Driver Class Initialized
INFO - 2023-09-12 17:59:25 --> Email Class Initialized
DEBUG - 2023-09-12 17:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 17:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 17:59:25 --> Controller Class Initialized
INFO - 2023-09-12 17:59:25 --> Model "Contact_model" initialized
INFO - 2023-09-12 17:59:25 --> Model "Home_model" initialized
INFO - 2023-09-12 17:59:25 --> Helper loaded: download_helper
INFO - 2023-09-12 17:59:26 --> Helper loaded: form_helper
INFO - 2023-09-12 17:59:26 --> Form Validation Class Initialized
INFO - 2023-09-12 17:59:26 --> Helper loaded: custom_helper
INFO - 2023-09-12 17:59:26 --> Model "Social_media_model" initialized
INFO - 2023-09-12 17:59:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 17:59:26 --> Final output sent to browser
DEBUG - 2023-09-12 17:59:26 --> Total execution time: 2.0583
INFO - 2023-09-12 17:59:29 --> Config Class Initialized
INFO - 2023-09-12 17:59:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 17:59:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 17:59:29 --> Utf8 Class Initialized
INFO - 2023-09-12 17:59:30 --> URI Class Initialized
INFO - 2023-09-12 17:59:30 --> Router Class Initialized
INFO - 2023-09-12 17:59:30 --> Output Class Initialized
INFO - 2023-09-12 17:59:30 --> Security Class Initialized
DEBUG - 2023-09-12 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 17:59:30 --> Input Class Initialized
INFO - 2023-09-12 17:59:30 --> Language Class Initialized
ERROR - 2023-09-12 17:59:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 18:00:38 --> Config Class Initialized
INFO - 2023-09-12 18:00:38 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:00:38 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:00:38 --> Utf8 Class Initialized
INFO - 2023-09-12 18:00:38 --> URI Class Initialized
DEBUG - 2023-09-12 18:00:38 --> No URI present. Default controller set.
INFO - 2023-09-12 18:00:38 --> Router Class Initialized
INFO - 2023-09-12 18:00:38 --> Output Class Initialized
INFO - 2023-09-12 18:00:38 --> Security Class Initialized
DEBUG - 2023-09-12 18:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:00:38 --> Input Class Initialized
INFO - 2023-09-12 18:00:38 --> Language Class Initialized
INFO - 2023-09-12 18:00:38 --> Loader Class Initialized
INFO - 2023-09-12 18:00:38 --> Helper loaded: url_helper
INFO - 2023-09-12 18:00:38 --> Helper loaded: file_helper
INFO - 2023-09-12 18:00:38 --> Database Driver Class Initialized
INFO - 2023-09-12 18:00:38 --> Email Class Initialized
DEBUG - 2023-09-12 18:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:00:38 --> Controller Class Initialized
INFO - 2023-09-12 18:00:38 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:00:38 --> Model "Home_model" initialized
INFO - 2023-09-12 18:00:38 --> Helper loaded: download_helper
INFO - 2023-09-12 18:00:38 --> Helper loaded: form_helper
INFO - 2023-09-12 18:00:38 --> Form Validation Class Initialized
INFO - 2023-09-12 18:00:38 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:00:38 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:00:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:00:38 --> Final output sent to browser
DEBUG - 2023-09-12 18:00:38 --> Total execution time: 0.5010
INFO - 2023-09-12 18:01:52 --> Config Class Initialized
INFO - 2023-09-12 18:01:52 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:01:52 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:01:52 --> Utf8 Class Initialized
INFO - 2023-09-12 18:01:52 --> URI Class Initialized
DEBUG - 2023-09-12 18:01:52 --> No URI present. Default controller set.
INFO - 2023-09-12 18:01:52 --> Router Class Initialized
INFO - 2023-09-12 18:01:52 --> Output Class Initialized
INFO - 2023-09-12 18:01:52 --> Security Class Initialized
DEBUG - 2023-09-12 18:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:01:52 --> Input Class Initialized
INFO - 2023-09-12 18:01:52 --> Language Class Initialized
INFO - 2023-09-12 18:01:52 --> Loader Class Initialized
INFO - 2023-09-12 18:01:52 --> Helper loaded: url_helper
INFO - 2023-09-12 18:01:52 --> Helper loaded: file_helper
INFO - 2023-09-12 18:01:52 --> Database Driver Class Initialized
INFO - 2023-09-12 18:01:52 --> Email Class Initialized
DEBUG - 2023-09-12 18:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:01:52 --> Controller Class Initialized
INFO - 2023-09-12 18:01:52 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:01:52 --> Model "Home_model" initialized
INFO - 2023-09-12 18:01:52 --> Helper loaded: download_helper
INFO - 2023-09-12 18:01:52 --> Helper loaded: form_helper
INFO - 2023-09-12 18:01:52 --> Form Validation Class Initialized
INFO - 2023-09-12 18:01:52 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:01:52 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:01:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:01:52 --> Final output sent to browser
DEBUG - 2023-09-12 18:01:52 --> Total execution time: 0.1792
INFO - 2023-09-12 18:13:00 --> Config Class Initialized
INFO - 2023-09-12 18:13:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:13:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:13:00 --> Utf8 Class Initialized
INFO - 2023-09-12 18:13:00 --> URI Class Initialized
DEBUG - 2023-09-12 18:13:00 --> No URI present. Default controller set.
INFO - 2023-09-12 18:13:00 --> Router Class Initialized
INFO - 2023-09-12 18:13:00 --> Output Class Initialized
INFO - 2023-09-12 18:13:00 --> Security Class Initialized
DEBUG - 2023-09-12 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:13:00 --> Input Class Initialized
INFO - 2023-09-12 18:13:00 --> Language Class Initialized
INFO - 2023-09-12 18:13:00 --> Loader Class Initialized
INFO - 2023-09-12 18:13:00 --> Helper loaded: url_helper
INFO - 2023-09-12 18:13:00 --> Helper loaded: file_helper
INFO - 2023-09-12 18:13:00 --> Database Driver Class Initialized
INFO - 2023-09-12 18:13:00 --> Email Class Initialized
DEBUG - 2023-09-12 18:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:13:01 --> Controller Class Initialized
INFO - 2023-09-12 18:13:01 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:13:01 --> Model "Home_model" initialized
INFO - 2023-09-12 18:13:01 --> Helper loaded: download_helper
INFO - 2023-09-12 18:13:01 --> Helper loaded: form_helper
INFO - 2023-09-12 18:13:01 --> Form Validation Class Initialized
INFO - 2023-09-12 18:13:01 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:13:01 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:13:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:13:01 --> Final output sent to browser
DEBUG - 2023-09-12 18:13:01 --> Total execution time: 0.2816
INFO - 2023-09-12 18:16:07 --> Config Class Initialized
INFO - 2023-09-12 18:16:07 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:16:07 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:16:07 --> Utf8 Class Initialized
INFO - 2023-09-12 18:16:07 --> URI Class Initialized
DEBUG - 2023-09-12 18:16:07 --> No URI present. Default controller set.
INFO - 2023-09-12 18:16:07 --> Router Class Initialized
INFO - 2023-09-12 18:16:07 --> Output Class Initialized
INFO - 2023-09-12 18:16:07 --> Security Class Initialized
DEBUG - 2023-09-12 18:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:16:08 --> Input Class Initialized
INFO - 2023-09-12 18:16:08 --> Language Class Initialized
INFO - 2023-09-12 18:16:08 --> Loader Class Initialized
INFO - 2023-09-12 18:16:08 --> Helper loaded: url_helper
INFO - 2023-09-12 18:16:08 --> Helper loaded: file_helper
INFO - 2023-09-12 18:16:08 --> Database Driver Class Initialized
INFO - 2023-09-12 18:16:08 --> Email Class Initialized
DEBUG - 2023-09-12 18:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:16:08 --> Controller Class Initialized
INFO - 2023-09-12 18:16:08 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:16:08 --> Model "Home_model" initialized
INFO - 2023-09-12 18:16:08 --> Helper loaded: download_helper
INFO - 2023-09-12 18:16:08 --> Helper loaded: form_helper
INFO - 2023-09-12 18:16:08 --> Form Validation Class Initialized
INFO - 2023-09-12 18:16:08 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:16:08 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:16:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:16:08 --> Final output sent to browser
DEBUG - 2023-09-12 18:16:08 --> Total execution time: 0.1365
INFO - 2023-09-12 18:21:07 --> Config Class Initialized
INFO - 2023-09-12 18:21:07 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:21:07 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:21:07 --> Utf8 Class Initialized
INFO - 2023-09-12 18:21:07 --> URI Class Initialized
DEBUG - 2023-09-12 18:21:07 --> No URI present. Default controller set.
INFO - 2023-09-12 18:21:07 --> Router Class Initialized
INFO - 2023-09-12 18:21:07 --> Output Class Initialized
INFO - 2023-09-12 18:21:07 --> Security Class Initialized
DEBUG - 2023-09-12 18:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:21:07 --> Input Class Initialized
INFO - 2023-09-12 18:21:07 --> Language Class Initialized
INFO - 2023-09-12 18:21:07 --> Loader Class Initialized
INFO - 2023-09-12 18:21:07 --> Helper loaded: url_helper
INFO - 2023-09-12 18:21:07 --> Helper loaded: file_helper
INFO - 2023-09-12 18:21:07 --> Database Driver Class Initialized
INFO - 2023-09-12 18:21:07 --> Email Class Initialized
DEBUG - 2023-09-12 18:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:21:07 --> Controller Class Initialized
INFO - 2023-09-12 18:21:07 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:21:07 --> Model "Home_model" initialized
INFO - 2023-09-12 18:21:07 --> Helper loaded: download_helper
INFO - 2023-09-12 18:21:07 --> Helper loaded: form_helper
INFO - 2023-09-12 18:21:07 --> Form Validation Class Initialized
INFO - 2023-09-12 18:21:07 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:21:07 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:21:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:21:07 --> Final output sent to browser
DEBUG - 2023-09-12 18:21:07 --> Total execution time: 0.1706
INFO - 2023-09-12 18:22:07 --> Config Class Initialized
INFO - 2023-09-12 18:22:07 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:22:07 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:22:07 --> Utf8 Class Initialized
INFO - 2023-09-12 18:22:07 --> URI Class Initialized
DEBUG - 2023-09-12 18:22:07 --> No URI present. Default controller set.
INFO - 2023-09-12 18:22:07 --> Router Class Initialized
INFO - 2023-09-12 18:22:07 --> Output Class Initialized
INFO - 2023-09-12 18:22:07 --> Security Class Initialized
DEBUG - 2023-09-12 18:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:22:07 --> Input Class Initialized
INFO - 2023-09-12 18:22:07 --> Language Class Initialized
INFO - 2023-09-12 18:22:07 --> Loader Class Initialized
INFO - 2023-09-12 18:22:07 --> Helper loaded: url_helper
INFO - 2023-09-12 18:22:07 --> Helper loaded: file_helper
INFO - 2023-09-12 18:22:07 --> Database Driver Class Initialized
INFO - 2023-09-12 18:22:07 --> Email Class Initialized
DEBUG - 2023-09-12 18:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:22:07 --> Controller Class Initialized
INFO - 2023-09-12 18:22:07 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:22:07 --> Model "Home_model" initialized
INFO - 2023-09-12 18:22:07 --> Helper loaded: download_helper
INFO - 2023-09-12 18:22:07 --> Helper loaded: form_helper
INFO - 2023-09-12 18:22:07 --> Form Validation Class Initialized
INFO - 2023-09-12 18:22:07 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:22:07 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:22:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:22:07 --> Final output sent to browser
DEBUG - 2023-09-12 18:22:07 --> Total execution time: 0.1916
INFO - 2023-09-12 18:22:08 --> Config Class Initialized
INFO - 2023-09-12 18:22:08 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:22:08 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:22:08 --> Utf8 Class Initialized
INFO - 2023-09-12 18:22:08 --> URI Class Initialized
INFO - 2023-09-12 18:22:08 --> Router Class Initialized
INFO - 2023-09-12 18:22:08 --> Output Class Initialized
INFO - 2023-09-12 18:22:08 --> Security Class Initialized
DEBUG - 2023-09-12 18:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:22:08 --> Input Class Initialized
INFO - 2023-09-12 18:22:08 --> Language Class Initialized
ERROR - 2023-09-12 18:22:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 18:22:19 --> Config Class Initialized
INFO - 2023-09-12 18:22:19 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:22:19 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:22:19 --> Utf8 Class Initialized
INFO - 2023-09-12 18:22:19 --> URI Class Initialized
DEBUG - 2023-09-12 18:22:19 --> No URI present. Default controller set.
INFO - 2023-09-12 18:22:19 --> Router Class Initialized
INFO - 2023-09-12 18:22:19 --> Output Class Initialized
INFO - 2023-09-12 18:22:20 --> Security Class Initialized
DEBUG - 2023-09-12 18:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:22:20 --> Input Class Initialized
INFO - 2023-09-12 18:22:20 --> Language Class Initialized
INFO - 2023-09-12 18:22:20 --> Loader Class Initialized
INFO - 2023-09-12 18:22:20 --> Helper loaded: url_helper
INFO - 2023-09-12 18:22:20 --> Helper loaded: file_helper
INFO - 2023-09-12 18:22:20 --> Database Driver Class Initialized
INFO - 2023-09-12 18:22:20 --> Email Class Initialized
DEBUG - 2023-09-12 18:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:22:20 --> Controller Class Initialized
INFO - 2023-09-12 18:22:20 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:22:20 --> Model "Home_model" initialized
INFO - 2023-09-12 18:22:20 --> Helper loaded: download_helper
INFO - 2023-09-12 18:22:20 --> Helper loaded: form_helper
INFO - 2023-09-12 18:22:20 --> Form Validation Class Initialized
INFO - 2023-09-12 18:22:20 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:22:20 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:22:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:22:20 --> Final output sent to browser
DEBUG - 2023-09-12 18:22:20 --> Total execution time: 0.1803
INFO - 2023-09-12 18:23:47 --> Config Class Initialized
INFO - 2023-09-12 18:23:47 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:23:47 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:23:47 --> Utf8 Class Initialized
INFO - 2023-09-12 18:23:47 --> URI Class Initialized
DEBUG - 2023-09-12 18:23:47 --> No URI present. Default controller set.
INFO - 2023-09-12 18:23:47 --> Router Class Initialized
INFO - 2023-09-12 18:23:47 --> Output Class Initialized
INFO - 2023-09-12 18:23:47 --> Security Class Initialized
DEBUG - 2023-09-12 18:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:23:47 --> Input Class Initialized
INFO - 2023-09-12 18:23:47 --> Language Class Initialized
INFO - 2023-09-12 18:23:47 --> Loader Class Initialized
INFO - 2023-09-12 18:23:47 --> Helper loaded: url_helper
INFO - 2023-09-12 18:23:47 --> Helper loaded: file_helper
INFO - 2023-09-12 18:23:47 --> Database Driver Class Initialized
INFO - 2023-09-12 18:23:47 --> Email Class Initialized
DEBUG - 2023-09-12 18:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:23:47 --> Controller Class Initialized
INFO - 2023-09-12 18:23:47 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:23:47 --> Model "Home_model" initialized
INFO - 2023-09-12 18:23:47 --> Helper loaded: download_helper
INFO - 2023-09-12 18:23:47 --> Helper loaded: form_helper
INFO - 2023-09-12 18:23:47 --> Form Validation Class Initialized
INFO - 2023-09-12 18:23:47 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:23:47 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:23:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:23:47 --> Final output sent to browser
DEBUG - 2023-09-12 18:23:47 --> Total execution time: 0.4803
INFO - 2023-09-12 18:31:39 --> Config Class Initialized
INFO - 2023-09-12 18:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-12 18:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-12 18:31:39 --> Utf8 Class Initialized
INFO - 2023-09-12 18:31:39 --> URI Class Initialized
DEBUG - 2023-09-12 18:31:39 --> No URI present. Default controller set.
INFO - 2023-09-12 18:31:39 --> Router Class Initialized
INFO - 2023-09-12 18:31:39 --> Output Class Initialized
INFO - 2023-09-12 18:31:39 --> Security Class Initialized
DEBUG - 2023-09-12 18:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 18:31:39 --> Input Class Initialized
INFO - 2023-09-12 18:31:39 --> Language Class Initialized
INFO - 2023-09-12 18:31:39 --> Loader Class Initialized
INFO - 2023-09-12 18:31:39 --> Helper loaded: url_helper
INFO - 2023-09-12 18:31:39 --> Helper loaded: file_helper
INFO - 2023-09-12 18:31:39 --> Database Driver Class Initialized
INFO - 2023-09-12 18:31:39 --> Email Class Initialized
DEBUG - 2023-09-12 18:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 18:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 18:31:39 --> Controller Class Initialized
INFO - 2023-09-12 18:31:39 --> Model "Contact_model" initialized
INFO - 2023-09-12 18:31:39 --> Model "Home_model" initialized
INFO - 2023-09-12 18:31:39 --> Helper loaded: download_helper
INFO - 2023-09-12 18:31:39 --> Helper loaded: form_helper
INFO - 2023-09-12 18:31:39 --> Form Validation Class Initialized
INFO - 2023-09-12 18:31:39 --> Helper loaded: custom_helper
INFO - 2023-09-12 18:31:39 --> Model "Social_media_model" initialized
INFO - 2023-09-12 18:31:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 18:31:39 --> Final output sent to browser
DEBUG - 2023-09-12 18:31:39 --> Total execution time: 0.2156
INFO - 2023-09-12 19:06:12 --> Config Class Initialized
INFO - 2023-09-12 19:06:12 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:06:12 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:06:12 --> Utf8 Class Initialized
INFO - 2023-09-12 19:06:12 --> URI Class Initialized
DEBUG - 2023-09-12 19:06:12 --> No URI present. Default controller set.
INFO - 2023-09-12 19:06:12 --> Router Class Initialized
INFO - 2023-09-12 19:06:12 --> Output Class Initialized
INFO - 2023-09-12 19:06:12 --> Security Class Initialized
DEBUG - 2023-09-12 19:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:06:12 --> Input Class Initialized
INFO - 2023-09-12 19:06:12 --> Language Class Initialized
INFO - 2023-09-12 19:06:12 --> Loader Class Initialized
INFO - 2023-09-12 19:06:12 --> Helper loaded: url_helper
INFO - 2023-09-12 19:06:12 --> Helper loaded: file_helper
INFO - 2023-09-12 19:06:12 --> Database Driver Class Initialized
INFO - 2023-09-12 19:06:12 --> Email Class Initialized
DEBUG - 2023-09-12 19:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:06:12 --> Controller Class Initialized
INFO - 2023-09-12 19:06:12 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:06:12 --> Model "Home_model" initialized
INFO - 2023-09-12 19:06:13 --> Helper loaded: download_helper
INFO - 2023-09-12 19:06:13 --> Helper loaded: form_helper
INFO - 2023-09-12 19:06:13 --> Form Validation Class Initialized
INFO - 2023-09-12 19:06:13 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:06:13 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:06:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:06:13 --> Final output sent to browser
DEBUG - 2023-09-12 19:06:13 --> Total execution time: 0.5489
INFO - 2023-09-12 19:07:04 --> Config Class Initialized
INFO - 2023-09-12 19:07:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:07:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:07:04 --> Utf8 Class Initialized
INFO - 2023-09-12 19:07:04 --> URI Class Initialized
DEBUG - 2023-09-12 19:07:04 --> No URI present. Default controller set.
INFO - 2023-09-12 19:07:04 --> Router Class Initialized
INFO - 2023-09-12 19:07:04 --> Output Class Initialized
INFO - 2023-09-12 19:07:04 --> Security Class Initialized
DEBUG - 2023-09-12 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:07:04 --> Input Class Initialized
INFO - 2023-09-12 19:07:04 --> Language Class Initialized
INFO - 2023-09-12 19:07:04 --> Loader Class Initialized
INFO - 2023-09-12 19:07:04 --> Helper loaded: url_helper
INFO - 2023-09-12 19:07:04 --> Helper loaded: file_helper
INFO - 2023-09-12 19:07:04 --> Database Driver Class Initialized
INFO - 2023-09-12 19:07:04 --> Email Class Initialized
DEBUG - 2023-09-12 19:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:07:04 --> Controller Class Initialized
INFO - 2023-09-12 19:07:05 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:07:05 --> Model "Home_model" initialized
INFO - 2023-09-12 19:07:05 --> Helper loaded: download_helper
INFO - 2023-09-12 19:07:05 --> Helper loaded: form_helper
INFO - 2023-09-12 19:07:05 --> Form Validation Class Initialized
INFO - 2023-09-12 19:07:05 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:07:05 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:07:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:07:05 --> Final output sent to browser
DEBUG - 2023-09-12 19:07:05 --> Total execution time: 0.5293
INFO - 2023-09-12 19:09:04 --> Config Class Initialized
INFO - 2023-09-12 19:09:04 --> Config Class Initialized
INFO - 2023-09-12 19:09:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:04 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:04 --> URI Class Initialized
INFO - 2023-09-12 19:09:04 --> Router Class Initialized
INFO - 2023-09-12 19:09:04 --> Output Class Initialized
INFO - 2023-09-12 19:09:04 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:04 --> Input Class Initialized
INFO - 2023-09-12 19:09:04 --> Language Class Initialized
ERROR - 2023-09-12 19:09:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:09:04 --> Hooks Class Initialized
INFO - 2023-09-12 19:09:04 --> Config Class Initialized
INFO - 2023-09-12 19:09:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:04 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:04 --> URI Class Initialized
INFO - 2023-09-12 19:09:04 --> Router Class Initialized
INFO - 2023-09-12 19:09:04 --> Output Class Initialized
INFO - 2023-09-12 19:09:04 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:04 --> Input Class Initialized
INFO - 2023-09-12 19:09:04 --> Language Class Initialized
ERROR - 2023-09-12 19:09:04 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-12 19:09:05 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:05 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:05 --> URI Class Initialized
INFO - 2023-09-12 19:09:05 --> Router Class Initialized
INFO - 2023-09-12 19:09:05 --> Output Class Initialized
INFO - 2023-09-12 19:09:05 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:05 --> Input Class Initialized
INFO - 2023-09-12 19:09:05 --> Language Class Initialized
ERROR - 2023-09-12 19:09:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:09:06 --> Config Class Initialized
INFO - 2023-09-12 19:09:06 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:06 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:06 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:06 --> URI Class Initialized
INFO - 2023-09-12 19:09:06 --> Router Class Initialized
INFO - 2023-09-12 19:09:06 --> Output Class Initialized
INFO - 2023-09-12 19:09:06 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:06 --> Input Class Initialized
INFO - 2023-09-12 19:09:06 --> Language Class Initialized
ERROR - 2023-09-12 19:09:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:09:06 --> Config Class Initialized
INFO - 2023-09-12 19:09:06 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:06 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:07 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:07 --> URI Class Initialized
INFO - 2023-09-12 19:09:07 --> Router Class Initialized
INFO - 2023-09-12 19:09:07 --> Output Class Initialized
INFO - 2023-09-12 19:09:07 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:07 --> Input Class Initialized
INFO - 2023-09-12 19:09:07 --> Language Class Initialized
ERROR - 2023-09-12 19:09:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:09:07 --> Config Class Initialized
INFO - 2023-09-12 19:09:08 --> Config Class Initialized
INFO - 2023-09-12 19:09:08 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:08 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:08 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:08 --> URI Class Initialized
INFO - 2023-09-12 19:09:08 --> Router Class Initialized
INFO - 2023-09-12 19:09:08 --> Output Class Initialized
INFO - 2023-09-12 19:09:08 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:08 --> Input Class Initialized
INFO - 2023-09-12 19:09:08 --> Language Class Initialized
ERROR - 2023-09-12 19:09:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:09:08 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:09:08 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:09:08 --> Utf8 Class Initialized
INFO - 2023-09-12 19:09:08 --> URI Class Initialized
INFO - 2023-09-12 19:09:08 --> Router Class Initialized
INFO - 2023-09-12 19:09:08 --> Output Class Initialized
INFO - 2023-09-12 19:09:08 --> Security Class Initialized
DEBUG - 2023-09-12 19:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:09:08 --> Input Class Initialized
INFO - 2023-09-12 19:09:08 --> Language Class Initialized
ERROR - 2023-09-12 19:09:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:14:46 --> Config Class Initialized
INFO - 2023-09-12 19:14:46 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:14:46 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:14:46 --> Utf8 Class Initialized
INFO - 2023-09-12 19:14:46 --> URI Class Initialized
DEBUG - 2023-09-12 19:14:46 --> No URI present. Default controller set.
INFO - 2023-09-12 19:14:46 --> Router Class Initialized
INFO - 2023-09-12 19:14:46 --> Output Class Initialized
INFO - 2023-09-12 19:14:46 --> Security Class Initialized
DEBUG - 2023-09-12 19:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:14:46 --> Input Class Initialized
INFO - 2023-09-12 19:14:46 --> Language Class Initialized
INFO - 2023-09-12 19:14:46 --> Loader Class Initialized
INFO - 2023-09-12 19:14:46 --> Helper loaded: url_helper
INFO - 2023-09-12 19:14:46 --> Helper loaded: file_helper
INFO - 2023-09-12 19:14:46 --> Database Driver Class Initialized
INFO - 2023-09-12 19:14:46 --> Email Class Initialized
DEBUG - 2023-09-12 19:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:14:46 --> Controller Class Initialized
INFO - 2023-09-12 19:14:46 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:14:46 --> Model "Home_model" initialized
INFO - 2023-09-12 19:14:46 --> Helper loaded: download_helper
INFO - 2023-09-12 19:14:46 --> Helper loaded: form_helper
INFO - 2023-09-12 19:14:46 --> Form Validation Class Initialized
INFO - 2023-09-12 19:14:46 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:14:46 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:14:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:14:46 --> Final output sent to browser
DEBUG - 2023-09-12 19:14:47 --> Total execution time: 0.6103
INFO - 2023-09-12 19:21:24 --> Config Class Initialized
INFO - 2023-09-12 19:21:24 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:21:24 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:21:24 --> Utf8 Class Initialized
INFO - 2023-09-12 19:21:24 --> URI Class Initialized
DEBUG - 2023-09-12 19:21:24 --> No URI present. Default controller set.
INFO - 2023-09-12 19:21:24 --> Router Class Initialized
INFO - 2023-09-12 19:21:24 --> Output Class Initialized
INFO - 2023-09-12 19:21:24 --> Security Class Initialized
DEBUG - 2023-09-12 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:21:24 --> Input Class Initialized
INFO - 2023-09-12 19:21:24 --> Language Class Initialized
INFO - 2023-09-12 19:21:24 --> Loader Class Initialized
INFO - 2023-09-12 19:21:24 --> Helper loaded: url_helper
INFO - 2023-09-12 19:21:24 --> Helper loaded: file_helper
INFO - 2023-09-12 19:21:24 --> Database Driver Class Initialized
INFO - 2023-09-12 19:21:24 --> Email Class Initialized
DEBUG - 2023-09-12 19:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:21:24 --> Controller Class Initialized
INFO - 2023-09-12 19:21:24 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:21:24 --> Model "Home_model" initialized
INFO - 2023-09-12 19:21:24 --> Helper loaded: download_helper
INFO - 2023-09-12 19:21:24 --> Helper loaded: form_helper
INFO - 2023-09-12 19:21:24 --> Form Validation Class Initialized
INFO - 2023-09-12 19:21:24 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:21:24 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:21:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:21:24 --> Final output sent to browser
DEBUG - 2023-09-12 19:21:24 --> Total execution time: 0.4291
INFO - 2023-09-12 19:21:31 --> Config Class Initialized
INFO - 2023-09-12 19:21:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:21:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:21:31 --> Utf8 Class Initialized
INFO - 2023-09-12 19:21:31 --> URI Class Initialized
INFO - 2023-09-12 19:21:31 --> Router Class Initialized
INFO - 2023-09-12 19:21:31 --> Output Class Initialized
INFO - 2023-09-12 19:21:31 --> Security Class Initialized
DEBUG - 2023-09-12 19:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:21:31 --> Input Class Initialized
INFO - 2023-09-12 19:21:31 --> Language Class Initialized
INFO - 2023-09-12 19:21:31 --> Loader Class Initialized
INFO - 2023-09-12 19:21:31 --> Helper loaded: url_helper
INFO - 2023-09-12 19:21:31 --> Helper loaded: file_helper
INFO - 2023-09-12 19:21:31 --> Database Driver Class Initialized
INFO - 2023-09-12 19:21:31 --> Email Class Initialized
DEBUG - 2023-09-12 19:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:21:31 --> Controller Class Initialized
INFO - 2023-09-12 19:21:31 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:21:31 --> Model "Home_model" initialized
INFO - 2023-09-12 19:21:31 --> Helper loaded: download_helper
INFO - 2023-09-12 19:21:31 --> Helper loaded: form_helper
INFO - 2023-09-12 19:21:31 --> Form Validation Class Initialized
INFO - 2023-09-12 19:21:31 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:21:31 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:21:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 19:21:31 --> Final output sent to browser
DEBUG - 2023-09-12 19:21:31 --> Total execution time: 0.1703
INFO - 2023-09-12 19:22:21 --> Config Class Initialized
INFO - 2023-09-12 19:22:21 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:22:21 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:22:21 --> Utf8 Class Initialized
INFO - 2023-09-12 19:22:21 --> URI Class Initialized
INFO - 2023-09-12 19:22:21 --> Router Class Initialized
INFO - 2023-09-12 19:22:21 --> Output Class Initialized
INFO - 2023-09-12 19:22:21 --> Security Class Initialized
DEBUG - 2023-09-12 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:22:21 --> Input Class Initialized
INFO - 2023-09-12 19:22:21 --> Language Class Initialized
INFO - 2023-09-12 19:22:21 --> Loader Class Initialized
INFO - 2023-09-12 19:22:21 --> Helper loaded: url_helper
INFO - 2023-09-12 19:22:21 --> Helper loaded: file_helper
INFO - 2023-09-12 19:22:21 --> Database Driver Class Initialized
INFO - 2023-09-12 19:22:21 --> Email Class Initialized
DEBUG - 2023-09-12 19:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:22:21 --> Controller Class Initialized
INFO - 2023-09-12 19:22:21 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:22:21 --> Model "Home_model" initialized
INFO - 2023-09-12 19:22:21 --> Helper loaded: download_helper
INFO - 2023-09-12 19:22:21 --> Helper loaded: form_helper
INFO - 2023-09-12 19:22:21 --> Form Validation Class Initialized
INFO - 2023-09-12 19:22:21 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:22:21 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:22:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 19:22:21 --> Final output sent to browser
DEBUG - 2023-09-12 19:22:21 --> Total execution time: 0.1322
INFO - 2023-09-12 19:30:04 --> Config Class Initialized
INFO - 2023-09-12 19:30:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:04 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:04 --> URI Class Initialized
DEBUG - 2023-09-12 19:30:04 --> No URI present. Default controller set.
INFO - 2023-09-12 19:30:04 --> Router Class Initialized
INFO - 2023-09-12 19:30:04 --> Output Class Initialized
INFO - 2023-09-12 19:30:04 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:04 --> Input Class Initialized
INFO - 2023-09-12 19:30:04 --> Language Class Initialized
INFO - 2023-09-12 19:30:04 --> Loader Class Initialized
INFO - 2023-09-12 19:30:04 --> Helper loaded: url_helper
INFO - 2023-09-12 19:30:04 --> Helper loaded: file_helper
INFO - 2023-09-12 19:30:04 --> Database Driver Class Initialized
INFO - 2023-09-12 19:30:04 --> Email Class Initialized
DEBUG - 2023-09-12 19:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:30:04 --> Controller Class Initialized
INFO - 2023-09-12 19:30:04 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:30:05 --> Model "Home_model" initialized
INFO - 2023-09-12 19:30:05 --> Helper loaded: download_helper
INFO - 2023-09-12 19:30:05 --> Helper loaded: form_helper
INFO - 2023-09-12 19:30:05 --> Form Validation Class Initialized
INFO - 2023-09-12 19:30:05 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:30:05 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:30:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:30:05 --> Final output sent to browser
DEBUG - 2023-09-12 19:30:05 --> Total execution time: 1.1145
INFO - 2023-09-12 19:30:10 --> Config Class Initialized
INFO - 2023-09-12 19:30:10 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:10 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:10 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:10 --> URI Class Initialized
INFO - 2023-09-12 19:30:10 --> Router Class Initialized
INFO - 2023-09-12 19:30:10 --> Output Class Initialized
INFO - 2023-09-12 19:30:10 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:10 --> Input Class Initialized
INFO - 2023-09-12 19:30:10 --> Language Class Initialized
INFO - 2023-09-12 19:30:10 --> Loader Class Initialized
INFO - 2023-09-12 19:30:10 --> Helper loaded: url_helper
INFO - 2023-09-12 19:30:10 --> Helper loaded: file_helper
INFO - 2023-09-12 19:30:10 --> Database Driver Class Initialized
INFO - 2023-09-12 19:30:10 --> Email Class Initialized
DEBUG - 2023-09-12 19:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:30:10 --> Controller Class Initialized
INFO - 2023-09-12 19:30:10 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:30:10 --> Model "Home_model" initialized
INFO - 2023-09-12 19:30:10 --> Helper loaded: download_helper
INFO - 2023-09-12 19:30:10 --> Helper loaded: form_helper
INFO - 2023-09-12 19:30:10 --> Form Validation Class Initialized
INFO - 2023-09-12 19:30:10 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:30:10 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:30:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-12 19:30:10 --> Final output sent to browser
DEBUG - 2023-09-12 19:30:10 --> Total execution time: 0.3499
INFO - 2023-09-12 19:30:15 --> Config Class Initialized
INFO - 2023-09-12 19:30:15 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:15 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:15 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:15 --> URI Class Initialized
INFO - 2023-09-12 19:30:15 --> Router Class Initialized
INFO - 2023-09-12 19:30:15 --> Output Class Initialized
INFO - 2023-09-12 19:30:15 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:15 --> Input Class Initialized
INFO - 2023-09-12 19:30:15 --> Language Class Initialized
INFO - 2023-09-12 19:30:15 --> Loader Class Initialized
INFO - 2023-09-12 19:30:15 --> Helper loaded: url_helper
INFO - 2023-09-12 19:30:15 --> Helper loaded: file_helper
INFO - 2023-09-12 19:30:15 --> Database Driver Class Initialized
INFO - 2023-09-12 19:30:15 --> Email Class Initialized
DEBUG - 2023-09-12 19:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:30:15 --> Controller Class Initialized
INFO - 2023-09-12 19:30:15 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:30:15 --> Model "Home_model" initialized
INFO - 2023-09-12 19:30:15 --> Helper loaded: download_helper
INFO - 2023-09-12 19:30:15 --> Helper loaded: form_helper
INFO - 2023-09-12 19:30:15 --> Form Validation Class Initialized
INFO - 2023-09-12 19:30:15 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:30:15 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:30:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 19:30:15 --> Final output sent to browser
DEBUG - 2023-09-12 19:30:15 --> Total execution time: 0.2245
INFO - 2023-09-12 19:30:21 --> Config Class Initialized
INFO - 2023-09-12 19:30:21 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:21 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:21 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:21 --> URI Class Initialized
INFO - 2023-09-12 19:30:21 --> Router Class Initialized
INFO - 2023-09-12 19:30:21 --> Output Class Initialized
INFO - 2023-09-12 19:30:21 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:21 --> Input Class Initialized
INFO - 2023-09-12 19:30:21 --> Language Class Initialized
INFO - 2023-09-12 19:30:21 --> Loader Class Initialized
INFO - 2023-09-12 19:30:21 --> Helper loaded: url_helper
INFO - 2023-09-12 19:30:21 --> Helper loaded: file_helper
INFO - 2023-09-12 19:30:21 --> Database Driver Class Initialized
INFO - 2023-09-12 19:30:21 --> Email Class Initialized
DEBUG - 2023-09-12 19:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:30:21 --> Controller Class Initialized
INFO - 2023-09-12 19:30:21 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:30:21 --> Model "Home_model" initialized
INFO - 2023-09-12 19:30:21 --> Helper loaded: download_helper
INFO - 2023-09-12 19:30:21 --> Helper loaded: form_helper
INFO - 2023-09-12 19:30:21 --> Form Validation Class Initialized
INFO - 2023-09-12 19:30:21 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:30:21 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:30:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 19:30:22 --> Final output sent to browser
DEBUG - 2023-09-12 19:30:22 --> Total execution time: 0.6830
INFO - 2023-09-12 19:30:28 --> Config Class Initialized
INFO - 2023-09-12 19:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:28 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:28 --> URI Class Initialized
INFO - 2023-09-12 19:30:28 --> Router Class Initialized
INFO - 2023-09-12 19:30:28 --> Output Class Initialized
INFO - 2023-09-12 19:30:28 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:28 --> Input Class Initialized
INFO - 2023-09-12 19:30:28 --> Language Class Initialized
INFO - 2023-09-12 19:30:28 --> Loader Class Initialized
INFO - 2023-09-12 19:30:28 --> Helper loaded: url_helper
INFO - 2023-09-12 19:30:28 --> Helper loaded: file_helper
INFO - 2023-09-12 19:30:28 --> Database Driver Class Initialized
INFO - 2023-09-12 19:30:28 --> Email Class Initialized
DEBUG - 2023-09-12 19:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:30:28 --> Controller Class Initialized
INFO - 2023-09-12 19:30:28 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:30:28 --> Model "Home_model" initialized
INFO - 2023-09-12 19:30:28 --> Helper loaded: download_helper
INFO - 2023-09-12 19:30:28 --> Helper loaded: form_helper
INFO - 2023-09-12 19:30:28 --> Form Validation Class Initialized
INFO - 2023-09-12 19:30:28 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:30:29 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:30:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-12 19:30:29 --> Final output sent to browser
DEBUG - 2023-09-12 19:30:29 --> Total execution time: 1.3914
INFO - 2023-09-12 19:30:31 --> Config Class Initialized
INFO - 2023-09-12 19:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:31 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:31 --> URI Class Initialized
INFO - 2023-09-12 19:30:31 --> Router Class Initialized
INFO - 2023-09-12 19:30:31 --> Output Class Initialized
INFO - 2023-09-12 19:30:31 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:31 --> Input Class Initialized
INFO - 2023-09-12 19:30:31 --> Language Class Initialized
ERROR - 2023-09-12 19:30:31 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:30:33 --> Config Class Initialized
INFO - 2023-09-12 19:30:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:33 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:33 --> URI Class Initialized
INFO - 2023-09-12 19:30:33 --> Router Class Initialized
INFO - 2023-09-12 19:30:33 --> Output Class Initialized
INFO - 2023-09-12 19:30:33 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:33 --> Input Class Initialized
INFO - 2023-09-12 19:30:33 --> Language Class Initialized
ERROR - 2023-09-12 19:30:33 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:30:33 --> Config Class Initialized
INFO - 2023-09-12 19:30:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:30:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:30:33 --> Utf8 Class Initialized
INFO - 2023-09-12 19:30:33 --> URI Class Initialized
INFO - 2023-09-12 19:30:33 --> Router Class Initialized
INFO - 2023-09-12 19:30:33 --> Output Class Initialized
INFO - 2023-09-12 19:30:33 --> Security Class Initialized
DEBUG - 2023-09-12 19:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:30:33 --> Input Class Initialized
INFO - 2023-09-12 19:30:33 --> Language Class Initialized
ERROR - 2023-09-12 19:30:33 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:34:32 --> Config Class Initialized
INFO - 2023-09-12 19:34:32 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:32 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:32 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:32 --> URI Class Initialized
INFO - 2023-09-12 19:34:32 --> Router Class Initialized
INFO - 2023-09-12 19:34:32 --> Output Class Initialized
INFO - 2023-09-12 19:34:32 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:32 --> Input Class Initialized
INFO - 2023-09-12 19:34:32 --> Language Class Initialized
INFO - 2023-09-12 19:34:32 --> Loader Class Initialized
INFO - 2023-09-12 19:34:32 --> Helper loaded: url_helper
INFO - 2023-09-12 19:34:33 --> Helper loaded: file_helper
INFO - 2023-09-12 19:34:33 --> Database Driver Class Initialized
INFO - 2023-09-12 19:34:33 --> Email Class Initialized
DEBUG - 2023-09-12 19:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:34:33 --> Controller Class Initialized
INFO - 2023-09-12 19:34:33 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:34:33 --> Model "Home_model" initialized
INFO - 2023-09-12 19:34:33 --> Helper loaded: download_helper
INFO - 2023-09-12 19:34:33 --> Helper loaded: form_helper
INFO - 2023-09-12 19:34:33 --> Form Validation Class Initialized
INFO - 2023-09-12 19:34:33 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:34:33 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:34:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-12 19:34:33 --> Final output sent to browser
DEBUG - 2023-09-12 19:34:33 --> Total execution time: 0.4159
INFO - 2023-09-12 19:34:33 --> Config Class Initialized
INFO - 2023-09-12 19:34:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:33 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:33 --> URI Class Initialized
INFO - 2023-09-12 19:34:33 --> Router Class Initialized
INFO - 2023-09-12 19:34:33 --> Output Class Initialized
INFO - 2023-09-12 19:34:33 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:33 --> Input Class Initialized
INFO - 2023-09-12 19:34:33 --> Language Class Initialized
ERROR - 2023-09-12 19:34:33 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:34:34 --> Config Class Initialized
INFO - 2023-09-12 19:34:34 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:34 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:34 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:34 --> URI Class Initialized
INFO - 2023-09-12 19:34:34 --> Router Class Initialized
INFO - 2023-09-12 19:34:34 --> Output Class Initialized
INFO - 2023-09-12 19:34:34 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:34 --> Input Class Initialized
INFO - 2023-09-12 19:34:34 --> Language Class Initialized
ERROR - 2023-09-12 19:34:34 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:34:34 --> Config Class Initialized
INFO - 2023-09-12 19:34:34 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:34 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:34 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:34 --> URI Class Initialized
INFO - 2023-09-12 19:34:34 --> Router Class Initialized
INFO - 2023-09-12 19:34:34 --> Output Class Initialized
INFO - 2023-09-12 19:34:34 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:34 --> Input Class Initialized
INFO - 2023-09-12 19:34:34 --> Language Class Initialized
ERROR - 2023-09-12 19:34:34 --> 404 Page Not Found: Blog-detail/assets
INFO - 2023-09-12 19:34:45 --> Config Class Initialized
INFO - 2023-09-12 19:34:45 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:45 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:45 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:45 --> URI Class Initialized
INFO - 2023-09-12 19:34:45 --> Router Class Initialized
INFO - 2023-09-12 19:34:45 --> Output Class Initialized
INFO - 2023-09-12 19:34:45 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:45 --> Input Class Initialized
INFO - 2023-09-12 19:34:45 --> Language Class Initialized
INFO - 2023-09-12 19:34:45 --> Loader Class Initialized
INFO - 2023-09-12 19:34:45 --> Helper loaded: url_helper
INFO - 2023-09-12 19:34:45 --> Helper loaded: file_helper
INFO - 2023-09-12 19:34:45 --> Database Driver Class Initialized
INFO - 2023-09-12 19:34:45 --> Email Class Initialized
DEBUG - 2023-09-12 19:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:34:45 --> Controller Class Initialized
INFO - 2023-09-12 19:34:45 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:34:45 --> Model "Home_model" initialized
INFO - 2023-09-12 19:34:45 --> Helper loaded: download_helper
INFO - 2023-09-12 19:34:45 --> Helper loaded: form_helper
INFO - 2023-09-12 19:34:45 --> Form Validation Class Initialized
INFO - 2023-09-12 19:34:45 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:34:45 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:34:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 19:34:45 --> Final output sent to browser
DEBUG - 2023-09-12 19:34:45 --> Total execution time: 0.3289
INFO - 2023-09-12 19:34:49 --> Config Class Initialized
INFO - 2023-09-12 19:34:49 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:34:49 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:34:49 --> Utf8 Class Initialized
INFO - 2023-09-12 19:34:49 --> URI Class Initialized
INFO - 2023-09-12 19:34:49 --> Router Class Initialized
INFO - 2023-09-12 19:34:49 --> Output Class Initialized
INFO - 2023-09-12 19:34:49 --> Security Class Initialized
DEBUG - 2023-09-12 19:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:34:49 --> Input Class Initialized
INFO - 2023-09-12 19:34:49 --> Language Class Initialized
INFO - 2023-09-12 19:34:49 --> Loader Class Initialized
INFO - 2023-09-12 19:34:49 --> Helper loaded: url_helper
INFO - 2023-09-12 19:34:49 --> Helper loaded: file_helper
INFO - 2023-09-12 19:34:49 --> Database Driver Class Initialized
INFO - 2023-09-12 19:34:49 --> Email Class Initialized
DEBUG - 2023-09-12 19:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:34:49 --> Controller Class Initialized
INFO - 2023-09-12 19:34:49 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:34:49 --> Model "Home_model" initialized
INFO - 2023-09-12 19:34:49 --> Helper loaded: download_helper
INFO - 2023-09-12 19:34:49 --> Helper loaded: form_helper
INFO - 2023-09-12 19:34:49 --> Form Validation Class Initialized
INFO - 2023-09-12 19:34:49 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:34:49 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:34:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 19:34:49 --> Final output sent to browser
DEBUG - 2023-09-12 19:34:49 --> Total execution time: 0.0784
INFO - 2023-09-12 19:35:03 --> Config Class Initialized
INFO - 2023-09-12 19:35:03 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:35:03 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:35:03 --> Utf8 Class Initialized
INFO - 2023-09-12 19:35:03 --> URI Class Initialized
INFO - 2023-09-12 19:35:03 --> Router Class Initialized
INFO - 2023-09-12 19:35:03 --> Output Class Initialized
INFO - 2023-09-12 19:35:03 --> Security Class Initialized
DEBUG - 2023-09-12 19:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:35:03 --> Input Class Initialized
INFO - 2023-09-12 19:35:03 --> Language Class Initialized
INFO - 2023-09-12 19:35:03 --> Loader Class Initialized
INFO - 2023-09-12 19:35:03 --> Helper loaded: url_helper
INFO - 2023-09-12 19:35:03 --> Helper loaded: file_helper
INFO - 2023-09-12 19:35:03 --> Database Driver Class Initialized
INFO - 2023-09-12 19:35:03 --> Email Class Initialized
DEBUG - 2023-09-12 19:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:35:03 --> Controller Class Initialized
INFO - 2023-09-12 19:35:03 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:35:03 --> Model "Home_model" initialized
INFO - 2023-09-12 19:35:03 --> Helper loaded: download_helper
INFO - 2023-09-12 19:35:03 --> Helper loaded: form_helper
INFO - 2023-09-12 19:35:03 --> Form Validation Class Initialized
INFO - 2023-09-12 19:35:03 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:35:03 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:35:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-12 19:35:03 --> Final output sent to browser
DEBUG - 2023-09-12 19:35:03 --> Total execution time: 0.1895
INFO - 2023-09-12 19:36:10 --> Config Class Initialized
INFO - 2023-09-12 19:36:10 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:36:10 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:36:10 --> Utf8 Class Initialized
INFO - 2023-09-12 19:36:10 --> URI Class Initialized
INFO - 2023-09-12 19:36:10 --> Router Class Initialized
INFO - 2023-09-12 19:36:10 --> Output Class Initialized
INFO - 2023-09-12 19:36:10 --> Security Class Initialized
DEBUG - 2023-09-12 19:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:36:10 --> Input Class Initialized
INFO - 2023-09-12 19:36:11 --> Language Class Initialized
INFO - 2023-09-12 19:36:11 --> Loader Class Initialized
INFO - 2023-09-12 19:36:11 --> Helper loaded: url_helper
INFO - 2023-09-12 19:36:11 --> Helper loaded: file_helper
INFO - 2023-09-12 19:36:11 --> Database Driver Class Initialized
INFO - 2023-09-12 19:36:11 --> Email Class Initialized
DEBUG - 2023-09-12 19:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:36:11 --> Controller Class Initialized
INFO - 2023-09-12 19:36:11 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:36:11 --> Model "Home_model" initialized
INFO - 2023-09-12 19:36:11 --> Helper loaded: download_helper
INFO - 2023-09-12 19:36:11 --> Helper loaded: form_helper
INFO - 2023-09-12 19:36:11 --> Form Validation Class Initialized
INFO - 2023-09-12 19:36:12 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:36:13 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:36:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-12 19:36:13 --> Final output sent to browser
DEBUG - 2023-09-12 19:36:13 --> Total execution time: 3.3883
INFO - 2023-09-12 19:39:31 --> Config Class Initialized
INFO - 2023-09-12 19:39:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:31 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:31 --> URI Class Initialized
INFO - 2023-09-12 19:39:31 --> Router Class Initialized
INFO - 2023-09-12 19:39:31 --> Output Class Initialized
INFO - 2023-09-12 19:39:31 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:31 --> Input Class Initialized
INFO - 2023-09-12 19:39:31 --> Language Class Initialized
ERROR - 2023-09-12 19:39:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:31 --> Config Class Initialized
INFO - 2023-09-12 19:39:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:31 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:31 --> URI Class Initialized
INFO - 2023-09-12 19:39:31 --> Router Class Initialized
INFO - 2023-09-12 19:39:31 --> Output Class Initialized
INFO - 2023-09-12 19:39:31 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:31 --> Input Class Initialized
INFO - 2023-09-12 19:39:31 --> Language Class Initialized
ERROR - 2023-09-12 19:39:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:31 --> Config Class Initialized
INFO - 2023-09-12 19:39:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:31 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:31 --> URI Class Initialized
INFO - 2023-09-12 19:39:31 --> Router Class Initialized
INFO - 2023-09-12 19:39:31 --> Output Class Initialized
INFO - 2023-09-12 19:39:31 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:31 --> Input Class Initialized
INFO - 2023-09-12 19:39:31 --> Language Class Initialized
ERROR - 2023-09-12 19:39:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:32 --> Config Class Initialized
INFO - 2023-09-12 19:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:32 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:32 --> URI Class Initialized
INFO - 2023-09-12 19:39:32 --> Router Class Initialized
INFO - 2023-09-12 19:39:32 --> Output Class Initialized
INFO - 2023-09-12 19:39:32 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:32 --> Input Class Initialized
INFO - 2023-09-12 19:39:32 --> Language Class Initialized
ERROR - 2023-09-12 19:39:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:32 --> Config Class Initialized
INFO - 2023-09-12 19:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:32 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:32 --> URI Class Initialized
INFO - 2023-09-12 19:39:32 --> Router Class Initialized
INFO - 2023-09-12 19:39:32 --> Output Class Initialized
INFO - 2023-09-12 19:39:32 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:32 --> Input Class Initialized
INFO - 2023-09-12 19:39:32 --> Language Class Initialized
ERROR - 2023-09-12 19:39:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:32 --> Config Class Initialized
INFO - 2023-09-12 19:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:32 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:32 --> URI Class Initialized
INFO - 2023-09-12 19:39:32 --> Router Class Initialized
INFO - 2023-09-12 19:39:32 --> Output Class Initialized
INFO - 2023-09-12 19:39:32 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:32 --> Input Class Initialized
INFO - 2023-09-12 19:39:32 --> Language Class Initialized
ERROR - 2023-09-12 19:39:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:39:33 --> Config Class Initialized
INFO - 2023-09-12 19:39:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:39:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:39:33 --> Utf8 Class Initialized
INFO - 2023-09-12 19:39:33 --> URI Class Initialized
INFO - 2023-09-12 19:39:33 --> Router Class Initialized
INFO - 2023-09-12 19:39:33 --> Output Class Initialized
INFO - 2023-09-12 19:39:33 --> Security Class Initialized
DEBUG - 2023-09-12 19:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:39:33 --> Input Class Initialized
INFO - 2023-09-12 19:39:33 --> Language Class Initialized
ERROR - 2023-09-12 19:39:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:00 --> Config Class Initialized
INFO - 2023-09-12 19:42:00 --> Config Class Initialized
INFO - 2023-09-12 19:42:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:00 --> URI Class Initialized
INFO - 2023-09-12 19:42:00 --> Router Class Initialized
INFO - 2023-09-12 19:42:00 --> Output Class Initialized
INFO - 2023-09-12 19:42:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:00 --> Input Class Initialized
INFO - 2023-09-12 19:42:00 --> Language Class Initialized
ERROR - 2023-09-12 19:42:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:00 --> Hooks Class Initialized
INFO - 2023-09-12 19:42:00 --> Config Class Initialized
INFO - 2023-09-12 19:42:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:00 --> URI Class Initialized
INFO - 2023-09-12 19:42:00 --> Router Class Initialized
INFO - 2023-09-12 19:42:00 --> Output Class Initialized
INFO - 2023-09-12 19:42:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:00 --> Input Class Initialized
INFO - 2023-09-12 19:42:00 --> Language Class Initialized
ERROR - 2023-09-12 19:42:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-12 19:42:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:00 --> URI Class Initialized
INFO - 2023-09-12 19:42:00 --> Router Class Initialized
INFO - 2023-09-12 19:42:01 --> Output Class Initialized
INFO - 2023-09-12 19:42:01 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:01 --> Input Class Initialized
INFO - 2023-09-12 19:42:01 --> Language Class Initialized
ERROR - 2023-09-12 19:42:01 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:02 --> Config Class Initialized
INFO - 2023-09-12 19:42:02 --> Config Class Initialized
INFO - 2023-09-12 19:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:02 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:02 --> URI Class Initialized
INFO - 2023-09-12 19:42:02 --> Router Class Initialized
INFO - 2023-09-12 19:42:02 --> Output Class Initialized
INFO - 2023-09-12 19:42:02 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:02 --> Input Class Initialized
INFO - 2023-09-12 19:42:02 --> Language Class Initialized
ERROR - 2023-09-12 19:42:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:02 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:02 --> URI Class Initialized
INFO - 2023-09-12 19:42:02 --> Router Class Initialized
INFO - 2023-09-12 19:42:02 --> Output Class Initialized
INFO - 2023-09-12 19:42:02 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:02 --> Input Class Initialized
INFO - 2023-09-12 19:42:02 --> Language Class Initialized
ERROR - 2023-09-12 19:42:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:02 --> Config Class Initialized
INFO - 2023-09-12 19:42:02 --> Config Class Initialized
INFO - 2023-09-12 19:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:02 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:02 --> URI Class Initialized
INFO - 2023-09-12 19:42:02 --> Router Class Initialized
INFO - 2023-09-12 19:42:02 --> Output Class Initialized
INFO - 2023-09-12 19:42:02 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:02 --> Input Class Initialized
INFO - 2023-09-12 19:42:02 --> Language Class Initialized
ERROR - 2023-09-12 19:42:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:42:02 --> Utf8 Class Initialized
INFO - 2023-09-12 19:42:02 --> URI Class Initialized
INFO - 2023-09-12 19:42:02 --> Router Class Initialized
INFO - 2023-09-12 19:42:02 --> Output Class Initialized
INFO - 2023-09-12 19:42:02 --> Security Class Initialized
DEBUG - 2023-09-12 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:42:02 --> Input Class Initialized
INFO - 2023-09-12 19:42:02 --> Language Class Initialized
ERROR - 2023-09-12 19:42:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:43:26 --> Config Class Initialized
INFO - 2023-09-12 19:43:26 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:43:26 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:43:26 --> Utf8 Class Initialized
INFO - 2023-09-12 19:43:26 --> URI Class Initialized
INFO - 2023-09-12 19:43:26 --> Router Class Initialized
INFO - 2023-09-12 19:43:26 --> Output Class Initialized
INFO - 2023-09-12 19:43:26 --> Security Class Initialized
DEBUG - 2023-09-12 19:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:43:26 --> Input Class Initialized
INFO - 2023-09-12 19:43:26 --> Language Class Initialized
INFO - 2023-09-12 19:43:26 --> Loader Class Initialized
INFO - 2023-09-12 19:43:26 --> Helper loaded: url_helper
INFO - 2023-09-12 19:43:26 --> Helper loaded: file_helper
INFO - 2023-09-12 19:43:26 --> Database Driver Class Initialized
INFO - 2023-09-12 19:43:26 --> Email Class Initialized
DEBUG - 2023-09-12 19:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:43:26 --> Controller Class Initialized
INFO - 2023-09-12 19:43:26 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:43:26 --> Model "Home_model" initialized
INFO - 2023-09-12 19:43:26 --> Helper loaded: download_helper
INFO - 2023-09-12 19:43:26 --> Helper loaded: form_helper
INFO - 2023-09-12 19:43:26 --> Form Validation Class Initialized
INFO - 2023-09-12 19:43:26 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:43:26 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:43:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-12 19:43:26 --> Final output sent to browser
DEBUG - 2023-09-12 19:43:26 --> Total execution time: 0.6405
INFO - 2023-09-12 19:43:44 --> Config Class Initialized
INFO - 2023-09-12 19:43:44 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:43:44 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:43:44 --> Utf8 Class Initialized
INFO - 2023-09-12 19:43:44 --> URI Class Initialized
DEBUG - 2023-09-12 19:43:44 --> No URI present. Default controller set.
INFO - 2023-09-12 19:43:44 --> Router Class Initialized
INFO - 2023-09-12 19:43:44 --> Output Class Initialized
INFO - 2023-09-12 19:43:44 --> Security Class Initialized
DEBUG - 2023-09-12 19:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:43:44 --> Input Class Initialized
INFO - 2023-09-12 19:43:44 --> Language Class Initialized
INFO - 2023-09-12 19:43:44 --> Loader Class Initialized
INFO - 2023-09-12 19:43:44 --> Helper loaded: url_helper
INFO - 2023-09-12 19:43:44 --> Helper loaded: file_helper
INFO - 2023-09-12 19:43:44 --> Database Driver Class Initialized
INFO - 2023-09-12 19:43:44 --> Email Class Initialized
DEBUG - 2023-09-12 19:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:43:44 --> Controller Class Initialized
INFO - 2023-09-12 19:43:45 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:43:45 --> Model "Home_model" initialized
INFO - 2023-09-12 19:43:45 --> Helper loaded: download_helper
INFO - 2023-09-12 19:43:45 --> Helper loaded: form_helper
INFO - 2023-09-12 19:43:45 --> Form Validation Class Initialized
INFO - 2023-09-12 19:43:45 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:43:45 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:43:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:43:45 --> Final output sent to browser
DEBUG - 2023-09-12 19:43:45 --> Total execution time: 0.6554
INFO - 2023-09-12 19:45:34 --> Config Class Initialized
INFO - 2023-09-12 19:45:34 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:45:34 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:45:34 --> Utf8 Class Initialized
INFO - 2023-09-12 19:45:34 --> URI Class Initialized
DEBUG - 2023-09-12 19:45:34 --> No URI present. Default controller set.
INFO - 2023-09-12 19:45:34 --> Router Class Initialized
INFO - 2023-09-12 19:45:34 --> Output Class Initialized
INFO - 2023-09-12 19:45:34 --> Security Class Initialized
DEBUG - 2023-09-12 19:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:45:34 --> Input Class Initialized
INFO - 2023-09-12 19:45:34 --> Language Class Initialized
INFO - 2023-09-12 19:45:34 --> Loader Class Initialized
INFO - 2023-09-12 19:45:34 --> Helper loaded: url_helper
INFO - 2023-09-12 19:45:34 --> Helper loaded: file_helper
INFO - 2023-09-12 19:45:34 --> Database Driver Class Initialized
INFO - 2023-09-12 19:45:34 --> Email Class Initialized
DEBUG - 2023-09-12 19:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:45:34 --> Controller Class Initialized
INFO - 2023-09-12 19:45:34 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:45:34 --> Model "Home_model" initialized
INFO - 2023-09-12 19:45:34 --> Helper loaded: download_helper
INFO - 2023-09-12 19:45:34 --> Helper loaded: form_helper
INFO - 2023-09-12 19:45:34 --> Form Validation Class Initialized
INFO - 2023-09-12 19:45:34 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:45:34 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:45:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:45:34 --> Final output sent to browser
DEBUG - 2023-09-12 19:45:34 --> Total execution time: 0.4105
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:00 --> Config Class Initialized
INFO - 2023-09-12 19:47:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:00 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:00 --> URI Class Initialized
INFO - 2023-09-12 19:47:00 --> Router Class Initialized
INFO - 2023-09-12 19:47:00 --> Output Class Initialized
INFO - 2023-09-12 19:47:00 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:00 --> Input Class Initialized
INFO - 2023-09-12 19:47:00 --> Language Class Initialized
ERROR - 2023-09-12 19:47:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:14 --> Config Class Initialized
INFO - 2023-09-12 19:47:14 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:14 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:14 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:14 --> URI Class Initialized
DEBUG - 2023-09-12 19:47:14 --> No URI present. Default controller set.
INFO - 2023-09-12 19:47:14 --> Router Class Initialized
INFO - 2023-09-12 19:47:14 --> Output Class Initialized
INFO - 2023-09-12 19:47:14 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:14 --> Input Class Initialized
INFO - 2023-09-12 19:47:14 --> Language Class Initialized
INFO - 2023-09-12 19:47:14 --> Loader Class Initialized
INFO - 2023-09-12 19:47:14 --> Helper loaded: url_helper
INFO - 2023-09-12 19:47:14 --> Helper loaded: file_helper
INFO - 2023-09-12 19:47:14 --> Database Driver Class Initialized
INFO - 2023-09-12 19:47:14 --> Email Class Initialized
DEBUG - 2023-09-12 19:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:47:15 --> Controller Class Initialized
INFO - 2023-09-12 19:47:15 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:47:15 --> Model "Home_model" initialized
INFO - 2023-09-12 19:47:15 --> Helper loaded: download_helper
INFO - 2023-09-12 19:47:15 --> Helper loaded: form_helper
INFO - 2023-09-12 19:47:15 --> Form Validation Class Initialized
INFO - 2023-09-12 19:47:15 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:47:15 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:47:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:47:15 --> Final output sent to browser
DEBUG - 2023-09-12 19:47:15 --> Total execution time: 0.5680
INFO - 2023-09-12 19:47:16 --> Config Class Initialized
INFO - 2023-09-12 19:47:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:16 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:16 --> URI Class Initialized
INFO - 2023-09-12 19:47:16 --> Router Class Initialized
INFO - 2023-09-12 19:47:16 --> Output Class Initialized
INFO - 2023-09-12 19:47:16 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:16 --> Input Class Initialized
INFO - 2023-09-12 19:47:16 --> Language Class Initialized
ERROR - 2023-09-12 19:47:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:16 --> Config Class Initialized
INFO - 2023-09-12 19:47:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:16 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:16 --> URI Class Initialized
INFO - 2023-09-12 19:47:16 --> Router Class Initialized
INFO - 2023-09-12 19:47:16 --> Output Class Initialized
INFO - 2023-09-12 19:47:16 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:16 --> Input Class Initialized
INFO - 2023-09-12 19:47:16 --> Language Class Initialized
ERROR - 2023-09-12 19:47:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:16 --> Config Class Initialized
INFO - 2023-09-12 19:47:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:16 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:16 --> URI Class Initialized
INFO - 2023-09-12 19:47:16 --> Router Class Initialized
INFO - 2023-09-12 19:47:16 --> Output Class Initialized
INFO - 2023-09-12 19:47:16 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:16 --> Input Class Initialized
INFO - 2023-09-12 19:47:16 --> Language Class Initialized
ERROR - 2023-09-12 19:47:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:17 --> Config Class Initialized
INFO - 2023-09-12 19:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:17 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:17 --> URI Class Initialized
INFO - 2023-09-12 19:47:17 --> Router Class Initialized
INFO - 2023-09-12 19:47:17 --> Output Class Initialized
INFO - 2023-09-12 19:47:17 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:17 --> Input Class Initialized
INFO - 2023-09-12 19:47:17 --> Language Class Initialized
ERROR - 2023-09-12 19:47:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:17 --> Config Class Initialized
INFO - 2023-09-12 19:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:17 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:17 --> URI Class Initialized
INFO - 2023-09-12 19:47:17 --> Router Class Initialized
INFO - 2023-09-12 19:47:17 --> Output Class Initialized
INFO - 2023-09-12 19:47:17 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:17 --> Input Class Initialized
INFO - 2023-09-12 19:47:17 --> Language Class Initialized
ERROR - 2023-09-12 19:47:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:17 --> Config Class Initialized
INFO - 2023-09-12 19:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:17 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:17 --> URI Class Initialized
INFO - 2023-09-12 19:47:17 --> Router Class Initialized
INFO - 2023-09-12 19:47:17 --> Output Class Initialized
INFO - 2023-09-12 19:47:17 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:17 --> Input Class Initialized
INFO - 2023-09-12 19:47:17 --> Language Class Initialized
ERROR - 2023-09-12 19:47:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:18 --> Config Class Initialized
INFO - 2023-09-12 19:47:18 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:18 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:18 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:18 --> URI Class Initialized
INFO - 2023-09-12 19:47:18 --> Router Class Initialized
INFO - 2023-09-12 19:47:19 --> Output Class Initialized
INFO - 2023-09-12 19:47:19 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:19 --> Input Class Initialized
INFO - 2023-09-12 19:47:19 --> Language Class Initialized
ERROR - 2023-09-12 19:47:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:47:57 --> Config Class Initialized
INFO - 2023-09-12 19:47:57 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:47:57 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:47:57 --> Utf8 Class Initialized
INFO - 2023-09-12 19:47:57 --> URI Class Initialized
DEBUG - 2023-09-12 19:47:57 --> No URI present. Default controller set.
INFO - 2023-09-12 19:47:57 --> Router Class Initialized
INFO - 2023-09-12 19:47:57 --> Output Class Initialized
INFO - 2023-09-12 19:47:57 --> Security Class Initialized
DEBUG - 2023-09-12 19:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:47:57 --> Input Class Initialized
INFO - 2023-09-12 19:47:57 --> Language Class Initialized
INFO - 2023-09-12 19:47:57 --> Loader Class Initialized
INFO - 2023-09-12 19:47:57 --> Helper loaded: url_helper
INFO - 2023-09-12 19:47:57 --> Helper loaded: file_helper
INFO - 2023-09-12 19:47:57 --> Database Driver Class Initialized
INFO - 2023-09-12 19:47:57 --> Email Class Initialized
DEBUG - 2023-09-12 19:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:47:57 --> Controller Class Initialized
INFO - 2023-09-12 19:47:57 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:47:57 --> Model "Home_model" initialized
INFO - 2023-09-12 19:47:57 --> Helper loaded: download_helper
INFO - 2023-09-12 19:47:57 --> Helper loaded: form_helper
INFO - 2023-09-12 19:47:57 --> Form Validation Class Initialized
INFO - 2023-09-12 19:47:57 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:47:57 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:47:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 19:47:57 --> Final output sent to browser
DEBUG - 2023-09-12 19:47:57 --> Total execution time: 0.2166
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:48:23 --> Config Class Initialized
INFO - 2023-09-12 19:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:48:23 --> Utf8 Class Initialized
INFO - 2023-09-12 19:48:23 --> URI Class Initialized
INFO - 2023-09-12 19:48:23 --> Router Class Initialized
INFO - 2023-09-12 19:48:23 --> Output Class Initialized
INFO - 2023-09-12 19:48:23 --> Security Class Initialized
DEBUG - 2023-09-12 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:48:23 --> Input Class Initialized
INFO - 2023-09-12 19:48:23 --> Language Class Initialized
ERROR - 2023-09-12 19:48:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-12 19:50:29 --> Config Class Initialized
INFO - 2023-09-12 19:50:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:50:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:50:29 --> Utf8 Class Initialized
INFO - 2023-09-12 19:50:29 --> URI Class Initialized
INFO - 2023-09-12 19:50:29 --> Router Class Initialized
INFO - 2023-09-12 19:50:29 --> Output Class Initialized
INFO - 2023-09-12 19:50:29 --> Security Class Initialized
DEBUG - 2023-09-12 19:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:50:29 --> Input Class Initialized
INFO - 2023-09-12 19:50:29 --> Language Class Initialized
INFO - 2023-09-12 19:50:29 --> Loader Class Initialized
INFO - 2023-09-12 19:50:29 --> Helper loaded: url_helper
INFO - 2023-09-12 19:50:29 --> Helper loaded: file_helper
INFO - 2023-09-12 19:50:29 --> Database Driver Class Initialized
INFO - 2023-09-12 19:50:29 --> Email Class Initialized
DEBUG - 2023-09-12 19:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:50:29 --> Controller Class Initialized
INFO - 2023-09-12 19:50:29 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:50:29 --> Model "Home_model" initialized
INFO - 2023-09-12 19:50:29 --> Helper loaded: download_helper
INFO - 2023-09-12 19:50:29 --> Helper loaded: form_helper
INFO - 2023-09-12 19:50:29 --> Form Validation Class Initialized
INFO - 2023-09-12 19:50:29 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:50:29 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:50:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 19:50:29 --> Final output sent to browser
DEBUG - 2023-09-12 19:50:29 --> Total execution time: 0.2582
INFO - 2023-09-12 19:53:24 --> Config Class Initialized
INFO - 2023-09-12 19:53:24 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:53:24 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:53:24 --> Utf8 Class Initialized
INFO - 2023-09-12 19:53:24 --> URI Class Initialized
INFO - 2023-09-12 19:53:24 --> Router Class Initialized
INFO - 2023-09-12 19:53:24 --> Output Class Initialized
INFO - 2023-09-12 19:53:24 --> Security Class Initialized
DEBUG - 2023-09-12 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:53:24 --> Input Class Initialized
INFO - 2023-09-12 19:53:24 --> Language Class Initialized
INFO - 2023-09-12 19:53:24 --> Loader Class Initialized
INFO - 2023-09-12 19:53:24 --> Helper loaded: url_helper
INFO - 2023-09-12 19:53:24 --> Helper loaded: file_helper
INFO - 2023-09-12 19:53:24 --> Database Driver Class Initialized
INFO - 2023-09-12 19:53:24 --> Email Class Initialized
DEBUG - 2023-09-12 19:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:53:24 --> Controller Class Initialized
INFO - 2023-09-12 19:53:24 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-09-12 19:53:24 --> Helper loaded: form_helper
INFO - 2023-09-12 19:53:24 --> Form Validation Class Initialized
INFO - 2023-09-12 19:53:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-09-12 19:53:25 --> Final output sent to browser
DEBUG - 2023-09-12 19:53:25 --> Total execution time: 0.7418
INFO - 2023-09-12 19:53:27 --> Config Class Initialized
INFO - 2023-09-12 19:53:27 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:53:27 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:53:27 --> Utf8 Class Initialized
INFO - 2023-09-12 19:53:27 --> URI Class Initialized
INFO - 2023-09-12 19:53:27 --> Router Class Initialized
INFO - 2023-09-12 19:53:27 --> Output Class Initialized
INFO - 2023-09-12 19:53:27 --> Security Class Initialized
DEBUG - 2023-09-12 19:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:53:27 --> Input Class Initialized
INFO - 2023-09-12 19:53:27 --> Language Class Initialized
ERROR - 2023-09-12 19:53:27 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-09-12 19:53:39 --> Config Class Initialized
INFO - 2023-09-12 19:53:39 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:53:39 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:53:39 --> Utf8 Class Initialized
INFO - 2023-09-12 19:53:39 --> URI Class Initialized
INFO - 2023-09-12 19:53:39 --> Router Class Initialized
INFO - 2023-09-12 19:53:39 --> Output Class Initialized
INFO - 2023-09-12 19:53:39 --> Security Class Initialized
DEBUG - 2023-09-12 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:53:39 --> Input Class Initialized
INFO - 2023-09-12 19:53:39 --> Language Class Initialized
INFO - 2023-09-12 19:53:39 --> Loader Class Initialized
INFO - 2023-09-12 19:53:39 --> Helper loaded: url_helper
INFO - 2023-09-12 19:53:39 --> Helper loaded: file_helper
INFO - 2023-09-12 19:53:39 --> Database Driver Class Initialized
INFO - 2023-09-12 19:53:39 --> Email Class Initialized
DEBUG - 2023-09-12 19:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:53:39 --> Controller Class Initialized
INFO - 2023-09-12 19:53:39 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:53:39 --> Helper loaded: form_helper
INFO - 2023-09-12 19:53:39 --> Form Validation Class Initialized
INFO - 2023-09-12 19:53:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 19:53:39 --> Final output sent to browser
DEBUG - 2023-09-12 19:53:40 --> Total execution time: 0.3187
INFO - 2023-09-12 19:53:41 --> Config Class Initialized
INFO - 2023-09-12 19:53:41 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:53:41 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:53:41 --> Utf8 Class Initialized
INFO - 2023-09-12 19:53:41 --> URI Class Initialized
INFO - 2023-09-12 19:53:41 --> Router Class Initialized
INFO - 2023-09-12 19:53:41 --> Output Class Initialized
INFO - 2023-09-12 19:53:41 --> Security Class Initialized
DEBUG - 2023-09-12 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:53:41 --> Input Class Initialized
INFO - 2023-09-12 19:53:41 --> Language Class Initialized
ERROR - 2023-09-12 19:53:41 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-12 19:56:19 --> Config Class Initialized
INFO - 2023-09-12 19:56:19 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:56:19 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:56:19 --> Utf8 Class Initialized
INFO - 2023-09-12 19:56:19 --> URI Class Initialized
INFO - 2023-09-12 19:56:19 --> Router Class Initialized
INFO - 2023-09-12 19:56:19 --> Output Class Initialized
INFO - 2023-09-12 19:56:19 --> Security Class Initialized
DEBUG - 2023-09-12 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:56:19 --> Input Class Initialized
INFO - 2023-09-12 19:56:19 --> Language Class Initialized
INFO - 2023-09-12 19:56:19 --> Loader Class Initialized
INFO - 2023-09-12 19:56:19 --> Helper loaded: url_helper
INFO - 2023-09-12 19:56:19 --> Helper loaded: file_helper
INFO - 2023-09-12 19:56:19 --> Database Driver Class Initialized
INFO - 2023-09-12 19:56:19 --> Email Class Initialized
DEBUG - 2023-09-12 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:56:19 --> Controller Class Initialized
INFO - 2023-09-12 19:56:19 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:56:19 --> Helper loaded: form_helper
INFO - 2023-09-12 19:56:19 --> Form Validation Class Initialized
INFO - 2023-09-12 19:56:19 --> Config Class Initialized
INFO - 2023-09-12 19:56:19 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:56:19 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:56:19 --> Utf8 Class Initialized
INFO - 2023-09-12 19:56:19 --> URI Class Initialized
INFO - 2023-09-12 19:56:19 --> Router Class Initialized
INFO - 2023-09-12 19:56:19 --> Output Class Initialized
INFO - 2023-09-12 19:56:19 --> Security Class Initialized
DEBUG - 2023-09-12 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:56:19 --> Input Class Initialized
INFO - 2023-09-12 19:56:19 --> Language Class Initialized
INFO - 2023-09-12 19:56:19 --> Loader Class Initialized
INFO - 2023-09-12 19:56:19 --> Helper loaded: url_helper
INFO - 2023-09-12 19:56:19 --> Helper loaded: file_helper
INFO - 2023-09-12 19:56:19 --> Database Driver Class Initialized
INFO - 2023-09-12 19:56:19 --> Email Class Initialized
DEBUG - 2023-09-12 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:56:19 --> Controller Class Initialized
INFO - 2023-09-12 19:56:19 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:56:19 --> Helper loaded: form_helper
INFO - 2023-09-12 19:56:19 --> Form Validation Class Initialized
INFO - 2023-09-12 19:56:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 19:56:19 --> Final output sent to browser
DEBUG - 2023-09-12 19:56:19 --> Total execution time: 0.1147
INFO - 2023-09-12 19:56:38 --> Config Class Initialized
INFO - 2023-09-12 19:56:38 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:56:38 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:56:38 --> Utf8 Class Initialized
INFO - 2023-09-12 19:56:38 --> URI Class Initialized
INFO - 2023-09-12 19:56:38 --> Router Class Initialized
INFO - 2023-09-12 19:56:38 --> Output Class Initialized
INFO - 2023-09-12 19:56:38 --> Security Class Initialized
DEBUG - 2023-09-12 19:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:56:38 --> Input Class Initialized
INFO - 2023-09-12 19:56:38 --> Language Class Initialized
INFO - 2023-09-12 19:56:38 --> Loader Class Initialized
INFO - 2023-09-12 19:56:38 --> Helper loaded: url_helper
INFO - 2023-09-12 19:56:38 --> Helper loaded: file_helper
INFO - 2023-09-12 19:56:38 --> Database Driver Class Initialized
INFO - 2023-09-12 19:56:38 --> Email Class Initialized
DEBUG - 2023-09-12 19:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:56:38 --> Controller Class Initialized
INFO - 2023-09-12 19:56:38 --> Model "Contact_model" initialized
INFO - 2023-09-12 19:56:38 --> Model "Home_model" initialized
INFO - 2023-09-12 19:56:38 --> Helper loaded: download_helper
INFO - 2023-09-12 19:56:38 --> Helper loaded: form_helper
INFO - 2023-09-12 19:56:38 --> Form Validation Class Initialized
INFO - 2023-09-12 19:56:38 --> Helper loaded: custom_helper
INFO - 2023-09-12 19:56:38 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:56:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 19:56:38 --> Final output sent to browser
DEBUG - 2023-09-12 19:56:38 --> Total execution time: 0.1909
INFO - 2023-09-12 19:57:20 --> Config Class Initialized
INFO - 2023-09-12 19:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:57:20 --> Utf8 Class Initialized
INFO - 2023-09-12 19:57:20 --> URI Class Initialized
INFO - 2023-09-12 19:57:20 --> Router Class Initialized
INFO - 2023-09-12 19:57:20 --> Output Class Initialized
INFO - 2023-09-12 19:57:20 --> Security Class Initialized
DEBUG - 2023-09-12 19:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:57:20 --> Input Class Initialized
INFO - 2023-09-12 19:57:20 --> Language Class Initialized
INFO - 2023-09-12 19:57:20 --> Loader Class Initialized
INFO - 2023-09-12 19:57:20 --> Helper loaded: url_helper
INFO - 2023-09-12 19:57:20 --> Helper loaded: file_helper
INFO - 2023-09-12 19:57:20 --> Database Driver Class Initialized
INFO - 2023-09-12 19:57:20 --> Email Class Initialized
DEBUG - 2023-09-12 19:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:57:20 --> Controller Class Initialized
INFO - 2023-09-12 19:57:20 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:57:20 --> Helper loaded: form_helper
INFO - 2023-09-12 19:57:20 --> Form Validation Class Initialized
INFO - 2023-09-12 19:57:20 --> Config Class Initialized
INFO - 2023-09-12 19:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:57:20 --> Utf8 Class Initialized
INFO - 2023-09-12 19:57:20 --> URI Class Initialized
INFO - 2023-09-12 19:57:20 --> Router Class Initialized
INFO - 2023-09-12 19:57:20 --> Output Class Initialized
INFO - 2023-09-12 19:57:20 --> Security Class Initialized
DEBUG - 2023-09-12 19:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:57:20 --> Input Class Initialized
INFO - 2023-09-12 19:57:20 --> Language Class Initialized
INFO - 2023-09-12 19:57:20 --> Loader Class Initialized
INFO - 2023-09-12 19:57:20 --> Helper loaded: url_helper
INFO - 2023-09-12 19:57:20 --> Helper loaded: file_helper
INFO - 2023-09-12 19:57:20 --> Database Driver Class Initialized
INFO - 2023-09-12 19:57:20 --> Email Class Initialized
DEBUG - 2023-09-12 19:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:57:20 --> Controller Class Initialized
INFO - 2023-09-12 19:57:20 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:57:20 --> Helper loaded: form_helper
INFO - 2023-09-12 19:57:20 --> Form Validation Class Initialized
INFO - 2023-09-12 19:57:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 19:57:20 --> Final output sent to browser
DEBUG - 2023-09-12 19:57:20 --> Total execution time: 0.0532
INFO - 2023-09-12 19:57:21 --> Config Class Initialized
INFO - 2023-09-12 19:57:21 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:57:21 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:57:21 --> Utf8 Class Initialized
INFO - 2023-09-12 19:57:21 --> URI Class Initialized
INFO - 2023-09-12 19:57:21 --> Router Class Initialized
INFO - 2023-09-12 19:57:21 --> Output Class Initialized
INFO - 2023-09-12 19:57:21 --> Security Class Initialized
DEBUG - 2023-09-12 19:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:57:21 --> Input Class Initialized
INFO - 2023-09-12 19:57:21 --> Language Class Initialized
ERROR - 2023-09-12 19:57:21 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-12 19:57:51 --> Config Class Initialized
INFO - 2023-09-12 19:57:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:57:51 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:57:51 --> Utf8 Class Initialized
INFO - 2023-09-12 19:57:51 --> URI Class Initialized
INFO - 2023-09-12 19:57:51 --> Router Class Initialized
INFO - 2023-09-12 19:57:51 --> Output Class Initialized
INFO - 2023-09-12 19:57:51 --> Security Class Initialized
DEBUG - 2023-09-12 19:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:57:51 --> Input Class Initialized
INFO - 2023-09-12 19:57:51 --> Language Class Initialized
INFO - 2023-09-12 19:57:51 --> Loader Class Initialized
INFO - 2023-09-12 19:57:51 --> Helper loaded: url_helper
INFO - 2023-09-12 19:57:51 --> Helper loaded: file_helper
INFO - 2023-09-12 19:57:51 --> Database Driver Class Initialized
INFO - 2023-09-12 19:57:51 --> Email Class Initialized
DEBUG - 2023-09-12 19:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:57:51 --> Controller Class Initialized
INFO - 2023-09-12 19:57:51 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:57:51 --> Helper loaded: form_helper
INFO - 2023-09-12 19:57:51 --> Form Validation Class Initialized
INFO - 2023-09-12 19:57:51 --> Config Class Initialized
INFO - 2023-09-12 19:57:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 19:57:51 --> UTF-8 Support Enabled
INFO - 2023-09-12 19:57:51 --> Utf8 Class Initialized
INFO - 2023-09-12 19:57:51 --> URI Class Initialized
INFO - 2023-09-12 19:57:51 --> Router Class Initialized
INFO - 2023-09-12 19:57:51 --> Output Class Initialized
INFO - 2023-09-12 19:57:51 --> Security Class Initialized
DEBUG - 2023-09-12 19:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 19:57:51 --> Input Class Initialized
INFO - 2023-09-12 19:57:51 --> Language Class Initialized
INFO - 2023-09-12 19:57:51 --> Loader Class Initialized
INFO - 2023-09-12 19:57:51 --> Helper loaded: url_helper
INFO - 2023-09-12 19:57:51 --> Helper loaded: file_helper
INFO - 2023-09-12 19:57:51 --> Database Driver Class Initialized
INFO - 2023-09-12 19:57:51 --> Email Class Initialized
DEBUG - 2023-09-12 19:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 19:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 19:57:51 --> Controller Class Initialized
INFO - 2023-09-12 19:57:51 --> Model "Social_media_model" initialized
INFO - 2023-09-12 19:57:51 --> Helper loaded: form_helper
INFO - 2023-09-12 19:57:51 --> Form Validation Class Initialized
INFO - 2023-09-12 19:57:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 19:57:51 --> Final output sent to browser
DEBUG - 2023-09-12 19:57:51 --> Total execution time: 0.0804
INFO - 2023-09-12 20:01:49 --> Config Class Initialized
INFO - 2023-09-12 20:01:49 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:01:49 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:01:49 --> Utf8 Class Initialized
INFO - 2023-09-12 20:01:49 --> URI Class Initialized
INFO - 2023-09-12 20:01:49 --> Router Class Initialized
INFO - 2023-09-12 20:01:49 --> Output Class Initialized
INFO - 2023-09-12 20:01:49 --> Security Class Initialized
DEBUG - 2023-09-12 20:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:01:49 --> Input Class Initialized
INFO - 2023-09-12 20:01:49 --> Language Class Initialized
INFO - 2023-09-12 20:01:49 --> Loader Class Initialized
INFO - 2023-09-12 20:01:49 --> Helper loaded: url_helper
INFO - 2023-09-12 20:01:50 --> Helper loaded: file_helper
INFO - 2023-09-12 20:01:50 --> Database Driver Class Initialized
INFO - 2023-09-12 20:01:50 --> Email Class Initialized
DEBUG - 2023-09-12 20:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:01:50 --> Controller Class Initialized
INFO - 2023-09-12 20:01:50 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:01:50 --> Helper loaded: form_helper
INFO - 2023-09-12 20:01:50 --> Form Validation Class Initialized
INFO - 2023-09-12 20:01:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 20:01:50 --> Final output sent to browser
DEBUG - 2023-09-12 20:01:50 --> Total execution time: 0.7573
INFO - 2023-09-12 20:02:51 --> Config Class Initialized
INFO - 2023-09-12 20:02:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:02:52 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:02:52 --> Utf8 Class Initialized
INFO - 2023-09-12 20:02:52 --> URI Class Initialized
INFO - 2023-09-12 20:02:52 --> Router Class Initialized
INFO - 2023-09-12 20:02:52 --> Output Class Initialized
INFO - 2023-09-12 20:02:52 --> Security Class Initialized
DEBUG - 2023-09-12 20:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:02:52 --> Input Class Initialized
INFO - 2023-09-12 20:02:52 --> Language Class Initialized
INFO - 2023-09-12 20:02:52 --> Loader Class Initialized
INFO - 2023-09-12 20:02:52 --> Helper loaded: url_helper
INFO - 2023-09-12 20:02:52 --> Helper loaded: file_helper
INFO - 2023-09-12 20:02:52 --> Database Driver Class Initialized
INFO - 2023-09-12 20:02:52 --> Email Class Initialized
DEBUG - 2023-09-12 20:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:02:52 --> Controller Class Initialized
INFO - 2023-09-12 20:02:52 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:02:52 --> Helper loaded: form_helper
INFO - 2023-09-12 20:02:52 --> Form Validation Class Initialized
INFO - 2023-09-12 20:02:52 --> Config Class Initialized
INFO - 2023-09-12 20:02:52 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:02:52 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:02:52 --> Utf8 Class Initialized
INFO - 2023-09-12 20:02:52 --> URI Class Initialized
INFO - 2023-09-12 20:02:52 --> Router Class Initialized
INFO - 2023-09-12 20:02:52 --> Output Class Initialized
INFO - 2023-09-12 20:02:52 --> Security Class Initialized
DEBUG - 2023-09-12 20:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:02:52 --> Input Class Initialized
INFO - 2023-09-12 20:02:52 --> Language Class Initialized
INFO - 2023-09-12 20:02:52 --> Loader Class Initialized
INFO - 2023-09-12 20:02:52 --> Helper loaded: url_helper
INFO - 2023-09-12 20:02:52 --> Helper loaded: file_helper
INFO - 2023-09-12 20:02:52 --> Database Driver Class Initialized
INFO - 2023-09-12 20:02:52 --> Email Class Initialized
DEBUG - 2023-09-12 20:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:02:52 --> Controller Class Initialized
INFO - 2023-09-12 20:02:52 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:02:52 --> Helper loaded: form_helper
INFO - 2023-09-12 20:02:52 --> Form Validation Class Initialized
INFO - 2023-09-12 20:02:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 20:02:52 --> Final output sent to browser
DEBUG - 2023-09-12 20:02:52 --> Total execution time: 0.3618
INFO - 2023-09-12 20:03:45 --> Config Class Initialized
INFO - 2023-09-12 20:03:45 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:03:45 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:03:45 --> Utf8 Class Initialized
INFO - 2023-09-12 20:03:45 --> URI Class Initialized
INFO - 2023-09-12 20:03:45 --> Router Class Initialized
INFO - 2023-09-12 20:03:45 --> Output Class Initialized
INFO - 2023-09-12 20:03:45 --> Security Class Initialized
DEBUG - 2023-09-12 20:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:03:45 --> Input Class Initialized
INFO - 2023-09-12 20:03:45 --> Language Class Initialized
INFO - 2023-09-12 20:03:46 --> Loader Class Initialized
INFO - 2023-09-12 20:03:46 --> Helper loaded: url_helper
INFO - 2023-09-12 20:03:46 --> Helper loaded: file_helper
INFO - 2023-09-12 20:03:46 --> Database Driver Class Initialized
INFO - 2023-09-12 20:03:46 --> Email Class Initialized
DEBUG - 2023-09-12 20:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:03:46 --> Controller Class Initialized
INFO - 2023-09-12 20:03:46 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:03:46 --> Helper loaded: form_helper
INFO - 2023-09-12 20:03:46 --> Form Validation Class Initialized
INFO - 2023-09-12 20:03:46 --> Config Class Initialized
INFO - 2023-09-12 20:03:46 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:03:46 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:03:46 --> Utf8 Class Initialized
INFO - 2023-09-12 20:03:46 --> URI Class Initialized
INFO - 2023-09-12 20:03:46 --> Router Class Initialized
INFO - 2023-09-12 20:03:46 --> Output Class Initialized
INFO - 2023-09-12 20:03:46 --> Security Class Initialized
DEBUG - 2023-09-12 20:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:03:46 --> Input Class Initialized
INFO - 2023-09-12 20:03:46 --> Language Class Initialized
INFO - 2023-09-12 20:03:46 --> Loader Class Initialized
INFO - 2023-09-12 20:03:46 --> Helper loaded: url_helper
INFO - 2023-09-12 20:03:46 --> Helper loaded: file_helper
INFO - 2023-09-12 20:03:46 --> Database Driver Class Initialized
INFO - 2023-09-12 20:03:46 --> Email Class Initialized
DEBUG - 2023-09-12 20:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:03:46 --> Controller Class Initialized
INFO - 2023-09-12 20:03:46 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:03:46 --> Helper loaded: form_helper
INFO - 2023-09-12 20:03:46 --> Form Validation Class Initialized
INFO - 2023-09-12 20:03:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 20:03:46 --> Final output sent to browser
DEBUG - 2023-09-12 20:03:46 --> Total execution time: 0.2436
INFO - 2023-09-12 20:03:53 --> Config Class Initialized
INFO - 2023-09-12 20:03:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:03:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:03:53 --> Utf8 Class Initialized
INFO - 2023-09-12 20:03:53 --> URI Class Initialized
INFO - 2023-09-12 20:03:53 --> Router Class Initialized
INFO - 2023-09-12 20:03:53 --> Output Class Initialized
INFO - 2023-09-12 20:03:53 --> Security Class Initialized
DEBUG - 2023-09-12 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:03:53 --> Input Class Initialized
INFO - 2023-09-12 20:03:53 --> Language Class Initialized
INFO - 2023-09-12 20:03:53 --> Loader Class Initialized
INFO - 2023-09-12 20:03:53 --> Helper loaded: url_helper
INFO - 2023-09-12 20:03:53 --> Helper loaded: file_helper
INFO - 2023-09-12 20:03:53 --> Database Driver Class Initialized
INFO - 2023-09-12 20:03:53 --> Email Class Initialized
DEBUG - 2023-09-12 20:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:03:53 --> Controller Class Initialized
INFO - 2023-09-12 20:03:53 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:03:53 --> Helper loaded: form_helper
INFO - 2023-09-12 20:03:53 --> Form Validation Class Initialized
INFO - 2023-09-12 20:03:53 --> Config Class Initialized
INFO - 2023-09-12 20:03:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:03:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:03:53 --> Utf8 Class Initialized
INFO - 2023-09-12 20:03:53 --> URI Class Initialized
INFO - 2023-09-12 20:03:53 --> Router Class Initialized
INFO - 2023-09-12 20:03:53 --> Output Class Initialized
INFO - 2023-09-12 20:03:53 --> Security Class Initialized
DEBUG - 2023-09-12 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:03:53 --> Input Class Initialized
INFO - 2023-09-12 20:03:53 --> Language Class Initialized
INFO - 2023-09-12 20:03:53 --> Loader Class Initialized
INFO - 2023-09-12 20:03:53 --> Helper loaded: url_helper
INFO - 2023-09-12 20:03:53 --> Helper loaded: file_helper
INFO - 2023-09-12 20:03:53 --> Database Driver Class Initialized
INFO - 2023-09-12 20:03:53 --> Email Class Initialized
DEBUG - 2023-09-12 20:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:03:53 --> Controller Class Initialized
INFO - 2023-09-12 20:03:53 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:03:53 --> Helper loaded: form_helper
INFO - 2023-09-12 20:03:53 --> Form Validation Class Initialized
INFO - 2023-09-12 20:03:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 20:03:53 --> Final output sent to browser
DEBUG - 2023-09-12 20:03:53 --> Total execution time: 0.0576
INFO - 2023-09-12 20:04:02 --> Config Class Initialized
INFO - 2023-09-12 20:04:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:04:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:04:02 --> Utf8 Class Initialized
INFO - 2023-09-12 20:04:03 --> URI Class Initialized
INFO - 2023-09-12 20:04:03 --> Router Class Initialized
INFO - 2023-09-12 20:04:03 --> Output Class Initialized
INFO - 2023-09-12 20:04:03 --> Security Class Initialized
DEBUG - 2023-09-12 20:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:04:03 --> Input Class Initialized
INFO - 2023-09-12 20:04:03 --> Language Class Initialized
INFO - 2023-09-12 20:04:03 --> Loader Class Initialized
INFO - 2023-09-12 20:04:03 --> Helper loaded: url_helper
INFO - 2023-09-12 20:04:03 --> Helper loaded: file_helper
INFO - 2023-09-12 20:04:03 --> Database Driver Class Initialized
INFO - 2023-09-12 20:04:03 --> Email Class Initialized
DEBUG - 2023-09-12 20:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:04:03 --> Controller Class Initialized
INFO - 2023-09-12 20:04:03 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:04:03 --> Helper loaded: form_helper
INFO - 2023-09-12 20:04:03 --> Form Validation Class Initialized
INFO - 2023-09-12 20:04:03 --> Config Class Initialized
INFO - 2023-09-12 20:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:04:03 --> Utf8 Class Initialized
INFO - 2023-09-12 20:04:03 --> URI Class Initialized
INFO - 2023-09-12 20:04:03 --> Router Class Initialized
INFO - 2023-09-12 20:04:03 --> Output Class Initialized
INFO - 2023-09-12 20:04:03 --> Security Class Initialized
DEBUG - 2023-09-12 20:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:04:03 --> Input Class Initialized
INFO - 2023-09-12 20:04:03 --> Language Class Initialized
INFO - 2023-09-12 20:04:03 --> Loader Class Initialized
INFO - 2023-09-12 20:04:03 --> Helper loaded: url_helper
INFO - 2023-09-12 20:04:03 --> Helper loaded: file_helper
INFO - 2023-09-12 20:04:03 --> Database Driver Class Initialized
INFO - 2023-09-12 20:04:03 --> Email Class Initialized
DEBUG - 2023-09-12 20:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:04:03 --> Controller Class Initialized
INFO - 2023-09-12 20:04:03 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:04:03 --> Helper loaded: form_helper
INFO - 2023-09-12 20:04:03 --> Form Validation Class Initialized
INFO - 2023-09-12 20:04:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-12 20:04:03 --> Final output sent to browser
DEBUG - 2023-09-12 20:04:03 --> Total execution time: 0.0451
INFO - 2023-09-12 20:05:33 --> Config Class Initialized
INFO - 2023-09-12 20:05:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:05:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:05:33 --> Utf8 Class Initialized
INFO - 2023-09-12 20:05:33 --> URI Class Initialized
INFO - 2023-09-12 20:05:33 --> Router Class Initialized
INFO - 2023-09-12 20:05:33 --> Output Class Initialized
INFO - 2023-09-12 20:05:33 --> Security Class Initialized
DEBUG - 2023-09-12 20:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:05:33 --> Input Class Initialized
INFO - 2023-09-12 20:05:33 --> Language Class Initialized
INFO - 2023-09-12 20:05:33 --> Loader Class Initialized
INFO - 2023-09-12 20:05:33 --> Helper loaded: url_helper
INFO - 2023-09-12 20:05:33 --> Helper loaded: file_helper
INFO - 2023-09-12 20:05:33 --> Database Driver Class Initialized
INFO - 2023-09-12 20:05:33 --> Email Class Initialized
DEBUG - 2023-09-12 20:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:05:33 --> Controller Class Initialized
INFO - 2023-09-12 20:05:33 --> Model "Contact_model" initialized
INFO - 2023-09-12 20:05:33 --> Model "Home_model" initialized
INFO - 2023-09-12 20:05:33 --> Helper loaded: download_helper
INFO - 2023-09-12 20:05:33 --> Helper loaded: form_helper
INFO - 2023-09-12 20:05:33 --> Form Validation Class Initialized
INFO - 2023-09-12 20:05:33 --> Helper loaded: custom_helper
INFO - 2023-09-12 20:05:33 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:05:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-12 20:05:33 --> Final output sent to browser
DEBUG - 2023-09-12 20:05:33 --> Total execution time: 0.4106
INFO - 2023-09-12 20:16:02 --> Config Class Initialized
INFO - 2023-09-12 20:16:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:16:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:16:02 --> Utf8 Class Initialized
INFO - 2023-09-12 20:16:02 --> URI Class Initialized
DEBUG - 2023-09-12 20:16:02 --> No URI present. Default controller set.
INFO - 2023-09-12 20:16:02 --> Router Class Initialized
INFO - 2023-09-12 20:16:02 --> Output Class Initialized
INFO - 2023-09-12 20:16:03 --> Security Class Initialized
DEBUG - 2023-09-12 20:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:16:03 --> Input Class Initialized
INFO - 2023-09-12 20:16:03 --> Language Class Initialized
INFO - 2023-09-12 20:16:03 --> Loader Class Initialized
INFO - 2023-09-12 20:16:03 --> Helper loaded: url_helper
INFO - 2023-09-12 20:16:03 --> Helper loaded: file_helper
INFO - 2023-09-12 20:16:03 --> Database Driver Class Initialized
INFO - 2023-09-12 20:16:03 --> Email Class Initialized
DEBUG - 2023-09-12 20:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:16:03 --> Controller Class Initialized
INFO - 2023-09-12 20:16:03 --> Model "Contact_model" initialized
INFO - 2023-09-12 20:16:03 --> Model "Home_model" initialized
INFO - 2023-09-12 20:16:03 --> Helper loaded: download_helper
INFO - 2023-09-12 20:16:03 --> Helper loaded: form_helper
INFO - 2023-09-12 20:16:03 --> Form Validation Class Initialized
INFO - 2023-09-12 20:16:03 --> Helper loaded: custom_helper
INFO - 2023-09-12 20:16:03 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:16:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 20:16:03 --> Final output sent to browser
DEBUG - 2023-09-12 20:16:03 --> Total execution time: 0.7316
INFO - 2023-09-12 20:16:14 --> Config Class Initialized
INFO - 2023-09-12 20:16:14 --> Hooks Class Initialized
DEBUG - 2023-09-12 20:16:14 --> UTF-8 Support Enabled
INFO - 2023-09-12 20:16:14 --> Utf8 Class Initialized
INFO - 2023-09-12 20:16:15 --> URI Class Initialized
DEBUG - 2023-09-12 20:16:15 --> No URI present. Default controller set.
INFO - 2023-09-12 20:16:15 --> Router Class Initialized
INFO - 2023-09-12 20:16:15 --> Output Class Initialized
INFO - 2023-09-12 20:16:15 --> Security Class Initialized
DEBUG - 2023-09-12 20:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 20:16:15 --> Input Class Initialized
INFO - 2023-09-12 20:16:15 --> Language Class Initialized
INFO - 2023-09-12 20:16:15 --> Loader Class Initialized
INFO - 2023-09-12 20:16:15 --> Helper loaded: url_helper
INFO - 2023-09-12 20:16:15 --> Helper loaded: file_helper
INFO - 2023-09-12 20:16:15 --> Database Driver Class Initialized
INFO - 2023-09-12 20:16:15 --> Email Class Initialized
DEBUG - 2023-09-12 20:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-12 20:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 20:16:15 --> Controller Class Initialized
INFO - 2023-09-12 20:16:15 --> Model "Contact_model" initialized
INFO - 2023-09-12 20:16:15 --> Model "Home_model" initialized
INFO - 2023-09-12 20:16:15 --> Helper loaded: download_helper
INFO - 2023-09-12 20:16:15 --> Helper loaded: form_helper
INFO - 2023-09-12 20:16:15 --> Form Validation Class Initialized
INFO - 2023-09-12 20:16:15 --> Helper loaded: custom_helper
INFO - 2023-09-12 20:16:15 --> Model "Social_media_model" initialized
INFO - 2023-09-12 20:16:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-12 20:16:15 --> Final output sent to browser
DEBUG - 2023-09-12 20:16:15 --> Total execution time: 0.5624
