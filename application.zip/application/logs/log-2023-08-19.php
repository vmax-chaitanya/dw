<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-19 11:43:38 --> Config Class Initialized
INFO - 2023-08-19 11:43:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:38 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:38 --> URI Class Initialized
INFO - 2023-08-19 11:43:38 --> Router Class Initialized
INFO - 2023-08-19 11:43:38 --> Output Class Initialized
INFO - 2023-08-19 11:43:38 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:38 --> Input Class Initialized
INFO - 2023-08-19 11:43:38 --> Language Class Initialized
INFO - 2023-08-19 11:43:38 --> Loader Class Initialized
INFO - 2023-08-19 11:43:39 --> Helper loaded: url_helper
INFO - 2023-08-19 11:43:39 --> Helper loaded: file_helper
INFO - 2023-08-19 11:43:39 --> Database Driver Class Initialized
INFO - 2023-08-19 11:43:39 --> Email Class Initialized
DEBUG - 2023-08-19 11:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 11:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 11:43:39 --> Controller Class Initialized
INFO - 2023-08-19 11:43:39 --> Model "Home_model" initialized
INFO - 2023-08-19 11:43:39 --> Helper loaded: form_helper
INFO - 2023-08-19 11:43:39 --> Form Validation Class Initialized
INFO - 2023-08-19 11:43:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 11:43:39 --> Final output sent to browser
DEBUG - 2023-08-19 11:43:39 --> Total execution time: 1.2632
INFO - 2023-08-19 11:43:40 --> Config Class Initialized
INFO - 2023-08-19 11:43:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:40 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:40 --> URI Class Initialized
INFO - 2023-08-19 11:43:40 --> Router Class Initialized
INFO - 2023-08-19 11:43:40 --> Output Class Initialized
INFO - 2023-08-19 11:43:40 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:40 --> Input Class Initialized
INFO - 2023-08-19 11:43:40 --> Language Class Initialized
INFO - 2023-08-19 11:43:40 --> Config Class Initialized
INFO - 2023-08-19 11:43:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:40 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:40 --> URI Class Initialized
INFO - 2023-08-19 11:43:40 --> Router Class Initialized
INFO - 2023-08-19 11:43:40 --> Output Class Initialized
INFO - 2023-08-19 11:43:40 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:40 --> Input Class Initialized
INFO - 2023-08-19 11:43:40 --> Language Class Initialized
INFO - 2023-08-19 11:43:40 --> Config Class Initialized
INFO - 2023-08-19 11:43:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:40 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:40 --> URI Class Initialized
INFO - 2023-08-19 11:43:40 --> Router Class Initialized
INFO - 2023-08-19 11:43:40 --> Output Class Initialized
INFO - 2023-08-19 11:43:40 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:40 --> Input Class Initialized
INFO - 2023-08-19 11:43:40 --> Language Class Initialized
ERROR - 2023-08-19 11:43:40 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-19 11:43:40 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-19 11:43:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:43:40 --> Config Class Initialized
INFO - 2023-08-19 11:43:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:40 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:40 --> URI Class Initialized
INFO - 2023-08-19 11:43:40 --> Router Class Initialized
INFO - 2023-08-19 11:43:40 --> Output Class Initialized
INFO - 2023-08-19 11:43:40 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:40 --> Input Class Initialized
INFO - 2023-08-19 11:43:40 --> Language Class Initialized
ERROR - 2023-08-19 11:43:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:43:40 --> Config Class Initialized
INFO - 2023-08-19 11:43:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:40 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:40 --> URI Class Initialized
INFO - 2023-08-19 11:43:40 --> Router Class Initialized
INFO - 2023-08-19 11:43:40 --> Output Class Initialized
INFO - 2023-08-19 11:43:40 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:40 --> Input Class Initialized
INFO - 2023-08-19 11:43:40 --> Language Class Initialized
ERROR - 2023-08-19 11:43:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:43:41 --> Config Class Initialized
INFO - 2023-08-19 11:43:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:41 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:41 --> URI Class Initialized
INFO - 2023-08-19 11:43:41 --> Router Class Initialized
INFO - 2023-08-19 11:43:41 --> Output Class Initialized
INFO - 2023-08-19 11:43:41 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:41 --> Input Class Initialized
INFO - 2023-08-19 11:43:41 --> Language Class Initialized
ERROR - 2023-08-19 11:43:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:43:41 --> Config Class Initialized
INFO - 2023-08-19 11:43:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:41 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:41 --> URI Class Initialized
INFO - 2023-08-19 11:43:41 --> Router Class Initialized
INFO - 2023-08-19 11:43:41 --> Output Class Initialized
INFO - 2023-08-19 11:43:41 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:41 --> Input Class Initialized
INFO - 2023-08-19 11:43:41 --> Language Class Initialized
ERROR - 2023-08-19 11:43:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:43:41 --> Config Class Initialized
INFO - 2023-08-19 11:43:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:43:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:43:41 --> Utf8 Class Initialized
INFO - 2023-08-19 11:43:41 --> URI Class Initialized
INFO - 2023-08-19 11:43:41 --> Router Class Initialized
INFO - 2023-08-19 11:43:41 --> Output Class Initialized
INFO - 2023-08-19 11:43:41 --> Security Class Initialized
DEBUG - 2023-08-19 11:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:43:41 --> Input Class Initialized
INFO - 2023-08-19 11:43:41 --> Language Class Initialized
ERROR - 2023-08-19 11:43:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:51:15 --> Config Class Initialized
INFO - 2023-08-19 11:51:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:15 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:15 --> URI Class Initialized
INFO - 2023-08-19 11:51:15 --> Router Class Initialized
INFO - 2023-08-19 11:51:15 --> Output Class Initialized
INFO - 2023-08-19 11:51:15 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:15 --> Input Class Initialized
INFO - 2023-08-19 11:51:15 --> Language Class Initialized
INFO - 2023-08-19 11:51:15 --> Loader Class Initialized
INFO - 2023-08-19 11:51:15 --> Helper loaded: url_helper
INFO - 2023-08-19 11:51:15 --> Helper loaded: file_helper
INFO - 2023-08-19 11:51:15 --> Database Driver Class Initialized
INFO - 2023-08-19 11:51:15 --> Email Class Initialized
DEBUG - 2023-08-19 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 11:51:15 --> Controller Class Initialized
INFO - 2023-08-19 11:51:15 --> Model "Home_model" initialized
INFO - 2023-08-19 11:51:15 --> Helper loaded: form_helper
INFO - 2023-08-19 11:51:15 --> Form Validation Class Initialized
INFO - 2023-08-19 11:51:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 11:51:15 --> Final output sent to browser
DEBUG - 2023-08-19 11:51:15 --> Total execution time: 0.2042
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:16 --> Config Class Initialized
INFO - 2023-08-19 11:51:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:16 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:16 --> URI Class Initialized
INFO - 2023-08-19 11:51:16 --> Router Class Initialized
INFO - 2023-08-19 11:51:16 --> Output Class Initialized
INFO - 2023-08-19 11:51:16 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:16 --> Input Class Initialized
INFO - 2023-08-19 11:51:16 --> Language Class Initialized
ERROR - 2023-08-19 11:51:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:17 --> Config Class Initialized
INFO - 2023-08-19 11:51:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:17 --> URI Class Initialized
INFO - 2023-08-19 11:51:17 --> Router Class Initialized
INFO - 2023-08-19 11:51:17 --> Output Class Initialized
INFO - 2023-08-19 11:51:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:17 --> Input Class Initialized
INFO - 2023-08-19 11:51:17 --> Language Class Initialized
ERROR - 2023-08-19 11:51:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:17 --> Config Class Initialized
INFO - 2023-08-19 11:51:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:17 --> URI Class Initialized
INFO - 2023-08-19 11:51:17 --> Router Class Initialized
INFO - 2023-08-19 11:51:17 --> Output Class Initialized
INFO - 2023-08-19 11:51:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:17 --> Input Class Initialized
INFO - 2023-08-19 11:51:17 --> Language Class Initialized
ERROR - 2023-08-19 11:51:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:51:53 --> Config Class Initialized
INFO - 2023-08-19 11:51:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:53 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:53 --> URI Class Initialized
INFO - 2023-08-19 11:51:59 --> Config Class Initialized
INFO - 2023-08-19 11:51:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:51:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:51:59 --> Utf8 Class Initialized
INFO - 2023-08-19 11:51:59 --> URI Class Initialized
INFO - 2023-08-19 11:51:59 --> Router Class Initialized
INFO - 2023-08-19 11:51:59 --> Output Class Initialized
INFO - 2023-08-19 11:51:59 --> Security Class Initialized
DEBUG - 2023-08-19 11:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:51:59 --> Input Class Initialized
INFO - 2023-08-19 11:51:59 --> Language Class Initialized
INFO - 2023-08-19 11:51:59 --> Loader Class Initialized
INFO - 2023-08-19 11:51:59 --> Helper loaded: url_helper
INFO - 2023-08-19 11:51:59 --> Helper loaded: file_helper
INFO - 2023-08-19 11:51:59 --> Database Driver Class Initialized
INFO - 2023-08-19 11:51:59 --> Email Class Initialized
DEBUG - 2023-08-19 11:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 11:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 11:51:59 --> Controller Class Initialized
INFO - 2023-08-19 11:51:59 --> Model "Home_model" initialized
INFO - 2023-08-19 11:51:59 --> Helper loaded: form_helper
INFO - 2023-08-19 11:51:59 --> Form Validation Class Initialized
INFO - 2023-08-19 11:51:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-19 11:51:59 --> Final output sent to browser
DEBUG - 2023-08-19 11:51:59 --> Total execution time: 0.1179
INFO - 2023-08-19 11:52:00 --> Config Class Initialized
INFO - 2023-08-19 11:52:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:00 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:00 --> URI Class Initialized
INFO - 2023-08-19 11:52:00 --> Router Class Initialized
INFO - 2023-08-19 11:52:00 --> Output Class Initialized
INFO - 2023-08-19 11:52:00 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:00 --> Input Class Initialized
INFO - 2023-08-19 11:52:00 --> Language Class Initialized
ERROR - 2023-08-19 11:52:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:00 --> Config Class Initialized
INFO - 2023-08-19 11:52:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:00 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:00 --> URI Class Initialized
INFO - 2023-08-19 11:52:00 --> Router Class Initialized
INFO - 2023-08-19 11:52:00 --> Output Class Initialized
INFO - 2023-08-19 11:52:00 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:00 --> Input Class Initialized
INFO - 2023-08-19 11:52:00 --> Language Class Initialized
ERROR - 2023-08-19 11:52:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:00 --> Config Class Initialized
INFO - 2023-08-19 11:52:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:00 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:00 --> URI Class Initialized
INFO - 2023-08-19 11:52:00 --> Router Class Initialized
INFO - 2023-08-19 11:52:00 --> Output Class Initialized
INFO - 2023-08-19 11:52:00 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:00 --> Input Class Initialized
INFO - 2023-08-19 11:52:00 --> Language Class Initialized
ERROR - 2023-08-19 11:52:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:52:01 --> Config Class Initialized
INFO - 2023-08-19 11:52:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:52:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:52:01 --> Utf8 Class Initialized
INFO - 2023-08-19 11:52:01 --> URI Class Initialized
INFO - 2023-08-19 11:52:01 --> Router Class Initialized
INFO - 2023-08-19 11:52:01 --> Output Class Initialized
INFO - 2023-08-19 11:52:01 --> Security Class Initialized
DEBUG - 2023-08-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:52:01 --> Input Class Initialized
INFO - 2023-08-19 11:52:01 --> Language Class Initialized
ERROR - 2023-08-19 11:52:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:07 --> Config Class Initialized
INFO - 2023-08-19 11:54:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:07 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:07 --> URI Class Initialized
INFO - 2023-08-19 11:54:07 --> Router Class Initialized
INFO - 2023-08-19 11:54:07 --> Output Class Initialized
INFO - 2023-08-19 11:54:07 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:07 --> Input Class Initialized
INFO - 2023-08-19 11:54:07 --> Language Class Initialized
INFO - 2023-08-19 11:54:07 --> Loader Class Initialized
INFO - 2023-08-19 11:54:07 --> Helper loaded: url_helper
INFO - 2023-08-19 11:54:07 --> Helper loaded: file_helper
INFO - 2023-08-19 11:54:07 --> Database Driver Class Initialized
INFO - 2023-08-19 11:54:07 --> Email Class Initialized
DEBUG - 2023-08-19 11:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 11:54:07 --> Controller Class Initialized
INFO - 2023-08-19 11:54:07 --> Model "Home_model" initialized
INFO - 2023-08-19 11:54:07 --> Helper loaded: form_helper
INFO - 2023-08-19 11:54:07 --> Form Validation Class Initialized
INFO - 2023-08-19 11:54:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 11:54:08 --> Final output sent to browser
DEBUG - 2023-08-19 11:54:08 --> Total execution time: 0.0520
INFO - 2023-08-19 11:54:08 --> Config Class Initialized
INFO - 2023-08-19 11:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:08 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:08 --> URI Class Initialized
INFO - 2023-08-19 11:54:08 --> Router Class Initialized
INFO - 2023-08-19 11:54:08 --> Output Class Initialized
INFO - 2023-08-19 11:54:08 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:08 --> Input Class Initialized
INFO - 2023-08-19 11:54:08 --> Language Class Initialized
ERROR - 2023-08-19 11:54:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:08 --> Config Class Initialized
INFO - 2023-08-19 11:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:08 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:08 --> URI Class Initialized
INFO - 2023-08-19 11:54:08 --> Router Class Initialized
INFO - 2023-08-19 11:54:08 --> Output Class Initialized
INFO - 2023-08-19 11:54:08 --> Config Class Initialized
INFO - 2023-08-19 11:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:08 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:08 --> URI Class Initialized
INFO - 2023-08-19 11:54:08 --> Router Class Initialized
INFO - 2023-08-19 11:54:08 --> Output Class Initialized
INFO - 2023-08-19 11:54:08 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:08 --> Input Class Initialized
INFO - 2023-08-19 11:54:08 --> Language Class Initialized
ERROR - 2023-08-19 11:54:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:08 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:08 --> Input Class Initialized
INFO - 2023-08-19 11:54:08 --> Language Class Initialized
ERROR - 2023-08-19 11:54:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:08 --> Config Class Initialized
INFO - 2023-08-19 11:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:08 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:08 --> URI Class Initialized
INFO - 2023-08-19 11:54:08 --> Router Class Initialized
INFO - 2023-08-19 11:54:08 --> Output Class Initialized
INFO - 2023-08-19 11:54:08 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:08 --> Input Class Initialized
INFO - 2023-08-19 11:54:08 --> Language Class Initialized
ERROR - 2023-08-19 11:54:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:08 --> Config Class Initialized
INFO - 2023-08-19 11:54:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:08 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:08 --> URI Class Initialized
INFO - 2023-08-19 11:54:08 --> Router Class Initialized
INFO - 2023-08-19 11:54:08 --> Output Class Initialized
INFO - 2023-08-19 11:54:08 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:08 --> Input Class Initialized
INFO - 2023-08-19 11:54:08 --> Language Class Initialized
ERROR - 2023-08-19 11:54:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:09 --> Config Class Initialized
INFO - 2023-08-19 11:54:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:09 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:09 --> URI Class Initialized
INFO - 2023-08-19 11:54:09 --> Router Class Initialized
INFO - 2023-08-19 11:54:09 --> Output Class Initialized
INFO - 2023-08-19 11:54:09 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:09 --> Input Class Initialized
INFO - 2023-08-19 11:54:09 --> Language Class Initialized
ERROR - 2023-08-19 11:54:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 11:54:17 --> Config Class Initialized
INFO - 2023-08-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:17 --> URI Class Initialized
INFO - 2023-08-19 11:54:17 --> Router Class Initialized
INFO - 2023-08-19 11:54:17 --> Output Class Initialized
INFO - 2023-08-19 11:54:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:17 --> Input Class Initialized
INFO - 2023-08-19 11:54:17 --> Language Class Initialized
INFO - 2023-08-19 11:54:17 --> Loader Class Initialized
INFO - 2023-08-19 11:54:17 --> Helper loaded: url_helper
INFO - 2023-08-19 11:54:17 --> Helper loaded: file_helper
INFO - 2023-08-19 11:54:17 --> Database Driver Class Initialized
INFO - 2023-08-19 11:54:17 --> Email Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 11:54:17 --> Controller Class Initialized
INFO - 2023-08-19 11:54:17 --> Model "Home_model" initialized
INFO - 2023-08-19 11:54:17 --> Helper loaded: form_helper
INFO - 2023-08-19 11:54:17 --> Form Validation Class Initialized
INFO - 2023-08-19 11:54:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 11:54:17 --> Final output sent to browser
DEBUG - 2023-08-19 11:54:17 --> Total execution time: 0.0599
INFO - 2023-08-19 11:54:17 --> Config Class Initialized
INFO - 2023-08-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:17 --> URI Class Initialized
INFO - 2023-08-19 11:54:17 --> Router Class Initialized
INFO - 2023-08-19 11:54:17 --> Output Class Initialized
INFO - 2023-08-19 11:54:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:17 --> Input Class Initialized
INFO - 2023-08-19 11:54:17 --> Language Class Initialized
ERROR - 2023-08-19 11:54:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:17 --> Config Class Initialized
INFO - 2023-08-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:17 --> URI Class Initialized
INFO - 2023-08-19 11:54:17 --> Router Class Initialized
INFO - 2023-08-19 11:54:17 --> Output Class Initialized
INFO - 2023-08-19 11:54:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:17 --> Input Class Initialized
INFO - 2023-08-19 11:54:17 --> Language Class Initialized
ERROR - 2023-08-19 11:54:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:17 --> Config Class Initialized
INFO - 2023-08-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:17 --> URI Class Initialized
INFO - 2023-08-19 11:54:17 --> Router Class Initialized
INFO - 2023-08-19 11:54:17 --> Output Class Initialized
INFO - 2023-08-19 11:54:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:17 --> Input Class Initialized
INFO - 2023-08-19 11:54:17 --> Language Class Initialized
ERROR - 2023-08-19 11:54:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:17 --> Config Class Initialized
INFO - 2023-08-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:17 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:17 --> URI Class Initialized
INFO - 2023-08-19 11:54:17 --> Router Class Initialized
INFO - 2023-08-19 11:54:17 --> Output Class Initialized
INFO - 2023-08-19 11:54:17 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:17 --> Input Class Initialized
INFO - 2023-08-19 11:54:17 --> Language Class Initialized
ERROR - 2023-08-19 11:54:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:18 --> Config Class Initialized
INFO - 2023-08-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:18 --> URI Class Initialized
INFO - 2023-08-19 11:54:18 --> Router Class Initialized
INFO - 2023-08-19 11:54:18 --> Output Class Initialized
INFO - 2023-08-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:18 --> Input Class Initialized
INFO - 2023-08-19 11:54:18 --> Language Class Initialized
ERROR - 2023-08-19 11:54:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:18 --> Config Class Initialized
INFO - 2023-08-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:18 --> URI Class Initialized
INFO - 2023-08-19 11:54:18 --> Router Class Initialized
INFO - 2023-08-19 11:54:18 --> Output Class Initialized
INFO - 2023-08-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:18 --> Input Class Initialized
INFO - 2023-08-19 11:54:18 --> Language Class Initialized
ERROR - 2023-08-19 11:54:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:18 --> Config Class Initialized
INFO - 2023-08-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:18 --> URI Class Initialized
INFO - 2023-08-19 11:54:18 --> Router Class Initialized
INFO - 2023-08-19 11:54:18 --> Output Class Initialized
INFO - 2023-08-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:18 --> Input Class Initialized
INFO - 2023-08-19 11:54:18 --> Language Class Initialized
ERROR - 2023-08-19 11:54:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:18 --> Config Class Initialized
INFO - 2023-08-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:18 --> URI Class Initialized
INFO - 2023-08-19 11:54:18 --> Router Class Initialized
INFO - 2023-08-19 11:54:18 --> Output Class Initialized
INFO - 2023-08-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:18 --> Input Class Initialized
INFO - 2023-08-19 11:54:18 --> Language Class Initialized
ERROR - 2023-08-19 11:54:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 11:54:18 --> Config Class Initialized
INFO - 2023-08-19 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 11:54:18 --> Utf8 Class Initialized
INFO - 2023-08-19 11:54:18 --> URI Class Initialized
INFO - 2023-08-19 11:54:18 --> Router Class Initialized
INFO - 2023-08-19 11:54:18 --> Output Class Initialized
INFO - 2023-08-19 11:54:18 --> Security Class Initialized
DEBUG - 2023-08-19 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 11:54:18 --> Input Class Initialized
INFO - 2023-08-19 11:54:18 --> Language Class Initialized
ERROR - 2023-08-19 11:54:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:00:46 --> Config Class Initialized
INFO - 2023-08-19 12:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:46 --> URI Class Initialized
INFO - 2023-08-19 12:00:46 --> Router Class Initialized
INFO - 2023-08-19 12:00:46 --> Output Class Initialized
INFO - 2023-08-19 12:00:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:46 --> Input Class Initialized
INFO - 2023-08-19 12:00:46 --> Language Class Initialized
INFO - 2023-08-19 12:00:46 --> Loader Class Initialized
INFO - 2023-08-19 12:00:46 --> Helper loaded: url_helper
INFO - 2023-08-19 12:00:46 --> Helper loaded: file_helper
INFO - 2023-08-19 12:00:46 --> Database Driver Class Initialized
INFO - 2023-08-19 12:00:46 --> Email Class Initialized
DEBUG - 2023-08-19 12:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:00:46 --> Controller Class Initialized
INFO - 2023-08-19 12:00:46 --> Model "Home_model" initialized
INFO - 2023-08-19 12:00:46 --> Helper loaded: form_helper
INFO - 2023-08-19 12:00:46 --> Form Validation Class Initialized
INFO - 2023-08-19 12:00:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 12:00:46 --> Final output sent to browser
DEBUG - 2023-08-19 12:00:46 --> Total execution time: 0.0382
INFO - 2023-08-19 12:00:46 --> Config Class Initialized
INFO - 2023-08-19 12:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:46 --> URI Class Initialized
INFO - 2023-08-19 12:00:46 --> Router Class Initialized
INFO - 2023-08-19 12:00:46 --> Output Class Initialized
INFO - 2023-08-19 12:00:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:46 --> Input Class Initialized
INFO - 2023-08-19 12:00:46 --> Language Class Initialized
ERROR - 2023-08-19 12:00:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:00:46 --> Config Class Initialized
INFO - 2023-08-19 12:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:46 --> URI Class Initialized
INFO - 2023-08-19 12:00:46 --> Router Class Initialized
INFO - 2023-08-19 12:00:46 --> Output Class Initialized
INFO - 2023-08-19 12:00:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:46 --> Input Class Initialized
INFO - 2023-08-19 12:00:46 --> Language Class Initialized
ERROR - 2023-08-19 12:00:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:00:46 --> Config Class Initialized
INFO - 2023-08-19 12:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:46 --> URI Class Initialized
INFO - 2023-08-19 12:00:46 --> Router Class Initialized
INFO - 2023-08-19 12:00:46 --> Output Class Initialized
INFO - 2023-08-19 12:00:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:46 --> Input Class Initialized
INFO - 2023-08-19 12:00:46 --> Language Class Initialized
ERROR - 2023-08-19 12:00:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:00:47 --> Config Class Initialized
INFO - 2023-08-19 12:00:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:47 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:47 --> URI Class Initialized
INFO - 2023-08-19 12:00:47 --> Router Class Initialized
INFO - 2023-08-19 12:00:47 --> Output Class Initialized
INFO - 2023-08-19 12:00:47 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:47 --> Input Class Initialized
INFO - 2023-08-19 12:00:47 --> Language Class Initialized
ERROR - 2023-08-19 12:00:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:00:47 --> Config Class Initialized
INFO - 2023-08-19 12:00:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:47 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:47 --> URI Class Initialized
INFO - 2023-08-19 12:00:47 --> Router Class Initialized
INFO - 2023-08-19 12:00:47 --> Output Class Initialized
INFO - 2023-08-19 12:00:47 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:47 --> Input Class Initialized
INFO - 2023-08-19 12:00:47 --> Language Class Initialized
ERROR - 2023-08-19 12:00:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:00:47 --> Config Class Initialized
INFO - 2023-08-19 12:00:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:00:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:00:47 --> Utf8 Class Initialized
INFO - 2023-08-19 12:00:47 --> URI Class Initialized
INFO - 2023-08-19 12:00:47 --> Router Class Initialized
INFO - 2023-08-19 12:00:47 --> Output Class Initialized
INFO - 2023-08-19 12:00:47 --> Security Class Initialized
DEBUG - 2023-08-19 12:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:00:47 --> Input Class Initialized
INFO - 2023-08-19 12:00:47 --> Language Class Initialized
ERROR - 2023-08-19 12:00:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:01:46 --> Config Class Initialized
INFO - 2023-08-19 12:01:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:01:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:01:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:01:46 --> URI Class Initialized
INFO - 2023-08-19 12:01:46 --> Router Class Initialized
INFO - 2023-08-19 12:01:46 --> Output Class Initialized
INFO - 2023-08-19 12:01:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:01:46 --> Input Class Initialized
INFO - 2023-08-19 12:01:46 --> Language Class Initialized
INFO - 2023-08-19 12:01:46 --> Loader Class Initialized
INFO - 2023-08-19 12:01:46 --> Helper loaded: url_helper
INFO - 2023-08-19 12:01:46 --> Helper loaded: file_helper
INFO - 2023-08-19 12:01:46 --> Database Driver Class Initialized
INFO - 2023-08-19 12:01:46 --> Email Class Initialized
DEBUG - 2023-08-19 12:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:01:46 --> Controller Class Initialized
INFO - 2023-08-19 12:01:46 --> Config Class Initialized
INFO - 2023-08-19 12:01:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:01:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:01:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:01:46 --> URI Class Initialized
INFO - 2023-08-19 12:01:46 --> Router Class Initialized
INFO - 2023-08-19 12:01:46 --> Output Class Initialized
INFO - 2023-08-19 12:01:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:01:46 --> Input Class Initialized
INFO - 2023-08-19 12:01:46 --> Language Class Initialized
INFO - 2023-08-19 12:01:46 --> Loader Class Initialized
INFO - 2023-08-19 12:01:46 --> Helper loaded: url_helper
INFO - 2023-08-19 12:01:46 --> Helper loaded: file_helper
INFO - 2023-08-19 12:01:46 --> Database Driver Class Initialized
INFO - 2023-08-19 12:01:46 --> Email Class Initialized
DEBUG - 2023-08-19 12:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:01:46 --> Controller Class Initialized
INFO - 2023-08-19 12:01:46 --> Model "User_model" initialized
INFO - 2023-08-19 12:01:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-19 12:01:46 --> Final output sent to browser
DEBUG - 2023-08-19 12:01:46 --> Total execution time: 0.1782
INFO - 2023-08-19 12:01:47 --> Config Class Initialized
INFO - 2023-08-19 12:01:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:01:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:01:47 --> Utf8 Class Initialized
INFO - 2023-08-19 12:01:47 --> URI Class Initialized
INFO - 2023-08-19 12:01:47 --> Router Class Initialized
INFO - 2023-08-19 12:01:47 --> Output Class Initialized
INFO - 2023-08-19 12:01:47 --> Security Class Initialized
DEBUG - 2023-08-19 12:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:01:47 --> Input Class Initialized
INFO - 2023-08-19 12:01:47 --> Language Class Initialized
ERROR - 2023-08-19 12:01:47 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-19 12:01:54 --> Config Class Initialized
INFO - 2023-08-19 12:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:01:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:01:54 --> URI Class Initialized
INFO - 2023-08-19 12:01:54 --> Router Class Initialized
INFO - 2023-08-19 12:01:54 --> Output Class Initialized
INFO - 2023-08-19 12:01:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:01:54 --> Input Class Initialized
INFO - 2023-08-19 12:01:54 --> Language Class Initialized
INFO - 2023-08-19 12:01:54 --> Loader Class Initialized
INFO - 2023-08-19 12:01:54 --> Helper loaded: url_helper
INFO - 2023-08-19 12:01:54 --> Helper loaded: file_helper
INFO - 2023-08-19 12:01:54 --> Database Driver Class Initialized
INFO - 2023-08-19 12:01:54 --> Email Class Initialized
DEBUG - 2023-08-19 12:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:01:54 --> Controller Class Initialized
INFO - 2023-08-19 12:01:54 --> Model "User_model" initialized
INFO - 2023-08-19 12:01:54 --> Config Class Initialized
INFO - 2023-08-19 12:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:01:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:01:54 --> URI Class Initialized
INFO - 2023-08-19 12:01:54 --> Router Class Initialized
INFO - 2023-08-19 12:01:54 --> Output Class Initialized
INFO - 2023-08-19 12:01:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:01:54 --> Input Class Initialized
INFO - 2023-08-19 12:01:54 --> Language Class Initialized
INFO - 2023-08-19 12:01:54 --> Loader Class Initialized
INFO - 2023-08-19 12:01:54 --> Helper loaded: url_helper
INFO - 2023-08-19 12:01:54 --> Helper loaded: file_helper
INFO - 2023-08-19 12:01:54 --> Database Driver Class Initialized
INFO - 2023-08-19 12:01:54 --> Email Class Initialized
DEBUG - 2023-08-19 12:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:01:54 --> Controller Class Initialized
INFO - 2023-08-19 12:01:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-19 12:01:55 --> Final output sent to browser
DEBUG - 2023-08-19 12:01:55 --> Total execution time: 0.1468
INFO - 2023-08-19 12:02:03 --> Config Class Initialized
INFO - 2023-08-19 12:02:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:02:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:02:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:02:03 --> URI Class Initialized
INFO - 2023-08-19 12:02:03 --> Router Class Initialized
INFO - 2023-08-19 12:02:03 --> Output Class Initialized
INFO - 2023-08-19 12:02:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:02:03 --> Input Class Initialized
INFO - 2023-08-19 12:02:03 --> Language Class Initialized
INFO - 2023-08-19 12:02:03 --> Loader Class Initialized
INFO - 2023-08-19 12:02:03 --> Helper loaded: url_helper
INFO - 2023-08-19 12:02:03 --> Helper loaded: file_helper
INFO - 2023-08-19 12:02:03 --> Database Driver Class Initialized
INFO - 2023-08-19 12:02:03 --> Email Class Initialized
DEBUG - 2023-08-19 12:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:02:03 --> Controller Class Initialized
INFO - 2023-08-19 12:02:04 --> Model "Blog_model" initialized
INFO - 2023-08-19 12:02:04 --> Helper loaded: form_helper
INFO - 2023-08-19 12:02:04 --> Form Validation Class Initialized
INFO - 2023-08-19 12:02:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-19 12:02:05 --> Final output sent to browser
DEBUG - 2023-08-19 12:02:05 --> Total execution time: 1.6467
INFO - 2023-08-19 12:02:12 --> Config Class Initialized
INFO - 2023-08-19 12:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:02:12 --> Utf8 Class Initialized
INFO - 2023-08-19 12:02:12 --> URI Class Initialized
INFO - 2023-08-19 12:02:12 --> Router Class Initialized
INFO - 2023-08-19 12:02:12 --> Output Class Initialized
INFO - 2023-08-19 12:02:12 --> Security Class Initialized
DEBUG - 2023-08-19 12:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:02:12 --> Input Class Initialized
INFO - 2023-08-19 12:02:12 --> Language Class Initialized
INFO - 2023-08-19 12:02:12 --> Loader Class Initialized
INFO - 2023-08-19 12:02:12 --> Helper loaded: url_helper
INFO - 2023-08-19 12:02:12 --> Helper loaded: file_helper
INFO - 2023-08-19 12:02:12 --> Database Driver Class Initialized
INFO - 2023-08-19 12:02:12 --> Email Class Initialized
DEBUG - 2023-08-19 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:02:12 --> Controller Class Initialized
INFO - 2023-08-19 12:02:12 --> Model "Blog_model" initialized
INFO - 2023-08-19 12:02:12 --> Helper loaded: form_helper
INFO - 2023-08-19 12:02:12 --> Form Validation Class Initialized
INFO - 2023-08-19 12:02:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-19 12:02:12 --> Final output sent to browser
DEBUG - 2023-08-19 12:02:12 --> Total execution time: 0.1518
INFO - 2023-08-19 12:02:12 --> Config Class Initialized
INFO - 2023-08-19 12:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:02:12 --> Utf8 Class Initialized
INFO - 2023-08-19 12:02:12 --> URI Class Initialized
INFO - 2023-08-19 12:02:12 --> Router Class Initialized
INFO - 2023-08-19 12:02:12 --> Output Class Initialized
INFO - 2023-08-19 12:02:12 --> Security Class Initialized
DEBUG - 2023-08-19 12:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:02:12 --> Input Class Initialized
INFO - 2023-08-19 12:02:12 --> Language Class Initialized
ERROR - 2023-08-19 12:02:12 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-19 12:02:57 --> Config Class Initialized
INFO - 2023-08-19 12:02:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:02:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:02:57 --> Utf8 Class Initialized
INFO - 2023-08-19 12:02:57 --> URI Class Initialized
INFO - 2023-08-19 12:02:57 --> Router Class Initialized
INFO - 2023-08-19 12:02:57 --> Output Class Initialized
INFO - 2023-08-19 12:02:57 --> Security Class Initialized
DEBUG - 2023-08-19 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:02:57 --> Input Class Initialized
INFO - 2023-08-19 12:02:57 --> Language Class Initialized
INFO - 2023-08-19 12:02:57 --> Loader Class Initialized
INFO - 2023-08-19 12:02:57 --> Helper loaded: url_helper
INFO - 2023-08-19 12:02:57 --> Helper loaded: file_helper
INFO - 2023-08-19 12:02:57 --> Database Driver Class Initialized
INFO - 2023-08-19 12:02:57 --> Email Class Initialized
DEBUG - 2023-08-19 12:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:02:57 --> Controller Class Initialized
INFO - 2023-08-19 12:02:57 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:02:57 --> Helper loaded: form_helper
INFO - 2023-08-19 12:02:57 --> Form Validation Class Initialized
INFO - 2023-08-19 12:02:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-19 12:02:58 --> Final output sent to browser
DEBUG - 2023-08-19 12:02:58 --> Total execution time: 0.2298
INFO - 2023-08-19 12:03:01 --> Config Class Initialized
INFO - 2023-08-19 12:03:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:01 --> URI Class Initialized
INFO - 2023-08-19 12:03:01 --> Router Class Initialized
INFO - 2023-08-19 12:03:01 --> Output Class Initialized
INFO - 2023-08-19 12:03:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:01 --> Input Class Initialized
INFO - 2023-08-19 12:03:01 --> Language Class Initialized
INFO - 2023-08-19 12:03:01 --> Loader Class Initialized
INFO - 2023-08-19 12:03:01 --> Helper loaded: url_helper
INFO - 2023-08-19 12:03:01 --> Helper loaded: file_helper
INFO - 2023-08-19 12:03:01 --> Database Driver Class Initialized
INFO - 2023-08-19 12:03:01 --> Email Class Initialized
DEBUG - 2023-08-19 12:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:03:01 --> Controller Class Initialized
INFO - 2023-08-19 12:03:01 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:03:01 --> Helper loaded: form_helper
INFO - 2023-08-19 12:03:01 --> Form Validation Class Initialized
INFO - 2023-08-19 12:03:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-19 12:03:01 --> Final output sent to browser
DEBUG - 2023-08-19 12:03:01 --> Total execution time: 0.1175
INFO - 2023-08-19 12:03:02 --> Config Class Initialized
INFO - 2023-08-19 12:03:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:02 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:02 --> URI Class Initialized
INFO - 2023-08-19 12:03:02 --> Router Class Initialized
INFO - 2023-08-19 12:03:02 --> Output Class Initialized
INFO - 2023-08-19 12:03:02 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:02 --> Input Class Initialized
INFO - 2023-08-19 12:03:02 --> Language Class Initialized
ERROR - 2023-08-19 12:03:02 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-19 12:03:06 --> Config Class Initialized
INFO - 2023-08-19 12:03:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:06 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:06 --> URI Class Initialized
INFO - 2023-08-19 12:03:06 --> Router Class Initialized
INFO - 2023-08-19 12:03:06 --> Output Class Initialized
INFO - 2023-08-19 12:03:06 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:06 --> Input Class Initialized
INFO - 2023-08-19 12:03:06 --> Language Class Initialized
INFO - 2023-08-19 12:03:06 --> Loader Class Initialized
INFO - 2023-08-19 12:03:06 --> Helper loaded: url_helper
INFO - 2023-08-19 12:03:06 --> Helper loaded: file_helper
INFO - 2023-08-19 12:03:06 --> Database Driver Class Initialized
INFO - 2023-08-19 12:03:06 --> Email Class Initialized
DEBUG - 2023-08-19 12:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:03:06 --> Controller Class Initialized
INFO - 2023-08-19 12:03:06 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:03:06 --> Helper loaded: form_helper
INFO - 2023-08-19 12:03:06 --> Form Validation Class Initialized
INFO - 2023-08-19 12:03:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-19 12:03:06 --> Final output sent to browser
DEBUG - 2023-08-19 12:03:06 --> Total execution time: 0.0507
INFO - 2023-08-19 12:03:38 --> Config Class Initialized
INFO - 2023-08-19 12:03:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:38 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:38 --> URI Class Initialized
INFO - 2023-08-19 12:03:38 --> Router Class Initialized
INFO - 2023-08-19 12:03:38 --> Output Class Initialized
INFO - 2023-08-19 12:03:38 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:38 --> Input Class Initialized
INFO - 2023-08-19 12:03:38 --> Language Class Initialized
INFO - 2023-08-19 12:03:38 --> Loader Class Initialized
INFO - 2023-08-19 12:03:38 --> Helper loaded: url_helper
INFO - 2023-08-19 12:03:38 --> Helper loaded: file_helper
INFO - 2023-08-19 12:03:38 --> Database Driver Class Initialized
INFO - 2023-08-19 12:03:38 --> Email Class Initialized
DEBUG - 2023-08-19 12:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:03:38 --> Controller Class Initialized
INFO - 2023-08-19 12:03:38 --> Model "Gallery_model" initialized
INFO - 2023-08-19 12:03:38 --> Helper loaded: form_helper
INFO - 2023-08-19 12:03:38 --> Form Validation Class Initialized
INFO - 2023-08-19 12:03:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-19 12:03:38 --> Final output sent to browser
DEBUG - 2023-08-19 12:03:38 --> Total execution time: 0.2181
INFO - 2023-08-19 12:03:42 --> Config Class Initialized
INFO - 2023-08-19 12:03:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:42 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:42 --> URI Class Initialized
INFO - 2023-08-19 12:03:42 --> Router Class Initialized
INFO - 2023-08-19 12:03:42 --> Output Class Initialized
INFO - 2023-08-19 12:03:42 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:42 --> Input Class Initialized
INFO - 2023-08-19 12:03:42 --> Language Class Initialized
INFO - 2023-08-19 12:03:42 --> Loader Class Initialized
INFO - 2023-08-19 12:03:42 --> Helper loaded: url_helper
INFO - 2023-08-19 12:03:42 --> Helper loaded: file_helper
INFO - 2023-08-19 12:03:42 --> Database Driver Class Initialized
INFO - 2023-08-19 12:03:42 --> Email Class Initialized
DEBUG - 2023-08-19 12:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:03:42 --> Controller Class Initialized
INFO - 2023-08-19 12:03:42 --> Model "Gallery_model" initialized
INFO - 2023-08-19 12:03:42 --> Helper loaded: form_helper
INFO - 2023-08-19 12:03:42 --> Form Validation Class Initialized
INFO - 2023-08-19 12:03:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_create.php
INFO - 2023-08-19 12:03:42 --> Final output sent to browser
DEBUG - 2023-08-19 12:03:42 --> Total execution time: 0.1207
INFO - 2023-08-19 12:03:43 --> Config Class Initialized
INFO - 2023-08-19 12:03:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:03:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:03:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:03:43 --> URI Class Initialized
INFO - 2023-08-19 12:03:43 --> Router Class Initialized
INFO - 2023-08-19 12:03:43 --> Output Class Initialized
INFO - 2023-08-19 12:03:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:03:43 --> Input Class Initialized
INFO - 2023-08-19 12:03:43 --> Language Class Initialized
ERROR - 2023-08-19 12:03:43 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-19 12:04:29 --> Config Class Initialized
INFO - 2023-08-19 12:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:04:29 --> Utf8 Class Initialized
INFO - 2023-08-19 12:04:29 --> URI Class Initialized
INFO - 2023-08-19 12:04:29 --> Router Class Initialized
INFO - 2023-08-19 12:04:29 --> Output Class Initialized
INFO - 2023-08-19 12:04:29 --> Security Class Initialized
DEBUG - 2023-08-19 12:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:04:29 --> Input Class Initialized
INFO - 2023-08-19 12:04:29 --> Language Class Initialized
INFO - 2023-08-19 12:04:29 --> Loader Class Initialized
INFO - 2023-08-19 12:04:29 --> Helper loaded: url_helper
INFO - 2023-08-19 12:04:29 --> Helper loaded: file_helper
INFO - 2023-08-19 12:04:29 --> Database Driver Class Initialized
INFO - 2023-08-19 12:04:29 --> Email Class Initialized
DEBUG - 2023-08-19 12:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:04:29 --> Controller Class Initialized
INFO - 2023-08-19 12:04:29 --> Model "Services_model" initialized
INFO - 2023-08-19 12:04:29 --> Helper loaded: form_helper
INFO - 2023-08-19 12:04:29 --> Form Validation Class Initialized
INFO - 2023-08-19 12:04:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-19 12:04:29 --> Final output sent to browser
DEBUG - 2023-08-19 12:04:29 --> Total execution time: 0.2397
INFO - 2023-08-19 12:04:29 --> Config Class Initialized
INFO - 2023-08-19 12:04:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:04:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:04:29 --> Utf8 Class Initialized
INFO - 2023-08-19 12:04:29 --> URI Class Initialized
INFO - 2023-08-19 12:04:29 --> Router Class Initialized
INFO - 2023-08-19 12:04:29 --> Output Class Initialized
INFO - 2023-08-19 12:04:29 --> Security Class Initialized
DEBUG - 2023-08-19 12:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:04:29 --> Input Class Initialized
INFO - 2023-08-19 12:04:29 --> Language Class Initialized
ERROR - 2023-08-19 12:04:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:04:36 --> Config Class Initialized
INFO - 2023-08-19 12:04:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:04:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:04:36 --> Utf8 Class Initialized
INFO - 2023-08-19 12:04:36 --> URI Class Initialized
INFO - 2023-08-19 12:04:36 --> Router Class Initialized
INFO - 2023-08-19 12:04:36 --> Output Class Initialized
INFO - 2023-08-19 12:04:36 --> Security Class Initialized
DEBUG - 2023-08-19 12:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:04:36 --> Input Class Initialized
INFO - 2023-08-19 12:04:36 --> Language Class Initialized
INFO - 2023-08-19 12:04:36 --> Loader Class Initialized
INFO - 2023-08-19 12:04:36 --> Helper loaded: url_helper
INFO - 2023-08-19 12:04:36 --> Helper loaded: file_helper
INFO - 2023-08-19 12:04:36 --> Database Driver Class Initialized
INFO - 2023-08-19 12:04:36 --> Email Class Initialized
DEBUG - 2023-08-19 12:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:04:36 --> Controller Class Initialized
INFO - 2023-08-19 12:04:36 --> Model "Services_model" initialized
INFO - 2023-08-19 12:04:36 --> Helper loaded: form_helper
INFO - 2023-08-19 12:04:36 --> Form Validation Class Initialized
INFO - 2023-08-19 12:04:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-19 12:04:36 --> Final output sent to browser
DEBUG - 2023-08-19 12:04:36 --> Total execution time: 0.1282
INFO - 2023-08-19 12:04:36 --> Config Class Initialized
INFO - 2023-08-19 12:04:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:04:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:04:36 --> Utf8 Class Initialized
INFO - 2023-08-19 12:04:36 --> URI Class Initialized
INFO - 2023-08-19 12:04:36 --> Router Class Initialized
INFO - 2023-08-19 12:04:36 --> Output Class Initialized
INFO - 2023-08-19 12:04:36 --> Security Class Initialized
DEBUG - 2023-08-19 12:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:04:36 --> Input Class Initialized
INFO - 2023-08-19 12:04:36 --> Language Class Initialized
ERROR - 2023-08-19 12:04:36 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-19 12:07:03 --> Config Class Initialized
INFO - 2023-08-19 12:07:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:03 --> URI Class Initialized
INFO - 2023-08-19 12:07:03 --> Router Class Initialized
INFO - 2023-08-19 12:07:03 --> Output Class Initialized
INFO - 2023-08-19 12:07:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:03 --> Input Class Initialized
INFO - 2023-08-19 12:07:03 --> Language Class Initialized
INFO - 2023-08-19 12:07:03 --> Loader Class Initialized
INFO - 2023-08-19 12:07:03 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:03 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:03 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:03 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:03 --> Controller Class Initialized
INFO - 2023-08-19 12:07:03 --> Model "Services_model" initialized
INFO - 2023-08-19 12:07:03 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:03 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-19 12:07:04 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:04 --> Total execution time: 0.0489
INFO - 2023-08-19 12:07:04 --> Config Class Initialized
INFO - 2023-08-19 12:07:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:04 --> URI Class Initialized
INFO - 2023-08-19 12:07:04 --> Router Class Initialized
INFO - 2023-08-19 12:07:04 --> Output Class Initialized
INFO - 2023-08-19 12:07:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:04 --> Input Class Initialized
INFO - 2023-08-19 12:07:04 --> Language Class Initialized
ERROR - 2023-08-19 12:07:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:07:29 --> Config Class Initialized
INFO - 2023-08-19 12:07:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:29 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:29 --> URI Class Initialized
INFO - 2023-08-19 12:07:29 --> Router Class Initialized
INFO - 2023-08-19 12:07:29 --> Output Class Initialized
INFO - 2023-08-19 12:07:29 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:29 --> Input Class Initialized
INFO - 2023-08-19 12:07:29 --> Language Class Initialized
INFO - 2023-08-19 12:07:29 --> Loader Class Initialized
INFO - 2023-08-19 12:07:29 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:29 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:29 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:29 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:29 --> Controller Class Initialized
INFO - 2023-08-19 12:07:29 --> Model "Certification_courses_model" initialized
INFO - 2023-08-19 12:07:29 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:29 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-19 12:07:29 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:29 --> Total execution time: 0.2220
INFO - 2023-08-19 12:07:31 --> Config Class Initialized
INFO - 2023-08-19 12:07:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:31 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:31 --> URI Class Initialized
INFO - 2023-08-19 12:07:31 --> Router Class Initialized
INFO - 2023-08-19 12:07:31 --> Output Class Initialized
INFO - 2023-08-19 12:07:31 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:31 --> Input Class Initialized
INFO - 2023-08-19 12:07:31 --> Language Class Initialized
INFO - 2023-08-19 12:07:31 --> Loader Class Initialized
INFO - 2023-08-19 12:07:31 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:31 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:31 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:31 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:31 --> Controller Class Initialized
INFO - 2023-08-19 12:07:31 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:31 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:31 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_list.php
INFO - 2023-08-19 12:07:31 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:31 --> Total execution time: 0.2268
INFO - 2023-08-19 12:07:33 --> Config Class Initialized
INFO - 2023-08-19 12:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:33 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:33 --> URI Class Initialized
INFO - 2023-08-19 12:07:33 --> Router Class Initialized
INFO - 2023-08-19 12:07:33 --> Output Class Initialized
INFO - 2023-08-19 12:07:33 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:33 --> Input Class Initialized
INFO - 2023-08-19 12:07:33 --> Language Class Initialized
INFO - 2023-08-19 12:07:33 --> Loader Class Initialized
INFO - 2023-08-19 12:07:33 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:33 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:33 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:33 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:33 --> Controller Class Initialized
INFO - 2023-08-19 12:07:33 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:33 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:33 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_create.php
INFO - 2023-08-19 12:07:33 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:33 --> Total execution time: 0.1930
INFO - 2023-08-19 12:07:33 --> Config Class Initialized
INFO - 2023-08-19 12:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:33 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:33 --> URI Class Initialized
INFO - 2023-08-19 12:07:33 --> Router Class Initialized
INFO - 2023-08-19 12:07:33 --> Output Class Initialized
INFO - 2023-08-19 12:07:33 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:33 --> Input Class Initialized
INFO - 2023-08-19 12:07:33 --> Language Class Initialized
ERROR - 2023-08-19 12:07:33 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-19 12:07:39 --> Config Class Initialized
INFO - 2023-08-19 12:07:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:39 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:39 --> URI Class Initialized
INFO - 2023-08-19 12:07:39 --> Router Class Initialized
INFO - 2023-08-19 12:07:39 --> Output Class Initialized
INFO - 2023-08-19 12:07:39 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:39 --> Input Class Initialized
INFO - 2023-08-19 12:07:39 --> Language Class Initialized
INFO - 2023-08-19 12:07:39 --> Loader Class Initialized
INFO - 2023-08-19 12:07:39 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:39 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:39 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:39 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:39 --> Controller Class Initialized
INFO - 2023-08-19 12:07:39 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:39 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:39 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-19 12:07:39 --> Config Class Initialized
INFO - 2023-08-19 12:07:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:39 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:39 --> URI Class Initialized
INFO - 2023-08-19 12:07:39 --> Router Class Initialized
INFO - 2023-08-19 12:07:39 --> Output Class Initialized
INFO - 2023-08-19 12:07:39 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:39 --> Input Class Initialized
INFO - 2023-08-19 12:07:39 --> Language Class Initialized
ERROR - 2023-08-19 12:07:39 --> 404 Page Not Found: admin/Faq_create/index
INFO - 2023-08-19 12:07:42 --> Config Class Initialized
INFO - 2023-08-19 12:07:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:42 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:42 --> URI Class Initialized
INFO - 2023-08-19 12:07:42 --> Router Class Initialized
INFO - 2023-08-19 12:07:42 --> Output Class Initialized
INFO - 2023-08-19 12:07:42 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:42 --> Input Class Initialized
INFO - 2023-08-19 12:07:42 --> Language Class Initialized
INFO - 2023-08-19 12:07:42 --> Loader Class Initialized
INFO - 2023-08-19 12:07:42 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:42 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:42 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:42 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:42 --> Controller Class Initialized
INFO - 2023-08-19 12:07:42 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:42 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:42 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_create.php
INFO - 2023-08-19 12:07:42 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:42 --> Total execution time: 0.0388
INFO - 2023-08-19 12:07:44 --> Config Class Initialized
INFO - 2023-08-19 12:07:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:44 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:44 --> URI Class Initialized
INFO - 2023-08-19 12:07:44 --> Router Class Initialized
INFO - 2023-08-19 12:07:44 --> Output Class Initialized
INFO - 2023-08-19 12:07:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:44 --> Input Class Initialized
INFO - 2023-08-19 12:07:44 --> Language Class Initialized
INFO - 2023-08-19 12:07:44 --> Loader Class Initialized
INFO - 2023-08-19 12:07:44 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:44 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:44 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:44 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:44 --> Controller Class Initialized
INFO - 2023-08-19 12:07:44 --> Model "Certification_courses_model" initialized
INFO - 2023-08-19 12:07:44 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:44 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/certification_courses_list.php
INFO - 2023-08-19 12:07:44 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:44 --> Total execution time: 0.0428
INFO - 2023-08-19 12:07:46 --> Config Class Initialized
INFO - 2023-08-19 12:07:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:46 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:46 --> URI Class Initialized
INFO - 2023-08-19 12:07:46 --> Router Class Initialized
INFO - 2023-08-19 12:07:46 --> Output Class Initialized
INFO - 2023-08-19 12:07:46 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:46 --> Input Class Initialized
INFO - 2023-08-19 12:07:46 --> Language Class Initialized
INFO - 2023-08-19 12:07:46 --> Loader Class Initialized
INFO - 2023-08-19 12:07:46 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:46 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:46 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:46 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:46 --> Controller Class Initialized
INFO - 2023-08-19 12:07:46 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:46 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:46 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_list.php
INFO - 2023-08-19 12:07:46 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:46 --> Total execution time: 0.0384
INFO - 2023-08-19 12:07:52 --> Config Class Initialized
INFO - 2023-08-19 12:07:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:52 --> URI Class Initialized
INFO - 2023-08-19 12:07:52 --> Router Class Initialized
INFO - 2023-08-19 12:07:52 --> Output Class Initialized
INFO - 2023-08-19 12:07:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:52 --> Input Class Initialized
INFO - 2023-08-19 12:07:52 --> Language Class Initialized
INFO - 2023-08-19 12:07:52 --> Loader Class Initialized
INFO - 2023-08-19 12:07:52 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:52 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:52 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:52 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:52 --> Controller Class Initialized
INFO - 2023-08-19 12:07:52 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:52 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:52 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_create.php
INFO - 2023-08-19 12:07:52 --> Final output sent to browser
DEBUG - 2023-08-19 12:07:52 --> Total execution time: 0.0431
INFO - 2023-08-19 12:07:57 --> Config Class Initialized
INFO - 2023-08-19 12:07:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:57 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:57 --> URI Class Initialized
INFO - 2023-08-19 12:07:57 --> Router Class Initialized
INFO - 2023-08-19 12:07:57 --> Output Class Initialized
INFO - 2023-08-19 12:07:57 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:57 --> Input Class Initialized
INFO - 2023-08-19 12:07:57 --> Language Class Initialized
INFO - 2023-08-19 12:07:57 --> Loader Class Initialized
INFO - 2023-08-19 12:07:57 --> Helper loaded: url_helper
INFO - 2023-08-19 12:07:57 --> Helper loaded: file_helper
INFO - 2023-08-19 12:07:57 --> Database Driver Class Initialized
INFO - 2023-08-19 12:07:57 --> Email Class Initialized
DEBUG - 2023-08-19 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:07:57 --> Controller Class Initialized
INFO - 2023-08-19 12:07:57 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:07:57 --> Helper loaded: form_helper
INFO - 2023-08-19 12:07:57 --> Form Validation Class Initialized
INFO - 2023-08-19 12:07:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-19 12:07:57 --> Config Class Initialized
INFO - 2023-08-19 12:07:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:07:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:07:57 --> Utf8 Class Initialized
INFO - 2023-08-19 12:07:57 --> URI Class Initialized
INFO - 2023-08-19 12:07:57 --> Router Class Initialized
INFO - 2023-08-19 12:07:57 --> Output Class Initialized
INFO - 2023-08-19 12:07:57 --> Security Class Initialized
DEBUG - 2023-08-19 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:07:57 --> Input Class Initialized
INFO - 2023-08-19 12:07:57 --> Language Class Initialized
ERROR - 2023-08-19 12:07:57 --> 404 Page Not Found: admin/Faq_create/index
INFO - 2023-08-19 12:08:01 --> Config Class Initialized
INFO - 2023-08-19 12:08:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:08:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:08:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:08:01 --> URI Class Initialized
INFO - 2023-08-19 12:08:01 --> Router Class Initialized
INFO - 2023-08-19 12:08:01 --> Output Class Initialized
INFO - 2023-08-19 12:08:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:08:01 --> Input Class Initialized
INFO - 2023-08-19 12:08:01 --> Language Class Initialized
INFO - 2023-08-19 12:08:01 --> Loader Class Initialized
INFO - 2023-08-19 12:08:01 --> Helper loaded: url_helper
INFO - 2023-08-19 12:08:01 --> Helper loaded: file_helper
INFO - 2023-08-19 12:08:01 --> Database Driver Class Initialized
INFO - 2023-08-19 12:08:01 --> Email Class Initialized
DEBUG - 2023-08-19 12:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:08:01 --> Controller Class Initialized
INFO - 2023-08-19 12:08:01 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:08:01 --> Helper loaded: form_helper
INFO - 2023-08-19 12:08:01 --> Form Validation Class Initialized
INFO - 2023-08-19 12:08:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_create.php
INFO - 2023-08-19 12:08:01 --> Final output sent to browser
DEBUG - 2023-08-19 12:08:01 --> Total execution time: 0.0454
INFO - 2023-08-19 12:08:03 --> Config Class Initialized
INFO - 2023-08-19 12:08:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:08:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:08:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:08:03 --> URI Class Initialized
INFO - 2023-08-19 12:08:03 --> Router Class Initialized
INFO - 2023-08-19 12:08:03 --> Output Class Initialized
INFO - 2023-08-19 12:08:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:08:03 --> Input Class Initialized
INFO - 2023-08-19 12:08:03 --> Language Class Initialized
INFO - 2023-08-19 12:08:03 --> Loader Class Initialized
INFO - 2023-08-19 12:08:03 --> Helper loaded: url_helper
INFO - 2023-08-19 12:08:03 --> Helper loaded: file_helper
INFO - 2023-08-19 12:08:03 --> Database Driver Class Initialized
INFO - 2023-08-19 12:08:03 --> Email Class Initialized
DEBUG - 2023-08-19 12:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:08:03 --> Controller Class Initialized
INFO - 2023-08-19 12:08:03 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:08:03 --> Helper loaded: form_helper
INFO - 2023-08-19 12:08:03 --> Form Validation Class Initialized
INFO - 2023-08-19 12:08:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_list.php
INFO - 2023-08-19 12:08:03 --> Final output sent to browser
DEBUG - 2023-08-19 12:08:03 --> Total execution time: 0.0438
INFO - 2023-08-19 12:08:04 --> Config Class Initialized
INFO - 2023-08-19 12:08:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:08:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:08:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:08:04 --> URI Class Initialized
INFO - 2023-08-19 12:08:04 --> Router Class Initialized
INFO - 2023-08-19 12:08:04 --> Output Class Initialized
INFO - 2023-08-19 12:08:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:08:04 --> Input Class Initialized
INFO - 2023-08-19 12:08:04 --> Language Class Initialized
INFO - 2023-08-19 12:08:04 --> Loader Class Initialized
INFO - 2023-08-19 12:08:04 --> Helper loaded: url_helper
INFO - 2023-08-19 12:08:04 --> Helper loaded: file_helper
INFO - 2023-08-19 12:08:04 --> Database Driver Class Initialized
INFO - 2023-08-19 12:08:04 --> Email Class Initialized
DEBUG - 2023-08-19 12:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:08:04 --> Controller Class Initialized
INFO - 2023-08-19 12:08:04 --> Model "Faq_model" initialized
INFO - 2023-08-19 12:08:04 --> Helper loaded: form_helper
INFO - 2023-08-19 12:08:04 --> Form Validation Class Initialized
INFO - 2023-08-19 12:08:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/faq_list.php
INFO - 2023-08-19 12:08:04 --> Final output sent to browser
DEBUG - 2023-08-19 12:08:04 --> Total execution time: 0.0763
INFO - 2023-08-19 12:11:30 --> Config Class Initialized
INFO - 2023-08-19 12:11:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:30 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:30 --> URI Class Initialized
INFO - 2023-08-19 12:11:30 --> Router Class Initialized
INFO - 2023-08-19 12:11:30 --> Output Class Initialized
INFO - 2023-08-19 12:11:30 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:30 --> Input Class Initialized
INFO - 2023-08-19 12:11:30 --> Language Class Initialized
INFO - 2023-08-19 12:11:30 --> Loader Class Initialized
INFO - 2023-08-19 12:11:30 --> Helper loaded: url_helper
INFO - 2023-08-19 12:11:30 --> Helper loaded: file_helper
INFO - 2023-08-19 12:11:30 --> Database Driver Class Initialized
INFO - 2023-08-19 12:11:30 --> Email Class Initialized
DEBUG - 2023-08-19 12:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:11:30 --> Controller Class Initialized
INFO - 2023-08-19 12:11:30 --> Model "Home_model" initialized
INFO - 2023-08-19 12:11:30 --> Helper loaded: form_helper
INFO - 2023-08-19 12:11:30 --> Form Validation Class Initialized
INFO - 2023-08-19 12:11:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:11:31 --> Final output sent to browser
DEBUG - 2023-08-19 12:11:31 --> Total execution time: 0.1664
INFO - 2023-08-19 12:11:31 --> Config Class Initialized
INFO - 2023-08-19 12:11:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:31 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:31 --> URI Class Initialized
INFO - 2023-08-19 12:11:31 --> Router Class Initialized
INFO - 2023-08-19 12:11:31 --> Output Class Initialized
INFO - 2023-08-19 12:11:31 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:31 --> Input Class Initialized
INFO - 2023-08-19 12:11:31 --> Language Class Initialized
ERROR - 2023-08-19 12:11:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:31 --> Config Class Initialized
INFO - 2023-08-19 12:11:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:31 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:31 --> URI Class Initialized
INFO - 2023-08-19 12:11:31 --> Router Class Initialized
INFO - 2023-08-19 12:11:31 --> Output Class Initialized
INFO - 2023-08-19 12:11:31 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:31 --> Input Class Initialized
INFO - 2023-08-19 12:11:31 --> Language Class Initialized
ERROR - 2023-08-19 12:11:31 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:32 --> Config Class Initialized
INFO - 2023-08-19 12:11:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:32 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:32 --> URI Class Initialized
INFO - 2023-08-19 12:11:32 --> Router Class Initialized
INFO - 2023-08-19 12:11:32 --> Output Class Initialized
INFO - 2023-08-19 12:11:32 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:32 --> Input Class Initialized
INFO - 2023-08-19 12:11:32 --> Language Class Initialized
ERROR - 2023-08-19 12:11:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:33 --> Config Class Initialized
INFO - 2023-08-19 12:11:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:33 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:33 --> URI Class Initialized
INFO - 2023-08-19 12:11:33 --> Router Class Initialized
INFO - 2023-08-19 12:11:33 --> Output Class Initialized
INFO - 2023-08-19 12:11:33 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:33 --> Input Class Initialized
INFO - 2023-08-19 12:11:33 --> Language Class Initialized
ERROR - 2023-08-19 12:11:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:33 --> Config Class Initialized
INFO - 2023-08-19 12:11:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:33 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:33 --> URI Class Initialized
INFO - 2023-08-19 12:11:33 --> Router Class Initialized
INFO - 2023-08-19 12:11:33 --> Output Class Initialized
INFO - 2023-08-19 12:11:33 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:33 --> Input Class Initialized
INFO - 2023-08-19 12:11:33 --> Language Class Initialized
ERROR - 2023-08-19 12:11:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:42 --> Config Class Initialized
INFO - 2023-08-19 12:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:42 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:42 --> URI Class Initialized
INFO - 2023-08-19 12:11:42 --> Router Class Initialized
INFO - 2023-08-19 12:11:42 --> Output Class Initialized
INFO - 2023-08-19 12:11:42 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:42 --> Input Class Initialized
INFO - 2023-08-19 12:11:42 --> Language Class Initialized
INFO - 2023-08-19 12:11:42 --> Loader Class Initialized
INFO - 2023-08-19 12:11:42 --> Helper loaded: url_helper
INFO - 2023-08-19 12:11:42 --> Helper loaded: file_helper
INFO - 2023-08-19 12:11:42 --> Database Driver Class Initialized
INFO - 2023-08-19 12:11:42 --> Email Class Initialized
DEBUG - 2023-08-19 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:11:42 --> Controller Class Initialized
INFO - 2023-08-19 12:11:42 --> Model "Home_model" initialized
INFO - 2023-08-19 12:11:42 --> Helper loaded: form_helper
INFO - 2023-08-19 12:11:42 --> Form Validation Class Initialized
INFO - 2023-08-19 12:11:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:11:42 --> Final output sent to browser
DEBUG - 2023-08-19 12:11:42 --> Total execution time: 0.0722
INFO - 2023-08-19 12:11:42 --> Config Class Initialized
INFO - 2023-08-19 12:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:42 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:42 --> URI Class Initialized
INFO - 2023-08-19 12:11:42 --> Router Class Initialized
INFO - 2023-08-19 12:11:42 --> Output Class Initialized
INFO - 2023-08-19 12:11:42 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:42 --> Input Class Initialized
INFO - 2023-08-19 12:11:42 --> Language Class Initialized
ERROR - 2023-08-19 12:11:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:43 --> Output Class Initialized
INFO - 2023-08-19 12:11:43 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:43 --> Input Class Initialized
INFO - 2023-08-19 12:11:43 --> Language Class Initialized
ERROR - 2023-08-19 12:11:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Config Class Initialized
INFO - 2023-08-19 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:43 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:43 --> URI Class Initialized
INFO - 2023-08-19 12:11:43 --> Router Class Initialized
INFO - 2023-08-19 12:11:44 --> Output Class Initialized
INFO - 2023-08-19 12:11:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:44 --> Input Class Initialized
INFO - 2023-08-19 12:11:44 --> Language Class Initialized
ERROR - 2023-08-19 12:11:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:44 --> Router Class Initialized
INFO - 2023-08-19 12:11:44 --> Output Class Initialized
INFO - 2023-08-19 12:11:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:44 --> Input Class Initialized
INFO - 2023-08-19 12:11:44 --> Config Class Initialized
INFO - 2023-08-19 12:11:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:44 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:44 --> URI Class Initialized
INFO - 2023-08-19 12:11:44 --> Router Class Initialized
INFO - 2023-08-19 12:11:44 --> Output Class Initialized
INFO - 2023-08-19 12:11:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:44 --> Input Class Initialized
INFO - 2023-08-19 12:11:44 --> Language Class Initialized
ERROR - 2023-08-19 12:11:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:44 --> Language Class Initialized
ERROR - 2023-08-19 12:11:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:44 --> Config Class Initialized
INFO - 2023-08-19 12:11:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:44 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:44 --> URI Class Initialized
INFO - 2023-08-19 12:11:44 --> Router Class Initialized
INFO - 2023-08-19 12:11:44 --> Output Class Initialized
INFO - 2023-08-19 12:11:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:44 --> Input Class Initialized
INFO - 2023-08-19 12:11:44 --> Language Class Initialized
ERROR - 2023-08-19 12:11:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:11:44 --> Config Class Initialized
INFO - 2023-08-19 12:11:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:11:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:11:44 --> Utf8 Class Initialized
INFO - 2023-08-19 12:11:44 --> URI Class Initialized
INFO - 2023-08-19 12:11:44 --> Router Class Initialized
INFO - 2023-08-19 12:11:44 --> Output Class Initialized
INFO - 2023-08-19 12:11:44 --> Security Class Initialized
DEBUG - 2023-08-19 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:11:44 --> Input Class Initialized
INFO - 2023-08-19 12:11:44 --> Language Class Initialized
ERROR - 2023-08-19 12:11:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:03 --> Config Class Initialized
INFO - 2023-08-19 12:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:03 --> URI Class Initialized
INFO - 2023-08-19 12:13:03 --> Router Class Initialized
INFO - 2023-08-19 12:13:03 --> Output Class Initialized
INFO - 2023-08-19 12:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:03 --> Input Class Initialized
INFO - 2023-08-19 12:13:03 --> Language Class Initialized
INFO - 2023-08-19 12:13:03 --> Loader Class Initialized
INFO - 2023-08-19 12:13:03 --> Helper loaded: url_helper
INFO - 2023-08-19 12:13:03 --> Helper loaded: file_helper
INFO - 2023-08-19 12:13:03 --> Database Driver Class Initialized
INFO - 2023-08-19 12:13:03 --> Email Class Initialized
DEBUG - 2023-08-19 12:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:13:03 --> Controller Class Initialized
INFO - 2023-08-19 12:13:03 --> Model "Home_model" initialized
INFO - 2023-08-19 12:13:03 --> Helper loaded: form_helper
INFO - 2023-08-19 12:13:03 --> Form Validation Class Initialized
INFO - 2023-08-19 12:13:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:13:03 --> Final output sent to browser
DEBUG - 2023-08-19 12:13:03 --> Total execution time: 0.1472
INFO - 2023-08-19 12:13:03 --> Config Class Initialized
INFO - 2023-08-19 12:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:03 --> URI Class Initialized
INFO - 2023-08-19 12:13:03 --> Router Class Initialized
INFO - 2023-08-19 12:13:03 --> Output Class Initialized
INFO - 2023-08-19 12:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:03 --> Input Class Initialized
INFO - 2023-08-19 12:13:03 --> Language Class Initialized
ERROR - 2023-08-19 12:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:04 --> Config Class Initialized
INFO - 2023-08-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:04 --> URI Class Initialized
INFO - 2023-08-19 12:13:04 --> Router Class Initialized
INFO - 2023-08-19 12:13:04 --> Output Class Initialized
INFO - 2023-08-19 12:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:04 --> Input Class Initialized
INFO - 2023-08-19 12:13:04 --> Language Class Initialized
ERROR - 2023-08-19 12:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:04 --> Config Class Initialized
INFO - 2023-08-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:04 --> URI Class Initialized
INFO - 2023-08-19 12:13:04 --> Router Class Initialized
INFO - 2023-08-19 12:13:04 --> Output Class Initialized
INFO - 2023-08-19 12:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:04 --> Input Class Initialized
INFO - 2023-08-19 12:13:04 --> Language Class Initialized
ERROR - 2023-08-19 12:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:04 --> Config Class Initialized
INFO - 2023-08-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:04 --> URI Class Initialized
INFO - 2023-08-19 12:13:04 --> Router Class Initialized
INFO - 2023-08-19 12:13:04 --> Output Class Initialized
INFO - 2023-08-19 12:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:04 --> Input Class Initialized
INFO - 2023-08-19 12:13:04 --> Language Class Initialized
ERROR - 2023-08-19 12:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:04 --> Config Class Initialized
INFO - 2023-08-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:04 --> URI Class Initialized
INFO - 2023-08-19 12:13:04 --> Router Class Initialized
INFO - 2023-08-19 12:13:04 --> Output Class Initialized
INFO - 2023-08-19 12:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:04 --> Input Class Initialized
INFO - 2023-08-19 12:13:04 --> Language Class Initialized
ERROR - 2023-08-19 12:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:04 --> Config Class Initialized
INFO - 2023-08-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:04 --> URI Class Initialized
INFO - 2023-08-19 12:13:04 --> Router Class Initialized
INFO - 2023-08-19 12:13:04 --> Output Class Initialized
INFO - 2023-08-19 12:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:04 --> Input Class Initialized
INFO - 2023-08-19 12:13:04 --> Language Class Initialized
ERROR - 2023-08-19 12:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:24 --> Config Class Initialized
INFO - 2023-08-19 12:13:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:24 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:24 --> URI Class Initialized
INFO - 2023-08-19 12:13:24 --> Router Class Initialized
INFO - 2023-08-19 12:13:24 --> Output Class Initialized
INFO - 2023-08-19 12:13:24 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:24 --> Input Class Initialized
INFO - 2023-08-19 12:13:24 --> Language Class Initialized
INFO - 2023-08-19 12:13:24 --> Loader Class Initialized
INFO - 2023-08-19 12:13:24 --> Helper loaded: url_helper
INFO - 2023-08-19 12:13:24 --> Helper loaded: file_helper
INFO - 2023-08-19 12:13:25 --> Database Driver Class Initialized
INFO - 2023-08-19 12:13:25 --> Email Class Initialized
DEBUG - 2023-08-19 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:13:25 --> Controller Class Initialized
INFO - 2023-08-19 12:13:25 --> Model "Home_model" initialized
INFO - 2023-08-19 12:13:25 --> Helper loaded: form_helper
INFO - 2023-08-19 12:13:25 --> Form Validation Class Initialized
INFO - 2023-08-19 12:13:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:13:25 --> Final output sent to browser
DEBUG - 2023-08-19 12:13:25 --> Total execution time: 0.4176
INFO - 2023-08-19 12:13:25 --> Config Class Initialized
INFO - 2023-08-19 12:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:25 --> URI Class Initialized
INFO - 2023-08-19 12:13:25 --> Router Class Initialized
INFO - 2023-08-19 12:13:25 --> Output Class Initialized
INFO - 2023-08-19 12:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:25 --> Input Class Initialized
INFO - 2023-08-19 12:13:25 --> Language Class Initialized
ERROR - 2023-08-19 12:13:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:25 --> Config Class Initialized
INFO - 2023-08-19 12:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:25 --> URI Class Initialized
INFO - 2023-08-19 12:13:25 --> Router Class Initialized
INFO - 2023-08-19 12:13:25 --> Output Class Initialized
INFO - 2023-08-19 12:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:25 --> Input Class Initialized
INFO - 2023-08-19 12:13:25 --> Language Class Initialized
ERROR - 2023-08-19 12:13:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:26 --> Config Class Initialized
INFO - 2023-08-19 12:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:26 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:26 --> URI Class Initialized
INFO - 2023-08-19 12:13:26 --> Router Class Initialized
INFO - 2023-08-19 12:13:26 --> Output Class Initialized
INFO - 2023-08-19 12:13:26 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:26 --> Input Class Initialized
INFO - 2023-08-19 12:13:26 --> Language Class Initialized
ERROR - 2023-08-19 12:13:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:26 --> Config Class Initialized
INFO - 2023-08-19 12:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:26 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:26 --> URI Class Initialized
INFO - 2023-08-19 12:13:26 --> Router Class Initialized
INFO - 2023-08-19 12:13:26 --> Output Class Initialized
INFO - 2023-08-19 12:13:26 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:26 --> Input Class Initialized
INFO - 2023-08-19 12:13:26 --> Language Class Initialized
ERROR - 2023-08-19 12:13:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:26 --> Config Class Initialized
INFO - 2023-08-19 12:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:26 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:26 --> URI Class Initialized
INFO - 2023-08-19 12:13:26 --> Router Class Initialized
INFO - 2023-08-19 12:13:26 --> Output Class Initialized
INFO - 2023-08-19 12:13:26 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:26 --> Input Class Initialized
INFO - 2023-08-19 12:13:26 --> Language Class Initialized
ERROR - 2023-08-19 12:13:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:13:26 --> Config Class Initialized
INFO - 2023-08-19 12:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:13:26 --> Utf8 Class Initialized
INFO - 2023-08-19 12:13:26 --> URI Class Initialized
INFO - 2023-08-19 12:13:26 --> Router Class Initialized
INFO - 2023-08-19 12:13:26 --> Output Class Initialized
INFO - 2023-08-19 12:13:26 --> Security Class Initialized
DEBUG - 2023-08-19 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:13:27 --> Input Class Initialized
INFO - 2023-08-19 12:13:27 --> Language Class Initialized
ERROR - 2023-08-19 12:13:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:14:05 --> Config Class Initialized
INFO - 2023-08-19 12:14:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:14:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:05 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:05 --> URI Class Initialized
INFO - 2023-08-19 12:14:05 --> Router Class Initialized
INFO - 2023-08-19 12:14:05 --> Output Class Initialized
INFO - 2023-08-19 12:14:05 --> Security Class Initialized
DEBUG - 2023-08-19 12:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:05 --> Input Class Initialized
INFO - 2023-08-19 12:14:05 --> Language Class Initialized
ERROR - 2023-08-19 12:14:05 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:14:06 --> Config Class Initialized
INFO - 2023-08-19 12:14:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:14:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:06 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:06 --> URI Class Initialized
INFO - 2023-08-19 12:14:06 --> Router Class Initialized
INFO - 2023-08-19 12:14:06 --> Output Class Initialized
INFO - 2023-08-19 12:14:06 --> Security Class Initialized
DEBUG - 2023-08-19 12:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:06 --> Input Class Initialized
INFO - 2023-08-19 12:14:06 --> Language Class Initialized
ERROR - 2023-08-19 12:14:06 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:14:06 --> Config Class Initialized
INFO - 2023-08-19 12:14:06 --> Hooks Class Initialized
INFO - 2023-08-19 12:14:06 --> Config Class Initialized
INFO - 2023-08-19 12:14:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:14:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:06 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:06 --> URI Class Initialized
INFO - 2023-08-19 12:14:06 --> Router Class Initialized
INFO - 2023-08-19 12:14:06 --> Output Class Initialized
INFO - 2023-08-19 12:14:06 --> Security Class Initialized
DEBUG - 2023-08-19 12:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:06 --> Input Class Initialized
INFO - 2023-08-19 12:14:06 --> Language Class Initialized
ERROR - 2023-08-19 12:14:06 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-19 12:14:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:06 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:07 --> URI Class Initialized
INFO - 2023-08-19 12:14:07 --> Router Class Initialized
INFO - 2023-08-19 12:14:07 --> Output Class Initialized
INFO - 2023-08-19 12:14:07 --> Security Class Initialized
DEBUG - 2023-08-19 12:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:07 --> Input Class Initialized
INFO - 2023-08-19 12:14:07 --> Language Class Initialized
ERROR - 2023-08-19 12:14:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:14:07 --> Config Class Initialized
INFO - 2023-08-19 12:14:08 --> Config Class Initialized
INFO - 2023-08-19 12:14:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:08 --> Hooks Class Initialized
INFO - 2023-08-19 12:14:08 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:08 --> URI Class Initialized
INFO - 2023-08-19 12:14:08 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:08 --> Router Class Initialized
INFO - 2023-08-19 12:14:08 --> Config Class Initialized
INFO - 2023-08-19 12:14:08 --> URI Class Initialized
INFO - 2023-08-19 12:14:08 --> Hooks Class Initialized
INFO - 2023-08-19 12:14:08 --> Router Class Initialized
DEBUG - 2023-08-19 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:14:08 --> Utf8 Class Initialized
INFO - 2023-08-19 12:14:08 --> Output Class Initialized
INFO - 2023-08-19 12:14:08 --> URI Class Initialized
INFO - 2023-08-19 12:14:08 --> Output Class Initialized
INFO - 2023-08-19 12:14:08 --> Router Class Initialized
INFO - 2023-08-19 12:14:08 --> Security Class Initialized
INFO - 2023-08-19 12:14:08 --> Output Class Initialized
INFO - 2023-08-19 12:14:08 --> Security Class Initialized
DEBUG - 2023-08-19 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:08 --> Security Class Initialized
INFO - 2023-08-19 12:14:08 --> Input Class Initialized
DEBUG - 2023-08-19 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:08 --> Language Class Initialized
INFO - 2023-08-19 12:14:08 --> Input Class Initialized
DEBUG - 2023-08-19 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:14:08 --> Language Class Initialized
ERROR - 2023-08-19 12:14:08 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-19 12:14:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:14:08 --> Input Class Initialized
INFO - 2023-08-19 12:14:08 --> Language Class Initialized
ERROR - 2023-08-19 12:14:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:15:28 --> Config Class Initialized
INFO - 2023-08-19 12:15:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:15:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:15:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:15:28 --> URI Class Initialized
INFO - 2023-08-19 12:15:28 --> Router Class Initialized
INFO - 2023-08-19 12:15:28 --> Output Class Initialized
INFO - 2023-08-19 12:15:28 --> Security Class Initialized
DEBUG - 2023-08-19 12:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:28 --> Input Class Initialized
INFO - 2023-08-19 12:15:28 --> Language Class Initialized
INFO - 2023-08-19 12:15:28 --> Loader Class Initialized
INFO - 2023-08-19 12:15:28 --> Helper loaded: url_helper
INFO - 2023-08-19 12:15:28 --> Helper loaded: file_helper
INFO - 2023-08-19 12:15:28 --> Database Driver Class Initialized
INFO - 2023-08-19 12:15:28 --> Email Class Initialized
DEBUG - 2023-08-19 12:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:15:28 --> Controller Class Initialized
INFO - 2023-08-19 12:15:28 --> Model "Home_model" initialized
INFO - 2023-08-19 12:15:28 --> Helper loaded: form_helper
INFO - 2023-08-19 12:15:28 --> Form Validation Class Initialized
INFO - 2023-08-19 12:15:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:15:29 --> Final output sent to browser
DEBUG - 2023-08-19 12:15:29 --> Total execution time: 0.9225
INFO - 2023-08-19 12:15:29 --> Config Class Initialized
INFO - 2023-08-19 12:15:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:15:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:15:29 --> Utf8 Class Initialized
INFO - 2023-08-19 12:15:29 --> URI Class Initialized
INFO - 2023-08-19 12:15:29 --> Router Class Initialized
INFO - 2023-08-19 12:15:29 --> Output Class Initialized
INFO - 2023-08-19 12:15:29 --> Security Class Initialized
DEBUG - 2023-08-19 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:29 --> Input Class Initialized
INFO - 2023-08-19 12:15:29 --> Language Class Initialized
ERROR - 2023-08-19 12:15:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:15:29 --> Config Class Initialized
INFO - 2023-08-19 12:15:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:15:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:15:29 --> Utf8 Class Initialized
INFO - 2023-08-19 12:15:29 --> Config Class Initialized
INFO - 2023-08-19 12:15:29 --> Config Class Initialized
INFO - 2023-08-19 12:15:29 --> Config Class Initialized
INFO - 2023-08-19 12:15:29 --> URI Class Initialized
INFO - 2023-08-19 12:15:29 --> Router Class Initialized
INFO - 2023-08-19 12:15:29 --> Hooks Class Initialized
INFO - 2023-08-19 12:15:29 --> Hooks Class Initialized
INFO - 2023-08-19 12:15:30 --> Output Class Initialized
INFO - 2023-08-19 12:15:30 --> Config Class Initialized
INFO - 2023-08-19 12:15:30 --> Security Class Initialized
DEBUG - 2023-08-19 12:15:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:15:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:15:30 --> Hooks Class Initialized
INFO - 2023-08-19 12:15:30 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:15:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:30 --> Hooks Class Initialized
INFO - 2023-08-19 12:15:30 --> Utf8 Class Initialized
INFO - 2023-08-19 12:15:30 --> URI Class Initialized
INFO - 2023-08-19 12:15:30 --> Router Class Initialized
INFO - 2023-08-19 12:15:30 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:15:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:15:30 --> URI Class Initialized
INFO - 2023-08-19 12:15:30 --> Input Class Initialized
INFO - 2023-08-19 12:15:30 --> Output Class Initialized
INFO - 2023-08-19 12:15:30 --> Utf8 Class Initialized
INFO - 2023-08-19 12:15:30 --> URI Class Initialized
INFO - 2023-08-19 12:15:30 --> URI Class Initialized
INFO - 2023-08-19 12:15:30 --> Router Class Initialized
INFO - 2023-08-19 12:15:30 --> Router Class Initialized
INFO - 2023-08-19 12:15:30 --> Output Class Initialized
INFO - 2023-08-19 12:15:30 --> Security Class Initialized
INFO - 2023-08-19 12:15:30 --> Output Class Initialized
INFO - 2023-08-19 12:15:30 --> Router Class Initialized
DEBUG - 2023-08-19 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:30 --> Language Class Initialized
INFO - 2023-08-19 12:15:30 --> Security Class Initialized
DEBUG - 2023-08-19 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:30 --> Security Class Initialized
INFO - 2023-08-19 12:15:30 --> Output Class Initialized
INFO - 2023-08-19 12:15:30 --> Input Class Initialized
INFO - 2023-08-19 12:15:30 --> Input Class Initialized
INFO - 2023-08-19 12:15:30 --> Language Class Initialized
INFO - 2023-08-19 12:15:30 --> Language Class Initialized
ERROR - 2023-08-19 12:15:30 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 12:15:30 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:30 --> Security Class Initialized
DEBUG - 2023-08-19 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:15:30 --> Input Class Initialized
ERROR - 2023-08-19 12:15:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:15:30 --> Language Class Initialized
ERROR - 2023-08-19 12:15:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:15:30 --> Input Class Initialized
INFO - 2023-08-19 12:15:30 --> Language Class Initialized
ERROR - 2023-08-19 12:15:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:19:48 --> Config Class Initialized
INFO - 2023-08-19 12:19:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:19:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:19:48 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:48 --> URI Class Initialized
INFO - 2023-08-19 12:19:48 --> Router Class Initialized
INFO - 2023-08-19 12:19:48 --> Output Class Initialized
INFO - 2023-08-19 12:19:48 --> Security Class Initialized
DEBUG - 2023-08-19 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:49 --> Input Class Initialized
INFO - 2023-08-19 12:19:49 --> Language Class Initialized
INFO - 2023-08-19 12:19:49 --> Loader Class Initialized
INFO - 2023-08-19 12:19:49 --> Helper loaded: url_helper
INFO - 2023-08-19 12:19:49 --> Helper loaded: file_helper
INFO - 2023-08-19 12:19:49 --> Database Driver Class Initialized
INFO - 2023-08-19 12:19:49 --> Email Class Initialized
DEBUG - 2023-08-19 12:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:19:49 --> Controller Class Initialized
INFO - 2023-08-19 12:19:49 --> Model "Home_model" initialized
INFO - 2023-08-19 12:19:49 --> Helper loaded: form_helper
INFO - 2023-08-19 12:19:49 --> Form Validation Class Initialized
INFO - 2023-08-19 12:19:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:19:49 --> Final output sent to browser
DEBUG - 2023-08-19 12:19:50 --> Total execution time: 1.0438
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
INFO - 2023-08-19 12:19:51 --> Config Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:19:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:19:51 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:51 --> Hooks Class Initialized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
INFO - 2023-08-19 12:19:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
DEBUG - 2023-08-19 12:19:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:19:52 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:52 --> URI Class Initialized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
INFO - 2023-08-19 12:19:52 --> Router Class Initialized
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:19:52 --> Output Class Initialized
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
INFO - 2023-08-19 12:19:52 --> Security Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
DEBUG - 2023-08-19 12:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:19:52 --> Input Class Initialized
INFO - 2023-08-19 12:19:52 --> Language Class Initialized
ERROR - 2023-08-19 12:19:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:09 --> Config Class Initialized
INFO - 2023-08-19 12:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:09 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:09 --> URI Class Initialized
INFO - 2023-08-19 12:20:09 --> Router Class Initialized
INFO - 2023-08-19 12:20:09 --> Output Class Initialized
INFO - 2023-08-19 12:20:09 --> Security Class Initialized
DEBUG - 2023-08-19 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:09 --> Input Class Initialized
INFO - 2023-08-19 12:20:09 --> Language Class Initialized
INFO - 2023-08-19 12:20:09 --> Loader Class Initialized
INFO - 2023-08-19 12:20:09 --> Helper loaded: url_helper
INFO - 2023-08-19 12:20:09 --> Helper loaded: file_helper
INFO - 2023-08-19 12:20:09 --> Database Driver Class Initialized
INFO - 2023-08-19 12:20:09 --> Email Class Initialized
DEBUG - 2023-08-19 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:20:09 --> Controller Class Initialized
INFO - 2023-08-19 12:20:09 --> Model "Home_model" initialized
INFO - 2023-08-19 12:20:09 --> Helper loaded: form_helper
INFO - 2023-08-19 12:20:09 --> Form Validation Class Initialized
INFO - 2023-08-19 12:20:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:20:10 --> Final output sent to browser
DEBUG - 2023-08-19 12:20:10 --> Total execution time: 0.4168
INFO - 2023-08-19 12:20:10 --> Config Class Initialized
INFO - 2023-08-19 12:20:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:20:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:10 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:10 --> URI Class Initialized
INFO - 2023-08-19 12:20:10 --> Router Class Initialized
INFO - 2023-08-19 12:20:10 --> Output Class Initialized
INFO - 2023-08-19 12:20:10 --> Security Class Initialized
DEBUG - 2023-08-19 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:10 --> Input Class Initialized
INFO - 2023-08-19 12:20:10 --> Language Class Initialized
ERROR - 2023-08-19 12:20:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:10 --> Config Class Initialized
INFO - 2023-08-19 12:20:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:20:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:10 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:10 --> URI Class Initialized
INFO - 2023-08-19 12:20:10 --> Router Class Initialized
INFO - 2023-08-19 12:20:10 --> Output Class Initialized
INFO - 2023-08-19 12:20:10 --> Security Class Initialized
INFO - 2023-08-19 12:20:11 --> Config Class Initialized
DEBUG - 2023-08-19 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:11 --> Hooks Class Initialized
INFO - 2023-08-19 12:20:11 --> Config Class Initialized
INFO - 2023-08-19 12:20:11 --> Input Class Initialized
INFO - 2023-08-19 12:20:11 --> Config Class Initialized
INFO - 2023-08-19 12:20:11 --> Language Class Initialized
INFO - 2023-08-19 12:20:11 --> Config Class Initialized
ERROR - 2023-08-19 12:20:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:11 --> Hooks Class Initialized
INFO - 2023-08-19 12:20:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:11 --> Config Class Initialized
DEBUG - 2023-08-19 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:11 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:11 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:11 --> URI Class Initialized
INFO - 2023-08-19 12:20:11 --> Router Class Initialized
INFO - 2023-08-19 12:20:11 --> Output Class Initialized
INFO - 2023-08-19 12:20:11 --> Security Class Initialized
DEBUG - 2023-08-19 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:11 --> Input Class Initialized
INFO - 2023-08-19 12:20:11 --> Language Class Initialized
ERROR - 2023-08-19 12:20:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:11 --> Hooks Class Initialized
INFO - 2023-08-19 12:20:11 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:11 --> URI Class Initialized
INFO - 2023-08-19 12:20:11 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:20:11 --> URI Class Initialized
INFO - 2023-08-19 12:20:11 --> Router Class Initialized
INFO - 2023-08-19 12:20:12 --> Output Class Initialized
INFO - 2023-08-19 12:20:12 --> Utf8 Class Initialized
INFO - 2023-08-19 12:20:12 --> Security Class Initialized
INFO - 2023-08-19 12:20:12 --> URI Class Initialized
INFO - 2023-08-19 12:20:12 --> Router Class Initialized
DEBUG - 2023-08-19 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:12 --> Router Class Initialized
INFO - 2023-08-19 12:20:12 --> Input Class Initialized
INFO - 2023-08-19 12:20:12 --> Language Class Initialized
INFO - 2023-08-19 12:20:12 --> Output Class Initialized
INFO - 2023-08-19 12:20:12 --> URI Class Initialized
ERROR - 2023-08-19 12:20:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:12 --> Output Class Initialized
INFO - 2023-08-19 12:20:12 --> Router Class Initialized
INFO - 2023-08-19 12:20:12 --> Security Class Initialized
DEBUG - 2023-08-19 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:12 --> Security Class Initialized
INFO - 2023-08-19 12:20:12 --> Input Class Initialized
INFO - 2023-08-19 12:20:12 --> Output Class Initialized
DEBUG - 2023-08-19 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:12 --> Security Class Initialized
INFO - 2023-08-19 12:20:12 --> Input Class Initialized
INFO - 2023-08-19 12:20:12 --> Language Class Initialized
DEBUG - 2023-08-19 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:20:12 --> Language Class Initialized
INFO - 2023-08-19 12:20:12 --> Input Class Initialized
ERROR - 2023-08-19 12:20:12 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 12:20:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:20:12 --> Language Class Initialized
ERROR - 2023-08-19 12:20:12 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:54 --> Config Class Initialized
INFO - 2023-08-19 12:24:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:54 --> URI Class Initialized
INFO - 2023-08-19 12:24:54 --> Router Class Initialized
INFO - 2023-08-19 12:24:54 --> Output Class Initialized
INFO - 2023-08-19 12:24:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:54 --> Input Class Initialized
INFO - 2023-08-19 12:24:54 --> Language Class Initialized
INFO - 2023-08-19 12:24:54 --> Loader Class Initialized
INFO - 2023-08-19 12:24:54 --> Helper loaded: url_helper
INFO - 2023-08-19 12:24:54 --> Helper loaded: file_helper
INFO - 2023-08-19 12:24:54 --> Database Driver Class Initialized
INFO - 2023-08-19 12:24:54 --> Email Class Initialized
DEBUG - 2023-08-19 12:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:24:54 --> Controller Class Initialized
INFO - 2023-08-19 12:24:54 --> Model "Home_model" initialized
INFO - 2023-08-19 12:24:54 --> Helper loaded: form_helper
INFO - 2023-08-19 12:24:54 --> Form Validation Class Initialized
INFO - 2023-08-19 12:24:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:24:54 --> Final output sent to browser
DEBUG - 2023-08-19 12:24:55 --> Total execution time: 0.4428
INFO - 2023-08-19 12:24:55 --> Config Class Initialized
INFO - 2023-08-19 12:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:55 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:55 --> URI Class Initialized
INFO - 2023-08-19 12:24:55 --> Router Class Initialized
INFO - 2023-08-19 12:24:55 --> Output Class Initialized
INFO - 2023-08-19 12:24:55 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:55 --> Input Class Initialized
INFO - 2023-08-19 12:24:55 --> Language Class Initialized
ERROR - 2023-08-19 12:24:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:55 --> Config Class Initialized
INFO - 2023-08-19 12:24:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:55 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:55 --> URI Class Initialized
INFO - 2023-08-19 12:24:55 --> Router Class Initialized
INFO - 2023-08-19 12:24:56 --> Output Class Initialized
INFO - 2023-08-19 12:24:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:56 --> Input Class Initialized
INFO - 2023-08-19 12:24:56 --> Language Class Initialized
ERROR - 2023-08-19 12:24:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:56 --> Config Class Initialized
INFO - 2023-08-19 12:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:56 --> URI Class Initialized
INFO - 2023-08-19 12:24:56 --> Router Class Initialized
INFO - 2023-08-19 12:24:56 --> Output Class Initialized
INFO - 2023-08-19 12:24:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:56 --> Input Class Initialized
INFO - 2023-08-19 12:24:56 --> Language Class Initialized
ERROR - 2023-08-19 12:24:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:56 --> Config Class Initialized
INFO - 2023-08-19 12:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:56 --> URI Class Initialized
INFO - 2023-08-19 12:24:56 --> Router Class Initialized
INFO - 2023-08-19 12:24:56 --> Output Class Initialized
INFO - 2023-08-19 12:24:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:56 --> Input Class Initialized
INFO - 2023-08-19 12:24:56 --> Language Class Initialized
ERROR - 2023-08-19 12:24:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:56 --> Config Class Initialized
INFO - 2023-08-19 12:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:56 --> URI Class Initialized
INFO - 2023-08-19 12:24:56 --> Router Class Initialized
INFO - 2023-08-19 12:24:56 --> Output Class Initialized
INFO - 2023-08-19 12:24:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:56 --> Input Class Initialized
INFO - 2023-08-19 12:24:56 --> Language Class Initialized
ERROR - 2023-08-19 12:24:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:24:56 --> Config Class Initialized
INFO - 2023-08-19 12:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:24:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:24:56 --> URI Class Initialized
INFO - 2023-08-19 12:24:56 --> Router Class Initialized
INFO - 2023-08-19 12:24:57 --> Output Class Initialized
INFO - 2023-08-19 12:24:57 --> Security Class Initialized
DEBUG - 2023-08-19 12:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:24:57 --> Input Class Initialized
INFO - 2023-08-19 12:24:57 --> Language Class Initialized
ERROR - 2023-08-19 12:24:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:25:59 --> Config Class Initialized
INFO - 2023-08-19 12:25:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:25:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:25:59 --> Utf8 Class Initialized
INFO - 2023-08-19 12:25:59 --> URI Class Initialized
INFO - 2023-08-19 12:25:59 --> Router Class Initialized
INFO - 2023-08-19 12:25:59 --> Output Class Initialized
INFO - 2023-08-19 12:25:59 --> Security Class Initialized
DEBUG - 2023-08-19 12:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:25:59 --> Input Class Initialized
INFO - 2023-08-19 12:25:59 --> Language Class Initialized
INFO - 2023-08-19 12:25:59 --> Loader Class Initialized
INFO - 2023-08-19 12:25:59 --> Helper loaded: url_helper
INFO - 2023-08-19 12:25:59 --> Helper loaded: file_helper
INFO - 2023-08-19 12:25:59 --> Database Driver Class Initialized
INFO - 2023-08-19 12:25:59 --> Email Class Initialized
DEBUG - 2023-08-19 12:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:25:59 --> Controller Class Initialized
INFO - 2023-08-19 12:25:59 --> Model "Home_model" initialized
INFO - 2023-08-19 12:25:59 --> Helper loaded: form_helper
INFO - 2023-08-19 12:25:59 --> Form Validation Class Initialized
INFO - 2023-08-19 12:25:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 12:25:59 --> Final output sent to browser
DEBUG - 2023-08-19 12:26:00 --> Total execution time: 0.4039
INFO - 2023-08-19 12:26:00 --> Config Class Initialized
INFO - 2023-08-19 12:26:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:26:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:26:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:26:00 --> URI Class Initialized
INFO - 2023-08-19 12:26:00 --> Router Class Initialized
INFO - 2023-08-19 12:26:00 --> Output Class Initialized
INFO - 2023-08-19 12:26:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:26:00 --> Input Class Initialized
INFO - 2023-08-19 12:26:00 --> Language Class Initialized
ERROR - 2023-08-19 12:26:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:26:00 --> Config Class Initialized
INFO - 2023-08-19 12:26:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:26:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:26:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:26:00 --> URI Class Initialized
INFO - 2023-08-19 12:26:00 --> Router Class Initialized
INFO - 2023-08-19 12:26:01 --> Output Class Initialized
INFO - 2023-08-19 12:26:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:26:01 --> Input Class Initialized
INFO - 2023-08-19 12:26:01 --> Language Class Initialized
ERROR - 2023-08-19 12:26:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:26:01 --> Config Class Initialized
INFO - 2023-08-19 12:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:26:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:26:01 --> URI Class Initialized
INFO - 2023-08-19 12:26:01 --> Router Class Initialized
INFO - 2023-08-19 12:26:01 --> Output Class Initialized
INFO - 2023-08-19 12:26:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:26:01 --> Input Class Initialized
INFO - 2023-08-19 12:26:01 --> Language Class Initialized
ERROR - 2023-08-19 12:26:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:26:01 --> Config Class Initialized
INFO - 2023-08-19 12:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:26:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:26:01 --> URI Class Initialized
INFO - 2023-08-19 12:26:01 --> Router Class Initialized
INFO - 2023-08-19 12:26:01 --> Output Class Initialized
INFO - 2023-08-19 12:26:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:26:01 --> Input Class Initialized
INFO - 2023-08-19 12:26:01 --> Language Class Initialized
ERROR - 2023-08-19 12:26:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:26:01 --> Config Class Initialized
INFO - 2023-08-19 12:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:26:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:26:02 --> URI Class Initialized
INFO - 2023-08-19 12:26:02 --> Router Class Initialized
INFO - 2023-08-19 12:26:02 --> Output Class Initialized
INFO - 2023-08-19 12:26:02 --> Security Class Initialized
DEBUG - 2023-08-19 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:26:02 --> Input Class Initialized
INFO - 2023-08-19 12:26:02 --> Language Class Initialized
ERROR - 2023-08-19 12:26:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:37:56 --> Config Class Initialized
INFO - 2023-08-19 12:37:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:37:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:37:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:37:56 --> URI Class Initialized
INFO - 2023-08-19 12:37:56 --> Router Class Initialized
INFO - 2023-08-19 12:37:56 --> Output Class Initialized
INFO - 2023-08-19 12:37:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:37:56 --> Input Class Initialized
INFO - 2023-08-19 12:37:56 --> Language Class Initialized
INFO - 2023-08-19 12:37:56 --> Loader Class Initialized
INFO - 2023-08-19 12:37:56 --> Helper loaded: url_helper
INFO - 2023-08-19 12:37:56 --> Helper loaded: file_helper
INFO - 2023-08-19 12:37:56 --> Database Driver Class Initialized
INFO - 2023-08-19 12:37:56 --> Email Class Initialized
DEBUG - 2023-08-19 12:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:37:56 --> Controller Class Initialized
INFO - 2023-08-19 12:37:56 --> Model "Home_model" initialized
INFO - 2023-08-19 12:37:56 --> Helper loaded: form_helper
INFO - 2023-08-19 12:37:56 --> Form Validation Class Initialized
INFO - 2023-08-19 12:37:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:37:56 --> Final output sent to browser
DEBUG - 2023-08-19 12:37:57 --> Total execution time: 0.8288
INFO - 2023-08-19 12:38:48 --> Config Class Initialized
INFO - 2023-08-19 12:38:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:49 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:49 --> URI Class Initialized
INFO - 2023-08-19 12:38:49 --> Router Class Initialized
INFO - 2023-08-19 12:38:49 --> Output Class Initialized
INFO - 2023-08-19 12:38:49 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:49 --> Input Class Initialized
INFO - 2023-08-19 12:38:49 --> Language Class Initialized
INFO - 2023-08-19 12:38:49 --> Loader Class Initialized
INFO - 2023-08-19 12:38:49 --> Helper loaded: url_helper
INFO - 2023-08-19 12:38:49 --> Helper loaded: file_helper
INFO - 2023-08-19 12:38:49 --> Database Driver Class Initialized
INFO - 2023-08-19 12:38:49 --> Email Class Initialized
DEBUG - 2023-08-19 12:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:38:49 --> Controller Class Initialized
INFO - 2023-08-19 12:38:49 --> Model "Home_model" initialized
INFO - 2023-08-19 12:38:49 --> Helper loaded: form_helper
INFO - 2023-08-19 12:38:49 --> Form Validation Class Initialized
INFO - 2023-08-19 12:38:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 12:38:49 --> Final output sent to browser
DEBUG - 2023-08-19 12:38:49 --> Total execution time: 0.5897
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:50 --> Router Class Initialized
INFO - 2023-08-19 12:38:50 --> Output Class Initialized
INFO - 2023-08-19 12:38:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:50 --> Input Class Initialized
INFO - 2023-08-19 12:38:50 --> Language Class Initialized
ERROR - 2023-08-19 12:38:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:50 --> Router Class Initialized
INFO - 2023-08-19 12:38:50 --> Output Class Initialized
INFO - 2023-08-19 12:38:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:50 --> Input Class Initialized
INFO - 2023-08-19 12:38:50 --> Language Class Initialized
ERROR - 2023-08-19 12:38:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:50 --> Router Class Initialized
INFO - 2023-08-19 12:38:50 --> Output Class Initialized
INFO - 2023-08-19 12:38:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:50 --> Input Class Initialized
INFO - 2023-08-19 12:38:50 --> Language Class Initialized
ERROR - 2023-08-19 12:38:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:50 --> Router Class Initialized
INFO - 2023-08-19 12:38:50 --> Output Class Initialized
INFO - 2023-08-19 12:38:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:50 --> Input Class Initialized
INFO - 2023-08-19 12:38:50 --> Language Class Initialized
ERROR - 2023-08-19 12:38:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:50 --> Router Class Initialized
INFO - 2023-08-19 12:38:50 --> Output Class Initialized
INFO - 2023-08-19 12:38:50 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:50 --> Input Class Initialized
INFO - 2023-08-19 12:38:50 --> Language Class Initialized
ERROR - 2023-08-19 12:38:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:38:50 --> Config Class Initialized
INFO - 2023-08-19 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:38:50 --> Utf8 Class Initialized
INFO - 2023-08-19 12:38:50 --> URI Class Initialized
INFO - 2023-08-19 12:38:51 --> Router Class Initialized
INFO - 2023-08-19 12:38:51 --> Output Class Initialized
INFO - 2023-08-19 12:38:51 --> Security Class Initialized
DEBUG - 2023-08-19 12:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:38:51 --> Input Class Initialized
INFO - 2023-08-19 12:38:51 --> Language Class Initialized
ERROR - 2023-08-19 12:38:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:49:01 --> Config Class Initialized
INFO - 2023-08-19 12:49:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:01 --> URI Class Initialized
INFO - 2023-08-19 12:49:01 --> Router Class Initialized
INFO - 2023-08-19 12:49:01 --> Output Class Initialized
INFO - 2023-08-19 12:49:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:01 --> Input Class Initialized
INFO - 2023-08-19 12:49:01 --> Language Class Initialized
INFO - 2023-08-19 12:49:01 --> Loader Class Initialized
INFO - 2023-08-19 12:49:01 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:01 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:01 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:01 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:01 --> Controller Class Initialized
INFO - 2023-08-19 12:49:01 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-19 12:49:01 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:01 --> Form Validation Class Initialized
INFO - 2023-08-19 12:49:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-19 12:49:01 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:02 --> Total execution time: 0.2995
INFO - 2023-08-19 12:49:03 --> Config Class Initialized
INFO - 2023-08-19 12:49:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:03 --> URI Class Initialized
INFO - 2023-08-19 12:49:03 --> Router Class Initialized
INFO - 2023-08-19 12:49:03 --> Output Class Initialized
INFO - 2023-08-19 12:49:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:03 --> Input Class Initialized
INFO - 2023-08-19 12:49:03 --> Language Class Initialized
ERROR - 2023-08-19 12:49:03 --> 404 Page Not Found: admin/Training_curriculum/add
INFO - 2023-08-19 12:49:04 --> Config Class Initialized
INFO - 2023-08-19 12:49:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:04 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:04 --> URI Class Initialized
INFO - 2023-08-19 12:49:04 --> Router Class Initialized
INFO - 2023-08-19 12:49:04 --> Output Class Initialized
INFO - 2023-08-19 12:49:04 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:04 --> Input Class Initialized
INFO - 2023-08-19 12:49:04 --> Language Class Initialized
INFO - 2023-08-19 12:49:04 --> Loader Class Initialized
INFO - 2023-08-19 12:49:04 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:04 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:04 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:04 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:04 --> Controller Class Initialized
INFO - 2023-08-19 12:49:04 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:49:04 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:04 --> Form Validation Class Initialized
INFO - 2023-08-19 12:49:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-19 12:49:04 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:04 --> Total execution time: 0.1814
INFO - 2023-08-19 12:49:10 --> Config Class Initialized
INFO - 2023-08-19 12:49:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:10 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:10 --> URI Class Initialized
INFO - 2023-08-19 12:49:10 --> Router Class Initialized
INFO - 2023-08-19 12:49:10 --> Output Class Initialized
INFO - 2023-08-19 12:49:10 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:10 --> Input Class Initialized
INFO - 2023-08-19 12:49:10 --> Language Class Initialized
INFO - 2023-08-19 12:49:10 --> Loader Class Initialized
INFO - 2023-08-19 12:49:10 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:10 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:10 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:10 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:10 --> Controller Class Initialized
INFO - 2023-08-19 12:49:10 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:49:10 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:10 --> Form Validation Class Initialized
INFO - 2023-08-19 12:49:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-19 12:49:10 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:10 --> Total execution time: 0.3033
INFO - 2023-08-19 12:49:23 --> Config Class Initialized
INFO - 2023-08-19 12:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:23 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:23 --> URI Class Initialized
INFO - 2023-08-19 12:49:23 --> Router Class Initialized
INFO - 2023-08-19 12:49:23 --> Output Class Initialized
INFO - 2023-08-19 12:49:23 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:23 --> Input Class Initialized
INFO - 2023-08-19 12:49:23 --> Language Class Initialized
INFO - 2023-08-19 12:49:23 --> Loader Class Initialized
INFO - 2023-08-19 12:49:23 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:23 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:24 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:24 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:24 --> Controller Class Initialized
INFO - 2023-08-19 12:49:24 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:49:24 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:24 --> Form Validation Class Initialized
INFO - 2023-08-19 12:49:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-19 12:49:24 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:24 --> Total execution time: 0.2437
INFO - 2023-08-19 12:49:30 --> Config Class Initialized
INFO - 2023-08-19 12:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:30 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:30 --> URI Class Initialized
INFO - 2023-08-19 12:49:30 --> Router Class Initialized
INFO - 2023-08-19 12:49:30 --> Output Class Initialized
INFO - 2023-08-19 12:49:30 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:30 --> Input Class Initialized
INFO - 2023-08-19 12:49:30 --> Language Class Initialized
INFO - 2023-08-19 12:49:30 --> Loader Class Initialized
INFO - 2023-08-19 12:49:30 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:30 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:30 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:30 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:30 --> Controller Class Initialized
INFO - 2023-08-19 12:49:30 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:49:30 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:30 --> Form Validation Class Initialized
INFO - 2023-08-19 12:49:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-19 12:49:30 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:30 --> Total execution time: 0.3527
INFO - 2023-08-19 12:49:31 --> Config Class Initialized
INFO - 2023-08-19 12:49:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:49:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:49:31 --> Utf8 Class Initialized
INFO - 2023-08-19 12:49:31 --> URI Class Initialized
INFO - 2023-08-19 12:49:31 --> Router Class Initialized
INFO - 2023-08-19 12:49:31 --> Output Class Initialized
INFO - 2023-08-19 12:49:31 --> Security Class Initialized
DEBUG - 2023-08-19 12:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:49:31 --> Input Class Initialized
INFO - 2023-08-19 12:49:31 --> Language Class Initialized
INFO - 2023-08-19 12:49:31 --> Loader Class Initialized
INFO - 2023-08-19 12:49:31 --> Helper loaded: url_helper
INFO - 2023-08-19 12:49:31 --> Helper loaded: file_helper
INFO - 2023-08-19 12:49:31 --> Database Driver Class Initialized
INFO - 2023-08-19 12:49:31 --> Email Class Initialized
DEBUG - 2023-08-19 12:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:49:31 --> Controller Class Initialized
INFO - 2023-08-19 12:49:31 --> Model "Banner_model" initialized
INFO - 2023-08-19 12:49:31 --> Helper loaded: form_helper
INFO - 2023-08-19 12:49:31 --> Form Validation Class Initialized
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-19 12:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-19 12:49:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-19 12:49:31 --> Final output sent to browser
DEBUG - 2023-08-19 12:49:31 --> Total execution time: 0.5042
INFO - 2023-08-19 12:52:17 --> Config Class Initialized
INFO - 2023-08-19 12:52:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:17 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:17 --> URI Class Initialized
INFO - 2023-08-19 12:52:17 --> Router Class Initialized
INFO - 2023-08-19 12:52:17 --> Output Class Initialized
INFO - 2023-08-19 12:52:17 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:17 --> Input Class Initialized
INFO - 2023-08-19 12:52:17 --> Language Class Initialized
INFO - 2023-08-19 12:52:17 --> Loader Class Initialized
INFO - 2023-08-19 12:52:17 --> Helper loaded: url_helper
INFO - 2023-08-19 12:52:17 --> Helper loaded: file_helper
INFO - 2023-08-19 12:52:17 --> Database Driver Class Initialized
INFO - 2023-08-19 12:52:17 --> Email Class Initialized
DEBUG - 2023-08-19 12:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:52:17 --> Controller Class Initialized
INFO - 2023-08-19 12:52:17 --> Model "Home_model" initialized
INFO - 2023-08-19 12:52:17 --> Helper loaded: form_helper
INFO - 2023-08-19 12:52:17 --> Form Validation Class Initialized
INFO - 2023-08-19 12:52:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:52:17 --> Final output sent to browser
DEBUG - 2023-08-19 12:52:18 --> Total execution time: 0.4451
INFO - 2023-08-19 12:52:19 --> Config Class Initialized
INFO - 2023-08-19 12:52:19 --> Config Class Initialized
INFO - 2023-08-19 12:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:19 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:19 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:19 --> URI Class Initialized
INFO - 2023-08-19 12:52:19 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:19 --> Router Class Initialized
INFO - 2023-08-19 12:52:19 --> URI Class Initialized
INFO - 2023-08-19 12:52:19 --> Output Class Initialized
INFO - 2023-08-19 12:52:19 --> Security Class Initialized
INFO - 2023-08-19 12:52:19 --> Router Class Initialized
DEBUG - 2023-08-19 12:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:19 --> Output Class Initialized
INFO - 2023-08-19 12:52:19 --> Input Class Initialized
INFO - 2023-08-19 12:52:19 --> Security Class Initialized
INFO - 2023-08-19 12:52:19 --> Language Class Initialized
DEBUG - 2023-08-19 12:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 12:52:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:52:19 --> Input Class Initialized
INFO - 2023-08-19 12:52:19 --> Language Class Initialized
ERROR - 2023-08-19 12:52:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:52:19 --> Config Class Initialized
INFO - 2023-08-19 12:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:19 --> Config Class Initialized
INFO - 2023-08-19 12:52:19 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:20 --> Config Class Initialized
INFO - 2023-08-19 12:52:20 --> Config Class Initialized
DEBUG - 2023-08-19 12:52:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:20 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:20 --> URI Class Initialized
INFO - 2023-08-19 12:52:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:20 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:20 --> URI Class Initialized
DEBUG - 2023-08-19 12:52:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:52:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:20 --> Router Class Initialized
INFO - 2023-08-19 12:52:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:20 --> Router Class Initialized
INFO - 2023-08-19 12:52:20 --> URI Class Initialized
INFO - 2023-08-19 12:52:20 --> Output Class Initialized
INFO - 2023-08-19 12:52:20 --> Output Class Initialized
INFO - 2023-08-19 12:52:20 --> Security Class Initialized
INFO - 2023-08-19 12:52:20 --> URI Class Initialized
INFO - 2023-08-19 12:52:20 --> Security Class Initialized
INFO - 2023-08-19 12:52:20 --> Router Class Initialized
INFO - 2023-08-19 12:52:20 --> Router Class Initialized
INFO - 2023-08-19 12:52:20 --> Output Class Initialized
INFO - 2023-08-19 12:52:20 --> Output Class Initialized
DEBUG - 2023-08-19 12:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 12:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:20 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:20 --> Input Class Initialized
INFO - 2023-08-19 12:52:20 --> Input Class Initialized
INFO - 2023-08-19 12:52:20 --> Security Class Initialized
INFO - 2023-08-19 12:52:20 --> Input Class Initialized
INFO - 2023-08-19 12:52:20 --> Language Class Initialized
ERROR - 2023-08-19 12:52:20 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 12:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:20 --> Language Class Initialized
INFO - 2023-08-19 12:52:20 --> Input Class Initialized
INFO - 2023-08-19 12:52:20 --> Language Class Initialized
INFO - 2023-08-19 12:52:20 --> Language Class Initialized
ERROR - 2023-08-19 12:52:20 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 12:52:20 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 12:52:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:52:26 --> Config Class Initialized
INFO - 2023-08-19 12:52:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:26 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:26 --> URI Class Initialized
INFO - 2023-08-19 12:52:26 --> Router Class Initialized
INFO - 2023-08-19 12:52:26 --> Output Class Initialized
INFO - 2023-08-19 12:52:26 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:26 --> Input Class Initialized
INFO - 2023-08-19 12:52:26 --> Language Class Initialized
INFO - 2023-08-19 12:52:26 --> Loader Class Initialized
INFO - 2023-08-19 12:52:26 --> Helper loaded: url_helper
INFO - 2023-08-19 12:52:26 --> Helper loaded: file_helper
INFO - 2023-08-19 12:52:26 --> Database Driver Class Initialized
INFO - 2023-08-19 12:52:26 --> Email Class Initialized
DEBUG - 2023-08-19 12:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:52:26 --> Controller Class Initialized
INFO - 2023-08-19 12:52:26 --> Model "Home_model" initialized
INFO - 2023-08-19 12:52:26 --> Helper loaded: form_helper
INFO - 2023-08-19 12:52:27 --> Form Validation Class Initialized
INFO - 2023-08-19 12:52:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 12:52:27 --> Final output sent to browser
DEBUG - 2023-08-19 12:52:27 --> Total execution time: 0.5014
INFO - 2023-08-19 12:52:27 --> Config Class Initialized
INFO - 2023-08-19 12:52:27 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:27 --> Config Class Initialized
DEBUG - 2023-08-19 12:52:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:27 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:27 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:27 --> URI Class Initialized
DEBUG - 2023-08-19 12:52:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:28 --> Router Class Initialized
INFO - 2023-08-19 12:52:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:28 --> Output Class Initialized
INFO - 2023-08-19 12:52:28 --> URI Class Initialized
INFO - 2023-08-19 12:52:28 --> Security Class Initialized
INFO - 2023-08-19 12:52:28 --> Router Class Initialized
DEBUG - 2023-08-19 12:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:28 --> Output Class Initialized
INFO - 2023-08-19 12:52:28 --> Input Class Initialized
INFO - 2023-08-19 12:52:28 --> Security Class Initialized
INFO - 2023-08-19 12:52:28 --> Language Class Initialized
DEBUG - 2023-08-19 12:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 12:52:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:52:28 --> Input Class Initialized
INFO - 2023-08-19 12:52:28 --> Language Class Initialized
ERROR - 2023-08-19 12:52:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:52:28 --> Config Class Initialized
INFO - 2023-08-19 12:52:28 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:28 --> Config Class Initialized
DEBUG - 2023-08-19 12:52:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:28 --> Config Class Initialized
INFO - 2023-08-19 12:52:28 --> Hooks Class Initialized
INFO - 2023-08-19 12:52:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:52:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:28 --> URI Class Initialized
INFO - 2023-08-19 12:52:28 --> URI Class Initialized
INFO - 2023-08-19 12:52:28 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:28 --> Router Class Initialized
INFO - 2023-08-19 12:52:28 --> URI Class Initialized
INFO - 2023-08-19 12:52:28 --> Output Class Initialized
INFO - 2023-08-19 12:52:28 --> Router Class Initialized
INFO - 2023-08-19 12:52:28 --> Router Class Initialized
INFO - 2023-08-19 12:52:28 --> Security Class Initialized
INFO - 2023-08-19 12:52:28 --> Output Class Initialized
INFO - 2023-08-19 12:52:28 --> Output Class Initialized
INFO - 2023-08-19 12:52:28 --> Security Class Initialized
INFO - 2023-08-19 12:52:28 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 12:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:28 --> Input Class Initialized
INFO - 2023-08-19 12:52:28 --> Language Class Initialized
INFO - 2023-08-19 12:52:28 --> Input Class Initialized
DEBUG - 2023-08-19 12:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:28 --> Language Class Initialized
ERROR - 2023-08-19 12:52:28 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-19 12:52:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:52:28 --> Input Class Initialized
INFO - 2023-08-19 12:52:28 --> Language Class Initialized
ERROR - 2023-08-19 12:52:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:52:36 --> Config Class Initialized
INFO - 2023-08-19 12:52:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:36 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:36 --> URI Class Initialized
INFO - 2023-08-19 12:52:36 --> Router Class Initialized
INFO - 2023-08-19 12:52:36 --> Output Class Initialized
INFO - 2023-08-19 12:52:36 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:36 --> Input Class Initialized
INFO - 2023-08-19 12:52:36 --> Language Class Initialized
INFO - 2023-08-19 12:52:36 --> Loader Class Initialized
INFO - 2023-08-19 12:52:36 --> Helper loaded: url_helper
INFO - 2023-08-19 12:52:36 --> Helper loaded: file_helper
INFO - 2023-08-19 12:52:36 --> Database Driver Class Initialized
INFO - 2023-08-19 12:52:36 --> Email Class Initialized
DEBUG - 2023-08-19 12:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:52:36 --> Controller Class Initialized
INFO - 2023-08-19 12:52:36 --> Model "Home_model" initialized
INFO - 2023-08-19 12:52:36 --> Helper loaded: form_helper
INFO - 2023-08-19 12:52:36 --> Form Validation Class Initialized
INFO - 2023-08-19 12:52:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 12:52:36 --> Final output sent to browser
DEBUG - 2023-08-19 12:52:36 --> Total execution time: 0.4586
INFO - 2023-08-19 12:52:56 --> Config Class Initialized
INFO - 2023-08-19 12:52:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:56 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:56 --> URI Class Initialized
INFO - 2023-08-19 12:52:56 --> Router Class Initialized
INFO - 2023-08-19 12:52:56 --> Output Class Initialized
INFO - 2023-08-19 12:52:56 --> Security Class Initialized
DEBUG - 2023-08-19 12:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:52:56 --> Input Class Initialized
INFO - 2023-08-19 12:52:56 --> Language Class Initialized
INFO - 2023-08-19 12:52:56 --> Loader Class Initialized
INFO - 2023-08-19 12:52:56 --> Helper loaded: url_helper
INFO - 2023-08-19 12:52:57 --> Helper loaded: file_helper
INFO - 2023-08-19 12:52:57 --> Database Driver Class Initialized
INFO - 2023-08-19 12:52:57 --> Email Class Initialized
DEBUG - 2023-08-19 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:52:57 --> Controller Class Initialized
INFO - 2023-08-19 12:52:57 --> Model "Gallery_model" initialized
INFO - 2023-08-19 12:52:57 --> Helper loaded: form_helper
INFO - 2023-08-19 12:52:57 --> Form Validation Class Initialized
INFO - 2023-08-19 12:52:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-08-19 12:52:57 --> Final output sent to browser
DEBUG - 2023-08-19 12:52:57 --> Total execution time: 0.5002
INFO - 2023-08-19 12:52:59 --> Config Class Initialized
INFO - 2023-08-19 12:52:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:52:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:52:59 --> Utf8 Class Initialized
INFO - 2023-08-19 12:52:59 --> URI Class Initialized
INFO - 2023-08-19 12:53:20 --> Config Class Initialized
INFO - 2023-08-19 12:53:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:53:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:20 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:20 --> URI Class Initialized
INFO - 2023-08-19 12:53:20 --> Router Class Initialized
INFO - 2023-08-19 12:53:20 --> Output Class Initialized
INFO - 2023-08-19 12:53:20 --> Security Class Initialized
DEBUG - 2023-08-19 12:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:20 --> Input Class Initialized
INFO - 2023-08-19 12:53:20 --> Language Class Initialized
INFO - 2023-08-19 12:53:20 --> Loader Class Initialized
INFO - 2023-08-19 12:53:20 --> Helper loaded: url_helper
INFO - 2023-08-19 12:53:20 --> Helper loaded: file_helper
INFO - 2023-08-19 12:53:20 --> Database Driver Class Initialized
INFO - 2023-08-19 12:53:20 --> Email Class Initialized
DEBUG - 2023-08-19 12:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:53:20 --> Controller Class Initialized
INFO - 2023-08-19 12:53:20 --> Model "Home_model" initialized
INFO - 2023-08-19 12:53:20 --> Helper loaded: form_helper
INFO - 2023-08-19 12:53:20 --> Form Validation Class Initialized
INFO - 2023-08-19 12:53:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 12:53:20 --> Final output sent to browser
DEBUG - 2023-08-19 12:53:21 --> Total execution time: 0.3737
INFO - 2023-08-19 12:53:21 --> Config Class Initialized
INFO - 2023-08-19 12:53:21 --> Config Class Initialized
INFO - 2023-08-19 12:53:21 --> Hooks Class Initialized
INFO - 2023-08-19 12:53:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:53:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:53:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:21 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:21 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:21 --> URI Class Initialized
INFO - 2023-08-19 12:53:21 --> URI Class Initialized
INFO - 2023-08-19 12:53:21 --> Router Class Initialized
INFO - 2023-08-19 12:53:21 --> Router Class Initialized
INFO - 2023-08-19 12:53:21 --> Output Class Initialized
INFO - 2023-08-19 12:53:21 --> Output Class Initialized
INFO - 2023-08-19 12:53:21 --> Security Class Initialized
INFO - 2023-08-19 12:53:21 --> Security Class Initialized
DEBUG - 2023-08-19 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:21 --> Input Class Initialized
DEBUG - 2023-08-19 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:21 --> Language Class Initialized
INFO - 2023-08-19 12:53:21 --> Input Class Initialized
ERROR - 2023-08-19 12:53:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:53:21 --> Language Class Initialized
ERROR - 2023-08-19 12:53:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:53:21 --> Config Class Initialized
INFO - 2023-08-19 12:53:21 --> Config Class Initialized
INFO - 2023-08-19 12:53:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:53:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:22 --> Hooks Class Initialized
INFO - 2023-08-19 12:53:22 --> Config Class Initialized
DEBUG - 2023-08-19 12:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:22 --> URI Class Initialized
INFO - 2023-08-19 12:53:22 --> URI Class Initialized
INFO - 2023-08-19 12:53:22 --> Router Class Initialized
INFO - 2023-08-19 12:53:22 --> Router Class Initialized
INFO - 2023-08-19 12:53:22 --> Hooks Class Initialized
INFO - 2023-08-19 12:53:22 --> Output Class Initialized
DEBUG - 2023-08-19 12:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:22 --> Security Class Initialized
INFO - 2023-08-19 12:53:22 --> Output Class Initialized
INFO - 2023-08-19 12:53:22 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:22 --> URI Class Initialized
INFO - 2023-08-19 12:53:22 --> Security Class Initialized
DEBUG - 2023-08-19 12:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:22 --> Router Class Initialized
INFO - 2023-08-19 12:53:22 --> Input Class Initialized
INFO - 2023-08-19 12:53:22 --> Input Class Initialized
INFO - 2023-08-19 12:53:22 --> Language Class Initialized
INFO - 2023-08-19 12:53:22 --> Output Class Initialized
INFO - 2023-08-19 12:53:22 --> Language Class Initialized
INFO - 2023-08-19 12:53:22 --> Security Class Initialized
ERROR - 2023-08-19 12:53:22 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-19 12:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 12:53:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:53:22 --> Input Class Initialized
INFO - 2023-08-19 12:53:22 --> Language Class Initialized
ERROR - 2023-08-19 12:53:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 12:53:51 --> Config Class Initialized
INFO - 2023-08-19 12:53:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:53:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:53:51 --> Utf8 Class Initialized
INFO - 2023-08-19 12:53:51 --> URI Class Initialized
INFO - 2023-08-19 12:53:51 --> Router Class Initialized
INFO - 2023-08-19 12:53:51 --> Output Class Initialized
INFO - 2023-08-19 12:53:51 --> Security Class Initialized
DEBUG - 2023-08-19 12:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:53:51 --> Input Class Initialized
INFO - 2023-08-19 12:53:51 --> Language Class Initialized
ERROR - 2023-08-19 12:53:51 --> 404 Page Not Found: Training-detail/contact.html
INFO - 2023-08-19 12:54:03 --> Config Class Initialized
INFO - 2023-08-19 12:54:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:03 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:03 --> URI Class Initialized
INFO - 2023-08-19 12:54:03 --> Router Class Initialized
INFO - 2023-08-19 12:54:03 --> Output Class Initialized
INFO - 2023-08-19 12:54:03 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:04 --> Input Class Initialized
INFO - 2023-08-19 12:54:04 --> Language Class Initialized
INFO - 2023-08-19 12:54:04 --> Loader Class Initialized
INFO - 2023-08-19 12:54:04 --> Helper loaded: url_helper
INFO - 2023-08-19 12:54:04 --> Helper loaded: file_helper
INFO - 2023-08-19 12:54:04 --> Database Driver Class Initialized
INFO - 2023-08-19 12:54:04 --> Email Class Initialized
DEBUG - 2023-08-19 12:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:54:04 --> Controller Class Initialized
INFO - 2023-08-19 12:54:04 --> Model "Home_model" initialized
INFO - 2023-08-19 12:54:04 --> Helper loaded: form_helper
INFO - 2023-08-19 12:54:04 --> Form Validation Class Initialized
INFO - 2023-08-19 12:54:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-19 12:54:04 --> Final output sent to browser
DEBUG - 2023-08-19 12:54:04 --> Total execution time: 0.3934
INFO - 2023-08-19 12:54:05 --> Config Class Initialized
INFO - 2023-08-19 12:54:05 --> Config Class Initialized
INFO - 2023-08-19 12:54:05 --> Config Class Initialized
INFO - 2023-08-19 12:54:05 --> Hooks Class Initialized
INFO - 2023-08-19 12:54:05 --> Config Class Initialized
INFO - 2023-08-19 12:54:05 --> Config Class Initialized
INFO - 2023-08-19 12:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:05 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:05 --> URI Class Initialized
INFO - 2023-08-19 12:54:05 --> Router Class Initialized
INFO - 2023-08-19 12:54:05 --> Output Class Initialized
INFO - 2023-08-19 12:54:05 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:05 --> Input Class Initialized
INFO - 2023-08-19 12:54:05 --> Language Class Initialized
ERROR - 2023-08-19 12:54:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:05 --> Hooks Class Initialized
INFO - 2023-08-19 12:54:05 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:05 --> Hooks Class Initialized
INFO - 2023-08-19 12:54:05 --> URI Class Initialized
DEBUG - 2023-08-19 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 12:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:05 --> Router Class Initialized
INFO - 2023-08-19 12:54:05 --> Output Class Initialized
INFO - 2023-08-19 12:54:05 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:05 --> URI Class Initialized
INFO - 2023-08-19 12:54:05 --> Router Class Initialized
INFO - 2023-08-19 12:54:05 --> Output Class Initialized
INFO - 2023-08-19 12:54:05 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:05 --> Input Class Initialized
INFO - 2023-08-19 12:54:05 --> Language Class Initialized
ERROR - 2023-08-19 12:54:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:05 --> Security Class Initialized
INFO - 2023-08-19 12:54:05 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:05 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:05 --> URI Class Initialized
INFO - 2023-08-19 12:54:05 --> Input Class Initialized
INFO - 2023-08-19 12:54:05 --> Router Class Initialized
INFO - 2023-08-19 12:54:05 --> URI Class Initialized
INFO - 2023-08-19 12:54:06 --> Language Class Initialized
INFO - 2023-08-19 12:54:06 --> Router Class Initialized
INFO - 2023-08-19 12:54:06 --> Output Class Initialized
ERROR - 2023-08-19 12:54:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:06 --> Security Class Initialized
INFO - 2023-08-19 12:54:06 --> Output Class Initialized
DEBUG - 2023-08-19 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:06 --> Security Class Initialized
INFO - 2023-08-19 12:54:06 --> Input Class Initialized
DEBUG - 2023-08-19 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:06 --> Language Class Initialized
INFO - 2023-08-19 12:54:06 --> Input Class Initialized
ERROR - 2023-08-19 12:54:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:06 --> Language Class Initialized
ERROR - 2023-08-19 12:54:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:52 --> Config Class Initialized
INFO - 2023-08-19 12:54:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:52 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:52 --> URI Class Initialized
INFO - 2023-08-19 12:54:52 --> Router Class Initialized
INFO - 2023-08-19 12:54:52 --> Output Class Initialized
INFO - 2023-08-19 12:54:52 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:52 --> Input Class Initialized
INFO - 2023-08-19 12:54:52 --> Language Class Initialized
INFO - 2023-08-19 12:54:52 --> Loader Class Initialized
INFO - 2023-08-19 12:54:52 --> Helper loaded: url_helper
INFO - 2023-08-19 12:54:52 --> Helper loaded: file_helper
INFO - 2023-08-19 12:54:52 --> Database Driver Class Initialized
INFO - 2023-08-19 12:54:52 --> Email Class Initialized
DEBUG - 2023-08-19 12:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 12:54:52 --> Controller Class Initialized
INFO - 2023-08-19 12:54:52 --> Model "Home_model" initialized
INFO - 2023-08-19 12:54:52 --> Helper loaded: form_helper
INFO - 2023-08-19 12:54:52 --> Form Validation Class Initialized
INFO - 2023-08-19 12:54:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-19 12:54:53 --> Final output sent to browser
DEBUG - 2023-08-19 12:54:53 --> Total execution time: 0.4621
INFO - 2023-08-19 12:54:53 --> Config Class Initialized
INFO - 2023-08-19 12:54:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:53 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:53 --> URI Class Initialized
INFO - 2023-08-19 12:54:53 --> Router Class Initialized
INFO - 2023-08-19 12:54:53 --> Output Class Initialized
INFO - 2023-08-19 12:54:53 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:53 --> Input Class Initialized
INFO - 2023-08-19 12:54:53 --> Language Class Initialized
ERROR - 2023-08-19 12:54:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:53 --> Config Class Initialized
INFO - 2023-08-19 12:54:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:53 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:53 --> URI Class Initialized
INFO - 2023-08-19 12:54:53 --> Router Class Initialized
INFO - 2023-08-19 12:54:53 --> Output Class Initialized
INFO - 2023-08-19 12:54:53 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:53 --> Input Class Initialized
INFO - 2023-08-19 12:54:53 --> Language Class Initialized
ERROR - 2023-08-19 12:54:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:53 --> Config Class Initialized
INFO - 2023-08-19 12:54:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:53 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:53 --> URI Class Initialized
INFO - 2023-08-19 12:54:53 --> Router Class Initialized
INFO - 2023-08-19 12:54:53 --> Output Class Initialized
INFO - 2023-08-19 12:54:53 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:53 --> Input Class Initialized
INFO - 2023-08-19 12:54:53 --> Language Class Initialized
ERROR - 2023-08-19 12:54:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:54 --> Config Class Initialized
INFO - 2023-08-19 12:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:54 --> URI Class Initialized
INFO - 2023-08-19 12:54:54 --> Router Class Initialized
INFO - 2023-08-19 12:54:54 --> Output Class Initialized
INFO - 2023-08-19 12:54:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:54 --> Input Class Initialized
INFO - 2023-08-19 12:54:54 --> Language Class Initialized
ERROR - 2023-08-19 12:54:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:54:54 --> Config Class Initialized
INFO - 2023-08-19 12:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:54 --> URI Class Initialized
INFO - 2023-08-19 12:54:54 --> Router Class Initialized
INFO - 2023-08-19 12:54:54 --> Output Class Initialized
INFO - 2023-08-19 12:54:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:54 --> Input Class Initialized
INFO - 2023-08-19 12:54:54 --> Language Class Initialized
ERROR - 2023-08-19 12:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:54 --> Config Class Initialized
INFO - 2023-08-19 12:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:54 --> URI Class Initialized
INFO - 2023-08-19 12:54:54 --> Router Class Initialized
INFO - 2023-08-19 12:54:54 --> Output Class Initialized
INFO - 2023-08-19 12:54:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:54 --> Input Class Initialized
INFO - 2023-08-19 12:54:54 --> Language Class Initialized
ERROR - 2023-08-19 12:54:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 12:54:54 --> Config Class Initialized
INFO - 2023-08-19 12:54:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:54:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:54:54 --> Utf8 Class Initialized
INFO - 2023-08-19 12:54:54 --> URI Class Initialized
INFO - 2023-08-19 12:54:54 --> Router Class Initialized
INFO - 2023-08-19 12:54:54 --> Output Class Initialized
INFO - 2023-08-19 12:54:54 --> Security Class Initialized
DEBUG - 2023-08-19 12:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:54:54 --> Input Class Initialized
INFO - 2023-08-19 12:54:55 --> Language Class Initialized
ERROR - 2023-08-19 12:54:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:00 --> URI Class Initialized
INFO - 2023-08-19 12:56:00 --> Router Class Initialized
INFO - 2023-08-19 12:56:00 --> Output Class Initialized
INFO - 2023-08-19 12:56:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:00 --> Input Class Initialized
INFO - 2023-08-19 12:56:00 --> Language Class Initialized
ERROR - 2023-08-19 12:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:00 --> URI Class Initialized
INFO - 2023-08-19 12:56:00 --> Router Class Initialized
INFO - 2023-08-19 12:56:00 --> Output Class Initialized
INFO - 2023-08-19 12:56:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:00 --> Input Class Initialized
INFO - 2023-08-19 12:56:00 --> Language Class Initialized
ERROR - 2023-08-19 12:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:00 --> URI Class Initialized
INFO - 2023-08-19 12:56:00 --> Router Class Initialized
INFO - 2023-08-19 12:56:00 --> Output Class Initialized
INFO - 2023-08-19 12:56:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:00 --> Input Class Initialized
INFO - 2023-08-19 12:56:00 --> Language Class Initialized
ERROR - 2023-08-19 12:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:00 --> URI Class Initialized
INFO - 2023-08-19 12:56:00 --> Router Class Initialized
INFO - 2023-08-19 12:56:00 --> Output Class Initialized
INFO - 2023-08-19 12:56:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:00 --> Input Class Initialized
INFO - 2023-08-19 12:56:00 --> Language Class Initialized
ERROR - 2023-08-19 12:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:00 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:00 --> URI Class Initialized
INFO - 2023-08-19 12:56:00 --> Router Class Initialized
INFO - 2023-08-19 12:56:00 --> Output Class Initialized
INFO - 2023-08-19 12:56:00 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:00 --> Input Class Initialized
INFO - 2023-08-19 12:56:00 --> Language Class Initialized
ERROR - 2023-08-19 12:56:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Config Class Initialized
INFO - 2023-08-19 12:56:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 12:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:01 --> Hooks Class Initialized
INFO - 2023-08-19 12:56:01 --> Utf8 Class Initialized
DEBUG - 2023-08-19 12:56:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 12:56:01 --> Utf8 Class Initialized
INFO - 2023-08-19 12:56:01 --> URI Class Initialized
INFO - 2023-08-19 12:56:01 --> Router Class Initialized
INFO - 2023-08-19 12:56:01 --> Output Class Initialized
INFO - 2023-08-19 12:56:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:01 --> Input Class Initialized
INFO - 2023-08-19 12:56:01 --> Language Class Initialized
ERROR - 2023-08-19 12:56:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 12:56:01 --> URI Class Initialized
INFO - 2023-08-19 12:56:01 --> Router Class Initialized
INFO - 2023-08-19 12:56:01 --> Output Class Initialized
INFO - 2023-08-19 12:56:01 --> Security Class Initialized
DEBUG - 2023-08-19 12:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 12:56:01 --> Input Class Initialized
INFO - 2023-08-19 12:56:01 --> Language Class Initialized
ERROR - 2023-08-19 12:56:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:02:03 --> Config Class Initialized
INFO - 2023-08-19 13:02:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:03 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:03 --> URI Class Initialized
INFO - 2023-08-19 13:02:03 --> Router Class Initialized
INFO - 2023-08-19 13:02:03 --> Output Class Initialized
INFO - 2023-08-19 13:02:03 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:03 --> Input Class Initialized
INFO - 2023-08-19 13:02:03 --> Language Class Initialized
INFO - 2023-08-19 13:02:03 --> Loader Class Initialized
INFO - 2023-08-19 13:02:03 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:03 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:03 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:03 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:03 --> Controller Class Initialized
INFO - 2023-08-19 13:02:03 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:03 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:04 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-19 13:02:04 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:04 --> Total execution time: 0.6156
INFO - 2023-08-19 13:02:06 --> Config Class Initialized
INFO - 2023-08-19 13:02:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:06 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:06 --> URI Class Initialized
INFO - 2023-08-19 13:02:06 --> Router Class Initialized
INFO - 2023-08-19 13:02:06 --> Output Class Initialized
INFO - 2023-08-19 13:02:06 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:06 --> Input Class Initialized
INFO - 2023-08-19 13:02:06 --> Language Class Initialized
INFO - 2023-08-19 13:02:06 --> Loader Class Initialized
INFO - 2023-08-19 13:02:06 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:06 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:06 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:06 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:06 --> Controller Class Initialized
INFO - 2023-08-19 13:02:06 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:06 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:06 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 13:02:06 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:06 --> Total execution time: 0.0773
INFO - 2023-08-19 13:02:07 --> Config Class Initialized
INFO - 2023-08-19 13:02:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:07 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:07 --> URI Class Initialized
INFO - 2023-08-19 13:02:07 --> Router Class Initialized
INFO - 2023-08-19 13:02:07 --> Output Class Initialized
INFO - 2023-08-19 13:02:07 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:07 --> Input Class Initialized
INFO - 2023-08-19 13:02:07 --> Language Class Initialized
INFO - 2023-08-19 13:02:07 --> Loader Class Initialized
INFO - 2023-08-19 13:02:07 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:07 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:07 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:07 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:07 --> Controller Class Initialized
INFO - 2023-08-19 13:02:07 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:07 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:07 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 13:02:07 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:07 --> Total execution time: 0.0626
INFO - 2023-08-19 13:02:30 --> Config Class Initialized
INFO - 2023-08-19 13:02:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:31 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:31 --> URI Class Initialized
INFO - 2023-08-19 13:02:31 --> Router Class Initialized
INFO - 2023-08-19 13:02:31 --> Output Class Initialized
INFO - 2023-08-19 13:02:31 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:31 --> Input Class Initialized
INFO - 2023-08-19 13:02:31 --> Language Class Initialized
INFO - 2023-08-19 13:02:31 --> Loader Class Initialized
INFO - 2023-08-19 13:02:31 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:32 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:32 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:32 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:32 --> Controller Class Initialized
INFO - 2023-08-19 13:02:32 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:32 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:32 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-19 13:02:32 --> Config Class Initialized
INFO - 2023-08-19 13:02:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:32 --> URI Class Initialized
INFO - 2023-08-19 13:02:32 --> Router Class Initialized
INFO - 2023-08-19 13:02:32 --> Output Class Initialized
INFO - 2023-08-19 13:02:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:32 --> Input Class Initialized
INFO - 2023-08-19 13:02:32 --> Language Class Initialized
INFO - 2023-08-19 13:02:32 --> Loader Class Initialized
INFO - 2023-08-19 13:02:32 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:32 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:32 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:32 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:32 --> Controller Class Initialized
INFO - 2023-08-19 13:02:32 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:32 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:32 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-19 13:02:32 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:32 --> Total execution time: 0.1199
INFO - 2023-08-19 13:02:37 --> Config Class Initialized
INFO - 2023-08-19 13:02:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:37 --> URI Class Initialized
INFO - 2023-08-19 13:02:37 --> Router Class Initialized
INFO - 2023-08-19 13:02:37 --> Output Class Initialized
INFO - 2023-08-19 13:02:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:37 --> Input Class Initialized
INFO - 2023-08-19 13:02:37 --> Language Class Initialized
INFO - 2023-08-19 13:02:37 --> Loader Class Initialized
INFO - 2023-08-19 13:02:37 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:37 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:37 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:37 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:37 --> Controller Class Initialized
INFO - 2023-08-19 13:02:37 --> Model "Key_highlights_model" initialized
INFO - 2023-08-19 13:02:37 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:37 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-19 13:02:37 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:37 --> Total execution time: 0.0714
INFO - 2023-08-19 13:02:38 --> Config Class Initialized
INFO - 2023-08-19 13:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:38 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:38 --> URI Class Initialized
INFO - 2023-08-19 13:02:38 --> Router Class Initialized
INFO - 2023-08-19 13:02:38 --> Output Class Initialized
INFO - 2023-08-19 13:02:38 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:38 --> Input Class Initialized
INFO - 2023-08-19 13:02:38 --> Language Class Initialized
ERROR - 2023-08-19 13:02:38 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-19 13:02:40 --> Config Class Initialized
INFO - 2023-08-19 13:02:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:41 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:41 --> URI Class Initialized
INFO - 2023-08-19 13:02:41 --> Router Class Initialized
INFO - 2023-08-19 13:02:41 --> Output Class Initialized
INFO - 2023-08-19 13:02:41 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:41 --> Input Class Initialized
INFO - 2023-08-19 13:02:41 --> Language Class Initialized
INFO - 2023-08-19 13:02:41 --> Loader Class Initialized
INFO - 2023-08-19 13:02:41 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:41 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:41 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:41 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:41 --> Controller Class Initialized
INFO - 2023-08-19 13:02:41 --> Model "Key_highlights_model" initialized
INFO - 2023-08-19 13:02:41 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:41 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_create.php
INFO - 2023-08-19 13:02:41 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:42 --> Total execution time: 0.9521
INFO - 2023-08-19 13:02:42 --> Config Class Initialized
INFO - 2023-08-19 13:02:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:42 --> URI Class Initialized
INFO - 2023-08-19 13:02:42 --> Router Class Initialized
INFO - 2023-08-19 13:02:42 --> Output Class Initialized
INFO - 2023-08-19 13:02:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:42 --> Input Class Initialized
INFO - 2023-08-19 13:02:42 --> Language Class Initialized
ERROR - 2023-08-19 13:02:42 --> 404 Page Not Found: admin/Key_highlights/add
INFO - 2023-08-19 13:02:45 --> Config Class Initialized
INFO - 2023-08-19 13:02:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:45 --> URI Class Initialized
INFO - 2023-08-19 13:02:45 --> Router Class Initialized
INFO - 2023-08-19 13:02:45 --> Output Class Initialized
INFO - 2023-08-19 13:02:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:46 --> Input Class Initialized
INFO - 2023-08-19 13:02:46 --> Language Class Initialized
ERROR - 2023-08-19 13:02:46 --> 404 Page Not Found: admin/Key_highlights/index
INFO - 2023-08-19 13:02:49 --> Config Class Initialized
INFO - 2023-08-19 13:02:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:49 --> URI Class Initialized
INFO - 2023-08-19 13:02:49 --> Router Class Initialized
INFO - 2023-08-19 13:02:49 --> Output Class Initialized
INFO - 2023-08-19 13:02:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:49 --> Input Class Initialized
INFO - 2023-08-19 13:02:49 --> Language Class Initialized
INFO - 2023-08-19 13:02:49 --> Loader Class Initialized
INFO - 2023-08-19 13:02:49 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:49 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:49 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:49 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:49 --> Controller Class Initialized
INFO - 2023-08-19 13:02:49 --> Model "Key_highlights_model" initialized
INFO - 2023-08-19 13:02:49 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:49 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_create.php
INFO - 2023-08-19 13:02:49 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:49 --> Total execution time: 0.7299
INFO - 2023-08-19 13:02:53 --> Config Class Initialized
INFO - 2023-08-19 13:02:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:53 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:53 --> URI Class Initialized
INFO - 2023-08-19 13:02:53 --> Router Class Initialized
INFO - 2023-08-19 13:02:53 --> Output Class Initialized
INFO - 2023-08-19 13:02:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:54 --> Input Class Initialized
INFO - 2023-08-19 13:02:54 --> Language Class Initialized
INFO - 2023-08-19 13:02:54 --> Loader Class Initialized
INFO - 2023-08-19 13:02:54 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:54 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:54 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:54 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:54 --> Controller Class Initialized
INFO - 2023-08-19 13:02:54 --> Model "Key_highlights_model" initialized
INFO - 2023-08-19 13:02:54 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:54 --> Form Validation Class Initialized
INFO - 2023-08-19 13:02:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/key_highlights_list.php
INFO - 2023-08-19 13:02:54 --> Final output sent to browser
DEBUG - 2023-08-19 13:02:54 --> Total execution time: 1.1003
INFO - 2023-08-19 13:02:59 --> Config Class Initialized
INFO - 2023-08-19 13:02:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:02:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:02:59 --> Utf8 Class Initialized
INFO - 2023-08-19 13:02:59 --> URI Class Initialized
INFO - 2023-08-19 13:02:59 --> Router Class Initialized
INFO - 2023-08-19 13:02:59 --> Output Class Initialized
INFO - 2023-08-19 13:02:59 --> Security Class Initialized
DEBUG - 2023-08-19 13:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:02:59 --> Input Class Initialized
INFO - 2023-08-19 13:02:59 --> Language Class Initialized
INFO - 2023-08-19 13:02:59 --> Loader Class Initialized
INFO - 2023-08-19 13:02:59 --> Helper loaded: url_helper
INFO - 2023-08-19 13:02:59 --> Helper loaded: file_helper
INFO - 2023-08-19 13:02:59 --> Database Driver Class Initialized
INFO - 2023-08-19 13:02:59 --> Email Class Initialized
DEBUG - 2023-08-19 13:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:02:59 --> Controller Class Initialized
INFO - 2023-08-19 13:02:59 --> Model "Training_model" initialized
INFO - 2023-08-19 13:02:59 --> Helper loaded: form_helper
INFO - 2023-08-19 13:02:59 --> Form Validation Class Initialized
INFO - 2023-08-19 13:03:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-19 13:03:00 --> Final output sent to browser
DEBUG - 2023-08-19 13:03:00 --> Total execution time: 1.0323
INFO - 2023-08-19 13:03:03 --> Config Class Initialized
INFO - 2023-08-19 13:03:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:03:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:03:03 --> Utf8 Class Initialized
INFO - 2023-08-19 13:03:03 --> URI Class Initialized
INFO - 2023-08-19 13:03:03 --> Router Class Initialized
INFO - 2023-08-19 13:03:03 --> Output Class Initialized
INFO - 2023-08-19 13:03:03 --> Security Class Initialized
DEBUG - 2023-08-19 13:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:03:04 --> Input Class Initialized
INFO - 2023-08-19 13:03:04 --> Language Class Initialized
INFO - 2023-08-19 13:03:04 --> Loader Class Initialized
INFO - 2023-08-19 13:03:04 --> Helper loaded: url_helper
INFO - 2023-08-19 13:03:04 --> Helper loaded: file_helper
INFO - 2023-08-19 13:03:04 --> Database Driver Class Initialized
INFO - 2023-08-19 13:03:04 --> Email Class Initialized
DEBUG - 2023-08-19 13:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:03:04 --> Controller Class Initialized
INFO - 2023-08-19 13:03:04 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-19 13:03:04 --> Helper loaded: form_helper
INFO - 2023-08-19 13:03:04 --> Form Validation Class Initialized
INFO - 2023-08-19 13:03:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_list.php
INFO - 2023-08-19 13:03:04 --> Final output sent to browser
DEBUG - 2023-08-19 13:03:04 --> Total execution time: 0.9627
INFO - 2023-08-19 13:03:05 --> Config Class Initialized
INFO - 2023-08-19 13:03:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:03:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:03:05 --> Utf8 Class Initialized
INFO - 2023-08-19 13:03:05 --> URI Class Initialized
INFO - 2023-08-19 13:03:05 --> Router Class Initialized
INFO - 2023-08-19 13:03:05 --> Output Class Initialized
INFO - 2023-08-19 13:03:05 --> Security Class Initialized
DEBUG - 2023-08-19 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:03:05 --> Input Class Initialized
INFO - 2023-08-19 13:03:05 --> Language Class Initialized
ERROR - 2023-08-19 13:03:05 --> 404 Page Not Found: admin/Training_curriculum/images
INFO - 2023-08-19 13:15:34 --> Config Class Initialized
INFO - 2023-08-19 13:15:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:15:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:15:34 --> Utf8 Class Initialized
INFO - 2023-08-19 13:15:34 --> URI Class Initialized
INFO - 2023-08-19 13:15:34 --> Router Class Initialized
INFO - 2023-08-19 13:15:34 --> Output Class Initialized
INFO - 2023-08-19 13:15:34 --> Security Class Initialized
DEBUG - 2023-08-19 13:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:15:34 --> Input Class Initialized
INFO - 2023-08-19 13:15:34 --> Language Class Initialized
INFO - 2023-08-19 13:15:34 --> Loader Class Initialized
INFO - 2023-08-19 13:15:34 --> Helper loaded: url_helper
INFO - 2023-08-19 13:15:34 --> Helper loaded: file_helper
INFO - 2023-08-19 13:15:34 --> Database Driver Class Initialized
INFO - 2023-08-19 13:15:34 --> Email Class Initialized
DEBUG - 2023-08-19 13:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:15:35 --> Controller Class Initialized
INFO - 2023-08-19 13:15:35 --> Model "Training_model" initialized
INFO - 2023-08-19 13:15:35 --> Helper loaded: form_helper
INFO - 2023-08-19 13:15:35 --> Form Validation Class Initialized
INFO - 2023-08-19 13:15:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-19 13:15:35 --> Final output sent to browser
DEBUG - 2023-08-19 13:15:35 --> Total execution time: 1.0621
INFO - 2023-08-19 13:15:36 --> Config Class Initialized
INFO - 2023-08-19 13:15:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:15:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:15:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:15:37 --> URI Class Initialized
INFO - 2023-08-19 13:15:37 --> Router Class Initialized
INFO - 2023-08-19 13:15:37 --> Output Class Initialized
INFO - 2023-08-19 13:15:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:15:37 --> Input Class Initialized
INFO - 2023-08-19 13:15:37 --> Language Class Initialized
INFO - 2023-08-19 13:15:37 --> Loader Class Initialized
INFO - 2023-08-19 13:15:37 --> Helper loaded: url_helper
INFO - 2023-08-19 13:15:37 --> Helper loaded: file_helper
INFO - 2023-08-19 13:15:37 --> Database Driver Class Initialized
INFO - 2023-08-19 13:15:37 --> Email Class Initialized
DEBUG - 2023-08-19 13:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:15:37 --> Controller Class Initialized
INFO - 2023-08-19 13:15:37 --> Model "Training_model" initialized
INFO - 2023-08-19 13:15:37 --> Helper loaded: form_helper
INFO - 2023-08-19 13:15:37 --> Form Validation Class Initialized
INFO - 2023-08-19 13:15:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 13:15:37 --> Final output sent to browser
DEBUG - 2023-08-19 13:15:37 --> Total execution time: 0.7885
INFO - 2023-08-19 13:15:38 --> Config Class Initialized
INFO - 2023-08-19 13:15:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:15:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:15:38 --> Utf8 Class Initialized
INFO - 2023-08-19 13:15:38 --> URI Class Initialized
INFO - 2023-08-19 13:15:38 --> Router Class Initialized
INFO - 2023-08-19 13:15:38 --> Output Class Initialized
INFO - 2023-08-19 13:15:38 --> Security Class Initialized
DEBUG - 2023-08-19 13:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:15:38 --> Input Class Initialized
INFO - 2023-08-19 13:15:38 --> Language Class Initialized
INFO - 2023-08-19 13:15:38 --> Loader Class Initialized
INFO - 2023-08-19 13:15:38 --> Helper loaded: url_helper
INFO - 2023-08-19 13:15:38 --> Helper loaded: file_helper
INFO - 2023-08-19 13:15:38 --> Database Driver Class Initialized
INFO - 2023-08-19 13:15:38 --> Email Class Initialized
DEBUG - 2023-08-19 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:15:38 --> Controller Class Initialized
INFO - 2023-08-19 13:15:38 --> Model "Training_model" initialized
INFO - 2023-08-19 13:15:38 --> Helper loaded: form_helper
INFO - 2023-08-19 13:15:38 --> Form Validation Class Initialized
INFO - 2023-08-19 13:15:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 13:15:38 --> Final output sent to browser
DEBUG - 2023-08-19 13:15:38 --> Total execution time: 0.7099
INFO - 2023-08-19 13:17:24 --> Config Class Initialized
INFO - 2023-08-19 13:17:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:24 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:24 --> URI Class Initialized
INFO - 2023-08-19 13:17:24 --> Router Class Initialized
INFO - 2023-08-19 13:17:24 --> Output Class Initialized
INFO - 2023-08-19 13:17:24 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:24 --> Input Class Initialized
INFO - 2023-08-19 13:17:24 --> Language Class Initialized
INFO - 2023-08-19 13:17:24 --> Loader Class Initialized
INFO - 2023-08-19 13:17:24 --> Helper loaded: url_helper
INFO - 2023-08-19 13:17:24 --> Helper loaded: file_helper
INFO - 2023-08-19 13:17:24 --> Database Driver Class Initialized
INFO - 2023-08-19 13:17:24 --> Email Class Initialized
DEBUG - 2023-08-19 13:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:17:25 --> Controller Class Initialized
INFO - 2023-08-19 13:17:25 --> Model "Home_model" initialized
INFO - 2023-08-19 13:17:25 --> Helper loaded: form_helper
INFO - 2023-08-19 13:17:25 --> Form Validation Class Initialized
INFO - 2023-08-19 13:17:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-19 13:17:25 --> Final output sent to browser
DEBUG - 2023-08-19 13:17:25 --> Total execution time: 0.7153
INFO - 2023-08-19 13:17:25 --> Config Class Initialized
INFO - 2023-08-19 13:17:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:25 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:25 --> URI Class Initialized
INFO - 2023-08-19 13:17:25 --> Router Class Initialized
INFO - 2023-08-19 13:17:25 --> Output Class Initialized
INFO - 2023-08-19 13:17:25 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:25 --> Input Class Initialized
INFO - 2023-08-19 13:17:25 --> Language Class Initialized
ERROR - 2023-08-19 13:17:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:17:26 --> Config Class Initialized
INFO - 2023-08-19 13:17:26 --> Hooks Class Initialized
INFO - 2023-08-19 13:17:26 --> Config Class Initialized
INFO - 2023-08-19 13:17:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:17:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:26 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:26 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Config Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
INFO - 2023-08-19 13:17:27 --> Config Class Initialized
INFO - 2023-08-19 13:17:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Hooks Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
DEBUG - 2023-08-19 13:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:27 --> Config Class Initialized
INFO - 2023-08-19 13:17:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:17:27 --> Config Class Initialized
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
INFO - 2023-08-19 13:17:27 --> Hooks Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
INFO - 2023-08-19 13:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:27 --> Config Class Initialized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:17:27 --> URI Class Initialized
INFO - 2023-08-19 13:17:27 --> Router Class Initialized
INFO - 2023-08-19 13:17:27 --> Output Class Initialized
INFO - 2023-08-19 13:17:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:27 --> Input Class Initialized
INFO - 2023-08-19 13:17:27 --> Language Class Initialized
ERROR - 2023-08-19 13:17:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:17:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:17:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:17:28 --> URI Class Initialized
INFO - 2023-08-19 13:17:28 --> Router Class Initialized
INFO - 2023-08-19 13:17:28 --> Output Class Initialized
INFO - 2023-08-19 13:17:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:17:28 --> Input Class Initialized
INFO - 2023-08-19 13:17:28 --> Language Class Initialized
ERROR - 2023-08-19 13:17:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:47 --> Config Class Initialized
INFO - 2023-08-19 13:23:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:47 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:47 --> URI Class Initialized
INFO - 2023-08-19 13:23:47 --> Router Class Initialized
INFO - 2023-08-19 13:23:47 --> Output Class Initialized
INFO - 2023-08-19 13:23:47 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:47 --> Input Class Initialized
INFO - 2023-08-19 13:23:47 --> Language Class Initialized
INFO - 2023-08-19 13:23:47 --> Loader Class Initialized
INFO - 2023-08-19 13:23:47 --> Helper loaded: url_helper
INFO - 2023-08-19 13:23:48 --> Helper loaded: file_helper
INFO - 2023-08-19 13:23:48 --> Database Driver Class Initialized
INFO - 2023-08-19 13:23:48 --> Email Class Initialized
DEBUG - 2023-08-19 13:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:23:48 --> Controller Class Initialized
INFO - 2023-08-19 13:23:48 --> Model "Home_model" initialized
INFO - 2023-08-19 13:23:48 --> Helper loaded: form_helper
INFO - 2023-08-19 13:23:48 --> Form Validation Class Initialized
INFO - 2023-08-19 13:23:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 13:23:48 --> Final output sent to browser
DEBUG - 2023-08-19 13:23:48 --> Total execution time: 0.8835
INFO - 2023-08-19 13:23:49 --> Config Class Initialized
INFO - 2023-08-19 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:49 --> URI Class Initialized
INFO - 2023-08-19 13:23:49 --> Router Class Initialized
INFO - 2023-08-19 13:23:49 --> Output Class Initialized
INFO - 2023-08-19 13:23:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:49 --> Input Class Initialized
INFO - 2023-08-19 13:23:49 --> Language Class Initialized
ERROR - 2023-08-19 13:23:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:49 --> Config Class Initialized
INFO - 2023-08-19 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:49 --> URI Class Initialized
INFO - 2023-08-19 13:23:49 --> Router Class Initialized
INFO - 2023-08-19 13:23:49 --> Output Class Initialized
INFO - 2023-08-19 13:23:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:49 --> Input Class Initialized
INFO - 2023-08-19 13:23:49 --> Language Class Initialized
ERROR - 2023-08-19 13:23:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:49 --> Config Class Initialized
INFO - 2023-08-19 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:49 --> URI Class Initialized
INFO - 2023-08-19 13:23:49 --> Router Class Initialized
INFO - 2023-08-19 13:23:49 --> Output Class Initialized
INFO - 2023-08-19 13:23:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:49 --> Input Class Initialized
INFO - 2023-08-19 13:23:49 --> Language Class Initialized
ERROR - 2023-08-19 13:23:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:49 --> Config Class Initialized
INFO - 2023-08-19 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:49 --> Config Class Initialized
INFO - 2023-08-19 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:49 --> URI Class Initialized
INFO - 2023-08-19 13:23:49 --> Router Class Initialized
INFO - 2023-08-19 13:23:49 --> Output Class Initialized
INFO - 2023-08-19 13:23:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:49 --> Input Class Initialized
INFO - 2023-08-19 13:23:49 --> Language Class Initialized
ERROR - 2023-08-19 13:23:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:49 --> URI Class Initialized
INFO - 2023-08-19 13:23:49 --> Router Class Initialized
INFO - 2023-08-19 13:23:49 --> Output Class Initialized
INFO - 2023-08-19 13:23:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:50 --> Input Class Initialized
INFO - 2023-08-19 13:23:50 --> Language Class Initialized
ERROR - 2023-08-19 13:23:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:50 --> Config Class Initialized
INFO - 2023-08-19 13:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:50 --> URI Class Initialized
INFO - 2023-08-19 13:23:50 --> Router Class Initialized
INFO - 2023-08-19 13:23:50 --> Output Class Initialized
INFO - 2023-08-19 13:23:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:50 --> Input Class Initialized
INFO - 2023-08-19 13:23:50 --> Language Class Initialized
ERROR - 2023-08-19 13:23:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:50 --> Config Class Initialized
INFO - 2023-08-19 13:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:50 --> URI Class Initialized
INFO - 2023-08-19 13:23:50 --> Router Class Initialized
INFO - 2023-08-19 13:23:50 --> Output Class Initialized
INFO - 2023-08-19 13:23:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:50 --> Input Class Initialized
INFO - 2023-08-19 13:23:50 --> Language Class Initialized
ERROR - 2023-08-19 13:23:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:23:53 --> Config Class Initialized
INFO - 2023-08-19 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:53 --> URI Class Initialized
INFO - 2023-08-19 13:23:53 --> Router Class Initialized
INFO - 2023-08-19 13:23:53 --> Output Class Initialized
INFO - 2023-08-19 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:53 --> Input Class Initialized
INFO - 2023-08-19 13:23:53 --> Language Class Initialized
INFO - 2023-08-19 13:23:53 --> Loader Class Initialized
INFO - 2023-08-19 13:23:53 --> Helper loaded: url_helper
INFO - 2023-08-19 13:23:53 --> Helper loaded: file_helper
INFO - 2023-08-19 13:23:53 --> Database Driver Class Initialized
INFO - 2023-08-19 13:23:53 --> Email Class Initialized
DEBUG - 2023-08-19 13:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:23:53 --> Controller Class Initialized
INFO - 2023-08-19 13:23:53 --> Model "Home_model" initialized
INFO - 2023-08-19 13:23:53 --> Helper loaded: form_helper
INFO - 2023-08-19 13:23:53 --> Form Validation Class Initialized
INFO - 2023-08-19 13:23:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 13:23:53 --> Final output sent to browser
DEBUG - 2023-08-19 13:23:53 --> Total execution time: 0.0505
INFO - 2023-08-19 13:23:53 --> Config Class Initialized
INFO - 2023-08-19 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:53 --> URI Class Initialized
INFO - 2023-08-19 13:23:53 --> Router Class Initialized
INFO - 2023-08-19 13:23:53 --> Output Class Initialized
INFO - 2023-08-19 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:53 --> Input Class Initialized
INFO - 2023-08-19 13:23:53 --> Language Class Initialized
ERROR - 2023-08-19 13:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:53 --> Config Class Initialized
INFO - 2023-08-19 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:53 --> URI Class Initialized
INFO - 2023-08-19 13:23:53 --> Router Class Initialized
INFO - 2023-08-19 13:23:53 --> Output Class Initialized
INFO - 2023-08-19 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:53 --> Input Class Initialized
INFO - 2023-08-19 13:23:53 --> Language Class Initialized
ERROR - 2023-08-19 13:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:53 --> Config Class Initialized
INFO - 2023-08-19 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:53 --> URI Class Initialized
INFO - 2023-08-19 13:23:53 --> Router Class Initialized
INFO - 2023-08-19 13:23:53 --> Output Class Initialized
INFO - 2023-08-19 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:53 --> Input Class Initialized
INFO - 2023-08-19 13:23:53 --> Language Class Initialized
ERROR - 2023-08-19 13:23:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:54 --> Config Class Initialized
INFO - 2023-08-19 13:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:54 --> URI Class Initialized
INFO - 2023-08-19 13:23:54 --> Router Class Initialized
INFO - 2023-08-19 13:23:54 --> Output Class Initialized
INFO - 2023-08-19 13:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:54 --> Input Class Initialized
INFO - 2023-08-19 13:23:54 --> Language Class Initialized
ERROR - 2023-08-19 13:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:54 --> Config Class Initialized
INFO - 2023-08-19 13:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:54 --> URI Class Initialized
INFO - 2023-08-19 13:23:54 --> Router Class Initialized
INFO - 2023-08-19 13:23:54 --> Output Class Initialized
INFO - 2023-08-19 13:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:54 --> Input Class Initialized
INFO - 2023-08-19 13:23:54 --> Language Class Initialized
ERROR - 2023-08-19 13:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:54 --> Config Class Initialized
INFO - 2023-08-19 13:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:54 --> URI Class Initialized
INFO - 2023-08-19 13:23:54 --> Router Class Initialized
INFO - 2023-08-19 13:23:54 --> Output Class Initialized
INFO - 2023-08-19 13:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:54 --> Input Class Initialized
INFO - 2023-08-19 13:23:54 --> Language Class Initialized
ERROR - 2023-08-19 13:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:54 --> Config Class Initialized
INFO - 2023-08-19 13:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:54 --> URI Class Initialized
INFO - 2023-08-19 13:23:54 --> Router Class Initialized
INFO - 2023-08-19 13:23:54 --> Output Class Initialized
INFO - 2023-08-19 13:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:54 --> Input Class Initialized
INFO - 2023-08-19 13:23:54 --> Language Class Initialized
ERROR - 2023-08-19 13:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:23:54 --> Config Class Initialized
INFO - 2023-08-19 13:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:23:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:23:54 --> URI Class Initialized
INFO - 2023-08-19 13:23:54 --> Router Class Initialized
INFO - 2023-08-19 13:23:54 --> Output Class Initialized
INFO - 2023-08-19 13:23:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:23:54 --> Input Class Initialized
INFO - 2023-08-19 13:23:54 --> Language Class Initialized
ERROR - 2023-08-19 13:23:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-19 13:28:58 --> Config Class Initialized
INFO - 2023-08-19 13:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:28:58 --> Utf8 Class Initialized
INFO - 2023-08-19 13:28:58 --> URI Class Initialized
INFO - 2023-08-19 13:28:58 --> Router Class Initialized
INFO - 2023-08-19 13:28:58 --> Output Class Initialized
INFO - 2023-08-19 13:28:58 --> Security Class Initialized
DEBUG - 2023-08-19 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:28:58 --> Input Class Initialized
INFO - 2023-08-19 13:28:58 --> Language Class Initialized
INFO - 2023-08-19 13:28:58 --> Loader Class Initialized
INFO - 2023-08-19 13:28:58 --> Helper loaded: url_helper
INFO - 2023-08-19 13:28:58 --> Helper loaded: file_helper
INFO - 2023-08-19 13:28:58 --> Database Driver Class Initialized
INFO - 2023-08-19 13:28:59 --> Email Class Initialized
DEBUG - 2023-08-19 13:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:28:59 --> Controller Class Initialized
INFO - 2023-08-19 13:28:59 --> Model "Home_model" initialized
INFO - 2023-08-19 13:28:59 --> Helper loaded: form_helper
INFO - 2023-08-19 13:28:59 --> Form Validation Class Initialized
INFO - 2023-08-19 13:30:13 --> Config Class Initialized
INFO - 2023-08-19 13:30:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:30:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:30:13 --> Utf8 Class Initialized
INFO - 2023-08-19 13:30:13 --> URI Class Initialized
INFO - 2023-08-19 13:30:13 --> Router Class Initialized
INFO - 2023-08-19 13:30:13 --> Output Class Initialized
INFO - 2023-08-19 13:30:13 --> Security Class Initialized
DEBUG - 2023-08-19 13:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:30:13 --> Input Class Initialized
INFO - 2023-08-19 13:30:13 --> Language Class Initialized
INFO - 2023-08-19 13:30:13 --> Loader Class Initialized
INFO - 2023-08-19 13:30:13 --> Helper loaded: url_helper
INFO - 2023-08-19 13:30:13 --> Helper loaded: file_helper
INFO - 2023-08-19 13:30:13 --> Database Driver Class Initialized
INFO - 2023-08-19 13:30:13 --> Email Class Initialized
DEBUG - 2023-08-19 13:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:30:13 --> Controller Class Initialized
INFO - 2023-08-19 13:30:13 --> Model "Home_model" initialized
INFO - 2023-08-19 13:30:13 --> Helper loaded: form_helper
INFO - 2023-08-19 13:30:13 --> Form Validation Class Initialized
INFO - 2023-08-19 13:30:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-19 13:30:14 --> Final output sent to browser
DEBUG - 2023-08-19 13:30:14 --> Total execution time: 0.1462
INFO - 2023-08-19 13:32:43 --> Config Class Initialized
INFO - 2023-08-19 13:32:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:43 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:43 --> URI Class Initialized
INFO - 2023-08-19 13:32:43 --> Router Class Initialized
INFO - 2023-08-19 13:32:43 --> Output Class Initialized
INFO - 2023-08-19 13:32:43 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:44 --> Input Class Initialized
INFO - 2023-08-19 13:32:44 --> Language Class Initialized
INFO - 2023-08-19 13:32:44 --> Loader Class Initialized
INFO - 2023-08-19 13:32:44 --> Helper loaded: url_helper
INFO - 2023-08-19 13:32:44 --> Helper loaded: file_helper
INFO - 2023-08-19 13:32:44 --> Database Driver Class Initialized
INFO - 2023-08-19 13:32:44 --> Email Class Initialized
DEBUG - 2023-08-19 13:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:32:44 --> Controller Class Initialized
INFO - 2023-08-19 13:32:44 --> Model "Home_model" initialized
INFO - 2023-08-19 13:32:44 --> Helper loaded: form_helper
INFO - 2023-08-19 13:32:44 --> Form Validation Class Initialized
INFO - 2023-08-19 13:32:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:32:44 --> Final output sent to browser
DEBUG - 2023-08-19 13:32:44 --> Total execution time: 0.5420
INFO - 2023-08-19 13:32:45 --> Config Class Initialized
INFO - 2023-08-19 13:32:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:45 --> URI Class Initialized
INFO - 2023-08-19 13:32:45 --> Router Class Initialized
INFO - 2023-08-19 13:32:45 --> Output Class Initialized
INFO - 2023-08-19 13:32:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:45 --> Input Class Initialized
INFO - 2023-08-19 13:32:45 --> Language Class Initialized
ERROR - 2023-08-19 13:32:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:32:45 --> Config Class Initialized
INFO - 2023-08-19 13:32:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:45 --> URI Class Initialized
INFO - 2023-08-19 13:32:45 --> Router Class Initialized
INFO - 2023-08-19 13:32:45 --> Output Class Initialized
INFO - 2023-08-19 13:32:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:45 --> Input Class Initialized
INFO - 2023-08-19 13:32:45 --> Language Class Initialized
ERROR - 2023-08-19 13:32:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:32:45 --> Config Class Initialized
INFO - 2023-08-19 13:32:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:45 --> URI Class Initialized
INFO - 2023-08-19 13:32:45 --> Router Class Initialized
INFO - 2023-08-19 13:32:45 --> Output Class Initialized
INFO - 2023-08-19 13:32:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:45 --> Input Class Initialized
INFO - 2023-08-19 13:32:45 --> Language Class Initialized
ERROR - 2023-08-19 13:32:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:32:45 --> Config Class Initialized
INFO - 2023-08-19 13:32:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:45 --> URI Class Initialized
INFO - 2023-08-19 13:32:45 --> Router Class Initialized
INFO - 2023-08-19 13:32:45 --> Output Class Initialized
INFO - 2023-08-19 13:32:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:45 --> Input Class Initialized
INFO - 2023-08-19 13:32:46 --> Language Class Initialized
ERROR - 2023-08-19 13:32:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:32:46 --> Config Class Initialized
INFO - 2023-08-19 13:32:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:46 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:46 --> URI Class Initialized
INFO - 2023-08-19 13:32:46 --> Router Class Initialized
INFO - 2023-08-19 13:32:46 --> Output Class Initialized
INFO - 2023-08-19 13:32:46 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:46 --> Input Class Initialized
INFO - 2023-08-19 13:32:46 --> Language Class Initialized
ERROR - 2023-08-19 13:32:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:32:46 --> Config Class Initialized
INFO - 2023-08-19 13:32:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:32:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:32:46 --> Utf8 Class Initialized
INFO - 2023-08-19 13:32:46 --> URI Class Initialized
INFO - 2023-08-19 13:32:46 --> Router Class Initialized
INFO - 2023-08-19 13:32:46 --> Output Class Initialized
INFO - 2023-08-19 13:32:46 --> Security Class Initialized
DEBUG - 2023-08-19 13:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:32:46 --> Input Class Initialized
INFO - 2023-08-19 13:32:46 --> Language Class Initialized
ERROR - 2023-08-19 13:32:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:33:43 --> Config Class Initialized
INFO - 2023-08-19 13:33:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:43 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:43 --> URI Class Initialized
INFO - 2023-08-19 13:33:43 --> Router Class Initialized
INFO - 2023-08-19 13:33:43 --> Output Class Initialized
INFO - 2023-08-19 13:33:43 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:43 --> Input Class Initialized
INFO - 2023-08-19 13:33:43 --> Language Class Initialized
INFO - 2023-08-19 13:33:43 --> Loader Class Initialized
INFO - 2023-08-19 13:33:43 --> Helper loaded: url_helper
INFO - 2023-08-19 13:33:43 --> Helper loaded: file_helper
INFO - 2023-08-19 13:33:43 --> Database Driver Class Initialized
INFO - 2023-08-19 13:33:43 --> Email Class Initialized
DEBUG - 2023-08-19 13:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:33:43 --> Controller Class Initialized
INFO - 2023-08-19 13:33:43 --> Model "Home_model" initialized
INFO - 2023-08-19 13:33:43 --> Helper loaded: form_helper
INFO - 2023-08-19 13:33:43 --> Form Validation Class Initialized
INFO - 2023-08-19 13:33:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:33:43 --> Final output sent to browser
DEBUG - 2023-08-19 13:33:43 --> Total execution time: 0.4705
INFO - 2023-08-19 13:33:44 --> Config Class Initialized
INFO - 2023-08-19 13:33:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:44 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:44 --> URI Class Initialized
INFO - 2023-08-19 13:33:44 --> Router Class Initialized
INFO - 2023-08-19 13:33:44 --> Output Class Initialized
INFO - 2023-08-19 13:33:44 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:44 --> Input Class Initialized
INFO - 2023-08-19 13:33:44 --> Language Class Initialized
ERROR - 2023-08-19 13:33:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:33:44 --> Config Class Initialized
INFO - 2023-08-19 13:33:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:44 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:44 --> URI Class Initialized
INFO - 2023-08-19 13:33:44 --> Router Class Initialized
INFO - 2023-08-19 13:33:44 --> Output Class Initialized
INFO - 2023-08-19 13:33:44 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:45 --> Input Class Initialized
INFO - 2023-08-19 13:33:45 --> Language Class Initialized
ERROR - 2023-08-19 13:33:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:33:45 --> Config Class Initialized
INFO - 2023-08-19 13:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:45 --> URI Class Initialized
INFO - 2023-08-19 13:33:45 --> Router Class Initialized
INFO - 2023-08-19 13:33:45 --> Output Class Initialized
INFO - 2023-08-19 13:33:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:45 --> Input Class Initialized
INFO - 2023-08-19 13:33:45 --> Language Class Initialized
ERROR - 2023-08-19 13:33:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:33:45 --> Config Class Initialized
INFO - 2023-08-19 13:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:45 --> URI Class Initialized
INFO - 2023-08-19 13:33:45 --> Router Class Initialized
INFO - 2023-08-19 13:33:45 --> Output Class Initialized
INFO - 2023-08-19 13:33:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:45 --> Input Class Initialized
INFO - 2023-08-19 13:33:45 --> Language Class Initialized
ERROR - 2023-08-19 13:33:45 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:33:45 --> Config Class Initialized
INFO - 2023-08-19 13:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:33:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:33:45 --> URI Class Initialized
INFO - 2023-08-19 13:33:45 --> Router Class Initialized
INFO - 2023-08-19 13:33:45 --> Output Class Initialized
INFO - 2023-08-19 13:33:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:33:46 --> Input Class Initialized
INFO - 2023-08-19 13:33:46 --> Language Class Initialized
ERROR - 2023-08-19 13:33:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:37:46 --> Config Class Initialized
INFO - 2023-08-19 13:37:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:46 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:46 --> URI Class Initialized
INFO - 2023-08-19 13:37:46 --> Router Class Initialized
INFO - 2023-08-19 13:37:46 --> Output Class Initialized
INFO - 2023-08-19 13:37:46 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:46 --> Input Class Initialized
INFO - 2023-08-19 13:37:46 --> Language Class Initialized
INFO - 2023-08-19 13:37:46 --> Loader Class Initialized
INFO - 2023-08-19 13:37:46 --> Helper loaded: url_helper
INFO - 2023-08-19 13:37:46 --> Helper loaded: file_helper
INFO - 2023-08-19 13:37:46 --> Database Driver Class Initialized
INFO - 2023-08-19 13:37:46 --> Email Class Initialized
DEBUG - 2023-08-19 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:37:46 --> Controller Class Initialized
INFO - 2023-08-19 13:37:46 --> Model "Training_model" initialized
INFO - 2023-08-19 13:37:46 --> Helper loaded: form_helper
INFO - 2023-08-19 13:37:46 --> Form Validation Class Initialized
INFO - 2023-08-19 13:37:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 13:37:47 --> Final output sent to browser
DEBUG - 2023-08-19 13:37:47 --> Total execution time: 0.8645
INFO - 2023-08-19 13:37:47 --> Config Class Initialized
INFO - 2023-08-19 13:37:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:47 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:47 --> URI Class Initialized
INFO - 2023-08-19 13:37:47 --> Router Class Initialized
INFO - 2023-08-19 13:37:47 --> Output Class Initialized
INFO - 2023-08-19 13:37:47 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:48 --> Input Class Initialized
INFO - 2023-08-19 13:37:48 --> Language Class Initialized
INFO - 2023-08-19 13:37:48 --> Loader Class Initialized
INFO - 2023-08-19 13:37:48 --> Helper loaded: url_helper
INFO - 2023-08-19 13:37:48 --> Helper loaded: file_helper
INFO - 2023-08-19 13:37:48 --> Database Driver Class Initialized
INFO - 2023-08-19 13:37:48 --> Email Class Initialized
DEBUG - 2023-08-19 13:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:37:48 --> Controller Class Initialized
INFO - 2023-08-19 13:37:48 --> Model "Home_model" initialized
INFO - 2023-08-19 13:37:48 --> Helper loaded: form_helper
INFO - 2023-08-19 13:37:48 --> Form Validation Class Initialized
INFO - 2023-08-19 13:37:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:37:48 --> Final output sent to browser
DEBUG - 2023-08-19 13:37:49 --> Total execution time: 1.0567
INFO - 2023-08-19 13:37:49 --> Config Class Initialized
INFO - 2023-08-19 13:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:49 --> URI Class Initialized
INFO - 2023-08-19 13:37:49 --> Router Class Initialized
INFO - 2023-08-19 13:37:49 --> Output Class Initialized
INFO - 2023-08-19 13:37:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:49 --> Input Class Initialized
INFO - 2023-08-19 13:37:49 --> Language Class Initialized
ERROR - 2023-08-19 13:37:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:37:49 --> Config Class Initialized
INFO - 2023-08-19 13:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:49 --> URI Class Initialized
INFO - 2023-08-19 13:37:49 --> Router Class Initialized
INFO - 2023-08-19 13:37:49 --> Output Class Initialized
INFO - 2023-08-19 13:37:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:49 --> Input Class Initialized
INFO - 2023-08-19 13:37:49 --> Language Class Initialized
ERROR - 2023-08-19 13:37:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:37:49 --> Config Class Initialized
INFO - 2023-08-19 13:37:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:50 --> URI Class Initialized
INFO - 2023-08-19 13:37:50 --> Router Class Initialized
INFO - 2023-08-19 13:37:50 --> Output Class Initialized
INFO - 2023-08-19 13:37:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:50 --> Input Class Initialized
INFO - 2023-08-19 13:37:50 --> Language Class Initialized
ERROR - 2023-08-19 13:37:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:37:50 --> Config Class Initialized
INFO - 2023-08-19 13:37:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:50 --> URI Class Initialized
INFO - 2023-08-19 13:37:50 --> Router Class Initialized
INFO - 2023-08-19 13:37:50 --> Output Class Initialized
INFO - 2023-08-19 13:37:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:50 --> Input Class Initialized
INFO - 2023-08-19 13:37:50 --> Language Class Initialized
ERROR - 2023-08-19 13:37:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:37:50 --> Config Class Initialized
INFO - 2023-08-19 13:37:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:37:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:37:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:37:50 --> URI Class Initialized
INFO - 2023-08-19 13:37:50 --> Router Class Initialized
INFO - 2023-08-19 13:37:50 --> Output Class Initialized
INFO - 2023-08-19 13:37:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:37:50 --> Input Class Initialized
INFO - 2023-08-19 13:37:50 --> Language Class Initialized
ERROR - 2023-08-19 13:37:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:22 --> Config Class Initialized
INFO - 2023-08-19 13:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:22 --> URI Class Initialized
INFO - 2023-08-19 13:38:22 --> Router Class Initialized
INFO - 2023-08-19 13:38:22 --> Output Class Initialized
INFO - 2023-08-19 13:38:22 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:22 --> Input Class Initialized
INFO - 2023-08-19 13:38:22 --> Language Class Initialized
INFO - 2023-08-19 13:38:22 --> Loader Class Initialized
INFO - 2023-08-19 13:38:22 --> Helper loaded: url_helper
INFO - 2023-08-19 13:38:22 --> Helper loaded: file_helper
INFO - 2023-08-19 13:38:22 --> Database Driver Class Initialized
INFO - 2023-08-19 13:38:22 --> Email Class Initialized
DEBUG - 2023-08-19 13:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:38:22 --> Controller Class Initialized
INFO - 2023-08-19 13:38:22 --> Model "Home_model" initialized
INFO - 2023-08-19 13:38:22 --> Helper loaded: form_helper
INFO - 2023-08-19 13:38:22 --> Form Validation Class Initialized
INFO - 2023-08-19 13:38:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:38:23 --> Final output sent to browser
DEBUG - 2023-08-19 13:38:23 --> Total execution time: 0.4702
INFO - 2023-08-19 13:38:23 --> Config Class Initialized
INFO - 2023-08-19 13:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:23 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:23 --> URI Class Initialized
INFO - 2023-08-19 13:38:23 --> Router Class Initialized
INFO - 2023-08-19 13:38:23 --> Output Class Initialized
INFO - 2023-08-19 13:38:23 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:23 --> Input Class Initialized
INFO - 2023-08-19 13:38:23 --> Language Class Initialized
ERROR - 2023-08-19 13:38:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:23 --> Config Class Initialized
INFO - 2023-08-19 13:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:23 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:23 --> URI Class Initialized
INFO - 2023-08-19 13:38:23 --> Router Class Initialized
INFO - 2023-08-19 13:38:23 --> Output Class Initialized
INFO - 2023-08-19 13:38:23 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:23 --> Input Class Initialized
INFO - 2023-08-19 13:38:23 --> Language Class Initialized
ERROR - 2023-08-19 13:38:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:23 --> Config Class Initialized
INFO - 2023-08-19 13:38:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:24 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:24 --> URI Class Initialized
INFO - 2023-08-19 13:38:24 --> Router Class Initialized
INFO - 2023-08-19 13:38:24 --> Output Class Initialized
INFO - 2023-08-19 13:38:24 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:24 --> Input Class Initialized
INFO - 2023-08-19 13:38:24 --> Language Class Initialized
ERROR - 2023-08-19 13:38:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:24 --> Config Class Initialized
INFO - 2023-08-19 13:38:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:24 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:24 --> URI Class Initialized
INFO - 2023-08-19 13:38:24 --> Router Class Initialized
INFO - 2023-08-19 13:38:24 --> Output Class Initialized
INFO - 2023-08-19 13:38:24 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:24 --> Input Class Initialized
INFO - 2023-08-19 13:38:24 --> Language Class Initialized
ERROR - 2023-08-19 13:38:24 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:25 --> Config Class Initialized
INFO - 2023-08-19 13:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:25 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:25 --> URI Class Initialized
INFO - 2023-08-19 13:38:25 --> Router Class Initialized
INFO - 2023-08-19 13:38:25 --> Output Class Initialized
INFO - 2023-08-19 13:38:25 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:25 --> Input Class Initialized
INFO - 2023-08-19 13:38:25 --> Language Class Initialized
ERROR - 2023-08-19 13:38:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:32 --> Config Class Initialized
INFO - 2023-08-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:32 --> URI Class Initialized
INFO - 2023-08-19 13:38:32 --> Router Class Initialized
INFO - 2023-08-19 13:38:32 --> Output Class Initialized
INFO - 2023-08-19 13:38:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:32 --> Input Class Initialized
INFO - 2023-08-19 13:38:32 --> Language Class Initialized
INFO - 2023-08-19 13:38:32 --> Loader Class Initialized
INFO - 2023-08-19 13:38:32 --> Helper loaded: url_helper
INFO - 2023-08-19 13:38:32 --> Helper loaded: file_helper
INFO - 2023-08-19 13:38:32 --> Database Driver Class Initialized
INFO - 2023-08-19 13:38:32 --> Email Class Initialized
DEBUG - 2023-08-19 13:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:38:32 --> Controller Class Initialized
INFO - 2023-08-19 13:38:32 --> Model "Home_model" initialized
INFO - 2023-08-19 13:38:32 --> Helper loaded: form_helper
INFO - 2023-08-19 13:38:32 --> Form Validation Class Initialized
INFO - 2023-08-19 13:38:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:38:32 --> Final output sent to browser
DEBUG - 2023-08-19 13:38:32 --> Total execution time: 0.1417
INFO - 2023-08-19 13:38:32 --> Config Class Initialized
INFO - 2023-08-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:32 --> URI Class Initialized
INFO - 2023-08-19 13:38:32 --> Router Class Initialized
INFO - 2023-08-19 13:38:32 --> Output Class Initialized
INFO - 2023-08-19 13:38:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:32 --> Input Class Initialized
INFO - 2023-08-19 13:38:32 --> Language Class Initialized
ERROR - 2023-08-19 13:38:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:32 --> Config Class Initialized
INFO - 2023-08-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:32 --> URI Class Initialized
INFO - 2023-08-19 13:38:32 --> Router Class Initialized
INFO - 2023-08-19 13:38:32 --> Output Class Initialized
INFO - 2023-08-19 13:38:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:32 --> Input Class Initialized
INFO - 2023-08-19 13:38:32 --> Language Class Initialized
ERROR - 2023-08-19 13:38:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:32 --> Config Class Initialized
INFO - 2023-08-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:32 --> URI Class Initialized
INFO - 2023-08-19 13:38:32 --> Router Class Initialized
INFO - 2023-08-19 13:38:32 --> Output Class Initialized
INFO - 2023-08-19 13:38:32 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:32 --> Input Class Initialized
INFO - 2023-08-19 13:38:32 --> Language Class Initialized
ERROR - 2023-08-19 13:38:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:32 --> Config Class Initialized
INFO - 2023-08-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:32 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:33 --> URI Class Initialized
INFO - 2023-08-19 13:38:33 --> Router Class Initialized
INFO - 2023-08-19 13:38:33 --> Output Class Initialized
INFO - 2023-08-19 13:38:33 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:33 --> Input Class Initialized
INFO - 2023-08-19 13:38:33 --> Language Class Initialized
ERROR - 2023-08-19 13:38:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:33 --> Config Class Initialized
INFO - 2023-08-19 13:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:33 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:33 --> URI Class Initialized
INFO - 2023-08-19 13:38:33 --> Router Class Initialized
INFO - 2023-08-19 13:38:33 --> Output Class Initialized
INFO - 2023-08-19 13:38:33 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:33 --> Input Class Initialized
INFO - 2023-08-19 13:38:33 --> Language Class Initialized
ERROR - 2023-08-19 13:38:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:33 --> Config Class Initialized
INFO - 2023-08-19 13:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:33 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:33 --> URI Class Initialized
INFO - 2023-08-19 13:38:33 --> Router Class Initialized
INFO - 2023-08-19 13:38:33 --> Output Class Initialized
INFO - 2023-08-19 13:38:33 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:33 --> Input Class Initialized
INFO - 2023-08-19 13:38:33 --> Language Class Initialized
ERROR - 2023-08-19 13:38:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:38 --> Config Class Initialized
INFO - 2023-08-19 13:38:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:38 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:38 --> URI Class Initialized
INFO - 2023-08-19 13:38:38 --> Router Class Initialized
INFO - 2023-08-19 13:38:38 --> Output Class Initialized
INFO - 2023-08-19 13:38:38 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:38 --> Input Class Initialized
INFO - 2023-08-19 13:38:38 --> Language Class Initialized
INFO - 2023-08-19 13:38:38 --> Loader Class Initialized
INFO - 2023-08-19 13:38:38 --> Helper loaded: url_helper
INFO - 2023-08-19 13:38:38 --> Helper loaded: file_helper
INFO - 2023-08-19 13:38:38 --> Database Driver Class Initialized
INFO - 2023-08-19 13:38:38 --> Email Class Initialized
DEBUG - 2023-08-19 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:38:38 --> Controller Class Initialized
INFO - 2023-08-19 13:38:38 --> Model "Home_model" initialized
INFO - 2023-08-19 13:38:38 --> Helper loaded: form_helper
INFO - 2023-08-19 13:38:38 --> Form Validation Class Initialized
INFO - 2023-08-19 13:38:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:38:39 --> Final output sent to browser
DEBUG - 2023-08-19 13:38:39 --> Total execution time: 0.1442
INFO - 2023-08-19 13:38:39 --> Config Class Initialized
INFO - 2023-08-19 13:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:39 --> URI Class Initialized
INFO - 2023-08-19 13:38:39 --> Router Class Initialized
INFO - 2023-08-19 13:38:39 --> Output Class Initialized
INFO - 2023-08-19 13:38:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:39 --> Input Class Initialized
INFO - 2023-08-19 13:38:39 --> Language Class Initialized
ERROR - 2023-08-19 13:38:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:39 --> Config Class Initialized
INFO - 2023-08-19 13:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:39 --> URI Class Initialized
INFO - 2023-08-19 13:38:39 --> Router Class Initialized
INFO - 2023-08-19 13:38:39 --> Output Class Initialized
INFO - 2023-08-19 13:38:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:39 --> Input Class Initialized
INFO - 2023-08-19 13:38:39 --> Language Class Initialized
ERROR - 2023-08-19 13:38:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:39 --> Config Class Initialized
INFO - 2023-08-19 13:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:39 --> URI Class Initialized
INFO - 2023-08-19 13:38:39 --> Router Class Initialized
INFO - 2023-08-19 13:38:39 --> Output Class Initialized
INFO - 2023-08-19 13:38:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:39 --> Input Class Initialized
INFO - 2023-08-19 13:38:39 --> Language Class Initialized
ERROR - 2023-08-19 13:38:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:39 --> Config Class Initialized
INFO - 2023-08-19 13:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:39 --> URI Class Initialized
INFO - 2023-08-19 13:38:39 --> Router Class Initialized
INFO - 2023-08-19 13:38:39 --> Output Class Initialized
INFO - 2023-08-19 13:38:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:39 --> Input Class Initialized
INFO - 2023-08-19 13:38:39 --> Language Class Initialized
ERROR - 2023-08-19 13:38:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:39 --> Config Class Initialized
INFO - 2023-08-19 13:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:39 --> URI Class Initialized
INFO - 2023-08-19 13:38:39 --> Router Class Initialized
INFO - 2023-08-19 13:38:39 --> Output Class Initialized
INFO - 2023-08-19 13:38:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:39 --> Input Class Initialized
INFO - 2023-08-19 13:38:39 --> Language Class Initialized
ERROR - 2023-08-19 13:38:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:46 --> Config Class Initialized
INFO - 2023-08-19 13:38:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:46 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:46 --> URI Class Initialized
INFO - 2023-08-19 13:38:46 --> Router Class Initialized
INFO - 2023-08-19 13:38:46 --> Output Class Initialized
INFO - 2023-08-19 13:38:46 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:46 --> Input Class Initialized
INFO - 2023-08-19 13:38:46 --> Language Class Initialized
INFO - 2023-08-19 13:38:47 --> Loader Class Initialized
INFO - 2023-08-19 13:38:47 --> Helper loaded: url_helper
INFO - 2023-08-19 13:38:47 --> Helper loaded: file_helper
INFO - 2023-08-19 13:38:47 --> Database Driver Class Initialized
INFO - 2023-08-19 13:38:47 --> Email Class Initialized
DEBUG - 2023-08-19 13:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:38:47 --> Controller Class Initialized
INFO - 2023-08-19 13:38:47 --> Model "Home_model" initialized
INFO - 2023-08-19 13:38:47 --> Helper loaded: form_helper
INFO - 2023-08-19 13:38:47 --> Form Validation Class Initialized
INFO - 2023-08-19 13:38:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:38:47 --> Final output sent to browser
DEBUG - 2023-08-19 13:38:47 --> Total execution time: 1.0278
INFO - 2023-08-19 13:38:48 --> Config Class Initialized
INFO - 2023-08-19 13:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:48 --> URI Class Initialized
INFO - 2023-08-19 13:38:48 --> Router Class Initialized
INFO - 2023-08-19 13:38:48 --> Output Class Initialized
INFO - 2023-08-19 13:38:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:48 --> Input Class Initialized
INFO - 2023-08-19 13:38:48 --> Language Class Initialized
ERROR - 2023-08-19 13:38:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:48 --> Config Class Initialized
INFO - 2023-08-19 13:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:48 --> URI Class Initialized
INFO - 2023-08-19 13:38:48 --> Router Class Initialized
INFO - 2023-08-19 13:38:48 --> Output Class Initialized
INFO - 2023-08-19 13:38:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:48 --> Input Class Initialized
INFO - 2023-08-19 13:38:48 --> Language Class Initialized
ERROR - 2023-08-19 13:38:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:48 --> Config Class Initialized
INFO - 2023-08-19 13:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:48 --> URI Class Initialized
INFO - 2023-08-19 13:38:48 --> Router Class Initialized
INFO - 2023-08-19 13:38:48 --> Output Class Initialized
INFO - 2023-08-19 13:38:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:48 --> Input Class Initialized
INFO - 2023-08-19 13:38:48 --> Language Class Initialized
ERROR - 2023-08-19 13:38:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:48 --> Config Class Initialized
INFO - 2023-08-19 13:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:48 --> URI Class Initialized
INFO - 2023-08-19 13:38:48 --> Router Class Initialized
INFO - 2023-08-19 13:38:48 --> Output Class Initialized
INFO - 2023-08-19 13:38:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:48 --> Input Class Initialized
INFO - 2023-08-19 13:38:48 --> Language Class Initialized
ERROR - 2023-08-19 13:38:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:38:48 --> Config Class Initialized
INFO - 2023-08-19 13:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:38:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:38:48 --> URI Class Initialized
INFO - 2023-08-19 13:38:48 --> Router Class Initialized
INFO - 2023-08-19 13:38:48 --> Output Class Initialized
INFO - 2023-08-19 13:38:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:38:48 --> Input Class Initialized
INFO - 2023-08-19 13:38:48 --> Language Class Initialized
ERROR - 2023-08-19 13:38:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:38 --> Config Class Initialized
INFO - 2023-08-19 13:39:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:38 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:38 --> URI Class Initialized
INFO - 2023-08-19 13:39:38 --> Router Class Initialized
INFO - 2023-08-19 13:39:38 --> Output Class Initialized
INFO - 2023-08-19 13:39:38 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:38 --> Input Class Initialized
INFO - 2023-08-19 13:39:38 --> Language Class Initialized
INFO - 2023-08-19 13:39:38 --> Loader Class Initialized
INFO - 2023-08-19 13:39:38 --> Helper loaded: url_helper
INFO - 2023-08-19 13:39:38 --> Helper loaded: file_helper
INFO - 2023-08-19 13:39:38 --> Database Driver Class Initialized
INFO - 2023-08-19 13:39:38 --> Email Class Initialized
DEBUG - 2023-08-19 13:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:39:38 --> Controller Class Initialized
INFO - 2023-08-19 13:39:38 --> Model "Home_model" initialized
INFO - 2023-08-19 13:39:38 --> Helper loaded: form_helper
INFO - 2023-08-19 13:39:38 --> Form Validation Class Initialized
INFO - 2023-08-19 13:39:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:39:38 --> Final output sent to browser
DEBUG - 2023-08-19 13:39:38 --> Total execution time: 0.4974
INFO - 2023-08-19 13:39:39 --> Config Class Initialized
INFO - 2023-08-19 13:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:39 --> URI Class Initialized
INFO - 2023-08-19 13:39:39 --> Router Class Initialized
INFO - 2023-08-19 13:39:39 --> Output Class Initialized
INFO - 2023-08-19 13:39:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:39 --> Input Class Initialized
INFO - 2023-08-19 13:39:39 --> Language Class Initialized
ERROR - 2023-08-19 13:39:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:39 --> Config Class Initialized
INFO - 2023-08-19 13:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:39 --> URI Class Initialized
INFO - 2023-08-19 13:39:39 --> Router Class Initialized
INFO - 2023-08-19 13:39:39 --> Output Class Initialized
INFO - 2023-08-19 13:39:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:39 --> Input Class Initialized
INFO - 2023-08-19 13:39:39 --> Language Class Initialized
ERROR - 2023-08-19 13:39:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:39 --> Config Class Initialized
INFO - 2023-08-19 13:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:39 --> URI Class Initialized
INFO - 2023-08-19 13:39:39 --> Router Class Initialized
INFO - 2023-08-19 13:39:39 --> Output Class Initialized
INFO - 2023-08-19 13:39:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:39 --> Input Class Initialized
INFO - 2023-08-19 13:39:39 --> Language Class Initialized
ERROR - 2023-08-19 13:39:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:39 --> Config Class Initialized
INFO - 2023-08-19 13:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:39 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:39 --> URI Class Initialized
INFO - 2023-08-19 13:39:39 --> Router Class Initialized
INFO - 2023-08-19 13:39:39 --> Output Class Initialized
INFO - 2023-08-19 13:39:39 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:39 --> Input Class Initialized
INFO - 2023-08-19 13:39:39 --> Language Class Initialized
ERROR - 2023-08-19 13:39:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:39 --> Config Class Initialized
INFO - 2023-08-19 13:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:40 --> URI Class Initialized
INFO - 2023-08-19 13:39:40 --> Router Class Initialized
INFO - 2023-08-19 13:39:40 --> Output Class Initialized
INFO - 2023-08-19 13:39:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:40 --> Input Class Initialized
INFO - 2023-08-19 13:39:40 --> Language Class Initialized
ERROR - 2023-08-19 13:39:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:54 --> Config Class Initialized
INFO - 2023-08-19 13:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:54 --> URI Class Initialized
INFO - 2023-08-19 13:39:54 --> Router Class Initialized
INFO - 2023-08-19 13:39:54 --> Output Class Initialized
INFO - 2023-08-19 13:39:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:54 --> Input Class Initialized
INFO - 2023-08-19 13:39:54 --> Language Class Initialized
INFO - 2023-08-19 13:39:54 --> Loader Class Initialized
INFO - 2023-08-19 13:39:54 --> Helper loaded: url_helper
INFO - 2023-08-19 13:39:54 --> Helper loaded: file_helper
INFO - 2023-08-19 13:39:54 --> Database Driver Class Initialized
INFO - 2023-08-19 13:39:54 --> Email Class Initialized
DEBUG - 2023-08-19 13:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:39:54 --> Controller Class Initialized
INFO - 2023-08-19 13:39:54 --> Model "Home_model" initialized
INFO - 2023-08-19 13:39:54 --> Helper loaded: form_helper
INFO - 2023-08-19 13:39:54 --> Form Validation Class Initialized
INFO - 2023-08-19 13:39:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:39:54 --> Final output sent to browser
DEBUG - 2023-08-19 13:39:54 --> Total execution time: 0.4542
INFO - 2023-08-19 13:39:55 --> Config Class Initialized
INFO - 2023-08-19 13:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:55 --> URI Class Initialized
INFO - 2023-08-19 13:39:55 --> Router Class Initialized
INFO - 2023-08-19 13:39:55 --> Output Class Initialized
INFO - 2023-08-19 13:39:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:55 --> Input Class Initialized
INFO - 2023-08-19 13:39:55 --> Language Class Initialized
ERROR - 2023-08-19 13:39:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:55 --> Config Class Initialized
INFO - 2023-08-19 13:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:55 --> URI Class Initialized
INFO - 2023-08-19 13:39:55 --> Router Class Initialized
INFO - 2023-08-19 13:39:55 --> Output Class Initialized
INFO - 2023-08-19 13:39:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:55 --> Input Class Initialized
INFO - 2023-08-19 13:39:55 --> Language Class Initialized
ERROR - 2023-08-19 13:39:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:55 --> Config Class Initialized
INFO - 2023-08-19 13:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:55 --> URI Class Initialized
INFO - 2023-08-19 13:39:55 --> Router Class Initialized
INFO - 2023-08-19 13:39:55 --> Output Class Initialized
INFO - 2023-08-19 13:39:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:55 --> Input Class Initialized
INFO - 2023-08-19 13:39:55 --> Language Class Initialized
ERROR - 2023-08-19 13:39:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:56 --> Config Class Initialized
INFO - 2023-08-19 13:39:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:56 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:56 --> URI Class Initialized
INFO - 2023-08-19 13:39:56 --> Router Class Initialized
INFO - 2023-08-19 13:39:56 --> Output Class Initialized
INFO - 2023-08-19 13:39:56 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:56 --> Input Class Initialized
INFO - 2023-08-19 13:39:56 --> Language Class Initialized
ERROR - 2023-08-19 13:39:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:39:56 --> Config Class Initialized
INFO - 2023-08-19 13:39:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:39:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:39:56 --> Utf8 Class Initialized
INFO - 2023-08-19 13:39:56 --> URI Class Initialized
INFO - 2023-08-19 13:39:56 --> Router Class Initialized
INFO - 2023-08-19 13:39:56 --> Output Class Initialized
INFO - 2023-08-19 13:39:56 --> Security Class Initialized
DEBUG - 2023-08-19 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:39:56 --> Input Class Initialized
INFO - 2023-08-19 13:39:56 --> Language Class Initialized
ERROR - 2023-08-19 13:39:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:13 --> Config Class Initialized
INFO - 2023-08-19 13:40:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:13 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:13 --> URI Class Initialized
INFO - 2023-08-19 13:40:14 --> Router Class Initialized
INFO - 2023-08-19 13:40:14 --> Output Class Initialized
INFO - 2023-08-19 13:40:14 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:14 --> Input Class Initialized
INFO - 2023-08-19 13:40:14 --> Language Class Initialized
INFO - 2023-08-19 13:40:14 --> Loader Class Initialized
INFO - 2023-08-19 13:40:14 --> Helper loaded: url_helper
INFO - 2023-08-19 13:40:14 --> Helper loaded: file_helper
INFO - 2023-08-19 13:40:14 --> Database Driver Class Initialized
INFO - 2023-08-19 13:40:14 --> Email Class Initialized
DEBUG - 2023-08-19 13:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:40:14 --> Controller Class Initialized
INFO - 2023-08-19 13:40:14 --> Model "Home_model" initialized
INFO - 2023-08-19 13:40:14 --> Helper loaded: form_helper
INFO - 2023-08-19 13:40:14 --> Form Validation Class Initialized
INFO - 2023-08-19 13:40:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:40:14 --> Final output sent to browser
DEBUG - 2023-08-19 13:40:14 --> Total execution time: 0.6107
INFO - 2023-08-19 13:40:14 --> Config Class Initialized
INFO - 2023-08-19 13:40:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:14 --> URI Class Initialized
INFO - 2023-08-19 13:40:14 --> Router Class Initialized
INFO - 2023-08-19 13:40:14 --> Output Class Initialized
INFO - 2023-08-19 13:40:14 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:14 --> Input Class Initialized
INFO - 2023-08-19 13:40:14 --> Language Class Initialized
ERROR - 2023-08-19 13:40:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:15 --> Config Class Initialized
INFO - 2023-08-19 13:40:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:15 --> URI Class Initialized
INFO - 2023-08-19 13:40:15 --> Router Class Initialized
INFO - 2023-08-19 13:40:15 --> Output Class Initialized
INFO - 2023-08-19 13:40:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:15 --> Input Class Initialized
INFO - 2023-08-19 13:40:15 --> Language Class Initialized
ERROR - 2023-08-19 13:40:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:15 --> Config Class Initialized
INFO - 2023-08-19 13:40:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:15 --> URI Class Initialized
INFO - 2023-08-19 13:40:15 --> Router Class Initialized
INFO - 2023-08-19 13:40:15 --> Output Class Initialized
INFO - 2023-08-19 13:40:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:15 --> Input Class Initialized
INFO - 2023-08-19 13:40:15 --> Language Class Initialized
ERROR - 2023-08-19 13:40:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:15 --> Config Class Initialized
INFO - 2023-08-19 13:40:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:15 --> URI Class Initialized
INFO - 2023-08-19 13:40:15 --> Router Class Initialized
INFO - 2023-08-19 13:40:15 --> Output Class Initialized
INFO - 2023-08-19 13:40:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:15 --> Input Class Initialized
INFO - 2023-08-19 13:40:15 --> Language Class Initialized
ERROR - 2023-08-19 13:40:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:15 --> Config Class Initialized
INFO - 2023-08-19 13:40:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:15 --> URI Class Initialized
INFO - 2023-08-19 13:40:15 --> Router Class Initialized
INFO - 2023-08-19 13:40:15 --> Output Class Initialized
INFO - 2023-08-19 13:40:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:15 --> Input Class Initialized
INFO - 2023-08-19 13:40:15 --> Language Class Initialized
ERROR - 2023-08-19 13:40:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:31 --> Config Class Initialized
INFO - 2023-08-19 13:40:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:31 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:31 --> URI Class Initialized
INFO - 2023-08-19 13:40:31 --> Router Class Initialized
INFO - 2023-08-19 13:40:31 --> Output Class Initialized
INFO - 2023-08-19 13:40:31 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:31 --> Input Class Initialized
INFO - 2023-08-19 13:40:31 --> Language Class Initialized
INFO - 2023-08-19 13:40:31 --> Loader Class Initialized
INFO - 2023-08-19 13:40:31 --> Helper loaded: url_helper
INFO - 2023-08-19 13:40:31 --> Helper loaded: file_helper
INFO - 2023-08-19 13:40:31 --> Database Driver Class Initialized
INFO - 2023-08-19 13:40:31 --> Email Class Initialized
DEBUG - 2023-08-19 13:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:40:32 --> Controller Class Initialized
INFO - 2023-08-19 13:40:32 --> Model "Home_model" initialized
INFO - 2023-08-19 13:40:32 --> Helper loaded: form_helper
INFO - 2023-08-19 13:40:32 --> Form Validation Class Initialized
INFO - 2023-08-19 13:40:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:40:32 --> Final output sent to browser
DEBUG - 2023-08-19 13:40:32 --> Total execution time: 1.0868
INFO - 2023-08-19 13:40:36 --> Config Class Initialized
INFO - 2023-08-19 13:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:36 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:36 --> URI Class Initialized
INFO - 2023-08-19 13:40:36 --> Router Class Initialized
INFO - 2023-08-19 13:40:36 --> Output Class Initialized
INFO - 2023-08-19 13:40:36 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:36 --> Input Class Initialized
INFO - 2023-08-19 13:40:36 --> Language Class Initialized
ERROR - 2023-08-19 13:40:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:36 --> Config Class Initialized
INFO - 2023-08-19 13:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:36 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:36 --> URI Class Initialized
INFO - 2023-08-19 13:40:36 --> Router Class Initialized
INFO - 2023-08-19 13:40:36 --> Output Class Initialized
INFO - 2023-08-19 13:40:36 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:36 --> Input Class Initialized
INFO - 2023-08-19 13:40:36 --> Language Class Initialized
ERROR - 2023-08-19 13:40:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:36 --> Config Class Initialized
INFO - 2023-08-19 13:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:36 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:36 --> URI Class Initialized
INFO - 2023-08-19 13:40:36 --> Router Class Initialized
INFO - 2023-08-19 13:40:36 --> Output Class Initialized
INFO - 2023-08-19 13:40:36 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:36 --> Input Class Initialized
INFO - 2023-08-19 13:40:36 --> Language Class Initialized
ERROR - 2023-08-19 13:40:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:37 --> Config Class Initialized
INFO - 2023-08-19 13:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:37 --> URI Class Initialized
INFO - 2023-08-19 13:40:37 --> Router Class Initialized
INFO - 2023-08-19 13:40:37 --> Output Class Initialized
INFO - 2023-08-19 13:40:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:37 --> Input Class Initialized
INFO - 2023-08-19 13:40:37 --> Language Class Initialized
ERROR - 2023-08-19 13:40:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:37 --> Config Class Initialized
INFO - 2023-08-19 13:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:37 --> URI Class Initialized
INFO - 2023-08-19 13:40:37 --> Router Class Initialized
INFO - 2023-08-19 13:40:37 --> Output Class Initialized
INFO - 2023-08-19 13:40:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:37 --> Input Class Initialized
INFO - 2023-08-19 13:40:37 --> Language Class Initialized
ERROR - 2023-08-19 13:40:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:37 --> Config Class Initialized
INFO - 2023-08-19 13:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:37 --> URI Class Initialized
INFO - 2023-08-19 13:40:37 --> Router Class Initialized
INFO - 2023-08-19 13:40:37 --> Output Class Initialized
INFO - 2023-08-19 13:40:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:37 --> Input Class Initialized
INFO - 2023-08-19 13:40:37 --> Language Class Initialized
ERROR - 2023-08-19 13:40:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:37 --> Config Class Initialized
INFO - 2023-08-19 13:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:37 --> URI Class Initialized
INFO - 2023-08-19 13:40:37 --> Router Class Initialized
INFO - 2023-08-19 13:40:37 --> Output Class Initialized
INFO - 2023-08-19 13:40:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:37 --> Input Class Initialized
INFO - 2023-08-19 13:40:37 --> Language Class Initialized
ERROR - 2023-08-19 13:40:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:40:37 --> Config Class Initialized
INFO - 2023-08-19 13:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:40:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:40:37 --> URI Class Initialized
INFO - 2023-08-19 13:40:37 --> Router Class Initialized
INFO - 2023-08-19 13:40:37 --> Output Class Initialized
INFO - 2023-08-19 13:40:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:40:37 --> Input Class Initialized
INFO - 2023-08-19 13:40:37 --> Language Class Initialized
ERROR - 2023-08-19 13:40:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:07 --> Config Class Initialized
INFO - 2023-08-19 13:41:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:07 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:07 --> URI Class Initialized
INFO - 2023-08-19 13:41:07 --> Router Class Initialized
INFO - 2023-08-19 13:41:07 --> Output Class Initialized
INFO - 2023-08-19 13:41:07 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:07 --> Input Class Initialized
INFO - 2023-08-19 13:41:07 --> Language Class Initialized
INFO - 2023-08-19 13:41:07 --> Loader Class Initialized
INFO - 2023-08-19 13:41:07 --> Helper loaded: url_helper
INFO - 2023-08-19 13:41:07 --> Helper loaded: file_helper
INFO - 2023-08-19 13:41:07 --> Database Driver Class Initialized
INFO - 2023-08-19 13:41:07 --> Email Class Initialized
DEBUG - 2023-08-19 13:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:41:07 --> Controller Class Initialized
INFO - 2023-08-19 13:41:07 --> Model "Home_model" initialized
INFO - 2023-08-19 13:41:07 --> Helper loaded: form_helper
INFO - 2023-08-19 13:41:07 --> Form Validation Class Initialized
INFO - 2023-08-19 13:41:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:41:07 --> Final output sent to browser
DEBUG - 2023-08-19 13:41:07 --> Total execution time: 0.4996
INFO - 2023-08-19 13:41:07 --> Config Class Initialized
INFO - 2023-08-19 13:41:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:07 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:07 --> URI Class Initialized
INFO - 2023-08-19 13:41:07 --> Router Class Initialized
INFO - 2023-08-19 13:41:07 --> Output Class Initialized
INFO - 2023-08-19 13:41:07 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:07 --> Input Class Initialized
INFO - 2023-08-19 13:41:07 --> Language Class Initialized
ERROR - 2023-08-19 13:41:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:08 --> Config Class Initialized
INFO - 2023-08-19 13:41:08 --> Config Class Initialized
INFO - 2023-08-19 13:41:08 --> Config Class Initialized
INFO - 2023-08-19 13:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:08 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:08 --> URI Class Initialized
INFO - 2023-08-19 13:41:08 --> Router Class Initialized
INFO - 2023-08-19 13:41:08 --> Output Class Initialized
INFO - 2023-08-19 13:41:08 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:08 --> Input Class Initialized
INFO - 2023-08-19 13:41:08 --> Language Class Initialized
ERROR - 2023-08-19 13:41:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:08 --> Config Class Initialized
INFO - 2023-08-19 13:41:08 --> Hooks Class Initialized
INFO - 2023-08-19 13:41:08 --> Hooks Class Initialized
INFO - 2023-08-19 13:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:08 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:08 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:08 --> URI Class Initialized
INFO - 2023-08-19 13:41:08 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:08 --> URI Class Initialized
INFO - 2023-08-19 13:41:08 --> Router Class Initialized
INFO - 2023-08-19 13:41:08 --> Router Class Initialized
INFO - 2023-08-19 13:41:08 --> URI Class Initialized
INFO - 2023-08-19 13:41:08 --> Output Class Initialized
INFO - 2023-08-19 13:41:08 --> Router Class Initialized
INFO - 2023-08-19 13:41:08 --> Output Class Initialized
INFO - 2023-08-19 13:41:08 --> Output Class Initialized
INFO - 2023-08-19 13:41:08 --> Security Class Initialized
INFO - 2023-08-19 13:41:08 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:08 --> Security Class Initialized
INFO - 2023-08-19 13:41:08 --> Input Class Initialized
DEBUG - 2023-08-19 13:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:08 --> Input Class Initialized
INFO - 2023-08-19 13:41:08 --> Language Class Initialized
INFO - 2023-08-19 13:41:08 --> Input Class Initialized
ERROR - 2023-08-19 13:41:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:08 --> Language Class Initialized
INFO - 2023-08-19 13:41:08 --> Language Class Initialized
ERROR - 2023-08-19 13:41:08 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 13:41:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:48 --> Config Class Initialized
INFO - 2023-08-19 13:41:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:49 --> URI Class Initialized
INFO - 2023-08-19 13:41:49 --> Router Class Initialized
INFO - 2023-08-19 13:41:49 --> Output Class Initialized
INFO - 2023-08-19 13:41:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:49 --> Input Class Initialized
INFO - 2023-08-19 13:41:49 --> Language Class Initialized
INFO - 2023-08-19 13:41:49 --> Loader Class Initialized
INFO - 2023-08-19 13:41:49 --> Helper loaded: url_helper
INFO - 2023-08-19 13:41:49 --> Helper loaded: file_helper
INFO - 2023-08-19 13:41:49 --> Database Driver Class Initialized
INFO - 2023-08-19 13:41:49 --> Email Class Initialized
DEBUG - 2023-08-19 13:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:41:49 --> Controller Class Initialized
INFO - 2023-08-19 13:41:49 --> Model "Home_model" initialized
INFO - 2023-08-19 13:41:49 --> Helper loaded: form_helper
INFO - 2023-08-19 13:41:49 --> Form Validation Class Initialized
INFO - 2023-08-19 13:41:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:41:49 --> Final output sent to browser
DEBUG - 2023-08-19 13:41:49 --> Total execution time: 0.5875
INFO - 2023-08-19 13:41:50 --> Config Class Initialized
INFO - 2023-08-19 13:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:50 --> Config Class Initialized
INFO - 2023-08-19 13:41:50 --> Hooks Class Initialized
INFO - 2023-08-19 13:41:50 --> Config Class Initialized
DEBUG - 2023-08-19 13:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:50 --> Hooks Class Initialized
INFO - 2023-08-19 13:41:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:50 --> Config Class Initialized
INFO - 2023-08-19 13:41:50 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:50 --> URI Class Initialized
INFO - 2023-08-19 13:41:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:50 --> URI Class Initialized
INFO - 2023-08-19 13:41:50 --> Hooks Class Initialized
INFO - 2023-08-19 13:41:50 --> Router Class Initialized
INFO - 2023-08-19 13:41:50 --> Config Class Initialized
INFO - 2023-08-19 13:41:50 --> URI Class Initialized
INFO - 2023-08-19 13:41:50 --> Output Class Initialized
INFO - 2023-08-19 13:41:50 --> Router Class Initialized
DEBUG - 2023-08-19 13:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:41:50 --> Router Class Initialized
INFO - 2023-08-19 13:41:50 --> Output Class Initialized
INFO - 2023-08-19 13:41:50 --> Security Class Initialized
INFO - 2023-08-19 13:41:50 --> Output Class Initialized
INFO - 2023-08-19 13:41:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:50 --> Security Class Initialized
INFO - 2023-08-19 13:41:50 --> Security Class Initialized
DEBUG - 2023-08-19 13:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:50 --> Input Class Initialized
INFO - 2023-08-19 13:41:50 --> Language Class Initialized
ERROR - 2023-08-19 13:41:50 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:41:50 --> URI Class Initialized
INFO - 2023-08-19 13:41:50 --> Router Class Initialized
DEBUG - 2023-08-19 13:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:50 --> Utf8 Class Initialized
INFO - 2023-08-19 13:41:51 --> Input Class Initialized
DEBUG - 2023-08-19 13:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:51 --> URI Class Initialized
INFO - 2023-08-19 13:41:51 --> Output Class Initialized
INFO - 2023-08-19 13:41:51 --> Input Class Initialized
INFO - 2023-08-19 13:41:51 --> Language Class Initialized
INFO - 2023-08-19 13:41:51 --> Security Class Initialized
INFO - 2023-08-19 13:41:51 --> Router Class Initialized
INFO - 2023-08-19 13:41:51 --> Output Class Initialized
INFO - 2023-08-19 13:41:51 --> Language Class Initialized
INFO - 2023-08-19 13:41:51 --> Security Class Initialized
ERROR - 2023-08-19 13:41:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 13:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 13:41:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 13:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:41:51 --> Input Class Initialized
INFO - 2023-08-19 13:41:51 --> Input Class Initialized
INFO - 2023-08-19 13:41:51 --> Language Class Initialized
INFO - 2023-08-19 13:41:51 --> Language Class Initialized
ERROR - 2023-08-19 13:41:51 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 13:41:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:42:49 --> Config Class Initialized
INFO - 2023-08-19 13:42:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:42:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:49 --> URI Class Initialized
INFO - 2023-08-19 13:42:49 --> Router Class Initialized
INFO - 2023-08-19 13:42:49 --> Output Class Initialized
INFO - 2023-08-19 13:42:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:42:49 --> Input Class Initialized
INFO - 2023-08-19 13:42:49 --> Language Class Initialized
INFO - 2023-08-19 13:42:49 --> Loader Class Initialized
INFO - 2023-08-19 13:42:49 --> Helper loaded: url_helper
INFO - 2023-08-19 13:42:49 --> Helper loaded: file_helper
INFO - 2023-08-19 13:42:50 --> Database Driver Class Initialized
INFO - 2023-08-19 13:42:50 --> Email Class Initialized
DEBUG - 2023-08-19 13:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:42:50 --> Controller Class Initialized
INFO - 2023-08-19 13:42:50 --> Model "Home_model" initialized
INFO - 2023-08-19 13:42:50 --> Helper loaded: form_helper
INFO - 2023-08-19 13:42:50 --> Form Validation Class Initialized
INFO - 2023-08-19 13:42:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:42:50 --> Final output sent to browser
DEBUG - 2023-08-19 13:42:50 --> Total execution time: 0.7013
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:51 --> URI Class Initialized
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:51 --> Router Class Initialized
INFO - 2023-08-19 13:42:51 --> URI Class Initialized
INFO - 2023-08-19 13:42:51 --> Output Class Initialized
INFO - 2023-08-19 13:42:51 --> Router Class Initialized
INFO - 2023-08-19 13:42:51 --> Output Class Initialized
INFO - 2023-08-19 13:42:51 --> Security Class Initialized
INFO - 2023-08-19 13:42:51 --> Security Class Initialized
DEBUG - 2023-08-19 13:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:42:51 --> Input Class Initialized
INFO - 2023-08-19 13:42:51 --> Input Class Initialized
INFO - 2023-08-19 13:42:51 --> Language Class Initialized
INFO - 2023-08-19 13:42:51 --> Language Class Initialized
ERROR - 2023-08-19 13:42:51 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 13:42:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:51 --> Config Class Initialized
INFO - 2023-08-19 13:42:51 --> URI Class Initialized
INFO - 2023-08-19 13:42:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:42:51 --> URI Class Initialized
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:51 --> Router Class Initialized
DEBUG - 2023-08-19 13:42:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:42:51 --> Router Class Initialized
INFO - 2023-08-19 13:42:51 --> Output Class Initialized
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:51 --> Security Class Initialized
INFO - 2023-08-19 13:42:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:42:51 --> Output Class Initialized
DEBUG - 2023-08-19 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:42:52 --> Security Class Initialized
INFO - 2023-08-19 13:42:52 --> URI Class Initialized
INFO - 2023-08-19 13:42:52 --> URI Class Initialized
INFO - 2023-08-19 13:42:52 --> Router Class Initialized
DEBUG - 2023-08-19 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:42:52 --> Input Class Initialized
INFO - 2023-08-19 13:42:52 --> Router Class Initialized
INFO - 2023-08-19 13:42:52 --> Input Class Initialized
INFO - 2023-08-19 13:42:52 --> Output Class Initialized
INFO - 2023-08-19 13:42:52 --> Output Class Initialized
INFO - 2023-08-19 13:42:52 --> Language Class Initialized
INFO - 2023-08-19 13:42:52 --> Language Class Initialized
INFO - 2023-08-19 13:42:52 --> Security Class Initialized
ERROR - 2023-08-19 13:42:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:42:52 --> Security Class Initialized
ERROR - 2023-08-19 13:42:52 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 13:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:42:52 --> Input Class Initialized
INFO - 2023-08-19 13:42:52 --> Input Class Initialized
INFO - 2023-08-19 13:42:52 --> Language Class Initialized
ERROR - 2023-08-19 13:42:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:42:52 --> Language Class Initialized
ERROR - 2023-08-19 13:42:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:43:13 --> Config Class Initialized
INFO - 2023-08-19 13:43:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:43:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:43:13 --> Utf8 Class Initialized
INFO - 2023-08-19 13:43:13 --> URI Class Initialized
INFO - 2023-08-19 13:43:13 --> Router Class Initialized
INFO - 2023-08-19 13:43:13 --> Output Class Initialized
INFO - 2023-08-19 13:43:13 --> Security Class Initialized
DEBUG - 2023-08-19 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:43:13 --> Input Class Initialized
INFO - 2023-08-19 13:43:13 --> Language Class Initialized
INFO - 2023-08-19 13:43:13 --> Loader Class Initialized
INFO - 2023-08-19 13:43:13 --> Helper loaded: url_helper
INFO - 2023-08-19 13:43:13 --> Helper loaded: file_helper
INFO - 2023-08-19 13:43:13 --> Database Driver Class Initialized
INFO - 2023-08-19 13:43:13 --> Email Class Initialized
DEBUG - 2023-08-19 13:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:43:13 --> Controller Class Initialized
INFO - 2023-08-19 13:43:13 --> Model "Home_model" initialized
INFO - 2023-08-19 13:43:13 --> Helper loaded: form_helper
INFO - 2023-08-19 13:43:13 --> Form Validation Class Initialized
INFO - 2023-08-19 13:43:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:43:13 --> Final output sent to browser
DEBUG - 2023-08-19 13:43:13 --> Total execution time: 0.4303
INFO - 2023-08-19 13:43:14 --> Config Class Initialized
INFO - 2023-08-19 13:43:14 --> Config Class Initialized
INFO - 2023-08-19 13:43:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:43:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:43:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:43:14 --> URI Class Initialized
INFO - 2023-08-19 13:43:14 --> Router Class Initialized
INFO - 2023-08-19 13:43:14 --> Output Class Initialized
INFO - 2023-08-19 13:43:14 --> Security Class Initialized
DEBUG - 2023-08-19 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:43:14 --> Input Class Initialized
INFO - 2023-08-19 13:43:14 --> Language Class Initialized
ERROR - 2023-08-19 13:43:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:43:14 --> Config Class Initialized
INFO - 2023-08-19 13:43:14 --> Hooks Class Initialized
INFO - 2023-08-19 13:43:14 --> Hooks Class Initialized
INFO - 2023-08-19 13:43:14 --> Config Class Initialized
DEBUG - 2023-08-19 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:43:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:43:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:43:14 --> Hooks Class Initialized
INFO - 2023-08-19 13:43:14 --> URI Class Initialized
DEBUG - 2023-08-19 13:43:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:43:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:43:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:43:14 --> URI Class Initialized
INFO - 2023-08-19 13:43:14 --> Router Class Initialized
INFO - 2023-08-19 13:43:14 --> Router Class Initialized
INFO - 2023-08-19 13:43:14 --> Output Class Initialized
INFO - 2023-08-19 13:43:14 --> Output Class Initialized
INFO - 2023-08-19 13:43:14 --> URI Class Initialized
INFO - 2023-08-19 13:43:14 --> Security Class Initialized
INFO - 2023-08-19 13:43:14 --> Router Class Initialized
INFO - 2023-08-19 13:43:14 --> Output Class Initialized
INFO - 2023-08-19 13:43:14 --> Security Class Initialized
DEBUG - 2023-08-19 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:43:14 --> Input Class Initialized
INFO - 2023-08-19 13:43:14 --> Language Class Initialized
ERROR - 2023-08-19 13:43:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:43:14 --> Config Class Initialized
INFO - 2023-08-19 13:43:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:43:15 --> Input Class Initialized
INFO - 2023-08-19 13:43:15 --> Language Class Initialized
INFO - 2023-08-19 13:43:15 --> Hooks Class Initialized
ERROR - 2023-08-19 13:43:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:43:15 --> Input Class Initialized
DEBUG - 2023-08-19 13:43:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:43:15 --> Language Class Initialized
INFO - 2023-08-19 13:43:15 --> Utf8 Class Initialized
ERROR - 2023-08-19 13:43:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:43:15 --> URI Class Initialized
INFO - 2023-08-19 13:43:15 --> Router Class Initialized
INFO - 2023-08-19 13:43:15 --> Output Class Initialized
INFO - 2023-08-19 13:43:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:43:15 --> Input Class Initialized
INFO - 2023-08-19 13:43:15 --> Language Class Initialized
ERROR - 2023-08-19 13:43:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:44:49 --> Config Class Initialized
INFO - 2023-08-19 13:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:49 --> Utf8 Class Initialized
INFO - 2023-08-19 13:44:49 --> URI Class Initialized
INFO - 2023-08-19 13:44:49 --> Router Class Initialized
INFO - 2023-08-19 13:44:49 --> Output Class Initialized
INFO - 2023-08-19 13:44:49 --> Security Class Initialized
DEBUG - 2023-08-19 13:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:44:49 --> Input Class Initialized
INFO - 2023-08-19 13:44:49 --> Language Class Initialized
INFO - 2023-08-19 13:44:49 --> Loader Class Initialized
INFO - 2023-08-19 13:44:49 --> Helper loaded: url_helper
INFO - 2023-08-19 13:44:49 --> Helper loaded: file_helper
INFO - 2023-08-19 13:44:49 --> Database Driver Class Initialized
INFO - 2023-08-19 13:44:49 --> Email Class Initialized
DEBUG - 2023-08-19 13:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:44:49 --> Controller Class Initialized
INFO - 2023-08-19 13:44:49 --> Model "Home_model" initialized
INFO - 2023-08-19 13:44:49 --> Helper loaded: form_helper
INFO - 2023-08-19 13:44:49 --> Form Validation Class Initialized
INFO - 2023-08-19 13:44:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:44:49 --> Final output sent to browser
DEBUG - 2023-08-19 13:44:50 --> Total execution time: 0.4843
INFO - 2023-08-19 13:44:51 --> Config Class Initialized
INFO - 2023-08-19 13:44:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:44:51 --> URI Class Initialized
INFO - 2023-08-19 13:44:51 --> Router Class Initialized
INFO - 2023-08-19 13:44:51 --> Output Class Initialized
INFO - 2023-08-19 13:44:51 --> Security Class Initialized
DEBUG - 2023-08-19 13:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:44:51 --> Input Class Initialized
INFO - 2023-08-19 13:44:51 --> Language Class Initialized
ERROR - 2023-08-19 13:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:44:51 --> Config Class Initialized
INFO - 2023-08-19 13:44:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:44:51 --> URI Class Initialized
INFO - 2023-08-19 13:44:51 --> Router Class Initialized
INFO - 2023-08-19 13:44:51 --> Output Class Initialized
INFO - 2023-08-19 13:44:51 --> Security Class Initialized
DEBUG - 2023-08-19 13:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:44:51 --> Input Class Initialized
INFO - 2023-08-19 13:44:51 --> Language Class Initialized
ERROR - 2023-08-19 13:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:44:51 --> Config Class Initialized
INFO - 2023-08-19 13:44:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:51 --> Config Class Initialized
INFO - 2023-08-19 13:44:51 --> Config Class Initialized
INFO - 2023-08-19 13:44:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:44:51 --> Hooks Class Initialized
INFO - 2023-08-19 13:44:51 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:51 --> URI Class Initialized
DEBUG - 2023-08-19 13:44:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:44:51 --> Router Class Initialized
INFO - 2023-08-19 13:44:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:44:51 --> Output Class Initialized
INFO - 2023-08-19 13:44:51 --> Security Class Initialized
INFO - 2023-08-19 13:44:51 --> Utf8 Class Initialized
INFO - 2023-08-19 13:44:51 --> URI Class Initialized
DEBUG - 2023-08-19 13:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:44:51 --> URI Class Initialized
INFO - 2023-08-19 13:44:51 --> Router Class Initialized
INFO - 2023-08-19 13:44:51 --> Router Class Initialized
INFO - 2023-08-19 13:44:51 --> Output Class Initialized
INFO - 2023-08-19 13:44:51 --> Security Class Initialized
INFO - 2023-08-19 13:44:52 --> Output Class Initialized
INFO - 2023-08-19 13:44:52 --> Input Class Initialized
INFO - 2023-08-19 13:44:52 --> Security Class Initialized
DEBUG - 2023-08-19 13:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:44:52 --> Language Class Initialized
INFO - 2023-08-19 13:44:52 --> Input Class Initialized
ERROR - 2023-08-19 13:44:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:44:52 --> Input Class Initialized
INFO - 2023-08-19 13:44:52 --> Language Class Initialized
INFO - 2023-08-19 13:44:52 --> Language Class Initialized
ERROR - 2023-08-19 13:44:52 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 13:44:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:14 --> Config Class Initialized
INFO - 2023-08-19 13:48:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:14 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:14 --> URI Class Initialized
INFO - 2023-08-19 13:48:14 --> Router Class Initialized
INFO - 2023-08-19 13:48:14 --> Output Class Initialized
INFO - 2023-08-19 13:48:14 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:14 --> Input Class Initialized
INFO - 2023-08-19 13:48:14 --> Language Class Initialized
INFO - 2023-08-19 13:48:14 --> Loader Class Initialized
INFO - 2023-08-19 13:48:14 --> Helper loaded: url_helper
INFO - 2023-08-19 13:48:14 --> Helper loaded: file_helper
INFO - 2023-08-19 13:48:14 --> Database Driver Class Initialized
INFO - 2023-08-19 13:48:14 --> Email Class Initialized
DEBUG - 2023-08-19 13:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:48:14 --> Controller Class Initialized
INFO - 2023-08-19 13:48:14 --> Model "Home_model" initialized
INFO - 2023-08-19 13:48:14 --> Helper loaded: form_helper
INFO - 2023-08-19 13:48:14 --> Form Validation Class Initialized
INFO - 2023-08-19 13:48:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:48:15 --> Final output sent to browser
DEBUG - 2023-08-19 13:48:15 --> Total execution time: 0.9178
INFO - 2023-08-19 13:48:15 --> Config Class Initialized
INFO - 2023-08-19 13:48:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:15 --> URI Class Initialized
INFO - 2023-08-19 13:48:15 --> Router Class Initialized
INFO - 2023-08-19 13:48:15 --> Output Class Initialized
INFO - 2023-08-19 13:48:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:15 --> Input Class Initialized
INFO - 2023-08-19 13:48:15 --> Language Class Initialized
ERROR - 2023-08-19 13:48:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:15 --> Config Class Initialized
INFO - 2023-08-19 13:48:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:15 --> URI Class Initialized
INFO - 2023-08-19 13:48:15 --> Router Class Initialized
INFO - 2023-08-19 13:48:15 --> Output Class Initialized
INFO - 2023-08-19 13:48:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:15 --> Input Class Initialized
INFO - 2023-08-19 13:48:15 --> Language Class Initialized
ERROR - 2023-08-19 13:48:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:15 --> Config Class Initialized
INFO - 2023-08-19 13:48:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:15 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:15 --> URI Class Initialized
INFO - 2023-08-19 13:48:15 --> Router Class Initialized
INFO - 2023-08-19 13:48:15 --> Output Class Initialized
INFO - 2023-08-19 13:48:15 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:15 --> Input Class Initialized
INFO - 2023-08-19 13:48:15 --> Language Class Initialized
ERROR - 2023-08-19 13:48:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:15 --> Config Class Initialized
INFO - 2023-08-19 13:48:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:16 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:16 --> URI Class Initialized
INFO - 2023-08-19 13:48:16 --> Router Class Initialized
INFO - 2023-08-19 13:48:16 --> Output Class Initialized
INFO - 2023-08-19 13:48:16 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:16 --> Input Class Initialized
INFO - 2023-08-19 13:48:16 --> Language Class Initialized
ERROR - 2023-08-19 13:48:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:16 --> Config Class Initialized
INFO - 2023-08-19 13:48:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:16 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:16 --> URI Class Initialized
INFO - 2023-08-19 13:48:16 --> Router Class Initialized
INFO - 2023-08-19 13:48:16 --> Output Class Initialized
INFO - 2023-08-19 13:48:16 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:16 --> Input Class Initialized
INFO - 2023-08-19 13:48:16 --> Language Class Initialized
ERROR - 2023-08-19 13:48:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:17 --> Config Class Initialized
INFO - 2023-08-19 13:48:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:17 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:17 --> URI Class Initialized
INFO - 2023-08-19 13:48:17 --> Router Class Initialized
INFO - 2023-08-19 13:48:17 --> Output Class Initialized
INFO - 2023-08-19 13:48:17 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:17 --> Input Class Initialized
INFO - 2023-08-19 13:48:17 --> Language Class Initialized
ERROR - 2023-08-19 13:48:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:52 --> Config Class Initialized
INFO - 2023-08-19 13:48:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:52 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:52 --> URI Class Initialized
INFO - 2023-08-19 13:48:52 --> Router Class Initialized
INFO - 2023-08-19 13:48:52 --> Output Class Initialized
INFO - 2023-08-19 13:48:53 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:53 --> Input Class Initialized
INFO - 2023-08-19 13:48:53 --> Language Class Initialized
INFO - 2023-08-19 13:48:53 --> Loader Class Initialized
INFO - 2023-08-19 13:48:53 --> Helper loaded: url_helper
INFO - 2023-08-19 13:48:53 --> Helper loaded: file_helper
INFO - 2023-08-19 13:48:53 --> Database Driver Class Initialized
INFO - 2023-08-19 13:48:53 --> Email Class Initialized
DEBUG - 2023-08-19 13:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:48:53 --> Controller Class Initialized
INFO - 2023-08-19 13:48:53 --> Model "Home_model" initialized
INFO - 2023-08-19 13:48:53 --> Helper loaded: form_helper
INFO - 2023-08-19 13:48:53 --> Form Validation Class Initialized
INFO - 2023-08-19 13:48:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:48:53 --> Final output sent to browser
DEBUG - 2023-08-19 13:48:53 --> Total execution time: 0.7732
INFO - 2023-08-19 13:48:54 --> Config Class Initialized
INFO - 2023-08-19 13:48:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:54 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:54 --> URI Class Initialized
INFO - 2023-08-19 13:48:54 --> Router Class Initialized
INFO - 2023-08-19 13:48:54 --> Output Class Initialized
INFO - 2023-08-19 13:48:54 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:54 --> Input Class Initialized
INFO - 2023-08-19 13:48:54 --> Language Class Initialized
ERROR - 2023-08-19 13:48:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:55 --> Config Class Initialized
INFO - 2023-08-19 13:48:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:55 --> URI Class Initialized
INFO - 2023-08-19 13:48:55 --> Router Class Initialized
INFO - 2023-08-19 13:48:55 --> Output Class Initialized
INFO - 2023-08-19 13:48:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:55 --> Input Class Initialized
INFO - 2023-08-19 13:48:55 --> Language Class Initialized
ERROR - 2023-08-19 13:48:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:55 --> Config Class Initialized
INFO - 2023-08-19 13:48:55 --> Config Class Initialized
INFO - 2023-08-19 13:48:55 --> Config Class Initialized
INFO - 2023-08-19 13:48:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:55 --> URI Class Initialized
INFO - 2023-08-19 13:48:55 --> Router Class Initialized
INFO - 2023-08-19 13:48:55 --> Output Class Initialized
INFO - 2023-08-19 13:48:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:55 --> Input Class Initialized
INFO - 2023-08-19 13:48:55 --> Language Class Initialized
ERROR - 2023-08-19 13:48:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:55 --> Hooks Class Initialized
INFO - 2023-08-19 13:48:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:55 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:48:55 --> URI Class Initialized
INFO - 2023-08-19 13:48:55 --> Utf8 Class Initialized
INFO - 2023-08-19 13:48:55 --> URI Class Initialized
INFO - 2023-08-19 13:48:55 --> Router Class Initialized
INFO - 2023-08-19 13:48:55 --> Output Class Initialized
INFO - 2023-08-19 13:48:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:55 --> Input Class Initialized
INFO - 2023-08-19 13:48:55 --> Language Class Initialized
ERROR - 2023-08-19 13:48:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:48:55 --> Router Class Initialized
INFO - 2023-08-19 13:48:55 --> Output Class Initialized
INFO - 2023-08-19 13:48:55 --> Security Class Initialized
DEBUG - 2023-08-19 13:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:48:55 --> Input Class Initialized
INFO - 2023-08-19 13:48:55 --> Language Class Initialized
ERROR - 2023-08-19 13:48:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:17 --> Config Class Initialized
INFO - 2023-08-19 13:50:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:17 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:17 --> URI Class Initialized
INFO - 2023-08-19 13:50:17 --> Router Class Initialized
INFO - 2023-08-19 13:50:17 --> Output Class Initialized
INFO - 2023-08-19 13:50:17 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:18 --> Input Class Initialized
INFO - 2023-08-19 13:50:18 --> Language Class Initialized
INFO - 2023-08-19 13:50:18 --> Loader Class Initialized
INFO - 2023-08-19 13:50:18 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:18 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:18 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:18 --> Email Class Initialized
DEBUG - 2023-08-19 13:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:18 --> Controller Class Initialized
INFO - 2023-08-19 13:50:18 --> Model "Home_model" initialized
INFO - 2023-08-19 13:50:18 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:18 --> Form Validation Class Initialized
INFO - 2023-08-19 13:50:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:50:18 --> Final output sent to browser
DEBUG - 2023-08-19 13:50:18 --> Total execution time: 0.9258
INFO - 2023-08-19 13:50:18 --> Config Class Initialized
INFO - 2023-08-19 13:50:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:18 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:18 --> URI Class Initialized
INFO - 2023-08-19 13:50:18 --> Router Class Initialized
INFO - 2023-08-19 13:50:18 --> Output Class Initialized
INFO - 2023-08-19 13:50:18 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:18 --> Input Class Initialized
INFO - 2023-08-19 13:50:18 --> Language Class Initialized
ERROR - 2023-08-19 13:50:18 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:19 --> Config Class Initialized
INFO - 2023-08-19 13:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:19 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:19 --> URI Class Initialized
INFO - 2023-08-19 13:50:19 --> Router Class Initialized
INFO - 2023-08-19 13:50:19 --> Output Class Initialized
INFO - 2023-08-19 13:50:19 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:19 --> Input Class Initialized
INFO - 2023-08-19 13:50:19 --> Language Class Initialized
ERROR - 2023-08-19 13:50:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:19 --> Config Class Initialized
INFO - 2023-08-19 13:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:19 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:19 --> URI Class Initialized
INFO - 2023-08-19 13:50:19 --> Router Class Initialized
INFO - 2023-08-19 13:50:19 --> Output Class Initialized
INFO - 2023-08-19 13:50:19 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:19 --> Input Class Initialized
INFO - 2023-08-19 13:50:19 --> Language Class Initialized
ERROR - 2023-08-19 13:50:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:19 --> Config Class Initialized
INFO - 2023-08-19 13:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:19 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:19 --> URI Class Initialized
INFO - 2023-08-19 13:50:19 --> Router Class Initialized
INFO - 2023-08-19 13:50:19 --> Output Class Initialized
INFO - 2023-08-19 13:50:19 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:19 --> Input Class Initialized
INFO - 2023-08-19 13:50:19 --> Language Class Initialized
ERROR - 2023-08-19 13:50:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:19 --> Config Class Initialized
INFO - 2023-08-19 13:50:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:20 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:20 --> URI Class Initialized
INFO - 2023-08-19 13:50:20 --> Router Class Initialized
INFO - 2023-08-19 13:50:20 --> Output Class Initialized
INFO - 2023-08-19 13:50:20 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:20 --> Input Class Initialized
INFO - 2023-08-19 13:50:20 --> Language Class Initialized
ERROR - 2023-08-19 13:50:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:50:59 --> Config Class Initialized
INFO - 2023-08-19 13:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:50:59 --> Utf8 Class Initialized
INFO - 2023-08-19 13:50:59 --> URI Class Initialized
INFO - 2023-08-19 13:50:59 --> Router Class Initialized
INFO - 2023-08-19 13:50:59 --> Output Class Initialized
INFO - 2023-08-19 13:50:59 --> Security Class Initialized
DEBUG - 2023-08-19 13:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:50:59 --> Input Class Initialized
INFO - 2023-08-19 13:50:59 --> Language Class Initialized
INFO - 2023-08-19 13:50:59 --> Loader Class Initialized
INFO - 2023-08-19 13:50:59 --> Helper loaded: url_helper
INFO - 2023-08-19 13:50:59 --> Helper loaded: file_helper
INFO - 2023-08-19 13:50:59 --> Database Driver Class Initialized
INFO - 2023-08-19 13:50:59 --> Email Class Initialized
DEBUG - 2023-08-19 13:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:50:59 --> Controller Class Initialized
INFO - 2023-08-19 13:50:59 --> Model "Home_model" initialized
INFO - 2023-08-19 13:50:59 --> Helper loaded: form_helper
INFO - 2023-08-19 13:50:59 --> Form Validation Class Initialized
INFO - 2023-08-19 13:50:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:50:59 --> Final output sent to browser
DEBUG - 2023-08-19 13:51:00 --> Total execution time: 0.8208
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Config Class Initialized
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:00 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:00 --> URI Class Initialized
INFO - 2023-08-19 13:51:00 --> Router Class Initialized
INFO - 2023-08-19 13:51:00 --> Output Class Initialized
INFO - 2023-08-19 13:51:00 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:00 --> Input Class Initialized
INFO - 2023-08-19 13:51:00 --> Language Class Initialized
ERROR - 2023-08-19 13:51:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:51:01 --> Config Class Initialized
INFO - 2023-08-19 13:51:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:51:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:51:01 --> Utf8 Class Initialized
INFO - 2023-08-19 13:51:01 --> URI Class Initialized
INFO - 2023-08-19 13:51:01 --> Router Class Initialized
INFO - 2023-08-19 13:51:01 --> Output Class Initialized
INFO - 2023-08-19 13:51:01 --> Security Class Initialized
DEBUG - 2023-08-19 13:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:51:01 --> Input Class Initialized
INFO - 2023-08-19 13:51:01 --> Language Class Initialized
ERROR - 2023-08-19 13:51:01 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:53:20 --> Config Class Initialized
INFO - 2023-08-19 13:53:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:53:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:53:20 --> Utf8 Class Initialized
INFO - 2023-08-19 13:53:20 --> URI Class Initialized
INFO - 2023-08-19 13:53:20 --> Router Class Initialized
INFO - 2023-08-19 13:53:20 --> Output Class Initialized
INFO - 2023-08-19 13:53:20 --> Security Class Initialized
DEBUG - 2023-08-19 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:53:20 --> Input Class Initialized
INFO - 2023-08-19 13:53:21 --> Language Class Initialized
INFO - 2023-08-19 13:53:21 --> Loader Class Initialized
INFO - 2023-08-19 13:53:21 --> Helper loaded: url_helper
INFO - 2023-08-19 13:53:21 --> Helper loaded: file_helper
INFO - 2023-08-19 13:53:21 --> Database Driver Class Initialized
INFO - 2023-08-19 13:53:21 --> Email Class Initialized
DEBUG - 2023-08-19 13:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:53:21 --> Controller Class Initialized
INFO - 2023-08-19 13:53:21 --> Model "Home_model" initialized
INFO - 2023-08-19 13:53:21 --> Helper loaded: form_helper
INFO - 2023-08-19 13:53:21 --> Form Validation Class Initialized
INFO - 2023-08-19 13:53:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:53:21 --> Final output sent to browser
DEBUG - 2023-08-19 13:53:21 --> Total execution time: 0.9013
INFO - 2023-08-19 13:53:22 --> Config Class Initialized
INFO - 2023-08-19 13:53:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:53:22 --> URI Class Initialized
INFO - 2023-08-19 13:53:22 --> Router Class Initialized
INFO - 2023-08-19 13:53:22 --> Output Class Initialized
INFO - 2023-08-19 13:53:22 --> Security Class Initialized
DEBUG - 2023-08-19 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:53:22 --> Input Class Initialized
INFO - 2023-08-19 13:53:22 --> Language Class Initialized
ERROR - 2023-08-19 13:53:22 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:53:22 --> Config Class Initialized
INFO - 2023-08-19 13:53:22 --> Hooks Class Initialized
INFO - 2023-08-19 13:53:22 --> Config Class Initialized
INFO - 2023-08-19 13:53:22 --> Config Class Initialized
INFO - 2023-08-19 13:53:22 --> Config Class Initialized
INFO - 2023-08-19 13:53:22 --> Hooks Class Initialized
INFO - 2023-08-19 13:53:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:53:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:53:22 --> URI Class Initialized
INFO - 2023-08-19 13:53:22 --> Router Class Initialized
INFO - 2023-08-19 13:53:22 --> Output Class Initialized
INFO - 2023-08-19 13:53:22 --> Security Class Initialized
DEBUG - 2023-08-19 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:53:22 --> Input Class Initialized
INFO - 2023-08-19 13:53:22 --> Language Class Initialized
ERROR - 2023-08-19 13:53:22 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 13:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:53:22 --> Hooks Class Initialized
INFO - 2023-08-19 13:53:22 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:53:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:53:22 --> URI Class Initialized
INFO - 2023-08-19 13:53:22 --> URI Class Initialized
INFO - 2023-08-19 13:53:22 --> Utf8 Class Initialized
INFO - 2023-08-19 13:53:22 --> Router Class Initialized
INFO - 2023-08-19 13:53:22 --> URI Class Initialized
INFO - 2023-08-19 13:53:22 --> Output Class Initialized
INFO - 2023-08-19 13:53:22 --> Router Class Initialized
INFO - 2023-08-19 13:53:22 --> Router Class Initialized
INFO - 2023-08-19 13:53:22 --> Security Class Initialized
INFO - 2023-08-19 13:53:22 --> Output Class Initialized
DEBUG - 2023-08-19 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:53:22 --> Output Class Initialized
INFO - 2023-08-19 13:53:22 --> Input Class Initialized
INFO - 2023-08-19 13:53:22 --> Security Class Initialized
INFO - 2023-08-19 13:53:22 --> Security Class Initialized
DEBUG - 2023-08-19 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:53:22 --> Input Class Initialized
INFO - 2023-08-19 13:53:23 --> Language Class Initialized
INFO - 2023-08-19 13:53:23 --> Language Class Initialized
DEBUG - 2023-08-19 13:53:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 13:53:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:53:23 --> Input Class Initialized
ERROR - 2023-08-19 13:53:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:53:23 --> Language Class Initialized
ERROR - 2023-08-19 13:53:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:54:58 --> Config Class Initialized
INFO - 2023-08-19 13:54:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:54:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:54:58 --> Utf8 Class Initialized
INFO - 2023-08-19 13:54:58 --> URI Class Initialized
INFO - 2023-08-19 13:54:58 --> Router Class Initialized
INFO - 2023-08-19 13:54:58 --> Output Class Initialized
INFO - 2023-08-19 13:54:58 --> Security Class Initialized
DEBUG - 2023-08-19 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:54:58 --> Input Class Initialized
INFO - 2023-08-19 13:54:58 --> Language Class Initialized
INFO - 2023-08-19 13:54:58 --> Loader Class Initialized
INFO - 2023-08-19 13:54:58 --> Helper loaded: url_helper
INFO - 2023-08-19 13:54:58 --> Helper loaded: file_helper
INFO - 2023-08-19 13:54:58 --> Database Driver Class Initialized
INFO - 2023-08-19 13:54:59 --> Email Class Initialized
DEBUG - 2023-08-19 13:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:54:59 --> Controller Class Initialized
INFO - 2023-08-19 13:54:59 --> Model "Home_model" initialized
INFO - 2023-08-19 13:54:59 --> Helper loaded: form_helper
INFO - 2023-08-19 13:54:59 --> Form Validation Class Initialized
INFO - 2023-08-19 13:54:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:54:59 --> Final output sent to browser
DEBUG - 2023-08-19 13:55:00 --> Total execution time: 1.2624
INFO - 2023-08-19 13:55:02 --> Config Class Initialized
INFO - 2023-08-19 13:55:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:02 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:02 --> URI Class Initialized
INFO - 2023-08-19 13:55:02 --> Router Class Initialized
INFO - 2023-08-19 13:55:02 --> Output Class Initialized
INFO - 2023-08-19 13:55:02 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:02 --> Input Class Initialized
INFO - 2023-08-19 13:55:02 --> Language Class Initialized
ERROR - 2023-08-19 13:55:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:55:02 --> Config Class Initialized
INFO - 2023-08-19 13:55:02 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:02 --> Config Class Initialized
INFO - 2023-08-19 13:55:02 --> Config Class Initialized
INFO - 2023-08-19 13:55:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:02 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:55:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:02 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:02 --> URI Class Initialized
INFO - 2023-08-19 13:55:02 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:02 --> Router Class Initialized
INFO - 2023-08-19 13:55:03 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:03 --> Output Class Initialized
INFO - 2023-08-19 13:55:03 --> URI Class Initialized
INFO - 2023-08-19 13:55:03 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:03 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:03 --> Router Class Initialized
INFO - 2023-08-19 13:55:03 --> URI Class Initialized
INFO - 2023-08-19 13:55:03 --> Output Class Initialized
INFO - 2023-08-19 13:55:03 --> Router Class Initialized
INFO - 2023-08-19 13:55:03 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:03 --> Input Class Initialized
INFO - 2023-08-19 13:55:03 --> Input Class Initialized
INFO - 2023-08-19 13:55:03 --> Output Class Initialized
INFO - 2023-08-19 13:55:03 --> Language Class Initialized
INFO - 2023-08-19 13:55:03 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 13:55:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:55:03 --> Language Class Initialized
INFO - 2023-08-19 13:55:03 --> Input Class Initialized
ERROR - 2023-08-19 13:55:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:55:03 --> Language Class Initialized
ERROR - 2023-08-19 13:55:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:55:03 --> Config Class Initialized
INFO - 2023-08-19 13:55:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:04 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:04 --> URI Class Initialized
INFO - 2023-08-19 13:55:04 --> Router Class Initialized
INFO - 2023-08-19 13:55:04 --> Output Class Initialized
INFO - 2023-08-19 13:55:04 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:04 --> Input Class Initialized
INFO - 2023-08-19 13:55:04 --> Language Class Initialized
ERROR - 2023-08-19 13:55:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:55:24 --> Config Class Initialized
INFO - 2023-08-19 13:55:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:25 --> Config Class Initialized
INFO - 2023-08-19 13:55:26 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:26 --> Config Class Initialized
INFO - 2023-08-19 13:55:26 --> URI Class Initialized
INFO - 2023-08-19 13:55:26 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:26 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:26 --> Router Class Initialized
DEBUG - 2023-08-19 13:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:27 --> Utf8 Class Initialized
DEBUG - 2023-08-19 13:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:27 --> Output Class Initialized
INFO - 2023-08-19 13:55:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:27 --> URI Class Initialized
INFO - 2023-08-19 13:55:27 --> URI Class Initialized
INFO - 2023-08-19 13:55:27 --> Security Class Initialized
INFO - 2023-08-19 13:55:27 --> Router Class Initialized
INFO - 2023-08-19 13:55:27 --> Router Class Initialized
DEBUG - 2023-08-19 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:27 --> Output Class Initialized
INFO - 2023-08-19 13:55:27 --> Output Class Initialized
INFO - 2023-08-19 13:55:27 --> Security Class Initialized
INFO - 2023-08-19 13:55:27 --> Security Class Initialized
INFO - 2023-08-19 13:55:27 --> Config Class Initialized
INFO - 2023-08-19 13:55:27 --> Config Class Initialized
INFO - 2023-08-19 13:55:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:27 --> URI Class Initialized
INFO - 2023-08-19 13:55:27 --> Router Class Initialized
INFO - 2023-08-19 13:55:27 --> Output Class Initialized
INFO - 2023-08-19 13:55:27 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:27 --> Input Class Initialized
INFO - 2023-08-19 13:55:27 --> Language Class Initialized
ERROR - 2023-08-19 13:55:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:55:27 --> Input Class Initialized
DEBUG - 2023-08-19 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:55:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:27 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:27 --> Language Class Initialized
INFO - 2023-08-19 13:55:27 --> Input Class Initialized
DEBUG - 2023-08-19 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:27 --> Config Class Initialized
INFO - 2023-08-19 13:55:27 --> URI Class Initialized
INFO - 2023-08-19 13:55:27 --> Config Class Initialized
ERROR - 2023-08-19 13:55:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:55:28 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:28 --> Hooks Class Initialized
INFO - 2023-08-19 13:55:28 --> Router Class Initialized
DEBUG - 2023-08-19 13:55:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:28 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:28 --> URI Class Initialized
INFO - 2023-08-19 13:55:28 --> Router Class Initialized
INFO - 2023-08-19 13:55:28 --> Output Class Initialized
INFO - 2023-08-19 13:55:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:28 --> Input Class Initialized
INFO - 2023-08-19 13:55:28 --> Language Class Initialized
ERROR - 2023-08-19 13:55:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:55:28 --> Language Class Initialized
INFO - 2023-08-19 13:55:28 --> Output Class Initialized
INFO - 2023-08-19 13:55:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:55:28 --> Input Class Initialized
INFO - 2023-08-19 13:55:28 --> Utf8 Class Initialized
INFO - 2023-08-19 13:55:28 --> Language Class Initialized
ERROR - 2023-08-19 13:55:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-19 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:28 --> URI Class Initialized
INFO - 2023-08-19 13:55:28 --> Input Class Initialized
ERROR - 2023-08-19 13:55:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:55:28 --> Language Class Initialized
ERROR - 2023-08-19 13:55:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:55:28 --> Router Class Initialized
INFO - 2023-08-19 13:55:28 --> Output Class Initialized
INFO - 2023-08-19 13:55:28 --> Security Class Initialized
DEBUG - 2023-08-19 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:55:28 --> Input Class Initialized
INFO - 2023-08-19 13:55:28 --> Language Class Initialized
ERROR - 2023-08-19 13:55:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:37 --> Config Class Initialized
INFO - 2023-08-19 13:58:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:37 --> URI Class Initialized
INFO - 2023-08-19 13:58:37 --> Router Class Initialized
INFO - 2023-08-19 13:58:37 --> Output Class Initialized
INFO - 2023-08-19 13:58:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:38 --> Input Class Initialized
INFO - 2023-08-19 13:58:38 --> Language Class Initialized
INFO - 2023-08-19 13:58:38 --> Loader Class Initialized
INFO - 2023-08-19 13:58:38 --> Helper loaded: url_helper
INFO - 2023-08-19 13:58:38 --> Helper loaded: file_helper
INFO - 2023-08-19 13:58:38 --> Database Driver Class Initialized
INFO - 2023-08-19 13:58:38 --> Email Class Initialized
DEBUG - 2023-08-19 13:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:58:38 --> Controller Class Initialized
INFO - 2023-08-19 13:58:38 --> Model "Home_model" initialized
INFO - 2023-08-19 13:58:38 --> Helper loaded: form_helper
INFO - 2023-08-19 13:58:38 --> Form Validation Class Initialized
INFO - 2023-08-19 13:58:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:58:38 --> Final output sent to browser
DEBUG - 2023-08-19 13:58:39 --> Total execution time: 1.4130
INFO - 2023-08-19 13:58:42 --> Config Class Initialized
INFO - 2023-08-19 13:58:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:42 --> URI Class Initialized
INFO - 2023-08-19 13:58:42 --> Router Class Initialized
INFO - 2023-08-19 13:58:42 --> Output Class Initialized
INFO - 2023-08-19 13:58:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:42 --> Input Class Initialized
INFO - 2023-08-19 13:58:42 --> Language Class Initialized
ERROR - 2023-08-19 13:58:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:58:42 --> Config Class Initialized
INFO - 2023-08-19 13:58:42 --> Config Class Initialized
INFO - 2023-08-19 13:58:42 --> Config Class Initialized
INFO - 2023-08-19 13:58:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:42 --> URI Class Initialized
INFO - 2023-08-19 13:58:42 --> Router Class Initialized
INFO - 2023-08-19 13:58:42 --> Output Class Initialized
INFO - 2023-08-19 13:58:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:42 --> Input Class Initialized
INFO - 2023-08-19 13:58:42 --> Language Class Initialized
ERROR - 2023-08-19 13:58:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:44 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:45 --> Config Class Initialized
INFO - 2023-08-19 13:58:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:45 --> URI Class Initialized
INFO - 2023-08-19 13:58:45 --> Router Class Initialized
INFO - 2023-08-19 13:58:45 --> Output Class Initialized
INFO - 2023-08-19 13:58:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:45 --> Input Class Initialized
INFO - 2023-08-19 13:58:45 --> Language Class Initialized
ERROR - 2023-08-19 13:58:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:45 --> URI Class Initialized
INFO - 2023-08-19 13:58:45 --> Config Class Initialized
INFO - 2023-08-19 13:58:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:45 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:45 --> URI Class Initialized
INFO - 2023-08-19 13:58:45 --> Router Class Initialized
INFO - 2023-08-19 13:58:45 --> Output Class Initialized
INFO - 2023-08-19 13:58:45 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:45 --> Input Class Initialized
INFO - 2023-08-19 13:58:45 --> Language Class Initialized
ERROR - 2023-08-19 13:58:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:47 --> Router Class Initialized
INFO - 2023-08-19 13:58:47 --> Config Class Initialized
INFO - 2023-08-19 13:58:47 --> Output Class Initialized
INFO - 2023-08-19 13:58:47 --> Config Class Initialized
INFO - 2023-08-19 13:58:47 --> Hooks Class Initialized
INFO - 2023-08-19 13:58:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:47 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:47 --> Config Class Initialized
INFO - 2023-08-19 13:58:47 --> Hooks Class Initialized
INFO - 2023-08-19 13:58:47 --> Config Class Initialized
DEBUG - 2023-08-19 13:58:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:47 --> Security Class Initialized
INFO - 2023-08-19 13:58:47 --> Config Class Initialized
DEBUG - 2023-08-19 13:58:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:58:47 --> URI Class Initialized
INFO - 2023-08-19 13:58:47 --> Router Class Initialized
INFO - 2023-08-19 13:58:47 --> Output Class Initialized
INFO - 2023-08-19 13:58:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:48 --> Input Class Initialized
INFO - 2023-08-19 13:58:48 --> Language Class Initialized
ERROR - 2023-08-19 13:58:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:48 --> URI Class Initialized
INFO - 2023-08-19 13:58:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:48 --> URI Class Initialized
INFO - 2023-08-19 13:58:48 --> Utf8 Class Initialized
INFO - 2023-08-19 13:58:48 --> Router Class Initialized
INFO - 2023-08-19 13:58:48 --> URI Class Initialized
INFO - 2023-08-19 13:58:48 --> URI Class Initialized
INFO - 2023-08-19 13:58:48 --> Input Class Initialized
INFO - 2023-08-19 13:58:48 --> Router Class Initialized
INFO - 2023-08-19 13:58:48 --> Output Class Initialized
INFO - 2023-08-19 13:58:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:48 --> Input Class Initialized
INFO - 2023-08-19 13:58:48 --> Language Class Initialized
ERROR - 2023-08-19 13:58:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:58:48 --> Language Class Initialized
INFO - 2023-08-19 13:58:48 --> Router Class Initialized
INFO - 2023-08-19 13:58:48 --> Router Class Initialized
INFO - 2023-08-19 13:58:48 --> Output Class Initialized
ERROR - 2023-08-19 13:58:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:58:48 --> Output Class Initialized
INFO - 2023-08-19 13:58:48 --> Output Class Initialized
INFO - 2023-08-19 13:58:48 --> Security Class Initialized
INFO - 2023-08-19 13:58:48 --> Security Class Initialized
INFO - 2023-08-19 13:58:48 --> Security Class Initialized
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:48 --> Input Class Initialized
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:58:49 --> Language Class Initialized
INFO - 2023-08-19 13:58:49 --> Input Class Initialized
INFO - 2023-08-19 13:58:49 --> Input Class Initialized
INFO - 2023-08-19 13:58:49 --> Language Class Initialized
ERROR - 2023-08-19 13:58:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:58:49 --> Language Class Initialized
ERROR - 2023-08-19 13:58:49 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-19 13:58:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:36 --> Config Class Initialized
INFO - 2023-08-19 13:59:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:36 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:36 --> URI Class Initialized
INFO - 2023-08-19 13:59:36 --> Router Class Initialized
INFO - 2023-08-19 13:59:36 --> Output Class Initialized
INFO - 2023-08-19 13:59:36 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:36 --> Input Class Initialized
INFO - 2023-08-19 13:59:36 --> Language Class Initialized
INFO - 2023-08-19 13:59:36 --> Loader Class Initialized
INFO - 2023-08-19 13:59:36 --> Helper loaded: url_helper
INFO - 2023-08-19 13:59:36 --> Helper loaded: file_helper
INFO - 2023-08-19 13:59:36 --> Database Driver Class Initialized
INFO - 2023-08-19 13:59:36 --> Email Class Initialized
DEBUG - 2023-08-19 13:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 13:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 13:59:36 --> Controller Class Initialized
INFO - 2023-08-19 13:59:36 --> Model "Home_model" initialized
INFO - 2023-08-19 13:59:36 --> Helper loaded: form_helper
INFO - 2023-08-19 13:59:36 --> Form Validation Class Initialized
INFO - 2023-08-19 13:59:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 13:59:36 --> Final output sent to browser
DEBUG - 2023-08-19 13:59:36 --> Total execution time: 0.2429
INFO - 2023-08-19 13:59:37 --> Config Class Initialized
INFO - 2023-08-19 13:59:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:37 --> URI Class Initialized
INFO - 2023-08-19 13:59:37 --> Router Class Initialized
INFO - 2023-08-19 13:59:37 --> Output Class Initialized
INFO - 2023-08-19 13:59:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:37 --> Input Class Initialized
INFO - 2023-08-19 13:59:37 --> Language Class Initialized
ERROR - 2023-08-19 13:59:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:37 --> Config Class Initialized
INFO - 2023-08-19 13:59:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:37 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:37 --> URI Class Initialized
INFO - 2023-08-19 13:59:37 --> Router Class Initialized
INFO - 2023-08-19 13:59:37 --> Output Class Initialized
INFO - 2023-08-19 13:59:37 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:38 --> Input Class Initialized
INFO - 2023-08-19 13:59:39 --> Language Class Initialized
ERROR - 2023-08-19 13:59:39 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:39 --> Config Class Initialized
INFO - 2023-08-19 13:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:40 --> Config Class Initialized
INFO - 2023-08-19 13:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:40 --> URI Class Initialized
INFO - 2023-08-19 13:59:40 --> Router Class Initialized
INFO - 2023-08-19 13:59:40 --> Output Class Initialized
INFO - 2023-08-19 13:59:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:40 --> Input Class Initialized
INFO - 2023-08-19 13:59:40 --> Language Class Initialized
ERROR - 2023-08-19 13:59:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:40 --> Config Class Initialized
INFO - 2023-08-19 13:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:40 --> URI Class Initialized
INFO - 2023-08-19 13:59:40 --> Router Class Initialized
INFO - 2023-08-19 13:59:40 --> Output Class Initialized
INFO - 2023-08-19 13:59:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:40 --> Input Class Initialized
INFO - 2023-08-19 13:59:40 --> Language Class Initialized
ERROR - 2023-08-19 13:59:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:40 --> Config Class Initialized
INFO - 2023-08-19 13:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:40 --> URI Class Initialized
INFO - 2023-08-19 13:59:40 --> Router Class Initialized
INFO - 2023-08-19 13:59:40 --> Output Class Initialized
INFO - 2023-08-19 13:59:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:40 --> Input Class Initialized
INFO - 2023-08-19 13:59:40 --> Language Class Initialized
ERROR - 2023-08-19 13:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:40 --> URI Class Initialized
INFO - 2023-08-19 13:59:40 --> Router Class Initialized
INFO - 2023-08-19 13:59:40 --> Output Class Initialized
INFO - 2023-08-19 13:59:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:40 --> Input Class Initialized
INFO - 2023-08-19 13:59:40 --> Language Class Initialized
ERROR - 2023-08-19 13:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:40 --> Config Class Initialized
INFO - 2023-08-19 13:59:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:40 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:40 --> URI Class Initialized
INFO - 2023-08-19 13:59:40 --> Router Class Initialized
INFO - 2023-08-19 13:59:40 --> Output Class Initialized
INFO - 2023-08-19 13:59:40 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:40 --> Input Class Initialized
INFO - 2023-08-19 13:59:40 --> Language Class Initialized
ERROR - 2023-08-19 13:59:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:41 --> Config Class Initialized
INFO - 2023-08-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:41 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:41 --> URI Class Initialized
INFO - 2023-08-19 13:59:41 --> Router Class Initialized
INFO - 2023-08-19 13:59:41 --> Output Class Initialized
INFO - 2023-08-19 13:59:41 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:41 --> Input Class Initialized
INFO - 2023-08-19 13:59:41 --> Language Class Initialized
ERROR - 2023-08-19 13:59:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:41 --> Config Class Initialized
INFO - 2023-08-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:41 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:41 --> URI Class Initialized
INFO - 2023-08-19 13:59:41 --> Router Class Initialized
INFO - 2023-08-19 13:59:41 --> Output Class Initialized
INFO - 2023-08-19 13:59:41 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:41 --> Input Class Initialized
INFO - 2023-08-19 13:59:41 --> Language Class Initialized
ERROR - 2023-08-19 13:59:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 13:59:41 --> Config Class Initialized
INFO - 2023-08-19 13:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:42 --> URI Class Initialized
INFO - 2023-08-19 13:59:42 --> Router Class Initialized
INFO - 2023-08-19 13:59:42 --> Output Class Initialized
INFO - 2023-08-19 13:59:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:42 --> Input Class Initialized
INFO - 2023-08-19 13:59:42 --> Language Class Initialized
ERROR - 2023-08-19 13:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:42 --> Config Class Initialized
INFO - 2023-08-19 13:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:42 --> URI Class Initialized
INFO - 2023-08-19 13:59:42 --> Router Class Initialized
INFO - 2023-08-19 13:59:42 --> Output Class Initialized
INFO - 2023-08-19 13:59:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:42 --> Input Class Initialized
INFO - 2023-08-19 13:59:42 --> Language Class Initialized
ERROR - 2023-08-19 13:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:42 --> Config Class Initialized
INFO - 2023-08-19 13:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:42 --> URI Class Initialized
INFO - 2023-08-19 13:59:42 --> Router Class Initialized
INFO - 2023-08-19 13:59:42 --> Output Class Initialized
INFO - 2023-08-19 13:59:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:42 --> Input Class Initialized
INFO - 2023-08-19 13:59:42 --> Language Class Initialized
ERROR - 2023-08-19 13:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 13:59:42 --> Config Class Initialized
INFO - 2023-08-19 13:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 13:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 13:59:42 --> Utf8 Class Initialized
INFO - 2023-08-19 13:59:42 --> URI Class Initialized
INFO - 2023-08-19 13:59:42 --> Router Class Initialized
INFO - 2023-08-19 13:59:42 --> Output Class Initialized
INFO - 2023-08-19 13:59:42 --> Security Class Initialized
DEBUG - 2023-08-19 13:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 13:59:42 --> Input Class Initialized
INFO - 2023-08-19 13:59:42 --> Language Class Initialized
ERROR - 2023-08-19 13:59:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:20 --> Config Class Initialized
INFO - 2023-08-19 14:00:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:20 --> URI Class Initialized
INFO - 2023-08-19 14:00:20 --> Router Class Initialized
INFO - 2023-08-19 14:00:20 --> Output Class Initialized
INFO - 2023-08-19 14:00:21 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:21 --> Input Class Initialized
INFO - 2023-08-19 14:00:21 --> Language Class Initialized
INFO - 2023-08-19 14:00:21 --> Loader Class Initialized
INFO - 2023-08-19 14:00:21 --> Helper loaded: url_helper
INFO - 2023-08-19 14:00:21 --> Helper loaded: file_helper
INFO - 2023-08-19 14:00:21 --> Database Driver Class Initialized
INFO - 2023-08-19 14:00:21 --> Email Class Initialized
DEBUG - 2023-08-19 14:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:00:21 --> Controller Class Initialized
INFO - 2023-08-19 14:00:21 --> Model "Home_model" initialized
INFO - 2023-08-19 14:00:21 --> Helper loaded: form_helper
INFO - 2023-08-19 14:00:21 --> Form Validation Class Initialized
INFO - 2023-08-19 14:00:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:00:21 --> Final output sent to browser
DEBUG - 2023-08-19 14:00:22 --> Total execution time: 1.2426
INFO - 2023-08-19 14:00:24 --> Config Class Initialized
INFO - 2023-08-19 14:00:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:25 --> Config Class Initialized
INFO - 2023-08-19 14:00:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:25 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:25 --> URI Class Initialized
INFO - 2023-08-19 14:00:25 --> Router Class Initialized
INFO - 2023-08-19 14:00:25 --> Output Class Initialized
INFO - 2023-08-19 14:00:25 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:25 --> Input Class Initialized
INFO - 2023-08-19 14:00:25 --> Language Class Initialized
ERROR - 2023-08-19 14:00:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:25 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:26 --> URI Class Initialized
INFO - 2023-08-19 14:00:26 --> Config Class Initialized
INFO - 2023-08-19 14:00:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:26 --> URI Class Initialized
INFO - 2023-08-19 14:00:26 --> Router Class Initialized
INFO - 2023-08-19 14:00:26 --> Output Class Initialized
INFO - 2023-08-19 14:00:26 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:26 --> Input Class Initialized
INFO - 2023-08-19 14:00:26 --> Language Class Initialized
ERROR - 2023-08-19 14:00:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:26 --> Router Class Initialized
INFO - 2023-08-19 14:00:26 --> Output Class Initialized
INFO - 2023-08-19 14:00:27 --> Config Class Initialized
INFO - 2023-08-19 14:00:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:27 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:27 --> URI Class Initialized
INFO - 2023-08-19 14:00:27 --> Router Class Initialized
INFO - 2023-08-19 14:00:27 --> Output Class Initialized
INFO - 2023-08-19 14:00:27 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:27 --> Input Class Initialized
INFO - 2023-08-19 14:00:27 --> Language Class Initialized
ERROR - 2023-08-19 14:00:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:27 --> Security Class Initialized
INFO - 2023-08-19 14:00:27 --> Config Class Initialized
INFO - 2023-08-19 14:00:28 --> Config Class Initialized
INFO - 2023-08-19 14:00:29 --> Config Class Initialized
INFO - 2023-08-19 14:00:29 --> Config Class Initialized
INFO - 2023-08-19 14:00:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:29 --> URI Class Initialized
INFO - 2023-08-19 14:00:29 --> Router Class Initialized
INFO - 2023-08-19 14:00:29 --> Output Class Initialized
INFO - 2023-08-19 14:00:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:29 --> Input Class Initialized
INFO - 2023-08-19 14:00:29 --> Language Class Initialized
ERROR - 2023-08-19 14:00:29 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-19 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:29 --> Hooks Class Initialized
INFO - 2023-08-19 14:00:29 --> Config Class Initialized
INFO - 2023-08-19 14:00:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:29 --> URI Class Initialized
INFO - 2023-08-19 14:00:29 --> Router Class Initialized
INFO - 2023-08-19 14:00:29 --> Output Class Initialized
INFO - 2023-08-19 14:00:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:29 --> Input Class Initialized
INFO - 2023-08-19 14:00:29 --> Language Class Initialized
ERROR - 2023-08-19 14:00:29 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:29 --> Config Class Initialized
INFO - 2023-08-19 14:00:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:29 --> URI Class Initialized
INFO - 2023-08-19 14:00:29 --> Router Class Initialized
INFO - 2023-08-19 14:00:29 --> Output Class Initialized
INFO - 2023-08-19 14:00:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:29 --> Input Class Initialized
INFO - 2023-08-19 14:00:29 --> Language Class Initialized
ERROR - 2023-08-19 14:00:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:30 --> Config Class Initialized
INFO - 2023-08-19 14:00:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:30 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:30 --> URI Class Initialized
INFO - 2023-08-19 14:00:30 --> Router Class Initialized
INFO - 2023-08-19 14:00:30 --> Output Class Initialized
INFO - 2023-08-19 14:00:30 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:30 --> Input Class Initialized
INFO - 2023-08-19 14:00:30 --> Language Class Initialized
ERROR - 2023-08-19 14:00:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:30 --> Input Class Initialized
INFO - 2023-08-19 14:00:30 --> Config Class Initialized
INFO - 2023-08-19 14:00:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:30 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:30 --> URI Class Initialized
INFO - 2023-08-19 14:00:30 --> Router Class Initialized
INFO - 2023-08-19 14:00:30 --> Output Class Initialized
INFO - 2023-08-19 14:00:30 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:30 --> Input Class Initialized
INFO - 2023-08-19 14:00:30 --> Language Class Initialized
ERROR - 2023-08-19 14:00:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:30 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:30 --> Config Class Initialized
INFO - 2023-08-19 14:00:30 --> Language Class Initialized
ERROR - 2023-08-19 14:00:30 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:30 --> Hooks Class Initialized
INFO - 2023-08-19 14:00:30 --> Hooks Class Initialized
INFO - 2023-08-19 14:00:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:00:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:31 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:31 --> URI Class Initialized
INFO - 2023-08-19 14:00:31 --> Router Class Initialized
INFO - 2023-08-19 14:00:31 --> Output Class Initialized
INFO - 2023-08-19 14:00:31 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:31 --> Input Class Initialized
INFO - 2023-08-19 14:00:31 --> Language Class Initialized
ERROR - 2023-08-19 14:00:31 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-19 14:00:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:31 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:31 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:31 --> URI Class Initialized
INFO - 2023-08-19 14:00:31 --> URI Class Initialized
INFO - 2023-08-19 14:00:31 --> URI Class Initialized
INFO - 2023-08-19 14:00:31 --> Router Class Initialized
INFO - 2023-08-19 14:00:31 --> Router Class Initialized
INFO - 2023-08-19 14:00:31 --> Output Class Initialized
INFO - 2023-08-19 14:00:31 --> Security Class Initialized
INFO - 2023-08-19 14:00:31 --> Router Class Initialized
DEBUG - 2023-08-19 14:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:31 --> Output Class Initialized
INFO - 2023-08-19 14:00:31 --> Input Class Initialized
INFO - 2023-08-19 14:00:31 --> Security Class Initialized
INFO - 2023-08-19 14:00:31 --> Language Class Initialized
INFO - 2023-08-19 14:00:32 --> Output Class Initialized
DEBUG - 2023-08-19 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:32 --> Input Class Initialized
ERROR - 2023-08-19 14:00:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:32 --> Language Class Initialized
INFO - 2023-08-19 14:00:32 --> Security Class Initialized
ERROR - 2023-08-19 14:00:32 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:32 --> Input Class Initialized
INFO - 2023-08-19 14:00:32 --> Language Class Initialized
ERROR - 2023-08-19 14:00:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:48 --> Config Class Initialized
INFO - 2023-08-19 14:00:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:48 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:48 --> URI Class Initialized
INFO - 2023-08-19 14:00:48 --> Router Class Initialized
INFO - 2023-08-19 14:00:48 --> Output Class Initialized
INFO - 2023-08-19 14:00:48 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:48 --> Input Class Initialized
INFO - 2023-08-19 14:00:48 --> Language Class Initialized
INFO - 2023-08-19 14:00:48 --> Loader Class Initialized
INFO - 2023-08-19 14:00:48 --> Helper loaded: url_helper
INFO - 2023-08-19 14:00:48 --> Helper loaded: file_helper
INFO - 2023-08-19 14:00:48 --> Database Driver Class Initialized
INFO - 2023-08-19 14:00:49 --> Email Class Initialized
DEBUG - 2023-08-19 14:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:00:49 --> Controller Class Initialized
INFO - 2023-08-19 14:00:49 --> Model "Home_model" initialized
INFO - 2023-08-19 14:00:49 --> Helper loaded: form_helper
INFO - 2023-08-19 14:00:49 --> Form Validation Class Initialized
INFO - 2023-08-19 14:00:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 14:00:49 --> Final output sent to browser
DEBUG - 2023-08-19 14:00:49 --> Total execution time: 0.4872
INFO - 2023-08-19 14:00:51 --> Config Class Initialized
INFO - 2023-08-19 14:00:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:51 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:51 --> URI Class Initialized
INFO - 2023-08-19 14:00:51 --> Router Class Initialized
INFO - 2023-08-19 14:00:51 --> Output Class Initialized
INFO - 2023-08-19 14:00:51 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:51 --> Input Class Initialized
INFO - 2023-08-19 14:00:51 --> Language Class Initialized
ERROR - 2023-08-19 14:00:51 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:51 --> Config Class Initialized
INFO - 2023-08-19 14:00:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:51 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:51 --> URI Class Initialized
INFO - 2023-08-19 14:00:51 --> Router Class Initialized
INFO - 2023-08-19 14:00:51 --> Output Class Initialized
INFO - 2023-08-19 14:00:51 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:51 --> Input Class Initialized
INFO - 2023-08-19 14:00:51 --> Language Class Initialized
ERROR - 2023-08-19 14:00:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:51 --> Config Class Initialized
INFO - 2023-08-19 14:00:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:51 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:51 --> URI Class Initialized
INFO - 2023-08-19 14:00:51 --> Router Class Initialized
INFO - 2023-08-19 14:00:51 --> Output Class Initialized
INFO - 2023-08-19 14:00:51 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:51 --> Input Class Initialized
INFO - 2023-08-19 14:00:51 --> Language Class Initialized
ERROR - 2023-08-19 14:00:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:52 --> Config Class Initialized
INFO - 2023-08-19 14:00:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:52 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:52 --> URI Class Initialized
INFO - 2023-08-19 14:00:52 --> Router Class Initialized
INFO - 2023-08-19 14:00:52 --> Output Class Initialized
INFO - 2023-08-19 14:00:52 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:52 --> Input Class Initialized
INFO - 2023-08-19 14:00:52 --> Language Class Initialized
ERROR - 2023-08-19 14:00:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:52 --> Config Class Initialized
INFO - 2023-08-19 14:00:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:52 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:52 --> URI Class Initialized
INFO - 2023-08-19 14:00:52 --> Router Class Initialized
INFO - 2023-08-19 14:00:52 --> Output Class Initialized
INFO - 2023-08-19 14:00:52 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:52 --> Input Class Initialized
INFO - 2023-08-19 14:00:52 --> Language Class Initialized
ERROR - 2023-08-19 14:00:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:54 --> Config Class Initialized
INFO - 2023-08-19 14:00:54 --> Config Class Initialized
INFO - 2023-08-19 14:00:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:54 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:54 --> URI Class Initialized
INFO - 2023-08-19 14:00:54 --> Router Class Initialized
INFO - 2023-08-19 14:00:54 --> Output Class Initialized
INFO - 2023-08-19 14:00:54 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:54 --> Input Class Initialized
INFO - 2023-08-19 14:00:54 --> Language Class Initialized
ERROR - 2023-08-19 14:00:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:54 --> Config Class Initialized
INFO - 2023-08-19 14:00:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:54 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:54 --> URI Class Initialized
INFO - 2023-08-19 14:00:54 --> Router Class Initialized
INFO - 2023-08-19 14:00:54 --> Output Class Initialized
INFO - 2023-08-19 14:00:54 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:54 --> Input Class Initialized
INFO - 2023-08-19 14:00:54 --> Language Class Initialized
ERROR - 2023-08-19 14:00:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:54 --> Config Class Initialized
INFO - 2023-08-19 14:00:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:54 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:54 --> URI Class Initialized
INFO - 2023-08-19 14:00:54 --> Router Class Initialized
INFO - 2023-08-19 14:00:54 --> Output Class Initialized
INFO - 2023-08-19 14:00:54 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:54 --> Input Class Initialized
INFO - 2023-08-19 14:00:54 --> Language Class Initialized
ERROR - 2023-08-19 14:00:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:55 --> Config Class Initialized
INFO - 2023-08-19 14:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:55 --> URI Class Initialized
INFO - 2023-08-19 14:00:55 --> Router Class Initialized
INFO - 2023-08-19 14:00:55 --> Output Class Initialized
INFO - 2023-08-19 14:00:55 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:55 --> Input Class Initialized
INFO - 2023-08-19 14:00:55 --> Language Class Initialized
ERROR - 2023-08-19 14:00:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:55 --> Config Class Initialized
INFO - 2023-08-19 14:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:55 --> URI Class Initialized
INFO - 2023-08-19 14:00:55 --> Router Class Initialized
INFO - 2023-08-19 14:00:55 --> Output Class Initialized
INFO - 2023-08-19 14:00:55 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:55 --> Input Class Initialized
INFO - 2023-08-19 14:00:55 --> Language Class Initialized
ERROR - 2023-08-19 14:00:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:55 --> Config Class Initialized
INFO - 2023-08-19 14:00:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:55 --> URI Class Initialized
INFO - 2023-08-19 14:00:55 --> Router Class Initialized
INFO - 2023-08-19 14:00:55 --> Output Class Initialized
INFO - 2023-08-19 14:00:55 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:55 --> Input Class Initialized
INFO - 2023-08-19 14:00:55 --> Language Class Initialized
ERROR - 2023-08-19 14:00:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:55 --> Hooks Class Initialized
INFO - 2023-08-19 14:00:57 --> Config Class Initialized
INFO - 2023-08-19 14:00:57 --> Config Class Initialized
INFO - 2023-08-19 14:00:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:57 --> URI Class Initialized
INFO - 2023-08-19 14:00:57 --> Router Class Initialized
INFO - 2023-08-19 14:00:57 --> Output Class Initialized
INFO - 2023-08-19 14:00:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:57 --> Input Class Initialized
INFO - 2023-08-19 14:00:57 --> Language Class Initialized
ERROR - 2023-08-19 14:00:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:00:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:00:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:58 --> Config Class Initialized
DEBUG - 2023-08-19 14:00:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:00:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:59 --> URI Class Initialized
INFO - 2023-08-19 14:00:59 --> Router Class Initialized
INFO - 2023-08-19 14:00:59 --> Output Class Initialized
INFO - 2023-08-19 14:00:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:00:59 --> Input Class Initialized
INFO - 2023-08-19 14:00:59 --> Language Class Initialized
ERROR - 2023-08-19 14:00:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:00:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:00:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:00:59 --> URI Class Initialized
INFO - 2023-08-19 14:00:59 --> Router Class Initialized
DEBUG - 2023-08-19 14:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:01:00 --> Output Class Initialized
INFO - 2023-08-19 14:01:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:01:00 --> Security Class Initialized
INFO - 2023-08-19 14:01:00 --> URI Class Initialized
DEBUG - 2023-08-19 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:01:00 --> Input Class Initialized
INFO - 2023-08-19 14:01:00 --> Language Class Initialized
ERROR - 2023-08-19 14:01:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:01:00 --> Router Class Initialized
INFO - 2023-08-19 14:01:00 --> Output Class Initialized
INFO - 2023-08-19 14:01:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:01:00 --> Input Class Initialized
INFO - 2023-08-19 14:01:00 --> Language Class Initialized
ERROR - 2023-08-19 14:01:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:01:01 --> Config Class Initialized
INFO - 2023-08-19 14:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:01:01 --> Utf8 Class Initialized
INFO - 2023-08-19 14:01:01 --> URI Class Initialized
INFO - 2023-08-19 14:01:01 --> Router Class Initialized
INFO - 2023-08-19 14:01:01 --> Output Class Initialized
INFO - 2023-08-19 14:01:01 --> Security Class Initialized
DEBUG - 2023-08-19 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:01:01 --> Input Class Initialized
INFO - 2023-08-19 14:01:02 --> Language Class Initialized
ERROR - 2023-08-19 14:01:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:46 --> Config Class Initialized
INFO - 2023-08-19 14:05:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:46 --> URI Class Initialized
INFO - 2023-08-19 14:05:46 --> Router Class Initialized
INFO - 2023-08-19 14:05:47 --> Output Class Initialized
INFO - 2023-08-19 14:05:47 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:47 --> Input Class Initialized
INFO - 2023-08-19 14:05:47 --> Language Class Initialized
INFO - 2023-08-19 14:05:47 --> Loader Class Initialized
INFO - 2023-08-19 14:05:47 --> Helper loaded: url_helper
INFO - 2023-08-19 14:05:47 --> Helper loaded: file_helper
INFO - 2023-08-19 14:05:47 --> Database Driver Class Initialized
INFO - 2023-08-19 14:05:47 --> Email Class Initialized
DEBUG - 2023-08-19 14:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:05:47 --> Controller Class Initialized
INFO - 2023-08-19 14:05:47 --> Model "Home_model" initialized
INFO - 2023-08-19 14:05:47 --> Helper loaded: form_helper
INFO - 2023-08-19 14:05:47 --> Form Validation Class Initialized
INFO - 2023-08-19 14:05:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 14:05:48 --> Final output sent to browser
DEBUG - 2023-08-19 14:05:48 --> Total execution time: 1.9681
INFO - 2023-08-19 14:05:52 --> Config Class Initialized
INFO - 2023-08-19 14:05:53 --> Config Class Initialized
INFO - 2023-08-19 14:05:54 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:05:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:55 --> URI Class Initialized
INFO - 2023-08-19 14:05:55 --> URI Class Initialized
INFO - 2023-08-19 14:05:55 --> Router Class Initialized
INFO - 2023-08-19 14:05:55 --> Router Class Initialized
INFO - 2023-08-19 14:05:55 --> Output Class Initialized
INFO - 2023-08-19 14:05:55 --> Config Class Initialized
INFO - 2023-08-19 14:05:55 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:55 --> Config Class Initialized
INFO - 2023-08-19 14:05:55 --> Config Class Initialized
DEBUG - 2023-08-19 14:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:55 --> Security Class Initialized
INFO - 2023-08-19 14:05:55 --> Output Class Initialized
INFO - 2023-08-19 14:05:55 --> Config Class Initialized
INFO - 2023-08-19 14:05:55 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:56 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:56 --> URI Class Initialized
DEBUG - 2023-08-19 14:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:56 --> Input Class Initialized
INFO - 2023-08-19 14:05:56 --> Language Class Initialized
ERROR - 2023-08-19 14:05:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:56 --> Router Class Initialized
INFO - 2023-08-19 14:05:56 --> Input Class Initialized
INFO - 2023-08-19 14:05:56 --> Language Class Initialized
INFO - 2023-08-19 14:05:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:56 --> URI Class Initialized
INFO - 2023-08-19 14:05:56 --> Output Class Initialized
INFO - 2023-08-19 14:05:56 --> Router Class Initialized
ERROR - 2023-08-19 14:05:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:56 --> URI Class Initialized
INFO - 2023-08-19 14:05:56 --> URI Class Initialized
INFO - 2023-08-19 14:05:56 --> Security Class Initialized
INFO - 2023-08-19 14:05:56 --> Output Class Initialized
INFO - 2023-08-19 14:05:56 --> Router Class Initialized
DEBUG - 2023-08-19 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:56 --> Config Class Initialized
INFO - 2023-08-19 14:05:56 --> Security Class Initialized
INFO - 2023-08-19 14:05:56 --> Router Class Initialized
DEBUG - 2023-08-19 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:56 --> Output Class Initialized
INFO - 2023-08-19 14:05:56 --> Input Class Initialized
INFO - 2023-08-19 14:05:56 --> Output Class Initialized
INFO - 2023-08-19 14:05:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:57 --> URI Class Initialized
INFO - 2023-08-19 14:05:57 --> Router Class Initialized
INFO - 2023-08-19 14:05:57 --> Output Class Initialized
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
INFO - 2023-08-19 14:05:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:57 --> URI Class Initialized
INFO - 2023-08-19 14:05:57 --> Router Class Initialized
INFO - 2023-08-19 14:05:57 --> Output Class Initialized
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:57 --> URI Class Initialized
INFO - 2023-08-19 14:05:57 --> Router Class Initialized
INFO - 2023-08-19 14:05:57 --> Output Class Initialized
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Config Class Initialized
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:57 --> URI Class Initialized
INFO - 2023-08-19 14:05:57 --> Router Class Initialized
INFO - 2023-08-19 14:05:57 --> Output Class Initialized
INFO - 2023-08-19 14:05:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:57 --> Input Class Initialized
INFO - 2023-08-19 14:05:57 --> Language Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
ERROR - 2023-08-19 14:05:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:05:57 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:57 --> Hooks Class Initialized
INFO - 2023-08-19 14:05:57 --> URI Class Initialized
INFO - 2023-08-19 14:05:57 --> Router Class Initialized
DEBUG - 2023-08-19 14:05:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:05:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:58 --> URI Class Initialized
INFO - 2023-08-19 14:05:58 --> Router Class Initialized
INFO - 2023-08-19 14:05:58 --> Output Class Initialized
INFO - 2023-08-19 14:05:58 --> Security Class Initialized
DEBUG - 2023-08-19 14:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:58 --> Input Class Initialized
INFO - 2023-08-19 14:05:58 --> Language Class Initialized
ERROR - 2023-08-19 14:05:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:05:58 --> Output Class Initialized
INFO - 2023-08-19 14:05:58 --> Security Class Initialized
INFO - 2023-08-19 14:05:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:05:59 --> URI Class Initialized
DEBUG - 2023-08-19 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:59 --> Router Class Initialized
INFO - 2023-08-19 14:05:59 --> Input Class Initialized
INFO - 2023-08-19 14:05:59 --> Output Class Initialized
INFO - 2023-08-19 14:05:59 --> Language Class Initialized
INFO - 2023-08-19 14:05:59 --> Security Class Initialized
ERROR - 2023-08-19 14:05:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-19 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:05:59 --> Input Class Initialized
INFO - 2023-08-19 14:06:00 --> Language Class Initialized
ERROR - 2023-08-19 14:06:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:09:57 --> Config Class Initialized
INFO - 2023-08-19 14:09:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:09:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:09:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:09:57 --> URI Class Initialized
INFO - 2023-08-19 14:09:57 --> Router Class Initialized
INFO - 2023-08-19 14:09:57 --> Output Class Initialized
INFO - 2023-08-19 14:09:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:09:57 --> Input Class Initialized
INFO - 2023-08-19 14:09:57 --> Language Class Initialized
INFO - 2023-08-19 14:09:57 --> Loader Class Initialized
INFO - 2023-08-19 14:09:58 --> Helper loaded: url_helper
INFO - 2023-08-19 14:09:58 --> Helper loaded: file_helper
INFO - 2023-08-19 14:09:58 --> Database Driver Class Initialized
INFO - 2023-08-19 14:09:58 --> Email Class Initialized
DEBUG - 2023-08-19 14:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:09:58 --> Controller Class Initialized
INFO - 2023-08-19 14:09:58 --> Model "Home_model" initialized
INFO - 2023-08-19 14:09:58 --> Helper loaded: form_helper
INFO - 2023-08-19 14:09:58 --> Form Validation Class Initialized
INFO - 2023-08-19 14:09:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:09:58 --> Final output sent to browser
DEBUG - 2023-08-19 14:09:58 --> Total execution time: 0.9242
INFO - 2023-08-19 14:09:59 --> Config Class Initialized
INFO - 2023-08-19 14:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:09:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:09:59 --> URI Class Initialized
INFO - 2023-08-19 14:09:59 --> Router Class Initialized
INFO - 2023-08-19 14:09:59 --> Output Class Initialized
INFO - 2023-08-19 14:09:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:09:59 --> Input Class Initialized
INFO - 2023-08-19 14:09:59 --> Language Class Initialized
ERROR - 2023-08-19 14:09:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:09:59 --> Config Class Initialized
INFO - 2023-08-19 14:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:09:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:09:59 --> URI Class Initialized
INFO - 2023-08-19 14:09:59 --> Router Class Initialized
INFO - 2023-08-19 14:09:59 --> Output Class Initialized
INFO - 2023-08-19 14:09:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:09:59 --> Input Class Initialized
INFO - 2023-08-19 14:09:59 --> Language Class Initialized
ERROR - 2023-08-19 14:09:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:09:59 --> Config Class Initialized
INFO - 2023-08-19 14:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:09:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:09:59 --> URI Class Initialized
INFO - 2023-08-19 14:09:59 --> Router Class Initialized
INFO - 2023-08-19 14:09:59 --> Output Class Initialized
INFO - 2023-08-19 14:09:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:09:59 --> Input Class Initialized
INFO - 2023-08-19 14:09:59 --> Language Class Initialized
ERROR - 2023-08-19 14:09:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:09:59 --> Config Class Initialized
INFO - 2023-08-19 14:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:09:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:09:59 --> URI Class Initialized
INFO - 2023-08-19 14:09:59 --> Router Class Initialized
INFO - 2023-08-19 14:09:59 --> Output Class Initialized
INFO - 2023-08-19 14:09:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:09:59 --> Input Class Initialized
INFO - 2023-08-19 14:09:59 --> Language Class Initialized
ERROR - 2023-08-19 14:09:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:00 --> Config Class Initialized
INFO - 2023-08-19 14:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:00 --> URI Class Initialized
INFO - 2023-08-19 14:10:00 --> Router Class Initialized
INFO - 2023-08-19 14:10:00 --> Output Class Initialized
INFO - 2023-08-19 14:10:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:00 --> Input Class Initialized
INFO - 2023-08-19 14:10:00 --> Language Class Initialized
ERROR - 2023-08-19 14:10:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:00 --> Config Class Initialized
INFO - 2023-08-19 14:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:00 --> URI Class Initialized
INFO - 2023-08-19 14:10:00 --> Router Class Initialized
INFO - 2023-08-19 14:10:00 --> Output Class Initialized
INFO - 2023-08-19 14:10:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:00 --> Input Class Initialized
INFO - 2023-08-19 14:10:00 --> Language Class Initialized
ERROR - 2023-08-19 14:10:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:41 --> Config Class Initialized
INFO - 2023-08-19 14:10:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:41 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:41 --> URI Class Initialized
INFO - 2023-08-19 14:10:41 --> Router Class Initialized
INFO - 2023-08-19 14:10:41 --> Output Class Initialized
INFO - 2023-08-19 14:10:41 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:41 --> Input Class Initialized
INFO - 2023-08-19 14:10:41 --> Language Class Initialized
INFO - 2023-08-19 14:10:41 --> Loader Class Initialized
INFO - 2023-08-19 14:10:41 --> Helper loaded: url_helper
INFO - 2023-08-19 14:10:41 --> Helper loaded: file_helper
INFO - 2023-08-19 14:10:41 --> Database Driver Class Initialized
INFO - 2023-08-19 14:10:41 --> Email Class Initialized
DEBUG - 2023-08-19 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:10:41 --> Controller Class Initialized
INFO - 2023-08-19 14:10:41 --> Model "Home_model" initialized
INFO - 2023-08-19 14:10:41 --> Helper loaded: form_helper
INFO - 2023-08-19 14:10:41 --> Form Validation Class Initialized
INFO - 2023-08-19 14:10:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:10:41 --> Final output sent to browser
DEBUG - 2023-08-19 14:10:41 --> Total execution time: 0.8133
INFO - 2023-08-19 14:10:42 --> Config Class Initialized
INFO - 2023-08-19 14:10:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:42 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:42 --> URI Class Initialized
INFO - 2023-08-19 14:10:42 --> Router Class Initialized
INFO - 2023-08-19 14:10:42 --> Output Class Initialized
INFO - 2023-08-19 14:10:42 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:42 --> Input Class Initialized
INFO - 2023-08-19 14:10:42 --> Language Class Initialized
ERROR - 2023-08-19 14:10:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:42 --> Config Class Initialized
INFO - 2023-08-19 14:10:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:42 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:42 --> URI Class Initialized
INFO - 2023-08-19 14:10:42 --> Router Class Initialized
INFO - 2023-08-19 14:10:42 --> Output Class Initialized
INFO - 2023-08-19 14:10:42 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:42 --> Input Class Initialized
INFO - 2023-08-19 14:10:42 --> Language Class Initialized
ERROR - 2023-08-19 14:10:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:42 --> Config Class Initialized
INFO - 2023-08-19 14:10:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:42 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:42 --> URI Class Initialized
INFO - 2023-08-19 14:10:42 --> Router Class Initialized
INFO - 2023-08-19 14:10:42 --> Output Class Initialized
INFO - 2023-08-19 14:10:42 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:42 --> Input Class Initialized
INFO - 2023-08-19 14:10:42 --> Language Class Initialized
ERROR - 2023-08-19 14:10:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:42 --> Config Class Initialized
INFO - 2023-08-19 14:10:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:42 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:42 --> URI Class Initialized
INFO - 2023-08-19 14:10:42 --> Router Class Initialized
INFO - 2023-08-19 14:10:42 --> Output Class Initialized
INFO - 2023-08-19 14:10:42 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:42 --> Input Class Initialized
INFO - 2023-08-19 14:10:42 --> Language Class Initialized
ERROR - 2023-08-19 14:10:42 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:43 --> Config Class Initialized
INFO - 2023-08-19 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:43 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:43 --> URI Class Initialized
INFO - 2023-08-19 14:10:43 --> Router Class Initialized
INFO - 2023-08-19 14:10:43 --> Output Class Initialized
INFO - 2023-08-19 14:10:43 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:43 --> Input Class Initialized
INFO - 2023-08-19 14:10:43 --> Language Class Initialized
ERROR - 2023-08-19 14:10:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:43 --> Config Class Initialized
INFO - 2023-08-19 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:43 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:43 --> URI Class Initialized
INFO - 2023-08-19 14:10:43 --> Router Class Initialized
INFO - 2023-08-19 14:10:43 --> Output Class Initialized
INFO - 2023-08-19 14:10:43 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:43 --> Input Class Initialized
INFO - 2023-08-19 14:10:43 --> Language Class Initialized
ERROR - 2023-08-19 14:10:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:43 --> Config Class Initialized
INFO - 2023-08-19 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:43 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:43 --> URI Class Initialized
INFO - 2023-08-19 14:10:43 --> Router Class Initialized
INFO - 2023-08-19 14:10:43 --> Output Class Initialized
INFO - 2023-08-19 14:10:43 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:43 --> Input Class Initialized
INFO - 2023-08-19 14:10:43 --> Language Class Initialized
ERROR - 2023-08-19 14:10:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:43 --> Config Class Initialized
INFO - 2023-08-19 14:10:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:44 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:44 --> URI Class Initialized
INFO - 2023-08-19 14:10:44 --> Router Class Initialized
INFO - 2023-08-19 14:10:44 --> Output Class Initialized
INFO - 2023-08-19 14:10:44 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:44 --> Input Class Initialized
INFO - 2023-08-19 14:10:44 --> Language Class Initialized
ERROR - 2023-08-19 14:10:44 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:56 --> Config Class Initialized
INFO - 2023-08-19 14:10:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:56 --> URI Class Initialized
INFO - 2023-08-19 14:10:56 --> Router Class Initialized
INFO - 2023-08-19 14:10:56 --> Output Class Initialized
INFO - 2023-08-19 14:10:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:56 --> Input Class Initialized
INFO - 2023-08-19 14:10:56 --> Language Class Initialized
INFO - 2023-08-19 14:10:56 --> Loader Class Initialized
INFO - 2023-08-19 14:10:56 --> Helper loaded: url_helper
INFO - 2023-08-19 14:10:56 --> Helper loaded: file_helper
INFO - 2023-08-19 14:10:56 --> Database Driver Class Initialized
INFO - 2023-08-19 14:10:56 --> Email Class Initialized
DEBUG - 2023-08-19 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:10:56 --> Controller Class Initialized
INFO - 2023-08-19 14:10:56 --> Model "Home_model" initialized
INFO - 2023-08-19 14:10:56 --> Helper loaded: form_helper
INFO - 2023-08-19 14:10:56 --> Form Validation Class Initialized
INFO - 2023-08-19 14:10:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:10:57 --> Final output sent to browser
DEBUG - 2023-08-19 14:10:57 --> Total execution time: 0.8759
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:57 --> Config Class Initialized
INFO - 2023-08-19 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:57 --> URI Class Initialized
INFO - 2023-08-19 14:10:57 --> Router Class Initialized
INFO - 2023-08-19 14:10:57 --> Output Class Initialized
INFO - 2023-08-19 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:57 --> Input Class Initialized
INFO - 2023-08-19 14:10:57 --> Language Class Initialized
ERROR - 2023-08-19 14:10:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:10:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:10:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:10:58 --> URI Class Initialized
INFO - 2023-08-19 14:10:58 --> Router Class Initialized
INFO - 2023-08-19 14:10:58 --> Output Class Initialized
INFO - 2023-08-19 14:10:58 --> Security Class Initialized
DEBUG - 2023-08-19 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:10:58 --> Input Class Initialized
INFO - 2023-08-19 14:10:58 --> Language Class Initialized
ERROR - 2023-08-19 14:10:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:12:51 --> Config Class Initialized
INFO - 2023-08-19 14:12:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:51 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:51 --> URI Class Initialized
INFO - 2023-08-19 14:12:51 --> Router Class Initialized
INFO - 2023-08-19 14:12:51 --> Output Class Initialized
INFO - 2023-08-19 14:12:51 --> Security Class Initialized
DEBUG - 2023-08-19 14:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:51 --> Input Class Initialized
INFO - 2023-08-19 14:12:51 --> Language Class Initialized
INFO - 2023-08-19 14:12:51 --> Loader Class Initialized
INFO - 2023-08-19 14:12:51 --> Helper loaded: url_helper
INFO - 2023-08-19 14:12:51 --> Helper loaded: file_helper
INFO - 2023-08-19 14:12:52 --> Database Driver Class Initialized
INFO - 2023-08-19 14:12:52 --> Email Class Initialized
DEBUG - 2023-08-19 14:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:12:52 --> Controller Class Initialized
INFO - 2023-08-19 14:12:52 --> Model "Home_model" initialized
INFO - 2023-08-19 14:12:52 --> Helper loaded: form_helper
INFO - 2023-08-19 14:12:52 --> Form Validation Class Initialized
INFO - 2023-08-19 14:12:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:12:52 --> Final output sent to browser
DEBUG - 2023-08-19 14:12:52 --> Total execution time: 0.8094
INFO - 2023-08-19 14:12:52 --> Config Class Initialized
INFO - 2023-08-19 14:12:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:52 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:52 --> URI Class Initialized
INFO - 2023-08-19 14:12:52 --> Router Class Initialized
INFO - 2023-08-19 14:12:52 --> Output Class Initialized
INFO - 2023-08-19 14:12:52 --> Security Class Initialized
DEBUG - 2023-08-19 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:52 --> Input Class Initialized
INFO - 2023-08-19 14:12:52 --> Language Class Initialized
ERROR - 2023-08-19 14:12:52 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:12:52 --> Config Class Initialized
INFO - 2023-08-19 14:12:53 --> Config Class Initialized
INFO - 2023-08-19 14:12:53 --> Config Class Initialized
INFO - 2023-08-19 14:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:12:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:12:53 --> Config Class Initialized
INFO - 2023-08-19 14:12:53 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:12:53 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:53 --> URI Class Initialized
INFO - 2023-08-19 14:12:53 --> URI Class Initialized
INFO - 2023-08-19 14:12:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:53 --> Router Class Initialized
INFO - 2023-08-19 14:12:53 --> Router Class Initialized
DEBUG - 2023-08-19 14:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:12:53 --> Output Class Initialized
INFO - 2023-08-19 14:12:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:12:53 --> URI Class Initialized
INFO - 2023-08-19 14:12:53 --> Router Class Initialized
INFO - 2023-08-19 14:12:53 --> Security Class Initialized
INFO - 2023-08-19 14:12:53 --> URI Class Initialized
INFO - 2023-08-19 14:12:53 --> Output Class Initialized
DEBUG - 2023-08-19 14:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:53 --> Input Class Initialized
INFO - 2023-08-19 14:12:53 --> Output Class Initialized
INFO - 2023-08-19 14:12:53 --> Language Class Initialized
INFO - 2023-08-19 14:12:53 --> Router Class Initialized
INFO - 2023-08-19 14:12:53 --> Security Class Initialized
INFO - 2023-08-19 14:12:53 --> Security Class Initialized
INFO - 2023-08-19 14:12:53 --> Output Class Initialized
ERROR - 2023-08-19 14:12:53 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:53 --> Security Class Initialized
INFO - 2023-08-19 14:12:53 --> Input Class Initialized
DEBUG - 2023-08-19 14:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:12:53 --> Language Class Initialized
INFO - 2023-08-19 14:12:53 --> Input Class Initialized
INFO - 2023-08-19 14:12:53 --> Language Class Initialized
DEBUG - 2023-08-19 14:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:12:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:12:53 --> Input Class Initialized
ERROR - 2023-08-19 14:12:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:12:53 --> Language Class Initialized
ERROR - 2023-08-19 14:12:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:13:01 --> Config Class Initialized
INFO - 2023-08-19 14:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:01 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:01 --> URI Class Initialized
INFO - 2023-08-19 14:13:01 --> Router Class Initialized
INFO - 2023-08-19 14:13:01 --> Output Class Initialized
INFO - 2023-08-19 14:13:01 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:01 --> Input Class Initialized
INFO - 2023-08-19 14:13:01 --> Language Class Initialized
INFO - 2023-08-19 14:13:01 --> Loader Class Initialized
INFO - 2023-08-19 14:13:01 --> Helper loaded: url_helper
INFO - 2023-08-19 14:13:01 --> Helper loaded: file_helper
INFO - 2023-08-19 14:13:01 --> Database Driver Class Initialized
INFO - 2023-08-19 14:13:01 --> Email Class Initialized
DEBUG - 2023-08-19 14:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:13:01 --> Controller Class Initialized
INFO - 2023-08-19 14:13:01 --> Model "Home_model" initialized
INFO - 2023-08-19 14:13:01 --> Helper loaded: form_helper
INFO - 2023-08-19 14:13:01 --> Form Validation Class Initialized
INFO - 2023-08-19 14:13:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:13:01 --> Final output sent to browser
DEBUG - 2023-08-19 14:13:01 --> Total execution time: 0.4794
INFO - 2023-08-19 14:13:03 --> Config Class Initialized
INFO - 2023-08-19 14:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:03 --> URI Class Initialized
INFO - 2023-08-19 14:13:03 --> Router Class Initialized
INFO - 2023-08-19 14:13:03 --> Output Class Initialized
INFO - 2023-08-19 14:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:03 --> Input Class Initialized
INFO - 2023-08-19 14:13:03 --> Language Class Initialized
ERROR - 2023-08-19 14:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:13:03 --> Config Class Initialized
INFO - 2023-08-19 14:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:03 --> Config Class Initialized
INFO - 2023-08-19 14:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:03 --> URI Class Initialized
INFO - 2023-08-19 14:13:03 --> Config Class Initialized
INFO - 2023-08-19 14:13:03 --> Hooks Class Initialized
INFO - 2023-08-19 14:13:03 --> Hooks Class Initialized
INFO - 2023-08-19 14:13:03 --> Config Class Initialized
DEBUG - 2023-08-19 14:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:03 --> Router Class Initialized
DEBUG - 2023-08-19 14:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:03 --> Hooks Class Initialized
INFO - 2023-08-19 14:13:03 --> URI Class Initialized
INFO - 2023-08-19 14:13:03 --> Output Class Initialized
INFO - 2023-08-19 14:13:03 --> Security Class Initialized
INFO - 2023-08-19 14:13:03 --> Router Class Initialized
INFO - 2023-08-19 14:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 14:13:03 --> URI Class Initialized
INFO - 2023-08-19 14:13:03 --> Output Class Initialized
INFO - 2023-08-19 14:13:03 --> Router Class Initialized
DEBUG - 2023-08-19 14:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:13:03 --> Output Class Initialized
DEBUG - 2023-08-19 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:03 --> Security Class Initialized
INFO - 2023-08-19 14:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:03 --> Input Class Initialized
INFO - 2023-08-19 14:13:03 --> Language Class Initialized
INFO - 2023-08-19 14:13:03 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:13:03 --> Input Class Initialized
INFO - 2023-08-19 14:13:03 --> Input Class Initialized
INFO - 2023-08-19 14:13:03 --> Language Class Initialized
INFO - 2023-08-19 14:13:03 --> URI Class Initialized
INFO - 2023-08-19 14:13:03 --> Language Class Initialized
INFO - 2023-08-19 14:13:03 --> Router Class Initialized
ERROR - 2023-08-19 14:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:13:03 --> Output Class Initialized
ERROR - 2023-08-19 14:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:13:04 --> Input Class Initialized
INFO - 2023-08-19 14:13:04 --> Language Class Initialized
ERROR - 2023-08-19 14:13:04 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:25 --> Config Class Initialized
INFO - 2023-08-19 14:14:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:14:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:25 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:25 --> URI Class Initialized
INFO - 2023-08-19 14:14:25 --> Router Class Initialized
INFO - 2023-08-19 14:14:25 --> Output Class Initialized
INFO - 2023-08-19 14:14:25 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:25 --> Input Class Initialized
INFO - 2023-08-19 14:14:25 --> Language Class Initialized
INFO - 2023-08-19 14:14:25 --> Loader Class Initialized
INFO - 2023-08-19 14:14:25 --> Helper loaded: url_helper
INFO - 2023-08-19 14:14:25 --> Helper loaded: file_helper
INFO - 2023-08-19 14:14:25 --> Database Driver Class Initialized
INFO - 2023-08-19 14:14:25 --> Email Class Initialized
DEBUG - 2023-08-19 14:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:14:25 --> Controller Class Initialized
INFO - 2023-08-19 14:14:25 --> Model "Home_model" initialized
INFO - 2023-08-19 14:14:25 --> Helper loaded: form_helper
INFO - 2023-08-19 14:14:25 --> Form Validation Class Initialized
INFO - 2023-08-19 14:14:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:14:25 --> Final output sent to browser
DEBUG - 2023-08-19 14:14:25 --> Total execution time: 0.4498
INFO - 2023-08-19 14:14:26 --> Config Class Initialized
INFO - 2023-08-19 14:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:26 --> URI Class Initialized
INFO - 2023-08-19 14:14:26 --> Router Class Initialized
INFO - 2023-08-19 14:14:26 --> Output Class Initialized
INFO - 2023-08-19 14:14:26 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:26 --> Input Class Initialized
INFO - 2023-08-19 14:14:26 --> Language Class Initialized
ERROR - 2023-08-19 14:14:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:26 --> Config Class Initialized
INFO - 2023-08-19 14:14:26 --> Config Class Initialized
INFO - 2023-08-19 14:14:26 --> Config Class Initialized
INFO - 2023-08-19 14:14:26 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:26 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:26 --> Config Class Initialized
INFO - 2023-08-19 14:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:26 --> URI Class Initialized
DEBUG - 2023-08-19 14:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:26 --> Router Class Initialized
INFO - 2023-08-19 14:14:26 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:26 --> URI Class Initialized
INFO - 2023-08-19 14:14:26 --> Router Class Initialized
INFO - 2023-08-19 14:14:26 --> Output Class Initialized
INFO - 2023-08-19 14:14:26 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:26 --> Input Class Initialized
INFO - 2023-08-19 14:14:26 --> Language Class Initialized
ERROR - 2023-08-19 14:14:26 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:26 --> Output Class Initialized
INFO - 2023-08-19 14:14:26 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:26 --> URI Class Initialized
INFO - 2023-08-19 14:14:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:26 --> Security Class Initialized
INFO - 2023-08-19 14:14:26 --> Router Class Initialized
DEBUG - 2023-08-19 14:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:27 --> URI Class Initialized
INFO - 2023-08-19 14:14:27 --> Input Class Initialized
INFO - 2023-08-19 14:14:27 --> Output Class Initialized
INFO - 2023-08-19 14:14:27 --> Language Class Initialized
INFO - 2023-08-19 14:14:27 --> Router Class Initialized
ERROR - 2023-08-19 14:14:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:27 --> Output Class Initialized
INFO - 2023-08-19 14:14:27 --> Security Class Initialized
INFO - 2023-08-19 14:14:27 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:27 --> Input Class Initialized
INFO - 2023-08-19 14:14:27 --> Input Class Initialized
INFO - 2023-08-19 14:14:27 --> Language Class Initialized
INFO - 2023-08-19 14:14:27 --> Language Class Initialized
ERROR - 2023-08-19 14:14:27 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:14:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:44 --> Config Class Initialized
INFO - 2023-08-19 14:14:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:14:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:44 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:44 --> URI Class Initialized
INFO - 2023-08-19 14:14:44 --> Router Class Initialized
INFO - 2023-08-19 14:14:44 --> Output Class Initialized
INFO - 2023-08-19 14:14:44 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:44 --> Input Class Initialized
INFO - 2023-08-19 14:14:44 --> Language Class Initialized
INFO - 2023-08-19 14:14:44 --> Loader Class Initialized
INFO - 2023-08-19 14:14:44 --> Helper loaded: url_helper
INFO - 2023-08-19 14:14:44 --> Helper loaded: file_helper
INFO - 2023-08-19 14:14:44 --> Database Driver Class Initialized
INFO - 2023-08-19 14:14:44 --> Email Class Initialized
DEBUG - 2023-08-19 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:14:44 --> Controller Class Initialized
INFO - 2023-08-19 14:14:44 --> Model "Home_model" initialized
INFO - 2023-08-19 14:14:44 --> Helper loaded: form_helper
INFO - 2023-08-19 14:14:44 --> Form Validation Class Initialized
INFO - 2023-08-19 14:14:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:14:44 --> Final output sent to browser
DEBUG - 2023-08-19 14:14:45 --> Total execution time: 0.4450
INFO - 2023-08-19 14:14:46 --> Config Class Initialized
INFO - 2023-08-19 14:14:46 --> Config Class Initialized
INFO - 2023-08-19 14:14:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:14:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:46 --> Config Class Initialized
INFO - 2023-08-19 14:14:46 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:46 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:46 --> URI Class Initialized
INFO - 2023-08-19 14:14:46 --> Router Class Initialized
DEBUG - 2023-08-19 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:14:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:46 --> Output Class Initialized
INFO - 2023-08-19 14:14:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:46 --> Security Class Initialized
INFO - 2023-08-19 14:14:46 --> URI Class Initialized
INFO - 2023-08-19 14:14:46 --> Router Class Initialized
INFO - 2023-08-19 14:14:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:46 --> Output Class Initialized
INFO - 2023-08-19 14:14:46 --> URI Class Initialized
DEBUG - 2023-08-19 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:46 --> Router Class Initialized
INFO - 2023-08-19 14:14:46 --> Security Class Initialized
INFO - 2023-08-19 14:14:46 --> Input Class Initialized
DEBUG - 2023-08-19 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:46 --> Language Class Initialized
ERROR - 2023-08-19 14:14:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:47 --> Input Class Initialized
INFO - 2023-08-19 14:14:47 --> Output Class Initialized
INFO - 2023-08-19 14:14:47 --> Security Class Initialized
INFO - 2023-08-19 14:14:47 --> Language Class Initialized
DEBUG - 2023-08-19 14:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:14:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:47 --> Input Class Initialized
INFO - 2023-08-19 14:14:47 --> Language Class Initialized
ERROR - 2023-08-19 14:14:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:14:47 --> Config Class Initialized
INFO - 2023-08-19 14:14:47 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:47 --> Config Class Initialized
DEBUG - 2023-08-19 14:14:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:47 --> Hooks Class Initialized
INFO - 2023-08-19 14:14:47 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:14:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:14:47 --> URI Class Initialized
INFO - 2023-08-19 14:14:47 --> Utf8 Class Initialized
INFO - 2023-08-19 14:14:47 --> Router Class Initialized
INFO - 2023-08-19 14:14:47 --> URI Class Initialized
INFO - 2023-08-19 14:14:47 --> Router Class Initialized
INFO - 2023-08-19 14:14:47 --> Output Class Initialized
INFO - 2023-08-19 14:14:47 --> Output Class Initialized
INFO - 2023-08-19 14:14:47 --> Security Class Initialized
INFO - 2023-08-19 14:14:47 --> Security Class Initialized
DEBUG - 2023-08-19 14:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:14:47 --> Input Class Initialized
INFO - 2023-08-19 14:14:47 --> Input Class Initialized
INFO - 2023-08-19 14:14:47 --> Language Class Initialized
INFO - 2023-08-19 14:14:47 --> Language Class Initialized
ERROR - 2023-08-19 14:14:47 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:14:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:31 --> Config Class Initialized
INFO - 2023-08-19 14:15:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:31 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:31 --> URI Class Initialized
INFO - 2023-08-19 14:15:31 --> Router Class Initialized
INFO - 2023-08-19 14:15:31 --> Output Class Initialized
INFO - 2023-08-19 14:15:31 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:31 --> Input Class Initialized
INFO - 2023-08-19 14:15:31 --> Language Class Initialized
INFO - 2023-08-19 14:15:31 --> Loader Class Initialized
INFO - 2023-08-19 14:15:31 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:31 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:31 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:31 --> Email Class Initialized
DEBUG - 2023-08-19 14:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:31 --> Controller Class Initialized
INFO - 2023-08-19 14:15:31 --> Model "Home_model" initialized
INFO - 2023-08-19 14:15:31 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:31 --> Form Validation Class Initialized
INFO - 2023-08-19 14:15:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:15:31 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:31 --> Total execution time: 0.4245
INFO - 2023-08-19 14:15:32 --> Config Class Initialized
INFO - 2023-08-19 14:15:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:32 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:32 --> URI Class Initialized
INFO - 2023-08-19 14:15:32 --> Router Class Initialized
INFO - 2023-08-19 14:15:32 --> Output Class Initialized
INFO - 2023-08-19 14:15:32 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:32 --> Input Class Initialized
INFO - 2023-08-19 14:15:32 --> Language Class Initialized
ERROR - 2023-08-19 14:15:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:32 --> Config Class Initialized
INFO - 2023-08-19 14:15:32 --> Config Class Initialized
INFO - 2023-08-19 14:15:32 --> Hooks Class Initialized
INFO - 2023-08-19 14:15:32 --> Config Class Initialized
INFO - 2023-08-19 14:15:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:32 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:15:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:32 --> Config Class Initialized
INFO - 2023-08-19 14:15:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:32 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:32 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:32 --> URI Class Initialized
INFO - 2023-08-19 14:15:33 --> Router Class Initialized
INFO - 2023-08-19 14:15:33 --> Hooks Class Initialized
INFO - 2023-08-19 14:15:33 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:33 --> URI Class Initialized
INFO - 2023-08-19 14:15:33 --> URI Class Initialized
INFO - 2023-08-19 14:15:33 --> Output Class Initialized
DEBUG - 2023-08-19 14:15:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:33 --> Router Class Initialized
INFO - 2023-08-19 14:15:33 --> Router Class Initialized
INFO - 2023-08-19 14:15:33 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:33 --> Security Class Initialized
INFO - 2023-08-19 14:15:33 --> Output Class Initialized
INFO - 2023-08-19 14:15:33 --> Output Class Initialized
INFO - 2023-08-19 14:15:33 --> Security Class Initialized
INFO - 2023-08-19 14:15:33 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:33 --> URI Class Initialized
INFO - 2023-08-19 14:15:33 --> Input Class Initialized
DEBUG - 2023-08-19 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:33 --> Language Class Initialized
INFO - 2023-08-19 14:15:33 --> Router Class Initialized
DEBUG - 2023-08-19 14:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:15:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:33 --> Output Class Initialized
INFO - 2023-08-19 14:15:33 --> Input Class Initialized
INFO - 2023-08-19 14:15:33 --> Language Class Initialized
INFO - 2023-08-19 14:15:33 --> Security Class Initialized
INFO - 2023-08-19 14:15:33 --> Input Class Initialized
DEBUG - 2023-08-19 14:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:15:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:33 --> Input Class Initialized
INFO - 2023-08-19 14:15:33 --> Language Class Initialized
INFO - 2023-08-19 14:15:33 --> Language Class Initialized
ERROR - 2023-08-19 14:15:33 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:15:33 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:54 --> Config Class Initialized
INFO - 2023-08-19 14:15:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:54 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:54 --> URI Class Initialized
INFO - 2023-08-19 14:15:54 --> Router Class Initialized
INFO - 2023-08-19 14:15:54 --> Output Class Initialized
INFO - 2023-08-19 14:15:54 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:54 --> Input Class Initialized
INFO - 2023-08-19 14:15:54 --> Language Class Initialized
INFO - 2023-08-19 14:15:54 --> Loader Class Initialized
INFO - 2023-08-19 14:15:54 --> Helper loaded: url_helper
INFO - 2023-08-19 14:15:54 --> Helper loaded: file_helper
INFO - 2023-08-19 14:15:54 --> Database Driver Class Initialized
INFO - 2023-08-19 14:15:54 --> Email Class Initialized
DEBUG - 2023-08-19 14:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:15:54 --> Controller Class Initialized
INFO - 2023-08-19 14:15:54 --> Model "Home_model" initialized
INFO - 2023-08-19 14:15:54 --> Helper loaded: form_helper
INFO - 2023-08-19 14:15:54 --> Form Validation Class Initialized
INFO - 2023-08-19 14:15:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:15:55 --> Final output sent to browser
DEBUG - 2023-08-19 14:15:55 --> Total execution time: 0.5100
INFO - 2023-08-19 14:15:55 --> Config Class Initialized
INFO - 2023-08-19 14:15:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:55 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:55 --> URI Class Initialized
INFO - 2023-08-19 14:15:55 --> Router Class Initialized
INFO - 2023-08-19 14:15:55 --> Output Class Initialized
INFO - 2023-08-19 14:15:55 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:56 --> Input Class Initialized
INFO - 2023-08-19 14:15:56 --> Language Class Initialized
ERROR - 2023-08-19 14:15:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:56 --> Config Class Initialized
INFO - 2023-08-19 14:15:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:56 --> Config Class Initialized
INFO - 2023-08-19 14:15:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:15:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:56 --> Config Class Initialized
INFO - 2023-08-19 14:15:56 --> URI Class Initialized
INFO - 2023-08-19 14:15:56 --> Hooks Class Initialized
INFO - 2023-08-19 14:15:56 --> Config Class Initialized
INFO - 2023-08-19 14:15:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:56 --> URI Class Initialized
INFO - 2023-08-19 14:15:56 --> Router Class Initialized
DEBUG - 2023-08-19 14:15:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:15:56 --> Hooks Class Initialized
INFO - 2023-08-19 14:15:56 --> Router Class Initialized
INFO - 2023-08-19 14:15:56 --> Output Class Initialized
INFO - 2023-08-19 14:15:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:56 --> Output Class Initialized
INFO - 2023-08-19 14:15:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:56 --> URI Class Initialized
INFO - 2023-08-19 14:15:56 --> Input Class Initialized
INFO - 2023-08-19 14:15:56 --> Utf8 Class Initialized
INFO - 2023-08-19 14:15:56 --> Security Class Initialized
INFO - 2023-08-19 14:15:56 --> Language Class Initialized
INFO - 2023-08-19 14:15:56 --> Router Class Initialized
DEBUG - 2023-08-19 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:56 --> Input Class Initialized
INFO - 2023-08-19 14:15:56 --> Language Class Initialized
ERROR - 2023-08-19 14:15:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:56 --> Output Class Initialized
INFO - 2023-08-19 14:15:56 --> URI Class Initialized
INFO - 2023-08-19 14:15:56 --> Router Class Initialized
INFO - 2023-08-19 14:15:56 --> Output Class Initialized
INFO - 2023-08-19 14:15:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:56 --> Input Class Initialized
INFO - 2023-08-19 14:15:56 --> Language Class Initialized
ERROR - 2023-08-19 14:15:56 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:15:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:15:56 --> Security Class Initialized
DEBUG - 2023-08-19 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:15:56 --> Input Class Initialized
INFO - 2023-08-19 14:15:56 --> Language Class Initialized
ERROR - 2023-08-19 14:15:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:08 --> Config Class Initialized
INFO - 2023-08-19 14:16:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:08 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:08 --> URI Class Initialized
INFO - 2023-08-19 14:16:08 --> Router Class Initialized
INFO - 2023-08-19 14:16:08 --> Output Class Initialized
INFO - 2023-08-19 14:16:08 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:08 --> Input Class Initialized
INFO - 2023-08-19 14:16:08 --> Language Class Initialized
INFO - 2023-08-19 14:16:08 --> Loader Class Initialized
INFO - 2023-08-19 14:16:08 --> Helper loaded: url_helper
INFO - 2023-08-19 14:16:08 --> Helper loaded: file_helper
INFO - 2023-08-19 14:16:08 --> Database Driver Class Initialized
INFO - 2023-08-19 14:16:08 --> Email Class Initialized
DEBUG - 2023-08-19 14:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:16:09 --> Controller Class Initialized
INFO - 2023-08-19 14:16:09 --> Model "Home_model" initialized
INFO - 2023-08-19 14:16:09 --> Helper loaded: form_helper
INFO - 2023-08-19 14:16:09 --> Form Validation Class Initialized
INFO - 2023-08-19 14:16:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:16:09 --> Final output sent to browser
DEBUG - 2023-08-19 14:16:09 --> Total execution time: 0.5526
INFO - 2023-08-19 14:16:09 --> Config Class Initialized
INFO - 2023-08-19 14:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:09 --> URI Class Initialized
INFO - 2023-08-19 14:16:09 --> Router Class Initialized
INFO - 2023-08-19 14:16:09 --> Output Class Initialized
INFO - 2023-08-19 14:16:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:09 --> Input Class Initialized
INFO - 2023-08-19 14:16:09 --> Language Class Initialized
ERROR - 2023-08-19 14:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:09 --> Config Class Initialized
INFO - 2023-08-19 14:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:09 --> URI Class Initialized
INFO - 2023-08-19 14:16:09 --> Router Class Initialized
INFO - 2023-08-19 14:16:09 --> Output Class Initialized
INFO - 2023-08-19 14:16:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:09 --> Input Class Initialized
INFO - 2023-08-19 14:16:09 --> Language Class Initialized
ERROR - 2023-08-19 14:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:09 --> Config Class Initialized
INFO - 2023-08-19 14:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:09 --> URI Class Initialized
INFO - 2023-08-19 14:16:09 --> Router Class Initialized
INFO - 2023-08-19 14:16:09 --> Output Class Initialized
INFO - 2023-08-19 14:16:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:09 --> Input Class Initialized
INFO - 2023-08-19 14:16:09 --> Language Class Initialized
ERROR - 2023-08-19 14:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:09 --> Config Class Initialized
INFO - 2023-08-19 14:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:09 --> URI Class Initialized
INFO - 2023-08-19 14:16:09 --> Router Class Initialized
INFO - 2023-08-19 14:16:09 --> Output Class Initialized
INFO - 2023-08-19 14:16:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:09 --> Input Class Initialized
INFO - 2023-08-19 14:16:09 --> Language Class Initialized
ERROR - 2023-08-19 14:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:09 --> Config Class Initialized
INFO - 2023-08-19 14:16:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:09 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:09 --> URI Class Initialized
INFO - 2023-08-19 14:16:09 --> Router Class Initialized
INFO - 2023-08-19 14:16:09 --> Output Class Initialized
INFO - 2023-08-19 14:16:09 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:09 --> Input Class Initialized
INFO - 2023-08-19 14:16:09 --> Language Class Initialized
ERROR - 2023-08-19 14:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:16:58 --> Config Class Initialized
INFO - 2023-08-19 14:16:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:58 --> URI Class Initialized
INFO - 2023-08-19 14:16:58 --> Router Class Initialized
INFO - 2023-08-19 14:16:58 --> Output Class Initialized
INFO - 2023-08-19 14:16:58 --> Security Class Initialized
DEBUG - 2023-08-19 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:16:58 --> Input Class Initialized
INFO - 2023-08-19 14:16:58 --> Language Class Initialized
INFO - 2023-08-19 14:16:58 --> Loader Class Initialized
INFO - 2023-08-19 14:16:58 --> Helper loaded: url_helper
INFO - 2023-08-19 14:16:58 --> Helper loaded: file_helper
INFO - 2023-08-19 14:16:58 --> Database Driver Class Initialized
INFO - 2023-08-19 14:16:58 --> Email Class Initialized
DEBUG - 2023-08-19 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:16:58 --> Controller Class Initialized
INFO - 2023-08-19 14:16:58 --> Model "Home_model" initialized
INFO - 2023-08-19 14:16:58 --> Helper loaded: form_helper
INFO - 2023-08-19 14:16:58 --> Form Validation Class Initialized
INFO - 2023-08-19 14:16:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:16:58 --> Final output sent to browser
DEBUG - 2023-08-19 14:16:59 --> Total execution time: 0.4459
INFO - 2023-08-19 14:16:59 --> Config Class Initialized
INFO - 2023-08-19 14:16:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:16:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:59 --> Config Class Initialized
INFO - 2023-08-19 14:16:59 --> Config Class Initialized
INFO - 2023-08-19 14:16:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:16:59 --> Config Class Initialized
INFO - 2023-08-19 14:16:59 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:16:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:59 --> Config Class Initialized
INFO - 2023-08-19 14:16:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:16:59 --> URI Class Initialized
INFO - 2023-08-19 14:16:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:16:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:16:59 --> Router Class Initialized
DEBUG - 2023-08-19 14:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:16:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:16:59 --> URI Class Initialized
INFO - 2023-08-19 14:16:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:17:00 --> Output Class Initialized
INFO - 2023-08-19 14:17:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:17:00 --> Router Class Initialized
INFO - 2023-08-19 14:17:00 --> Hooks Class Initialized
INFO - 2023-08-19 14:17:00 --> URI Class Initialized
INFO - 2023-08-19 14:17:00 --> URI Class Initialized
INFO - 2023-08-19 14:17:00 --> Security Class Initialized
INFO - 2023-08-19 14:17:00 --> Router Class Initialized
INFO - 2023-08-19 14:17:00 --> Output Class Initialized
DEBUG - 2023-08-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:17:00 --> Router Class Initialized
INFO - 2023-08-19 14:17:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:17:00 --> Input Class Initialized
INFO - 2023-08-19 14:17:00 --> Language Class Initialized
ERROR - 2023-08-19 14:17:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:17:00 --> Input Class Initialized
DEBUG - 2023-08-19 14:17:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:17:00 --> Output Class Initialized
INFO - 2023-08-19 14:17:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:17:00 --> Output Class Initialized
INFO - 2023-08-19 14:17:00 --> Security Class Initialized
INFO - 2023-08-19 14:17:00 --> Language Class Initialized
INFO - 2023-08-19 14:17:00 --> Security Class Initialized
INFO - 2023-08-19 14:17:00 --> URI Class Initialized
DEBUG - 2023-08-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:17:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:17:00 --> Input Class Initialized
INFO - 2023-08-19 14:17:00 --> Router Class Initialized
INFO - 2023-08-19 14:17:00 --> Input Class Initialized
INFO - 2023-08-19 14:17:00 --> Output Class Initialized
INFO - 2023-08-19 14:17:00 --> Language Class Initialized
ERROR - 2023-08-19 14:17:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:17:00 --> Security Class Initialized
INFO - 2023-08-19 14:17:00 --> Language Class Initialized
DEBUG - 2023-08-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:17:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:17:00 --> Input Class Initialized
INFO - 2023-08-19 14:17:00 --> Language Class Initialized
ERROR - 2023-08-19 14:17:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:03 --> Config Class Initialized
INFO - 2023-08-19 14:18:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:03 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:03 --> URI Class Initialized
INFO - 2023-08-19 14:18:03 --> Router Class Initialized
INFO - 2023-08-19 14:18:03 --> Output Class Initialized
INFO - 2023-08-19 14:18:03 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:03 --> Input Class Initialized
INFO - 2023-08-19 14:18:03 --> Language Class Initialized
INFO - 2023-08-19 14:18:03 --> Loader Class Initialized
INFO - 2023-08-19 14:18:03 --> Helper loaded: url_helper
INFO - 2023-08-19 14:18:03 --> Helper loaded: file_helper
INFO - 2023-08-19 14:18:03 --> Database Driver Class Initialized
INFO - 2023-08-19 14:18:03 --> Email Class Initialized
DEBUG - 2023-08-19 14:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:18:03 --> Controller Class Initialized
INFO - 2023-08-19 14:18:03 --> Model "Home_model" initialized
INFO - 2023-08-19 14:18:03 --> Helper loaded: form_helper
INFO - 2023-08-19 14:18:03 --> Form Validation Class Initialized
INFO - 2023-08-19 14:18:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:18:04 --> Final output sent to browser
DEBUG - 2023-08-19 14:18:04 --> Total execution time: 0.6272
INFO - 2023-08-19 14:18:04 --> Config Class Initialized
INFO - 2023-08-19 14:18:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:05 --> Config Class Initialized
INFO - 2023-08-19 14:18:05 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:05 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:05 --> Config Class Initialized
INFO - 2023-08-19 14:18:05 --> URI Class Initialized
DEBUG - 2023-08-19 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:05 --> Router Class Initialized
INFO - 2023-08-19 14:18:05 --> Config Class Initialized
INFO - 2023-08-19 14:18:05 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:05 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:05 --> Config Class Initialized
INFO - 2023-08-19 14:18:05 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:05 --> Output Class Initialized
INFO - 2023-08-19 14:18:05 --> URI Class Initialized
INFO - 2023-08-19 14:18:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:05 --> Router Class Initialized
INFO - 2023-08-19 14:18:05 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:05 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:05 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:05 --> Security Class Initialized
INFO - 2023-08-19 14:18:05 --> Output Class Initialized
INFO - 2023-08-19 14:18:05 --> URI Class Initialized
INFO - 2023-08-19 14:18:05 --> Security Class Initialized
INFO - 2023-08-19 14:18:05 --> URI Class Initialized
DEBUG - 2023-08-19 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:05 --> URI Class Initialized
INFO - 2023-08-19 14:18:05 --> Router Class Initialized
INFO - 2023-08-19 14:18:05 --> Output Class Initialized
INFO - 2023-08-19 14:18:05 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:05 --> Input Class Initialized
INFO - 2023-08-19 14:18:05 --> Language Class Initialized
ERROR - 2023-08-19 14:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:05 --> Input Class Initialized
DEBUG - 2023-08-19 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:05 --> Input Class Initialized
INFO - 2023-08-19 14:18:05 --> Router Class Initialized
INFO - 2023-08-19 14:18:05 --> Output Class Initialized
INFO - 2023-08-19 14:18:05 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:05 --> Input Class Initialized
INFO - 2023-08-19 14:18:05 --> Language Class Initialized
ERROR - 2023-08-19 14:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:05 --> Router Class Initialized
INFO - 2023-08-19 14:18:05 --> Language Class Initialized
ERROR - 2023-08-19 14:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:05 --> Language Class Initialized
INFO - 2023-08-19 14:18:05 --> Output Class Initialized
ERROR - 2023-08-19 14:18:05 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:05 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:06 --> Input Class Initialized
INFO - 2023-08-19 14:18:06 --> Language Class Initialized
ERROR - 2023-08-19 14:18:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:51 --> Config Class Initialized
INFO - 2023-08-19 14:18:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:51 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:51 --> URI Class Initialized
INFO - 2023-08-19 14:18:51 --> Router Class Initialized
INFO - 2023-08-19 14:18:51 --> Output Class Initialized
INFO - 2023-08-19 14:18:51 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:51 --> Input Class Initialized
INFO - 2023-08-19 14:18:51 --> Language Class Initialized
INFO - 2023-08-19 14:18:51 --> Loader Class Initialized
INFO - 2023-08-19 14:18:51 --> Helper loaded: url_helper
INFO - 2023-08-19 14:18:51 --> Helper loaded: file_helper
INFO - 2023-08-19 14:18:51 --> Database Driver Class Initialized
INFO - 2023-08-19 14:18:51 --> Email Class Initialized
DEBUG - 2023-08-19 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:18:51 --> Controller Class Initialized
INFO - 2023-08-19 14:18:51 --> Model "Home_model" initialized
INFO - 2023-08-19 14:18:51 --> Helper loaded: form_helper
INFO - 2023-08-19 14:18:51 --> Form Validation Class Initialized
INFO - 2023-08-19 14:18:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 14:18:51 --> Final output sent to browser
DEBUG - 2023-08-19 14:18:52 --> Total execution time: 0.4798
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
ERROR - 2023-08-19 14:18:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
ERROR - 2023-08-19 14:18:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:53 --> Config Class Initialized
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:53 --> Hooks Class Initialized
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Utf8 Class Initialized
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
INFO - 2023-08-19 14:18:53 --> URI Class Initialized
INFO - 2023-08-19 14:18:53 --> Router Class Initialized
ERROR - 2023-08-19 14:18:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> Output Class Initialized
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Security Class Initialized
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
DEBUG - 2023-08-19 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
ERROR - 2023-08-19 14:18:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:18:53 --> Input Class Initialized
INFO - 2023-08-19 14:18:53 --> Language Class Initialized
ERROR - 2023-08-19 14:18:53 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:18:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
DEBUG - 2023-08-19 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:18 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:18 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:18 --> Config Class Initialized
DEBUG - 2023-08-19 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:18 --> URI Class Initialized
INFO - 2023-08-19 14:19:18 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:18 --> URI Class Initialized
INFO - 2023-08-19 14:19:18 --> URI Class Initialized
INFO - 2023-08-19 14:19:18 --> Router Class Initialized
INFO - 2023-08-19 14:19:18 --> Output Class Initialized
INFO - 2023-08-19 14:19:18 --> Security Class Initialized
DEBUG - 2023-08-19 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:19:18 --> Input Class Initialized
INFO - 2023-08-19 14:19:18 --> Language Class Initialized
ERROR - 2023-08-19 14:19:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:18 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:18 --> Hooks Class Initialized
INFO - 2023-08-19 14:19:18 --> Router Class Initialized
INFO - 2023-08-19 14:19:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:19 --> Router Class Initialized
INFO - 2023-08-19 14:19:19 --> URI Class Initialized
DEBUG - 2023-08-19 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Config Class Initialized
INFO - 2023-08-19 14:19:19 --> Router Class Initialized
INFO - 2023-08-19 14:19:19 --> URI Class Initialized
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:19 --> URI Class Initialized
INFO - 2023-08-19 14:19:19 --> Router Class Initialized
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:19 --> Router Class Initialized
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
DEBUG - 2023-08-19 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
INFO - 2023-08-19 14:19:19 --> URI Class Initialized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:19 --> Router Class Initialized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:19 --> Output Class Initialized
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
INFO - 2023-08-19 14:19:19 --> Security Class Initialized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
DEBUG - 2023-08-19 14:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:19:19 --> Input Class Initialized
INFO - 2023-08-19 14:19:19 --> Language Class Initialized
ERROR - 2023-08-19 14:19:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-19 14:20:57 --> Config Class Initialized
INFO - 2023-08-19 14:20:57 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:20:57 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:57 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:57 --> URI Class Initialized
INFO - 2023-08-19 14:20:57 --> Router Class Initialized
INFO - 2023-08-19 14:20:57 --> Output Class Initialized
INFO - 2023-08-19 14:20:57 --> Security Class Initialized
DEBUG - 2023-08-19 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:20:57 --> Input Class Initialized
INFO - 2023-08-19 14:20:57 --> Language Class Initialized
INFO - 2023-08-19 14:20:57 --> Loader Class Initialized
INFO - 2023-08-19 14:20:57 --> Helper loaded: url_helper
INFO - 2023-08-19 14:20:57 --> Helper loaded: file_helper
INFO - 2023-08-19 14:20:57 --> Database Driver Class Initialized
INFO - 2023-08-19 14:20:57 --> Email Class Initialized
DEBUG - 2023-08-19 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:20:57 --> Controller Class Initialized
INFO - 2023-08-19 14:20:57 --> Model "Home_model" initialized
INFO - 2023-08-19 14:20:57 --> Helper loaded: form_helper
INFO - 2023-08-19 14:20:57 --> Form Validation Class Initialized
INFO - 2023-08-19 14:20:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 14:20:57 --> Final output sent to browser
DEBUG - 2023-08-19 14:20:57 --> Total execution time: 0.4694
INFO - 2023-08-19 14:20:58 --> Config Class Initialized
INFO - 2023-08-19 14:20:58 --> Hooks Class Initialized
INFO - 2023-08-19 14:20:59 --> Config Class Initialized
INFO - 2023-08-19 14:20:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Router Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Output Class Initialized
INFO - 2023-08-19 14:20:59 --> Router Class Initialized
INFO - 2023-08-19 14:20:59 --> Security Class Initialized
INFO - 2023-08-19 14:20:59 --> Output Class Initialized
DEBUG - 2023-08-19 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:20:59 --> Security Class Initialized
INFO - 2023-08-19 14:20:59 --> Input Class Initialized
DEBUG - 2023-08-19 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:20:59 --> Language Class Initialized
INFO - 2023-08-19 14:20:59 --> Input Class Initialized
ERROR - 2023-08-19 14:20:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:20:59 --> Language Class Initialized
ERROR - 2023-08-19 14:20:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:20:59 --> Config Class Initialized
INFO - 2023-08-19 14:20:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Router Class Initialized
INFO - 2023-08-19 14:20:59 --> Output Class Initialized
INFO - 2023-08-19 14:20:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:20:59 --> Input Class Initialized
INFO - 2023-08-19 14:20:59 --> Language Class Initialized
ERROR - 2023-08-19 14:20:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:20:59 --> Config Class Initialized
INFO - 2023-08-19 14:20:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:20:59 --> Config Class Initialized
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:59 --> Hooks Class Initialized
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Config Class Initialized
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:59 --> Router Class Initialized
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> Output Class Initialized
INFO - 2023-08-19 14:20:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:20:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:20:59 --> Security Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Router Class Initialized
INFO - 2023-08-19 14:20:59 --> Output Class Initialized
INFO - 2023-08-19 14:20:59 --> Utf8 Class Initialized
INFO - 2023-08-19 14:20:59 --> URI Class Initialized
INFO - 2023-08-19 14:20:59 --> Security Class Initialized
DEBUG - 2023-08-19 14:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:21:00 --> Input Class Initialized
INFO - 2023-08-19 14:21:00 --> Input Class Initialized
INFO - 2023-08-19 14:21:00 --> Language Class Initialized
INFO - 2023-08-19 14:21:00 --> Language Class Initialized
INFO - 2023-08-19 14:21:00 --> Router Class Initialized
ERROR - 2023-08-19 14:21:00 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:21:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:21:00 --> Output Class Initialized
INFO - 2023-08-19 14:21:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:21:00 --> Input Class Initialized
INFO - 2023-08-19 14:21:00 --> Language Class Initialized
ERROR - 2023-08-19 14:21:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:24:04 --> Config Class Initialized
INFO - 2023-08-19 14:24:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:24:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:24:05 --> Utf8 Class Initialized
INFO - 2023-08-19 14:24:05 --> URI Class Initialized
INFO - 2023-08-19 14:24:05 --> Router Class Initialized
INFO - 2023-08-19 14:24:05 --> Output Class Initialized
INFO - 2023-08-19 14:24:05 --> Security Class Initialized
DEBUG - 2023-08-19 14:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:05 --> Input Class Initialized
INFO - 2023-08-19 14:24:05 --> Language Class Initialized
INFO - 2023-08-19 14:24:05 --> Loader Class Initialized
INFO - 2023-08-19 14:24:05 --> Helper loaded: url_helper
INFO - 2023-08-19 14:24:05 --> Helper loaded: file_helper
INFO - 2023-08-19 14:24:05 --> Database Driver Class Initialized
INFO - 2023-08-19 14:24:05 --> Email Class Initialized
DEBUG - 2023-08-19 14:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:24:05 --> Controller Class Initialized
INFO - 2023-08-19 14:24:05 --> Model "Home_model" initialized
INFO - 2023-08-19 14:24:05 --> Helper loaded: form_helper
INFO - 2023-08-19 14:24:05 --> Form Validation Class Initialized
INFO - 2023-08-19 14:24:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:24:05 --> Final output sent to browser
DEBUG - 2023-08-19 14:24:05 --> Total execution time: 0.4929
INFO - 2023-08-19 14:24:06 --> Config Class Initialized
INFO - 2023-08-19 14:24:06 --> Hooks Class Initialized
INFO - 2023-08-19 14:24:06 --> Config Class Initialized
INFO - 2023-08-19 14:24:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:24:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:24:06 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:24:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:24:06 --> Utf8 Class Initialized
INFO - 2023-08-19 14:24:06 --> URI Class Initialized
INFO - 2023-08-19 14:24:06 --> URI Class Initialized
INFO - 2023-08-19 14:24:06 --> Router Class Initialized
INFO - 2023-08-19 14:24:06 --> Router Class Initialized
INFO - 2023-08-19 14:24:06 --> Output Class Initialized
INFO - 2023-08-19 14:24:06 --> Output Class Initialized
INFO - 2023-08-19 14:24:06 --> Security Class Initialized
INFO - 2023-08-19 14:24:06 --> Security Class Initialized
DEBUG - 2023-08-19 14:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:06 --> Input Class Initialized
DEBUG - 2023-08-19 14:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:06 --> Language Class Initialized
INFO - 2023-08-19 14:24:06 --> Input Class Initialized
ERROR - 2023-08-19 14:24:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:24:06 --> Language Class Initialized
ERROR - 2023-08-19 14:24:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:24:07 --> Config Class Initialized
INFO - 2023-08-19 14:24:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:24:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:24:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:24:07 --> URI Class Initialized
INFO - 2023-08-19 14:24:07 --> Router Class Initialized
INFO - 2023-08-19 14:24:07 --> Output Class Initialized
INFO - 2023-08-19 14:24:07 --> Security Class Initialized
INFO - 2023-08-19 14:24:07 --> Config Class Initialized
INFO - 2023-08-19 14:24:07 --> Config Class Initialized
INFO - 2023-08-19 14:24:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:24:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:24:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:24:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:24:07 --> Input Class Initialized
INFO - 2023-08-19 14:24:07 --> Language Class Initialized
ERROR - 2023-08-19 14:24:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:24:07 --> URI Class Initialized
INFO - 2023-08-19 14:24:07 --> Router Class Initialized
INFO - 2023-08-19 14:24:07 --> URI Class Initialized
INFO - 2023-08-19 14:24:07 --> Output Class Initialized
INFO - 2023-08-19 14:24:07 --> Router Class Initialized
INFO - 2023-08-19 14:24:07 --> Security Class Initialized
INFO - 2023-08-19 14:24:07 --> Output Class Initialized
DEBUG - 2023-08-19 14:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:07 --> Security Class Initialized
INFO - 2023-08-19 14:24:07 --> Input Class Initialized
DEBUG - 2023-08-19 14:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:24:07 --> Input Class Initialized
INFO - 2023-08-19 14:24:07 --> Language Class Initialized
INFO - 2023-08-19 14:24:07 --> Language Class Initialized
ERROR - 2023-08-19 14:24:07 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:24:07 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:27:18 --> Config Class Initialized
INFO - 2023-08-19 14:27:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:27:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:27:19 --> URI Class Initialized
INFO - 2023-08-19 14:27:19 --> Router Class Initialized
INFO - 2023-08-19 14:27:19 --> Output Class Initialized
INFO - 2023-08-19 14:27:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:19 --> Input Class Initialized
INFO - 2023-08-19 14:27:19 --> Language Class Initialized
INFO - 2023-08-19 14:27:19 --> Loader Class Initialized
INFO - 2023-08-19 14:27:19 --> Helper loaded: url_helper
INFO - 2023-08-19 14:27:19 --> Helper loaded: file_helper
INFO - 2023-08-19 14:27:19 --> Database Driver Class Initialized
INFO - 2023-08-19 14:27:19 --> Email Class Initialized
DEBUG - 2023-08-19 14:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:27:19 --> Controller Class Initialized
INFO - 2023-08-19 14:27:19 --> Model "Home_model" initialized
INFO - 2023-08-19 14:27:19 --> Helper loaded: form_helper
INFO - 2023-08-19 14:27:19 --> Form Validation Class Initialized
INFO - 2023-08-19 14:27:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:27:19 --> Final output sent to browser
DEBUG - 2023-08-19 14:27:19 --> Total execution time: 0.4518
INFO - 2023-08-19 14:27:20 --> Config Class Initialized
INFO - 2023-08-19 14:27:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:27:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:27:20 --> URI Class Initialized
INFO - 2023-08-19 14:27:20 --> Router Class Initialized
INFO - 2023-08-19 14:27:20 --> Output Class Initialized
INFO - 2023-08-19 14:27:20 --> Security Class Initialized
DEBUG - 2023-08-19 14:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:20 --> Input Class Initialized
INFO - 2023-08-19 14:27:20 --> Language Class Initialized
ERROR - 2023-08-19 14:27:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:27:20 --> Config Class Initialized
INFO - 2023-08-19 14:27:20 --> Config Class Initialized
INFO - 2023-08-19 14:27:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:27:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:27:20 --> URI Class Initialized
INFO - 2023-08-19 14:27:20 --> Router Class Initialized
INFO - 2023-08-19 14:27:20 --> Output Class Initialized
INFO - 2023-08-19 14:27:20 --> Security Class Initialized
DEBUG - 2023-08-19 14:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:20 --> Input Class Initialized
INFO - 2023-08-19 14:27:20 --> Language Class Initialized
ERROR - 2023-08-19 14:27:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:27:20 --> Config Class Initialized
INFO - 2023-08-19 14:27:20 --> Hooks Class Initialized
INFO - 2023-08-19 14:27:20 --> Config Class Initialized
DEBUG - 2023-08-19 14:27:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:27:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:20 --> Hooks Class Initialized
INFO - 2023-08-19 14:27:20 --> Utf8 Class Initialized
DEBUG - 2023-08-19 14:27:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:27:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:27:20 --> URI Class Initialized
INFO - 2023-08-19 14:27:20 --> URI Class Initialized
INFO - 2023-08-19 14:27:20 --> Router Class Initialized
INFO - 2023-08-19 14:27:20 --> Router Class Initialized
INFO - 2023-08-19 14:27:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:27:20 --> Output Class Initialized
INFO - 2023-08-19 14:27:20 --> Output Class Initialized
INFO - 2023-08-19 14:27:20 --> Security Class Initialized
INFO - 2023-08-19 14:27:20 --> URI Class Initialized
DEBUG - 2023-08-19 14:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:20 --> Router Class Initialized
INFO - 2023-08-19 14:27:20 --> Security Class Initialized
INFO - 2023-08-19 14:27:21 --> Output Class Initialized
INFO - 2023-08-19 14:27:21 --> Input Class Initialized
INFO - 2023-08-19 14:27:21 --> Language Class Initialized
ERROR - 2023-08-19 14:27:21 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:21 --> Input Class Initialized
INFO - 2023-08-19 14:27:21 --> Security Class Initialized
INFO - 2023-08-19 14:27:21 --> Language Class Initialized
DEBUG - 2023-08-19 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:27:21 --> Input Class Initialized
ERROR - 2023-08-19 14:27:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:27:21 --> Language Class Initialized
ERROR - 2023-08-19 14:27:21 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:32:27 --> Config Class Initialized
INFO - 2023-08-19 14:32:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:32:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:27 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:27 --> URI Class Initialized
INFO - 2023-08-19 14:32:27 --> Router Class Initialized
INFO - 2023-08-19 14:32:27 --> Output Class Initialized
INFO - 2023-08-19 14:32:27 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:27 --> Input Class Initialized
INFO - 2023-08-19 14:32:27 --> Language Class Initialized
INFO - 2023-08-19 14:32:27 --> Loader Class Initialized
INFO - 2023-08-19 14:32:27 --> Helper loaded: url_helper
INFO - 2023-08-19 14:32:27 --> Helper loaded: file_helper
INFO - 2023-08-19 14:32:27 --> Database Driver Class Initialized
INFO - 2023-08-19 14:32:27 --> Email Class Initialized
DEBUG - 2023-08-19 14:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:32:27 --> Controller Class Initialized
INFO - 2023-08-19 14:32:27 --> Model "Home_model" initialized
INFO - 2023-08-19 14:32:27 --> Helper loaded: form_helper
INFO - 2023-08-19 14:32:27 --> Form Validation Class Initialized
INFO - 2023-08-19 14:32:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:32:27 --> Final output sent to browser
DEBUG - 2023-08-19 14:32:27 --> Total execution time: 0.1636
INFO - 2023-08-19 14:32:27 --> Config Class Initialized
INFO - 2023-08-19 14:32:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:32:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:27 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:27 --> URI Class Initialized
INFO - 2023-08-19 14:32:27 --> Router Class Initialized
INFO - 2023-08-19 14:32:27 --> Output Class Initialized
INFO - 2023-08-19 14:32:27 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:27 --> Input Class Initialized
INFO - 2023-08-19 14:32:27 --> Language Class Initialized
ERROR - 2023-08-19 14:32:27 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:32:27 --> Config Class Initialized
INFO - 2023-08-19 14:32:28 --> Hooks Class Initialized
INFO - 2023-08-19 14:32:28 --> Config Class Initialized
INFO - 2023-08-19 14:32:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:32:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:28 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:28 --> URI Class Initialized
INFO - 2023-08-19 14:32:28 --> Router Class Initialized
INFO - 2023-08-19 14:32:28 --> Output Class Initialized
INFO - 2023-08-19 14:32:28 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:28 --> Input Class Initialized
INFO - 2023-08-19 14:32:28 --> Language Class Initialized
ERROR - 2023-08-19 14:32:28 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:32:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:28 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:28 --> URI Class Initialized
INFO - 2023-08-19 14:32:28 --> Router Class Initialized
INFO - 2023-08-19 14:32:28 --> Output Class Initialized
INFO - 2023-08-19 14:32:28 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:28 --> Input Class Initialized
INFO - 2023-08-19 14:32:28 --> Language Class Initialized
INFO - 2023-08-19 14:32:28 --> Config Class Initialized
INFO - 2023-08-19 14:32:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:32:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:28 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:28 --> URI Class Initialized
INFO - 2023-08-19 14:32:28 --> Router Class Initialized
INFO - 2023-08-19 14:32:28 --> Output Class Initialized
INFO - 2023-08-19 14:32:28 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:28 --> Input Class Initialized
INFO - 2023-08-19 14:32:28 --> Language Class Initialized
INFO - 2023-08-19 14:32:28 --> Config Class Initialized
ERROR - 2023-08-19 14:32:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:32:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:32:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:32:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:32:29 --> URI Class Initialized
INFO - 2023-08-19 14:32:29 --> Router Class Initialized
INFO - 2023-08-19 14:32:29 --> Output Class Initialized
INFO - 2023-08-19 14:32:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:32:29 --> Input Class Initialized
INFO - 2023-08-19 14:32:29 --> Language Class Initialized
ERROR - 2023-08-19 14:32:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:33:14 --> Config Class Initialized
INFO - 2023-08-19 14:33:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:14 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:14 --> URI Class Initialized
INFO - 2023-08-19 14:33:14 --> Router Class Initialized
INFO - 2023-08-19 14:33:14 --> Output Class Initialized
INFO - 2023-08-19 14:33:15 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:15 --> Input Class Initialized
INFO - 2023-08-19 14:33:15 --> Language Class Initialized
INFO - 2023-08-19 14:33:15 --> Loader Class Initialized
INFO - 2023-08-19 14:33:15 --> Helper loaded: url_helper
INFO - 2023-08-19 14:33:15 --> Helper loaded: file_helper
INFO - 2023-08-19 14:33:15 --> Database Driver Class Initialized
INFO - 2023-08-19 14:33:15 --> Email Class Initialized
DEBUG - 2023-08-19 14:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:33:15 --> Controller Class Initialized
INFO - 2023-08-19 14:33:15 --> Model "Home_model" initialized
INFO - 2023-08-19 14:33:15 --> Helper loaded: form_helper
INFO - 2023-08-19 14:33:15 --> Form Validation Class Initialized
INFO - 2023-08-19 14:33:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-19 14:33:15 --> Final output sent to browser
DEBUG - 2023-08-19 14:33:15 --> Total execution time: 0.4647
INFO - 2023-08-19 14:33:15 --> Config Class Initialized
INFO - 2023-08-19 14:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:15 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:15 --> URI Class Initialized
INFO - 2023-08-19 14:33:15 --> Router Class Initialized
INFO - 2023-08-19 14:33:15 --> Output Class Initialized
INFO - 2023-08-19 14:33:15 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:15 --> Input Class Initialized
INFO - 2023-08-19 14:33:15 --> Language Class Initialized
ERROR - 2023-08-19 14:33:15 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:33:16 --> Config Class Initialized
INFO - 2023-08-19 14:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:16 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:16 --> URI Class Initialized
INFO - 2023-08-19 14:33:16 --> Router Class Initialized
INFO - 2023-08-19 14:33:16 --> Output Class Initialized
INFO - 2023-08-19 14:33:16 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:16 --> Input Class Initialized
INFO - 2023-08-19 14:33:16 --> Language Class Initialized
INFO - 2023-08-19 14:33:16 --> Config Class Initialized
INFO - 2023-08-19 14:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:16 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:16 --> URI Class Initialized
INFO - 2023-08-19 14:33:16 --> Router Class Initialized
INFO - 2023-08-19 14:33:16 --> Output Class Initialized
INFO - 2023-08-19 14:33:16 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:16 --> Input Class Initialized
INFO - 2023-08-19 14:33:16 --> Language Class Initialized
ERROR - 2023-08-19 14:33:16 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:33:16 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:33:16 --> Config Class Initialized
INFO - 2023-08-19 14:33:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:17 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:17 --> URI Class Initialized
INFO - 2023-08-19 14:33:17 --> Router Class Initialized
INFO - 2023-08-19 14:33:17 --> Output Class Initialized
INFO - 2023-08-19 14:33:17 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:17 --> Input Class Initialized
INFO - 2023-08-19 14:33:17 --> Language Class Initialized
ERROR - 2023-08-19 14:33:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:33:17 --> Config Class Initialized
INFO - 2023-08-19 14:33:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:17 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:17 --> URI Class Initialized
INFO - 2023-08-19 14:33:17 --> Router Class Initialized
INFO - 2023-08-19 14:33:17 --> Output Class Initialized
INFO - 2023-08-19 14:33:17 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:17 --> Input Class Initialized
INFO - 2023-08-19 14:33:17 --> Language Class Initialized
ERROR - 2023-08-19 14:33:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:33:17 --> Config Class Initialized
INFO - 2023-08-19 14:33:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:33:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:33:17 --> Utf8 Class Initialized
INFO - 2023-08-19 14:33:17 --> URI Class Initialized
INFO - 2023-08-19 14:33:17 --> Router Class Initialized
INFO - 2023-08-19 14:33:17 --> Output Class Initialized
INFO - 2023-08-19 14:33:17 --> Security Class Initialized
DEBUG - 2023-08-19 14:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:33:17 --> Input Class Initialized
INFO - 2023-08-19 14:33:17 --> Language Class Initialized
ERROR - 2023-08-19 14:33:17 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:34:46 --> Config Class Initialized
INFO - 2023-08-19 14:34:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:34:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:34:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:46 --> URI Class Initialized
INFO - 2023-08-19 14:34:46 --> Router Class Initialized
INFO - 2023-08-19 14:34:46 --> Output Class Initialized
INFO - 2023-08-19 14:34:46 --> Security Class Initialized
DEBUG - 2023-08-19 14:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:46 --> Input Class Initialized
INFO - 2023-08-19 14:34:46 --> Language Class Initialized
INFO - 2023-08-19 14:34:46 --> Loader Class Initialized
INFO - 2023-08-19 14:34:46 --> Helper loaded: url_helper
INFO - 2023-08-19 14:34:46 --> Helper loaded: file_helper
INFO - 2023-08-19 14:34:46 --> Database Driver Class Initialized
INFO - 2023-08-19 14:34:46 --> Email Class Initialized
DEBUG - 2023-08-19 14:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:34:46 --> Controller Class Initialized
INFO - 2023-08-19 14:34:46 --> Model "Home_model" initialized
INFO - 2023-08-19 14:34:46 --> Helper loaded: form_helper
INFO - 2023-08-19 14:34:46 --> Form Validation Class Initialized
INFO - 2023-08-19 14:34:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-19 14:34:46 --> Final output sent to browser
DEBUG - 2023-08-19 14:34:46 --> Total execution time: 0.5583
INFO - 2023-08-19 14:34:47 --> Config Class Initialized
INFO - 2023-08-19 14:34:47 --> Config Class Initialized
INFO - 2023-08-19 14:34:47 --> Hooks Class Initialized
INFO - 2023-08-19 14:34:47 --> Config Class Initialized
INFO - 2023-08-19 14:34:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:34:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:34:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:34:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:34:48 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:48 --> URI Class Initialized
INFO - 2023-08-19 14:34:48 --> Router Class Initialized
INFO - 2023-08-19 14:34:48 --> Output Class Initialized
INFO - 2023-08-19 14:34:48 --> Security Class Initialized
DEBUG - 2023-08-19 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:48 --> Input Class Initialized
INFO - 2023-08-19 14:34:48 --> Language Class Initialized
ERROR - 2023-08-19 14:34:48 --> 404 Page Not Found: Assets/images
DEBUG - 2023-08-19 14:34:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:34:48 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:48 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:48 --> URI Class Initialized
INFO - 2023-08-19 14:34:48 --> URI Class Initialized
INFO - 2023-08-19 14:34:48 --> Router Class Initialized
INFO - 2023-08-19 14:34:48 --> Router Class Initialized
INFO - 2023-08-19 14:34:48 --> Output Class Initialized
INFO - 2023-08-19 14:34:48 --> Output Class Initialized
INFO - 2023-08-19 14:34:48 --> Security Class Initialized
DEBUG - 2023-08-19 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:48 --> Security Class Initialized
INFO - 2023-08-19 14:34:48 --> Config Class Initialized
INFO - 2023-08-19 14:34:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:48 --> Input Class Initialized
INFO - 2023-08-19 14:34:48 --> Language Class Initialized
INFO - 2023-08-19 14:34:48 --> Input Class Initialized
DEBUG - 2023-08-19 14:34:48 --> UTF-8 Support Enabled
ERROR - 2023-08-19 14:34:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:34:48 --> Language Class Initialized
ERROR - 2023-08-19 14:34:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:34:48 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:48 --> URI Class Initialized
INFO - 2023-08-19 14:34:48 --> Router Class Initialized
INFO - 2023-08-19 14:34:48 --> Output Class Initialized
INFO - 2023-08-19 14:34:48 --> Security Class Initialized
DEBUG - 2023-08-19 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:48 --> Input Class Initialized
INFO - 2023-08-19 14:34:48 --> Language Class Initialized
ERROR - 2023-08-19 14:34:48 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:34:48 --> Config Class Initialized
INFO - 2023-08-19 14:34:48 --> Config Class Initialized
INFO - 2023-08-19 14:34:49 --> Hooks Class Initialized
INFO - 2023-08-19 14:34:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2023-08-19 14:34:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:34:49 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:49 --> Utf8 Class Initialized
INFO - 2023-08-19 14:34:49 --> URI Class Initialized
INFO - 2023-08-19 14:34:49 --> URI Class Initialized
INFO - 2023-08-19 14:34:49 --> Router Class Initialized
INFO - 2023-08-19 14:34:49 --> Router Class Initialized
INFO - 2023-08-19 14:34:49 --> Output Class Initialized
INFO - 2023-08-19 14:34:49 --> Output Class Initialized
INFO - 2023-08-19 14:34:49 --> Security Class Initialized
INFO - 2023-08-19 14:34:49 --> Security Class Initialized
DEBUG - 2023-08-19 14:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-19 14:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:34:49 --> Input Class Initialized
INFO - 2023-08-19 14:34:49 --> Input Class Initialized
INFO - 2023-08-19 14:34:49 --> Language Class Initialized
INFO - 2023-08-19 14:34:49 --> Language Class Initialized
ERROR - 2023-08-19 14:34:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-19 14:34:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-19 14:56:20 --> Config Class Initialized
INFO - 2023-08-19 14:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:20 --> URI Class Initialized
INFO - 2023-08-19 14:56:20 --> Router Class Initialized
INFO - 2023-08-19 14:56:20 --> Output Class Initialized
INFO - 2023-08-19 14:56:20 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:20 --> Input Class Initialized
INFO - 2023-08-19 14:56:20 --> Language Class Initialized
INFO - 2023-08-19 14:56:21 --> Loader Class Initialized
INFO - 2023-08-19 14:56:21 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:21 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:21 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:21 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:21 --> Controller Class Initialized
INFO - 2023-08-19 14:56:21 --> Model "Training_Curriculum_Model" initialized
INFO - 2023-08-19 14:56:21 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:21 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_curriculum_create.php
INFO - 2023-08-19 14:56:21 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:21 --> Total execution time: 0.3622
INFO - 2023-08-19 14:56:26 --> Config Class Initialized
INFO - 2023-08-19 14:56:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:26 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:26 --> URI Class Initialized
INFO - 2023-08-19 14:56:26 --> Router Class Initialized
INFO - 2023-08-19 14:56:26 --> Output Class Initialized
INFO - 2023-08-19 14:56:26 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:26 --> Input Class Initialized
INFO - 2023-08-19 14:56:26 --> Language Class Initialized
INFO - 2023-08-19 14:56:26 --> Loader Class Initialized
INFO - 2023-08-19 14:56:26 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:26 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:26 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:26 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:26 --> Controller Class Initialized
INFO - 2023-08-19 14:56:26 --> Model "Banner_model" initialized
INFO - 2023-08-19 14:56:26 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:26 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-19 14:56:26 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:26 --> Total execution time: 0.0498
INFO - 2023-08-19 14:56:28 --> Config Class Initialized
INFO - 2023-08-19 14:56:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:28 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:28 --> URI Class Initialized
INFO - 2023-08-19 14:56:28 --> Router Class Initialized
INFO - 2023-08-19 14:56:28 --> Output Class Initialized
INFO - 2023-08-19 14:56:28 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:28 --> Input Class Initialized
INFO - 2023-08-19 14:56:28 --> Language Class Initialized
INFO - 2023-08-19 14:56:28 --> Loader Class Initialized
INFO - 2023-08-19 14:56:28 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:28 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:28 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:28 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:28 --> Controller Class Initialized
INFO - 2023-08-19 14:56:28 --> Model "Banner_model" initialized
INFO - 2023-08-19 14:56:28 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:28 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-19 14:56:28 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:28 --> Total execution time: 0.0613
INFO - 2023-08-19 14:56:35 --> Config Class Initialized
INFO - 2023-08-19 14:56:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:36 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:36 --> URI Class Initialized
INFO - 2023-08-19 14:56:36 --> Router Class Initialized
INFO - 2023-08-19 14:56:36 --> Output Class Initialized
INFO - 2023-08-19 14:56:36 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:36 --> Input Class Initialized
INFO - 2023-08-19 14:56:36 --> Language Class Initialized
INFO - 2023-08-19 14:56:36 --> Loader Class Initialized
INFO - 2023-08-19 14:56:36 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:36 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:36 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:36 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:36 --> Controller Class Initialized
INFO - 2023-08-19 14:56:36 --> Model "Banner_model" initialized
INFO - 2023-08-19 14:56:36 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:36 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_create.php
INFO - 2023-08-19 14:56:36 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:36 --> Total execution time: 0.5376
INFO - 2023-08-19 14:56:39 --> Config Class Initialized
INFO - 2023-08-19 14:56:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:39 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:39 --> URI Class Initialized
INFO - 2023-08-19 14:56:39 --> Router Class Initialized
INFO - 2023-08-19 14:56:39 --> Output Class Initialized
INFO - 2023-08-19 14:56:39 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:39 --> Input Class Initialized
INFO - 2023-08-19 14:56:39 --> Language Class Initialized
INFO - 2023-08-19 14:56:39 --> Loader Class Initialized
INFO - 2023-08-19 14:56:39 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:39 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:39 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:39 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:39 --> Controller Class Initialized
INFO - 2023-08-19 14:56:39 --> Model "Training_model" initialized
INFO - 2023-08-19 14:56:39 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:39 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-19 14:56:39 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:39 --> Total execution time: 0.0494
INFO - 2023-08-19 14:56:41 --> Config Class Initialized
INFO - 2023-08-19 14:56:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:41 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:41 --> URI Class Initialized
INFO - 2023-08-19 14:56:41 --> Router Class Initialized
INFO - 2023-08-19 14:56:41 --> Output Class Initialized
INFO - 2023-08-19 14:56:41 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:41 --> Input Class Initialized
INFO - 2023-08-19 14:56:41 --> Language Class Initialized
INFO - 2023-08-19 14:56:41 --> Loader Class Initialized
INFO - 2023-08-19 14:56:41 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:41 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:41 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:41 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:41 --> Controller Class Initialized
INFO - 2023-08-19 14:56:41 --> Model "Training_model" initialized
INFO - 2023-08-19 14:56:41 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:41 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 14:56:41 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:41 --> Total execution time: 0.2384
INFO - 2023-08-19 14:56:41 --> Config Class Initialized
INFO - 2023-08-19 14:56:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:41 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:41 --> URI Class Initialized
INFO - 2023-08-19 14:56:41 --> Router Class Initialized
INFO - 2023-08-19 14:56:41 --> Output Class Initialized
INFO - 2023-08-19 14:56:41 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:41 --> Input Class Initialized
INFO - 2023-08-19 14:56:41 --> Language Class Initialized
INFO - 2023-08-19 14:56:41 --> Loader Class Initialized
INFO - 2023-08-19 14:56:41 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:41 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:41 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:41 --> Email Class Initialized
DEBUG - 2023-08-19 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-19 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:41 --> Controller Class Initialized
INFO - 2023-08-19 14:56:41 --> Model "Training_model" initialized
INFO - 2023-08-19 14:56:41 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:41 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-19 14:56:41 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:41 --> Total execution time: 0.0471
