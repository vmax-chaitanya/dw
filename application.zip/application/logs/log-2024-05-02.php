<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-05-02 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:18 --> No URI present. Default controller set.
DEBUG - 2024-05-02 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:14:18 --> Total execution time: 0.1098
DEBUG - 2024-05-02 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:14:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:14:22 --> Total execution time: 0.1164
DEBUG - 2024-05-02 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:29 --> Total execution time: 0.0676
DEBUG - 2024-05-02 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:30 --> Total execution time: 0.1006
DEBUG - 2024-05-02 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:31 --> Total execution time: 0.1053
DEBUG - 2024-05-02 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:32 --> Total execution time: 0.0804
DEBUG - 2024-05-02 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:34 --> Total execution time: 0.1266
DEBUG - 2024-05-02 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:35 --> Total execution time: 0.1055
DEBUG - 2024-05-02 08:44:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 12:14:36 --> Total execution time: 0.1613
DEBUG - 2024-05-02 08:45:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:15:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:15:50 --> Total execution time: 0.1589
DEBUG - 2024-05-02 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:17:16 --> Total execution time: 0.1744
DEBUG - 2024-05-02 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:20:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:20:12 --> Total execution time: 0.1317
DEBUG - 2024-05-02 08:50:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:20:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:20:39 --> Total execution time: 0.1401
DEBUG - 2024-05-02 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:20:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:20:57 --> Total execution time: 0.1476
DEBUG - 2024-05-02 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:21:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:21:20 --> Total execution time: 0.1343
DEBUG - 2024-05-02 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 08:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:21:21 --> Total execution time: 0.1508
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:21:21 --> Total execution time: 0.2542
DEBUG - 2024-05-02 08:52:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:22:53 --> Total execution time: 0.1521
DEBUG - 2024-05-02 08:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 08:54:14 --> No URI present. Default controller set.
DEBUG - 2024-05-02 08:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 08:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:24:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:24:14 --> Total execution time: 0.1462
DEBUG - 2024-05-02 09:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:01:24 --> No URI present. Default controller set.
DEBUG - 2024-05-02 09:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:31:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:31:25 --> Total execution time: 1.3811
DEBUG - 2024-05-02 09:07:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:07:53 --> Total execution time: 0.1492
DEBUG - 2024-05-02 09:07:54 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:37:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:37:54 --> Total execution time: 0.0673
DEBUG - 2024-05-02 09:08:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:45 --> Total execution time: 0.1167
DEBUG - 2024-05-02 09:08:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:50 --> Total execution time: 0.3485
DEBUG - 2024-05-02 09:08:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:50 --> UTF-8 Support Enabled
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-05-02 09:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:38:50 --> Total execution time: 0.0767
DEBUG - 2024-05-02 09:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:38:50 --> Total execution time: 0.1454
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 12:38:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 12:38:50 --> Total execution time: 0.1436
DEBUG - 2024-05-02 09:08:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:08:56 --> Total execution time: 0.1761
DEBUG - 2024-05-02 09:08:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 65
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 75
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 91
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 106
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 124
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 136
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 148
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 160
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 173
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 183
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 196
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 206
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 219
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 229
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 241
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 252
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 263
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 272
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 274
ERROR - 2024-05-02 09:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 276
DEBUG - 2024-05-02 09:08:56 --> Total execution time: 0.0770
DEBUG - 2024-05-02 09:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:23 --> Total execution time: 0.1237
DEBUG - 2024-05-02 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:25 --> Total execution time: 0.1357
DEBUG - 2024-05-02 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-02 09:33:25 --> UTF-8 Support Enabled
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:25 --> Total execution time: 0.0716
DEBUG - 2024-05-02 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:25 --> Total execution time: 0.1143
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:25 --> Total execution time: 0.0978
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:25 --> Total execution time: 0.1622
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:27 --> Total execution time: 0.1734
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1025
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1286
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1303
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.0976
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1746
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.2852
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.2922
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1851
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1918
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.2053
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1913
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1965
DEBUG - 2024-05-02 09:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1577
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.2133
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1763
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1760
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:28 --> Total execution time: 0.1700
DEBUG - 2024-05-02 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:31 --> Total execution time: 0.0396
DEBUG - 2024-05-02 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-05-02 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:31 --> Total execution time: 0.0704
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:31 --> Total execution time: 0.1039
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-02 13:03:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-02 13:03:31 --> Total execution time: 0.1398
DEBUG - 2024-05-02 09:33:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:32 --> Total execution time: 0.1659
DEBUG - 2024-05-02 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:34 --> Total execution time: 0.1143
DEBUG - 2024-05-02 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:36 --> Total execution time: 0.1318
DEBUG - 2024-05-02 09:33:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:38 --> Total execution time: 0.1133
DEBUG - 2024-05-02 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-02 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-02 09:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-02 09:33:40 --> Total execution time: 0.1217
