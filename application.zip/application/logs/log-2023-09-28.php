<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-28 18:11:14 --> Config Class Initialized
INFO - 2023-09-28 18:11:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:11:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:11:14 --> Utf8 Class Initialized
INFO - 2023-09-28 18:11:14 --> URI Class Initialized
DEBUG - 2023-09-28 18:11:14 --> No URI present. Default controller set.
INFO - 2023-09-28 18:11:14 --> Router Class Initialized
INFO - 2023-09-28 18:11:14 --> Output Class Initialized
INFO - 2023-09-28 18:11:14 --> Security Class Initialized
DEBUG - 2023-09-28 18:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:11:14 --> Input Class Initialized
INFO - 2023-09-28 18:11:14 --> Language Class Initialized
INFO - 2023-09-28 18:11:14 --> Loader Class Initialized
INFO - 2023-09-28 18:11:14 --> Helper loaded: url_helper
INFO - 2023-09-28 18:11:14 --> Helper loaded: file_helper
INFO - 2023-09-28 18:11:14 --> Database Driver Class Initialized
INFO - 2023-09-28 18:11:14 --> Email Class Initialized
DEBUG - 2023-09-28 18:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:11:14 --> Controller Class Initialized
INFO - 2023-09-28 18:11:14 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:11:14 --> Model "Home_model" initialized
INFO - 2023-09-28 18:11:14 --> Helper loaded: download_helper
INFO - 2023-09-28 18:11:14 --> Helper loaded: form_helper
INFO - 2023-09-28 18:11:14 --> Form Validation Class Initialized
INFO - 2023-09-28 18:11:14 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:11:14 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:11:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-28 18:11:14 --> Final output sent to browser
DEBUG - 2023-09-28 18:11:14 --> Total execution time: 0.3040
INFO - 2023-09-28 18:11:26 --> Config Class Initialized
INFO - 2023-09-28 18:11:26 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:11:26 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:11:26 --> Utf8 Class Initialized
INFO - 2023-09-28 18:11:26 --> URI Class Initialized
INFO - 2023-09-28 18:11:26 --> Router Class Initialized
INFO - 2023-09-28 18:11:26 --> Output Class Initialized
INFO - 2023-09-28 18:11:26 --> Security Class Initialized
DEBUG - 2023-09-28 18:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:11:26 --> Input Class Initialized
INFO - 2023-09-28 18:11:26 --> Language Class Initialized
INFO - 2023-09-28 18:11:26 --> Loader Class Initialized
INFO - 2023-09-28 18:11:26 --> Helper loaded: url_helper
INFO - 2023-09-28 18:11:26 --> Helper loaded: file_helper
INFO - 2023-09-28 18:11:26 --> Database Driver Class Initialized
INFO - 2023-09-28 18:11:26 --> Email Class Initialized
DEBUG - 2023-09-28 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:11:26 --> Controller Class Initialized
INFO - 2023-09-28 18:11:26 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:11:26 --> Model "Home_model" initialized
INFO - 2023-09-28 18:11:26 --> Helper loaded: download_helper
INFO - 2023-09-28 18:11:26 --> Helper loaded: form_helper
INFO - 2023-09-28 18:11:26 --> Form Validation Class Initialized
INFO - 2023-09-28 18:11:26 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:11:26 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:11:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:11:26 --> Final output sent to browser
DEBUG - 2023-09-28 18:11:26 --> Total execution time: 0.1402
INFO - 2023-09-28 18:18:11 --> Config Class Initialized
INFO - 2023-09-28 18:18:11 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:18:11 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:18:11 --> Utf8 Class Initialized
INFO - 2023-09-28 18:18:11 --> URI Class Initialized
INFO - 2023-09-28 18:18:11 --> Router Class Initialized
INFO - 2023-09-28 18:18:11 --> Output Class Initialized
INFO - 2023-09-28 18:18:11 --> Security Class Initialized
DEBUG - 2023-09-28 18:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:18:11 --> Input Class Initialized
INFO - 2023-09-28 18:18:11 --> Language Class Initialized
INFO - 2023-09-28 18:18:11 --> Loader Class Initialized
INFO - 2023-09-28 18:18:11 --> Helper loaded: url_helper
INFO - 2023-09-28 18:18:11 --> Helper loaded: file_helper
INFO - 2023-09-28 18:18:11 --> Database Driver Class Initialized
INFO - 2023-09-28 18:18:11 --> Email Class Initialized
DEBUG - 2023-09-28 18:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:18:11 --> Controller Class Initialized
INFO - 2023-09-28 18:18:11 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:18:11 --> Model "Home_model" initialized
INFO - 2023-09-28 18:18:11 --> Helper loaded: download_helper
INFO - 2023-09-28 18:18:11 --> Helper loaded: form_helper
INFO - 2023-09-28 18:18:11 --> Form Validation Class Initialized
INFO - 2023-09-28 18:18:11 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:18:11 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:18:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:18:11 --> Final output sent to browser
DEBUG - 2023-09-28 18:18:11 --> Total execution time: 0.2037
INFO - 2023-09-28 18:19:06 --> Config Class Initialized
INFO - 2023-09-28 18:19:06 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:19:06 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:19:06 --> Utf8 Class Initialized
INFO - 2023-09-28 18:19:06 --> URI Class Initialized
INFO - 2023-09-28 18:19:06 --> Router Class Initialized
INFO - 2023-09-28 18:19:06 --> Output Class Initialized
INFO - 2023-09-28 18:19:06 --> Security Class Initialized
DEBUG - 2023-09-28 18:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:19:06 --> Input Class Initialized
INFO - 2023-09-28 18:19:06 --> Language Class Initialized
INFO - 2023-09-28 18:19:06 --> Loader Class Initialized
INFO - 2023-09-28 18:19:06 --> Helper loaded: url_helper
INFO - 2023-09-28 18:19:06 --> Helper loaded: file_helper
INFO - 2023-09-28 18:19:06 --> Database Driver Class Initialized
INFO - 2023-09-28 18:19:06 --> Email Class Initialized
DEBUG - 2023-09-28 18:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:19:06 --> Controller Class Initialized
INFO - 2023-09-28 18:19:06 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:19:06 --> Model "Home_model" initialized
INFO - 2023-09-28 18:19:06 --> Helper loaded: download_helper
INFO - 2023-09-28 18:19:06 --> Helper loaded: form_helper
INFO - 2023-09-28 18:19:06 --> Form Validation Class Initialized
INFO - 2023-09-28 18:19:06 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:19:06 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:19:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:19:07 --> Final output sent to browser
DEBUG - 2023-09-28 18:19:07 --> Total execution time: 0.1172
INFO - 2023-09-28 18:19:13 --> Config Class Initialized
INFO - 2023-09-28 18:19:13 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:19:13 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:19:13 --> Utf8 Class Initialized
INFO - 2023-09-28 18:19:13 --> URI Class Initialized
INFO - 2023-09-28 18:19:13 --> Router Class Initialized
INFO - 2023-09-28 18:19:13 --> Output Class Initialized
INFO - 2023-09-28 18:19:13 --> Security Class Initialized
DEBUG - 2023-09-28 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:19:13 --> Input Class Initialized
INFO - 2023-09-28 18:19:13 --> Language Class Initialized
INFO - 2023-09-28 18:19:13 --> Loader Class Initialized
INFO - 2023-09-28 18:19:13 --> Helper loaded: url_helper
INFO - 2023-09-28 18:19:13 --> Helper loaded: file_helper
INFO - 2023-09-28 18:19:13 --> Database Driver Class Initialized
INFO - 2023-09-28 18:19:13 --> Email Class Initialized
DEBUG - 2023-09-28 18:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:19:13 --> Controller Class Initialized
INFO - 2023-09-28 18:19:13 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:19:13 --> Model "Home_model" initialized
INFO - 2023-09-28 18:19:13 --> Helper loaded: download_helper
INFO - 2023-09-28 18:19:13 --> Helper loaded: form_helper
INFO - 2023-09-28 18:19:13 --> Form Validation Class Initialized
INFO - 2023-09-28 18:19:13 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:19:13 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:19:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:19:13 --> Final output sent to browser
DEBUG - 2023-09-28 18:19:14 --> Total execution time: 0.1510
INFO - 2023-09-28 18:19:32 --> Config Class Initialized
INFO - 2023-09-28 18:19:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:19:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:19:32 --> Utf8 Class Initialized
INFO - 2023-09-28 18:19:32 --> URI Class Initialized
INFO - 2023-09-28 18:19:32 --> Router Class Initialized
INFO - 2023-09-28 18:19:32 --> Output Class Initialized
INFO - 2023-09-28 18:19:32 --> Security Class Initialized
DEBUG - 2023-09-28 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:19:32 --> Input Class Initialized
INFO - 2023-09-28 18:19:32 --> Language Class Initialized
INFO - 2023-09-28 18:19:32 --> Loader Class Initialized
INFO - 2023-09-28 18:19:32 --> Helper loaded: url_helper
INFO - 2023-09-28 18:19:32 --> Helper loaded: file_helper
INFO - 2023-09-28 18:19:32 --> Database Driver Class Initialized
INFO - 2023-09-28 18:19:32 --> Email Class Initialized
DEBUG - 2023-09-28 18:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:19:32 --> Controller Class Initialized
INFO - 2023-09-28 18:19:32 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:19:32 --> Model "Home_model" initialized
INFO - 2023-09-28 18:19:32 --> Helper loaded: download_helper
INFO - 2023-09-28 18:19:32 --> Helper loaded: form_helper
INFO - 2023-09-28 18:19:32 --> Form Validation Class Initialized
INFO - 2023-09-28 18:19:32 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:19:32 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:19:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:19:32 --> Final output sent to browser
DEBUG - 2023-09-28 18:19:33 --> Total execution time: 0.1138
INFO - 2023-09-28 18:19:48 --> Config Class Initialized
INFO - 2023-09-28 18:19:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:19:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:19:48 --> Utf8 Class Initialized
INFO - 2023-09-28 18:19:48 --> URI Class Initialized
INFO - 2023-09-28 18:19:48 --> Router Class Initialized
INFO - 2023-09-28 18:19:48 --> Output Class Initialized
INFO - 2023-09-28 18:19:48 --> Security Class Initialized
DEBUG - 2023-09-28 18:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:19:48 --> Input Class Initialized
INFO - 2023-09-28 18:19:48 --> Language Class Initialized
INFO - 2023-09-28 18:19:48 --> Loader Class Initialized
INFO - 2023-09-28 18:19:48 --> Helper loaded: url_helper
INFO - 2023-09-28 18:19:48 --> Helper loaded: file_helper
INFO - 2023-09-28 18:19:48 --> Database Driver Class Initialized
INFO - 2023-09-28 18:19:48 --> Email Class Initialized
DEBUG - 2023-09-28 18:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:19:48 --> Controller Class Initialized
INFO - 2023-09-28 18:19:48 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:19:48 --> Model "Home_model" initialized
INFO - 2023-09-28 18:19:48 --> Helper loaded: download_helper
INFO - 2023-09-28 18:19:48 --> Helper loaded: form_helper
INFO - 2023-09-28 18:19:48 --> Form Validation Class Initialized
INFO - 2023-09-28 18:19:48 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:19:48 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:19:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:19:48 --> Final output sent to browser
DEBUG - 2023-09-28 18:19:48 --> Total execution time: 0.1181
INFO - 2023-09-28 18:21:06 --> Config Class Initialized
INFO - 2023-09-28 18:21:06 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:21:06 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:21:06 --> Utf8 Class Initialized
INFO - 2023-09-28 18:21:06 --> URI Class Initialized
INFO - 2023-09-28 18:21:06 --> Router Class Initialized
INFO - 2023-09-28 18:21:06 --> Output Class Initialized
INFO - 2023-09-28 18:21:06 --> Security Class Initialized
DEBUG - 2023-09-28 18:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:21:06 --> Input Class Initialized
INFO - 2023-09-28 18:21:06 --> Language Class Initialized
INFO - 2023-09-28 18:21:06 --> Loader Class Initialized
INFO - 2023-09-28 18:21:06 --> Helper loaded: url_helper
INFO - 2023-09-28 18:21:06 --> Helper loaded: file_helper
INFO - 2023-09-28 18:21:06 --> Database Driver Class Initialized
INFO - 2023-09-28 18:21:06 --> Email Class Initialized
DEBUG - 2023-09-28 18:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:21:06 --> Controller Class Initialized
INFO - 2023-09-28 18:21:06 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:21:06 --> Model "Home_model" initialized
INFO - 2023-09-28 18:21:06 --> Helper loaded: download_helper
INFO - 2023-09-28 18:21:06 --> Helper loaded: form_helper
INFO - 2023-09-28 18:21:06 --> Form Validation Class Initialized
INFO - 2023-09-28 18:21:06 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:21:06 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:21:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:21:06 --> Final output sent to browser
DEBUG - 2023-09-28 18:21:06 --> Total execution time: 0.1315
INFO - 2023-09-28 18:23:06 --> Config Class Initialized
INFO - 2023-09-28 18:23:06 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:23:06 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:23:06 --> Utf8 Class Initialized
INFO - 2023-09-28 18:23:06 --> URI Class Initialized
INFO - 2023-09-28 18:23:06 --> Router Class Initialized
INFO - 2023-09-28 18:23:06 --> Output Class Initialized
INFO - 2023-09-28 18:23:06 --> Security Class Initialized
DEBUG - 2023-09-28 18:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:23:06 --> Input Class Initialized
INFO - 2023-09-28 18:23:06 --> Language Class Initialized
INFO - 2023-09-28 18:23:06 --> Loader Class Initialized
INFO - 2023-09-28 18:23:06 --> Helper loaded: url_helper
INFO - 2023-09-28 18:23:06 --> Helper loaded: file_helper
INFO - 2023-09-28 18:23:06 --> Database Driver Class Initialized
INFO - 2023-09-28 18:23:06 --> Email Class Initialized
DEBUG - 2023-09-28 18:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:23:06 --> Controller Class Initialized
INFO - 2023-09-28 18:23:06 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:23:06 --> Model "Home_model" initialized
INFO - 2023-09-28 18:23:06 --> Helper loaded: download_helper
INFO - 2023-09-28 18:23:06 --> Helper loaded: form_helper
INFO - 2023-09-28 18:23:06 --> Form Validation Class Initialized
INFO - 2023-09-28 18:23:06 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:23:06 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:23:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:23:06 --> Final output sent to browser
DEBUG - 2023-09-28 18:23:06 --> Total execution time: 0.1225
INFO - 2023-09-28 18:23:34 --> Config Class Initialized
INFO - 2023-09-28 18:23:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:23:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:23:34 --> Utf8 Class Initialized
INFO - 2023-09-28 18:23:34 --> URI Class Initialized
INFO - 2023-09-28 18:23:34 --> Router Class Initialized
INFO - 2023-09-28 18:23:34 --> Output Class Initialized
INFO - 2023-09-28 18:23:34 --> Security Class Initialized
DEBUG - 2023-09-28 18:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:23:34 --> Input Class Initialized
INFO - 2023-09-28 18:23:34 --> Language Class Initialized
INFO - 2023-09-28 18:23:34 --> Loader Class Initialized
INFO - 2023-09-28 18:23:34 --> Helper loaded: url_helper
INFO - 2023-09-28 18:23:34 --> Helper loaded: file_helper
INFO - 2023-09-28 18:23:34 --> Database Driver Class Initialized
INFO - 2023-09-28 18:23:34 --> Email Class Initialized
DEBUG - 2023-09-28 18:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:23:34 --> Controller Class Initialized
INFO - 2023-09-28 18:23:34 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:23:34 --> Model "Home_model" initialized
INFO - 2023-09-28 18:23:34 --> Helper loaded: download_helper
INFO - 2023-09-28 18:23:34 --> Helper loaded: form_helper
INFO - 2023-09-28 18:23:34 --> Form Validation Class Initialized
INFO - 2023-09-28 18:23:35 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:23:35 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:23:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:23:35 --> Final output sent to browser
DEBUG - 2023-09-28 18:23:35 --> Total execution time: 0.1604
INFO - 2023-09-28 18:24:34 --> Config Class Initialized
INFO - 2023-09-28 18:24:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:24:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:24:34 --> Utf8 Class Initialized
INFO - 2023-09-28 18:24:34 --> URI Class Initialized
INFO - 2023-09-28 18:24:34 --> Router Class Initialized
INFO - 2023-09-28 18:24:34 --> Output Class Initialized
INFO - 2023-09-28 18:24:34 --> Security Class Initialized
DEBUG - 2023-09-28 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:24:34 --> Input Class Initialized
INFO - 2023-09-28 18:24:34 --> Language Class Initialized
INFO - 2023-09-28 18:24:34 --> Loader Class Initialized
INFO - 2023-09-28 18:24:34 --> Helper loaded: url_helper
INFO - 2023-09-28 18:24:34 --> Helper loaded: file_helper
INFO - 2023-09-28 18:24:34 --> Database Driver Class Initialized
INFO - 2023-09-28 18:24:34 --> Email Class Initialized
DEBUG - 2023-09-28 18:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:24:34 --> Controller Class Initialized
INFO - 2023-09-28 18:24:34 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:24:34 --> Model "Home_model" initialized
INFO - 2023-09-28 18:24:34 --> Helper loaded: download_helper
INFO - 2023-09-28 18:24:34 --> Helper loaded: form_helper
INFO - 2023-09-28 18:24:34 --> Form Validation Class Initialized
INFO - 2023-09-28 18:24:34 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:24:34 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:24:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:24:34 --> Final output sent to browser
DEBUG - 2023-09-28 18:24:34 --> Total execution time: 0.1951
INFO - 2023-09-28 18:25:10 --> Config Class Initialized
INFO - 2023-09-28 18:25:10 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:25:10 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:25:10 --> Utf8 Class Initialized
INFO - 2023-09-28 18:25:10 --> URI Class Initialized
INFO - 2023-09-28 18:25:10 --> Router Class Initialized
INFO - 2023-09-28 18:25:10 --> Output Class Initialized
INFO - 2023-09-28 18:25:10 --> Security Class Initialized
DEBUG - 2023-09-28 18:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:25:10 --> Input Class Initialized
INFO - 2023-09-28 18:25:10 --> Language Class Initialized
INFO - 2023-09-28 18:25:10 --> Loader Class Initialized
INFO - 2023-09-28 18:25:10 --> Helper loaded: url_helper
INFO - 2023-09-28 18:25:10 --> Helper loaded: file_helper
INFO - 2023-09-28 18:25:10 --> Database Driver Class Initialized
INFO - 2023-09-28 18:25:10 --> Email Class Initialized
DEBUG - 2023-09-28 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:25:10 --> Controller Class Initialized
INFO - 2023-09-28 18:25:10 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:25:10 --> Model "Home_model" initialized
INFO - 2023-09-28 18:25:10 --> Helper loaded: download_helper
INFO - 2023-09-28 18:25:10 --> Helper loaded: form_helper
INFO - 2023-09-28 18:25:10 --> Form Validation Class Initialized
INFO - 2023-09-28 18:25:10 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:25:10 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:25:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:25:10 --> Final output sent to browser
DEBUG - 2023-09-28 18:25:11 --> Total execution time: 0.1808
INFO - 2023-09-28 18:27:19 --> Config Class Initialized
INFO - 2023-09-28 18:27:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:27:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:27:19 --> Utf8 Class Initialized
INFO - 2023-09-28 18:27:19 --> URI Class Initialized
INFO - 2023-09-28 18:27:19 --> Router Class Initialized
INFO - 2023-09-28 18:27:19 --> Output Class Initialized
INFO - 2023-09-28 18:27:19 --> Security Class Initialized
DEBUG - 2023-09-28 18:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:27:19 --> Input Class Initialized
INFO - 2023-09-28 18:27:19 --> Language Class Initialized
INFO - 2023-09-28 18:27:19 --> Loader Class Initialized
INFO - 2023-09-28 18:27:19 --> Helper loaded: url_helper
INFO - 2023-09-28 18:27:19 --> Helper loaded: file_helper
INFO - 2023-09-28 18:27:19 --> Database Driver Class Initialized
INFO - 2023-09-28 18:27:19 --> Email Class Initialized
DEBUG - 2023-09-28 18:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:27:19 --> Controller Class Initialized
INFO - 2023-09-28 18:27:19 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:27:19 --> Model "Home_model" initialized
INFO - 2023-09-28 18:27:19 --> Helper loaded: download_helper
INFO - 2023-09-28 18:27:19 --> Helper loaded: form_helper
INFO - 2023-09-28 18:27:19 --> Form Validation Class Initialized
INFO - 2023-09-28 18:27:19 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:27:19 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:27:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-28 18:27:19 --> Final output sent to browser
DEBUG - 2023-09-28 18:27:19 --> Total execution time: 0.3165
INFO - 2023-09-28 18:27:40 --> Config Class Initialized
INFO - 2023-09-28 18:27:40 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:27:40 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:27:40 --> Utf8 Class Initialized
INFO - 2023-09-28 18:27:40 --> URI Class Initialized
DEBUG - 2023-09-28 18:27:40 --> No URI present. Default controller set.
INFO - 2023-09-28 18:27:40 --> Router Class Initialized
INFO - 2023-09-28 18:27:40 --> Output Class Initialized
INFO - 2023-09-28 18:27:40 --> Security Class Initialized
DEBUG - 2023-09-28 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:27:40 --> Input Class Initialized
INFO - 2023-09-28 18:27:40 --> Language Class Initialized
INFO - 2023-09-28 18:27:40 --> Loader Class Initialized
INFO - 2023-09-28 18:27:40 --> Helper loaded: url_helper
INFO - 2023-09-28 18:27:40 --> Helper loaded: file_helper
INFO - 2023-09-28 18:27:40 --> Database Driver Class Initialized
INFO - 2023-09-28 18:27:40 --> Email Class Initialized
DEBUG - 2023-09-28 18:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:27:40 --> Controller Class Initialized
INFO - 2023-09-28 18:27:40 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:27:40 --> Model "Home_model" initialized
INFO - 2023-09-28 18:27:40 --> Helper loaded: download_helper
INFO - 2023-09-28 18:27:40 --> Helper loaded: form_helper
INFO - 2023-09-28 18:27:40 --> Form Validation Class Initialized
INFO - 2023-09-28 18:27:40 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:27:40 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:27:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-28 18:27:40 --> Final output sent to browser
DEBUG - 2023-09-28 18:27:40 --> Total execution time: 0.1436
INFO - 2023-09-28 18:27:56 --> Config Class Initialized
INFO - 2023-09-28 18:27:56 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:27:56 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:27:56 --> Utf8 Class Initialized
INFO - 2023-09-28 18:27:56 --> URI Class Initialized
DEBUG - 2023-09-28 18:27:56 --> No URI present. Default controller set.
INFO - 2023-09-28 18:27:56 --> Router Class Initialized
INFO - 2023-09-28 18:27:56 --> Output Class Initialized
INFO - 2023-09-28 18:27:56 --> Security Class Initialized
DEBUG - 2023-09-28 18:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:27:56 --> Input Class Initialized
INFO - 2023-09-28 18:27:56 --> Language Class Initialized
INFO - 2023-09-28 18:27:56 --> Loader Class Initialized
INFO - 2023-09-28 18:27:56 --> Helper loaded: url_helper
INFO - 2023-09-28 18:27:56 --> Helper loaded: file_helper
INFO - 2023-09-28 18:27:56 --> Database Driver Class Initialized
INFO - 2023-09-28 18:27:56 --> Email Class Initialized
DEBUG - 2023-09-28 18:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:27:56 --> Controller Class Initialized
INFO - 2023-09-28 18:27:56 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:27:56 --> Model "Home_model" initialized
INFO - 2023-09-28 18:27:56 --> Helper loaded: download_helper
INFO - 2023-09-28 18:27:56 --> Helper loaded: form_helper
INFO - 2023-09-28 18:27:56 --> Form Validation Class Initialized
INFO - 2023-09-28 18:27:56 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:27:56 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:27:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-28 18:27:56 --> Final output sent to browser
DEBUG - 2023-09-28 18:27:56 --> Total execution time: 0.1352
INFO - 2023-09-28 18:28:05 --> Config Class Initialized
INFO - 2023-09-28 18:28:05 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:05 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:05 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:05 --> URI Class Initialized
INFO - 2023-09-28 18:28:05 --> Router Class Initialized
INFO - 2023-09-28 18:28:05 --> Output Class Initialized
INFO - 2023-09-28 18:28:05 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:05 --> Input Class Initialized
INFO - 2023-09-28 18:28:05 --> Language Class Initialized
INFO - 2023-09-28 18:28:05 --> Loader Class Initialized
INFO - 2023-09-28 18:28:05 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:05 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:05 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:05 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:05 --> Controller Class Initialized
INFO - 2023-09-28 18:28:05 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:05 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:05 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:05 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:05 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:05 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:05 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:05 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:05 --> Total execution time: 0.3166
INFO - 2023-09-28 18:28:09 --> Config Class Initialized
INFO - 2023-09-28 18:28:09 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:09 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:09 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:09 --> URI Class Initialized
INFO - 2023-09-28 18:28:09 --> Router Class Initialized
INFO - 2023-09-28 18:28:09 --> Output Class Initialized
INFO - 2023-09-28 18:28:09 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:09 --> Input Class Initialized
INFO - 2023-09-28 18:28:09 --> Language Class Initialized
INFO - 2023-09-28 18:28:09 --> Loader Class Initialized
INFO - 2023-09-28 18:28:09 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:09 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:09 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:09 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:09 --> Controller Class Initialized
INFO - 2023-09-28 18:28:09 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:09 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:09 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:09 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:09 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:09 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:09 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:09 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:09 --> Total execution time: 0.1404
INFO - 2023-09-28 18:28:15 --> Config Class Initialized
INFO - 2023-09-28 18:28:15 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:15 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:15 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:15 --> URI Class Initialized
INFO - 2023-09-28 18:28:15 --> Router Class Initialized
INFO - 2023-09-28 18:28:15 --> Output Class Initialized
INFO - 2023-09-28 18:28:15 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:15 --> Input Class Initialized
INFO - 2023-09-28 18:28:15 --> Language Class Initialized
INFO - 2023-09-28 18:28:15 --> Loader Class Initialized
INFO - 2023-09-28 18:28:15 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:15 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:15 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:15 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:15 --> Controller Class Initialized
INFO - 2023-09-28 18:28:15 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:15 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:15 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:15 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:15 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:15 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:15 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:15 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:15 --> Total execution time: 0.1569
INFO - 2023-09-28 18:28:18 --> Config Class Initialized
INFO - 2023-09-28 18:28:18 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:18 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:18 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:18 --> URI Class Initialized
INFO - 2023-09-28 18:28:18 --> Router Class Initialized
INFO - 2023-09-28 18:28:18 --> Output Class Initialized
INFO - 2023-09-28 18:28:18 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:18 --> Input Class Initialized
INFO - 2023-09-28 18:28:18 --> Language Class Initialized
INFO - 2023-09-28 18:28:18 --> Loader Class Initialized
INFO - 2023-09-28 18:28:18 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:18 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:18 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:18 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:18 --> Controller Class Initialized
INFO - 2023-09-28 18:28:18 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:18 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:18 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:18 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:18 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:18 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:18 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:18 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:18 --> Total execution time: 0.1609
INFO - 2023-09-28 18:28:21 --> Config Class Initialized
INFO - 2023-09-28 18:28:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:21 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:21 --> URI Class Initialized
INFO - 2023-09-28 18:28:21 --> Router Class Initialized
INFO - 2023-09-28 18:28:21 --> Output Class Initialized
INFO - 2023-09-28 18:28:21 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:21 --> Input Class Initialized
INFO - 2023-09-28 18:28:21 --> Language Class Initialized
INFO - 2023-09-28 18:28:21 --> Loader Class Initialized
INFO - 2023-09-28 18:28:21 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:21 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:21 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:21 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:21 --> Controller Class Initialized
INFO - 2023-09-28 18:28:21 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:21 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:21 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:21 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:21 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:21 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:21 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:21 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:21 --> Total execution time: 0.1352
INFO - 2023-09-28 18:28:24 --> Config Class Initialized
INFO - 2023-09-28 18:28:24 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:24 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:24 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:24 --> URI Class Initialized
INFO - 2023-09-28 18:28:24 --> Router Class Initialized
INFO - 2023-09-28 18:28:24 --> Output Class Initialized
INFO - 2023-09-28 18:28:24 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:24 --> Input Class Initialized
INFO - 2023-09-28 18:28:24 --> Language Class Initialized
INFO - 2023-09-28 18:28:24 --> Loader Class Initialized
INFO - 2023-09-28 18:28:24 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:24 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:24 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:24 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:24 --> Controller Class Initialized
INFO - 2023-09-28 18:28:24 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:24 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:24 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:24 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:24 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:24 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:24 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:24 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:24 --> Total execution time: 0.1235
INFO - 2023-09-28 18:28:31 --> Config Class Initialized
INFO - 2023-09-28 18:28:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:31 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:31 --> URI Class Initialized
INFO - 2023-09-28 18:28:31 --> Router Class Initialized
INFO - 2023-09-28 18:28:31 --> Output Class Initialized
INFO - 2023-09-28 18:28:31 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:31 --> Input Class Initialized
INFO - 2023-09-28 18:28:31 --> Language Class Initialized
INFO - 2023-09-28 18:28:31 --> Loader Class Initialized
INFO - 2023-09-28 18:28:31 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:31 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:31 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:31 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:31 --> Controller Class Initialized
INFO - 2023-09-28 18:28:31 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:31 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:31 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:31 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:31 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:31 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:31 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:31 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:31 --> Total execution time: 0.1511
INFO - 2023-09-28 18:28:48 --> Config Class Initialized
INFO - 2023-09-28 18:28:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:48 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:48 --> URI Class Initialized
INFO - 2023-09-28 18:28:48 --> Router Class Initialized
INFO - 2023-09-28 18:28:48 --> Output Class Initialized
INFO - 2023-09-28 18:28:48 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:48 --> Input Class Initialized
INFO - 2023-09-28 18:28:48 --> Language Class Initialized
INFO - 2023-09-28 18:28:48 --> Loader Class Initialized
INFO - 2023-09-28 18:28:48 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:48 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:48 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:48 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:48 --> Controller Class Initialized
INFO - 2023-09-28 18:28:48 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:48 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:48 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:48 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:48 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:48 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:48 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:48 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:48 --> Total execution time: 0.1221
INFO - 2023-09-28 18:28:52 --> Config Class Initialized
INFO - 2023-09-28 18:28:52 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:52 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:52 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:52 --> URI Class Initialized
INFO - 2023-09-28 18:28:52 --> Router Class Initialized
INFO - 2023-09-28 18:28:52 --> Output Class Initialized
INFO - 2023-09-28 18:28:52 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:52 --> Input Class Initialized
INFO - 2023-09-28 18:28:52 --> Language Class Initialized
INFO - 2023-09-28 18:28:52 --> Loader Class Initialized
INFO - 2023-09-28 18:28:52 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:52 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:52 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:52 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:52 --> Controller Class Initialized
INFO - 2023-09-28 18:28:52 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:52 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:52 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:52 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:52 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:52 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:52 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:52 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:52 --> Total execution time: 0.1086
INFO - 2023-09-28 18:28:58 --> Config Class Initialized
INFO - 2023-09-28 18:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:28:58 --> Utf8 Class Initialized
INFO - 2023-09-28 18:28:58 --> URI Class Initialized
INFO - 2023-09-28 18:28:58 --> Router Class Initialized
INFO - 2023-09-28 18:28:58 --> Output Class Initialized
INFO - 2023-09-28 18:28:58 --> Security Class Initialized
DEBUG - 2023-09-28 18:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:28:58 --> Input Class Initialized
INFO - 2023-09-28 18:28:58 --> Language Class Initialized
INFO - 2023-09-28 18:28:58 --> Loader Class Initialized
INFO - 2023-09-28 18:28:58 --> Helper loaded: url_helper
INFO - 2023-09-28 18:28:58 --> Helper loaded: file_helper
INFO - 2023-09-28 18:28:58 --> Database Driver Class Initialized
INFO - 2023-09-28 18:28:58 --> Email Class Initialized
DEBUG - 2023-09-28 18:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:28:58 --> Controller Class Initialized
INFO - 2023-09-28 18:28:58 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:28:58 --> Model "Home_model" initialized
INFO - 2023-09-28 18:28:58 --> Helper loaded: download_helper
INFO - 2023-09-28 18:28:58 --> Helper loaded: form_helper
INFO - 2023-09-28 18:28:58 --> Form Validation Class Initialized
INFO - 2023-09-28 18:28:58 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:28:58 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:28:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:28:58 --> Final output sent to browser
DEBUG - 2023-09-28 18:28:58 --> Total execution time: 0.1258
INFO - 2023-09-28 18:29:54 --> Config Class Initialized
INFO - 2023-09-28 18:29:54 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:29:54 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:29:54 --> Utf8 Class Initialized
INFO - 2023-09-28 18:29:54 --> URI Class Initialized
INFO - 2023-09-28 18:29:54 --> Router Class Initialized
INFO - 2023-09-28 18:29:54 --> Output Class Initialized
INFO - 2023-09-28 18:29:54 --> Security Class Initialized
DEBUG - 2023-09-28 18:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:29:54 --> Input Class Initialized
INFO - 2023-09-28 18:29:54 --> Language Class Initialized
INFO - 2023-09-28 18:29:54 --> Loader Class Initialized
INFO - 2023-09-28 18:29:54 --> Helper loaded: url_helper
INFO - 2023-09-28 18:29:54 --> Helper loaded: file_helper
INFO - 2023-09-28 18:29:54 --> Database Driver Class Initialized
INFO - 2023-09-28 18:29:54 --> Email Class Initialized
DEBUG - 2023-09-28 18:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:29:54 --> Controller Class Initialized
INFO - 2023-09-28 18:29:54 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:29:54 --> Model "Home_model" initialized
INFO - 2023-09-28 18:29:54 --> Helper loaded: download_helper
INFO - 2023-09-28 18:29:54 --> Helper loaded: form_helper
INFO - 2023-09-28 18:29:54 --> Form Validation Class Initialized
INFO - 2023-09-28 18:29:55 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:29:55 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:29:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:29:55 --> Final output sent to browser
DEBUG - 2023-09-28 18:29:55 --> Total execution time: 0.4786
INFO - 2023-09-28 18:30:00 --> Config Class Initialized
INFO - 2023-09-28 18:30:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:30:00 --> Utf8 Class Initialized
INFO - 2023-09-28 18:30:00 --> URI Class Initialized
INFO - 2023-09-28 18:30:00 --> Router Class Initialized
INFO - 2023-09-28 18:30:00 --> Output Class Initialized
INFO - 2023-09-28 18:30:00 --> Security Class Initialized
DEBUG - 2023-09-28 18:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:30:00 --> Input Class Initialized
INFO - 2023-09-28 18:30:00 --> Language Class Initialized
INFO - 2023-09-28 18:30:00 --> Loader Class Initialized
INFO - 2023-09-28 18:30:00 --> Helper loaded: url_helper
INFO - 2023-09-28 18:30:00 --> Helper loaded: file_helper
INFO - 2023-09-28 18:30:00 --> Database Driver Class Initialized
INFO - 2023-09-28 18:30:00 --> Email Class Initialized
DEBUG - 2023-09-28 18:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:30:00 --> Controller Class Initialized
INFO - 2023-09-28 18:30:00 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:30:00 --> Model "Home_model" initialized
INFO - 2023-09-28 18:30:00 --> Helper loaded: download_helper
INFO - 2023-09-28 18:30:00 --> Helper loaded: form_helper
INFO - 2023-09-28 18:30:00 --> Form Validation Class Initialized
INFO - 2023-09-28 18:30:00 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:30:00 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:30:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:30:00 --> Final output sent to browser
DEBUG - 2023-09-28 18:30:00 --> Total execution time: 0.1368
INFO - 2023-09-28 18:31:31 --> Config Class Initialized
INFO - 2023-09-28 18:31:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:31 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:31 --> URI Class Initialized
INFO - 2023-09-28 18:31:31 --> Router Class Initialized
INFO - 2023-09-28 18:31:31 --> Output Class Initialized
INFO - 2023-09-28 18:31:31 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:31 --> Input Class Initialized
INFO - 2023-09-28 18:31:31 --> Language Class Initialized
INFO - 2023-09-28 18:31:31 --> Loader Class Initialized
INFO - 2023-09-28 18:31:31 --> Helper loaded: url_helper
INFO - 2023-09-28 18:31:31 --> Helper loaded: file_helper
INFO - 2023-09-28 18:31:31 --> Database Driver Class Initialized
INFO - 2023-09-28 18:31:31 --> Email Class Initialized
DEBUG - 2023-09-28 18:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:31:31 --> Controller Class Initialized
INFO - 2023-09-28 18:31:31 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:31:31 --> Model "Home_model" initialized
INFO - 2023-09-28 18:31:31 --> Helper loaded: download_helper
INFO - 2023-09-28 18:31:31 --> Helper loaded: form_helper
INFO - 2023-09-28 18:31:31 --> Form Validation Class Initialized
INFO - 2023-09-28 18:31:31 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:31:31 --> Model "Social_media_model" initialized
ERROR - 2023-09-28 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 52
ERROR - 2023-09-28 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 72
ERROR - 2023-09-28 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 158
ERROR - 2023-09-28 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 162
ERROR - 2023-09-28 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 166
INFO - 2023-09-28 18:31:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:31:31 --> Final output sent to browser
DEBUG - 2023-09-28 18:31:31 --> Total execution time: 0.1286
INFO - 2023-09-28 18:31:31 --> Config Class Initialized
INFO - 2023-09-28 18:31:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:31 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:38 --> Config Class Initialized
INFO - 2023-09-28 18:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:38 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:38 --> URI Class Initialized
INFO - 2023-09-28 18:31:38 --> Router Class Initialized
INFO - 2023-09-28 18:31:38 --> Output Class Initialized
INFO - 2023-09-28 18:31:38 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:38 --> Input Class Initialized
INFO - 2023-09-28 18:31:38 --> Language Class Initialized
INFO - 2023-09-28 18:31:38 --> Loader Class Initialized
INFO - 2023-09-28 18:31:38 --> Helper loaded: url_helper
INFO - 2023-09-28 18:31:38 --> Helper loaded: file_helper
INFO - 2023-09-28 18:31:38 --> Database Driver Class Initialized
INFO - 2023-09-28 18:31:38 --> Email Class Initialized
DEBUG - 2023-09-28 18:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:31:38 --> Controller Class Initialized
INFO - 2023-09-28 18:31:38 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:31:38 --> Model "Home_model" initialized
INFO - 2023-09-28 18:31:38 --> Helper loaded: download_helper
INFO - 2023-09-28 18:31:38 --> Helper loaded: form_helper
INFO - 2023-09-28 18:31:38 --> Form Validation Class Initialized
INFO - 2023-09-28 18:31:38 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:31:38 --> Model "Social_media_model" initialized
ERROR - 2023-09-28 18:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 52
ERROR - 2023-09-28 18:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 72
ERROR - 2023-09-28 18:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 158
ERROR - 2023-09-28 18:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 162
ERROR - 2023-09-28 18:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 166
INFO - 2023-09-28 18:31:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-28 18:31:38 --> Final output sent to browser
DEBUG - 2023-09-28 18:31:38 --> Total execution time: 0.1307
INFO - 2023-09-28 18:31:39 --> Config Class Initialized
INFO - 2023-09-28 18:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:39 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:50 --> Config Class Initialized
INFO - 2023-09-28 18:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:50 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:50 --> URI Class Initialized
INFO - 2023-09-28 18:31:50 --> Router Class Initialized
INFO - 2023-09-28 18:31:50 --> Output Class Initialized
INFO - 2023-09-28 18:31:50 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:50 --> Input Class Initialized
INFO - 2023-09-28 18:31:50 --> Language Class Initialized
INFO - 2023-09-28 18:31:50 --> Loader Class Initialized
INFO - 2023-09-28 18:31:50 --> Helper loaded: url_helper
INFO - 2023-09-28 18:31:50 --> Helper loaded: file_helper
INFO - 2023-09-28 18:31:50 --> Database Driver Class Initialized
INFO - 2023-09-28 18:31:50 --> Email Class Initialized
DEBUG - 2023-09-28 18:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:31:50 --> Controller Class Initialized
INFO - 2023-09-28 18:31:50 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:31:50 --> Model "Home_model" initialized
INFO - 2023-09-28 18:31:50 --> Helper loaded: download_helper
INFO - 2023-09-28 18:31:50 --> Helper loaded: form_helper
INFO - 2023-09-28 18:31:50 --> Form Validation Class Initialized
INFO - 2023-09-28 18:31:50 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:31:50 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:31:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-09-28 18:31:50 --> Final output sent to browser
DEBUG - 2023-09-28 18:31:50 --> Total execution time: 0.1376
INFO - 2023-09-28 18:31:50 --> Config Class Initialized
INFO - 2023-09-28 18:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:50 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:50 --> URI Class Initialized
INFO - 2023-09-28 18:31:50 --> Router Class Initialized
INFO - 2023-09-28 18:31:50 --> Output Class Initialized
INFO - 2023-09-28 18:31:50 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:50 --> Input Class Initialized
INFO - 2023-09-28 18:31:50 --> Language Class Initialized
ERROR - 2023-09-28 18:31:50 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:31:51 --> Config Class Initialized
INFO - 2023-09-28 18:31:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:51 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:51 --> URI Class Initialized
INFO - 2023-09-28 18:31:51 --> Router Class Initialized
INFO - 2023-09-28 18:31:51 --> Output Class Initialized
INFO - 2023-09-28 18:31:51 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:51 --> Input Class Initialized
INFO - 2023-09-28 18:31:51 --> Language Class Initialized
ERROR - 2023-09-28 18:31:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:31:51 --> Config Class Initialized
INFO - 2023-09-28 18:31:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:51 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:51 --> URI Class Initialized
INFO - 2023-09-28 18:31:51 --> Router Class Initialized
INFO - 2023-09-28 18:31:51 --> Output Class Initialized
INFO - 2023-09-28 18:31:51 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:51 --> Input Class Initialized
INFO - 2023-09-28 18:31:51 --> Language Class Initialized
ERROR - 2023-09-28 18:31:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:31:51 --> Config Class Initialized
INFO - 2023-09-28 18:31:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:51 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:51 --> URI Class Initialized
INFO - 2023-09-28 18:31:51 --> Router Class Initialized
INFO - 2023-09-28 18:31:51 --> Output Class Initialized
INFO - 2023-09-28 18:31:51 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:51 --> Input Class Initialized
INFO - 2023-09-28 18:31:51 --> Language Class Initialized
ERROR - 2023-09-28 18:31:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:31:51 --> Config Class Initialized
INFO - 2023-09-28 18:31:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:51 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:51 --> URI Class Initialized
INFO - 2023-09-28 18:31:51 --> Router Class Initialized
INFO - 2023-09-28 18:31:51 --> Output Class Initialized
INFO - 2023-09-28 18:31:51 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:51 --> Input Class Initialized
INFO - 2023-09-28 18:31:51 --> Language Class Initialized
ERROR - 2023-09-28 18:31:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:31:55 --> Config Class Initialized
INFO - 2023-09-28 18:31:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:55 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:55 --> URI Class Initialized
INFO - 2023-09-28 18:31:55 --> Router Class Initialized
INFO - 2023-09-28 18:31:55 --> Output Class Initialized
INFO - 2023-09-28 18:31:55 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:55 --> Input Class Initialized
INFO - 2023-09-28 18:31:55 --> Language Class Initialized
INFO - 2023-09-28 18:31:55 --> Loader Class Initialized
INFO - 2023-09-28 18:31:55 --> Helper loaded: url_helper
INFO - 2023-09-28 18:31:55 --> Helper loaded: file_helper
INFO - 2023-09-28 18:31:55 --> Database Driver Class Initialized
INFO - 2023-09-28 18:31:55 --> Email Class Initialized
DEBUG - 2023-09-28 18:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:31:55 --> Controller Class Initialized
INFO - 2023-09-28 18:31:55 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:31:55 --> Model "Home_model" initialized
INFO - 2023-09-28 18:31:55 --> Helper loaded: download_helper
INFO - 2023-09-28 18:31:55 --> Helper loaded: form_helper
INFO - 2023-09-28 18:31:55 --> Form Validation Class Initialized
INFO - 2023-09-28 18:31:55 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:31:55 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:31:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-09-28 18:31:55 --> Final output sent to browser
DEBUG - 2023-09-28 18:31:55 --> Total execution time: 0.0908
INFO - 2023-09-28 18:31:56 --> Config Class Initialized
INFO - 2023-09-28 18:31:56 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:31:56 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:31:56 --> Utf8 Class Initialized
INFO - 2023-09-28 18:31:56 --> URI Class Initialized
INFO - 2023-09-28 18:31:56 --> Router Class Initialized
INFO - 2023-09-28 18:31:56 --> Output Class Initialized
INFO - 2023-09-28 18:31:56 --> Security Class Initialized
DEBUG - 2023-09-28 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:31:56 --> Input Class Initialized
INFO - 2023-09-28 18:31:56 --> Language Class Initialized
ERROR - 2023-09-28 18:31:56 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:34:28 --> Config Class Initialized
INFO - 2023-09-28 18:34:28 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:34:28 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:34:28 --> Utf8 Class Initialized
INFO - 2023-09-28 18:34:28 --> URI Class Initialized
INFO - 2023-09-28 18:34:28 --> Router Class Initialized
INFO - 2023-09-28 18:34:28 --> Output Class Initialized
INFO - 2023-09-28 18:34:28 --> Security Class Initialized
DEBUG - 2023-09-28 18:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:34:28 --> Input Class Initialized
INFO - 2023-09-28 18:34:28 --> Language Class Initialized
INFO - 2023-09-28 18:34:28 --> Loader Class Initialized
INFO - 2023-09-28 18:34:28 --> Helper loaded: url_helper
INFO - 2023-09-28 18:34:28 --> Helper loaded: file_helper
INFO - 2023-09-28 18:34:28 --> Database Driver Class Initialized
INFO - 2023-09-28 18:34:28 --> Email Class Initialized
DEBUG - 2023-09-28 18:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:34:28 --> Controller Class Initialized
INFO - 2023-09-28 18:34:28 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:34:28 --> Model "Home_model" initialized
INFO - 2023-09-28 18:34:28 --> Helper loaded: download_helper
INFO - 2023-09-28 18:34:28 --> Helper loaded: form_helper
INFO - 2023-09-28 18:34:28 --> Form Validation Class Initialized
INFO - 2023-09-28 18:34:28 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:34:28 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:34:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-09-28 18:34:28 --> Final output sent to browser
DEBUG - 2023-09-28 18:34:29 --> Total execution time: 0.1789
INFO - 2023-09-28 18:34:29 --> Config Class Initialized
INFO - 2023-09-28 18:34:29 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:34:29 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:34:29 --> Utf8 Class Initialized
INFO - 2023-09-28 18:34:29 --> URI Class Initialized
INFO - 2023-09-28 18:34:29 --> Router Class Initialized
INFO - 2023-09-28 18:34:29 --> Output Class Initialized
INFO - 2023-09-28 18:34:29 --> Security Class Initialized
DEBUG - 2023-09-28 18:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:34:29 --> Input Class Initialized
INFO - 2023-09-28 18:34:29 --> Language Class Initialized
ERROR - 2023-09-28 18:34:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-28 18:34:53 --> Config Class Initialized
INFO - 2023-09-28 18:34:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:34:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:34:53 --> Utf8 Class Initialized
INFO - 2023-09-28 18:34:53 --> URI Class Initialized
INFO - 2023-09-28 18:34:53 --> Router Class Initialized
INFO - 2023-09-28 18:34:53 --> Output Class Initialized
INFO - 2023-09-28 18:34:53 --> Security Class Initialized
DEBUG - 2023-09-28 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:34:53 --> Input Class Initialized
INFO - 2023-09-28 18:34:53 --> Language Class Initialized
INFO - 2023-09-28 18:34:53 --> Loader Class Initialized
INFO - 2023-09-28 18:34:53 --> Helper loaded: url_helper
INFO - 2023-09-28 18:34:53 --> Helper loaded: file_helper
INFO - 2023-09-28 18:34:53 --> Database Driver Class Initialized
INFO - 2023-09-28 18:34:53 --> Email Class Initialized
DEBUG - 2023-09-28 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-28 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:34:53 --> Controller Class Initialized
INFO - 2023-09-28 18:34:53 --> Model "Contact_model" initialized
INFO - 2023-09-28 18:34:53 --> Model "Home_model" initialized
INFO - 2023-09-28 18:34:53 --> Helper loaded: download_helper
INFO - 2023-09-28 18:34:53 --> Helper loaded: form_helper
INFO - 2023-09-28 18:34:53 --> Form Validation Class Initialized
INFO - 2023-09-28 18:34:53 --> Helper loaded: custom_helper
INFO - 2023-09-28 18:34:53 --> Model "Social_media_model" initialized
INFO - 2023-09-28 18:34:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-09-28 18:34:53 --> Final output sent to browser
DEBUG - 2023-09-28 18:34:53 --> Total execution time: 0.1846
INFO - 2023-09-28 18:34:54 --> Config Class Initialized
INFO - 2023-09-28 18:34:54 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:34:54 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:34:54 --> Utf8 Class Initialized
INFO - 2023-09-28 18:34:54 --> URI Class Initialized
INFO - 2023-09-28 18:34:54 --> Router Class Initialized
INFO - 2023-09-28 18:34:54 --> Output Class Initialized
INFO - 2023-09-28 18:34:54 --> Security Class Initialized
DEBUG - 2023-09-28 18:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:34:55 --> Input Class Initialized
INFO - 2023-09-28 18:34:55 --> Language Class Initialized
ERROR - 2023-09-28 18:34:55 --> 404 Page Not Found: Assets/images
