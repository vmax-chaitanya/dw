<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-05 08:21:48 --> Config Class Initialized
INFO - 2023-11-05 08:21:48 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:21:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:21:48 --> Utf8 Class Initialized
INFO - 2023-11-05 08:21:48 --> URI Class Initialized
DEBUG - 2023-11-05 08:21:48 --> No URI present. Default controller set.
INFO - 2023-11-05 08:21:48 --> Router Class Initialized
INFO - 2023-11-05 08:21:48 --> Output Class Initialized
INFO - 2023-11-05 08:21:48 --> Security Class Initialized
DEBUG - 2023-11-05 08:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:21:48 --> Input Class Initialized
INFO - 2023-11-05 08:21:48 --> Language Class Initialized
INFO - 2023-11-05 08:21:48 --> Loader Class Initialized
INFO - 2023-11-05 08:21:48 --> Helper loaded: url_helper
INFO - 2023-11-05 08:21:48 --> Helper loaded: file_helper
INFO - 2023-11-05 08:21:49 --> Database Driver Class Initialized
INFO - 2023-11-05 08:21:49 --> Email Class Initialized
DEBUG - 2023-11-05 08:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:21:49 --> Controller Class Initialized
INFO - 2023-11-05 08:21:49 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:21:49 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:21:49 --> Model "Home_model" initialized
INFO - 2023-11-05 08:21:49 --> Helper loaded: download_helper
INFO - 2023-11-05 08:21:49 --> Helper loaded: form_helper
INFO - 2023-11-05 08:21:49 --> Form Validation Class Initialized
INFO - 2023-11-05 12:51:49 --> Helper loaded: custom_helper
INFO - 2023-11-05 12:51:49 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 12:51:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 12:51:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-05 12:51:49 --> Final output sent to browser
DEBUG - 2023-11-05 12:51:49 --> Total execution time: 1.4975
INFO - 2023-11-05 08:25:17 --> Config Class Initialized
INFO - 2023-11-05 08:25:17 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:25:17 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:25:17 --> Utf8 Class Initialized
INFO - 2023-11-05 08:25:17 --> URI Class Initialized
DEBUG - 2023-11-05 08:25:17 --> No URI present. Default controller set.
INFO - 2023-11-05 08:25:17 --> Router Class Initialized
INFO - 2023-11-05 08:25:17 --> Output Class Initialized
INFO - 2023-11-05 08:25:17 --> Security Class Initialized
DEBUG - 2023-11-05 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:25:17 --> Input Class Initialized
INFO - 2023-11-05 08:25:17 --> Language Class Initialized
INFO - 2023-11-05 08:25:17 --> Loader Class Initialized
INFO - 2023-11-05 08:25:17 --> Helper loaded: url_helper
INFO - 2023-11-05 08:25:17 --> Helper loaded: file_helper
INFO - 2023-11-05 08:25:17 --> Database Driver Class Initialized
INFO - 2023-11-05 08:25:17 --> Email Class Initialized
DEBUG - 2023-11-05 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:25:17 --> Controller Class Initialized
INFO - 2023-11-05 08:25:17 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:25:17 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:25:17 --> Model "Home_model" initialized
INFO - 2023-11-05 08:25:17 --> Helper loaded: download_helper
INFO - 2023-11-05 08:25:17 --> Helper loaded: form_helper
INFO - 2023-11-05 08:25:17 --> Form Validation Class Initialized
INFO - 2023-11-05 12:55:17 --> Helper loaded: custom_helper
INFO - 2023-11-05 12:55:17 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 12:55:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 12:55:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-05 12:55:17 --> Final output sent to browser
DEBUG - 2023-11-05 12:55:17 --> Total execution time: 0.1097
INFO - 2023-11-05 08:27:55 --> Config Class Initialized
INFO - 2023-11-05 08:27:55 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:27:55 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:27:55 --> Utf8 Class Initialized
INFO - 2023-11-05 08:27:56 --> URI Class Initialized
DEBUG - 2023-11-05 08:27:56 --> No URI present. Default controller set.
INFO - 2023-11-05 08:27:56 --> Router Class Initialized
INFO - 2023-11-05 08:27:56 --> Output Class Initialized
INFO - 2023-11-05 08:27:56 --> Security Class Initialized
DEBUG - 2023-11-05 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:27:56 --> Input Class Initialized
INFO - 2023-11-05 08:27:56 --> Language Class Initialized
INFO - 2023-11-05 08:27:56 --> Loader Class Initialized
INFO - 2023-11-05 08:27:56 --> Helper loaded: url_helper
INFO - 2023-11-05 08:27:56 --> Helper loaded: file_helper
INFO - 2023-11-05 08:27:56 --> Database Driver Class Initialized
INFO - 2023-11-05 08:27:56 --> Email Class Initialized
DEBUG - 2023-11-05 08:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:27:56 --> Controller Class Initialized
INFO - 2023-11-05 08:27:56 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:27:56 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:27:56 --> Model "Home_model" initialized
INFO - 2023-11-05 08:27:56 --> Helper loaded: download_helper
INFO - 2023-11-05 08:27:56 --> Helper loaded: form_helper
INFO - 2023-11-05 08:27:56 --> Form Validation Class Initialized
INFO - 2023-11-05 12:57:56 --> Helper loaded: custom_helper
INFO - 2023-11-05 12:57:56 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 12:57:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 12:57:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-05 12:57:56 --> Final output sent to browser
DEBUG - 2023-11-05 12:57:56 --> Total execution time: 0.5350
INFO - 2023-11-05 08:28:12 --> Config Class Initialized
INFO - 2023-11-05 08:28:12 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:28:12 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:28:12 --> Utf8 Class Initialized
INFO - 2023-11-05 08:28:12 --> URI Class Initialized
DEBUG - 2023-11-05 08:28:12 --> No URI present. Default controller set.
INFO - 2023-11-05 08:28:12 --> Router Class Initialized
INFO - 2023-11-05 08:28:12 --> Output Class Initialized
INFO - 2023-11-05 08:28:12 --> Security Class Initialized
DEBUG - 2023-11-05 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:28:12 --> Input Class Initialized
INFO - 2023-11-05 08:28:12 --> Language Class Initialized
INFO - 2023-11-05 08:28:12 --> Loader Class Initialized
INFO - 2023-11-05 08:28:12 --> Helper loaded: url_helper
INFO - 2023-11-05 08:28:12 --> Helper loaded: file_helper
INFO - 2023-11-05 08:28:12 --> Database Driver Class Initialized
INFO - 2023-11-05 08:28:13 --> Email Class Initialized
DEBUG - 2023-11-05 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:28:13 --> Controller Class Initialized
INFO - 2023-11-05 08:28:13 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:28:13 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:28:13 --> Model "Home_model" initialized
INFO - 2023-11-05 08:28:13 --> Helper loaded: download_helper
INFO - 2023-11-05 08:28:13 --> Helper loaded: form_helper
INFO - 2023-11-05 08:28:13 --> Form Validation Class Initialized
INFO - 2023-11-05 12:58:13 --> Helper loaded: custom_helper
INFO - 2023-11-05 12:58:13 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 12:58:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 12:58:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-11-05 12:58:13 --> Final output sent to browser
DEBUG - 2023-11-05 12:58:13 --> Total execution time: 0.1739
INFO - 2023-11-05 08:39:38 --> Config Class Initialized
INFO - 2023-11-05 08:39:38 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:38 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:38 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:38 --> URI Class Initialized
INFO - 2023-11-05 08:39:38 --> Router Class Initialized
INFO - 2023-11-05 08:39:38 --> Output Class Initialized
INFO - 2023-11-05 08:39:38 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:38 --> Input Class Initialized
INFO - 2023-11-05 08:39:38 --> Language Class Initialized
INFO - 2023-11-05 08:39:38 --> Loader Class Initialized
INFO - 2023-11-05 08:39:38 --> Helper loaded: url_helper
INFO - 2023-11-05 08:39:38 --> Helper loaded: file_helper
INFO - 2023-11-05 08:39:38 --> Database Driver Class Initialized
INFO - 2023-11-05 08:39:38 --> Email Class Initialized
DEBUG - 2023-11-05 08:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:39:38 --> Controller Class Initialized
INFO - 2023-11-05 08:39:38 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:39:38 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:39:38 --> Model "Home_model" initialized
INFO - 2023-11-05 08:39:38 --> Helper loaded: download_helper
INFO - 2023-11-05 08:39:38 --> Helper loaded: form_helper
INFO - 2023-11-05 08:39:38 --> Form Validation Class Initialized
INFO - 2023-11-05 13:09:38 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:09:38 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:09:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:09:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:09:38 --> Final output sent to browser
DEBUG - 2023-11-05 13:09:38 --> Total execution time: 0.2168
INFO - 2023-11-05 08:39:43 --> Config Class Initialized
INFO - 2023-11-05 08:39:43 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:43 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:43 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:43 --> URI Class Initialized
INFO - 2023-11-05 08:39:43 --> Router Class Initialized
INFO - 2023-11-05 08:39:43 --> Output Class Initialized
INFO - 2023-11-05 08:39:43 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:43 --> Config Class Initialized
INFO - 2023-11-05 08:39:43 --> Hooks Class Initialized
INFO - 2023-11-05 08:39:43 --> Input Class Initialized
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
INFO - 2023-11-05 08:39:44 --> Config Class Initialized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Config Class Initialized
INFO - 2023-11-05 08:39:44 --> Config Class Initialized
INFO - 2023-11-05 08:39:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:44 --> Hooks Class Initialized
INFO - 2023-11-05 08:39:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:44 --> Config Class Initialized
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
INFO - 2023-11-05 08:39:44 --> Config Class Initialized
INFO - 2023-11-05 08:39:44 --> Hooks Class Initialized
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
INFO - 2023-11-05 08:39:44 --> Hooks Class Initialized
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 08:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> URI Class Initialized
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
INFO - 2023-11-05 08:39:44 --> Router Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:44 --> Output Class Initialized
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> Security Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
DEBUG - 2023-11-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:44 --> Input Class Initialized
INFO - 2023-11-05 08:39:44 --> Language Class Initialized
ERROR - 2023-11-05 08:39:44 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:46 --> Config Class Initialized
INFO - 2023-11-05 08:39:46 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:46 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:46 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:46 --> URI Class Initialized
INFO - 2023-11-05 08:39:46 --> Router Class Initialized
INFO - 2023-11-05 08:39:46 --> Output Class Initialized
INFO - 2023-11-05 08:39:46 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:46 --> Input Class Initialized
INFO - 2023-11-05 08:39:46 --> Language Class Initialized
INFO - 2023-11-05 08:39:46 --> Loader Class Initialized
INFO - 2023-11-05 08:39:46 --> Helper loaded: url_helper
INFO - 2023-11-05 08:39:46 --> Helper loaded: file_helper
INFO - 2023-11-05 08:39:46 --> Database Driver Class Initialized
INFO - 2023-11-05 08:39:46 --> Email Class Initialized
DEBUG - 2023-11-05 08:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:39:46 --> Controller Class Initialized
INFO - 2023-11-05 08:39:46 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:39:46 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:39:46 --> Model "Home_model" initialized
INFO - 2023-11-05 08:39:46 --> Helper loaded: download_helper
INFO - 2023-11-05 08:39:46 --> Helper loaded: form_helper
INFO - 2023-11-05 08:39:46 --> Form Validation Class Initialized
INFO - 2023-11-05 13:09:46 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:09:46 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:09:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:09:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:09:46 --> Final output sent to browser
DEBUG - 2023-11-05 13:09:46 --> Total execution time: 0.1486
INFO - 2023-11-05 08:39:47 --> Config Class Initialized
INFO - 2023-11-05 08:39:47 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:47 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:47 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:47 --> URI Class Initialized
INFO - 2023-11-05 08:39:47 --> Router Class Initialized
INFO - 2023-11-05 08:39:47 --> Output Class Initialized
INFO - 2023-11-05 08:39:47 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:47 --> Config Class Initialized
INFO - 2023-11-05 08:39:47 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:47 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:47 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:47 --> URI Class Initialized
INFO - 2023-11-05 08:39:47 --> Router Class Initialized
INFO - 2023-11-05 08:39:47 --> Output Class Initialized
INFO - 2023-11-05 08:39:47 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:47 --> Input Class Initialized
INFO - 2023-11-05 08:39:47 --> Language Class Initialized
ERROR - 2023-11-05 08:39:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:47 --> Config Class Initialized
INFO - 2023-11-05 08:39:47 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:47 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:47 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:47 --> URI Class Initialized
INFO - 2023-11-05 08:39:47 --> Router Class Initialized
INFO - 2023-11-05 08:39:47 --> Output Class Initialized
INFO - 2023-11-05 08:39:47 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:47 --> Input Class Initialized
INFO - 2023-11-05 08:39:47 --> Language Class Initialized
ERROR - 2023-11-05 08:39:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:47 --> Input Class Initialized
INFO - 2023-11-05 08:39:48 --> Config Class Initialized
INFO - 2023-11-05 08:39:48 --> Config Class Initialized
INFO - 2023-11-05 08:39:48 --> Hooks Class Initialized
INFO - 2023-11-05 08:39:48 --> Language Class Initialized
INFO - 2023-11-05 08:39:48 --> Config Class Initialized
INFO - 2023-11-05 08:39:48 --> Config Class Initialized
INFO - 2023-11-05 08:39:48 --> Hooks Class Initialized
ERROR - 2023-11-05 08:39:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:48 --> Utf8 Class Initialized
DEBUG - 2023-11-05 08:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:39:48 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:48 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:48 --> URI Class Initialized
INFO - 2023-11-05 08:39:48 --> Utf8 Class Initialized
INFO - 2023-11-05 08:39:48 --> URI Class Initialized
INFO - 2023-11-05 08:39:48 --> Router Class Initialized
INFO - 2023-11-05 08:39:48 --> Output Class Initialized
INFO - 2023-11-05 08:39:48 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:48 --> Input Class Initialized
INFO - 2023-11-05 08:39:48 --> Language Class Initialized
ERROR - 2023-11-05 08:39:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:48 --> Router Class Initialized
INFO - 2023-11-05 08:39:48 --> URI Class Initialized
INFO - 2023-11-05 08:39:48 --> URI Class Initialized
INFO - 2023-11-05 08:39:48 --> Output Class Initialized
INFO - 2023-11-05 08:39:48 --> Router Class Initialized
INFO - 2023-11-05 08:39:48 --> Router Class Initialized
INFO - 2023-11-05 08:39:48 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:48 --> Input Class Initialized
INFO - 2023-11-05 08:39:48 --> Language Class Initialized
ERROR - 2023-11-05 08:39:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:39:48 --> Output Class Initialized
INFO - 2023-11-05 08:39:48 --> Output Class Initialized
INFO - 2023-11-05 08:39:48 --> Security Class Initialized
INFO - 2023-11-05 08:39:48 --> Security Class Initialized
DEBUG - 2023-11-05 08:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-05 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:39:48 --> Input Class Initialized
INFO - 2023-11-05 08:39:48 --> Input Class Initialized
INFO - 2023-11-05 08:39:48 --> Language Class Initialized
INFO - 2023-11-05 08:39:48 --> Language Class Initialized
ERROR - 2023-11-05 08:39:48 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-05 08:39:48 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:40:09 --> Config Class Initialized
INFO - 2023-11-05 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:40:09 --> Utf8 Class Initialized
INFO - 2023-11-05 08:40:09 --> URI Class Initialized
INFO - 2023-11-05 08:40:09 --> Router Class Initialized
INFO - 2023-11-05 08:40:09 --> Output Class Initialized
INFO - 2023-11-05 08:40:09 --> Security Class Initialized
DEBUG - 2023-11-05 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:40:09 --> Input Class Initialized
INFO - 2023-11-05 08:40:09 --> Language Class Initialized
INFO - 2023-11-05 08:40:09 --> Loader Class Initialized
INFO - 2023-11-05 08:40:09 --> Helper loaded: url_helper
INFO - 2023-11-05 08:40:09 --> Helper loaded: file_helper
INFO - 2023-11-05 08:40:09 --> Database Driver Class Initialized
INFO - 2023-11-05 08:40:09 --> Email Class Initialized
DEBUG - 2023-11-05 08:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:40:09 --> Controller Class Initialized
INFO - 2023-11-05 08:40:09 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:40:09 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:40:09 --> Model "Home_model" initialized
INFO - 2023-11-05 08:40:09 --> Helper loaded: download_helper
INFO - 2023-11-05 08:40:09 --> Helper loaded: form_helper
INFO - 2023-11-05 08:40:09 --> Form Validation Class Initialized
INFO - 2023-11-05 08:42:50 --> Config Class Initialized
INFO - 2023-11-05 08:42:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:42:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:42:50 --> Utf8 Class Initialized
INFO - 2023-11-05 08:42:50 --> URI Class Initialized
INFO - 2023-11-05 08:42:50 --> Router Class Initialized
INFO - 2023-11-05 08:42:50 --> Output Class Initialized
INFO - 2023-11-05 08:42:50 --> Security Class Initialized
DEBUG - 2023-11-05 08:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:42:50 --> Input Class Initialized
INFO - 2023-11-05 08:42:50 --> Language Class Initialized
INFO - 2023-11-05 08:42:50 --> Loader Class Initialized
INFO - 2023-11-05 08:42:50 --> Helper loaded: url_helper
INFO - 2023-11-05 08:42:50 --> Helper loaded: file_helper
INFO - 2023-11-05 08:42:50 --> Database Driver Class Initialized
INFO - 2023-11-05 08:42:50 --> Email Class Initialized
DEBUG - 2023-11-05 08:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:42:50 --> Controller Class Initialized
INFO - 2023-11-05 08:42:50 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:42:50 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:42:50 --> Model "Home_model" initialized
INFO - 2023-11-05 08:42:50 --> Helper loaded: download_helper
INFO - 2023-11-05 08:42:50 --> Helper loaded: form_helper
INFO - 2023-11-05 08:42:50 --> Form Validation Class Initialized
ERROR - 2023-11-05 13:12:50 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\dw\application\controllers\HomeController.php 495
INFO - 2023-11-05 08:46:50 --> Config Class Initialized
INFO - 2023-11-05 08:46:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:46:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:46:50 --> Utf8 Class Initialized
INFO - 2023-11-05 08:46:50 --> URI Class Initialized
INFO - 2023-11-05 08:46:50 --> Router Class Initialized
INFO - 2023-11-05 08:46:50 --> Output Class Initialized
INFO - 2023-11-05 08:46:50 --> Security Class Initialized
DEBUG - 2023-11-05 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:46:50 --> Input Class Initialized
INFO - 2023-11-05 08:46:50 --> Language Class Initialized
INFO - 2023-11-05 08:46:50 --> Loader Class Initialized
INFO - 2023-11-05 08:46:50 --> Helper loaded: url_helper
INFO - 2023-11-05 08:46:50 --> Helper loaded: file_helper
INFO - 2023-11-05 08:46:50 --> Database Driver Class Initialized
INFO - 2023-11-05 08:46:50 --> Email Class Initialized
DEBUG - 2023-11-05 08:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:46:50 --> Controller Class Initialized
INFO - 2023-11-05 08:46:50 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:46:50 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:46:50 --> Model "Home_model" initialized
INFO - 2023-11-05 08:46:50 --> Helper loaded: download_helper
INFO - 2023-11-05 08:46:50 --> Helper loaded: form_helper
INFO - 2023-11-05 08:46:50 --> Form Validation Class Initialized
INFO - 2023-11-05 13:16:50 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:16:50 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:16:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:16:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:16:50 --> Final output sent to browser
DEBUG - 2023-11-05 13:16:51 --> Total execution time: 0.2650
INFO - 2023-11-05 08:46:53 --> Config Class Initialized
INFO - 2023-11-05 08:46:53 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:46:53 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:46:53 --> Utf8 Class Initialized
INFO - 2023-11-05 08:46:53 --> URI Class Initialized
INFO - 2023-11-05 08:46:53 --> Router Class Initialized
INFO - 2023-11-05 08:46:53 --> Output Class Initialized
INFO - 2023-11-05 08:46:53 --> Security Class Initialized
DEBUG - 2023-11-05 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:46:53 --> Input Class Initialized
INFO - 2023-11-05 08:46:53 --> Language Class Initialized
ERROR - 2023-11-05 08:46:53 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:46:53 --> Config Class Initialized
INFO - 2023-11-05 08:46:53 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:46:53 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:46:53 --> Utf8 Class Initialized
INFO - 2023-11-05 08:46:53 --> URI Class Initialized
INFO - 2023-11-05 08:46:53 --> Router Class Initialized
INFO - 2023-11-05 08:46:53 --> Output Class Initialized
INFO - 2023-11-05 08:46:53 --> Security Class Initialized
DEBUG - 2023-11-05 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:46:53 --> Input Class Initialized
INFO - 2023-11-05 08:46:53 --> Language Class Initialized
ERROR - 2023-11-05 08:46:53 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:46:54 --> Config Class Initialized
INFO - 2023-11-05 08:46:54 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:46:54 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:46:54 --> Utf8 Class Initialized
INFO - 2023-11-05 08:46:54 --> URI Class Initialized
INFO - 2023-11-05 08:46:54 --> Router Class Initialized
INFO - 2023-11-05 08:46:54 --> Output Class Initialized
INFO - 2023-11-05 08:46:54 --> Security Class Initialized
DEBUG - 2023-11-05 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:46:54 --> Input Class Initialized
INFO - 2023-11-05 08:46:54 --> Language Class Initialized
ERROR - 2023-11-05 08:46:54 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:46:54 --> Config Class Initialized
INFO - 2023-11-05 08:46:55 --> Hooks Class Initialized
INFO - 2023-11-05 08:47:19 --> Config Class Initialized
INFO - 2023-11-05 08:47:19 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:47:19 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:47:19 --> Utf8 Class Initialized
INFO - 2023-11-05 08:47:19 --> URI Class Initialized
INFO - 2023-11-05 08:47:19 --> Router Class Initialized
INFO - 2023-11-05 08:47:19 --> Output Class Initialized
INFO - 2023-11-05 08:47:19 --> Security Class Initialized
DEBUG - 2023-11-05 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:47:19 --> Input Class Initialized
INFO - 2023-11-05 08:47:19 --> Language Class Initialized
INFO - 2023-11-05 08:47:19 --> Loader Class Initialized
INFO - 2023-11-05 08:47:19 --> Helper loaded: url_helper
INFO - 2023-11-05 08:47:19 --> Helper loaded: file_helper
INFO - 2023-11-05 08:47:19 --> Database Driver Class Initialized
INFO - 2023-11-05 08:47:19 --> Email Class Initialized
DEBUG - 2023-11-05 08:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:47:19 --> Controller Class Initialized
INFO - 2023-11-05 08:47:19 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:47:19 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:47:19 --> Model "Home_model" initialized
INFO - 2023-11-05 08:47:19 --> Helper loaded: download_helper
INFO - 2023-11-05 08:47:19 --> Helper loaded: form_helper
INFO - 2023-11-05 08:47:19 --> Form Validation Class Initialized
ERROR - 2023-11-05 13:17:19 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\dw\application\controllers\HomeController.php 495
INFO - 2023-11-05 08:48:20 --> Config Class Initialized
INFO - 2023-11-05 08:48:20 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:20 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:20 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:20 --> URI Class Initialized
INFO - 2023-11-05 08:48:20 --> Router Class Initialized
INFO - 2023-11-05 08:48:20 --> Output Class Initialized
INFO - 2023-11-05 08:48:20 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:20 --> Input Class Initialized
INFO - 2023-11-05 08:48:20 --> Language Class Initialized
INFO - 2023-11-05 08:48:20 --> Loader Class Initialized
INFO - 2023-11-05 08:48:20 --> Helper loaded: url_helper
INFO - 2023-11-05 08:48:20 --> Helper loaded: file_helper
INFO - 2023-11-05 08:48:20 --> Database Driver Class Initialized
INFO - 2023-11-05 08:48:20 --> Email Class Initialized
DEBUG - 2023-11-05 08:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:48:20 --> Controller Class Initialized
INFO - 2023-11-05 08:48:20 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:48:20 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:48:20 --> Model "Home_model" initialized
INFO - 2023-11-05 08:48:21 --> Helper loaded: download_helper
INFO - 2023-11-05 08:48:21 --> Helper loaded: form_helper
INFO - 2023-11-05 08:48:21 --> Form Validation Class Initialized
INFO - 2023-11-05 13:18:21 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:18:21 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:18:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:18:21 --> Final output sent to browser
DEBUG - 2023-11-05 13:18:22 --> Total execution time: 0.2004
INFO - 2023-11-05 08:48:23 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:24 --> Config Class Initialized
INFO - 2023-11-05 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:24 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:24 --> URI Class Initialized
INFO - 2023-11-05 08:48:24 --> Router Class Initialized
INFO - 2023-11-05 08:48:24 --> Output Class Initialized
INFO - 2023-11-05 08:48:24 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:24 --> Input Class Initialized
INFO - 2023-11-05 08:48:24 --> Language Class Initialized
ERROR - 2023-11-05 08:48:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:30 --> Config Class Initialized
INFO - 2023-11-05 08:48:30 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:30 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:30 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:30 --> URI Class Initialized
INFO - 2023-11-05 08:48:30 --> Router Class Initialized
INFO - 2023-11-05 08:48:30 --> Output Class Initialized
INFO - 2023-11-05 08:48:30 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:30 --> Input Class Initialized
INFO - 2023-11-05 08:48:30 --> Language Class Initialized
INFO - 2023-11-05 08:48:30 --> Loader Class Initialized
INFO - 2023-11-05 08:48:30 --> Helper loaded: url_helper
INFO - 2023-11-05 08:48:30 --> Helper loaded: file_helper
INFO - 2023-11-05 08:48:30 --> Database Driver Class Initialized
INFO - 2023-11-05 08:48:30 --> Email Class Initialized
DEBUG - 2023-11-05 08:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:48:30 --> Controller Class Initialized
INFO - 2023-11-05 08:48:30 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:48:30 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:48:30 --> Model "Home_model" initialized
INFO - 2023-11-05 08:48:30 --> Helper loaded: download_helper
INFO - 2023-11-05 08:48:30 --> Helper loaded: form_helper
INFO - 2023-11-05 08:48:30 --> Form Validation Class Initialized
INFO - 2023-11-05 13:18:30 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:18:30 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:18:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:18:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:18:31 --> Final output sent to browser
DEBUG - 2023-11-05 13:18:31 --> Total execution time: 0.1466
INFO - 2023-11-05 08:48:32 --> Config Class Initialized
INFO - 2023-11-05 08:48:32 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:32 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:32 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:32 --> URI Class Initialized
INFO - 2023-11-05 08:48:32 --> Router Class Initialized
INFO - 2023-11-05 08:48:32 --> Output Class Initialized
INFO - 2023-11-05 08:48:32 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:32 --> Input Class Initialized
INFO - 2023-11-05 08:48:32 --> Language Class Initialized
ERROR - 2023-11-05 08:48:32 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:48:47 --> Config Class Initialized
INFO - 2023-11-05 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:48:47 --> Utf8 Class Initialized
INFO - 2023-11-05 08:48:47 --> URI Class Initialized
INFO - 2023-11-05 08:48:47 --> Router Class Initialized
INFO - 2023-11-05 08:48:47 --> Output Class Initialized
INFO - 2023-11-05 08:48:47 --> Security Class Initialized
DEBUG - 2023-11-05 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:48:47 --> Input Class Initialized
INFO - 2023-11-05 08:48:47 --> Language Class Initialized
INFO - 2023-11-05 08:48:47 --> Loader Class Initialized
INFO - 2023-11-05 08:48:47 --> Helper loaded: url_helper
INFO - 2023-11-05 08:48:47 --> Helper loaded: file_helper
INFO - 2023-11-05 08:48:47 --> Database Driver Class Initialized
INFO - 2023-11-05 08:48:47 --> Email Class Initialized
DEBUG - 2023-11-05 08:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:48:47 --> Controller Class Initialized
INFO - 2023-11-05 08:48:47 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:48:47 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:48:47 --> Model "Home_model" initialized
INFO - 2023-11-05 08:48:47 --> Helper loaded: download_helper
INFO - 2023-11-05 08:48:47 --> Helper loaded: form_helper
INFO - 2023-11-05 08:48:47 --> Form Validation Class Initialized
ERROR - 2023-11-05 13:18:47 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\dw\application\controllers\HomeController.php 495
INFO - 2023-11-05 08:50:26 --> Config Class Initialized
INFO - 2023-11-05 08:50:26 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:50:26 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:50:26 --> Utf8 Class Initialized
INFO - 2023-11-05 08:50:26 --> URI Class Initialized
INFO - 2023-11-05 08:50:26 --> Router Class Initialized
INFO - 2023-11-05 08:50:26 --> Output Class Initialized
INFO - 2023-11-05 08:50:26 --> Security Class Initialized
DEBUG - 2023-11-05 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:50:26 --> Input Class Initialized
INFO - 2023-11-05 08:50:26 --> Language Class Initialized
INFO - 2023-11-05 08:50:26 --> Loader Class Initialized
INFO - 2023-11-05 08:50:26 --> Helper loaded: url_helper
INFO - 2023-11-05 08:50:26 --> Helper loaded: file_helper
INFO - 2023-11-05 08:50:26 --> Database Driver Class Initialized
INFO - 2023-11-05 08:50:26 --> Email Class Initialized
DEBUG - 2023-11-05 08:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:50:26 --> Controller Class Initialized
INFO - 2023-11-05 08:50:26 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:50:26 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:50:26 --> Model "Home_model" initialized
INFO - 2023-11-05 08:50:26 --> Helper loaded: download_helper
INFO - 2023-11-05 08:50:26 --> Helper loaded: form_helper
INFO - 2023-11-05 08:50:26 --> Form Validation Class Initialized
INFO - 2023-11-05 13:20:26 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:20:26 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:20:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:20:27 --> Final output sent to browser
DEBUG - 2023-11-05 13:20:27 --> Total execution time: 0.2104
INFO - 2023-11-05 08:50:28 --> Config Class Initialized
INFO - 2023-11-05 08:50:28 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:50:28 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:50:28 --> Utf8 Class Initialized
INFO - 2023-11-05 08:50:28 --> URI Class Initialized
INFO - 2023-11-05 08:50:28 --> Router Class Initialized
INFO - 2023-11-05 08:50:56 --> Config Class Initialized
INFO - 2023-11-05 08:50:56 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:50:56 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:50:56 --> Utf8 Class Initialized
INFO - 2023-11-05 08:50:56 --> URI Class Initialized
INFO - 2023-11-05 08:50:56 --> Router Class Initialized
INFO - 2023-11-05 08:50:56 --> Output Class Initialized
INFO - 2023-11-05 08:50:56 --> Security Class Initialized
DEBUG - 2023-11-05 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:50:56 --> Input Class Initialized
INFO - 2023-11-05 08:50:56 --> Language Class Initialized
INFO - 2023-11-05 08:50:56 --> Loader Class Initialized
INFO - 2023-11-05 08:50:56 --> Helper loaded: url_helper
INFO - 2023-11-05 08:50:56 --> Helper loaded: file_helper
INFO - 2023-11-05 08:50:56 --> Database Driver Class Initialized
INFO - 2023-11-05 08:50:56 --> Email Class Initialized
DEBUG - 2023-11-05 08:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:50:56 --> Controller Class Initialized
INFO - 2023-11-05 08:50:56 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:50:56 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:50:56 --> Model "Home_model" initialized
INFO - 2023-11-05 08:50:56 --> Helper loaded: download_helper
INFO - 2023-11-05 08:50:56 --> Helper loaded: form_helper
INFO - 2023-11-05 08:50:56 --> Form Validation Class Initialized
ERROR - 2023-11-05 13:20:56 --> Severity: Warning --> move_uploaded_file(./assets/images/resume/1699170656SAMPLE.jpg): Failed to open stream: No such file or directory C:\xampp\htdocs\dw\application\controllers\HomeController.php 487
ERROR - 2023-11-05 13:20:56 --> Severity: Warning --> move_uploaded_file(): Unable to move &quot;C:\xampp\tmp\phpF258.tmp&quot; to &quot;./assets/images/resume/1699170656SAMPLE.jpg&quot; C:\xampp\htdocs\dw\application\controllers\HomeController.php 487
INFO - 2023-11-05 08:51:44 --> Config Class Initialized
INFO - 2023-11-05 08:51:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:51:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:51:44 --> Utf8 Class Initialized
INFO - 2023-11-05 08:51:44 --> URI Class Initialized
INFO - 2023-11-05 08:51:44 --> Router Class Initialized
INFO - 2023-11-05 08:51:44 --> Output Class Initialized
INFO - 2023-11-05 08:51:44 --> Security Class Initialized
DEBUG - 2023-11-05 08:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:51:44 --> Input Class Initialized
INFO - 2023-11-05 08:51:44 --> Language Class Initialized
INFO - 2023-11-05 08:51:44 --> Loader Class Initialized
INFO - 2023-11-05 08:51:44 --> Helper loaded: url_helper
INFO - 2023-11-05 08:51:44 --> Helper loaded: file_helper
INFO - 2023-11-05 08:51:44 --> Database Driver Class Initialized
INFO - 2023-11-05 08:51:44 --> Email Class Initialized
DEBUG - 2023-11-05 08:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:51:44 --> Controller Class Initialized
INFO - 2023-11-05 08:51:44 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:51:44 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:51:44 --> Model "Home_model" initialized
INFO - 2023-11-05 08:51:44 --> Helper loaded: download_helper
INFO - 2023-11-05 08:51:44 --> Helper loaded: form_helper
INFO - 2023-11-05 08:51:44 --> Form Validation Class Initialized
INFO - 2023-11-05 13:21:45 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:21:45 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:21:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 13:21:45 --> Final output sent to browser
DEBUG - 2023-11-05 13:21:45 --> Total execution time: 0.1297
INFO - 2023-11-05 08:51:45 --> Config Class Initialized
INFO - 2023-11-05 08:51:45 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:51:45 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:51:45 --> Utf8 Class Initialized
INFO - 2023-11-05 08:51:45 --> URI Class Initialized
INFO - 2023-11-05 08:51:45 --> Router Class Initialized
INFO - 2023-11-05 08:51:45 --> Output Class Initialized
INFO - 2023-11-05 08:51:45 --> Security Class Initialized
DEBUG - 2023-11-05 08:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:51:46 --> Input Class Initialized
INFO - 2023-11-05 08:51:46 --> Language Class Initialized
ERROR - 2023-11-05 08:51:46 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:51:47 --> Config Class Initialized
INFO - 2023-11-05 08:51:47 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:51:47 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:51:47 --> Utf8 Class Initialized
INFO - 2023-11-05 08:51:47 --> URI Class Initialized
INFO - 2023-11-05 08:51:47 --> Router Class Initialized
INFO - 2023-11-05 08:51:47 --> Output Class Initialized
INFO - 2023-11-05 08:51:47 --> Security Class Initialized
DEBUG - 2023-11-05 08:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:51:47 --> Input Class Initialized
INFO - 2023-11-05 08:51:47 --> Language Class Initialized
ERROR - 2023-11-05 08:51:47 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 08:52:00 --> Config Class Initialized
INFO - 2023-11-05 08:52:00 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:52:00 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:52:00 --> Utf8 Class Initialized
INFO - 2023-11-05 08:52:00 --> URI Class Initialized
INFO - 2023-11-05 08:52:00 --> Router Class Initialized
INFO - 2023-11-05 08:52:00 --> Output Class Initialized
INFO - 2023-11-05 08:52:00 --> Security Class Initialized
DEBUG - 2023-11-05 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:52:00 --> Input Class Initialized
INFO - 2023-11-05 08:52:00 --> Language Class Initialized
INFO - 2023-11-05 08:52:00 --> Loader Class Initialized
INFO - 2023-11-05 08:52:00 --> Helper loaded: url_helper
INFO - 2023-11-05 08:52:00 --> Helper loaded: file_helper
INFO - 2023-11-05 08:52:00 --> Database Driver Class Initialized
INFO - 2023-11-05 08:52:00 --> Email Class Initialized
DEBUG - 2023-11-05 08:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:52:00 --> Controller Class Initialized
INFO - 2023-11-05 08:52:00 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:52:00 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:52:00 --> Model "Home_model" initialized
INFO - 2023-11-05 08:52:00 --> Helper loaded: download_helper
INFO - 2023-11-05 08:52:00 --> Helper loaded: form_helper
INFO - 2023-11-05 08:52:00 --> Form Validation Class Initialized
INFO - 2023-11-05 08:59:40 --> Config Class Initialized
INFO - 2023-11-05 08:59:40 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:59:40 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:59:40 --> Utf8 Class Initialized
INFO - 2023-11-05 08:59:40 --> URI Class Initialized
INFO - 2023-11-05 08:59:40 --> Router Class Initialized
INFO - 2023-11-05 08:59:40 --> Output Class Initialized
INFO - 2023-11-05 08:59:40 --> Security Class Initialized
DEBUG - 2023-11-05 08:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:59:40 --> Input Class Initialized
INFO - 2023-11-05 08:59:40 --> Language Class Initialized
INFO - 2023-11-05 08:59:40 --> Loader Class Initialized
INFO - 2023-11-05 08:59:40 --> Helper loaded: url_helper
INFO - 2023-11-05 08:59:40 --> Helper loaded: file_helper
INFO - 2023-11-05 08:59:40 --> Database Driver Class Initialized
INFO - 2023-11-05 08:59:40 --> Email Class Initialized
DEBUG - 2023-11-05 08:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:59:40 --> Controller Class Initialized
INFO - 2023-11-05 08:59:40 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:59:40 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:59:40 --> Model "Home_model" initialized
INFO - 2023-11-05 08:59:40 --> Helper loaded: download_helper
INFO - 2023-11-05 08:59:40 --> Helper loaded: form_helper
INFO - 2023-11-05 08:59:40 --> Form Validation Class Initialized
INFO - 2023-11-05 13:29:40 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:29:40 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:29:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:29:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-11-05 13:29:40 --> Final output sent to browser
DEBUG - 2023-11-05 13:29:40 --> Total execution time: 0.1607
INFO - 2023-11-05 08:59:42 --> Config Class Initialized
INFO - 2023-11-05 08:59:42 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:59:42 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:59:42 --> Utf8 Class Initialized
INFO - 2023-11-05 08:59:42 --> URI Class Initialized
INFO - 2023-11-05 08:59:42 --> Router Class Initialized
INFO - 2023-11-05 08:59:42 --> Output Class Initialized
INFO - 2023-11-05 08:59:42 --> Security Class Initialized
DEBUG - 2023-11-05 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:59:42 --> Input Class Initialized
INFO - 2023-11-05 08:59:42 --> Language Class Initialized
ERROR - 2023-11-05 08:59:42 --> 404 Page Not Found: Assets/images
INFO - 2023-11-05 08:59:46 --> Config Class Initialized
INFO - 2023-11-05 08:59:46 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:59:46 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:59:46 --> Utf8 Class Initialized
INFO - 2023-11-05 08:59:46 --> URI Class Initialized
INFO - 2023-11-05 08:59:46 --> Router Class Initialized
INFO - 2023-11-05 08:59:46 --> Output Class Initialized
INFO - 2023-11-05 08:59:46 --> Security Class Initialized
DEBUG - 2023-11-05 08:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:59:46 --> Input Class Initialized
INFO - 2023-11-05 08:59:46 --> Language Class Initialized
INFO - 2023-11-05 08:59:46 --> Loader Class Initialized
INFO - 2023-11-05 08:59:46 --> Helper loaded: url_helper
INFO - 2023-11-05 08:59:46 --> Helper loaded: file_helper
INFO - 2023-11-05 08:59:46 --> Database Driver Class Initialized
INFO - 2023-11-05 08:59:46 --> Email Class Initialized
DEBUG - 2023-11-05 08:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:59:46 --> Controller Class Initialized
INFO - 2023-11-05 08:59:46 --> Model "Contact_model" initialized
INFO - 2023-11-05 08:59:46 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 08:59:46 --> Model "Home_model" initialized
INFO - 2023-11-05 08:59:46 --> Helper loaded: download_helper
INFO - 2023-11-05 08:59:46 --> Helper loaded: form_helper
INFO - 2023-11-05 08:59:46 --> Form Validation Class Initialized
INFO - 2023-11-05 13:29:46 --> Helper loaded: custom_helper
INFO - 2023-11-05 13:29:46 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 13:29:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 13:29:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-11-05 13:29:46 --> Final output sent to browser
DEBUG - 2023-11-05 13:29:46 --> Total execution time: 0.0688
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Output Class Initialized
INFO - 2023-11-05 09:00:23 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:23 --> Input Class Initialized
INFO - 2023-11-05 09:00:23 --> Language Class Initialized
ERROR - 2023-11-05 09:00:23 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Output Class Initialized
INFO - 2023-11-05 09:00:23 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:23 --> Input Class Initialized
INFO - 2023-11-05 09:00:23 --> Language Class Initialized
ERROR - 2023-11-05 09:00:23 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:23 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:23 --> URI Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Output Class Initialized
INFO - 2023-11-05 09:00:23 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:23 --> Input Class Initialized
INFO - 2023-11-05 09:00:23 --> Language Class Initialized
ERROR - 2023-11-05 09:00:23 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:23 --> Output Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Config Class Initialized
INFO - 2023-11-05 09:00:23 --> Hooks Class Initialized
INFO - 2023-11-05 09:00:23 --> Router Class Initialized
INFO - 2023-11-05 09:00:23 --> Output Class Initialized
INFO - 2023-11-05 09:00:23 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:24 --> Output Class Initialized
INFO - 2023-11-05 09:00:24 --> Utf8 Class Initialized
DEBUG - 2023-11-05 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:24 --> Security Class Initialized
INFO - 2023-11-05 09:00:24 --> URI Class Initialized
INFO - 2023-11-05 09:00:24 --> Security Class Initialized
INFO - 2023-11-05 09:00:24 --> Input Class Initialized
DEBUG - 2023-11-05 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:24 --> Language Class Initialized
INFO - 2023-11-05 09:00:24 --> Router Class Initialized
INFO - 2023-11-05 09:00:24 --> Input Class Initialized
DEBUG - 2023-11-05 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:24 --> Language Class Initialized
ERROR - 2023-11-05 09:00:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:24 --> Output Class Initialized
INFO - 2023-11-05 09:00:24 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:24 --> Input Class Initialized
INFO - 2023-11-05 09:00:24 --> Language Class Initialized
ERROR - 2023-11-05 09:00:24 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-05 09:00:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:24 --> Input Class Initialized
INFO - 2023-11-05 09:00:24 --> Language Class Initialized
ERROR - 2023-11-05 09:00:24 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Config Class Initialized
INFO - 2023-11-05 09:00:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 09:00:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
INFO - 2023-11-05 09:00:50 --> Utf8 Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
INFO - 2023-11-05 09:00:50 --> URI Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Router Class Initialized
INFO - 2023-11-05 09:00:50 --> Output Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
INFO - 2023-11-05 09:00:50 --> Security Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
INFO - 2023-11-05 09:00:50 --> Input Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:00:50 --> Language Class Initialized
ERROR - 2023-11-05 09:00:50 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 09:01:08 --> Config Class Initialized
INFO - 2023-11-05 09:01:08 --> Hooks Class Initialized
DEBUG - 2023-11-05 09:01:08 --> UTF-8 Support Enabled
INFO - 2023-11-05 09:01:08 --> Utf8 Class Initialized
INFO - 2023-11-05 09:01:08 --> URI Class Initialized
INFO - 2023-11-05 09:01:08 --> Router Class Initialized
INFO - 2023-11-05 09:01:08 --> Output Class Initialized
INFO - 2023-11-05 09:01:08 --> Security Class Initialized
DEBUG - 2023-11-05 09:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 09:01:08 --> Input Class Initialized
INFO - 2023-11-05 09:01:08 --> Language Class Initialized
INFO - 2023-11-05 09:01:08 --> Loader Class Initialized
INFO - 2023-11-05 09:01:08 --> Helper loaded: url_helper
INFO - 2023-11-05 09:01:08 --> Helper loaded: file_helper
INFO - 2023-11-05 09:01:08 --> Database Driver Class Initialized
INFO - 2023-11-05 09:01:08 --> Email Class Initialized
DEBUG - 2023-11-05 09:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 09:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 09:01:08 --> Controller Class Initialized
INFO - 2023-11-05 09:01:08 --> Model "Contact_model" initialized
INFO - 2023-11-05 09:01:08 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 09:01:08 --> Model "Home_model" initialized
INFO - 2023-11-05 09:01:08 --> Helper loaded: download_helper
INFO - 2023-11-05 09:01:08 --> Helper loaded: form_helper
INFO - 2023-11-05 09:01:08 --> Form Validation Class Initialized
DEBUG - 2023-11-05 13:31:08 --> Phpmailer class already loaded. Second attempt ignored.
INFO - 2023-11-05 11:01:18 --> Config Class Initialized
INFO - 2023-11-05 11:01:18 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:18 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:18 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:18 --> URI Class Initialized
INFO - 2023-11-05 11:01:18 --> Router Class Initialized
INFO - 2023-11-05 11:01:18 --> Output Class Initialized
INFO - 2023-11-05 11:01:18 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:18 --> Input Class Initialized
INFO - 2023-11-05 11:01:18 --> Language Class Initialized
INFO - 2023-11-05 11:01:18 --> Loader Class Initialized
INFO - 2023-11-05 11:01:18 --> Helper loaded: url_helper
INFO - 2023-11-05 11:01:18 --> Helper loaded: file_helper
INFO - 2023-11-05 11:01:18 --> Database Driver Class Initialized
INFO - 2023-11-05 11:01:18 --> Email Class Initialized
DEBUG - 2023-11-05 11:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:01:18 --> Controller Class Initialized
INFO - 2023-11-05 11:01:18 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:01:18 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:01:18 --> Model "Home_model" initialized
INFO - 2023-11-05 11:01:18 --> Helper loaded: download_helper
INFO - 2023-11-05 11:01:18 --> Helper loaded: form_helper
INFO - 2023-11-05 11:01:18 --> Form Validation Class Initialized
INFO - 2023-11-05 15:31:18 --> Helper loaded: custom_helper
INFO - 2023-11-05 15:31:18 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 15:31:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 15:31:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 15:31:18 --> Final output sent to browser
DEBUG - 2023-11-05 15:31:19 --> Total execution time: 0.1473
INFO - 2023-11-05 11:01:19 --> Config Class Initialized
INFO - 2023-11-05 11:01:19 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:19 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:19 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:19 --> URI Class Initialized
INFO - 2023-11-05 11:01:19 --> Router Class Initialized
INFO - 2023-11-05 11:01:19 --> Output Class Initialized
INFO - 2023-11-05 11:01:19 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:20 --> Input Class Initialized
INFO - 2023-11-05 11:01:20 --> Language Class Initialized
ERROR - 2023-11-05 11:01:20 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:21 --> Config Class Initialized
INFO - 2023-11-05 11:01:21 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:21 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:21 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:21 --> URI Class Initialized
INFO - 2023-11-05 11:01:21 --> Router Class Initialized
INFO - 2023-11-05 11:01:21 --> Output Class Initialized
INFO - 2023-11-05 11:01:21 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:21 --> Input Class Initialized
INFO - 2023-11-05 11:01:21 --> Language Class Initialized
ERROR - 2023-11-05 11:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:21 --> Config Class Initialized
INFO - 2023-11-05 11:01:21 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:21 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:21 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:21 --> URI Class Initialized
INFO - 2023-11-05 11:01:21 --> Router Class Initialized
INFO - 2023-11-05 11:01:21 --> Output Class Initialized
INFO - 2023-11-05 11:01:21 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:21 --> Input Class Initialized
INFO - 2023-11-05 11:01:21 --> Language Class Initialized
ERROR - 2023-11-05 11:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:22 --> Config Class Initialized
INFO - 2023-11-05 11:01:22 --> Config Class Initialized
INFO - 2023-11-05 11:01:22 --> Config Class Initialized
INFO - 2023-11-05 11:01:22 --> Config Class Initialized
INFO - 2023-11-05 11:01:22 --> Hooks Class Initialized
INFO - 2023-11-05 11:01:22 --> Hooks Class Initialized
INFO - 2023-11-05 11:01:22 --> Hooks Class Initialized
INFO - 2023-11-05 11:01:22 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 11:01:22 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:22 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:22 --> Utf8 Class Initialized
DEBUG - 2023-11-05 11:01:22 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:22 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:22 --> URI Class Initialized
INFO - 2023-11-05 11:01:22 --> Router Class Initialized
INFO - 2023-11-05 11:01:22 --> Output Class Initialized
INFO - 2023-11-05 11:01:22 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:22 --> Input Class Initialized
INFO - 2023-11-05 11:01:22 --> Language Class Initialized
ERROR - 2023-11-05 11:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:22 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:22 --> URI Class Initialized
INFO - 2023-11-05 11:01:22 --> URI Class Initialized
INFO - 2023-11-05 11:01:22 --> URI Class Initialized
INFO - 2023-11-05 11:01:22 --> Router Class Initialized
INFO - 2023-11-05 11:01:22 --> Router Class Initialized
INFO - 2023-11-05 11:01:22 --> Router Class Initialized
INFO - 2023-11-05 11:01:22 --> Output Class Initialized
INFO - 2023-11-05 11:01:22 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:22 --> Input Class Initialized
INFO - 2023-11-05 11:01:22 --> Language Class Initialized
ERROR - 2023-11-05 11:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:22 --> Output Class Initialized
INFO - 2023-11-05 11:01:22 --> Output Class Initialized
INFO - 2023-11-05 11:01:22 --> Security Class Initialized
INFO - 2023-11-05 11:01:22 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-05 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:22 --> Input Class Initialized
INFO - 2023-11-05 11:01:22 --> Input Class Initialized
INFO - 2023-11-05 11:01:22 --> Language Class Initialized
INFO - 2023-11-05 11:01:22 --> Language Class Initialized
ERROR - 2023-11-05 11:01:22 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-05 11:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:01:42 --> Config Class Initialized
INFO - 2023-11-05 11:01:42 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:01:42 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:01:42 --> Utf8 Class Initialized
INFO - 2023-11-05 11:01:42 --> URI Class Initialized
INFO - 2023-11-05 11:01:42 --> Router Class Initialized
INFO - 2023-11-05 11:01:42 --> Output Class Initialized
INFO - 2023-11-05 11:01:42 --> Security Class Initialized
DEBUG - 2023-11-05 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:01:42 --> Input Class Initialized
INFO - 2023-11-05 11:01:42 --> Language Class Initialized
INFO - 2023-11-05 11:01:42 --> Loader Class Initialized
INFO - 2023-11-05 11:01:42 --> Helper loaded: url_helper
INFO - 2023-11-05 11:01:42 --> Helper loaded: file_helper
INFO - 2023-11-05 11:01:42 --> Database Driver Class Initialized
INFO - 2023-11-05 11:01:42 --> Email Class Initialized
DEBUG - 2023-11-05 11:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:01:42 --> Controller Class Initialized
INFO - 2023-11-05 11:01:42 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:01:42 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:01:42 --> Model "Home_model" initialized
INFO - 2023-11-05 11:01:42 --> Helper loaded: download_helper
INFO - 2023-11-05 11:01:42 --> Helper loaded: form_helper
INFO - 2023-11-05 11:01:42 --> Form Validation Class Initialized
ERROR - 2023-11-05 15:31:42 --> Severity: error --> Exception: Call to undefined method Contact_model::getCareerById() C:\xampp\htdocs\dw\application\controllers\HomeController.php 508
INFO - 2023-11-05 11:02:48 --> Config Class Initialized
INFO - 2023-11-05 11:02:48 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:02:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:02:48 --> Utf8 Class Initialized
INFO - 2023-11-05 11:02:48 --> URI Class Initialized
INFO - 2023-11-05 11:02:48 --> Router Class Initialized
INFO - 2023-11-05 11:02:48 --> Output Class Initialized
INFO - 2023-11-05 11:02:48 --> Security Class Initialized
DEBUG - 2023-11-05 11:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:02:48 --> Input Class Initialized
INFO - 2023-11-05 11:02:48 --> Language Class Initialized
INFO - 2023-11-05 11:02:48 --> Loader Class Initialized
INFO - 2023-11-05 11:02:48 --> Helper loaded: url_helper
INFO - 2023-11-05 11:02:48 --> Helper loaded: file_helper
INFO - 2023-11-05 11:02:48 --> Database Driver Class Initialized
INFO - 2023-11-05 11:02:48 --> Email Class Initialized
DEBUG - 2023-11-05 11:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:02:48 --> Controller Class Initialized
INFO - 2023-11-05 11:02:48 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:02:48 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:02:48 --> Model "Home_model" initialized
INFO - 2023-11-05 11:02:48 --> Helper loaded: download_helper
INFO - 2023-11-05 11:02:48 --> Helper loaded: form_helper
INFO - 2023-11-05 11:02:48 --> Form Validation Class Initialized
ERROR - 2023-11-05 15:32:48 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `career_form`
INNER JOIN `careers_jobs` ON `careers_jobs`.`id` = `career_form`.`career_id`
WHERE `id` = 8
INFO - 2023-11-05 15:32:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-11-05 11:03:45 --> Config Class Initialized
INFO - 2023-11-05 11:03:45 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:03:45 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:03:45 --> Utf8 Class Initialized
INFO - 2023-11-05 11:03:45 --> URI Class Initialized
INFO - 2023-11-05 11:03:45 --> Router Class Initialized
INFO - 2023-11-05 11:03:45 --> Output Class Initialized
INFO - 2023-11-05 11:03:45 --> Security Class Initialized
DEBUG - 2023-11-05 11:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:03:45 --> Input Class Initialized
INFO - 2023-11-05 11:03:45 --> Language Class Initialized
INFO - 2023-11-05 11:03:45 --> Loader Class Initialized
INFO - 2023-11-05 11:03:45 --> Helper loaded: url_helper
INFO - 2023-11-05 11:03:45 --> Helper loaded: file_helper
INFO - 2023-11-05 11:03:45 --> Database Driver Class Initialized
INFO - 2023-11-05 11:03:45 --> Email Class Initialized
DEBUG - 2023-11-05 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:03:45 --> Controller Class Initialized
INFO - 2023-11-05 11:03:45 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:03:45 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:03:45 --> Model "Home_model" initialized
INFO - 2023-11-05 11:03:45 --> Helper loaded: download_helper
INFO - 2023-11-05 11:03:45 --> Helper loaded: form_helper
INFO - 2023-11-05 11:03:45 --> Form Validation Class Initialized
INFO - 2023-11-05 11:20:53 --> Config Class Initialized
INFO - 2023-11-05 11:20:53 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:20:53 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:54 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:54 --> URI Class Initialized
INFO - 2023-11-05 11:20:54 --> Router Class Initialized
INFO - 2023-11-05 11:20:54 --> Output Class Initialized
INFO - 2023-11-05 11:20:54 --> Security Class Initialized
DEBUG - 2023-11-05 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:54 --> Input Class Initialized
INFO - 2023-11-05 11:20:54 --> Language Class Initialized
INFO - 2023-11-05 11:20:54 --> Loader Class Initialized
INFO - 2023-11-05 11:20:54 --> Helper loaded: url_helper
INFO - 2023-11-05 11:20:54 --> Helper loaded: file_helper
INFO - 2023-11-05 11:20:54 --> Database Driver Class Initialized
INFO - 2023-11-05 11:20:54 --> Email Class Initialized
DEBUG - 2023-11-05 11:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:20:54 --> Controller Class Initialized
INFO - 2023-11-05 11:20:54 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:20:54 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:20:54 --> Model "Home_model" initialized
INFO - 2023-11-05 11:20:54 --> Helper loaded: download_helper
INFO - 2023-11-05 11:20:54 --> Helper loaded: form_helper
INFO - 2023-11-05 11:20:54 --> Form Validation Class Initialized
INFO - 2023-11-05 15:50:54 --> Helper loaded: custom_helper
INFO - 2023-11-05 15:50:54 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 15:50:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 15:50:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 15:50:54 --> Final output sent to browser
DEBUG - 2023-11-05 15:50:54 --> Total execution time: 0.1253
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> Config Class Initialized
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
INFO - 2023-11-05 11:20:58 --> Hooks Class Initialized
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
INFO - 2023-11-05 11:20:58 --> Utf8 Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> URI Class Initialized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
INFO - 2023-11-05 11:20:58 --> Router Class Initialized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
INFO - 2023-11-05 11:20:58 --> Output Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Security Class Initialized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
DEBUG - 2023-11-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
INFO - 2023-11-05 11:20:58 --> Input Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:20:58 --> Language Class Initialized
ERROR - 2023-11-05 11:20:58 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:21:27 --> Config Class Initialized
INFO - 2023-11-05 11:21:27 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:21:27 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:27 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:27 --> URI Class Initialized
INFO - 2023-11-05 11:21:27 --> Router Class Initialized
INFO - 2023-11-05 11:21:27 --> Output Class Initialized
INFO - 2023-11-05 11:21:27 --> Security Class Initialized
DEBUG - 2023-11-05 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:27 --> Input Class Initialized
INFO - 2023-11-05 11:21:27 --> Language Class Initialized
INFO - 2023-11-05 11:21:27 --> Loader Class Initialized
INFO - 2023-11-05 11:21:27 --> Helper loaded: url_helper
INFO - 2023-11-05 11:21:27 --> Helper loaded: file_helper
INFO - 2023-11-05 11:21:27 --> Database Driver Class Initialized
INFO - 2023-11-05 11:21:27 --> Email Class Initialized
DEBUG - 2023-11-05 11:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 11:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 11:21:27 --> Controller Class Initialized
INFO - 2023-11-05 11:21:27 --> Model "Contact_model" initialized
INFO - 2023-11-05 11:21:27 --> Model "CareerFormModel" initialized
INFO - 2023-11-05 11:21:27 --> Model "Home_model" initialized
INFO - 2023-11-05 11:21:27 --> Helper loaded: download_helper
INFO - 2023-11-05 11:21:27 --> Helper loaded: form_helper
INFO - 2023-11-05 11:21:27 --> Form Validation Class Initialized
INFO - 2023-11-05 15:51:27 --> Helper loaded: custom_helper
INFO - 2023-11-05 15:51:27 --> Model "Social_media_model" initialized
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-11-05 15:51:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-11-05 15:51:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-11-05 15:51:27 --> Final output sent to browser
DEBUG - 2023-11-05 15:51:27 --> Total execution time: 0.1306
INFO - 2023-11-05 11:21:28 --> Config Class Initialized
INFO - 2023-11-05 11:21:28 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:21:28 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:28 --> Config Class Initialized
INFO - 2023-11-05 11:21:28 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:28 --> Hooks Class Initialized
INFO - 2023-11-05 11:21:28 --> URI Class Initialized
INFO - 2023-11-05 11:21:29 --> Router Class Initialized
DEBUG - 2023-11-05 11:21:29 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:29 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:29 --> URI Class Initialized
INFO - 2023-11-05 11:21:29 --> Router Class Initialized
INFO - 2023-11-05 11:21:29 --> Output Class Initialized
INFO - 2023-11-05 11:21:29 --> Security Class Initialized
DEBUG - 2023-11-05 11:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:29 --> Input Class Initialized
INFO - 2023-11-05 11:21:29 --> Language Class Initialized
ERROR - 2023-11-05 11:21:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:21:29 --> Output Class Initialized
INFO - 2023-11-05 11:21:29 --> Security Class Initialized
DEBUG - 2023-11-05 11:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:29 --> Input Class Initialized
INFO - 2023-11-05 11:21:29 --> Language Class Initialized
ERROR - 2023-11-05 11:21:29 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:21:29 --> Config Class Initialized
INFO - 2023-11-05 11:21:29 --> Config Class Initialized
INFO - 2023-11-05 11:21:29 --> Hooks Class Initialized
INFO - 2023-11-05 11:21:29 --> Hooks Class Initialized
DEBUG - 2023-11-05 11:21:29 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:30 --> Utf8 Class Initialized
DEBUG - 2023-11-05 11:21:30 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:30 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:30 --> URI Class Initialized
INFO - 2023-11-05 11:21:30 --> Router Class Initialized
INFO - 2023-11-05 11:21:30 --> URI Class Initialized
INFO - 2023-11-05 11:21:30 --> Router Class Initialized
INFO - 2023-11-05 11:21:30 --> Config Class Initialized
INFO - 2023-11-05 11:21:30 --> Config Class Initialized
INFO - 2023-11-05 11:21:31 --> Output Class Initialized
INFO - 2023-11-05 11:21:31 --> Hooks Class Initialized
INFO - 2023-11-05 11:21:31 --> Output Class Initialized
DEBUG - 2023-11-05 11:21:31 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:31 --> Config Class Initialized
INFO - 2023-11-05 11:21:31 --> Hooks Class Initialized
INFO - 2023-11-05 11:21:31 --> Security Class Initialized
INFO - 2023-11-05 11:21:31 --> Hooks Class Initialized
INFO - 2023-11-05 11:21:31 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:31 --> URI Class Initialized
INFO - 2023-11-05 11:21:31 --> Router Class Initialized
INFO - 2023-11-05 11:21:31 --> Output Class Initialized
INFO - 2023-11-05 11:21:31 --> Security Class Initialized
DEBUG - 2023-11-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:31 --> Input Class Initialized
INFO - 2023-11-05 11:21:31 --> Language Class Initialized
ERROR - 2023-11-05 11:21:31 --> 404 Page Not Found: Assets/home
DEBUG - 2023-11-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:31 --> Security Class Initialized
INFO - 2023-11-05 11:21:31 --> Input Class Initialized
DEBUG - 2023-11-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-05 11:21:31 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:31 --> Input Class Initialized
DEBUG - 2023-11-05 11:21:31 --> UTF-8 Support Enabled
INFO - 2023-11-05 11:21:31 --> Language Class Initialized
INFO - 2023-11-05 11:21:31 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:31 --> Language Class Initialized
ERROR - 2023-11-05 11:21:31 --> 404 Page Not Found: Assets/home
ERROR - 2023-11-05 11:21:31 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:21:31 --> URI Class Initialized
INFO - 2023-11-05 11:21:31 --> Utf8 Class Initialized
INFO - 2023-11-05 11:21:31 --> Router Class Initialized
INFO - 2023-11-05 11:21:31 --> URI Class Initialized
INFO - 2023-11-05 11:21:31 --> Output Class Initialized
INFO - 2023-11-05 11:21:31 --> Router Class Initialized
INFO - 2023-11-05 11:21:31 --> Security Class Initialized
INFO - 2023-11-05 11:21:31 --> Output Class Initialized
DEBUG - 2023-11-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:31 --> Security Class Initialized
INFO - 2023-11-05 11:21:31 --> Input Class Initialized
DEBUG - 2023-11-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 11:21:31 --> Language Class Initialized
INFO - 2023-11-05 11:21:31 --> Input Class Initialized
ERROR - 2023-11-05 11:21:31 --> 404 Page Not Found: Assets/home
INFO - 2023-11-05 11:21:31 --> Language Class Initialized
ERROR - 2023-11-05 11:21:31 --> 404 Page Not Found: Assets/home
