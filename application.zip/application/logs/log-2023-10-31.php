<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-31 17:09:04 --> Config Class Initialized
INFO - 2023-10-31 17:09:04 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:09:04 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:09:04 --> Utf8 Class Initialized
INFO - 2023-10-31 17:09:04 --> URI Class Initialized
DEBUG - 2023-10-31 17:09:04 --> No URI present. Default controller set.
INFO - 2023-10-31 17:09:04 --> Router Class Initialized
INFO - 2023-10-31 17:09:04 --> Output Class Initialized
INFO - 2023-10-31 17:09:04 --> Security Class Initialized
DEBUG - 2023-10-31 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:09:04 --> Input Class Initialized
INFO - 2023-10-31 17:09:04 --> Language Class Initialized
INFO - 2023-10-31 17:09:04 --> Loader Class Initialized
INFO - 2023-10-31 17:09:04 --> Helper loaded: url_helper
INFO - 2023-10-31 17:09:04 --> Helper loaded: file_helper
INFO - 2023-10-31 17:09:04 --> Database Driver Class Initialized
INFO - 2023-10-31 17:09:04 --> Email Class Initialized
DEBUG - 2023-10-31 17:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:09:04 --> Controller Class Initialized
INFO - 2023-10-31 17:09:04 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:09:04 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:09:04 --> Model "Home_model" initialized
INFO - 2023-10-31 17:09:04 --> Helper loaded: download_helper
INFO - 2023-10-31 17:09:04 --> Helper loaded: form_helper
INFO - 2023-10-31 17:09:04 --> Form Validation Class Initialized
INFO - 2023-10-31 17:09:04 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:09:04 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:09:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:09:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-31 17:09:05 --> Final output sent to browser
DEBUG - 2023-10-31 17:09:05 --> Total execution time: 0.3407
INFO - 2023-10-31 17:09:17 --> Config Class Initialized
INFO - 2023-10-31 17:09:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:09:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:09:17 --> Utf8 Class Initialized
INFO - 2023-10-31 17:09:17 --> URI Class Initialized
INFO - 2023-10-31 17:09:17 --> Router Class Initialized
INFO - 2023-10-31 17:09:17 --> Output Class Initialized
INFO - 2023-10-31 17:09:17 --> Security Class Initialized
DEBUG - 2023-10-31 17:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:09:17 --> Input Class Initialized
INFO - 2023-10-31 17:09:17 --> Language Class Initialized
INFO - 2023-10-31 17:09:17 --> Loader Class Initialized
INFO - 2023-10-31 17:09:17 --> Helper loaded: url_helper
INFO - 2023-10-31 17:09:17 --> Helper loaded: file_helper
INFO - 2023-10-31 17:09:17 --> Database Driver Class Initialized
INFO - 2023-10-31 17:09:17 --> Email Class Initialized
DEBUG - 2023-10-31 17:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:09:17 --> Controller Class Initialized
INFO - 2023-10-31 17:09:17 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:09:17 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:09:17 --> Model "Home_model" initialized
INFO - 2023-10-31 17:09:17 --> Helper loaded: download_helper
INFO - 2023-10-31 17:09:17 --> Helper loaded: form_helper
INFO - 2023-10-31 17:09:17 --> Form Validation Class Initialized
INFO - 2023-10-31 17:09:17 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:09:17 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:09:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:09:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:09:17 --> Final output sent to browser
DEBUG - 2023-10-31 17:09:17 --> Total execution time: 0.2638
INFO - 2023-10-31 17:10:08 --> Config Class Initialized
INFO - 2023-10-31 17:10:08 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:10:08 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:10:08 --> Utf8 Class Initialized
INFO - 2023-10-31 17:10:08 --> URI Class Initialized
INFO - 2023-10-31 17:10:08 --> Router Class Initialized
INFO - 2023-10-31 17:10:08 --> Output Class Initialized
INFO - 2023-10-31 17:10:08 --> Security Class Initialized
DEBUG - 2023-10-31 17:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:10:08 --> Input Class Initialized
INFO - 2023-10-31 17:10:08 --> Language Class Initialized
INFO - 2023-10-31 17:10:08 --> Loader Class Initialized
INFO - 2023-10-31 17:10:08 --> Helper loaded: url_helper
INFO - 2023-10-31 17:10:08 --> Helper loaded: file_helper
INFO - 2023-10-31 17:10:08 --> Database Driver Class Initialized
INFO - 2023-10-31 17:10:08 --> Email Class Initialized
DEBUG - 2023-10-31 17:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:10:08 --> Controller Class Initialized
INFO - 2023-10-31 17:10:08 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:10:08 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:10:08 --> Model "Home_model" initialized
INFO - 2023-10-31 17:10:08 --> Helper loaded: download_helper
INFO - 2023-10-31 17:10:08 --> Helper loaded: form_helper
INFO - 2023-10-31 17:10:08 --> Form Validation Class Initialized
INFO - 2023-10-31 17:10:08 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:10:08 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:10:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:10:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:10:08 --> Final output sent to browser
DEBUG - 2023-10-31 17:10:09 --> Total execution time: 0.1626
INFO - 2023-10-31 17:10:50 --> Config Class Initialized
INFO - 2023-10-31 17:10:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:10:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:10:50 --> Utf8 Class Initialized
INFO - 2023-10-31 17:10:50 --> URI Class Initialized
INFO - 2023-10-31 17:10:50 --> Router Class Initialized
INFO - 2023-10-31 17:10:50 --> Output Class Initialized
INFO - 2023-10-31 17:10:50 --> Security Class Initialized
DEBUG - 2023-10-31 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:10:50 --> Input Class Initialized
INFO - 2023-10-31 17:10:50 --> Language Class Initialized
INFO - 2023-10-31 17:10:50 --> Loader Class Initialized
INFO - 2023-10-31 17:10:50 --> Helper loaded: url_helper
INFO - 2023-10-31 17:10:50 --> Helper loaded: file_helper
INFO - 2023-10-31 17:10:50 --> Database Driver Class Initialized
INFO - 2023-10-31 17:10:50 --> Email Class Initialized
DEBUG - 2023-10-31 17:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:10:50 --> Controller Class Initialized
INFO - 2023-10-31 17:10:50 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:10:50 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:10:50 --> Model "Home_model" initialized
INFO - 2023-10-31 17:10:50 --> Helper loaded: download_helper
INFO - 2023-10-31 17:10:50 --> Helper loaded: form_helper
INFO - 2023-10-31 17:10:50 --> Form Validation Class Initialized
INFO - 2023-10-31 17:10:50 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:10:50 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:10:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:10:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:10:50 --> Final output sent to browser
DEBUG - 2023-10-31 17:10:50 --> Total execution time: 0.1919
INFO - 2023-10-31 17:11:43 --> Config Class Initialized
INFO - 2023-10-31 17:11:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:11:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:11:43 --> Utf8 Class Initialized
INFO - 2023-10-31 17:11:43 --> URI Class Initialized
INFO - 2023-10-31 17:11:43 --> Router Class Initialized
INFO - 2023-10-31 17:11:43 --> Output Class Initialized
INFO - 2023-10-31 17:11:43 --> Security Class Initialized
DEBUG - 2023-10-31 17:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:11:43 --> Input Class Initialized
INFO - 2023-10-31 17:11:43 --> Language Class Initialized
INFO - 2023-10-31 17:11:43 --> Loader Class Initialized
INFO - 2023-10-31 17:11:43 --> Helper loaded: url_helper
INFO - 2023-10-31 17:11:43 --> Helper loaded: file_helper
INFO - 2023-10-31 17:11:43 --> Database Driver Class Initialized
INFO - 2023-10-31 17:11:43 --> Email Class Initialized
DEBUG - 2023-10-31 17:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:11:43 --> Controller Class Initialized
INFO - 2023-10-31 17:11:43 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:11:43 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:11:43 --> Model "Home_model" initialized
INFO - 2023-10-31 17:11:43 --> Helper loaded: download_helper
INFO - 2023-10-31 17:11:43 --> Helper loaded: form_helper
INFO - 2023-10-31 17:11:43 --> Form Validation Class Initialized
INFO - 2023-10-31 17:11:43 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:11:43 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:11:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:11:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:11:43 --> Final output sent to browser
DEBUG - 2023-10-31 17:11:44 --> Total execution time: 0.2308
INFO - 2023-10-31 17:12:52 --> Config Class Initialized
INFO - 2023-10-31 17:12:52 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:12:52 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:12:52 --> Utf8 Class Initialized
INFO - 2023-10-31 17:12:52 --> URI Class Initialized
INFO - 2023-10-31 17:12:52 --> Router Class Initialized
INFO - 2023-10-31 17:12:52 --> Output Class Initialized
INFO - 2023-10-31 17:12:52 --> Security Class Initialized
DEBUG - 2023-10-31 17:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:12:52 --> Input Class Initialized
INFO - 2023-10-31 17:12:52 --> Language Class Initialized
INFO - 2023-10-31 17:12:52 --> Loader Class Initialized
INFO - 2023-10-31 17:12:52 --> Helper loaded: url_helper
INFO - 2023-10-31 17:12:52 --> Helper loaded: file_helper
INFO - 2023-10-31 17:12:52 --> Database Driver Class Initialized
INFO - 2023-10-31 17:12:52 --> Email Class Initialized
DEBUG - 2023-10-31 17:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:12:52 --> Controller Class Initialized
INFO - 2023-10-31 17:12:52 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:12:52 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:12:52 --> Model "Home_model" initialized
INFO - 2023-10-31 17:12:52 --> Helper loaded: download_helper
INFO - 2023-10-31 17:12:52 --> Helper loaded: form_helper
INFO - 2023-10-31 17:12:52 --> Form Validation Class Initialized
INFO - 2023-10-31 17:12:52 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:12:52 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
ERROR - 2023-10-31 17:12:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 150
INFO - 2023-10-31 17:12:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:12:53 --> Final output sent to browser
DEBUG - 2023-10-31 17:12:53 --> Total execution time: 0.2731
INFO - 2023-10-31 17:14:18 --> Config Class Initialized
INFO - 2023-10-31 17:14:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:14:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:14:18 --> Utf8 Class Initialized
INFO - 2023-10-31 17:14:18 --> URI Class Initialized
INFO - 2023-10-31 17:14:18 --> Router Class Initialized
INFO - 2023-10-31 17:14:18 --> Output Class Initialized
INFO - 2023-10-31 17:14:18 --> Security Class Initialized
DEBUG - 2023-10-31 17:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:14:18 --> Input Class Initialized
INFO - 2023-10-31 17:14:18 --> Language Class Initialized
INFO - 2023-10-31 17:14:18 --> Loader Class Initialized
INFO - 2023-10-31 17:14:18 --> Helper loaded: url_helper
INFO - 2023-10-31 17:14:18 --> Helper loaded: file_helper
INFO - 2023-10-31 17:14:18 --> Database Driver Class Initialized
INFO - 2023-10-31 17:14:18 --> Email Class Initialized
DEBUG - 2023-10-31 17:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:14:18 --> Controller Class Initialized
INFO - 2023-10-31 17:14:18 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:14:18 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:14:18 --> Model "Home_model" initialized
INFO - 2023-10-31 17:14:18 --> Helper loaded: download_helper
INFO - 2023-10-31 17:14:18 --> Helper loaded: form_helper
INFO - 2023-10-31 17:14:18 --> Form Validation Class Initialized
INFO - 2023-10-31 17:14:18 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:14:18 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:14:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:14:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:14:18 --> Final output sent to browser
DEBUG - 2023-10-31 17:14:18 --> Total execution time: 0.1369
INFO - 2023-10-31 17:15:10 --> Config Class Initialized
INFO - 2023-10-31 17:15:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:15:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:15:10 --> Utf8 Class Initialized
INFO - 2023-10-31 17:15:10 --> URI Class Initialized
INFO - 2023-10-31 17:15:10 --> Router Class Initialized
INFO - 2023-10-31 17:15:10 --> Output Class Initialized
INFO - 2023-10-31 17:15:10 --> Security Class Initialized
DEBUG - 2023-10-31 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:15:10 --> Input Class Initialized
INFO - 2023-10-31 17:15:10 --> Language Class Initialized
INFO - 2023-10-31 17:15:10 --> Loader Class Initialized
INFO - 2023-10-31 17:15:10 --> Helper loaded: url_helper
INFO - 2023-10-31 17:15:10 --> Helper loaded: file_helper
INFO - 2023-10-31 17:15:10 --> Database Driver Class Initialized
INFO - 2023-10-31 17:15:10 --> Email Class Initialized
DEBUG - 2023-10-31 17:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:15:10 --> Controller Class Initialized
INFO - 2023-10-31 17:15:10 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:15:10 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:15:10 --> Model "Home_model" initialized
INFO - 2023-10-31 17:15:10 --> Helper loaded: download_helper
INFO - 2023-10-31 17:15:10 --> Helper loaded: form_helper
INFO - 2023-10-31 17:15:10 --> Form Validation Class Initialized
INFO - 2023-10-31 17:15:10 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:15:10 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:15:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/careers.php
INFO - 2023-10-31 17:15:10 --> Final output sent to browser
DEBUG - 2023-10-31 17:15:10 --> Total execution time: 0.1521
INFO - 2023-10-31 17:19:18 --> Config Class Initialized
INFO - 2023-10-31 17:19:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:19:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:19:18 --> Utf8 Class Initialized
INFO - 2023-10-31 17:19:18 --> URI Class Initialized
INFO - 2023-10-31 17:19:18 --> Router Class Initialized
INFO - 2023-10-31 17:19:18 --> Output Class Initialized
INFO - 2023-10-31 17:19:18 --> Security Class Initialized
DEBUG - 2023-10-31 17:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:19:18 --> Input Class Initialized
INFO - 2023-10-31 17:19:18 --> Language Class Initialized
INFO - 2023-10-31 17:19:18 --> Loader Class Initialized
INFO - 2023-10-31 17:19:18 --> Helper loaded: url_helper
INFO - 2023-10-31 17:19:18 --> Helper loaded: file_helper
INFO - 2023-10-31 17:19:18 --> Database Driver Class Initialized
INFO - 2023-10-31 17:19:18 --> Email Class Initialized
DEBUG - 2023-10-31 17:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:19:18 --> Controller Class Initialized
INFO - 2023-10-31 17:19:18 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:19:18 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:19:18 --> Model "Home_model" initialized
INFO - 2023-10-31 17:19:18 --> Helper loaded: download_helper
INFO - 2023-10-31 17:19:18 --> Helper loaded: form_helper
INFO - 2023-10-31 17:19:18 --> Form Validation Class Initialized
INFO - 2023-10-31 17:19:18 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:19:18 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:19:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:19:18 --> Final output sent to browser
DEBUG - 2023-10-31 17:19:18 --> Total execution time: 0.1872
INFO - 2023-10-31 17:19:37 --> Config Class Initialized
INFO - 2023-10-31 17:19:37 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:19:37 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:19:37 --> Utf8 Class Initialized
INFO - 2023-10-31 17:19:37 --> URI Class Initialized
INFO - 2023-10-31 17:19:37 --> Router Class Initialized
INFO - 2023-10-31 17:19:37 --> Output Class Initialized
INFO - 2023-10-31 17:19:37 --> Security Class Initialized
DEBUG - 2023-10-31 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:19:37 --> Input Class Initialized
INFO - 2023-10-31 17:19:37 --> Language Class Initialized
INFO - 2023-10-31 17:19:37 --> Loader Class Initialized
INFO - 2023-10-31 17:19:37 --> Helper loaded: url_helper
INFO - 2023-10-31 17:19:37 --> Helper loaded: file_helper
INFO - 2023-10-31 17:19:37 --> Database Driver Class Initialized
INFO - 2023-10-31 17:19:37 --> Email Class Initialized
DEBUG - 2023-10-31 17:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:19:37 --> Controller Class Initialized
INFO - 2023-10-31 17:19:37 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:19:37 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:19:37 --> Model "Home_model" initialized
INFO - 2023-10-31 17:19:37 --> Helper loaded: download_helper
INFO - 2023-10-31 17:19:37 --> Helper loaded: form_helper
INFO - 2023-10-31 17:19:37 --> Form Validation Class Initialized
INFO - 2023-10-31 17:19:37 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:19:37 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:19:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:19:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:19:37 --> Final output sent to browser
DEBUG - 2023-10-31 17:19:38 --> Total execution time: 0.2657
INFO - 2023-10-31 17:20:26 --> Config Class Initialized
INFO - 2023-10-31 17:20:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:20:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:20:26 --> Utf8 Class Initialized
INFO - 2023-10-31 17:20:26 --> URI Class Initialized
INFO - 2023-10-31 17:20:26 --> Router Class Initialized
INFO - 2023-10-31 17:20:26 --> Output Class Initialized
INFO - 2023-10-31 17:20:26 --> Security Class Initialized
DEBUG - 2023-10-31 17:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:20:26 --> Input Class Initialized
INFO - 2023-10-31 17:20:26 --> Language Class Initialized
INFO - 2023-10-31 17:20:27 --> Loader Class Initialized
INFO - 2023-10-31 17:20:27 --> Helper loaded: url_helper
INFO - 2023-10-31 17:20:27 --> Helper loaded: file_helper
INFO - 2023-10-31 17:20:27 --> Database Driver Class Initialized
INFO - 2023-10-31 17:20:27 --> Email Class Initialized
DEBUG - 2023-10-31 17:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:20:27 --> Controller Class Initialized
INFO - 2023-10-31 17:20:27 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:20:27 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:20:27 --> Model "Home_model" initialized
INFO - 2023-10-31 17:20:27 --> Helper loaded: download_helper
INFO - 2023-10-31 17:20:27 --> Helper loaded: form_helper
INFO - 2023-10-31 17:20:27 --> Form Validation Class Initialized
INFO - 2023-10-31 17:20:27 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:20:27 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:20:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:20:27 --> Final output sent to browser
DEBUG - 2023-10-31 17:20:27 --> Total execution time: 0.1984
INFO - 2023-10-31 17:20:37 --> Config Class Initialized
INFO - 2023-10-31 17:20:37 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:20:37 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:20:37 --> Utf8 Class Initialized
INFO - 2023-10-31 17:20:37 --> URI Class Initialized
INFO - 2023-10-31 17:20:37 --> Router Class Initialized
INFO - 2023-10-31 17:20:37 --> Output Class Initialized
INFO - 2023-10-31 17:20:37 --> Security Class Initialized
DEBUG - 2023-10-31 17:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:20:37 --> Input Class Initialized
INFO - 2023-10-31 17:20:37 --> Language Class Initialized
INFO - 2023-10-31 17:20:37 --> Loader Class Initialized
INFO - 2023-10-31 17:20:37 --> Helper loaded: url_helper
INFO - 2023-10-31 17:20:37 --> Helper loaded: file_helper
INFO - 2023-10-31 17:20:37 --> Database Driver Class Initialized
INFO - 2023-10-31 17:20:37 --> Email Class Initialized
DEBUG - 2023-10-31 17:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:20:37 --> Controller Class Initialized
INFO - 2023-10-31 17:20:37 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:20:37 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:20:37 --> Model "Home_model" initialized
INFO - 2023-10-31 17:20:37 --> Helper loaded: download_helper
INFO - 2023-10-31 17:20:37 --> Helper loaded: form_helper
INFO - 2023-10-31 17:20:37 --> Form Validation Class Initialized
INFO - 2023-10-31 17:20:37 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:20:37 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:20:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:20:37 --> Final output sent to browser
DEBUG - 2023-10-31 17:20:37 --> Total execution time: 0.1520
INFO - 2023-10-31 17:21:02 --> Config Class Initialized
INFO - 2023-10-31 17:21:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:21:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:21:02 --> Utf8 Class Initialized
INFO - 2023-10-31 17:21:02 --> URI Class Initialized
INFO - 2023-10-31 17:21:02 --> Router Class Initialized
INFO - 2023-10-31 17:21:02 --> Output Class Initialized
INFO - 2023-10-31 17:21:02 --> Security Class Initialized
DEBUG - 2023-10-31 17:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:21:02 --> Input Class Initialized
INFO - 2023-10-31 17:21:02 --> Language Class Initialized
INFO - 2023-10-31 17:21:02 --> Loader Class Initialized
INFO - 2023-10-31 17:21:02 --> Helper loaded: url_helper
INFO - 2023-10-31 17:21:02 --> Helper loaded: file_helper
INFO - 2023-10-31 17:21:02 --> Database Driver Class Initialized
INFO - 2023-10-31 17:21:02 --> Email Class Initialized
DEBUG - 2023-10-31 17:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:21:02 --> Controller Class Initialized
INFO - 2023-10-31 17:21:02 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:21:02 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:21:02 --> Model "Home_model" initialized
INFO - 2023-10-31 17:21:02 --> Helper loaded: download_helper
INFO - 2023-10-31 17:21:02 --> Helper loaded: form_helper
INFO - 2023-10-31 17:21:02 --> Form Validation Class Initialized
INFO - 2023-10-31 17:21:02 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:21:02 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:21:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:21:02 --> Final output sent to browser
DEBUG - 2023-10-31 17:21:03 --> Total execution time: 0.1498
INFO - 2023-10-31 17:21:15 --> Config Class Initialized
INFO - 2023-10-31 17:21:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:21:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:21:15 --> Utf8 Class Initialized
INFO - 2023-10-31 17:21:15 --> URI Class Initialized
INFO - 2023-10-31 17:21:15 --> Router Class Initialized
INFO - 2023-10-31 17:21:15 --> Output Class Initialized
INFO - 2023-10-31 17:21:15 --> Security Class Initialized
DEBUG - 2023-10-31 17:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:21:15 --> Input Class Initialized
INFO - 2023-10-31 17:21:15 --> Language Class Initialized
INFO - 2023-10-31 17:21:15 --> Loader Class Initialized
INFO - 2023-10-31 17:21:15 --> Helper loaded: url_helper
INFO - 2023-10-31 17:21:15 --> Helper loaded: file_helper
INFO - 2023-10-31 17:21:15 --> Database Driver Class Initialized
INFO - 2023-10-31 17:21:15 --> Email Class Initialized
DEBUG - 2023-10-31 17:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:21:15 --> Controller Class Initialized
INFO - 2023-10-31 17:21:15 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:21:15 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:21:15 --> Model "Home_model" initialized
INFO - 2023-10-31 17:21:15 --> Helper loaded: download_helper
INFO - 2023-10-31 17:21:15 --> Helper loaded: form_helper
INFO - 2023-10-31 17:21:15 --> Form Validation Class Initialized
INFO - 2023-10-31 17:21:15 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:21:15 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:21:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:21:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:21:15 --> Final output sent to browser
DEBUG - 2023-10-31 17:21:16 --> Total execution time: 0.1573
INFO - 2023-10-31 17:22:19 --> Config Class Initialized
INFO - 2023-10-31 17:22:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:22:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:22:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:22:19 --> URI Class Initialized
INFO - 2023-10-31 17:22:19 --> Router Class Initialized
INFO - 2023-10-31 17:22:19 --> Output Class Initialized
INFO - 2023-10-31 17:22:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:22:19 --> Input Class Initialized
INFO - 2023-10-31 17:22:19 --> Language Class Initialized
INFO - 2023-10-31 17:22:19 --> Loader Class Initialized
INFO - 2023-10-31 17:22:19 --> Helper loaded: url_helper
INFO - 2023-10-31 17:22:19 --> Helper loaded: file_helper
INFO - 2023-10-31 17:22:19 --> Database Driver Class Initialized
INFO - 2023-10-31 17:22:19 --> Email Class Initialized
DEBUG - 2023-10-31 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:22:19 --> Controller Class Initialized
INFO - 2023-10-31 17:22:19 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:22:19 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:22:19 --> Model "Home_model" initialized
INFO - 2023-10-31 17:22:19 --> Helper loaded: download_helper
INFO - 2023-10-31 17:22:19 --> Helper loaded: form_helper
INFO - 2023-10-31 17:22:19 --> Form Validation Class Initialized
INFO - 2023-10-31 17:22:19 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:22:19 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:22:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:22:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:22:19 --> Final output sent to browser
DEBUG - 2023-10-31 17:22:19 --> Total execution time: 0.1851
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
INFO - 2023-10-31 17:23:13 --> Config Class Initialized
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Utf8 Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> URI Class Initialized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
INFO - 2023-10-31 17:23:13 --> Router Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:23:13 --> Output Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Security Class Initialized
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
DEBUG - 2023-10-31 17:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:23:13 --> Input Class Initialized
INFO - 2023-10-31 17:23:13 --> Language Class Initialized
ERROR - 2023-10-31 17:23:13 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:28 --> Config Class Initialized
INFO - 2023-10-31 17:27:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:28 --> URI Class Initialized
INFO - 2023-10-31 17:27:29 --> Router Class Initialized
INFO - 2023-10-31 17:27:29 --> Output Class Initialized
INFO - 2023-10-31 17:27:29 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:29 --> Input Class Initialized
INFO - 2023-10-31 17:27:29 --> Language Class Initialized
INFO - 2023-10-31 17:27:29 --> Loader Class Initialized
INFO - 2023-10-31 17:27:29 --> Helper loaded: url_helper
INFO - 2023-10-31 17:27:29 --> Helper loaded: file_helper
INFO - 2023-10-31 17:27:29 --> Database Driver Class Initialized
INFO - 2023-10-31 17:27:29 --> Email Class Initialized
DEBUG - 2023-10-31 17:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:27:29 --> Controller Class Initialized
INFO - 2023-10-31 17:27:29 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:27:29 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:27:29 --> Model "Home_model" initialized
INFO - 2023-10-31 17:27:29 --> Helper loaded: download_helper
INFO - 2023-10-31 17:27:29 --> Helper loaded: form_helper
INFO - 2023-10-31 17:27:29 --> Form Validation Class Initialized
INFO - 2023-10-31 17:27:29 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:27:29 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:27:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:27:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:27:29 --> Final output sent to browser
DEBUG - 2023-10-31 17:27:30 --> Total execution time: 1.5844
INFO - 2023-10-31 17:27:32 --> Config Class Initialized
INFO - 2023-10-31 17:27:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:32 --> URI Class Initialized
INFO - 2023-10-31 17:27:32 --> Router Class Initialized
INFO - 2023-10-31 17:27:32 --> Output Class Initialized
INFO - 2023-10-31 17:27:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:32 --> Input Class Initialized
INFO - 2023-10-31 17:27:32 --> Language Class Initialized
ERROR - 2023-10-31 17:27:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:32 --> Config Class Initialized
INFO - 2023-10-31 17:27:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:32 --> URI Class Initialized
INFO - 2023-10-31 17:27:32 --> Router Class Initialized
INFO - 2023-10-31 17:27:32 --> Output Class Initialized
INFO - 2023-10-31 17:27:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:32 --> Input Class Initialized
INFO - 2023-10-31 17:27:32 --> Language Class Initialized
ERROR - 2023-10-31 17:27:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:32 --> Config Class Initialized
INFO - 2023-10-31 17:27:32 --> Config Class Initialized
INFO - 2023-10-31 17:27:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:32 --> URI Class Initialized
INFO - 2023-10-31 17:27:32 --> Router Class Initialized
INFO - 2023-10-31 17:27:32 --> Output Class Initialized
INFO - 2023-10-31 17:27:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:32 --> Input Class Initialized
INFO - 2023-10-31 17:27:32 --> Language Class Initialized
ERROR - 2023-10-31 17:27:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:32 --> Config Class Initialized
INFO - 2023-10-31 17:27:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:32 --> URI Class Initialized
INFO - 2023-10-31 17:27:32 --> Router Class Initialized
INFO - 2023-10-31 17:27:32 --> Output Class Initialized
INFO - 2023-10-31 17:27:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:32 --> Input Class Initialized
INFO - 2023-10-31 17:27:32 --> Language Class Initialized
ERROR - 2023-10-31 17:27:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:33 --> Config Class Initialized
INFO - 2023-10-31 17:27:33 --> Hooks Class Initialized
INFO - 2023-10-31 17:27:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:33 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:27:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:33 --> URI Class Initialized
INFO - 2023-10-31 17:27:33 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:33 --> Router Class Initialized
INFO - 2023-10-31 17:27:33 --> Output Class Initialized
INFO - 2023-10-31 17:27:33 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:33 --> Input Class Initialized
INFO - 2023-10-31 17:27:33 --> Language Class Initialized
ERROR - 2023-10-31 17:27:33 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:34 --> URI Class Initialized
INFO - 2023-10-31 17:27:34 --> Router Class Initialized
INFO - 2023-10-31 17:27:34 --> Output Class Initialized
INFO - 2023-10-31 17:27:35 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:35 --> Input Class Initialized
INFO - 2023-10-31 17:27:35 --> Language Class Initialized
ERROR - 2023-10-31 17:27:35 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:35 --> Config Class Initialized
INFO - 2023-10-31 17:27:35 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:35 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:35 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:35 --> URI Class Initialized
INFO - 2023-10-31 17:27:35 --> Router Class Initialized
INFO - 2023-10-31 17:27:35 --> Output Class Initialized
INFO - 2023-10-31 17:27:35 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:35 --> Input Class Initialized
INFO - 2023-10-31 17:27:35 --> Language Class Initialized
ERROR - 2023-10-31 17:27:35 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:48 --> Config Class Initialized
INFO - 2023-10-31 17:27:48 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:48 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:48 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:48 --> URI Class Initialized
INFO - 2023-10-31 17:27:48 --> Router Class Initialized
INFO - 2023-10-31 17:27:48 --> Output Class Initialized
INFO - 2023-10-31 17:27:48 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:48 --> Input Class Initialized
INFO - 2023-10-31 17:27:48 --> Language Class Initialized
INFO - 2023-10-31 17:27:48 --> Loader Class Initialized
INFO - 2023-10-31 17:27:48 --> Helper loaded: url_helper
INFO - 2023-10-31 17:27:48 --> Helper loaded: file_helper
INFO - 2023-10-31 17:27:48 --> Database Driver Class Initialized
INFO - 2023-10-31 17:27:48 --> Email Class Initialized
DEBUG - 2023-10-31 17:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:27:48 --> Controller Class Initialized
INFO - 2023-10-31 17:27:48 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:27:48 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:27:48 --> Model "Home_model" initialized
INFO - 2023-10-31 17:27:48 --> Helper loaded: download_helper
INFO - 2023-10-31 17:27:48 --> Helper loaded: form_helper
INFO - 2023-10-31 17:27:48 --> Form Validation Class Initialized
INFO - 2023-10-31 17:27:48 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:27:48 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:27:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:27:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:27:48 --> Final output sent to browser
DEBUG - 2023-10-31 17:27:48 --> Total execution time: 0.0838
INFO - 2023-10-31 17:27:50 --> Config Class Initialized
INFO - 2023-10-31 17:27:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:50 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:50 --> URI Class Initialized
INFO - 2023-10-31 17:27:50 --> Router Class Initialized
INFO - 2023-10-31 17:27:50 --> Output Class Initialized
INFO - 2023-10-31 17:27:50 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:50 --> Input Class Initialized
INFO - 2023-10-31 17:27:50 --> Language Class Initialized
ERROR - 2023-10-31 17:27:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:51 --> Config Class Initialized
INFO - 2023-10-31 17:27:51 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:51 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:51 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:51 --> URI Class Initialized
INFO - 2023-10-31 17:27:52 --> Router Class Initialized
INFO - 2023-10-31 17:27:52 --> Config Class Initialized
INFO - 2023-10-31 17:27:52 --> Hooks Class Initialized
INFO - 2023-10-31 17:27:53 --> Output Class Initialized
DEBUG - 2023-10-31 17:27:53 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:54 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:54 --> URI Class Initialized
INFO - 2023-10-31 17:27:54 --> Router Class Initialized
INFO - 2023-10-31 17:27:54 --> Output Class Initialized
INFO - 2023-10-31 17:27:54 --> Security Class Initialized
DEBUG - 2023-10-31 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:54 --> Input Class Initialized
INFO - 2023-10-31 17:27:54 --> Language Class Initialized
ERROR - 2023-10-31 17:27:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:55 --> Config Class Initialized
INFO - 2023-10-31 17:27:55 --> Hooks Class Initialized
INFO - 2023-10-31 17:27:55 --> Config Class Initialized
INFO - 2023-10-31 17:27:55 --> Config Class Initialized
DEBUG - 2023-10-31 17:27:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:55 --> Hooks Class Initialized
INFO - 2023-10-31 17:27:55 --> Security Class Initialized
INFO - 2023-10-31 17:27:55 --> Config Class Initialized
INFO - 2023-10-31 17:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:55 --> Hooks Class Initialized
INFO - 2023-10-31 17:27:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-31 17:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-31 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:55 --> URI Class Initialized
DEBUG - 2023-10-31 17:27:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:27:55 --> Input Class Initialized
INFO - 2023-10-31 17:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:55 --> Language Class Initialized
INFO - 2023-10-31 17:27:55 --> URI Class Initialized
INFO - 2023-10-31 17:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:27:55 --> Router Class Initialized
INFO - 2023-10-31 17:27:55 --> URI Class Initialized
ERROR - 2023-10-31 17:27:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:27:55 --> Router Class Initialized
INFO - 2023-10-31 17:27:55 --> URI Class Initialized
INFO - 2023-10-31 17:27:55 --> Output Class Initialized
INFO - 2023-10-31 17:27:55 --> Router Class Initialized
INFO - 2023-10-31 17:27:55 --> Router Class Initialized
INFO - 2023-10-31 17:27:55 --> Output Class Initialized
INFO - 2023-10-31 17:27:55 --> Security Class Initialized
INFO - 2023-10-31 17:27:55 --> Security Class Initialized
INFO - 2023-10-31 17:27:55 --> Output Class Initialized
INFO - 2023-10-31 17:27:55 --> Output Class Initialized
DEBUG - 2023-10-31 17:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-31 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:55 --> Security Class Initialized
INFO - 2023-10-31 17:27:55 --> Input Class Initialized
INFO - 2023-10-31 17:27:55 --> Security Class Initialized
INFO - 2023-10-31 17:27:55 --> Input Class Initialized
DEBUG - 2023-10-31 17:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-31 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:27:55 --> Language Class Initialized
INFO - 2023-10-31 17:27:55 --> Input Class Initialized
INFO - 2023-10-31 17:27:55 --> Language Class Initialized
INFO - 2023-10-31 17:27:55 --> Input Class Initialized
INFO - 2023-10-31 17:27:55 --> Language Class Initialized
INFO - 2023-10-31 17:27:55 --> Language Class Initialized
ERROR - 2023-10-31 17:27:55 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:27:56 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:27:56 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:27:56 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:28:02 --> Config Class Initialized
INFO - 2023-10-31 17:28:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:28:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:28:02 --> Utf8 Class Initialized
INFO - 2023-10-31 17:28:02 --> URI Class Initialized
INFO - 2023-10-31 17:28:02 --> Router Class Initialized
INFO - 2023-10-31 17:28:02 --> Output Class Initialized
INFO - 2023-10-31 17:28:02 --> Security Class Initialized
DEBUG - 2023-10-31 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:28:02 --> Input Class Initialized
INFO - 2023-10-31 17:28:02 --> Language Class Initialized
INFO - 2023-10-31 17:28:03 --> Loader Class Initialized
INFO - 2023-10-31 17:28:03 --> Helper loaded: url_helper
INFO - 2023-10-31 17:28:03 --> Helper loaded: file_helper
INFO - 2023-10-31 17:28:03 --> Database Driver Class Initialized
INFO - 2023-10-31 17:28:03 --> Email Class Initialized
DEBUG - 2023-10-31 17:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:28:03 --> Controller Class Initialized
INFO - 2023-10-31 17:28:03 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:28:03 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:28:03 --> Model "Home_model" initialized
INFO - 2023-10-31 17:28:03 --> Helper loaded: download_helper
INFO - 2023-10-31 17:28:03 --> Helper loaded: form_helper
INFO - 2023-10-31 17:28:03 --> Form Validation Class Initialized
INFO - 2023-10-31 17:31:24 --> Config Class Initialized
INFO - 2023-10-31 17:31:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:31:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:31:24 --> Utf8 Class Initialized
INFO - 2023-10-31 17:31:24 --> URI Class Initialized
INFO - 2023-10-31 17:31:24 --> Router Class Initialized
INFO - 2023-10-31 17:31:24 --> Output Class Initialized
INFO - 2023-10-31 17:31:24 --> Security Class Initialized
DEBUG - 2023-10-31 17:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:31:24 --> Input Class Initialized
INFO - 2023-10-31 17:31:24 --> Language Class Initialized
INFO - 2023-10-31 17:31:24 --> Loader Class Initialized
INFO - 2023-10-31 17:31:24 --> Helper loaded: url_helper
INFO - 2023-10-31 17:31:24 --> Helper loaded: file_helper
INFO - 2023-10-31 17:31:24 --> Database Driver Class Initialized
INFO - 2023-10-31 17:31:24 --> Email Class Initialized
DEBUG - 2023-10-31 17:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:31:24 --> Controller Class Initialized
INFO - 2023-10-31 17:31:24 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:31:24 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:31:24 --> Model "Home_model" initialized
INFO - 2023-10-31 17:31:24 --> Helper loaded: download_helper
INFO - 2023-10-31 17:31:24 --> Helper loaded: form_helper
INFO - 2023-10-31 17:31:24 --> Form Validation Class Initialized
INFO - 2023-10-31 17:31:36 --> Config Class Initialized
INFO - 2023-10-31 17:31:36 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:31:36 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:31:36 --> Utf8 Class Initialized
INFO - 2023-10-31 17:31:36 --> URI Class Initialized
INFO - 2023-10-31 17:31:36 --> Router Class Initialized
INFO - 2023-10-31 17:31:36 --> Output Class Initialized
INFO - 2023-10-31 17:31:36 --> Security Class Initialized
DEBUG - 2023-10-31 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:31:36 --> Input Class Initialized
INFO - 2023-10-31 17:31:36 --> Language Class Initialized
INFO - 2023-10-31 17:31:36 --> Loader Class Initialized
INFO - 2023-10-31 17:31:36 --> Helper loaded: url_helper
INFO - 2023-10-31 17:31:36 --> Helper loaded: file_helper
INFO - 2023-10-31 17:31:36 --> Database Driver Class Initialized
INFO - 2023-10-31 17:31:36 --> Email Class Initialized
DEBUG - 2023-10-31 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:31:36 --> Controller Class Initialized
INFO - 2023-10-31 17:31:36 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:31:36 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:31:36 --> Model "Home_model" initialized
INFO - 2023-10-31 17:31:36 --> Helper loaded: download_helper
INFO - 2023-10-31 17:31:36 --> Helper loaded: form_helper
INFO - 2023-10-31 17:31:36 --> Form Validation Class Initialized
INFO - 2023-10-31 17:31:36 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:31:36 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:31:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:31:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:31:36 --> Final output sent to browser
DEBUG - 2023-10-31 17:31:36 --> Total execution time: 0.1309
INFO - 2023-10-31 17:34:18 --> Config Class Initialized
INFO - 2023-10-31 17:34:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:34:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:34:18 --> Utf8 Class Initialized
INFO - 2023-10-31 17:34:18 --> URI Class Initialized
INFO - 2023-10-31 17:34:18 --> Router Class Initialized
INFO - 2023-10-31 17:34:18 --> Output Class Initialized
INFO - 2023-10-31 17:34:18 --> Security Class Initialized
DEBUG - 2023-10-31 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:34:18 --> Input Class Initialized
INFO - 2023-10-31 17:34:18 --> Language Class Initialized
INFO - 2023-10-31 17:34:18 --> Loader Class Initialized
INFO - 2023-10-31 17:34:18 --> Helper loaded: url_helper
INFO - 2023-10-31 17:34:18 --> Helper loaded: file_helper
INFO - 2023-10-31 17:34:18 --> Database Driver Class Initialized
INFO - 2023-10-31 17:34:18 --> Email Class Initialized
DEBUG - 2023-10-31 17:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:34:18 --> Controller Class Initialized
INFO - 2023-10-31 17:34:18 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:34:18 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:34:18 --> Model "Home_model" initialized
INFO - 2023-10-31 17:34:18 --> Helper loaded: download_helper
INFO - 2023-10-31 17:34:18 --> Helper loaded: form_helper
INFO - 2023-10-31 17:34:18 --> Form Validation Class Initialized
INFO - 2023-10-31 17:34:18 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:34:18 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:34:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:34:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:34:18 --> Final output sent to browser
DEBUG - 2023-10-31 17:34:18 --> Total execution time: 0.1308
INFO - 2023-10-31 17:34:27 --> Config Class Initialized
INFO - 2023-10-31 17:34:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:34:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:34:27 --> Utf8 Class Initialized
INFO - 2023-10-31 17:34:27 --> URI Class Initialized
INFO - 2023-10-31 17:34:27 --> Router Class Initialized
INFO - 2023-10-31 17:34:27 --> Output Class Initialized
INFO - 2023-10-31 17:34:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:34:27 --> Input Class Initialized
INFO - 2023-10-31 17:34:27 --> Language Class Initialized
INFO - 2023-10-31 17:34:27 --> Loader Class Initialized
INFO - 2023-10-31 17:34:27 --> Helper loaded: url_helper
INFO - 2023-10-31 17:34:27 --> Helper loaded: file_helper
INFO - 2023-10-31 17:34:27 --> Database Driver Class Initialized
INFO - 2023-10-31 17:34:27 --> Email Class Initialized
DEBUG - 2023-10-31 17:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:34:27 --> Controller Class Initialized
INFO - 2023-10-31 17:34:27 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:34:27 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:34:27 --> Model "Home_model" initialized
INFO - 2023-10-31 17:34:27 --> Helper loaded: download_helper
INFO - 2023-10-31 17:34:27 --> Helper loaded: form_helper
INFO - 2023-10-31 17:34:27 --> Form Validation Class Initialized
INFO - 2023-10-31 17:34:27 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:34:27 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:34:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:34:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:34:27 --> Final output sent to browser
DEBUG - 2023-10-31 17:34:27 --> Total execution time: 0.1382
INFO - 2023-10-31 17:35:07 --> Config Class Initialized
INFO - 2023-10-31 17:35:07 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:07 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:07 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:07 --> URI Class Initialized
INFO - 2023-10-31 17:35:07 --> Router Class Initialized
INFO - 2023-10-31 17:35:07 --> Output Class Initialized
INFO - 2023-10-31 17:35:07 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:07 --> Input Class Initialized
INFO - 2023-10-31 17:35:07 --> Language Class Initialized
INFO - 2023-10-31 17:35:07 --> Loader Class Initialized
INFO - 2023-10-31 17:35:07 --> Helper loaded: url_helper
INFO - 2023-10-31 17:35:07 --> Helper loaded: file_helper
INFO - 2023-10-31 17:35:07 --> Database Driver Class Initialized
INFO - 2023-10-31 17:35:07 --> Email Class Initialized
DEBUG - 2023-10-31 17:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:35:07 --> Controller Class Initialized
INFO - 2023-10-31 17:35:07 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:35:07 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:35:07 --> Model "Home_model" initialized
INFO - 2023-10-31 17:35:07 --> Helper loaded: download_helper
INFO - 2023-10-31 17:35:07 --> Helper loaded: form_helper
INFO - 2023-10-31 17:35:07 --> Form Validation Class Initialized
INFO - 2023-10-31 17:35:07 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:35:07 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:35:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:35:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:35:07 --> Final output sent to browser
DEBUG - 2023-10-31 17:35:08 --> Total execution time: 0.1400
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:35:19 --> Config Class Initialized
INFO - 2023-10-31 17:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:35:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:35:19 --> URI Class Initialized
INFO - 2023-10-31 17:35:19 --> Router Class Initialized
INFO - 2023-10-31 17:35:19 --> Output Class Initialized
INFO - 2023-10-31 17:35:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:35:19 --> Input Class Initialized
INFO - 2023-10-31 17:35:19 --> Language Class Initialized
ERROR - 2023-10-31 17:35:19 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:51 --> Config Class Initialized
INFO - 2023-10-31 17:38:51 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:51 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:51 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:51 --> URI Class Initialized
INFO - 2023-10-31 17:38:51 --> Router Class Initialized
INFO - 2023-10-31 17:38:51 --> Output Class Initialized
INFO - 2023-10-31 17:38:51 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:51 --> Input Class Initialized
INFO - 2023-10-31 17:38:51 --> Language Class Initialized
INFO - 2023-10-31 17:38:51 --> Loader Class Initialized
INFO - 2023-10-31 17:38:51 --> Helper loaded: url_helper
INFO - 2023-10-31 17:38:51 --> Helper loaded: file_helper
INFO - 2023-10-31 17:38:51 --> Database Driver Class Initialized
INFO - 2023-10-31 17:38:51 --> Email Class Initialized
DEBUG - 2023-10-31 17:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:38:51 --> Controller Class Initialized
INFO - 2023-10-31 17:38:51 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:38:51 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:38:51 --> Model "Home_model" initialized
INFO - 2023-10-31 17:38:51 --> Helper loaded: download_helper
INFO - 2023-10-31 17:38:51 --> Helper loaded: form_helper
INFO - 2023-10-31 17:38:51 --> Form Validation Class Initialized
INFO - 2023-10-31 17:38:51 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:38:51 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:38:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:38:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:38:52 --> Final output sent to browser
DEBUG - 2023-10-31 17:38:52 --> Total execution time: 0.1407
INFO - 2023-10-31 17:38:53 --> Config Class Initialized
INFO - 2023-10-31 17:38:53 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:53 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:53 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:53 --> URI Class Initialized
INFO - 2023-10-31 17:38:53 --> Router Class Initialized
INFO - 2023-10-31 17:38:54 --> Config Class Initialized
INFO - 2023-10-31 17:38:54 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:54 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:54 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:54 --> URI Class Initialized
INFO - 2023-10-31 17:38:54 --> Router Class Initialized
INFO - 2023-10-31 17:38:54 --> Output Class Initialized
INFO - 2023-10-31 17:38:54 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:54 --> Input Class Initialized
INFO - 2023-10-31 17:38:54 --> Language Class Initialized
ERROR - 2023-10-31 17:38:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:54 --> Output Class Initialized
INFO - 2023-10-31 17:38:54 --> Config Class Initialized
INFO - 2023-10-31 17:38:54 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:54 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:54 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:54 --> URI Class Initialized
INFO - 2023-10-31 17:38:54 --> Router Class Initialized
INFO - 2023-10-31 17:38:54 --> Output Class Initialized
INFO - 2023-10-31 17:38:54 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:54 --> Input Class Initialized
INFO - 2023-10-31 17:38:54 --> Language Class Initialized
ERROR - 2023-10-31 17:38:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:55 --> Config Class Initialized
INFO - 2023-10-31 17:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:55 --> URI Class Initialized
INFO - 2023-10-31 17:38:55 --> Router Class Initialized
INFO - 2023-10-31 17:38:55 --> Output Class Initialized
INFO - 2023-10-31 17:38:55 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:55 --> Input Class Initialized
INFO - 2023-10-31 17:38:55 --> Language Class Initialized
ERROR - 2023-10-31 17:38:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:55 --> Config Class Initialized
INFO - 2023-10-31 17:38:55 --> Config Class Initialized
INFO - 2023-10-31 17:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:55 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:55 --> URI Class Initialized
INFO - 2023-10-31 17:38:55 --> Router Class Initialized
INFO - 2023-10-31 17:38:55 --> Output Class Initialized
INFO - 2023-10-31 17:38:55 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:55 --> Input Class Initialized
INFO - 2023-10-31 17:38:55 --> Language Class Initialized
ERROR - 2023-10-31 17:38:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:56 --> Security Class Initialized
INFO - 2023-10-31 17:38:57 --> Config Class Initialized
INFO - 2023-10-31 17:38:57 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:38:57 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:57 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:58 --> Hooks Class Initialized
INFO - 2023-10-31 17:38:58 --> URI Class Initialized
INFO - 2023-10-31 17:38:58 --> Input Class Initialized
DEBUG - 2023-10-31 17:38:58 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:38:58 --> Utf8 Class Initialized
INFO - 2023-10-31 17:38:58 --> URI Class Initialized
INFO - 2023-10-31 17:38:58 --> Router Class Initialized
INFO - 2023-10-31 17:38:58 --> Output Class Initialized
INFO - 2023-10-31 17:38:58 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:58 --> Input Class Initialized
INFO - 2023-10-31 17:38:58 --> Language Class Initialized
ERROR - 2023-10-31 17:38:58 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:58 --> Router Class Initialized
INFO - 2023-10-31 17:38:58 --> Language Class Initialized
INFO - 2023-10-31 17:38:58 --> Output Class Initialized
ERROR - 2023-10-31 17:38:58 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:38:58 --> Security Class Initialized
DEBUG - 2023-10-31 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:38:58 --> Input Class Initialized
INFO - 2023-10-31 17:38:58 --> Language Class Initialized
ERROR - 2023-10-31 17:38:58 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:21 --> Config Class Initialized
INFO - 2023-10-31 17:40:22 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:22 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:22 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:22 --> URI Class Initialized
INFO - 2023-10-31 17:40:22 --> Router Class Initialized
INFO - 2023-10-31 17:40:22 --> Output Class Initialized
INFO - 2023-10-31 17:40:22 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:22 --> Input Class Initialized
INFO - 2023-10-31 17:40:22 --> Language Class Initialized
INFO - 2023-10-31 17:40:22 --> Loader Class Initialized
INFO - 2023-10-31 17:40:22 --> Helper loaded: url_helper
INFO - 2023-10-31 17:40:22 --> Helper loaded: file_helper
INFO - 2023-10-31 17:40:22 --> Database Driver Class Initialized
INFO - 2023-10-31 17:40:22 --> Email Class Initialized
DEBUG - 2023-10-31 17:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:40:22 --> Controller Class Initialized
INFO - 2023-10-31 17:40:22 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:40:22 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:40:22 --> Model "Home_model" initialized
INFO - 2023-10-31 17:40:22 --> Helper loaded: download_helper
INFO - 2023-10-31 17:40:22 --> Helper loaded: form_helper
INFO - 2023-10-31 17:40:22 --> Form Validation Class Initialized
INFO - 2023-10-31 17:40:22 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:40:22 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:40:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:40:22 --> Final output sent to browser
DEBUG - 2023-10-31 17:40:22 --> Total execution time: 0.2482
INFO - 2023-10-31 17:40:24 --> Config Class Initialized
INFO - 2023-10-31 17:40:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:24 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:24 --> URI Class Initialized
INFO - 2023-10-31 17:40:24 --> Router Class Initialized
INFO - 2023-10-31 17:40:24 --> Output Class Initialized
INFO - 2023-10-31 17:40:24 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:24 --> Input Class Initialized
INFO - 2023-10-31 17:40:24 --> Language Class Initialized
ERROR - 2023-10-31 17:40:24 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:25 --> Config Class Initialized
INFO - 2023-10-31 17:40:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:25 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:25 --> URI Class Initialized
INFO - 2023-10-31 17:40:25 --> Router Class Initialized
INFO - 2023-10-31 17:40:25 --> Output Class Initialized
INFO - 2023-10-31 17:40:25 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:25 --> Input Class Initialized
INFO - 2023-10-31 17:40:25 --> Language Class Initialized
ERROR - 2023-10-31 17:40:25 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:25 --> Config Class Initialized
INFO - 2023-10-31 17:40:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:27 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:27 --> URI Class Initialized
INFO - 2023-10-31 17:40:27 --> Router Class Initialized
INFO - 2023-10-31 17:40:27 --> Output Class Initialized
INFO - 2023-10-31 17:40:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:27 --> Input Class Initialized
INFO - 2023-10-31 17:40:27 --> Language Class Initialized
ERROR - 2023-10-31 17:40:27 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:27 --> Config Class Initialized
INFO - 2023-10-31 17:40:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:27 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:27 --> URI Class Initialized
INFO - 2023-10-31 17:40:27 --> Router Class Initialized
INFO - 2023-10-31 17:40:27 --> Output Class Initialized
INFO - 2023-10-31 17:40:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:27 --> Input Class Initialized
INFO - 2023-10-31 17:40:27 --> Language Class Initialized
ERROR - 2023-10-31 17:40:27 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:28 --> Config Class Initialized
INFO - 2023-10-31 17:40:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:28 --> URI Class Initialized
INFO - 2023-10-31 17:40:28 --> Router Class Initialized
INFO - 2023-10-31 17:40:28 --> Output Class Initialized
INFO - 2023-10-31 17:40:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:28 --> Input Class Initialized
INFO - 2023-10-31 17:40:28 --> Language Class Initialized
ERROR - 2023-10-31 17:40:28 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:28 --> Config Class Initialized
INFO - 2023-10-31 17:40:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:28 --> URI Class Initialized
INFO - 2023-10-31 17:40:28 --> Router Class Initialized
INFO - 2023-10-31 17:40:28 --> Output Class Initialized
INFO - 2023-10-31 17:40:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:28 --> Input Class Initialized
INFO - 2023-10-31 17:40:28 --> Language Class Initialized
ERROR - 2023-10-31 17:40:28 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:28 --> Config Class Initialized
INFO - 2023-10-31 17:40:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:28 --> URI Class Initialized
INFO - 2023-10-31 17:40:28 --> Router Class Initialized
INFO - 2023-10-31 17:40:28 --> Output Class Initialized
INFO - 2023-10-31 17:40:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:28 --> Input Class Initialized
INFO - 2023-10-31 17:40:28 --> Language Class Initialized
ERROR - 2023-10-31 17:40:28 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:47 --> Config Class Initialized
INFO - 2023-10-31 17:40:47 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:47 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:47 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:47 --> URI Class Initialized
INFO - 2023-10-31 17:40:47 --> Router Class Initialized
INFO - 2023-10-31 17:40:47 --> Output Class Initialized
INFO - 2023-10-31 17:40:47 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:47 --> Input Class Initialized
INFO - 2023-10-31 17:40:47 --> Language Class Initialized
INFO - 2023-10-31 17:40:47 --> Loader Class Initialized
INFO - 2023-10-31 17:40:47 --> Helper loaded: url_helper
INFO - 2023-10-31 17:40:47 --> Helper loaded: file_helper
INFO - 2023-10-31 17:40:47 --> Database Driver Class Initialized
INFO - 2023-10-31 17:40:47 --> Email Class Initialized
DEBUG - 2023-10-31 17:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:40:47 --> Controller Class Initialized
INFO - 2023-10-31 17:40:47 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:40:47 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:40:47 --> Model "Home_model" initialized
INFO - 2023-10-31 17:40:47 --> Helper loaded: download_helper
INFO - 2023-10-31 17:40:47 --> Helper loaded: form_helper
INFO - 2023-10-31 17:40:47 --> Form Validation Class Initialized
INFO - 2023-10-31 17:40:48 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:40:48 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:40:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:40:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:40:48 --> Final output sent to browser
DEBUG - 2023-10-31 17:40:48 --> Total execution time: 0.2515
INFO - 2023-10-31 17:40:49 --> Config Class Initialized
INFO - 2023-10-31 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:49 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:49 --> URI Class Initialized
INFO - 2023-10-31 17:40:49 --> Router Class Initialized
INFO - 2023-10-31 17:40:49 --> Output Class Initialized
INFO - 2023-10-31 17:40:49 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:49 --> Input Class Initialized
INFO - 2023-10-31 17:40:49 --> Language Class Initialized
ERROR - 2023-10-31 17:40:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:40:49 --> Config Class Initialized
INFO - 2023-10-31 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:49 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:49 --> URI Class Initialized
INFO - 2023-10-31 17:40:49 --> Router Class Initialized
INFO - 2023-10-31 17:40:49 --> Output Class Initialized
INFO - 2023-10-31 17:40:49 --> Security Class Initialized
INFO - 2023-10-31 17:40:51 --> Config Class Initialized
INFO - 2023-10-31 17:40:51 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:40:51 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:40:51 --> Utf8 Class Initialized
INFO - 2023-10-31 17:40:51 --> URI Class Initialized
INFO - 2023-10-31 17:40:51 --> Router Class Initialized
INFO - 2023-10-31 17:40:51 --> Output Class Initialized
INFO - 2023-10-31 17:40:51 --> Security Class Initialized
DEBUG - 2023-10-31 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:40:51 --> Input Class Initialized
INFO - 2023-10-31 17:40:51 --> Language Class Initialized
ERROR - 2023-10-31 17:40:51 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:41:27 --> Config Class Initialized
INFO - 2023-10-31 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:27 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:27 --> URI Class Initialized
INFO - 2023-10-31 17:41:27 --> Router Class Initialized
INFO - 2023-10-31 17:41:27 --> Output Class Initialized
INFO - 2023-10-31 17:41:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:41:27 --> Input Class Initialized
INFO - 2023-10-31 17:41:27 --> Language Class Initialized
INFO - 2023-10-31 17:41:27 --> Loader Class Initialized
INFO - 2023-10-31 17:41:27 --> Helper loaded: url_helper
INFO - 2023-10-31 17:41:27 --> Helper loaded: file_helper
INFO - 2023-10-31 17:41:27 --> Database Driver Class Initialized
INFO - 2023-10-31 17:41:27 --> Email Class Initialized
DEBUG - 2023-10-31 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:41:27 --> Controller Class Initialized
INFO - 2023-10-31 17:41:27 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:41:27 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:41:27 --> Model "Home_model" initialized
INFO - 2023-10-31 17:41:27 --> Helper loaded: download_helper
INFO - 2023-10-31 17:41:27 --> Helper loaded: form_helper
INFO - 2023-10-31 17:41:27 --> Form Validation Class Initialized
INFO - 2023-10-31 17:41:27 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:41:27 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:41:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:41:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:41:27 --> Final output sent to browser
DEBUG - 2023-10-31 17:41:27 --> Total execution time: 0.2677
INFO - 2023-10-31 17:41:29 --> Config Class Initialized
INFO - 2023-10-31 17:41:29 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:29 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:29 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:29 --> URI Class Initialized
INFO - 2023-10-31 17:41:29 --> Router Class Initialized
INFO - 2023-10-31 17:41:29 --> Output Class Initialized
INFO - 2023-10-31 17:41:29 --> Security Class Initialized
DEBUG - 2023-10-31 17:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:41:29 --> Input Class Initialized
INFO - 2023-10-31 17:41:29 --> Language Class Initialized
ERROR - 2023-10-31 17:41:29 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:41:29 --> Config Class Initialized
INFO - 2023-10-31 17:41:30 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:30 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:30 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:31 --> URI Class Initialized
INFO - 2023-10-31 17:41:31 --> Router Class Initialized
INFO - 2023-10-31 17:41:31 --> Output Class Initialized
INFO - 2023-10-31 17:41:31 --> Security Class Initialized
DEBUG - 2023-10-31 17:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:41:31 --> Input Class Initialized
INFO - 2023-10-31 17:41:31 --> Language Class Initialized
ERROR - 2023-10-31 17:41:31 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:41:32 --> Config Class Initialized
INFO - 2023-10-31 17:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:32 --> URI Class Initialized
INFO - 2023-10-31 17:41:32 --> Router Class Initialized
INFO - 2023-10-31 17:41:32 --> Output Class Initialized
INFO - 2023-10-31 17:41:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:41:32 --> Input Class Initialized
INFO - 2023-10-31 17:41:32 --> Language Class Initialized
ERROR - 2023-10-31 17:41:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:41:32 --> Config Class Initialized
INFO - 2023-10-31 17:41:33 --> Config Class Initialized
INFO - 2023-10-31 17:41:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:33 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:33 --> URI Class Initialized
INFO - 2023-10-31 17:41:33 --> Router Class Initialized
INFO - 2023-10-31 17:41:33 --> Output Class Initialized
INFO - 2023-10-31 17:41:33 --> Security Class Initialized
DEBUG - 2023-10-31 17:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:41:33 --> Input Class Initialized
INFO - 2023-10-31 17:41:33 --> Language Class Initialized
ERROR - 2023-10-31 17:41:33 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:41:33 --> Config Class Initialized
INFO - 2023-10-31 17:41:33 --> Hooks Class Initialized
INFO - 2023-10-31 17:41:33 --> Config Class Initialized
INFO - 2023-10-31 17:41:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:33 --> Hooks Class Initialized
INFO - 2023-10-31 17:41:33 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:41:33 --> UTF-8 Support Enabled
DEBUG - 2023-10-31 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:41:33 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:33 --> URI Class Initialized
INFO - 2023-10-31 17:41:33 --> Utf8 Class Initialized
INFO - 2023-10-31 17:41:33 --> URI Class Initialized
INFO - 2023-10-31 17:41:33 --> Router Class Initialized
INFO - 2023-10-31 17:41:33 --> URI Class Initialized
INFO - 2023-10-31 17:41:34 --> Router Class Initialized
INFO - 2023-10-31 17:43:03 --> Config Class Initialized
INFO - 2023-10-31 17:43:03 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:03 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:03 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:03 --> URI Class Initialized
INFO - 2023-10-31 17:43:03 --> Router Class Initialized
INFO - 2023-10-31 17:43:03 --> Output Class Initialized
INFO - 2023-10-31 17:43:03 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:03 --> Input Class Initialized
INFO - 2023-10-31 17:43:03 --> Language Class Initialized
INFO - 2023-10-31 17:43:03 --> Loader Class Initialized
INFO - 2023-10-31 17:43:03 --> Helper loaded: url_helper
INFO - 2023-10-31 17:43:03 --> Helper loaded: file_helper
INFO - 2023-10-31 17:43:03 --> Database Driver Class Initialized
INFO - 2023-10-31 17:43:03 --> Email Class Initialized
DEBUG - 2023-10-31 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:43:03 --> Controller Class Initialized
INFO - 2023-10-31 17:43:03 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:43:03 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:43:03 --> Model "Home_model" initialized
INFO - 2023-10-31 17:43:03 --> Helper loaded: download_helper
INFO - 2023-10-31 17:43:03 --> Helper loaded: form_helper
INFO - 2023-10-31 17:43:03 --> Form Validation Class Initialized
INFO - 2023-10-31 17:43:03 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:43:03 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:43:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:43:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:43:03 --> Final output sent to browser
DEBUG - 2023-10-31 17:43:03 --> Total execution time: 0.3365
INFO - 2023-10-31 17:43:05 --> Config Class Initialized
INFO - 2023-10-31 17:43:05 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:05 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:05 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:05 --> URI Class Initialized
INFO - 2023-10-31 17:43:05 --> Router Class Initialized
INFO - 2023-10-31 17:43:05 --> Output Class Initialized
INFO - 2023-10-31 17:43:05 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:05 --> Input Class Initialized
INFO - 2023-10-31 17:43:05 --> Language Class Initialized
ERROR - 2023-10-31 17:43:05 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:43:05 --> Config Class Initialized
INFO - 2023-10-31 17:43:05 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:05 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:05 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:05 --> URI Class Initialized
INFO - 2023-10-31 17:43:05 --> Router Class Initialized
INFO - 2023-10-31 17:43:05 --> Output Class Initialized
INFO - 2023-10-31 17:43:05 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:05 --> Input Class Initialized
INFO - 2023-10-31 17:43:05 --> Language Class Initialized
INFO - 2023-10-31 17:43:26 --> Config Class Initialized
INFO - 2023-10-31 17:43:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:26 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:26 --> URI Class Initialized
INFO - 2023-10-31 17:43:26 --> Router Class Initialized
INFO - 2023-10-31 17:43:26 --> Output Class Initialized
INFO - 2023-10-31 17:43:26 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:26 --> Input Class Initialized
INFO - 2023-10-31 17:43:26 --> Language Class Initialized
INFO - 2023-10-31 17:43:26 --> Loader Class Initialized
INFO - 2023-10-31 17:43:26 --> Helper loaded: url_helper
INFO - 2023-10-31 17:43:26 --> Helper loaded: file_helper
INFO - 2023-10-31 17:43:26 --> Database Driver Class Initialized
INFO - 2023-10-31 17:43:26 --> Email Class Initialized
DEBUG - 2023-10-31 17:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:43:26 --> Controller Class Initialized
INFO - 2023-10-31 17:43:26 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:43:26 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:43:26 --> Model "Home_model" initialized
INFO - 2023-10-31 17:43:26 --> Helper loaded: download_helper
INFO - 2023-10-31 17:43:26 --> Helper loaded: form_helper
INFO - 2023-10-31 17:43:26 --> Form Validation Class Initialized
INFO - 2023-10-31 17:43:26 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:43:26 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:43:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:43:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:43:26 --> Final output sent to browser
DEBUG - 2023-10-31 17:43:26 --> Total execution time: 0.2475
INFO - 2023-10-31 17:43:28 --> Config Class Initialized
INFO - 2023-10-31 17:43:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:28 --> URI Class Initialized
INFO - 2023-10-31 17:43:28 --> Router Class Initialized
INFO - 2023-10-31 17:43:28 --> Output Class Initialized
INFO - 2023-10-31 17:43:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:28 --> Input Class Initialized
INFO - 2023-10-31 17:43:28 --> Language Class Initialized
ERROR - 2023-10-31 17:43:28 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:43:28 --> Config Class Initialized
INFO - 2023-10-31 17:43:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:28 --> URI Class Initialized
INFO - 2023-10-31 17:43:28 --> Router Class Initialized
INFO - 2023-10-31 17:43:28 --> Output Class Initialized
INFO - 2023-10-31 17:43:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:29 --> Input Class Initialized
INFO - 2023-10-31 17:43:29 --> Language Class Initialized
ERROR - 2023-10-31 17:43:29 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:43:29 --> Config Class Initialized
INFO - 2023-10-31 17:43:29 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:29 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:29 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:29 --> URI Class Initialized
INFO - 2023-10-31 17:43:29 --> Router Class Initialized
INFO - 2023-10-31 17:43:29 --> Output Class Initialized
INFO - 2023-10-31 17:43:29 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:29 --> Input Class Initialized
INFO - 2023-10-31 17:43:29 --> Language Class Initialized
ERROR - 2023-10-31 17:43:29 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:43:52 --> Config Class Initialized
INFO - 2023-10-31 17:43:52 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:43:52 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:43:52 --> Utf8 Class Initialized
INFO - 2023-10-31 17:43:52 --> URI Class Initialized
INFO - 2023-10-31 17:43:52 --> Router Class Initialized
INFO - 2023-10-31 17:43:52 --> Output Class Initialized
INFO - 2023-10-31 17:43:52 --> Security Class Initialized
DEBUG - 2023-10-31 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:43:52 --> Input Class Initialized
INFO - 2023-10-31 17:43:52 --> Language Class Initialized
INFO - 2023-10-31 17:43:52 --> Loader Class Initialized
INFO - 2023-10-31 17:43:52 --> Helper loaded: url_helper
INFO - 2023-10-31 17:43:52 --> Helper loaded: file_helper
INFO - 2023-10-31 17:43:52 --> Database Driver Class Initialized
INFO - 2023-10-31 17:43:52 --> Email Class Initialized
DEBUG - 2023-10-31 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:43:52 --> Controller Class Initialized
INFO - 2023-10-31 17:43:52 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:43:52 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:43:52 --> Model "Home_model" initialized
INFO - 2023-10-31 17:43:52 --> Helper loaded: download_helper
INFO - 2023-10-31 17:43:52 --> Helper loaded: form_helper
INFO - 2023-10-31 17:43:52 --> Form Validation Class Initialized
INFO - 2023-10-31 17:43:52 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:43:52 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:43:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:43:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:43:52 --> Final output sent to browser
DEBUG - 2023-10-31 17:43:52 --> Total execution time: 0.2678
INFO - 2023-10-31 17:44:16 --> Config Class Initialized
INFO - 2023-10-31 17:44:16 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:16 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:16 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:16 --> URI Class Initialized
INFO - 2023-10-31 17:44:16 --> Router Class Initialized
INFO - 2023-10-31 17:44:16 --> Output Class Initialized
INFO - 2023-10-31 17:44:16 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:16 --> Input Class Initialized
INFO - 2023-10-31 17:44:16 --> Language Class Initialized
ERROR - 2023-10-31 17:44:16 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:16 --> Config Class Initialized
INFO - 2023-10-31 17:44:16 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:16 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:16 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:16 --> URI Class Initialized
INFO - 2023-10-31 17:44:16 --> Router Class Initialized
INFO - 2023-10-31 17:44:16 --> Output Class Initialized
INFO - 2023-10-31 17:44:16 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:16 --> Input Class Initialized
INFO - 2023-10-31 17:44:16 --> Language Class Initialized
ERROR - 2023-10-31 17:44:16 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:17 --> Config Class Initialized
INFO - 2023-10-31 17:44:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:17 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:17 --> URI Class Initialized
INFO - 2023-10-31 17:44:17 --> Router Class Initialized
INFO - 2023-10-31 17:44:17 --> Output Class Initialized
INFO - 2023-10-31 17:44:17 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:17 --> Input Class Initialized
INFO - 2023-10-31 17:44:17 --> Language Class Initialized
ERROR - 2023-10-31 17:44:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:17 --> Config Class Initialized
INFO - 2023-10-31 17:44:17 --> Config Class Initialized
INFO - 2023-10-31 17:44:17 --> Config Class Initialized
INFO - 2023-10-31 17:44:17 --> Hooks Class Initialized
INFO - 2023-10-31 17:44:17 --> Hooks Class Initialized
INFO - 2023-10-31 17:44:17 --> Config Class Initialized
DEBUG - 2023-10-31 17:44:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:17 --> Hooks Class Initialized
INFO - 2023-10-31 17:44:17 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:17 --> UTF-8 Support Enabled
DEBUG - 2023-10-31 17:44:17 --> UTF-8 Support Enabled
DEBUG - 2023-10-31 17:44:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:17 --> URI Class Initialized
INFO - 2023-10-31 17:44:17 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:17 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:17 --> URI Class Initialized
INFO - 2023-10-31 17:44:17 --> Router Class Initialized
INFO - 2023-10-31 17:44:17 --> Output Class Initialized
INFO - 2023-10-31 17:44:17 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:17 --> Input Class Initialized
INFO - 2023-10-31 17:44:17 --> Language Class Initialized
ERROR - 2023-10-31 17:44:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:17 --> Router Class Initialized
INFO - 2023-10-31 17:44:18 --> URI Class Initialized
INFO - 2023-10-31 17:44:18 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:18 --> Output Class Initialized
INFO - 2023-10-31 17:44:18 --> URI Class Initialized
INFO - 2023-10-31 17:44:18 --> Router Class Initialized
INFO - 2023-10-31 17:44:18 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:18 --> Input Class Initialized
INFO - 2023-10-31 17:44:18 --> Language Class Initialized
ERROR - 2023-10-31 17:44:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:18 --> Router Class Initialized
INFO - 2023-10-31 17:44:18 --> Output Class Initialized
INFO - 2023-10-31 17:44:18 --> Output Class Initialized
INFO - 2023-10-31 17:44:18 --> Security Class Initialized
INFO - 2023-10-31 17:44:18 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-31 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:18 --> Input Class Initialized
INFO - 2023-10-31 17:44:18 --> Input Class Initialized
INFO - 2023-10-31 17:44:18 --> Language Class Initialized
INFO - 2023-10-31 17:44:18 --> Language Class Initialized
ERROR - 2023-10-31 17:44:18 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-31 17:44:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:45 --> Config Class Initialized
INFO - 2023-10-31 17:44:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:45 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:45 --> URI Class Initialized
INFO - 2023-10-31 17:44:45 --> Router Class Initialized
INFO - 2023-10-31 17:44:45 --> Output Class Initialized
INFO - 2023-10-31 17:44:45 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:45 --> Input Class Initialized
INFO - 2023-10-31 17:44:46 --> Language Class Initialized
INFO - 2023-10-31 17:44:46 --> Loader Class Initialized
INFO - 2023-10-31 17:44:46 --> Helper loaded: url_helper
INFO - 2023-10-31 17:44:46 --> Helper loaded: file_helper
INFO - 2023-10-31 17:44:46 --> Database Driver Class Initialized
INFO - 2023-10-31 17:44:46 --> Email Class Initialized
DEBUG - 2023-10-31 17:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:44:46 --> Controller Class Initialized
INFO - 2023-10-31 17:44:46 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:44:46 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:44:46 --> Model "Home_model" initialized
INFO - 2023-10-31 17:44:46 --> Helper loaded: download_helper
INFO - 2023-10-31 17:44:46 --> Helper loaded: form_helper
INFO - 2023-10-31 17:44:46 --> Form Validation Class Initialized
INFO - 2023-10-31 17:44:46 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:44:46 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:44:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:44:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:44:46 --> Final output sent to browser
DEBUG - 2023-10-31 17:44:46 --> Total execution time: 0.1307
INFO - 2023-10-31 17:44:47 --> Config Class Initialized
INFO - 2023-10-31 17:44:47 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:47 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:47 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:47 --> URI Class Initialized
INFO - 2023-10-31 17:44:47 --> Router Class Initialized
INFO - 2023-10-31 17:44:47 --> Output Class Initialized
INFO - 2023-10-31 17:44:47 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:47 --> Input Class Initialized
INFO - 2023-10-31 17:44:47 --> Language Class Initialized
ERROR - 2023-10-31 17:44:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:49 --> Config Class Initialized
INFO - 2023-10-31 17:44:49 --> Config Class Initialized
INFO - 2023-10-31 17:44:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:49 --> Hooks Class Initialized
INFO - 2023-10-31 17:44:49 --> Utf8 Class Initialized
DEBUG - 2023-10-31 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:49 --> URI Class Initialized
INFO - 2023-10-31 17:44:49 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:49 --> Router Class Initialized
INFO - 2023-10-31 17:44:49 --> URI Class Initialized
INFO - 2023-10-31 17:44:49 --> Output Class Initialized
INFO - 2023-10-31 17:44:49 --> Router Class Initialized
INFO - 2023-10-31 17:44:49 --> Security Class Initialized
INFO - 2023-10-31 17:44:49 --> Output Class Initialized
DEBUG - 2023-10-31 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:49 --> Security Class Initialized
INFO - 2023-10-31 17:44:49 --> Input Class Initialized
DEBUG - 2023-10-31 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:49 --> Language Class Initialized
INFO - 2023-10-31 17:44:49 --> Input Class Initialized
ERROR - 2023-10-31 17:44:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:49 --> Language Class Initialized
ERROR - 2023-10-31 17:44:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:49 --> Config Class Initialized
INFO - 2023-10-31 17:44:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:49 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:49 --> URI Class Initialized
INFO - 2023-10-31 17:44:49 --> Router Class Initialized
INFO - 2023-10-31 17:44:49 --> Output Class Initialized
INFO - 2023-10-31 17:44:49 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:49 --> Input Class Initialized
INFO - 2023-10-31 17:44:49 --> Language Class Initialized
ERROR - 2023-10-31 17:44:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:49 --> Config Class Initialized
INFO - 2023-10-31 17:44:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:49 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:49 --> URI Class Initialized
INFO - 2023-10-31 17:44:49 --> Router Class Initialized
INFO - 2023-10-31 17:44:49 --> Output Class Initialized
INFO - 2023-10-31 17:44:49 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:49 --> Input Class Initialized
INFO - 2023-10-31 17:44:49 --> Language Class Initialized
ERROR - 2023-10-31 17:44:49 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:50 --> Config Class Initialized
INFO - 2023-10-31 17:44:50 --> Config Class Initialized
INFO - 2023-10-31 17:44:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:50 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:50 --> URI Class Initialized
INFO - 2023-10-31 17:44:50 --> Router Class Initialized
INFO - 2023-10-31 17:44:50 --> Output Class Initialized
INFO - 2023-10-31 17:44:50 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:50 --> Input Class Initialized
INFO - 2023-10-31 17:44:50 --> Language Class Initialized
ERROR - 2023-10-31 17:44:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:44:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:44:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:44:50 --> Utf8 Class Initialized
INFO - 2023-10-31 17:44:50 --> URI Class Initialized
INFO - 2023-10-31 17:44:50 --> Router Class Initialized
INFO - 2023-10-31 17:44:50 --> Output Class Initialized
INFO - 2023-10-31 17:44:50 --> Security Class Initialized
DEBUG - 2023-10-31 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:44:50 --> Input Class Initialized
INFO - 2023-10-31 17:44:50 --> Language Class Initialized
ERROR - 2023-10-31 17:44:50 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:45:20 --> Config Class Initialized
INFO - 2023-10-31 17:45:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:45:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:45:20 --> Utf8 Class Initialized
INFO - 2023-10-31 17:45:20 --> URI Class Initialized
INFO - 2023-10-31 17:45:20 --> Router Class Initialized
INFO - 2023-10-31 17:45:20 --> Output Class Initialized
INFO - 2023-10-31 17:45:20 --> Security Class Initialized
DEBUG - 2023-10-31 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:45:20 --> Input Class Initialized
INFO - 2023-10-31 17:45:20 --> Language Class Initialized
INFO - 2023-10-31 17:45:20 --> Loader Class Initialized
INFO - 2023-10-31 17:45:20 --> Helper loaded: url_helper
INFO - 2023-10-31 17:45:20 --> Helper loaded: file_helper
INFO - 2023-10-31 17:45:20 --> Database Driver Class Initialized
INFO - 2023-10-31 17:45:20 --> Email Class Initialized
DEBUG - 2023-10-31 17:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:45:20 --> Controller Class Initialized
INFO - 2023-10-31 17:45:20 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:45:20 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:45:20 --> Model "Home_model" initialized
INFO - 2023-10-31 17:45:20 --> Helper loaded: download_helper
INFO - 2023-10-31 17:45:20 --> Helper loaded: form_helper
INFO - 2023-10-31 17:45:20 --> Form Validation Class Initialized
INFO - 2023-10-31 17:45:20 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:45:20 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:45:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:45:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-10-31 17:45:20 --> Final output sent to browser
DEBUG - 2023-10-31 17:45:20 --> Total execution time: 0.2476
INFO - 2023-10-31 17:45:23 --> Config Class Initialized
INFO - 2023-10-31 17:45:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:45:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:45:23 --> Utf8 Class Initialized
INFO - 2023-10-31 17:45:23 --> URI Class Initialized
INFO - 2023-10-31 17:45:23 --> Router Class Initialized
INFO - 2023-10-31 17:45:23 --> Output Class Initialized
INFO - 2023-10-31 17:45:23 --> Security Class Initialized
DEBUG - 2023-10-31 17:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:45:23 --> Input Class Initialized
INFO - 2023-10-31 17:45:23 --> Language Class Initialized
ERROR - 2023-10-31 17:45:23 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:45:23 --> Config Class Initialized
INFO - 2023-10-31 17:45:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:45:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:45:23 --> Utf8 Class Initialized
INFO - 2023-10-31 17:45:24 --> URI Class Initialized
INFO - 2023-10-31 17:45:27 --> Router Class Initialized
INFO - 2023-10-31 17:45:27 --> Output Class Initialized
INFO - 2023-10-31 17:45:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:45:27 --> Input Class Initialized
INFO - 2023-10-31 17:45:27 --> Language Class Initialized
ERROR - 2023-10-31 17:45:27 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:45:27 --> Config Class Initialized
INFO - 2023-10-31 17:45:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:45:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:45:27 --> Utf8 Class Initialized
INFO - 2023-10-31 17:45:27 --> URI Class Initialized
INFO - 2023-10-31 17:45:27 --> Router Class Initialized
INFO - 2023-10-31 17:45:27 --> Output Class Initialized
INFO - 2023-10-31 17:45:27 --> Security Class Initialized
DEBUG - 2023-10-31 17:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:45:27 --> Input Class Initialized
INFO - 2023-10-31 17:45:27 --> Language Class Initialized
ERROR - 2023-10-31 17:45:27 --> 404 Page Not Found: Assets/home
INFO - 2023-10-31 17:52:10 --> Config Class Initialized
INFO - 2023-10-31 17:52:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:52:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:52:10 --> Utf8 Class Initialized
INFO - 2023-10-31 17:52:10 --> URI Class Initialized
INFO - 2023-10-31 17:52:10 --> Router Class Initialized
INFO - 2023-10-31 17:52:10 --> Output Class Initialized
INFO - 2023-10-31 17:52:10 --> Security Class Initialized
DEBUG - 2023-10-31 17:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:52:10 --> Input Class Initialized
INFO - 2023-10-31 17:52:10 --> Language Class Initialized
INFO - 2023-10-31 17:52:10 --> Loader Class Initialized
INFO - 2023-10-31 17:52:10 --> Helper loaded: url_helper
INFO - 2023-10-31 17:52:10 --> Helper loaded: file_helper
INFO - 2023-10-31 17:52:10 --> Database Driver Class Initialized
INFO - 2023-10-31 17:52:10 --> Email Class Initialized
DEBUG - 2023-10-31 17:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:52:10 --> Controller Class Initialized
INFO - 2023-10-31 17:52:11 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:52:11 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:52:11 --> Model "Home_model" initialized
INFO - 2023-10-31 17:52:11 --> Helper loaded: download_helper
INFO - 2023-10-31 17:52:11 --> Helper loaded: form_helper
INFO - 2023-10-31 17:52:11 --> Form Validation Class Initialized
INFO - 2023-10-31 17:52:11 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:52:11 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:52:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:52:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-10-31 17:52:11 --> Final output sent to browser
DEBUG - 2023-10-31 17:52:11 --> Total execution time: 0.0877
INFO - 2023-10-31 17:52:19 --> Config Class Initialized
INFO - 2023-10-31 17:52:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:52:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:52:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:52:19 --> URI Class Initialized
INFO - 2023-10-31 17:52:19 --> Router Class Initialized
INFO - 2023-10-31 17:52:19 --> Output Class Initialized
INFO - 2023-10-31 17:52:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:52:19 --> Input Class Initialized
INFO - 2023-10-31 17:52:19 --> Language Class Initialized
INFO - 2023-10-31 17:52:19 --> Loader Class Initialized
INFO - 2023-10-31 17:52:19 --> Helper loaded: url_helper
INFO - 2023-10-31 17:52:19 --> Helper loaded: file_helper
INFO - 2023-10-31 17:52:19 --> Database Driver Class Initialized
INFO - 2023-10-31 17:52:19 --> Email Class Initialized
DEBUG - 2023-10-31 17:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:52:19 --> Controller Class Initialized
INFO - 2023-10-31 17:52:19 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:52:19 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:52:19 --> Model "Home_model" initialized
INFO - 2023-10-31 17:52:19 --> Helper loaded: download_helper
INFO - 2023-10-31 17:52:19 --> Helper loaded: form_helper
INFO - 2023-10-31 17:52:19 --> Form Validation Class Initialized
INFO - 2023-10-31 17:52:19 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:52:19 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:52:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:52:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:52:19 --> Final output sent to browser
DEBUG - 2023-10-31 17:52:19 --> Total execution time: 0.1351
INFO - 2023-10-31 17:52:32 --> Config Class Initialized
INFO - 2023-10-31 17:52:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:52:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:52:32 --> Utf8 Class Initialized
INFO - 2023-10-31 17:52:32 --> URI Class Initialized
INFO - 2023-10-31 17:52:32 --> Router Class Initialized
INFO - 2023-10-31 17:52:32 --> Output Class Initialized
INFO - 2023-10-31 17:52:32 --> Security Class Initialized
DEBUG - 2023-10-31 17:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:52:32 --> Input Class Initialized
INFO - 2023-10-31 17:52:32 --> Language Class Initialized
INFO - 2023-10-31 17:52:32 --> Loader Class Initialized
INFO - 2023-10-31 17:52:32 --> Helper loaded: url_helper
INFO - 2023-10-31 17:52:32 --> Helper loaded: file_helper
INFO - 2023-10-31 17:52:32 --> Database Driver Class Initialized
INFO - 2023-10-31 17:52:32 --> Email Class Initialized
DEBUG - 2023-10-31 17:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:52:32 --> Controller Class Initialized
INFO - 2023-10-31 17:52:32 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:52:32 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:52:32 --> Model "Home_model" initialized
INFO - 2023-10-31 17:52:32 --> Helper loaded: download_helper
INFO - 2023-10-31 17:52:32 --> Helper loaded: form_helper
INFO - 2023-10-31 17:52:32 --> Form Validation Class Initialized
INFO - 2023-10-31 17:52:32 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:52:32 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:52:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:52:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:52:32 --> Final output sent to browser
DEBUG - 2023-10-31 17:52:32 --> Total execution time: 0.1419
INFO - 2023-10-31 17:54:19 --> Config Class Initialized
INFO - 2023-10-31 17:54:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:54:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:54:19 --> Utf8 Class Initialized
INFO - 2023-10-31 17:54:19 --> URI Class Initialized
INFO - 2023-10-31 17:54:19 --> Router Class Initialized
INFO - 2023-10-31 17:54:19 --> Output Class Initialized
INFO - 2023-10-31 17:54:19 --> Security Class Initialized
DEBUG - 2023-10-31 17:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:54:19 --> Input Class Initialized
INFO - 2023-10-31 17:54:19 --> Language Class Initialized
INFO - 2023-10-31 17:54:19 --> Loader Class Initialized
INFO - 2023-10-31 17:54:19 --> Helper loaded: url_helper
INFO - 2023-10-31 17:54:19 --> Helper loaded: file_helper
INFO - 2023-10-31 17:54:19 --> Database Driver Class Initialized
INFO - 2023-10-31 17:54:19 --> Email Class Initialized
DEBUG - 2023-10-31 17:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:54:19 --> Controller Class Initialized
INFO - 2023-10-31 17:54:19 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:54:19 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:54:19 --> Model "Home_model" initialized
INFO - 2023-10-31 17:54:19 --> Helper loaded: download_helper
INFO - 2023-10-31 17:54:19 --> Helper loaded: form_helper
INFO - 2023-10-31 17:54:19 --> Form Validation Class Initialized
INFO - 2023-10-31 17:54:19 --> Helper loaded: custom_helper
INFO - 2023-10-31 17:54:19 --> Model "Social_media_model" initialized
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 39
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 65
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
ERROR - 2023-10-31 17:54:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 135
INFO - 2023-10-31 17:54:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-10-31 17:54:19 --> Final output sent to browser
DEBUG - 2023-10-31 17:54:19 --> Total execution time: 0.3286
INFO - 2023-10-31 17:54:23 --> Config Class Initialized
INFO - 2023-10-31 17:54:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:54:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:54:23 --> Utf8 Class Initialized
INFO - 2023-10-31 17:54:23 --> URI Class Initialized
INFO - 2023-10-31 17:54:23 --> Router Class Initialized
INFO - 2023-10-31 17:54:23 --> Output Class Initialized
INFO - 2023-10-31 17:54:23 --> Security Class Initialized
DEBUG - 2023-10-31 17:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:54:23 --> Input Class Initialized
INFO - 2023-10-31 17:54:23 --> Language Class Initialized
INFO - 2023-10-31 17:54:23 --> Loader Class Initialized
INFO - 2023-10-31 17:54:23 --> Helper loaded: url_helper
INFO - 2023-10-31 17:54:23 --> Helper loaded: file_helper
INFO - 2023-10-31 17:54:23 --> Database Driver Class Initialized
INFO - 2023-10-31 17:54:23 --> Email Class Initialized
DEBUG - 2023-10-31 17:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 17:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:54:23 --> Controller Class Initialized
INFO - 2023-10-31 17:54:23 --> Model "Contact_model" initialized
INFO - 2023-10-31 17:54:23 --> Model "CareerFormModel" initialized
INFO - 2023-10-31 17:54:23 --> Model "Home_model" initialized
INFO - 2023-10-31 17:54:23 --> Helper loaded: download_helper
INFO - 2023-10-31 17:54:23 --> Helper loaded: form_helper
INFO - 2023-10-31 17:54:23 --> Form Validation Class Initialized
ERROR - 2023-10-31 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 117
ERROR - 2023-10-31 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 118
ERROR - 2023-10-31 17:54:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `services`
WHERE `id` >
AND `status` = '1'
ORDER BY `id` ASC
 LIMIT 5
INFO - 2023-10-31 17:54:23 --> Language file loaded: language/english/db_lang.php
