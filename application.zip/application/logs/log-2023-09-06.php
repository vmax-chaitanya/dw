<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-06 16:44:51 --> Config Class Initialized
INFO - 2023-09-06 16:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-06 16:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-06 16:44:51 --> Utf8 Class Initialized
INFO - 2023-09-06 16:44:51 --> URI Class Initialized
DEBUG - 2023-09-06 16:44:51 --> No URI present. Default controller set.
INFO - 2023-09-06 16:44:51 --> Router Class Initialized
INFO - 2023-09-06 16:44:51 --> Output Class Initialized
INFO - 2023-09-06 16:44:51 --> Security Class Initialized
DEBUG - 2023-09-06 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 16:44:51 --> Input Class Initialized
INFO - 2023-09-06 16:44:51 --> Language Class Initialized
INFO - 2023-09-06 16:44:51 --> Loader Class Initialized
INFO - 2023-09-06 16:44:51 --> Helper loaded: url_helper
INFO - 2023-09-06 16:44:51 --> Helper loaded: file_helper
INFO - 2023-09-06 16:44:51 --> Database Driver Class Initialized
INFO - 2023-09-06 16:44:51 --> Email Class Initialized
DEBUG - 2023-09-06 16:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 16:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 16:44:51 --> Controller Class Initialized
INFO - 2023-09-06 16:44:51 --> Model "Contact_model" initialized
INFO - 2023-09-06 16:44:51 --> Model "Home_model" initialized
INFO - 2023-09-06 16:44:52 --> Helper loaded: download_helper
INFO - 2023-09-06 16:44:52 --> Helper loaded: form_helper
INFO - 2023-09-06 16:44:52 --> Form Validation Class Initialized
INFO - 2023-09-06 16:44:52 --> Helper loaded: custom_helper
INFO - 2023-09-06 16:44:52 --> Model "Social_media_model" initialized
INFO - 2023-09-06 16:44:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 16:44:52 --> Final output sent to browser
DEBUG - 2023-09-06 16:44:52 --> Total execution time: 0.7220
INFO - 2023-09-06 16:44:54 --> Config Class Initialized
INFO - 2023-09-06 16:44:54 --> Hooks Class Initialized
DEBUG - 2023-09-06 16:44:54 --> UTF-8 Support Enabled
INFO - 2023-09-06 16:44:54 --> Utf8 Class Initialized
INFO - 2023-09-06 16:44:54 --> URI Class Initialized
INFO - 2023-09-06 16:44:54 --> Router Class Initialized
INFO - 2023-09-06 16:44:54 --> Output Class Initialized
INFO - 2023-09-06 16:44:54 --> Security Class Initialized
DEBUG - 2023-09-06 16:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 16:44:54 --> Input Class Initialized
INFO - 2023-09-06 16:44:54 --> Language Class Initialized
ERROR - 2023-09-06 16:44:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 17:37:06 --> Config Class Initialized
INFO - 2023-09-06 17:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:06 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:06 --> URI Class Initialized
INFO - 2023-09-06 17:37:06 --> Router Class Initialized
INFO - 2023-09-06 17:37:06 --> Output Class Initialized
INFO - 2023-09-06 17:37:06 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:06 --> Input Class Initialized
INFO - 2023-09-06 17:37:06 --> Language Class Initialized
INFO - 2023-09-06 17:37:06 --> Loader Class Initialized
INFO - 2023-09-06 17:37:06 --> Helper loaded: url_helper
INFO - 2023-09-06 17:37:06 --> Helper loaded: file_helper
INFO - 2023-09-06 17:37:06 --> Database Driver Class Initialized
INFO - 2023-09-06 17:37:06 --> Email Class Initialized
DEBUG - 2023-09-06 17:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:37:06 --> Controller Class Initialized
INFO - 2023-09-06 17:37:06 --> Config Class Initialized
INFO - 2023-09-06 17:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:06 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:06 --> URI Class Initialized
INFO - 2023-09-06 17:37:06 --> Router Class Initialized
INFO - 2023-09-06 17:37:06 --> Output Class Initialized
INFO - 2023-09-06 17:37:06 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:06 --> Input Class Initialized
INFO - 2023-09-06 17:37:06 --> Language Class Initialized
INFO - 2023-09-06 17:37:06 --> Loader Class Initialized
INFO - 2023-09-06 17:37:06 --> Helper loaded: url_helper
INFO - 2023-09-06 17:37:06 --> Helper loaded: file_helper
INFO - 2023-09-06 17:37:06 --> Database Driver Class Initialized
INFO - 2023-09-06 17:37:06 --> Email Class Initialized
DEBUG - 2023-09-06 17:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:37:06 --> Controller Class Initialized
INFO - 2023-09-06 17:37:06 --> Model "User_model" initialized
INFO - 2023-09-06 17:37:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-06 17:37:06 --> Final output sent to browser
DEBUG - 2023-09-06 17:37:06 --> Total execution time: 0.0266
INFO - 2023-09-06 17:37:07 --> Config Class Initialized
INFO - 2023-09-06 17:37:07 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:07 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:07 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:07 --> URI Class Initialized
INFO - 2023-09-06 17:37:07 --> Router Class Initialized
INFO - 2023-09-06 17:37:07 --> Output Class Initialized
INFO - 2023-09-06 17:37:07 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:07 --> Input Class Initialized
INFO - 2023-09-06 17:37:07 --> Language Class Initialized
ERROR - 2023-09-06 17:37:07 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-06 17:37:20 --> Config Class Initialized
INFO - 2023-09-06 17:37:20 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:20 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:20 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:20 --> URI Class Initialized
INFO - 2023-09-06 17:37:20 --> Router Class Initialized
INFO - 2023-09-06 17:37:20 --> Output Class Initialized
INFO - 2023-09-06 17:37:20 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:20 --> Input Class Initialized
INFO - 2023-09-06 17:37:20 --> Language Class Initialized
INFO - 2023-09-06 17:37:20 --> Loader Class Initialized
INFO - 2023-09-06 17:37:20 --> Helper loaded: url_helper
INFO - 2023-09-06 17:37:20 --> Helper loaded: file_helper
INFO - 2023-09-06 17:37:20 --> Database Driver Class Initialized
INFO - 2023-09-06 17:37:20 --> Email Class Initialized
DEBUG - 2023-09-06 17:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:37:20 --> Controller Class Initialized
INFO - 2023-09-06 17:37:20 --> Model "User_model" initialized
INFO - 2023-09-06 17:37:20 --> Config Class Initialized
INFO - 2023-09-06 17:37:20 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:20 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:20 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:20 --> URI Class Initialized
INFO - 2023-09-06 17:37:20 --> Router Class Initialized
INFO - 2023-09-06 17:37:20 --> Output Class Initialized
INFO - 2023-09-06 17:37:20 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:20 --> Input Class Initialized
INFO - 2023-09-06 17:37:20 --> Language Class Initialized
INFO - 2023-09-06 17:37:20 --> Loader Class Initialized
INFO - 2023-09-06 17:37:20 --> Helper loaded: url_helper
INFO - 2023-09-06 17:37:20 --> Helper loaded: file_helper
INFO - 2023-09-06 17:37:20 --> Database Driver Class Initialized
INFO - 2023-09-06 17:37:20 --> Email Class Initialized
DEBUG - 2023-09-06 17:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:37:20 --> Controller Class Initialized
INFO - 2023-09-06 17:37:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-06 17:37:20 --> Final output sent to browser
DEBUG - 2023-09-06 17:37:20 --> Total execution time: 0.0625
INFO - 2023-09-06 17:37:25 --> Config Class Initialized
INFO - 2023-09-06 17:37:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:25 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:25 --> URI Class Initialized
INFO - 2023-09-06 17:37:25 --> Router Class Initialized
INFO - 2023-09-06 17:37:25 --> Output Class Initialized
INFO - 2023-09-06 17:37:25 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:25 --> Input Class Initialized
INFO - 2023-09-06 17:37:25 --> Language Class Initialized
INFO - 2023-09-06 17:37:25 --> Loader Class Initialized
INFO - 2023-09-06 17:37:25 --> Helper loaded: url_helper
INFO - 2023-09-06 17:37:25 --> Helper loaded: file_helper
INFO - 2023-09-06 17:37:25 --> Database Driver Class Initialized
INFO - 2023-09-06 17:37:25 --> Email Class Initialized
DEBUG - 2023-09-06 17:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:37:25 --> Controller Class Initialized
INFO - 2023-09-06 17:37:25 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:37:25 --> Helper loaded: form_helper
INFO - 2023-09-06 17:37:25 --> Form Validation Class Initialized
INFO - 2023-09-06 17:37:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:37:25 --> Final output sent to browser
DEBUG - 2023-09-06 17:37:25 --> Total execution time: 0.2172
INFO - 2023-09-06 17:37:26 --> Config Class Initialized
INFO - 2023-09-06 17:37:26 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:37:26 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:37:26 --> Utf8 Class Initialized
INFO - 2023-09-06 17:37:26 --> URI Class Initialized
INFO - 2023-09-06 17:37:26 --> Router Class Initialized
INFO - 2023-09-06 17:37:26 --> Output Class Initialized
INFO - 2023-09-06 17:37:26 --> Security Class Initialized
DEBUG - 2023-09-06 17:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:37:26 --> Input Class Initialized
INFO - 2023-09-06 17:37:26 --> Language Class Initialized
ERROR - 2023-09-06 17:37:26 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:38:07 --> Config Class Initialized
INFO - 2023-09-06 17:38:07 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:38:07 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:38:07 --> Utf8 Class Initialized
INFO - 2023-09-06 17:38:07 --> URI Class Initialized
INFO - 2023-09-06 17:38:08 --> Router Class Initialized
INFO - 2023-09-06 17:38:08 --> Output Class Initialized
INFO - 2023-09-06 17:38:08 --> Security Class Initialized
DEBUG - 2023-09-06 17:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:38:08 --> Input Class Initialized
INFO - 2023-09-06 17:38:08 --> Language Class Initialized
INFO - 2023-09-06 17:38:08 --> Loader Class Initialized
INFO - 2023-09-06 17:38:08 --> Helper loaded: url_helper
INFO - 2023-09-06 17:38:08 --> Helper loaded: file_helper
INFO - 2023-09-06 17:38:08 --> Database Driver Class Initialized
INFO - 2023-09-06 17:38:08 --> Email Class Initialized
DEBUG - 2023-09-06 17:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:38:08 --> Controller Class Initialized
INFO - 2023-09-06 17:38:08 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:38:08 --> Helper loaded: form_helper
INFO - 2023-09-06 17:38:08 --> Form Validation Class Initialized
INFO - 2023-09-06 17:38:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:38:08 --> Final output sent to browser
DEBUG - 2023-09-06 17:38:08 --> Total execution time: 0.5447
INFO - 2023-09-06 17:38:10 --> Config Class Initialized
INFO - 2023-09-06 17:38:10 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:38:10 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:38:10 --> Utf8 Class Initialized
INFO - 2023-09-06 17:38:10 --> URI Class Initialized
INFO - 2023-09-06 17:38:10 --> Router Class Initialized
INFO - 2023-09-06 17:38:10 --> Output Class Initialized
INFO - 2023-09-06 17:38:10 --> Security Class Initialized
DEBUG - 2023-09-06 17:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:38:10 --> Input Class Initialized
INFO - 2023-09-06 17:38:10 --> Language Class Initialized
ERROR - 2023-09-06 17:38:10 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:38:25 --> Config Class Initialized
INFO - 2023-09-06 17:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:38:25 --> Utf8 Class Initialized
INFO - 2023-09-06 17:38:25 --> URI Class Initialized
INFO - 2023-09-06 17:38:25 --> Router Class Initialized
INFO - 2023-09-06 17:38:25 --> Output Class Initialized
INFO - 2023-09-06 17:38:25 --> Security Class Initialized
DEBUG - 2023-09-06 17:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:38:25 --> Input Class Initialized
INFO - 2023-09-06 17:38:25 --> Language Class Initialized
INFO - 2023-09-06 17:38:25 --> Loader Class Initialized
INFO - 2023-09-06 17:38:25 --> Helper loaded: url_helper
INFO - 2023-09-06 17:38:25 --> Helper loaded: file_helper
INFO - 2023-09-06 17:38:25 --> Database Driver Class Initialized
INFO - 2023-09-06 17:38:25 --> Email Class Initialized
DEBUG - 2023-09-06 17:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:38:25 --> Controller Class Initialized
INFO - 2023-09-06 17:38:25 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:38:25 --> Helper loaded: form_helper
INFO - 2023-09-06 17:38:25 --> Form Validation Class Initialized
INFO - 2023-09-06 17:38:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:38:25 --> Final output sent to browser
DEBUG - 2023-09-06 17:38:25 --> Total execution time: 0.4882
INFO - 2023-09-06 17:38:47 --> Config Class Initialized
INFO - 2023-09-06 17:38:47 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:38:47 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:38:47 --> Utf8 Class Initialized
INFO - 2023-09-06 17:38:47 --> URI Class Initialized
INFO - 2023-09-06 17:38:47 --> Router Class Initialized
INFO - 2023-09-06 17:38:47 --> Output Class Initialized
INFO - 2023-09-06 17:38:47 --> Security Class Initialized
DEBUG - 2023-09-06 17:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:38:47 --> Input Class Initialized
INFO - 2023-09-06 17:38:47 --> Language Class Initialized
INFO - 2023-09-06 17:38:47 --> Loader Class Initialized
INFO - 2023-09-06 17:38:47 --> Helper loaded: url_helper
INFO - 2023-09-06 17:38:47 --> Helper loaded: file_helper
INFO - 2023-09-06 17:38:47 --> Database Driver Class Initialized
INFO - 2023-09-06 17:38:47 --> Email Class Initialized
DEBUG - 2023-09-06 17:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:38:47 --> Controller Class Initialized
INFO - 2023-09-06 17:38:47 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:38:47 --> Helper loaded: form_helper
INFO - 2023-09-06 17:38:47 --> Form Validation Class Initialized
INFO - 2023-09-06 17:38:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:38:47 --> Final output sent to browser
DEBUG - 2023-09-06 17:38:47 --> Total execution time: 0.4879
INFO - 2023-09-06 17:39:07 --> Config Class Initialized
INFO - 2023-09-06 17:39:07 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:39:07 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:39:07 --> Utf8 Class Initialized
INFO - 2023-09-06 17:39:07 --> URI Class Initialized
INFO - 2023-09-06 17:39:07 --> Router Class Initialized
INFO - 2023-09-06 17:39:07 --> Output Class Initialized
INFO - 2023-09-06 17:39:07 --> Security Class Initialized
DEBUG - 2023-09-06 17:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:39:07 --> Input Class Initialized
INFO - 2023-09-06 17:39:07 --> Language Class Initialized
INFO - 2023-09-06 17:39:07 --> Loader Class Initialized
INFO - 2023-09-06 17:39:07 --> Helper loaded: url_helper
INFO - 2023-09-06 17:39:07 --> Helper loaded: file_helper
INFO - 2023-09-06 17:39:07 --> Database Driver Class Initialized
INFO - 2023-09-06 17:39:07 --> Email Class Initialized
DEBUG - 2023-09-06 17:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:39:07 --> Controller Class Initialized
INFO - 2023-09-06 17:39:07 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:39:07 --> Helper loaded: form_helper
INFO - 2023-09-06 17:39:07 --> Form Validation Class Initialized
INFO - 2023-09-06 17:39:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:39:07 --> Final output sent to browser
DEBUG - 2023-09-06 17:39:07 --> Total execution time: 0.4665
INFO - 2023-09-06 17:39:25 --> Config Class Initialized
INFO - 2023-09-06 17:39:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:39:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:39:25 --> Utf8 Class Initialized
INFO - 2023-09-06 17:39:25 --> URI Class Initialized
INFO - 2023-09-06 17:39:25 --> Router Class Initialized
INFO - 2023-09-06 17:39:25 --> Output Class Initialized
INFO - 2023-09-06 17:39:25 --> Security Class Initialized
DEBUG - 2023-09-06 17:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:39:25 --> Input Class Initialized
INFO - 2023-09-06 17:39:25 --> Language Class Initialized
INFO - 2023-09-06 17:39:25 --> Loader Class Initialized
INFO - 2023-09-06 17:39:25 --> Helper loaded: url_helper
INFO - 2023-09-06 17:39:25 --> Helper loaded: file_helper
INFO - 2023-09-06 17:39:25 --> Database Driver Class Initialized
INFO - 2023-09-06 17:39:25 --> Email Class Initialized
DEBUG - 2023-09-06 17:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:39:25 --> Controller Class Initialized
INFO - 2023-09-06 17:39:25 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:39:25 --> Helper loaded: form_helper
INFO - 2023-09-06 17:39:25 --> Form Validation Class Initialized
INFO - 2023-09-06 17:39:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:39:25 --> Final output sent to browser
DEBUG - 2023-09-06 17:39:25 --> Total execution time: 0.4305
INFO - 2023-09-06 17:40:14 --> Config Class Initialized
INFO - 2023-09-06 17:40:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:40:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:40:14 --> Utf8 Class Initialized
INFO - 2023-09-06 17:40:14 --> URI Class Initialized
INFO - 2023-09-06 17:40:14 --> Router Class Initialized
INFO - 2023-09-06 17:40:14 --> Output Class Initialized
INFO - 2023-09-06 17:40:14 --> Security Class Initialized
DEBUG - 2023-09-06 17:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:40:14 --> Input Class Initialized
INFO - 2023-09-06 17:40:14 --> Language Class Initialized
INFO - 2023-09-06 17:40:14 --> Loader Class Initialized
INFO - 2023-09-06 17:40:14 --> Helper loaded: url_helper
INFO - 2023-09-06 17:40:14 --> Helper loaded: file_helper
INFO - 2023-09-06 17:40:14 --> Database Driver Class Initialized
INFO - 2023-09-06 17:40:14 --> Email Class Initialized
DEBUG - 2023-09-06 17:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:40:14 --> Controller Class Initialized
INFO - 2023-09-06 17:40:14 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:40:14 --> Helper loaded: form_helper
INFO - 2023-09-06 17:40:14 --> Form Validation Class Initialized
INFO - 2023-09-06 17:40:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:40:14 --> Final output sent to browser
DEBUG - 2023-09-06 17:40:14 --> Total execution time: 0.4886
INFO - 2023-09-06 17:40:16 --> Config Class Initialized
INFO - 2023-09-06 17:40:16 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:40:16 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:40:16 --> Utf8 Class Initialized
INFO - 2023-09-06 17:40:16 --> URI Class Initialized
INFO - 2023-09-06 17:40:16 --> Router Class Initialized
INFO - 2023-09-06 17:40:16 --> Output Class Initialized
INFO - 2023-09-06 17:40:16 --> Security Class Initialized
DEBUG - 2023-09-06 17:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:40:16 --> Input Class Initialized
INFO - 2023-09-06 17:40:16 --> Language Class Initialized
ERROR - 2023-09-06 17:40:16 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:42:26 --> Config Class Initialized
INFO - 2023-09-06 17:42:26 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:42:26 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:42:26 --> Utf8 Class Initialized
INFO - 2023-09-06 17:42:26 --> URI Class Initialized
INFO - 2023-09-06 17:42:26 --> Router Class Initialized
INFO - 2023-09-06 17:42:26 --> Output Class Initialized
INFO - 2023-09-06 17:42:26 --> Security Class Initialized
DEBUG - 2023-09-06 17:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:42:26 --> Input Class Initialized
INFO - 2023-09-06 17:42:26 --> Language Class Initialized
INFO - 2023-09-06 17:42:26 --> Loader Class Initialized
INFO - 2023-09-06 17:42:26 --> Helper loaded: url_helper
INFO - 2023-09-06 17:42:26 --> Helper loaded: file_helper
INFO - 2023-09-06 17:42:26 --> Database Driver Class Initialized
INFO - 2023-09-06 17:42:26 --> Email Class Initialized
DEBUG - 2023-09-06 17:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:42:26 --> Controller Class Initialized
INFO - 2023-09-06 17:42:26 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:42:26 --> Helper loaded: form_helper
INFO - 2023-09-06 17:42:26 --> Form Validation Class Initialized
INFO - 2023-09-06 17:42:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:42:26 --> Final output sent to browser
DEBUG - 2023-09-06 17:42:26 --> Total execution time: 0.4205
INFO - 2023-09-06 17:42:28 --> Config Class Initialized
INFO - 2023-09-06 17:42:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:42:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:42:28 --> Utf8 Class Initialized
INFO - 2023-09-06 17:42:28 --> URI Class Initialized
INFO - 2023-09-06 17:42:28 --> Router Class Initialized
INFO - 2023-09-06 17:42:28 --> Output Class Initialized
INFO - 2023-09-06 17:42:28 --> Security Class Initialized
DEBUG - 2023-09-06 17:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:42:28 --> Input Class Initialized
INFO - 2023-09-06 17:42:28 --> Language Class Initialized
ERROR - 2023-09-06 17:42:28 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:42:53 --> Config Class Initialized
INFO - 2023-09-06 17:42:53 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:42:53 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:42:53 --> Utf8 Class Initialized
INFO - 2023-09-06 17:42:53 --> URI Class Initialized
INFO - 2023-09-06 17:42:53 --> Router Class Initialized
INFO - 2023-09-06 17:42:53 --> Output Class Initialized
INFO - 2023-09-06 17:42:53 --> Security Class Initialized
DEBUG - 2023-09-06 17:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:42:53 --> Input Class Initialized
INFO - 2023-09-06 17:42:53 --> Language Class Initialized
INFO - 2023-09-06 17:42:53 --> Loader Class Initialized
INFO - 2023-09-06 17:42:53 --> Helper loaded: url_helper
INFO - 2023-09-06 17:42:53 --> Helper loaded: file_helper
INFO - 2023-09-06 17:42:53 --> Database Driver Class Initialized
INFO - 2023-09-06 17:42:53 --> Email Class Initialized
DEBUG - 2023-09-06 17:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:42:53 --> Controller Class Initialized
INFO - 2023-09-06 17:42:53 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:42:53 --> Helper loaded: form_helper
INFO - 2023-09-06 17:42:53 --> Form Validation Class Initialized
INFO - 2023-09-06 17:42:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:42:53 --> Final output sent to browser
DEBUG - 2023-09-06 17:42:53 --> Total execution time: 0.3759
INFO - 2023-09-06 17:42:54 --> Config Class Initialized
INFO - 2023-09-06 17:42:54 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:42:54 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:42:54 --> Utf8 Class Initialized
INFO - 2023-09-06 17:42:54 --> URI Class Initialized
INFO - 2023-09-06 17:42:54 --> Router Class Initialized
INFO - 2023-09-06 17:42:54 --> Output Class Initialized
INFO - 2023-09-06 17:42:54 --> Security Class Initialized
DEBUG - 2023-09-06 17:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:42:54 --> Input Class Initialized
INFO - 2023-09-06 17:42:54 --> Language Class Initialized
ERROR - 2023-09-06 17:42:54 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:44:32 --> Config Class Initialized
INFO - 2023-09-06 17:44:32 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:44:32 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:44:32 --> Utf8 Class Initialized
INFO - 2023-09-06 17:44:32 --> URI Class Initialized
INFO - 2023-09-06 17:44:32 --> Router Class Initialized
INFO - 2023-09-06 17:44:32 --> Output Class Initialized
INFO - 2023-09-06 17:44:32 --> Security Class Initialized
DEBUG - 2023-09-06 17:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:44:33 --> Input Class Initialized
INFO - 2023-09-06 17:44:33 --> Language Class Initialized
INFO - 2023-09-06 17:44:33 --> Loader Class Initialized
INFO - 2023-09-06 17:44:33 --> Helper loaded: url_helper
INFO - 2023-09-06 17:44:33 --> Helper loaded: file_helper
INFO - 2023-09-06 17:44:33 --> Database Driver Class Initialized
INFO - 2023-09-06 17:44:33 --> Email Class Initialized
DEBUG - 2023-09-06 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:44:33 --> Controller Class Initialized
INFO - 2023-09-06 17:44:33 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:44:33 --> Helper loaded: form_helper
INFO - 2023-09-06 17:44:33 --> Form Validation Class Initialized
INFO - 2023-09-06 17:44:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:44:33 --> Final output sent to browser
DEBUG - 2023-09-06 17:44:33 --> Total execution time: 0.3262
INFO - 2023-09-06 17:44:34 --> Config Class Initialized
INFO - 2023-09-06 17:44:34 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:44:34 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:44:34 --> Utf8 Class Initialized
INFO - 2023-09-06 17:44:34 --> URI Class Initialized
INFO - 2023-09-06 17:44:34 --> Router Class Initialized
INFO - 2023-09-06 17:44:34 --> Output Class Initialized
INFO - 2023-09-06 17:44:34 --> Security Class Initialized
DEBUG - 2023-09-06 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:44:34 --> Input Class Initialized
INFO - 2023-09-06 17:44:34 --> Language Class Initialized
ERROR - 2023-09-06 17:44:34 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 17:52:47 --> Config Class Initialized
INFO - 2023-09-06 17:52:47 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:52:47 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:52:47 --> Utf8 Class Initialized
INFO - 2023-09-06 17:52:47 --> URI Class Initialized
INFO - 2023-09-06 17:52:47 --> Router Class Initialized
INFO - 2023-09-06 17:52:47 --> Output Class Initialized
INFO - 2023-09-06 17:52:47 --> Security Class Initialized
DEBUG - 2023-09-06 17:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:52:47 --> Input Class Initialized
INFO - 2023-09-06 17:52:47 --> Language Class Initialized
INFO - 2023-09-06 17:52:48 --> Loader Class Initialized
INFO - 2023-09-06 17:52:48 --> Helper loaded: url_helper
INFO - 2023-09-06 17:52:48 --> Helper loaded: file_helper
INFO - 2023-09-06 17:52:48 --> Database Driver Class Initialized
INFO - 2023-09-06 17:52:48 --> Email Class Initialized
DEBUG - 2023-09-06 17:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 17:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 17:52:48 --> Controller Class Initialized
INFO - 2023-09-06 17:52:48 --> Model "Social_media_model" initialized
INFO - 2023-09-06 17:52:48 --> Helper loaded: form_helper
INFO - 2023-09-06 17:52:48 --> Form Validation Class Initialized
INFO - 2023-09-06 17:52:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 17:52:48 --> Final output sent to browser
DEBUG - 2023-09-06 17:52:48 --> Total execution time: 0.5323
INFO - 2023-09-06 17:52:49 --> Config Class Initialized
INFO - 2023-09-06 17:52:49 --> Hooks Class Initialized
DEBUG - 2023-09-06 17:52:49 --> UTF-8 Support Enabled
INFO - 2023-09-06 17:52:49 --> Utf8 Class Initialized
INFO - 2023-09-06 17:52:49 --> URI Class Initialized
INFO - 2023-09-06 17:52:49 --> Router Class Initialized
INFO - 2023-09-06 17:52:49 --> Output Class Initialized
INFO - 2023-09-06 17:52:49 --> Security Class Initialized
DEBUG - 2023-09-06 17:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 17:52:49 --> Input Class Initialized
INFO - 2023-09-06 17:52:49 --> Language Class Initialized
ERROR - 2023-09-06 17:52:49 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 19:37:00 --> Config Class Initialized
INFO - 2023-09-06 19:37:00 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:37:01 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:37:01 --> Utf8 Class Initialized
INFO - 2023-09-06 19:37:01 --> URI Class Initialized
INFO - 2023-09-06 19:37:01 --> Router Class Initialized
INFO - 2023-09-06 19:37:01 --> Output Class Initialized
INFO - 2023-09-06 19:37:01 --> Security Class Initialized
DEBUG - 2023-09-06 19:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:37:02 --> Input Class Initialized
INFO - 2023-09-06 19:37:02 --> Language Class Initialized
INFO - 2023-09-06 19:37:02 --> Loader Class Initialized
INFO - 2023-09-06 19:37:02 --> Helper loaded: url_helper
INFO - 2023-09-06 19:37:03 --> Helper loaded: file_helper
INFO - 2023-09-06 19:37:04 --> Database Driver Class Initialized
INFO - 2023-09-06 19:37:04 --> Email Class Initialized
DEBUG - 2023-09-06 19:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:37:05 --> Controller Class Initialized
INFO - 2023-09-06 19:37:05 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:37:05 --> Helper loaded: form_helper
INFO - 2023-09-06 19:37:05 --> Form Validation Class Initialized
INFO - 2023-09-06 19:37:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:37:06 --> Final output sent to browser
DEBUG - 2023-09-06 19:37:06 --> Total execution time: 6.0149
INFO - 2023-09-06 19:37:34 --> Config Class Initialized
INFO - 2023-09-06 19:37:34 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:37:34 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:37:34 --> Utf8 Class Initialized
INFO - 2023-09-06 19:37:34 --> URI Class Initialized
INFO - 2023-09-06 19:37:34 --> Router Class Initialized
INFO - 2023-09-06 19:37:34 --> Output Class Initialized
INFO - 2023-09-06 19:37:34 --> Security Class Initialized
DEBUG - 2023-09-06 19:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:37:35 --> Input Class Initialized
INFO - 2023-09-06 19:37:35 --> Language Class Initialized
ERROR - 2023-09-06 19:37:35 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 19:40:56 --> Config Class Initialized
INFO - 2023-09-06 19:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:40:57 --> Utf8 Class Initialized
INFO - 2023-09-06 19:40:57 --> URI Class Initialized
INFO - 2023-09-06 19:40:57 --> Router Class Initialized
INFO - 2023-09-06 19:40:57 --> Output Class Initialized
INFO - 2023-09-06 19:40:57 --> Security Class Initialized
DEBUG - 2023-09-06 19:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:40:57 --> Input Class Initialized
INFO - 2023-09-06 19:40:57 --> Language Class Initialized
INFO - 2023-09-06 19:40:57 --> Loader Class Initialized
INFO - 2023-09-06 19:40:57 --> Helper loaded: url_helper
INFO - 2023-09-06 19:40:57 --> Helper loaded: file_helper
INFO - 2023-09-06 19:40:57 --> Database Driver Class Initialized
INFO - 2023-09-06 19:40:57 --> Email Class Initialized
DEBUG - 2023-09-06 19:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:40:57 --> Controller Class Initialized
INFO - 2023-09-06 19:40:57 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:40:57 --> Helper loaded: form_helper
INFO - 2023-09-06 19:40:57 --> Form Validation Class Initialized
INFO - 2023-09-06 19:40:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:40:57 --> Final output sent to browser
DEBUG - 2023-09-06 19:40:57 --> Total execution time: 0.5621
INFO - 2023-09-06 19:41:28 --> Config Class Initialized
INFO - 2023-09-06 19:41:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:41:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:41:28 --> Utf8 Class Initialized
INFO - 2023-09-06 19:41:28 --> URI Class Initialized
INFO - 2023-09-06 19:41:28 --> Router Class Initialized
INFO - 2023-09-06 19:41:28 --> Output Class Initialized
INFO - 2023-09-06 19:41:28 --> Security Class Initialized
DEBUG - 2023-09-06 19:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:41:28 --> Input Class Initialized
INFO - 2023-09-06 19:41:28 --> Language Class Initialized
INFO - 2023-09-06 19:41:28 --> Loader Class Initialized
INFO - 2023-09-06 19:41:28 --> Helper loaded: url_helper
INFO - 2023-09-06 19:41:28 --> Helper loaded: file_helper
INFO - 2023-09-06 19:41:28 --> Database Driver Class Initialized
INFO - 2023-09-06 19:41:28 --> Email Class Initialized
DEBUG - 2023-09-06 19:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:41:28 --> Controller Class Initialized
INFO - 2023-09-06 19:41:28 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:41:28 --> Helper loaded: form_helper
INFO - 2023-09-06 19:41:28 --> Form Validation Class Initialized
INFO - 2023-09-06 19:41:28 --> Config Class Initialized
INFO - 2023-09-06 19:41:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:41:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:41:28 --> Utf8 Class Initialized
INFO - 2023-09-06 19:41:28 --> URI Class Initialized
INFO - 2023-09-06 19:41:28 --> Router Class Initialized
INFO - 2023-09-06 19:41:28 --> Output Class Initialized
INFO - 2023-09-06 19:41:28 --> Security Class Initialized
DEBUG - 2023-09-06 19:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:41:28 --> Input Class Initialized
INFO - 2023-09-06 19:41:28 --> Language Class Initialized
INFO - 2023-09-06 19:41:28 --> Loader Class Initialized
INFO - 2023-09-06 19:41:28 --> Helper loaded: url_helper
INFO - 2023-09-06 19:41:28 --> Helper loaded: file_helper
INFO - 2023-09-06 19:41:28 --> Database Driver Class Initialized
INFO - 2023-09-06 19:41:28 --> Email Class Initialized
DEBUG - 2023-09-06 19:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:41:28 --> Controller Class Initialized
INFO - 2023-09-06 19:41:29 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:41:29 --> Helper loaded: form_helper
INFO - 2023-09-06 19:41:29 --> Form Validation Class Initialized
INFO - 2023-09-06 19:41:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:41:29 --> Final output sent to browser
DEBUG - 2023-09-06 19:41:29 --> Total execution time: 0.6469
INFO - 2023-09-06 19:41:37 --> Config Class Initialized
INFO - 2023-09-06 19:41:37 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:41:37 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:41:37 --> Utf8 Class Initialized
INFO - 2023-09-06 19:41:37 --> URI Class Initialized
INFO - 2023-09-06 19:41:37 --> Router Class Initialized
INFO - 2023-09-06 19:41:38 --> Output Class Initialized
INFO - 2023-09-06 19:41:38 --> Security Class Initialized
DEBUG - 2023-09-06 19:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:41:38 --> Input Class Initialized
INFO - 2023-09-06 19:41:38 --> Language Class Initialized
INFO - 2023-09-06 19:41:38 --> Loader Class Initialized
INFO - 2023-09-06 19:41:38 --> Helper loaded: url_helper
INFO - 2023-09-06 19:41:38 --> Helper loaded: file_helper
INFO - 2023-09-06 19:41:38 --> Database Driver Class Initialized
INFO - 2023-09-06 19:41:38 --> Email Class Initialized
DEBUG - 2023-09-06 19:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:41:38 --> Controller Class Initialized
INFO - 2023-09-06 19:41:38 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:41:38 --> Helper loaded: form_helper
INFO - 2023-09-06 19:41:38 --> Form Validation Class Initialized
INFO - 2023-09-06 19:41:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:41:38 --> Final output sent to browser
DEBUG - 2023-09-06 19:41:39 --> Total execution time: 0.8972
INFO - 2023-09-06 19:43:18 --> Config Class Initialized
INFO - 2023-09-06 19:43:18 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:18 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:18 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:18 --> URI Class Initialized
INFO - 2023-09-06 19:43:18 --> Router Class Initialized
INFO - 2023-09-06 19:43:18 --> Output Class Initialized
INFO - 2023-09-06 19:43:18 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:18 --> Input Class Initialized
INFO - 2023-09-06 19:43:18 --> Language Class Initialized
INFO - 2023-09-06 19:43:18 --> Loader Class Initialized
INFO - 2023-09-06 19:43:18 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:18 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:18 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:18 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:18 --> Controller Class Initialized
INFO - 2023-09-06 19:43:18 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:18 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:18 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:43:19 --> Final output sent to browser
DEBUG - 2023-09-06 19:43:19 --> Total execution time: 0.3387
INFO - 2023-09-06 19:43:37 --> Config Class Initialized
INFO - 2023-09-06 19:43:37 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:37 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:37 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:37 --> URI Class Initialized
INFO - 2023-09-06 19:43:37 --> Router Class Initialized
INFO - 2023-09-06 19:43:37 --> Output Class Initialized
INFO - 2023-09-06 19:43:37 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:37 --> Input Class Initialized
INFO - 2023-09-06 19:43:37 --> Language Class Initialized
INFO - 2023-09-06 19:43:37 --> Loader Class Initialized
INFO - 2023-09-06 19:43:37 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:37 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:37 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:37 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:37 --> Controller Class Initialized
INFO - 2023-09-06 19:43:37 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:37 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:37 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:37 --> Config Class Initialized
INFO - 2023-09-06 19:43:37 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:37 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:37 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:37 --> URI Class Initialized
INFO - 2023-09-06 19:43:37 --> Router Class Initialized
INFO - 2023-09-06 19:43:37 --> Output Class Initialized
INFO - 2023-09-06 19:43:37 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:37 --> Input Class Initialized
INFO - 2023-09-06 19:43:37 --> Language Class Initialized
INFO - 2023-09-06 19:43:37 --> Loader Class Initialized
INFO - 2023-09-06 19:43:37 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:37 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:37 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:37 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:37 --> Controller Class Initialized
INFO - 2023-09-06 19:43:37 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:37 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:37 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:43:37 --> Final output sent to browser
DEBUG - 2023-09-06 19:43:37 --> Total execution time: 0.0834
INFO - 2023-09-06 19:43:47 --> Config Class Initialized
INFO - 2023-09-06 19:43:47 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:47 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:47 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:47 --> URI Class Initialized
INFO - 2023-09-06 19:43:47 --> Router Class Initialized
INFO - 2023-09-06 19:43:47 --> Output Class Initialized
INFO - 2023-09-06 19:43:47 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:47 --> Input Class Initialized
INFO - 2023-09-06 19:43:47 --> Language Class Initialized
INFO - 2023-09-06 19:43:47 --> Loader Class Initialized
INFO - 2023-09-06 19:43:47 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:47 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:47 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:47 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:47 --> Controller Class Initialized
INFO - 2023-09-06 19:43:47 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:47 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:47 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:43:47 --> Final output sent to browser
DEBUG - 2023-09-06 19:43:47 --> Total execution time: 0.1068
INFO - 2023-09-06 19:43:52 --> Config Class Initialized
INFO - 2023-09-06 19:43:52 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:52 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:52 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:52 --> URI Class Initialized
INFO - 2023-09-06 19:43:52 --> Router Class Initialized
INFO - 2023-09-06 19:43:52 --> Output Class Initialized
INFO - 2023-09-06 19:43:52 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:52 --> Input Class Initialized
INFO - 2023-09-06 19:43:52 --> Language Class Initialized
INFO - 2023-09-06 19:43:52 --> Loader Class Initialized
INFO - 2023-09-06 19:43:52 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:52 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:52 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:52 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:52 --> Controller Class Initialized
INFO - 2023-09-06 19:43:52 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:52 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:52 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:52 --> Config Class Initialized
INFO - 2023-09-06 19:43:52 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:43:52 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:43:52 --> Utf8 Class Initialized
INFO - 2023-09-06 19:43:52 --> URI Class Initialized
INFO - 2023-09-06 19:43:52 --> Router Class Initialized
INFO - 2023-09-06 19:43:52 --> Output Class Initialized
INFO - 2023-09-06 19:43:52 --> Security Class Initialized
DEBUG - 2023-09-06 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:43:52 --> Input Class Initialized
INFO - 2023-09-06 19:43:52 --> Language Class Initialized
INFO - 2023-09-06 19:43:52 --> Loader Class Initialized
INFO - 2023-09-06 19:43:52 --> Helper loaded: url_helper
INFO - 2023-09-06 19:43:52 --> Helper loaded: file_helper
INFO - 2023-09-06 19:43:52 --> Database Driver Class Initialized
INFO - 2023-09-06 19:43:52 --> Email Class Initialized
DEBUG - 2023-09-06 19:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:43:52 --> Controller Class Initialized
INFO - 2023-09-06 19:43:52 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:43:52 --> Helper loaded: form_helper
INFO - 2023-09-06 19:43:52 --> Form Validation Class Initialized
INFO - 2023-09-06 19:43:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:43:52 --> Final output sent to browser
DEBUG - 2023-09-06 19:43:52 --> Total execution time: 0.0546
INFO - 2023-09-06 19:44:28 --> Config Class Initialized
INFO - 2023-09-06 19:44:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:44:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:44:28 --> Utf8 Class Initialized
INFO - 2023-09-06 19:44:28 --> URI Class Initialized
INFO - 2023-09-06 19:44:28 --> Router Class Initialized
INFO - 2023-09-06 19:44:29 --> Output Class Initialized
INFO - 2023-09-06 19:44:29 --> Security Class Initialized
DEBUG - 2023-09-06 19:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:44:29 --> Input Class Initialized
INFO - 2023-09-06 19:44:29 --> Language Class Initialized
INFO - 2023-09-06 19:44:29 --> Loader Class Initialized
INFO - 2023-09-06 19:44:29 --> Helper loaded: url_helper
INFO - 2023-09-06 19:44:29 --> Helper loaded: file_helper
INFO - 2023-09-06 19:44:29 --> Database Driver Class Initialized
INFO - 2023-09-06 19:44:29 --> Email Class Initialized
DEBUG - 2023-09-06 19:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:44:29 --> Controller Class Initialized
INFO - 2023-09-06 19:44:29 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:44:29 --> Helper loaded: form_helper
INFO - 2023-09-06 19:44:29 --> Form Validation Class Initialized
INFO - 2023-09-06 19:44:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:44:29 --> Final output sent to browser
DEBUG - 2023-09-06 19:44:30 --> Total execution time: 1.1492
INFO - 2023-09-06 19:44:31 --> Config Class Initialized
INFO - 2023-09-06 19:44:31 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:44:31 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:44:31 --> Utf8 Class Initialized
INFO - 2023-09-06 19:44:31 --> URI Class Initialized
INFO - 2023-09-06 19:44:31 --> Router Class Initialized
INFO - 2023-09-06 19:44:31 --> Output Class Initialized
INFO - 2023-09-06 19:44:31 --> Security Class Initialized
DEBUG - 2023-09-06 19:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:44:31 --> Input Class Initialized
INFO - 2023-09-06 19:44:31 --> Language Class Initialized
ERROR - 2023-09-06 19:44:31 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 19:45:25 --> Config Class Initialized
INFO - 2023-09-06 19:45:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:45:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:45:25 --> Utf8 Class Initialized
INFO - 2023-09-06 19:45:25 --> URI Class Initialized
INFO - 2023-09-06 19:45:25 --> Router Class Initialized
INFO - 2023-09-06 19:45:25 --> Output Class Initialized
INFO - 2023-09-06 19:45:25 --> Security Class Initialized
DEBUG - 2023-09-06 19:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:45:25 --> Input Class Initialized
INFO - 2023-09-06 19:45:26 --> Language Class Initialized
INFO - 2023-09-06 19:45:26 --> Loader Class Initialized
INFO - 2023-09-06 19:45:26 --> Helper loaded: url_helper
INFO - 2023-09-06 19:45:26 --> Helper loaded: file_helper
INFO - 2023-09-06 19:45:26 --> Database Driver Class Initialized
INFO - 2023-09-06 19:45:26 --> Email Class Initialized
DEBUG - 2023-09-06 19:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:45:26 --> Controller Class Initialized
INFO - 2023-09-06 19:45:26 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:45:26 --> Helper loaded: form_helper
INFO - 2023-09-06 19:45:26 --> Form Validation Class Initialized
INFO - 2023-09-06 19:45:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:45:26 --> Final output sent to browser
DEBUG - 2023-09-06 19:45:26 --> Total execution time: 0.9199
INFO - 2023-09-06 19:45:27 --> Config Class Initialized
INFO - 2023-09-06 19:45:27 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:45:27 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:45:27 --> Utf8 Class Initialized
INFO - 2023-09-06 19:45:27 --> URI Class Initialized
INFO - 2023-09-06 19:45:27 --> Router Class Initialized
INFO - 2023-09-06 19:45:28 --> Output Class Initialized
INFO - 2023-09-06 19:45:28 --> Security Class Initialized
DEBUG - 2023-09-06 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:45:28 --> Input Class Initialized
INFO - 2023-09-06 19:45:28 --> Language Class Initialized
ERROR - 2023-09-06 19:45:28 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 19:46:10 --> Config Class Initialized
INFO - 2023-09-06 19:46:10 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:46:10 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:46:10 --> Utf8 Class Initialized
INFO - 2023-09-06 19:46:10 --> URI Class Initialized
INFO - 2023-09-06 19:46:10 --> Router Class Initialized
INFO - 2023-09-06 19:46:10 --> Output Class Initialized
INFO - 2023-09-06 19:46:10 --> Security Class Initialized
DEBUG - 2023-09-06 19:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:46:10 --> Input Class Initialized
INFO - 2023-09-06 19:46:10 --> Language Class Initialized
ERROR - 2023-09-06 19:46:10 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\dw\application\controllers\Admin\Social_media.php 104
INFO - 2023-09-06 19:46:19 --> Config Class Initialized
INFO - 2023-09-06 19:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:46:19 --> Utf8 Class Initialized
INFO - 2023-09-06 19:46:19 --> URI Class Initialized
INFO - 2023-09-06 19:46:19 --> Router Class Initialized
INFO - 2023-09-06 19:46:19 --> Output Class Initialized
INFO - 2023-09-06 19:46:19 --> Security Class Initialized
DEBUG - 2023-09-06 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:46:19 --> Input Class Initialized
INFO - 2023-09-06 19:46:19 --> Language Class Initialized
INFO - 2023-09-06 19:46:19 --> Loader Class Initialized
INFO - 2023-09-06 19:46:19 --> Helper loaded: url_helper
INFO - 2023-09-06 19:46:19 --> Helper loaded: file_helper
INFO - 2023-09-06 19:46:19 --> Database Driver Class Initialized
INFO - 2023-09-06 19:46:19 --> Email Class Initialized
DEBUG - 2023-09-06 19:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:46:19 --> Controller Class Initialized
INFO - 2023-09-06 19:46:19 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:46:19 --> Helper loaded: form_helper
INFO - 2023-09-06 19:46:20 --> Form Validation Class Initialized
INFO - 2023-09-06 19:46:42 --> Config Class Initialized
INFO - 2023-09-06 19:46:42 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:46:42 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:46:42 --> Utf8 Class Initialized
INFO - 2023-09-06 19:46:42 --> URI Class Initialized
INFO - 2023-09-06 19:46:42 --> Router Class Initialized
INFO - 2023-09-06 19:46:42 --> Output Class Initialized
INFO - 2023-09-06 19:46:42 --> Security Class Initialized
DEBUG - 2023-09-06 19:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:46:42 --> Input Class Initialized
INFO - 2023-09-06 19:46:42 --> Language Class Initialized
INFO - 2023-09-06 19:46:43 --> Loader Class Initialized
INFO - 2023-09-06 19:46:43 --> Helper loaded: url_helper
INFO - 2023-09-06 19:46:43 --> Helper loaded: file_helper
INFO - 2023-09-06 19:46:43 --> Database Driver Class Initialized
INFO - 2023-09-06 19:46:43 --> Email Class Initialized
DEBUG - 2023-09-06 19:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:46:43 --> Controller Class Initialized
INFO - 2023-09-06 19:46:43 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:46:43 --> Helper loaded: form_helper
INFO - 2023-09-06 19:46:43 --> Form Validation Class Initialized
INFO - 2023-09-06 19:47:24 --> Config Class Initialized
INFO - 2023-09-06 19:47:24 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:47:24 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:47:24 --> Utf8 Class Initialized
INFO - 2023-09-06 19:47:24 --> URI Class Initialized
INFO - 2023-09-06 19:47:24 --> Router Class Initialized
INFO - 2023-09-06 19:47:24 --> Output Class Initialized
INFO - 2023-09-06 19:47:24 --> Security Class Initialized
DEBUG - 2023-09-06 19:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:47:24 --> Input Class Initialized
INFO - 2023-09-06 19:47:24 --> Language Class Initialized
INFO - 2023-09-06 19:47:24 --> Loader Class Initialized
INFO - 2023-09-06 19:47:24 --> Helper loaded: url_helper
INFO - 2023-09-06 19:47:24 --> Helper loaded: file_helper
INFO - 2023-09-06 19:47:24 --> Database Driver Class Initialized
INFO - 2023-09-06 19:47:24 --> Email Class Initialized
DEBUG - 2023-09-06 19:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:47:24 --> Controller Class Initialized
INFO - 2023-09-06 19:47:24 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:47:24 --> Helper loaded: form_helper
INFO - 2023-09-06 19:47:24 --> Form Validation Class Initialized
INFO - 2023-09-06 19:48:54 --> Config Class Initialized
INFO - 2023-09-06 19:48:54 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:48:54 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:48:55 --> Utf8 Class Initialized
INFO - 2023-09-06 19:48:55 --> URI Class Initialized
INFO - 2023-09-06 19:48:55 --> Router Class Initialized
INFO - 2023-09-06 19:48:55 --> Output Class Initialized
INFO - 2023-09-06 19:48:55 --> Security Class Initialized
DEBUG - 2023-09-06 19:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:48:55 --> Input Class Initialized
INFO - 2023-09-06 19:48:55 --> Language Class Initialized
INFO - 2023-09-06 19:48:55 --> Loader Class Initialized
INFO - 2023-09-06 19:48:55 --> Helper loaded: url_helper
INFO - 2023-09-06 19:48:55 --> Helper loaded: file_helper
INFO - 2023-09-06 19:48:55 --> Database Driver Class Initialized
INFO - 2023-09-06 19:48:55 --> Email Class Initialized
DEBUG - 2023-09-06 19:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:48:55 --> Controller Class Initialized
INFO - 2023-09-06 19:48:55 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:48:55 --> Helper loaded: form_helper
INFO - 2023-09-06 19:48:55 --> Form Validation Class Initialized
INFO - 2023-09-06 19:48:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:48:55 --> Final output sent to browser
DEBUG - 2023-09-06 19:48:55 --> Total execution time: 0.5259
INFO - 2023-09-06 19:48:57 --> Config Class Initialized
INFO - 2023-09-06 19:48:57 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:48:57 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:48:57 --> Utf8 Class Initialized
INFO - 2023-09-06 19:48:57 --> URI Class Initialized
INFO - 2023-09-06 19:48:57 --> Router Class Initialized
INFO - 2023-09-06 19:48:57 --> Output Class Initialized
INFO - 2023-09-06 19:48:57 --> Security Class Initialized
DEBUG - 2023-09-06 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:48:57 --> Input Class Initialized
INFO - 2023-09-06 19:48:57 --> Language Class Initialized
INFO - 2023-09-06 19:48:57 --> Loader Class Initialized
INFO - 2023-09-06 19:48:57 --> Helper loaded: url_helper
INFO - 2023-09-06 19:48:57 --> Helper loaded: file_helper
INFO - 2023-09-06 19:48:57 --> Database Driver Class Initialized
INFO - 2023-09-06 19:48:58 --> Email Class Initialized
DEBUG - 2023-09-06 19:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:48:58 --> Controller Class Initialized
INFO - 2023-09-06 19:48:58 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:48:58 --> Helper loaded: form_helper
INFO - 2023-09-06 19:48:58 --> Form Validation Class Initialized
INFO - 2023-09-06 19:48:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:48:58 --> Final output sent to browser
DEBUG - 2023-09-06 19:48:58 --> Total execution time: 0.3893
INFO - 2023-09-06 19:48:59 --> Config Class Initialized
INFO - 2023-09-06 19:48:59 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:48:59 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:48:59 --> Utf8 Class Initialized
INFO - 2023-09-06 19:48:59 --> URI Class Initialized
INFO - 2023-09-06 19:48:59 --> Router Class Initialized
INFO - 2023-09-06 19:48:59 --> Output Class Initialized
INFO - 2023-09-06 19:48:59 --> Security Class Initialized
DEBUG - 2023-09-06 19:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:48:59 --> Input Class Initialized
INFO - 2023-09-06 19:48:59 --> Language Class Initialized
ERROR - 2023-09-06 19:48:59 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-06 19:49:13 --> Config Class Initialized
INFO - 2023-09-06 19:49:13 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:49:13 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:49:13 --> Utf8 Class Initialized
INFO - 2023-09-06 19:49:13 --> URI Class Initialized
INFO - 2023-09-06 19:49:13 --> Router Class Initialized
INFO - 2023-09-06 19:49:13 --> Output Class Initialized
INFO - 2023-09-06 19:49:13 --> Security Class Initialized
DEBUG - 2023-09-06 19:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:49:13 --> Input Class Initialized
INFO - 2023-09-06 19:49:13 --> Language Class Initialized
INFO - 2023-09-06 19:49:13 --> Loader Class Initialized
INFO - 2023-09-06 19:49:13 --> Helper loaded: url_helper
INFO - 2023-09-06 19:49:13 --> Helper loaded: file_helper
INFO - 2023-09-06 19:49:13 --> Database Driver Class Initialized
INFO - 2023-09-06 19:49:13 --> Email Class Initialized
DEBUG - 2023-09-06 19:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:49:13 --> Controller Class Initialized
INFO - 2023-09-06 19:49:13 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:49:13 --> Helper loaded: form_helper
INFO - 2023-09-06 19:49:13 --> Form Validation Class Initialized
INFO - 2023-09-06 19:49:13 --> Config Class Initialized
INFO - 2023-09-06 19:49:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:49:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:49:14 --> Utf8 Class Initialized
INFO - 2023-09-06 19:49:14 --> URI Class Initialized
INFO - 2023-09-06 19:49:14 --> Router Class Initialized
INFO - 2023-09-06 19:49:14 --> Output Class Initialized
INFO - 2023-09-06 19:49:14 --> Security Class Initialized
DEBUG - 2023-09-06 19:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:49:14 --> Input Class Initialized
INFO - 2023-09-06 19:49:14 --> Language Class Initialized
INFO - 2023-09-06 19:49:14 --> Loader Class Initialized
INFO - 2023-09-06 19:49:14 --> Helper loaded: url_helper
INFO - 2023-09-06 19:49:14 --> Helper loaded: file_helper
INFO - 2023-09-06 19:49:14 --> Database Driver Class Initialized
INFO - 2023-09-06 19:49:14 --> Email Class Initialized
DEBUG - 2023-09-06 19:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:49:14 --> Controller Class Initialized
INFO - 2023-09-06 19:49:14 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:49:14 --> Helper loaded: form_helper
INFO - 2023-09-06 19:49:15 --> Form Validation Class Initialized
INFO - 2023-09-06 19:49:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:49:15 --> Final output sent to browser
DEBUG - 2023-09-06 19:49:15 --> Total execution time: 1.1758
INFO - 2023-09-06 19:50:45 --> Config Class Initialized
INFO - 2023-09-06 19:50:45 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:50:45 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:50:45 --> Utf8 Class Initialized
INFO - 2023-09-06 19:50:45 --> URI Class Initialized
INFO - 2023-09-06 19:50:45 --> Router Class Initialized
INFO - 2023-09-06 19:50:45 --> Output Class Initialized
INFO - 2023-09-06 19:50:45 --> Security Class Initialized
DEBUG - 2023-09-06 19:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:50:45 --> Input Class Initialized
INFO - 2023-09-06 19:50:45 --> Language Class Initialized
INFO - 2023-09-06 19:50:45 --> Loader Class Initialized
INFO - 2023-09-06 19:50:46 --> Helper loaded: url_helper
INFO - 2023-09-06 19:50:46 --> Helper loaded: file_helper
INFO - 2023-09-06 19:50:46 --> Database Driver Class Initialized
INFO - 2023-09-06 19:50:46 --> Email Class Initialized
DEBUG - 2023-09-06 19:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:50:46 --> Controller Class Initialized
INFO - 2023-09-06 19:50:46 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:50:46 --> Helper loaded: form_helper
INFO - 2023-09-06 19:50:46 --> Form Validation Class Initialized
INFO - 2023-09-06 19:50:46 --> Config Class Initialized
INFO - 2023-09-06 19:50:46 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:50:46 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:50:46 --> Utf8 Class Initialized
INFO - 2023-09-06 19:50:46 --> URI Class Initialized
INFO - 2023-09-06 19:50:46 --> Router Class Initialized
INFO - 2023-09-06 19:50:46 --> Output Class Initialized
INFO - 2023-09-06 19:50:46 --> Security Class Initialized
DEBUG - 2023-09-06 19:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:50:46 --> Input Class Initialized
INFO - 2023-09-06 19:50:46 --> Language Class Initialized
INFO - 2023-09-06 19:50:46 --> Loader Class Initialized
INFO - 2023-09-06 19:50:46 --> Helper loaded: url_helper
INFO - 2023-09-06 19:50:46 --> Helper loaded: file_helper
INFO - 2023-09-06 19:50:46 --> Database Driver Class Initialized
INFO - 2023-09-06 19:50:46 --> Email Class Initialized
DEBUG - 2023-09-06 19:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:50:46 --> Controller Class Initialized
INFO - 2023-09-06 19:50:46 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:50:46 --> Helper loaded: form_helper
INFO - 2023-09-06 19:50:46 --> Form Validation Class Initialized
INFO - 2023-09-06 19:50:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-06 19:50:46 --> Final output sent to browser
DEBUG - 2023-09-06 19:50:46 --> Total execution time: 0.5011
INFO - 2023-09-06 19:51:23 --> Config Class Initialized
INFO - 2023-09-06 19:51:23 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:23 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:24 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:24 --> URI Class Initialized
DEBUG - 2023-09-06 19:51:24 --> No URI present. Default controller set.
INFO - 2023-09-06 19:51:24 --> Router Class Initialized
INFO - 2023-09-06 19:51:24 --> Output Class Initialized
INFO - 2023-09-06 19:51:24 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:24 --> Input Class Initialized
INFO - 2023-09-06 19:51:24 --> Language Class Initialized
INFO - 2023-09-06 19:51:24 --> Loader Class Initialized
INFO - 2023-09-06 19:51:24 --> Helper loaded: url_helper
INFO - 2023-09-06 19:51:24 --> Helper loaded: file_helper
INFO - 2023-09-06 19:51:24 --> Database Driver Class Initialized
INFO - 2023-09-06 19:51:24 --> Email Class Initialized
DEBUG - 2023-09-06 19:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:51:24 --> Controller Class Initialized
INFO - 2023-09-06 19:51:24 --> Model "Contact_model" initialized
INFO - 2023-09-06 19:51:24 --> Model "Home_model" initialized
INFO - 2023-09-06 19:51:24 --> Helper loaded: download_helper
INFO - 2023-09-06 19:51:24 --> Helper loaded: form_helper
INFO - 2023-09-06 19:51:24 --> Form Validation Class Initialized
INFO - 2023-09-06 19:51:24 --> Helper loaded: custom_helper
INFO - 2023-09-06 19:51:24 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:51:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 19:51:24 --> Final output sent to browser
DEBUG - 2023-09-06 19:51:24 --> Total execution time: 0.7910
INFO - 2023-09-06 19:51:28 --> Config Class Initialized
INFO - 2023-09-06 19:51:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:28 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:28 --> URI Class Initialized
INFO - 2023-09-06 19:51:28 --> Router Class Initialized
INFO - 2023-09-06 19:51:28 --> Output Class Initialized
INFO - 2023-09-06 19:51:28 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:28 --> Input Class Initialized
INFO - 2023-09-06 19:51:28 --> Language Class Initialized
ERROR - 2023-09-06 19:51:28 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 19:51:37 --> Config Class Initialized
INFO - 2023-09-06 19:51:37 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:37 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:37 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:37 --> URI Class Initialized
INFO - 2023-09-06 19:51:37 --> Router Class Initialized
INFO - 2023-09-06 19:51:37 --> Output Class Initialized
INFO - 2023-09-06 19:51:37 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:37 --> Input Class Initialized
INFO - 2023-09-06 19:51:37 --> Language Class Initialized
INFO - 2023-09-06 19:51:37 --> Loader Class Initialized
INFO - 2023-09-06 19:51:37 --> Helper loaded: url_helper
INFO - 2023-09-06 19:51:37 --> Helper loaded: file_helper
INFO - 2023-09-06 19:51:37 --> Database Driver Class Initialized
INFO - 2023-09-06 19:51:38 --> Email Class Initialized
DEBUG - 2023-09-06 19:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:51:38 --> Controller Class Initialized
INFO - 2023-09-06 19:51:38 --> Model "Contact_model" initialized
INFO - 2023-09-06 19:51:38 --> Model "Home_model" initialized
INFO - 2023-09-06 19:51:38 --> Helper loaded: download_helper
INFO - 2023-09-06 19:51:38 --> Helper loaded: form_helper
INFO - 2023-09-06 19:51:38 --> Form Validation Class Initialized
INFO - 2023-09-06 19:51:38 --> Helper loaded: custom_helper
INFO - 2023-09-06 19:51:38 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:51:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 19:51:38 --> Final output sent to browser
DEBUG - 2023-09-06 19:51:38 --> Total execution time: 1.1197
INFO - 2023-09-06 19:51:38 --> Config Class Initialized
INFO - 2023-09-06 19:51:38 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:38 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:38 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:38 --> URI Class Initialized
INFO - 2023-09-06 19:51:38 --> Router Class Initialized
INFO - 2023-09-06 19:51:38 --> Output Class Initialized
INFO - 2023-09-06 19:51:38 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:38 --> Input Class Initialized
INFO - 2023-09-06 19:51:38 --> Language Class Initialized
INFO - 2023-09-06 19:51:38 --> Loader Class Initialized
INFO - 2023-09-06 19:51:38 --> Helper loaded: url_helper
INFO - 2023-09-06 19:51:38 --> Helper loaded: file_helper
INFO - 2023-09-06 19:51:38 --> Database Driver Class Initialized
INFO - 2023-09-06 19:51:38 --> Email Class Initialized
DEBUG - 2023-09-06 19:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:51:38 --> Controller Class Initialized
INFO - 2023-09-06 19:51:38 --> Model "Contact_model" initialized
INFO - 2023-09-06 19:51:38 --> Model "Home_model" initialized
INFO - 2023-09-06 19:51:38 --> Helper loaded: download_helper
INFO - 2023-09-06 19:51:38 --> Helper loaded: form_helper
INFO - 2023-09-06 19:51:38 --> Form Validation Class Initialized
INFO - 2023-09-06 19:51:38 --> Helper loaded: custom_helper
INFO - 2023-09-06 19:51:38 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:51:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-06 19:51:38 --> Final output sent to browser
DEBUG - 2023-09-06 19:51:38 --> Total execution time: 0.7340
INFO - 2023-09-06 19:51:39 --> Config Class Initialized
INFO - 2023-09-06 19:51:39 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:39 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:39 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:39 --> URI Class Initialized
INFO - 2023-09-06 19:51:39 --> Router Class Initialized
INFO - 2023-09-06 19:51:40 --> Output Class Initialized
INFO - 2023-09-06 19:51:40 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:40 --> Input Class Initialized
INFO - 2023-09-06 19:51:40 --> Language Class Initialized
ERROR - 2023-09-06 19:51:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 19:51:41 --> Config Class Initialized
INFO - 2023-09-06 19:51:41 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:41 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:41 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:41 --> URI Class Initialized
INFO - 2023-09-06 19:51:41 --> Router Class Initialized
INFO - 2023-09-06 19:51:41 --> Output Class Initialized
INFO - 2023-09-06 19:51:41 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:41 --> Input Class Initialized
INFO - 2023-09-06 19:51:41 --> Language Class Initialized
INFO - 2023-09-06 19:51:41 --> Loader Class Initialized
INFO - 2023-09-06 19:51:41 --> Helper loaded: url_helper
INFO - 2023-09-06 19:51:41 --> Helper loaded: file_helper
INFO - 2023-09-06 19:51:41 --> Database Driver Class Initialized
INFO - 2023-09-06 19:51:41 --> Email Class Initialized
DEBUG - 2023-09-06 19:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 19:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 19:51:41 --> Controller Class Initialized
INFO - 2023-09-06 19:51:41 --> Model "Contact_model" initialized
INFO - 2023-09-06 19:51:41 --> Model "Home_model" initialized
INFO - 2023-09-06 19:51:41 --> Helper loaded: download_helper
INFO - 2023-09-06 19:51:41 --> Helper loaded: form_helper
INFO - 2023-09-06 19:51:41 --> Form Validation Class Initialized
INFO - 2023-09-06 19:51:42 --> Helper loaded: custom_helper
INFO - 2023-09-06 19:51:42 --> Model "Social_media_model" initialized
INFO - 2023-09-06 19:51:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-06 19:51:42 --> Final output sent to browser
DEBUG - 2023-09-06 19:51:42 --> Total execution time: 0.2241
INFO - 2023-09-06 19:51:42 --> Config Class Initialized
INFO - 2023-09-06 19:51:42 --> Hooks Class Initialized
DEBUG - 2023-09-06 19:51:42 --> UTF-8 Support Enabled
INFO - 2023-09-06 19:51:42 --> Utf8 Class Initialized
INFO - 2023-09-06 19:51:42 --> URI Class Initialized
INFO - 2023-09-06 19:51:42 --> Router Class Initialized
INFO - 2023-09-06 19:51:42 --> Output Class Initialized
INFO - 2023-09-06 19:51:42 --> Security Class Initialized
DEBUG - 2023-09-06 19:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 19:51:42 --> Input Class Initialized
INFO - 2023-09-06 19:51:42 --> Language Class Initialized
ERROR - 2023-09-06 19:51:42 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:06:02 --> Config Class Initialized
INFO - 2023-09-06 20:06:02 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:02 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:02 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:02 --> URI Class Initialized
INFO - 2023-09-06 20:06:02 --> Router Class Initialized
INFO - 2023-09-06 20:06:02 --> Output Class Initialized
INFO - 2023-09-06 20:06:02 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:03 --> Input Class Initialized
INFO - 2023-09-06 20:06:03 --> Language Class Initialized
INFO - 2023-09-06 20:06:03 --> Loader Class Initialized
INFO - 2023-09-06 20:06:03 --> Helper loaded: url_helper
INFO - 2023-09-06 20:06:03 --> Helper loaded: file_helper
INFO - 2023-09-06 20:06:03 --> Database Driver Class Initialized
INFO - 2023-09-06 20:06:03 --> Email Class Initialized
DEBUG - 2023-09-06 20:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:06:03 --> Controller Class Initialized
INFO - 2023-09-06 20:06:03 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:06:03 --> Model "Home_model" initialized
INFO - 2023-09-06 20:06:03 --> Helper loaded: download_helper
INFO - 2023-09-06 20:06:03 --> Helper loaded: form_helper
INFO - 2023-09-06 20:06:03 --> Form Validation Class Initialized
INFO - 2023-09-06 20:06:03 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:06:03 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:06:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-06 20:06:03 --> Final output sent to browser
DEBUG - 2023-09-06 20:06:03 --> Total execution time: 0.8756
INFO - 2023-09-06 20:06:05 --> Config Class Initialized
INFO - 2023-09-06 20:06:05 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:05 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:05 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:05 --> URI Class Initialized
INFO - 2023-09-06 20:06:05 --> Router Class Initialized
INFO - 2023-09-06 20:06:05 --> Output Class Initialized
INFO - 2023-09-06 20:06:05 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:05 --> Input Class Initialized
INFO - 2023-09-06 20:06:05 --> Language Class Initialized
ERROR - 2023-09-06 20:06:05 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:06:08 --> Config Class Initialized
INFO - 2023-09-06 20:06:08 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:08 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:08 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:08 --> URI Class Initialized
INFO - 2023-09-06 20:06:08 --> Router Class Initialized
INFO - 2023-09-06 20:06:08 --> Output Class Initialized
INFO - 2023-09-06 20:06:08 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:08 --> Input Class Initialized
INFO - 2023-09-06 20:06:08 --> Language Class Initialized
INFO - 2023-09-06 20:06:08 --> Loader Class Initialized
INFO - 2023-09-06 20:06:08 --> Helper loaded: url_helper
INFO - 2023-09-06 20:06:08 --> Helper loaded: file_helper
INFO - 2023-09-06 20:06:08 --> Database Driver Class Initialized
INFO - 2023-09-06 20:06:08 --> Email Class Initialized
DEBUG - 2023-09-06 20:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:06:08 --> Controller Class Initialized
INFO - 2023-09-06 20:06:08 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:06:08 --> Model "Home_model" initialized
INFO - 2023-09-06 20:06:08 --> Helper loaded: download_helper
INFO - 2023-09-06 20:06:08 --> Helper loaded: form_helper
INFO - 2023-09-06 20:06:08 --> Form Validation Class Initialized
INFO - 2023-09-06 20:06:08 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:06:08 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:06:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-06 20:06:08 --> Final output sent to browser
DEBUG - 2023-09-06 20:06:09 --> Total execution time: 0.9150
INFO - 2023-09-06 20:06:10 --> Config Class Initialized
INFO - 2023-09-06 20:06:10 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:10 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:10 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:10 --> URI Class Initialized
INFO - 2023-09-06 20:06:10 --> Router Class Initialized
INFO - 2023-09-06 20:06:10 --> Output Class Initialized
INFO - 2023-09-06 20:06:10 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:10 --> Input Class Initialized
INFO - 2023-09-06 20:06:10 --> Language Class Initialized
ERROR - 2023-09-06 20:06:10 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:06:13 --> Config Class Initialized
INFO - 2023-09-06 20:06:13 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:13 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:13 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:13 --> URI Class Initialized
DEBUG - 2023-09-06 20:06:13 --> No URI present. Default controller set.
INFO - 2023-09-06 20:06:13 --> Router Class Initialized
INFO - 2023-09-06 20:06:13 --> Output Class Initialized
INFO - 2023-09-06 20:06:13 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:13 --> Input Class Initialized
INFO - 2023-09-06 20:06:13 --> Language Class Initialized
INFO - 2023-09-06 20:06:13 --> Loader Class Initialized
INFO - 2023-09-06 20:06:13 --> Helper loaded: url_helper
INFO - 2023-09-06 20:06:13 --> Helper loaded: file_helper
INFO - 2023-09-06 20:06:13 --> Database Driver Class Initialized
INFO - 2023-09-06 20:06:13 --> Email Class Initialized
DEBUG - 2023-09-06 20:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:06:13 --> Controller Class Initialized
INFO - 2023-09-06 20:06:13 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:06:13 --> Model "Home_model" initialized
INFO - 2023-09-06 20:06:13 --> Helper loaded: download_helper
INFO - 2023-09-06 20:06:14 --> Helper loaded: form_helper
INFO - 2023-09-06 20:06:14 --> Form Validation Class Initialized
INFO - 2023-09-06 20:06:14 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:06:14 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:06:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 20:06:14 --> Final output sent to browser
DEBUG - 2023-09-06 20:06:14 --> Total execution time: 0.5463
INFO - 2023-09-06 20:06:14 --> Config Class Initialized
INFO - 2023-09-06 20:06:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:14 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:14 --> URI Class Initialized
INFO - 2023-09-06 20:06:14 --> Router Class Initialized
INFO - 2023-09-06 20:06:14 --> Output Class Initialized
INFO - 2023-09-06 20:06:14 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:14 --> Input Class Initialized
INFO - 2023-09-06 20:06:14 --> Language Class Initialized
ERROR - 2023-09-06 20:06:14 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:06:19 --> Config Class Initialized
INFO - 2023-09-06 20:06:19 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:19 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:19 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:19 --> URI Class Initialized
INFO - 2023-09-06 20:06:19 --> Router Class Initialized
INFO - 2023-09-06 20:06:19 --> Output Class Initialized
INFO - 2023-09-06 20:06:19 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:19 --> Input Class Initialized
INFO - 2023-09-06 20:06:19 --> Language Class Initialized
INFO - 2023-09-06 20:06:19 --> Loader Class Initialized
INFO - 2023-09-06 20:06:19 --> Helper loaded: url_helper
INFO - 2023-09-06 20:06:19 --> Helper loaded: file_helper
INFO - 2023-09-06 20:06:19 --> Database Driver Class Initialized
INFO - 2023-09-06 20:06:19 --> Email Class Initialized
DEBUG - 2023-09-06 20:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:06:19 --> Controller Class Initialized
INFO - 2023-09-06 20:06:19 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:06:19 --> Model "Home_model" initialized
INFO - 2023-09-06 20:06:19 --> Helper loaded: download_helper
INFO - 2023-09-06 20:06:19 --> Helper loaded: form_helper
INFO - 2023-09-06 20:06:19 --> Form Validation Class Initialized
INFO - 2023-09-06 20:06:19 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:06:19 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:06:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:06:19 --> Final output sent to browser
DEBUG - 2023-09-06 20:06:19 --> Total execution time: 0.0724
INFO - 2023-09-06 20:06:21 --> Config Class Initialized
INFO - 2023-09-06 20:06:21 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:06:21 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:06:21 --> Utf8 Class Initialized
INFO - 2023-09-06 20:06:21 --> URI Class Initialized
INFO - 2023-09-06 20:06:21 --> Router Class Initialized
INFO - 2023-09-06 20:06:21 --> Output Class Initialized
INFO - 2023-09-06 20:06:21 --> Security Class Initialized
DEBUG - 2023-09-06 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:06:21 --> Input Class Initialized
INFO - 2023-09-06 20:06:21 --> Language Class Initialized
ERROR - 2023-09-06 20:06:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:07:15 --> Config Class Initialized
INFO - 2023-09-06 20:07:15 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:15 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:15 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:15 --> URI Class Initialized
INFO - 2023-09-06 20:07:15 --> Router Class Initialized
INFO - 2023-09-06 20:07:15 --> Output Class Initialized
INFO - 2023-09-06 20:07:15 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:15 --> Input Class Initialized
INFO - 2023-09-06 20:07:15 --> Language Class Initialized
INFO - 2023-09-06 20:07:15 --> Loader Class Initialized
INFO - 2023-09-06 20:07:15 --> Helper loaded: url_helper
INFO - 2023-09-06 20:07:16 --> Helper loaded: file_helper
INFO - 2023-09-06 20:07:16 --> Database Driver Class Initialized
INFO - 2023-09-06 20:07:16 --> Email Class Initialized
DEBUG - 2023-09-06 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:07:16 --> Controller Class Initialized
INFO - 2023-09-06 20:07:16 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:07:16 --> Model "Home_model" initialized
INFO - 2023-09-06 20:07:16 --> Helper loaded: download_helper
INFO - 2023-09-06 20:07:16 --> Helper loaded: form_helper
INFO - 2023-09-06 20:07:16 --> Form Validation Class Initialized
INFO - 2023-09-06 20:07:16 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:07:16 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:07:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:07:16 --> Final output sent to browser
DEBUG - 2023-09-06 20:07:17 --> Total execution time: 1.4799
INFO - 2023-09-06 20:07:18 --> Config Class Initialized
INFO - 2023-09-06 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:18 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:19 --> URI Class Initialized
INFO - 2023-09-06 20:07:19 --> Router Class Initialized
INFO - 2023-09-06 20:07:19 --> Output Class Initialized
INFO - 2023-09-06 20:07:19 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:19 --> Input Class Initialized
INFO - 2023-09-06 20:07:19 --> Language Class Initialized
ERROR - 2023-09-06 20:07:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:07:25 --> Config Class Initialized
INFO - 2023-09-06 20:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:25 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:25 --> URI Class Initialized
INFO - 2023-09-06 20:07:25 --> Router Class Initialized
INFO - 2023-09-06 20:07:25 --> Output Class Initialized
INFO - 2023-09-06 20:07:25 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:26 --> Input Class Initialized
INFO - 2023-09-06 20:07:26 --> Language Class Initialized
INFO - 2023-09-06 20:07:26 --> Loader Class Initialized
INFO - 2023-09-06 20:07:26 --> Helper loaded: url_helper
INFO - 2023-09-06 20:07:26 --> Helper loaded: file_helper
INFO - 2023-09-06 20:07:26 --> Database Driver Class Initialized
INFO - 2023-09-06 20:07:26 --> Email Class Initialized
DEBUG - 2023-09-06 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:07:26 --> Controller Class Initialized
INFO - 2023-09-06 20:07:26 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:07:26 --> Model "Home_model" initialized
INFO - 2023-09-06 20:07:26 --> Helper loaded: download_helper
INFO - 2023-09-06 20:07:26 --> Helper loaded: form_helper
INFO - 2023-09-06 20:07:26 --> Form Validation Class Initialized
INFO - 2023-09-06 20:07:26 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:07:26 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:07:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:07:26 --> Final output sent to browser
DEBUG - 2023-09-06 20:07:26 --> Total execution time: 1.0972
INFO - 2023-09-06 20:07:27 --> Config Class Initialized
INFO - 2023-09-06 20:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:27 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:27 --> URI Class Initialized
INFO - 2023-09-06 20:07:27 --> Router Class Initialized
INFO - 2023-09-06 20:07:27 --> Output Class Initialized
INFO - 2023-09-06 20:07:27 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:27 --> Input Class Initialized
INFO - 2023-09-06 20:07:28 --> Language Class Initialized
ERROR - 2023-09-06 20:07:28 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:07:30 --> Config Class Initialized
INFO - 2023-09-06 20:07:30 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:30 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:30 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:30 --> URI Class Initialized
INFO - 2023-09-06 20:07:30 --> Router Class Initialized
INFO - 2023-09-06 20:07:30 --> Output Class Initialized
INFO - 2023-09-06 20:07:30 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:30 --> Input Class Initialized
INFO - 2023-09-06 20:07:30 --> Language Class Initialized
INFO - 2023-09-06 20:07:30 --> Loader Class Initialized
INFO - 2023-09-06 20:07:30 --> Helper loaded: url_helper
INFO - 2023-09-06 20:07:30 --> Helper loaded: file_helper
INFO - 2023-09-06 20:07:30 --> Database Driver Class Initialized
INFO - 2023-09-06 20:07:30 --> Email Class Initialized
DEBUG - 2023-09-06 20:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:07:31 --> Controller Class Initialized
INFO - 2023-09-06 20:07:31 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:07:31 --> Model "Home_model" initialized
INFO - 2023-09-06 20:07:31 --> Helper loaded: download_helper
INFO - 2023-09-06 20:07:31 --> Helper loaded: form_helper
INFO - 2023-09-06 20:07:31 --> Form Validation Class Initialized
INFO - 2023-09-06 20:07:31 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:07:31 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:07:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:07:31 --> Final output sent to browser
DEBUG - 2023-09-06 20:07:31 --> Total execution time: 1.1859
INFO - 2023-09-06 20:07:32 --> Config Class Initialized
INFO - 2023-09-06 20:07:32 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:32 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:32 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:32 --> URI Class Initialized
INFO - 2023-09-06 20:07:32 --> Router Class Initialized
INFO - 2023-09-06 20:07:32 --> Output Class Initialized
INFO - 2023-09-06 20:07:32 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:32 --> Input Class Initialized
INFO - 2023-09-06 20:07:32 --> Language Class Initialized
ERROR - 2023-09-06 20:07:32 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:07:46 --> Config Class Initialized
INFO - 2023-09-06 20:07:46 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:46 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:46 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:46 --> URI Class Initialized
INFO - 2023-09-06 20:07:46 --> Router Class Initialized
INFO - 2023-09-06 20:07:46 --> Output Class Initialized
INFO - 2023-09-06 20:07:46 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:46 --> Input Class Initialized
INFO - 2023-09-06 20:07:46 --> Language Class Initialized
INFO - 2023-09-06 20:07:46 --> Loader Class Initialized
INFO - 2023-09-06 20:07:46 --> Helper loaded: url_helper
INFO - 2023-09-06 20:07:46 --> Helper loaded: file_helper
INFO - 2023-09-06 20:07:46 --> Database Driver Class Initialized
INFO - 2023-09-06 20:07:46 --> Email Class Initialized
DEBUG - 2023-09-06 20:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:07:46 --> Controller Class Initialized
INFO - 2023-09-06 20:07:46 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:07:46 --> Model "Home_model" initialized
INFO - 2023-09-06 20:07:47 --> Helper loaded: download_helper
INFO - 2023-09-06 20:07:47 --> Helper loaded: form_helper
INFO - 2023-09-06 20:07:47 --> Form Validation Class Initialized
INFO - 2023-09-06 20:07:47 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:07:47 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:07:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:07:47 --> Final output sent to browser
DEBUG - 2023-09-06 20:07:47 --> Total execution time: 0.8772
INFO - 2023-09-06 20:07:47 --> Config Class Initialized
INFO - 2023-09-06 20:07:47 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:47 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:48 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:48 --> URI Class Initialized
INFO - 2023-09-06 20:07:48 --> Router Class Initialized
INFO - 2023-09-06 20:07:48 --> Output Class Initialized
INFO - 2023-09-06 20:07:48 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:48 --> Input Class Initialized
INFO - 2023-09-06 20:07:48 --> Language Class Initialized
ERROR - 2023-09-06 20:07:48 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:07:50 --> Config Class Initialized
INFO - 2023-09-06 20:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:50 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:50 --> URI Class Initialized
INFO - 2023-09-06 20:07:50 --> Router Class Initialized
INFO - 2023-09-06 20:07:50 --> Output Class Initialized
INFO - 2023-09-06 20:07:50 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:50 --> Input Class Initialized
INFO - 2023-09-06 20:07:50 --> Language Class Initialized
INFO - 2023-09-06 20:07:50 --> Loader Class Initialized
INFO - 2023-09-06 20:07:50 --> Helper loaded: url_helper
INFO - 2023-09-06 20:07:50 --> Helper loaded: file_helper
INFO - 2023-09-06 20:07:50 --> Database Driver Class Initialized
INFO - 2023-09-06 20:07:51 --> Email Class Initialized
DEBUG - 2023-09-06 20:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:07:51 --> Controller Class Initialized
INFO - 2023-09-06 20:07:51 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:07:51 --> Model "Home_model" initialized
INFO - 2023-09-06 20:07:51 --> Helper loaded: download_helper
INFO - 2023-09-06 20:07:51 --> Helper loaded: form_helper
INFO - 2023-09-06 20:07:51 --> Form Validation Class Initialized
INFO - 2023-09-06 20:07:51 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:07:51 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:07:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:07:51 --> Final output sent to browser
DEBUG - 2023-09-06 20:07:51 --> Total execution time: 0.9466
INFO - 2023-09-06 20:07:51 --> Config Class Initialized
INFO - 2023-09-06 20:07:52 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:07:52 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:07:52 --> Utf8 Class Initialized
INFO - 2023-09-06 20:07:52 --> URI Class Initialized
INFO - 2023-09-06 20:07:52 --> Router Class Initialized
INFO - 2023-09-06 20:07:52 --> Output Class Initialized
INFO - 2023-09-06 20:07:52 --> Security Class Initialized
DEBUG - 2023-09-06 20:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:07:52 --> Input Class Initialized
INFO - 2023-09-06 20:07:52 --> Language Class Initialized
ERROR - 2023-09-06 20:07:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:09:27 --> Config Class Initialized
INFO - 2023-09-06 20:09:27 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:27 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:27 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:27 --> URI Class Initialized
INFO - 2023-09-06 20:09:27 --> Router Class Initialized
INFO - 2023-09-06 20:09:27 --> Output Class Initialized
INFO - 2023-09-06 20:09:27 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:27 --> Input Class Initialized
INFO - 2023-09-06 20:09:27 --> Language Class Initialized
INFO - 2023-09-06 20:09:27 --> Loader Class Initialized
INFO - 2023-09-06 20:09:27 --> Helper loaded: url_helper
INFO - 2023-09-06 20:09:27 --> Helper loaded: file_helper
INFO - 2023-09-06 20:09:27 --> Database Driver Class Initialized
INFO - 2023-09-06 20:09:27 --> Email Class Initialized
DEBUG - 2023-09-06 20:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:09:27 --> Controller Class Initialized
INFO - 2023-09-06 20:09:27 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:09:27 --> Model "Home_model" initialized
INFO - 2023-09-06 20:09:27 --> Helper loaded: download_helper
INFO - 2023-09-06 20:09:27 --> Helper loaded: form_helper
INFO - 2023-09-06 20:09:27 --> Form Validation Class Initialized
INFO - 2023-09-06 20:09:27 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:09:28 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:09:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:09:28 --> Final output sent to browser
DEBUG - 2023-09-06 20:09:28 --> Total execution time: 0.9479
INFO - 2023-09-06 20:09:30 --> Config Class Initialized
INFO - 2023-09-06 20:09:30 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:30 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:30 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:30 --> URI Class Initialized
INFO - 2023-09-06 20:09:30 --> Router Class Initialized
INFO - 2023-09-06 20:09:30 --> Output Class Initialized
INFO - 2023-09-06 20:09:30 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:30 --> Input Class Initialized
INFO - 2023-09-06 20:09:30 --> Language Class Initialized
ERROR - 2023-09-06 20:09:30 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:09:33 --> Config Class Initialized
INFO - 2023-09-06 20:09:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:33 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:33 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:33 --> URI Class Initialized
INFO - 2023-09-06 20:09:33 --> Router Class Initialized
INFO - 2023-09-06 20:09:33 --> Output Class Initialized
INFO - 2023-09-06 20:09:33 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:33 --> Input Class Initialized
INFO - 2023-09-06 20:09:33 --> Language Class Initialized
INFO - 2023-09-06 20:09:33 --> Loader Class Initialized
INFO - 2023-09-06 20:09:33 --> Helper loaded: url_helper
INFO - 2023-09-06 20:09:33 --> Helper loaded: file_helper
INFO - 2023-09-06 20:09:33 --> Database Driver Class Initialized
INFO - 2023-09-06 20:09:33 --> Email Class Initialized
DEBUG - 2023-09-06 20:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:09:34 --> Controller Class Initialized
INFO - 2023-09-06 20:09:34 --> Model "Services_model" initialized
INFO - 2023-09-06 20:09:34 --> Helper loaded: form_helper
INFO - 2023-09-06 20:09:34 --> Form Validation Class Initialized
INFO - 2023-09-06 20:09:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-06 20:09:34 --> Final output sent to browser
DEBUG - 2023-09-06 20:09:34 --> Total execution time: 1.6418
INFO - 2023-09-06 20:09:40 --> Config Class Initialized
INFO - 2023-09-06 20:09:40 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:40 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:40 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:40 --> URI Class Initialized
INFO - 2023-09-06 20:09:40 --> Router Class Initialized
INFO - 2023-09-06 20:09:40 --> Output Class Initialized
INFO - 2023-09-06 20:09:40 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:40 --> Input Class Initialized
INFO - 2023-09-06 20:09:40 --> Language Class Initialized
INFO - 2023-09-06 20:09:40 --> Loader Class Initialized
INFO - 2023-09-06 20:09:40 --> Helper loaded: url_helper
INFO - 2023-09-06 20:09:40 --> Helper loaded: file_helper
INFO - 2023-09-06 20:09:40 --> Database Driver Class Initialized
INFO - 2023-09-06 20:09:40 --> Email Class Initialized
DEBUG - 2023-09-06 20:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:09:40 --> Controller Class Initialized
INFO - 2023-09-06 20:09:40 --> Model "Services_model" initialized
INFO - 2023-09-06 20:09:40 --> Helper loaded: form_helper
INFO - 2023-09-06 20:09:40 --> Form Validation Class Initialized
ERROR - 2023-09-06 20:09:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-06 20:09:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-06 20:09:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-06 20:09:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-06 20:09:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-06 20:09:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-06 20:09:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-06 20:09:41 --> Final output sent to browser
DEBUG - 2023-09-06 20:09:41 --> Total execution time: 1.1198
INFO - 2023-09-06 20:09:45 --> Config Class Initialized
INFO - 2023-09-06 20:09:45 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:45 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:45 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:45 --> URI Class Initialized
DEBUG - 2023-09-06 20:09:45 --> No URI present. Default controller set.
INFO - 2023-09-06 20:09:45 --> Router Class Initialized
INFO - 2023-09-06 20:09:45 --> Output Class Initialized
INFO - 2023-09-06 20:09:45 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:45 --> Input Class Initialized
INFO - 2023-09-06 20:09:45 --> Language Class Initialized
INFO - 2023-09-06 20:09:45 --> Loader Class Initialized
INFO - 2023-09-06 20:09:45 --> Helper loaded: url_helper
INFO - 2023-09-06 20:09:45 --> Helper loaded: file_helper
INFO - 2023-09-06 20:09:45 --> Database Driver Class Initialized
INFO - 2023-09-06 20:09:45 --> Email Class Initialized
DEBUG - 2023-09-06 20:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:09:46 --> Controller Class Initialized
INFO - 2023-09-06 20:09:46 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:09:46 --> Model "Home_model" initialized
INFO - 2023-09-06 20:09:46 --> Helper loaded: download_helper
INFO - 2023-09-06 20:09:46 --> Helper loaded: form_helper
INFO - 2023-09-06 20:09:46 --> Form Validation Class Initialized
INFO - 2023-09-06 20:09:46 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:09:46 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:09:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 20:09:46 --> Final output sent to browser
DEBUG - 2023-09-06 20:09:46 --> Total execution time: 0.8142
INFO - 2023-09-06 20:09:48 --> Config Class Initialized
INFO - 2023-09-06 20:09:48 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:09:48 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:09:48 --> Utf8 Class Initialized
INFO - 2023-09-06 20:09:48 --> URI Class Initialized
INFO - 2023-09-06 20:09:48 --> Router Class Initialized
INFO - 2023-09-06 20:09:48 --> Output Class Initialized
INFO - 2023-09-06 20:09:48 --> Security Class Initialized
DEBUG - 2023-09-06 20:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:09:48 --> Input Class Initialized
INFO - 2023-09-06 20:09:48 --> Language Class Initialized
ERROR - 2023-09-06 20:09:48 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:00 --> Config Class Initialized
INFO - 2023-09-06 20:12:00 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:00 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:00 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:00 --> URI Class Initialized
INFO - 2023-09-06 20:12:00 --> Router Class Initialized
INFO - 2023-09-06 20:12:00 --> Output Class Initialized
INFO - 2023-09-06 20:12:00 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:00 --> Input Class Initialized
INFO - 2023-09-06 20:12:00 --> Language Class Initialized
INFO - 2023-09-06 20:12:00 --> Loader Class Initialized
INFO - 2023-09-06 20:12:00 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:00 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:00 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:00 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:00 --> Controller Class Initialized
INFO - 2023-09-06 20:12:00 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:00 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:00 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:00 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:00 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:00 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:00 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-06 20:12:00 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:00 --> Total execution time: 0.6356
INFO - 2023-09-06 20:12:01 --> Config Class Initialized
INFO - 2023-09-06 20:12:01 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:01 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:01 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:01 --> URI Class Initialized
INFO - 2023-09-06 20:12:01 --> Router Class Initialized
INFO - 2023-09-06 20:12:01 --> Output Class Initialized
INFO - 2023-09-06 20:12:01 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:01 --> Input Class Initialized
INFO - 2023-09-06 20:12:01 --> Language Class Initialized
ERROR - 2023-09-06 20:12:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:11 --> Config Class Initialized
INFO - 2023-09-06 20:12:11 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:11 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:11 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:11 --> URI Class Initialized
DEBUG - 2023-09-06 20:12:11 --> No URI present. Default controller set.
INFO - 2023-09-06 20:12:11 --> Router Class Initialized
INFO - 2023-09-06 20:12:11 --> Output Class Initialized
INFO - 2023-09-06 20:12:11 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:11 --> Input Class Initialized
INFO - 2023-09-06 20:12:11 --> Language Class Initialized
INFO - 2023-09-06 20:12:11 --> Loader Class Initialized
INFO - 2023-09-06 20:12:11 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:11 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:11 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:11 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:11 --> Controller Class Initialized
INFO - 2023-09-06 20:12:11 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:11 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:11 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:11 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:11 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:11 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:11 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 20:12:11 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:11 --> Total execution time: 0.5112
INFO - 2023-09-06 20:12:12 --> Config Class Initialized
INFO - 2023-09-06 20:12:12 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:12 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:12 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:12 --> URI Class Initialized
INFO - 2023-09-06 20:12:12 --> Router Class Initialized
INFO - 2023-09-06 20:12:12 --> Output Class Initialized
INFO - 2023-09-06 20:12:12 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:12 --> Input Class Initialized
INFO - 2023-09-06 20:12:12 --> Language Class Initialized
ERROR - 2023-09-06 20:12:12 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:14 --> Config Class Initialized
INFO - 2023-09-06 20:12:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:14 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:14 --> URI Class Initialized
INFO - 2023-09-06 20:12:14 --> Router Class Initialized
INFO - 2023-09-06 20:12:14 --> Output Class Initialized
INFO - 2023-09-06 20:12:14 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:14 --> Input Class Initialized
INFO - 2023-09-06 20:12:14 --> Language Class Initialized
INFO - 2023-09-06 20:12:14 --> Loader Class Initialized
INFO - 2023-09-06 20:12:14 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:14 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:14 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:14 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:14 --> Controller Class Initialized
INFO - 2023-09-06 20:12:14 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:14 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:14 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:14 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:14 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:14 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:14 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-06 20:12:14 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:14 --> Total execution time: 0.0752
INFO - 2023-09-06 20:12:15 --> Config Class Initialized
INFO - 2023-09-06 20:12:15 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:15 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:15 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:15 --> URI Class Initialized
INFO - 2023-09-06 20:12:15 --> Router Class Initialized
INFO - 2023-09-06 20:12:15 --> Output Class Initialized
INFO - 2023-09-06 20:12:15 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:15 --> Input Class Initialized
INFO - 2023-09-06 20:12:15 --> Language Class Initialized
ERROR - 2023-09-06 20:12:15 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:17 --> Config Class Initialized
INFO - 2023-09-06 20:12:17 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:17 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:17 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:17 --> URI Class Initialized
INFO - 2023-09-06 20:12:17 --> Router Class Initialized
INFO - 2023-09-06 20:12:17 --> Output Class Initialized
INFO - 2023-09-06 20:12:17 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:17 --> Input Class Initialized
INFO - 2023-09-06 20:12:17 --> Language Class Initialized
INFO - 2023-09-06 20:12:17 --> Loader Class Initialized
INFO - 2023-09-06 20:12:17 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:17 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:17 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:17 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:17 --> Controller Class Initialized
INFO - 2023-09-06 20:12:17 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:17 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:17 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:17 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:17 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:17 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:17 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-06 20:12:17 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:17 --> Total execution time: 0.0598
INFO - 2023-09-06 20:12:17 --> Config Class Initialized
INFO - 2023-09-06 20:12:17 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:17 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:17 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:17 --> URI Class Initialized
INFO - 2023-09-06 20:12:17 --> Router Class Initialized
INFO - 2023-09-06 20:12:17 --> Output Class Initialized
INFO - 2023-09-06 20:12:17 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:17 --> Input Class Initialized
INFO - 2023-09-06 20:12:17 --> Language Class Initialized
ERROR - 2023-09-06 20:12:17 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:19 --> Config Class Initialized
INFO - 2023-09-06 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:19 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:19 --> URI Class Initialized
INFO - 2023-09-06 20:12:19 --> Router Class Initialized
INFO - 2023-09-06 20:12:19 --> Output Class Initialized
INFO - 2023-09-06 20:12:19 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:19 --> Input Class Initialized
INFO - 2023-09-06 20:12:19 --> Language Class Initialized
INFO - 2023-09-06 20:12:19 --> Loader Class Initialized
INFO - 2023-09-06 20:12:19 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:19 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:19 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:19 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:19 --> Controller Class Initialized
INFO - 2023-09-06 20:12:19 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:19 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:19 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:19 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:19 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:19 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:19 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-06 20:12:19 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:19 --> Total execution time: 0.0647
INFO - 2023-09-06 20:12:19 --> Config Class Initialized
INFO - 2023-09-06 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:19 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:19 --> URI Class Initialized
INFO - 2023-09-06 20:12:19 --> Router Class Initialized
INFO - 2023-09-06 20:12:19 --> Output Class Initialized
INFO - 2023-09-06 20:12:19 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:19 --> Input Class Initialized
INFO - 2023-09-06 20:12:19 --> Language Class Initialized
ERROR - 2023-09-06 20:12:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-06 20:12:25 --> Config Class Initialized
INFO - 2023-09-06 20:12:25 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:25 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:25 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:25 --> URI Class Initialized
DEBUG - 2023-09-06 20:12:25 --> No URI present. Default controller set.
INFO - 2023-09-06 20:12:25 --> Router Class Initialized
INFO - 2023-09-06 20:12:25 --> Output Class Initialized
INFO - 2023-09-06 20:12:25 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:25 --> Input Class Initialized
INFO - 2023-09-06 20:12:25 --> Language Class Initialized
INFO - 2023-09-06 20:12:25 --> Loader Class Initialized
INFO - 2023-09-06 20:12:25 --> Helper loaded: url_helper
INFO - 2023-09-06 20:12:25 --> Helper loaded: file_helper
INFO - 2023-09-06 20:12:25 --> Database Driver Class Initialized
INFO - 2023-09-06 20:12:25 --> Email Class Initialized
DEBUG - 2023-09-06 20:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 20:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 20:12:25 --> Controller Class Initialized
INFO - 2023-09-06 20:12:25 --> Model "Contact_model" initialized
INFO - 2023-09-06 20:12:25 --> Model "Home_model" initialized
INFO - 2023-09-06 20:12:25 --> Helper loaded: download_helper
INFO - 2023-09-06 20:12:25 --> Helper loaded: form_helper
INFO - 2023-09-06 20:12:25 --> Form Validation Class Initialized
INFO - 2023-09-06 20:12:25 --> Helper loaded: custom_helper
INFO - 2023-09-06 20:12:25 --> Model "Social_media_model" initialized
INFO - 2023-09-06 20:12:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-06 20:12:25 --> Final output sent to browser
DEBUG - 2023-09-06 20:12:25 --> Total execution time: 0.0696
INFO - 2023-09-06 20:12:26 --> Config Class Initialized
INFO - 2023-09-06 20:12:26 --> Hooks Class Initialized
DEBUG - 2023-09-06 20:12:26 --> UTF-8 Support Enabled
INFO - 2023-09-06 20:12:26 --> Utf8 Class Initialized
INFO - 2023-09-06 20:12:26 --> URI Class Initialized
INFO - 2023-09-06 20:12:26 --> Router Class Initialized
INFO - 2023-09-06 20:12:26 --> Output Class Initialized
INFO - 2023-09-06 20:12:26 --> Security Class Initialized
DEBUG - 2023-09-06 20:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 20:12:26 --> Input Class Initialized
INFO - 2023-09-06 20:12:26 --> Language Class Initialized
ERROR - 2023-09-06 20:12:26 --> 404 Page Not Found: Assets/images
