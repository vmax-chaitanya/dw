<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-10 07:51:34 --> Config Class Initialized
INFO - 2023-09-10 07:51:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:34 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:34 --> URI Class Initialized
DEBUG - 2023-09-10 07:51:34 --> No URI present. Default controller set.
INFO - 2023-09-10 07:51:34 --> Router Class Initialized
INFO - 2023-09-10 07:51:34 --> Output Class Initialized
INFO - 2023-09-10 07:51:34 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:34 --> Input Class Initialized
INFO - 2023-09-10 07:51:34 --> Language Class Initialized
INFO - 2023-09-10 07:51:35 --> Loader Class Initialized
INFO - 2023-09-10 07:51:35 --> Helper loaded: url_helper
INFO - 2023-09-10 07:51:35 --> Helper loaded: file_helper
INFO - 2023-09-10 07:51:35 --> Database Driver Class Initialized
INFO - 2023-09-10 07:51:35 --> Email Class Initialized
DEBUG - 2023-09-10 07:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:51:35 --> Controller Class Initialized
INFO - 2023-09-10 07:51:35 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:51:35 --> Model "Home_model" initialized
INFO - 2023-09-10 07:51:35 --> Helper loaded: download_helper
INFO - 2023-09-10 07:51:35 --> Helper loaded: form_helper
INFO - 2023-09-10 07:51:35 --> Form Validation Class Initialized
INFO - 2023-09-10 07:51:35 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:51:35 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:51:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:51:35 --> Final output sent to browser
DEBUG - 2023-09-10 07:51:35 --> Total execution time: 1.3707
INFO - 2023-09-10 07:51:37 --> Config Class Initialized
INFO - 2023-09-10 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:37 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:37 --> URI Class Initialized
INFO - 2023-09-10 07:51:37 --> Router Class Initialized
INFO - 2023-09-10 07:51:37 --> Output Class Initialized
INFO - 2023-09-10 07:51:37 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:37 --> Input Class Initialized
INFO - 2023-09-10 07:51:37 --> Language Class Initialized
ERROR - 2023-09-10 07:51:37 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 07:51:50 --> Config Class Initialized
INFO - 2023-09-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:50 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:50 --> URI Class Initialized
INFO - 2023-09-10 07:51:50 --> Router Class Initialized
INFO - 2023-09-10 07:51:50 --> Output Class Initialized
INFO - 2023-09-10 07:51:50 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:50 --> Input Class Initialized
INFO - 2023-09-10 07:51:50 --> Language Class Initialized
ERROR - 2023-09-10 07:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:50 --> Config Class Initialized
INFO - 2023-09-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:50 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:50 --> URI Class Initialized
INFO - 2023-09-10 07:51:50 --> Router Class Initialized
INFO - 2023-09-10 07:51:50 --> Output Class Initialized
INFO - 2023-09-10 07:51:50 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:50 --> Input Class Initialized
INFO - 2023-09-10 07:51:50 --> Language Class Initialized
ERROR - 2023-09-10 07:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:50 --> Config Class Initialized
INFO - 2023-09-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:50 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:50 --> URI Class Initialized
INFO - 2023-09-10 07:51:50 --> Router Class Initialized
INFO - 2023-09-10 07:51:50 --> Output Class Initialized
INFO - 2023-09-10 07:51:50 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:50 --> Input Class Initialized
INFO - 2023-09-10 07:51:50 --> Language Class Initialized
ERROR - 2023-09-10 07:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:50 --> Config Class Initialized
INFO - 2023-09-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:50 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:50 --> URI Class Initialized
INFO - 2023-09-10 07:51:50 --> Router Class Initialized
INFO - 2023-09-10 07:51:50 --> Output Class Initialized
INFO - 2023-09-10 07:51:50 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:50 --> Input Class Initialized
INFO - 2023-09-10 07:51:50 --> Language Class Initialized
ERROR - 2023-09-10 07:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:50 --> Config Class Initialized
INFO - 2023-09-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:50 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:50 --> URI Class Initialized
INFO - 2023-09-10 07:51:50 --> Router Class Initialized
INFO - 2023-09-10 07:51:50 --> Output Class Initialized
INFO - 2023-09-10 07:51:50 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:50 --> Input Class Initialized
INFO - 2023-09-10 07:51:50 --> Language Class Initialized
ERROR - 2023-09-10 07:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:51 --> Config Class Initialized
INFO - 2023-09-10 07:51:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:51 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:51 --> URI Class Initialized
INFO - 2023-09-10 07:51:51 --> Router Class Initialized
INFO - 2023-09-10 07:51:51 --> Output Class Initialized
INFO - 2023-09-10 07:51:51 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:51 --> Input Class Initialized
INFO - 2023-09-10 07:51:51 --> Language Class Initialized
ERROR - 2023-09-10 07:51:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:51:51 --> Config Class Initialized
INFO - 2023-09-10 07:51:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:51:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:51:51 --> Utf8 Class Initialized
INFO - 2023-09-10 07:51:51 --> URI Class Initialized
INFO - 2023-09-10 07:51:51 --> Router Class Initialized
INFO - 2023-09-10 07:51:51 --> Output Class Initialized
INFO - 2023-09-10 07:51:51 --> Security Class Initialized
DEBUG - 2023-09-10 07:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:51:51 --> Input Class Initialized
INFO - 2023-09-10 07:51:51 --> Language Class Initialized
ERROR - 2023-09-10 07:51:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:23 --> Config Class Initialized
INFO - 2023-09-10 07:54:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:23 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:23 --> URI Class Initialized
DEBUG - 2023-09-10 07:54:23 --> No URI present. Default controller set.
INFO - 2023-09-10 07:54:23 --> Router Class Initialized
INFO - 2023-09-10 07:54:23 --> Output Class Initialized
INFO - 2023-09-10 07:54:23 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:23 --> Input Class Initialized
INFO - 2023-09-10 07:54:23 --> Language Class Initialized
INFO - 2023-09-10 07:54:23 --> Loader Class Initialized
INFO - 2023-09-10 07:54:23 --> Helper loaded: url_helper
INFO - 2023-09-10 07:54:23 --> Helper loaded: file_helper
INFO - 2023-09-10 07:54:23 --> Database Driver Class Initialized
INFO - 2023-09-10 07:54:23 --> Email Class Initialized
DEBUG - 2023-09-10 07:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:54:23 --> Controller Class Initialized
INFO - 2023-09-10 07:54:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:54:23 --> Model "Home_model" initialized
INFO - 2023-09-10 07:54:23 --> Helper loaded: download_helper
INFO - 2023-09-10 07:54:23 --> Helper loaded: form_helper
INFO - 2023-09-10 07:54:23 --> Form Validation Class Initialized
INFO - 2023-09-10 07:54:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:54:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:54:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:54:23 --> Final output sent to browser
DEBUG - 2023-09-10 07:54:23 --> Total execution time: 0.2753
INFO - 2023-09-10 07:54:25 --> Config Class Initialized
INFO - 2023-09-10 07:54:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:25 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:25 --> URI Class Initialized
INFO - 2023-09-10 07:54:25 --> Router Class Initialized
INFO - 2023-09-10 07:54:25 --> Output Class Initialized
INFO - 2023-09-10 07:54:25 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:25 --> Input Class Initialized
INFO - 2023-09-10 07:54:25 --> Language Class Initialized
ERROR - 2023-09-10 07:54:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:27 --> Config Class Initialized
INFO - 2023-09-10 07:54:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:27 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:27 --> URI Class Initialized
INFO - 2023-09-10 07:54:27 --> Router Class Initialized
INFO - 2023-09-10 07:54:27 --> Output Class Initialized
INFO - 2023-09-10 07:54:27 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:27 --> Input Class Initialized
INFO - 2023-09-10 07:54:27 --> Language Class Initialized
ERROR - 2023-09-10 07:54:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:28 --> Config Class Initialized
INFO - 2023-09-10 07:54:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:28 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:28 --> URI Class Initialized
INFO - 2023-09-10 07:54:28 --> Router Class Initialized
INFO - 2023-09-10 07:54:28 --> Output Class Initialized
INFO - 2023-09-10 07:54:28 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:28 --> Input Class Initialized
INFO - 2023-09-10 07:54:28 --> Language Class Initialized
ERROR - 2023-09-10 07:54:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:28 --> Config Class Initialized
INFO - 2023-09-10 07:54:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:28 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:28 --> URI Class Initialized
INFO - 2023-09-10 07:54:28 --> Router Class Initialized
INFO - 2023-09-10 07:54:28 --> Output Class Initialized
INFO - 2023-09-10 07:54:28 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:28 --> Input Class Initialized
INFO - 2023-09-10 07:54:28 --> Language Class Initialized
ERROR - 2023-09-10 07:54:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:30 --> Config Class Initialized
INFO - 2023-09-10 07:54:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:30 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:30 --> URI Class Initialized
INFO - 2023-09-10 07:54:30 --> Router Class Initialized
INFO - 2023-09-10 07:54:30 --> Output Class Initialized
INFO - 2023-09-10 07:54:30 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:30 --> Input Class Initialized
INFO - 2023-09-10 07:54:30 --> Language Class Initialized
ERROR - 2023-09-10 07:54:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:31 --> Config Class Initialized
INFO - 2023-09-10 07:54:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:31 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:31 --> URI Class Initialized
INFO - 2023-09-10 07:54:31 --> Router Class Initialized
INFO - 2023-09-10 07:54:31 --> Output Class Initialized
INFO - 2023-09-10 07:54:31 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:31 --> Input Class Initialized
INFO - 2023-09-10 07:54:31 --> Language Class Initialized
ERROR - 2023-09-10 07:54:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:31 --> Config Class Initialized
INFO - 2023-09-10 07:54:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:31 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:31 --> URI Class Initialized
INFO - 2023-09-10 07:54:31 --> Router Class Initialized
INFO - 2023-09-10 07:54:31 --> Output Class Initialized
INFO - 2023-09-10 07:54:31 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:31 --> Input Class Initialized
INFO - 2023-09-10 07:54:31 --> Language Class Initialized
ERROR - 2023-09-10 07:54:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:54:34 --> Config Class Initialized
INFO - 2023-09-10 07:54:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:54:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:54:34 --> Utf8 Class Initialized
INFO - 2023-09-10 07:54:34 --> URI Class Initialized
INFO - 2023-09-10 07:54:34 --> Router Class Initialized
INFO - 2023-09-10 07:54:34 --> Output Class Initialized
INFO - 2023-09-10 07:54:34 --> Security Class Initialized
DEBUG - 2023-09-10 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:54:34 --> Input Class Initialized
INFO - 2023-09-10 07:54:34 --> Language Class Initialized
ERROR - 2023-09-10 07:54:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 07:55:14 --> Config Class Initialized
INFO - 2023-09-10 07:55:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:15 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:15 --> URI Class Initialized
DEBUG - 2023-09-10 07:55:15 --> No URI present. Default controller set.
INFO - 2023-09-10 07:55:15 --> Router Class Initialized
INFO - 2023-09-10 07:55:15 --> Output Class Initialized
INFO - 2023-09-10 07:55:15 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:15 --> Input Class Initialized
INFO - 2023-09-10 07:55:15 --> Language Class Initialized
INFO - 2023-09-10 07:55:15 --> Loader Class Initialized
INFO - 2023-09-10 07:55:15 --> Helper loaded: url_helper
INFO - 2023-09-10 07:55:15 --> Helper loaded: file_helper
INFO - 2023-09-10 07:55:15 --> Database Driver Class Initialized
INFO - 2023-09-10 07:55:15 --> Email Class Initialized
DEBUG - 2023-09-10 07:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:55:15 --> Controller Class Initialized
INFO - 2023-09-10 07:55:15 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:55:15 --> Model "Home_model" initialized
INFO - 2023-09-10 07:55:15 --> Helper loaded: download_helper
INFO - 2023-09-10 07:55:15 --> Helper loaded: form_helper
INFO - 2023-09-10 07:55:15 --> Form Validation Class Initialized
INFO - 2023-09-10 07:55:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:55:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:55:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:55:15 --> Final output sent to browser
DEBUG - 2023-09-10 07:55:15 --> Total execution time: 0.7514
INFO - 2023-09-10 07:55:16 --> Config Class Initialized
INFO - 2023-09-10 07:55:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:16 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:16 --> URI Class Initialized
INFO - 2023-09-10 07:55:16 --> Router Class Initialized
INFO - 2023-09-10 07:55:16 --> Output Class Initialized
INFO - 2023-09-10 07:55:16 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:16 --> Input Class Initialized
INFO - 2023-09-10 07:55:16 --> Language Class Initialized
ERROR - 2023-09-10 07:55:16 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 07:55:17 --> Config Class Initialized
INFO - 2023-09-10 07:55:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:17 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:17 --> URI Class Initialized
INFO - 2023-09-10 07:55:17 --> Router Class Initialized
INFO - 2023-09-10 07:55:17 --> Output Class Initialized
INFO - 2023-09-10 07:55:17 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:17 --> Input Class Initialized
INFO - 2023-09-10 07:55:17 --> Language Class Initialized
ERROR - 2023-09-10 07:55:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:17 --> Config Class Initialized
INFO - 2023-09-10 07:55:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:17 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:17 --> URI Class Initialized
INFO - 2023-09-10 07:55:17 --> Router Class Initialized
INFO - 2023-09-10 07:55:17 --> Output Class Initialized
INFO - 2023-09-10 07:55:17 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:17 --> Input Class Initialized
INFO - 2023-09-10 07:55:17 --> Language Class Initialized
ERROR - 2023-09-10 07:55:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:18 --> Config Class Initialized
INFO - 2023-09-10 07:55:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:18 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:18 --> URI Class Initialized
INFO - 2023-09-10 07:55:18 --> Router Class Initialized
INFO - 2023-09-10 07:55:18 --> Output Class Initialized
INFO - 2023-09-10 07:55:18 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:18 --> Input Class Initialized
INFO - 2023-09-10 07:55:18 --> Language Class Initialized
ERROR - 2023-09-10 07:55:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:18 --> Config Class Initialized
INFO - 2023-09-10 07:55:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:18 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:18 --> URI Class Initialized
INFO - 2023-09-10 07:55:18 --> Router Class Initialized
INFO - 2023-09-10 07:55:18 --> Output Class Initialized
INFO - 2023-09-10 07:55:18 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:18 --> Input Class Initialized
INFO - 2023-09-10 07:55:18 --> Language Class Initialized
ERROR - 2023-09-10 07:55:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:19 --> Config Class Initialized
INFO - 2023-09-10 07:55:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:19 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:19 --> URI Class Initialized
INFO - 2023-09-10 07:55:19 --> Router Class Initialized
INFO - 2023-09-10 07:55:19 --> Output Class Initialized
INFO - 2023-09-10 07:55:19 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:19 --> Input Class Initialized
INFO - 2023-09-10 07:55:19 --> Language Class Initialized
ERROR - 2023-09-10 07:55:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:20 --> Config Class Initialized
INFO - 2023-09-10 07:55:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:20 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:20 --> URI Class Initialized
INFO - 2023-09-10 07:55:20 --> Router Class Initialized
INFO - 2023-09-10 07:55:20 --> Output Class Initialized
INFO - 2023-09-10 07:55:20 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:20 --> Input Class Initialized
INFO - 2023-09-10 07:55:20 --> Language Class Initialized
ERROR - 2023-09-10 07:55:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:21 --> Config Class Initialized
INFO - 2023-09-10 07:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:22 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:22 --> URI Class Initialized
INFO - 2023-09-10 07:55:22 --> Router Class Initialized
INFO - 2023-09-10 07:55:22 --> Output Class Initialized
INFO - 2023-09-10 07:55:22 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:23 --> Input Class Initialized
INFO - 2023-09-10 07:55:23 --> Language Class Initialized
ERROR - 2023-09-10 07:55:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:32 --> Config Class Initialized
INFO - 2023-09-10 07:55:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:33 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:33 --> URI Class Initialized
DEBUG - 2023-09-10 07:55:33 --> No URI present. Default controller set.
INFO - 2023-09-10 07:55:33 --> Router Class Initialized
INFO - 2023-09-10 07:55:33 --> Output Class Initialized
INFO - 2023-09-10 07:55:33 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:33 --> Input Class Initialized
INFO - 2023-09-10 07:55:33 --> Language Class Initialized
INFO - 2023-09-10 07:55:33 --> Loader Class Initialized
INFO - 2023-09-10 07:55:33 --> Helper loaded: url_helper
INFO - 2023-09-10 07:55:33 --> Helper loaded: file_helper
INFO - 2023-09-10 07:55:33 --> Database Driver Class Initialized
INFO - 2023-09-10 07:55:33 --> Email Class Initialized
DEBUG - 2023-09-10 07:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:55:33 --> Controller Class Initialized
INFO - 2023-09-10 07:55:33 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:55:33 --> Model "Home_model" initialized
INFO - 2023-09-10 07:55:33 --> Helper loaded: download_helper
INFO - 2023-09-10 07:55:33 --> Helper loaded: form_helper
INFO - 2023-09-10 07:55:33 --> Form Validation Class Initialized
INFO - 2023-09-10 07:55:33 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:55:33 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:55:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:55:33 --> Final output sent to browser
DEBUG - 2023-09-10 07:55:33 --> Total execution time: 0.6597
INFO - 2023-09-10 07:55:34 --> Config Class Initialized
INFO - 2023-09-10 07:55:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:34 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:34 --> URI Class Initialized
INFO - 2023-09-10 07:55:34 --> Router Class Initialized
INFO - 2023-09-10 07:55:34 --> Output Class Initialized
INFO - 2023-09-10 07:55:34 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:34 --> Input Class Initialized
INFO - 2023-09-10 07:55:34 --> Language Class Initialized
ERROR - 2023-09-10 07:55:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 07:55:34 --> Config Class Initialized
INFO - 2023-09-10 07:55:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:34 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:34 --> URI Class Initialized
INFO - 2023-09-10 07:55:34 --> Router Class Initialized
INFO - 2023-09-10 07:55:34 --> Output Class Initialized
INFO - 2023-09-10 07:55:34 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:34 --> Input Class Initialized
INFO - 2023-09-10 07:55:34 --> Language Class Initialized
ERROR - 2023-09-10 07:55:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:34 --> Config Class Initialized
INFO - 2023-09-10 07:55:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:34 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:34 --> URI Class Initialized
INFO - 2023-09-10 07:55:34 --> Router Class Initialized
INFO - 2023-09-10 07:55:34 --> Output Class Initialized
INFO - 2023-09-10 07:55:34 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:34 --> Input Class Initialized
INFO - 2023-09-10 07:55:34 --> Language Class Initialized
ERROR - 2023-09-10 07:55:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:35 --> Config Class Initialized
INFO - 2023-09-10 07:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:35 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:35 --> URI Class Initialized
INFO - 2023-09-10 07:55:35 --> Router Class Initialized
INFO - 2023-09-10 07:55:35 --> Output Class Initialized
INFO - 2023-09-10 07:55:35 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:35 --> Input Class Initialized
INFO - 2023-09-10 07:55:35 --> Language Class Initialized
ERROR - 2023-09-10 07:55:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:35 --> Config Class Initialized
INFO - 2023-09-10 07:55:35 --> Config Class Initialized
INFO - 2023-09-10 07:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:35 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:35 --> URI Class Initialized
INFO - 2023-09-10 07:55:35 --> Router Class Initialized
INFO - 2023-09-10 07:55:35 --> Output Class Initialized
INFO - 2023-09-10 07:55:35 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:35 --> Input Class Initialized
INFO - 2023-09-10 07:55:35 --> Language Class Initialized
ERROR - 2023-09-10 07:55:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:35 --> Config Class Initialized
INFO - 2023-09-10 07:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:35 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:35 --> URI Class Initialized
INFO - 2023-09-10 07:55:35 --> Router Class Initialized
INFO - 2023-09-10 07:55:35 --> Output Class Initialized
INFO - 2023-09-10 07:55:35 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:35 --> Input Class Initialized
INFO - 2023-09-10 07:55:35 --> Language Class Initialized
ERROR - 2023-09-10 07:55:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:35 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:35 --> URI Class Initialized
INFO - 2023-09-10 07:55:35 --> Router Class Initialized
INFO - 2023-09-10 07:55:35 --> Output Class Initialized
INFO - 2023-09-10 07:55:35 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:35 --> Input Class Initialized
INFO - 2023-09-10 07:55:35 --> Language Class Initialized
ERROR - 2023-09-10 07:55:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:55:36 --> Config Class Initialized
INFO - 2023-09-10 07:55:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:55:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:55:36 --> Utf8 Class Initialized
INFO - 2023-09-10 07:55:36 --> URI Class Initialized
INFO - 2023-09-10 07:55:36 --> Router Class Initialized
INFO - 2023-09-10 07:55:36 --> Output Class Initialized
INFO - 2023-09-10 07:55:36 --> Security Class Initialized
DEBUG - 2023-09-10 07:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:55:36 --> Input Class Initialized
INFO - 2023-09-10 07:55:36 --> Language Class Initialized
ERROR - 2023-09-10 07:55:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 07:58:51 --> Config Class Initialized
INFO - 2023-09-10 07:58:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:58:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:58:51 --> Utf8 Class Initialized
INFO - 2023-09-10 07:58:51 --> URI Class Initialized
DEBUG - 2023-09-10 07:58:51 --> No URI present. Default controller set.
INFO - 2023-09-10 07:58:51 --> Router Class Initialized
INFO - 2023-09-10 07:58:51 --> Output Class Initialized
INFO - 2023-09-10 07:58:51 --> Security Class Initialized
DEBUG - 2023-09-10 07:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:58:51 --> Input Class Initialized
INFO - 2023-09-10 07:58:51 --> Language Class Initialized
INFO - 2023-09-10 07:58:51 --> Loader Class Initialized
INFO - 2023-09-10 07:58:51 --> Helper loaded: url_helper
INFO - 2023-09-10 07:58:51 --> Helper loaded: file_helper
INFO - 2023-09-10 07:58:51 --> Database Driver Class Initialized
INFO - 2023-09-10 07:58:51 --> Email Class Initialized
DEBUG - 2023-09-10 07:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:58:51 --> Controller Class Initialized
INFO - 2023-09-10 07:58:51 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:58:51 --> Model "Home_model" initialized
INFO - 2023-09-10 07:58:51 --> Helper loaded: download_helper
INFO - 2023-09-10 07:58:51 --> Helper loaded: form_helper
INFO - 2023-09-10 07:58:51 --> Form Validation Class Initialized
INFO - 2023-09-10 07:58:51 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:58:51 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:58:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:58:51 --> Final output sent to browser
DEBUG - 2023-09-10 07:58:51 --> Total execution time: 0.6032
INFO - 2023-09-10 07:58:53 --> Config Class Initialized
INFO - 2023-09-10 07:58:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:58:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:58:53 --> Utf8 Class Initialized
INFO - 2023-09-10 07:58:53 --> URI Class Initialized
INFO - 2023-09-10 07:58:53 --> Router Class Initialized
INFO - 2023-09-10 07:58:53 --> Output Class Initialized
INFO - 2023-09-10 07:58:53 --> Security Class Initialized
DEBUG - 2023-09-10 07:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:58:53 --> Input Class Initialized
INFO - 2023-09-10 07:58:53 --> Language Class Initialized
ERROR - 2023-09-10 07:58:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 07:59:18 --> Config Class Initialized
INFO - 2023-09-10 07:59:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:59:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:59:18 --> Utf8 Class Initialized
INFO - 2023-09-10 07:59:18 --> URI Class Initialized
DEBUG - 2023-09-10 07:59:18 --> No URI present. Default controller set.
INFO - 2023-09-10 07:59:18 --> Router Class Initialized
INFO - 2023-09-10 07:59:18 --> Output Class Initialized
INFO - 2023-09-10 07:59:18 --> Security Class Initialized
DEBUG - 2023-09-10 07:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:59:18 --> Input Class Initialized
INFO - 2023-09-10 07:59:18 --> Language Class Initialized
INFO - 2023-09-10 07:59:19 --> Loader Class Initialized
INFO - 2023-09-10 07:59:19 --> Helper loaded: url_helper
INFO - 2023-09-10 07:59:19 --> Helper loaded: file_helper
INFO - 2023-09-10 07:59:19 --> Database Driver Class Initialized
INFO - 2023-09-10 07:59:19 --> Email Class Initialized
DEBUG - 2023-09-10 07:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 07:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 07:59:19 --> Controller Class Initialized
INFO - 2023-09-10 07:59:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 07:59:19 --> Model "Home_model" initialized
INFO - 2023-09-10 07:59:19 --> Helper loaded: download_helper
INFO - 2023-09-10 07:59:19 --> Helper loaded: form_helper
INFO - 2023-09-10 07:59:19 --> Form Validation Class Initialized
INFO - 2023-09-10 07:59:19 --> Helper loaded: custom_helper
INFO - 2023-09-10 07:59:19 --> Model "Social_media_model" initialized
INFO - 2023-09-10 07:59:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 07:59:19 --> Final output sent to browser
DEBUG - 2023-09-10 07:59:19 --> Total execution time: 0.8959
INFO - 2023-09-10 07:59:21 --> Config Class Initialized
INFO - 2023-09-10 07:59:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 07:59:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 07:59:21 --> Utf8 Class Initialized
INFO - 2023-09-10 07:59:21 --> URI Class Initialized
INFO - 2023-09-10 07:59:21 --> Router Class Initialized
INFO - 2023-09-10 07:59:21 --> Output Class Initialized
INFO - 2023-09-10 07:59:22 --> Security Class Initialized
DEBUG - 2023-09-10 07:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 07:59:22 --> Input Class Initialized
INFO - 2023-09-10 07:59:22 --> Language Class Initialized
ERROR - 2023-09-10 07:59:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:00:22 --> Config Class Initialized
INFO - 2023-09-10 08:00:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:00:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:00:22 --> Utf8 Class Initialized
INFO - 2023-09-10 08:00:22 --> URI Class Initialized
DEBUG - 2023-09-10 08:00:22 --> No URI present. Default controller set.
INFO - 2023-09-10 08:00:22 --> Router Class Initialized
INFO - 2023-09-10 08:00:22 --> Output Class Initialized
INFO - 2023-09-10 08:00:22 --> Security Class Initialized
DEBUG - 2023-09-10 08:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:00:22 --> Input Class Initialized
INFO - 2023-09-10 08:00:22 --> Language Class Initialized
INFO - 2023-09-10 08:00:22 --> Loader Class Initialized
INFO - 2023-09-10 08:00:22 --> Helper loaded: url_helper
INFO - 2023-09-10 08:00:22 --> Helper loaded: file_helper
INFO - 2023-09-10 08:00:22 --> Database Driver Class Initialized
INFO - 2023-09-10 08:00:22 --> Email Class Initialized
DEBUG - 2023-09-10 08:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:00:22 --> Controller Class Initialized
INFO - 2023-09-10 08:00:22 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:00:22 --> Model "Home_model" initialized
INFO - 2023-09-10 08:00:22 --> Helper loaded: download_helper
INFO - 2023-09-10 08:00:22 --> Helper loaded: form_helper
INFO - 2023-09-10 08:00:22 --> Form Validation Class Initialized
INFO - 2023-09-10 08:00:22 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:00:22 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:00:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:00:22 --> Final output sent to browser
DEBUG - 2023-09-10 08:00:22 --> Total execution time: 0.4239
INFO - 2023-09-10 08:00:24 --> Config Class Initialized
INFO - 2023-09-10 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:00:24 --> Utf8 Class Initialized
INFO - 2023-09-10 08:00:24 --> URI Class Initialized
INFO - 2023-09-10 08:00:24 --> Router Class Initialized
INFO - 2023-09-10 08:00:24 --> Output Class Initialized
INFO - 2023-09-10 08:00:24 --> Security Class Initialized
DEBUG - 2023-09-10 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:00:24 --> Input Class Initialized
INFO - 2023-09-10 08:00:24 --> Language Class Initialized
ERROR - 2023-09-10 08:00:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:02:15 --> Config Class Initialized
INFO - 2023-09-10 08:02:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:02:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:02:15 --> Utf8 Class Initialized
INFO - 2023-09-10 08:02:15 --> URI Class Initialized
DEBUG - 2023-09-10 08:02:15 --> No URI present. Default controller set.
INFO - 2023-09-10 08:02:15 --> Router Class Initialized
INFO - 2023-09-10 08:02:15 --> Output Class Initialized
INFO - 2023-09-10 08:02:15 --> Security Class Initialized
DEBUG - 2023-09-10 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:02:15 --> Input Class Initialized
INFO - 2023-09-10 08:02:15 --> Language Class Initialized
INFO - 2023-09-10 08:02:15 --> Loader Class Initialized
INFO - 2023-09-10 08:02:15 --> Helper loaded: url_helper
INFO - 2023-09-10 08:02:15 --> Helper loaded: file_helper
INFO - 2023-09-10 08:02:15 --> Database Driver Class Initialized
INFO - 2023-09-10 08:02:15 --> Email Class Initialized
DEBUG - 2023-09-10 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:02:15 --> Controller Class Initialized
INFO - 2023-09-10 08:02:15 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:02:15 --> Model "Home_model" initialized
INFO - 2023-09-10 08:02:15 --> Helper loaded: download_helper
INFO - 2023-09-10 08:02:15 --> Helper loaded: form_helper
INFO - 2023-09-10 08:02:15 --> Form Validation Class Initialized
INFO - 2023-09-10 08:02:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:02:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:02:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:02:15 --> Final output sent to browser
DEBUG - 2023-09-10 08:02:15 --> Total execution time: 0.5901
INFO - 2023-09-10 08:02:19 --> Config Class Initialized
INFO - 2023-09-10 08:02:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:02:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:02:19 --> Utf8 Class Initialized
INFO - 2023-09-10 08:02:19 --> URI Class Initialized
INFO - 2023-09-10 08:02:19 --> Router Class Initialized
INFO - 2023-09-10 08:02:19 --> Output Class Initialized
INFO - 2023-09-10 08:02:19 --> Security Class Initialized
DEBUG - 2023-09-10 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:02:19 --> Input Class Initialized
INFO - 2023-09-10 08:02:19 --> Language Class Initialized
ERROR - 2023-09-10 08:02:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:02:32 --> Config Class Initialized
INFO - 2023-09-10 08:02:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:02:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:02:33 --> Utf8 Class Initialized
INFO - 2023-09-10 08:02:33 --> URI Class Initialized
DEBUG - 2023-09-10 08:02:34 --> No URI present. Default controller set.
INFO - 2023-09-10 08:02:34 --> Router Class Initialized
INFO - 2023-09-10 08:02:34 --> Output Class Initialized
INFO - 2023-09-10 08:02:34 --> Security Class Initialized
DEBUG - 2023-09-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:02:34 --> Input Class Initialized
INFO - 2023-09-10 08:02:34 --> Language Class Initialized
INFO - 2023-09-10 08:02:34 --> Loader Class Initialized
INFO - 2023-09-10 08:02:34 --> Helper loaded: url_helper
INFO - 2023-09-10 08:02:35 --> Helper loaded: file_helper
INFO - 2023-09-10 08:02:35 --> Database Driver Class Initialized
INFO - 2023-09-10 08:02:35 --> Email Class Initialized
DEBUG - 2023-09-10 08:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:02:35 --> Controller Class Initialized
INFO - 2023-09-10 08:02:35 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:02:35 --> Model "Home_model" initialized
INFO - 2023-09-10 08:02:35 --> Helper loaded: download_helper
INFO - 2023-09-10 08:02:36 --> Helper loaded: form_helper
INFO - 2023-09-10 08:02:36 --> Form Validation Class Initialized
INFO - 2023-09-10 08:02:36 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:02:36 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:02:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:02:36 --> Final output sent to browser
DEBUG - 2023-09-10 08:02:36 --> Total execution time: 3.4901
INFO - 2023-09-10 08:02:39 --> Config Class Initialized
INFO - 2023-09-10 08:02:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:02:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:02:39 --> Utf8 Class Initialized
INFO - 2023-09-10 08:02:39 --> URI Class Initialized
INFO - 2023-09-10 08:02:39 --> Router Class Initialized
INFO - 2023-09-10 08:02:39 --> Output Class Initialized
INFO - 2023-09-10 08:02:39 --> Security Class Initialized
DEBUG - 2023-09-10 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:02:39 --> Input Class Initialized
INFO - 2023-09-10 08:02:39 --> Language Class Initialized
ERROR - 2023-09-10 08:02:39 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:03:12 --> Config Class Initialized
INFO - 2023-09-10 08:03:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:03:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:03:12 --> Utf8 Class Initialized
INFO - 2023-09-10 08:03:12 --> URI Class Initialized
DEBUG - 2023-09-10 08:03:12 --> No URI present. Default controller set.
INFO - 2023-09-10 08:03:12 --> Router Class Initialized
INFO - 2023-09-10 08:03:12 --> Output Class Initialized
INFO - 2023-09-10 08:03:12 --> Security Class Initialized
DEBUG - 2023-09-10 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:03:12 --> Input Class Initialized
INFO - 2023-09-10 08:03:12 --> Language Class Initialized
INFO - 2023-09-10 08:03:12 --> Loader Class Initialized
INFO - 2023-09-10 08:03:12 --> Helper loaded: url_helper
INFO - 2023-09-10 08:03:12 --> Helper loaded: file_helper
INFO - 2023-09-10 08:03:12 --> Database Driver Class Initialized
INFO - 2023-09-10 08:03:12 --> Email Class Initialized
DEBUG - 2023-09-10 08:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:03:12 --> Controller Class Initialized
INFO - 2023-09-10 08:03:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:03:12 --> Model "Home_model" initialized
INFO - 2023-09-10 08:03:12 --> Helper loaded: download_helper
INFO - 2023-09-10 08:03:12 --> Helper loaded: form_helper
INFO - 2023-09-10 08:03:12 --> Form Validation Class Initialized
INFO - 2023-09-10 08:03:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:03:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:03:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:03:12 --> Final output sent to browser
DEBUG - 2023-09-10 08:03:13 --> Total execution time: 0.7493
INFO - 2023-09-10 08:03:16 --> Config Class Initialized
INFO - 2023-09-10 08:03:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:03:16 --> Utf8 Class Initialized
INFO - 2023-09-10 08:03:16 --> URI Class Initialized
INFO - 2023-09-10 08:03:16 --> Router Class Initialized
INFO - 2023-09-10 08:03:16 --> Output Class Initialized
INFO - 2023-09-10 08:03:16 --> Security Class Initialized
DEBUG - 2023-09-10 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:03:17 --> Input Class Initialized
INFO - 2023-09-10 08:03:17 --> Language Class Initialized
ERROR - 2023-09-10 08:03:17 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:04:16 --> Config Class Initialized
INFO - 2023-09-10 08:04:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:04:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:04:16 --> Utf8 Class Initialized
INFO - 2023-09-10 08:04:16 --> URI Class Initialized
DEBUG - 2023-09-10 08:04:16 --> No URI present. Default controller set.
INFO - 2023-09-10 08:04:16 --> Router Class Initialized
INFO - 2023-09-10 08:04:16 --> Output Class Initialized
INFO - 2023-09-10 08:04:16 --> Security Class Initialized
DEBUG - 2023-09-10 08:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:04:16 --> Input Class Initialized
INFO - 2023-09-10 08:04:17 --> Language Class Initialized
INFO - 2023-09-10 08:04:17 --> Loader Class Initialized
INFO - 2023-09-10 08:04:17 --> Helper loaded: url_helper
INFO - 2023-09-10 08:04:17 --> Helper loaded: file_helper
INFO - 2023-09-10 08:04:17 --> Database Driver Class Initialized
INFO - 2023-09-10 08:04:17 --> Email Class Initialized
DEBUG - 2023-09-10 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:04:17 --> Controller Class Initialized
INFO - 2023-09-10 08:04:17 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:04:17 --> Model "Home_model" initialized
INFO - 2023-09-10 08:04:17 --> Helper loaded: download_helper
INFO - 2023-09-10 08:04:17 --> Helper loaded: form_helper
INFO - 2023-09-10 08:04:17 --> Form Validation Class Initialized
INFO - 2023-09-10 08:04:17 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:04:17 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:04:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:04:17 --> Final output sent to browser
DEBUG - 2023-09-10 08:04:17 --> Total execution time: 0.8964
INFO - 2023-09-10 08:04:18 --> Config Class Initialized
INFO - 2023-09-10 08:04:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:04:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:04:19 --> Utf8 Class Initialized
INFO - 2023-09-10 08:04:19 --> URI Class Initialized
INFO - 2023-09-10 08:04:19 --> Router Class Initialized
INFO - 2023-09-10 08:04:19 --> Output Class Initialized
INFO - 2023-09-10 08:04:19 --> Security Class Initialized
DEBUG - 2023-09-10 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:04:19 --> Input Class Initialized
INFO - 2023-09-10 08:04:19 --> Language Class Initialized
ERROR - 2023-09-10 08:04:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:07:26 --> Config Class Initialized
INFO - 2023-09-10 08:07:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:07:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:07:26 --> Utf8 Class Initialized
INFO - 2023-09-10 08:07:26 --> URI Class Initialized
INFO - 2023-09-10 08:07:26 --> Router Class Initialized
INFO - 2023-09-10 08:07:26 --> Output Class Initialized
INFO - 2023-09-10 08:07:26 --> Security Class Initialized
DEBUG - 2023-09-10 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:07:26 --> Input Class Initialized
INFO - 2023-09-10 08:07:26 --> Language Class Initialized
INFO - 2023-09-10 08:07:26 --> Loader Class Initialized
INFO - 2023-09-10 08:07:26 --> Helper loaded: url_helper
INFO - 2023-09-10 08:07:26 --> Helper loaded: file_helper
INFO - 2023-09-10 08:07:26 --> Database Driver Class Initialized
INFO - 2023-09-10 08:07:26 --> Email Class Initialized
DEBUG - 2023-09-10 08:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:07:26 --> Controller Class Initialized
INFO - 2023-09-10 08:07:26 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:07:26 --> Model "Home_model" initialized
INFO - 2023-09-10 08:07:26 --> Helper loaded: download_helper
INFO - 2023-09-10 08:07:26 --> Helper loaded: form_helper
INFO - 2023-09-10 08:07:26 --> Form Validation Class Initialized
INFO - 2023-09-10 08:07:26 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:07:26 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:07:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:07:26 --> Final output sent to browser
DEBUG - 2023-09-10 08:07:26 --> Total execution time: 0.2254
INFO - 2023-09-10 08:07:28 --> Config Class Initialized
INFO - 2023-09-10 08:07:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:07:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:07:28 --> Utf8 Class Initialized
INFO - 2023-09-10 08:07:28 --> URI Class Initialized
INFO - 2023-09-10 08:07:28 --> Router Class Initialized
INFO - 2023-09-10 08:07:28 --> Output Class Initialized
INFO - 2023-09-10 08:07:28 --> Security Class Initialized
DEBUG - 2023-09-10 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:07:28 --> Input Class Initialized
INFO - 2023-09-10 08:07:28 --> Language Class Initialized
ERROR - 2023-09-10 08:07:28 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:07:47 --> Config Class Initialized
INFO - 2023-09-10 08:07:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:07:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:07:47 --> Utf8 Class Initialized
INFO - 2023-09-10 08:07:47 --> URI Class Initialized
INFO - 2023-09-10 08:07:47 --> Router Class Initialized
INFO - 2023-09-10 08:07:47 --> Output Class Initialized
INFO - 2023-09-10 08:07:47 --> Security Class Initialized
DEBUG - 2023-09-10 08:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:07:47 --> Input Class Initialized
INFO - 2023-09-10 08:07:47 --> Language Class Initialized
INFO - 2023-09-10 08:07:47 --> Loader Class Initialized
INFO - 2023-09-10 08:07:47 --> Helper loaded: url_helper
INFO - 2023-09-10 08:07:47 --> Helper loaded: file_helper
INFO - 2023-09-10 08:07:47 --> Database Driver Class Initialized
INFO - 2023-09-10 08:07:47 --> Email Class Initialized
DEBUG - 2023-09-10 08:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:07:47 --> Controller Class Initialized
INFO - 2023-09-10 08:07:47 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:07:47 --> Model "Home_model" initialized
INFO - 2023-09-10 08:07:47 --> Helper loaded: download_helper
INFO - 2023-09-10 08:07:47 --> Helper loaded: form_helper
INFO - 2023-09-10 08:07:47 --> Form Validation Class Initialized
INFO - 2023-09-10 08:07:47 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:07:47 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:07:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:07:47 --> Final output sent to browser
DEBUG - 2023-09-10 08:07:48 --> Total execution time: 0.4151
INFO - 2023-09-10 08:07:49 --> Config Class Initialized
INFO - 2023-09-10 08:07:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:07:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:07:49 --> Utf8 Class Initialized
INFO - 2023-09-10 08:07:49 --> URI Class Initialized
INFO - 2023-09-10 08:07:49 --> Router Class Initialized
INFO - 2023-09-10 08:07:49 --> Output Class Initialized
INFO - 2023-09-10 08:07:49 --> Security Class Initialized
DEBUG - 2023-09-10 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:07:49 --> Input Class Initialized
INFO - 2023-09-10 08:07:49 --> Language Class Initialized
ERROR - 2023-09-10 08:07:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:10:23 --> Config Class Initialized
INFO - 2023-09-10 08:10:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:10:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:10:23 --> Utf8 Class Initialized
INFO - 2023-09-10 08:10:23 --> URI Class Initialized
INFO - 2023-09-10 08:10:23 --> Router Class Initialized
INFO - 2023-09-10 08:10:23 --> Output Class Initialized
INFO - 2023-09-10 08:10:23 --> Security Class Initialized
DEBUG - 2023-09-10 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:10:23 --> Input Class Initialized
INFO - 2023-09-10 08:10:23 --> Language Class Initialized
INFO - 2023-09-10 08:10:23 --> Loader Class Initialized
INFO - 2023-09-10 08:10:23 --> Helper loaded: url_helper
INFO - 2023-09-10 08:10:23 --> Helper loaded: file_helper
INFO - 2023-09-10 08:10:23 --> Database Driver Class Initialized
INFO - 2023-09-10 08:10:23 --> Email Class Initialized
DEBUG - 2023-09-10 08:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:10:23 --> Controller Class Initialized
INFO - 2023-09-10 08:10:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:10:23 --> Model "Home_model" initialized
INFO - 2023-09-10 08:10:23 --> Helper loaded: download_helper
INFO - 2023-09-10 08:10:23 --> Helper loaded: form_helper
INFO - 2023-09-10 08:10:23 --> Form Validation Class Initialized
INFO - 2023-09-10 08:10:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:10:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:10:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:10:23 --> Final output sent to browser
DEBUG - 2023-09-10 08:10:23 --> Total execution time: 0.1876
INFO - 2023-09-10 08:10:24 --> Config Class Initialized
INFO - 2023-09-10 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:10:24 --> Utf8 Class Initialized
INFO - 2023-09-10 08:10:24 --> URI Class Initialized
INFO - 2023-09-10 08:10:24 --> Router Class Initialized
INFO - 2023-09-10 08:10:24 --> Output Class Initialized
INFO - 2023-09-10 08:10:24 --> Security Class Initialized
DEBUG - 2023-09-10 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:10:24 --> Input Class Initialized
INFO - 2023-09-10 08:10:24 --> Language Class Initialized
ERROR - 2023-09-10 08:10:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:16:08 --> Config Class Initialized
INFO - 2023-09-10 08:16:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:16:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:16:08 --> Utf8 Class Initialized
INFO - 2023-09-10 08:16:08 --> URI Class Initialized
INFO - 2023-09-10 08:16:08 --> Router Class Initialized
INFO - 2023-09-10 08:16:08 --> Output Class Initialized
INFO - 2023-09-10 08:16:08 --> Security Class Initialized
DEBUG - 2023-09-10 08:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:16:08 --> Input Class Initialized
INFO - 2023-09-10 08:16:08 --> Language Class Initialized
INFO - 2023-09-10 08:16:08 --> Loader Class Initialized
INFO - 2023-09-10 08:16:08 --> Helper loaded: url_helper
INFO - 2023-09-10 08:16:08 --> Helper loaded: file_helper
INFO - 2023-09-10 08:16:08 --> Database Driver Class Initialized
INFO - 2023-09-10 08:16:08 --> Email Class Initialized
DEBUG - 2023-09-10 08:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:16:08 --> Controller Class Initialized
INFO - 2023-09-10 08:16:08 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:16:08 --> Model "Home_model" initialized
INFO - 2023-09-10 08:16:08 --> Helper loaded: download_helper
INFO - 2023-09-10 08:16:08 --> Helper loaded: form_helper
INFO - 2023-09-10 08:16:08 --> Form Validation Class Initialized
INFO - 2023-09-10 08:16:08 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:16:08 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:16:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:16:09 --> Final output sent to browser
DEBUG - 2023-09-10 08:16:09 --> Total execution time: 0.6078
INFO - 2023-09-10 08:16:09 --> Config Class Initialized
INFO - 2023-09-10 08:16:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:16:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:16:09 --> Utf8 Class Initialized
INFO - 2023-09-10 08:16:09 --> URI Class Initialized
INFO - 2023-09-10 08:16:09 --> Router Class Initialized
INFO - 2023-09-10 08:16:09 --> Output Class Initialized
INFO - 2023-09-10 08:16:09 --> Security Class Initialized
DEBUG - 2023-09-10 08:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:16:09 --> Input Class Initialized
INFO - 2023-09-10 08:16:09 --> Language Class Initialized
ERROR - 2023-09-10 08:16:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:23:37 --> Config Class Initialized
INFO - 2023-09-10 08:23:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:23:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:23:37 --> Utf8 Class Initialized
INFO - 2023-09-10 08:23:37 --> URI Class Initialized
INFO - 2023-09-10 08:23:37 --> Router Class Initialized
INFO - 2023-09-10 08:23:37 --> Output Class Initialized
INFO - 2023-09-10 08:23:37 --> Security Class Initialized
DEBUG - 2023-09-10 08:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:23:37 --> Input Class Initialized
INFO - 2023-09-10 08:23:37 --> Language Class Initialized
INFO - 2023-09-10 08:23:37 --> Loader Class Initialized
INFO - 2023-09-10 08:23:37 --> Helper loaded: url_helper
INFO - 2023-09-10 08:23:37 --> Helper loaded: file_helper
INFO - 2023-09-10 08:23:38 --> Database Driver Class Initialized
INFO - 2023-09-10 08:23:38 --> Email Class Initialized
DEBUG - 2023-09-10 08:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:23:38 --> Controller Class Initialized
INFO - 2023-09-10 08:23:38 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:23:38 --> Model "Home_model" initialized
INFO - 2023-09-10 08:23:38 --> Helper loaded: download_helper
INFO - 2023-09-10 08:23:38 --> Helper loaded: form_helper
INFO - 2023-09-10 08:23:38 --> Form Validation Class Initialized
INFO - 2023-09-10 08:23:38 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:23:38 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:23:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:23:38 --> Final output sent to browser
DEBUG - 2023-09-10 08:23:38 --> Total execution time: 1.5726
INFO - 2023-09-10 08:23:39 --> Config Class Initialized
INFO - 2023-09-10 08:23:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:23:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:23:39 --> Utf8 Class Initialized
INFO - 2023-09-10 08:23:39 --> URI Class Initialized
INFO - 2023-09-10 08:23:39 --> Router Class Initialized
INFO - 2023-09-10 08:23:39 --> Output Class Initialized
INFO - 2023-09-10 08:23:39 --> Security Class Initialized
DEBUG - 2023-09-10 08:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:23:39 --> Input Class Initialized
INFO - 2023-09-10 08:23:39 --> Language Class Initialized
ERROR - 2023-09-10 08:23:39 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:23:51 --> Config Class Initialized
INFO - 2023-09-10 08:23:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:23:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:23:51 --> Utf8 Class Initialized
INFO - 2023-09-10 08:23:51 --> URI Class Initialized
INFO - 2023-09-10 08:23:51 --> Router Class Initialized
INFO - 2023-09-10 08:23:51 --> Output Class Initialized
INFO - 2023-09-10 08:23:51 --> Security Class Initialized
DEBUG - 2023-09-10 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:23:51 --> Input Class Initialized
INFO - 2023-09-10 08:23:51 --> Language Class Initialized
INFO - 2023-09-10 08:23:52 --> Loader Class Initialized
INFO - 2023-09-10 08:23:52 --> Helper loaded: url_helper
INFO - 2023-09-10 08:23:52 --> Helper loaded: file_helper
INFO - 2023-09-10 08:23:52 --> Database Driver Class Initialized
INFO - 2023-09-10 08:23:52 --> Email Class Initialized
DEBUG - 2023-09-10 08:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:23:52 --> Controller Class Initialized
INFO - 2023-09-10 08:23:52 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:23:52 --> Model "Home_model" initialized
INFO - 2023-09-10 08:23:52 --> Helper loaded: download_helper
INFO - 2023-09-10 08:23:52 --> Helper loaded: form_helper
INFO - 2023-09-10 08:23:52 --> Form Validation Class Initialized
INFO - 2023-09-10 08:23:52 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:23:52 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:23:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:23:52 --> Final output sent to browser
DEBUG - 2023-09-10 08:23:52 --> Total execution time: 1.0421
INFO - 2023-09-10 08:23:53 --> Config Class Initialized
INFO - 2023-09-10 08:23:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:23:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:23:53 --> Utf8 Class Initialized
INFO - 2023-09-10 08:23:53 --> URI Class Initialized
INFO - 2023-09-10 08:23:53 --> Router Class Initialized
INFO - 2023-09-10 08:23:53 --> Output Class Initialized
INFO - 2023-09-10 08:23:53 --> Security Class Initialized
DEBUG - 2023-09-10 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:23:53 --> Input Class Initialized
INFO - 2023-09-10 08:23:53 --> Language Class Initialized
ERROR - 2023-09-10 08:23:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:25:07 --> Config Class Initialized
INFO - 2023-09-10 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:25:08 --> Utf8 Class Initialized
INFO - 2023-09-10 08:25:08 --> URI Class Initialized
INFO - 2023-09-10 08:25:08 --> Router Class Initialized
INFO - 2023-09-10 08:25:08 --> Output Class Initialized
INFO - 2023-09-10 08:25:08 --> Security Class Initialized
DEBUG - 2023-09-10 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:25:08 --> Input Class Initialized
INFO - 2023-09-10 08:25:08 --> Language Class Initialized
INFO - 2023-09-10 08:25:08 --> Loader Class Initialized
INFO - 2023-09-10 08:25:08 --> Helper loaded: url_helper
INFO - 2023-09-10 08:25:08 --> Helper loaded: file_helper
INFO - 2023-09-10 08:25:08 --> Database Driver Class Initialized
INFO - 2023-09-10 08:25:08 --> Email Class Initialized
DEBUG - 2023-09-10 08:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:25:08 --> Controller Class Initialized
INFO - 2023-09-10 08:25:08 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:25:08 --> Model "Home_model" initialized
INFO - 2023-09-10 08:25:08 --> Helper loaded: download_helper
INFO - 2023-09-10 08:25:08 --> Helper loaded: form_helper
INFO - 2023-09-10 08:25:08 --> Form Validation Class Initialized
INFO - 2023-09-10 08:25:08 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:25:08 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:25:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:25:08 --> Final output sent to browser
DEBUG - 2023-09-10 08:25:08 --> Total execution time: 0.8994
INFO - 2023-09-10 08:25:09 --> Config Class Initialized
INFO - 2023-09-10 08:25:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:25:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:25:09 --> Utf8 Class Initialized
INFO - 2023-09-10 08:25:09 --> URI Class Initialized
INFO - 2023-09-10 08:25:09 --> Router Class Initialized
INFO - 2023-09-10 08:25:09 --> Output Class Initialized
INFO - 2023-09-10 08:25:09 --> Security Class Initialized
DEBUG - 2023-09-10 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:25:09 --> Input Class Initialized
INFO - 2023-09-10 08:25:09 --> Language Class Initialized
ERROR - 2023-09-10 08:25:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:25:40 --> Config Class Initialized
INFO - 2023-09-10 08:25:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:25:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:25:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:25:40 --> URI Class Initialized
INFO - 2023-09-10 08:25:40 --> Router Class Initialized
INFO - 2023-09-10 08:25:40 --> Output Class Initialized
INFO - 2023-09-10 08:25:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:25:40 --> Input Class Initialized
INFO - 2023-09-10 08:25:40 --> Language Class Initialized
INFO - 2023-09-10 08:25:40 --> Loader Class Initialized
INFO - 2023-09-10 08:25:40 --> Helper loaded: url_helper
INFO - 2023-09-10 08:25:40 --> Helper loaded: file_helper
INFO - 2023-09-10 08:25:40 --> Database Driver Class Initialized
INFO - 2023-09-10 08:25:40 --> Email Class Initialized
DEBUG - 2023-09-10 08:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:25:40 --> Controller Class Initialized
INFO - 2023-09-10 08:25:40 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:25:40 --> Model "Home_model" initialized
INFO - 2023-09-10 08:25:40 --> Helper loaded: download_helper
INFO - 2023-09-10 08:25:40 --> Helper loaded: form_helper
INFO - 2023-09-10 08:25:40 --> Form Validation Class Initialized
INFO - 2023-09-10 08:25:40 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:25:40 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:25:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:25:40 --> Final output sent to browser
DEBUG - 2023-09-10 08:25:40 --> Total execution time: 0.7851
INFO - 2023-09-10 08:25:41 --> Config Class Initialized
INFO - 2023-09-10 08:25:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:25:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:25:41 --> Utf8 Class Initialized
INFO - 2023-09-10 08:25:41 --> URI Class Initialized
INFO - 2023-09-10 08:25:41 --> Router Class Initialized
INFO - 2023-09-10 08:25:41 --> Output Class Initialized
INFO - 2023-09-10 08:25:41 --> Security Class Initialized
DEBUG - 2023-09-10 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:25:41 --> Input Class Initialized
INFO - 2023-09-10 08:25:41 --> Language Class Initialized
ERROR - 2023-09-10 08:25:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:26:14 --> Config Class Initialized
INFO - 2023-09-10 08:26:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:26:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:26:14 --> Utf8 Class Initialized
INFO - 2023-09-10 08:26:14 --> URI Class Initialized
INFO - 2023-09-10 08:26:14 --> Router Class Initialized
INFO - 2023-09-10 08:26:14 --> Output Class Initialized
INFO - 2023-09-10 08:26:14 --> Security Class Initialized
DEBUG - 2023-09-10 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:26:15 --> Input Class Initialized
INFO - 2023-09-10 08:26:15 --> Language Class Initialized
INFO - 2023-09-10 08:26:15 --> Loader Class Initialized
INFO - 2023-09-10 08:26:15 --> Helper loaded: url_helper
INFO - 2023-09-10 08:26:15 --> Helper loaded: file_helper
INFO - 2023-09-10 08:26:15 --> Database Driver Class Initialized
INFO - 2023-09-10 08:26:15 --> Email Class Initialized
DEBUG - 2023-09-10 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:26:15 --> Controller Class Initialized
INFO - 2023-09-10 08:26:15 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:26:15 --> Model "Home_model" initialized
INFO - 2023-09-10 08:26:15 --> Helper loaded: download_helper
INFO - 2023-09-10 08:26:15 --> Helper loaded: form_helper
INFO - 2023-09-10 08:26:15 --> Form Validation Class Initialized
INFO - 2023-09-10 08:26:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:26:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:26:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:26:15 --> Final output sent to browser
DEBUG - 2023-09-10 08:26:15 --> Total execution time: 0.6495
INFO - 2023-09-10 08:26:17 --> Config Class Initialized
INFO - 2023-09-10 08:26:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:26:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:26:17 --> Utf8 Class Initialized
INFO - 2023-09-10 08:26:17 --> URI Class Initialized
INFO - 2023-09-10 08:26:17 --> Router Class Initialized
INFO - 2023-09-10 08:26:17 --> Output Class Initialized
INFO - 2023-09-10 08:26:17 --> Security Class Initialized
DEBUG - 2023-09-10 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:26:17 --> Input Class Initialized
INFO - 2023-09-10 08:26:17 --> Language Class Initialized
ERROR - 2023-09-10 08:26:17 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:26:31 --> Config Class Initialized
INFO - 2023-09-10 08:26:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:26:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:26:31 --> Utf8 Class Initialized
INFO - 2023-09-10 08:26:31 --> URI Class Initialized
INFO - 2023-09-10 08:26:31 --> Router Class Initialized
INFO - 2023-09-10 08:26:32 --> Output Class Initialized
INFO - 2023-09-10 08:26:32 --> Security Class Initialized
DEBUG - 2023-09-10 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:26:32 --> Input Class Initialized
INFO - 2023-09-10 08:26:32 --> Language Class Initialized
INFO - 2023-09-10 08:26:32 --> Loader Class Initialized
INFO - 2023-09-10 08:26:32 --> Helper loaded: url_helper
INFO - 2023-09-10 08:26:32 --> Helper loaded: file_helper
INFO - 2023-09-10 08:26:32 --> Database Driver Class Initialized
INFO - 2023-09-10 08:26:32 --> Email Class Initialized
DEBUG - 2023-09-10 08:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:26:32 --> Controller Class Initialized
INFO - 2023-09-10 08:26:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:26:32 --> Model "Home_model" initialized
INFO - 2023-09-10 08:26:32 --> Helper loaded: download_helper
INFO - 2023-09-10 08:26:32 --> Helper loaded: form_helper
INFO - 2023-09-10 08:26:32 --> Form Validation Class Initialized
INFO - 2023-09-10 08:26:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:26:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:26:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 08:26:32 --> Final output sent to browser
DEBUG - 2023-09-10 08:26:32 --> Total execution time: 1.1694
INFO - 2023-09-10 08:26:33 --> Config Class Initialized
INFO - 2023-09-10 08:26:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:26:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:26:33 --> Utf8 Class Initialized
INFO - 2023-09-10 08:26:33 --> URI Class Initialized
INFO - 2023-09-10 08:26:33 --> Router Class Initialized
INFO - 2023-09-10 08:26:33 --> Output Class Initialized
INFO - 2023-09-10 08:26:33 --> Security Class Initialized
DEBUG - 2023-09-10 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:26:33 --> Input Class Initialized
INFO - 2023-09-10 08:26:33 --> Language Class Initialized
ERROR - 2023-09-10 08:26:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:27:22 --> Config Class Initialized
INFO - 2023-09-10 08:27:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:27:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:27:22 --> Utf8 Class Initialized
INFO - 2023-09-10 08:27:22 --> URI Class Initialized
INFO - 2023-09-10 08:27:22 --> Router Class Initialized
INFO - 2023-09-10 08:27:22 --> Output Class Initialized
INFO - 2023-09-10 08:27:22 --> Security Class Initialized
DEBUG - 2023-09-10 08:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:27:22 --> Input Class Initialized
INFO - 2023-09-10 08:27:22 --> Language Class Initialized
INFO - 2023-09-10 08:27:22 --> Loader Class Initialized
INFO - 2023-09-10 08:27:22 --> Helper loaded: url_helper
INFO - 2023-09-10 08:27:22 --> Helper loaded: file_helper
INFO - 2023-09-10 08:27:23 --> Database Driver Class Initialized
INFO - 2023-09-10 08:27:23 --> Email Class Initialized
DEBUG - 2023-09-10 08:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:27:23 --> Controller Class Initialized
INFO - 2023-09-10 08:27:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:27:23 --> Model "Home_model" initialized
INFO - 2023-09-10 08:27:23 --> Helper loaded: download_helper
INFO - 2023-09-10 08:27:23 --> Helper loaded: form_helper
INFO - 2023-09-10 08:27:23 --> Form Validation Class Initialized
INFO - 2023-09-10 08:27:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:27:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:27:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 08:27:23 --> Final output sent to browser
DEBUG - 2023-09-10 08:27:23 --> Total execution time: 1.1450
INFO - 2023-09-10 08:27:24 --> Config Class Initialized
INFO - 2023-09-10 08:27:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:27:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:27:24 --> Utf8 Class Initialized
INFO - 2023-09-10 08:27:24 --> URI Class Initialized
INFO - 2023-09-10 08:27:24 --> Router Class Initialized
INFO - 2023-09-10 08:27:24 --> Output Class Initialized
INFO - 2023-09-10 08:27:24 --> Security Class Initialized
DEBUG - 2023-09-10 08:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:27:24 --> Input Class Initialized
INFO - 2023-09-10 08:27:24 --> Language Class Initialized
ERROR - 2023-09-10 08:27:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:27:35 --> Config Class Initialized
INFO - 2023-09-10 08:27:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:27:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:27:35 --> Utf8 Class Initialized
INFO - 2023-09-10 08:27:35 --> URI Class Initialized
DEBUG - 2023-09-10 08:27:35 --> No URI present. Default controller set.
INFO - 2023-09-10 08:27:35 --> Router Class Initialized
INFO - 2023-09-10 08:27:35 --> Output Class Initialized
INFO - 2023-09-10 08:27:35 --> Security Class Initialized
DEBUG - 2023-09-10 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:27:35 --> Input Class Initialized
INFO - 2023-09-10 08:27:35 --> Language Class Initialized
INFO - 2023-09-10 08:27:35 --> Loader Class Initialized
INFO - 2023-09-10 08:27:35 --> Helper loaded: url_helper
INFO - 2023-09-10 08:27:35 --> Helper loaded: file_helper
INFO - 2023-09-10 08:27:35 --> Database Driver Class Initialized
INFO - 2023-09-10 08:27:35 --> Email Class Initialized
DEBUG - 2023-09-10 08:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:27:35 --> Controller Class Initialized
INFO - 2023-09-10 08:27:35 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:27:35 --> Model "Home_model" initialized
INFO - 2023-09-10 08:27:35 --> Helper loaded: download_helper
INFO - 2023-09-10 08:27:35 --> Helper loaded: form_helper
INFO - 2023-09-10 08:27:35 --> Form Validation Class Initialized
INFO - 2023-09-10 08:27:35 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:27:35 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:27:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:27:35 --> Final output sent to browser
DEBUG - 2023-09-10 08:27:35 --> Total execution time: 0.2092
INFO - 2023-09-10 08:27:36 --> Config Class Initialized
INFO - 2023-09-10 08:27:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:27:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:27:36 --> Utf8 Class Initialized
INFO - 2023-09-10 08:27:36 --> URI Class Initialized
INFO - 2023-09-10 08:27:36 --> Router Class Initialized
INFO - 2023-09-10 08:27:36 --> Output Class Initialized
INFO - 2023-09-10 08:27:36 --> Security Class Initialized
DEBUG - 2023-09-10 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:27:36 --> Input Class Initialized
INFO - 2023-09-10 08:27:36 --> Language Class Initialized
ERROR - 2023-09-10 08:27:36 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:04 --> Config Class Initialized
INFO - 2023-09-10 08:29:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:04 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:04 --> URI Class Initialized
INFO - 2023-09-10 08:29:04 --> Router Class Initialized
INFO - 2023-09-10 08:29:04 --> Output Class Initialized
INFO - 2023-09-10 08:29:04 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:04 --> Input Class Initialized
INFO - 2023-09-10 08:29:04 --> Language Class Initialized
INFO - 2023-09-10 08:29:04 --> Loader Class Initialized
INFO - 2023-09-10 08:29:04 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:04 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:04 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:04 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:04 --> Controller Class Initialized
INFO - 2023-09-10 08:29:04 --> Model "User_model" initialized
INFO - 2023-09-10 08:29:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-10 08:29:04 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:04 --> Total execution time: 0.3967
INFO - 2023-09-10 08:29:05 --> Config Class Initialized
INFO - 2023-09-10 08:29:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:05 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:05 --> URI Class Initialized
INFO - 2023-09-10 08:29:05 --> Router Class Initialized
INFO - 2023-09-10 08:29:05 --> Output Class Initialized
INFO - 2023-09-10 08:29:05 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:05 --> Input Class Initialized
INFO - 2023-09-10 08:29:05 --> Language Class Initialized
ERROR - 2023-09-10 08:29:05 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-10 08:29:12 --> Config Class Initialized
INFO - 2023-09-10 08:29:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:12 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:12 --> URI Class Initialized
INFO - 2023-09-10 08:29:12 --> Router Class Initialized
INFO - 2023-09-10 08:29:12 --> Output Class Initialized
INFO - 2023-09-10 08:29:12 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:12 --> Input Class Initialized
INFO - 2023-09-10 08:29:12 --> Language Class Initialized
INFO - 2023-09-10 08:29:12 --> Loader Class Initialized
INFO - 2023-09-10 08:29:12 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:12 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:12 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:12 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:12 --> Controller Class Initialized
INFO - 2023-09-10 08:29:12 --> Model "User_model" initialized
INFO - 2023-09-10 08:29:12 --> Config Class Initialized
INFO - 2023-09-10 08:29:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:12 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:12 --> URI Class Initialized
INFO - 2023-09-10 08:29:12 --> Router Class Initialized
INFO - 2023-09-10 08:29:12 --> Output Class Initialized
INFO - 2023-09-10 08:29:12 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:12 --> Input Class Initialized
INFO - 2023-09-10 08:29:12 --> Language Class Initialized
INFO - 2023-09-10 08:29:12 --> Loader Class Initialized
INFO - 2023-09-10 08:29:12 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:12 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:12 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:12 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:12 --> Controller Class Initialized
INFO - 2023-09-10 08:29:12 --> Model "User_model" initialized
INFO - 2023-09-10 08:29:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-10 08:29:12 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:12 --> Total execution time: 0.0386
INFO - 2023-09-10 08:29:20 --> Config Class Initialized
INFO - 2023-09-10 08:29:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:20 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:20 --> URI Class Initialized
INFO - 2023-09-10 08:29:20 --> Router Class Initialized
INFO - 2023-09-10 08:29:20 --> Output Class Initialized
INFO - 2023-09-10 08:29:20 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:20 --> Input Class Initialized
INFO - 2023-09-10 08:29:20 --> Language Class Initialized
INFO - 2023-09-10 08:29:20 --> Loader Class Initialized
INFO - 2023-09-10 08:29:20 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:20 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:20 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:20 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:20 --> Controller Class Initialized
INFO - 2023-09-10 08:29:20 --> Model "User_model" initialized
INFO - 2023-09-10 08:29:20 --> Config Class Initialized
INFO - 2023-09-10 08:29:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:20 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:20 --> URI Class Initialized
INFO - 2023-09-10 08:29:20 --> Router Class Initialized
INFO - 2023-09-10 08:29:20 --> Output Class Initialized
INFO - 2023-09-10 08:29:20 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:20 --> Input Class Initialized
INFO - 2023-09-10 08:29:20 --> Language Class Initialized
INFO - 2023-09-10 08:29:20 --> Loader Class Initialized
INFO - 2023-09-10 08:29:20 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:20 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:20 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:20 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:20 --> Controller Class Initialized
INFO - 2023-09-10 08:29:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-10 08:29:20 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:21 --> Total execution time: 0.2843
INFO - 2023-09-10 08:29:25 --> Config Class Initialized
INFO - 2023-09-10 08:29:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:25 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:25 --> URI Class Initialized
INFO - 2023-09-10 08:29:25 --> Router Class Initialized
INFO - 2023-09-10 08:29:25 --> Output Class Initialized
INFO - 2023-09-10 08:29:25 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:25 --> Input Class Initialized
INFO - 2023-09-10 08:29:25 --> Language Class Initialized
INFO - 2023-09-10 08:29:25 --> Loader Class Initialized
INFO - 2023-09-10 08:29:25 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:25 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:25 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:25 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:25 --> Controller Class Initialized
INFO - 2023-09-10 08:29:25 --> Model "Services_model" initialized
INFO - 2023-09-10 08:29:25 --> Helper loaded: form_helper
INFO - 2023-09-10 08:29:25 --> Form Validation Class Initialized
INFO - 2023-09-10 08:29:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 08:29:25 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:25 --> Total execution time: 0.1891
INFO - 2023-09-10 08:29:26 --> Config Class Initialized
INFO - 2023-09-10 08:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:26 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:26 --> URI Class Initialized
INFO - 2023-09-10 08:29:26 --> Router Class Initialized
INFO - 2023-09-10 08:29:26 --> Output Class Initialized
INFO - 2023-09-10 08:29:26 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:26 --> Input Class Initialized
INFO - 2023-09-10 08:29:26 --> Language Class Initialized
ERROR - 2023-09-10 08:29:26 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:26 --> Config Class Initialized
INFO - 2023-09-10 08:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:26 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:26 --> URI Class Initialized
INFO - 2023-09-10 08:29:26 --> Router Class Initialized
INFO - 2023-09-10 08:29:26 --> Output Class Initialized
INFO - 2023-09-10 08:29:26 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:26 --> Input Class Initialized
INFO - 2023-09-10 08:29:26 --> Language Class Initialized
ERROR - 2023-09-10 08:29:26 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:26 --> Config Class Initialized
INFO - 2023-09-10 08:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:26 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:26 --> URI Class Initialized
INFO - 2023-09-10 08:29:26 --> Router Class Initialized
INFO - 2023-09-10 08:29:26 --> Output Class Initialized
INFO - 2023-09-10 08:29:26 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:26 --> Input Class Initialized
INFO - 2023-09-10 08:29:26 --> Language Class Initialized
ERROR - 2023-09-10 08:29:26 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:27 --> Config Class Initialized
INFO - 2023-09-10 08:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:27 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:27 --> URI Class Initialized
INFO - 2023-09-10 08:29:27 --> Router Class Initialized
INFO - 2023-09-10 08:29:27 --> Output Class Initialized
INFO - 2023-09-10 08:29:27 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:27 --> Input Class Initialized
INFO - 2023-09-10 08:29:27 --> Language Class Initialized
ERROR - 2023-09-10 08:29:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:27 --> Config Class Initialized
INFO - 2023-09-10 08:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:27 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:27 --> URI Class Initialized
INFO - 2023-09-10 08:29:27 --> Router Class Initialized
INFO - 2023-09-10 08:29:27 --> Output Class Initialized
INFO - 2023-09-10 08:29:27 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:27 --> Input Class Initialized
INFO - 2023-09-10 08:29:27 --> Language Class Initialized
ERROR - 2023-09-10 08:29:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:27 --> Config Class Initialized
INFO - 2023-09-10 08:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:27 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:27 --> URI Class Initialized
INFO - 2023-09-10 08:29:27 --> Router Class Initialized
INFO - 2023-09-10 08:29:27 --> Output Class Initialized
INFO - 2023-09-10 08:29:27 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:27 --> Input Class Initialized
INFO - 2023-09-10 08:29:27 --> Language Class Initialized
ERROR - 2023-09-10 08:29:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:27 --> Config Class Initialized
INFO - 2023-09-10 08:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:27 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:27 --> URI Class Initialized
INFO - 2023-09-10 08:29:27 --> Router Class Initialized
INFO - 2023-09-10 08:29:27 --> Output Class Initialized
INFO - 2023-09-10 08:29:27 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:27 --> Input Class Initialized
INFO - 2023-09-10 08:29:27 --> Language Class Initialized
INFO - 2023-09-10 08:29:27 --> Loader Class Initialized
INFO - 2023-09-10 08:29:27 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:27 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:27 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:27 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:27 --> Controller Class Initialized
INFO - 2023-09-10 08:29:27 --> Model "Services_model" initialized
INFO - 2023-09-10 08:29:27 --> Helper loaded: form_helper
INFO - 2023-09-10 08:29:27 --> Form Validation Class Initialized
INFO - 2023-09-10 08:29:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-10 08:29:28 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:28 --> Total execution time: 0.3147
INFO - 2023-09-10 08:29:28 --> Config Class Initialized
INFO - 2023-09-10 08:29:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:28 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:28 --> URI Class Initialized
INFO - 2023-09-10 08:29:28 --> Router Class Initialized
INFO - 2023-09-10 08:29:28 --> Output Class Initialized
INFO - 2023-09-10 08:29:28 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:28 --> Input Class Initialized
INFO - 2023-09-10 08:29:28 --> Language Class Initialized
ERROR - 2023-09-10 08:29:28 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-10 08:29:38 --> Config Class Initialized
INFO - 2023-09-10 08:29:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:38 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:38 --> URI Class Initialized
INFO - 2023-09-10 08:29:38 --> Router Class Initialized
INFO - 2023-09-10 08:29:38 --> Output Class Initialized
INFO - 2023-09-10 08:29:38 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:38 --> Input Class Initialized
INFO - 2023-09-10 08:29:38 --> Language Class Initialized
INFO - 2023-09-10 08:29:38 --> Loader Class Initialized
INFO - 2023-09-10 08:29:39 --> Helper loaded: url_helper
INFO - 2023-09-10 08:29:39 --> Helper loaded: file_helper
INFO - 2023-09-10 08:29:39 --> Database Driver Class Initialized
INFO - 2023-09-10 08:29:39 --> Email Class Initialized
DEBUG - 2023-09-10 08:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:29:39 --> Controller Class Initialized
INFO - 2023-09-10 08:29:39 --> Model "Services_model" initialized
INFO - 2023-09-10 08:29:39 --> Helper loaded: form_helper
INFO - 2023-09-10 08:29:39 --> Form Validation Class Initialized
INFO - 2023-09-10 08:29:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 08:29:39 --> Final output sent to browser
DEBUG - 2023-09-10 08:29:39 --> Total execution time: 0.3261
INFO - 2023-09-10 08:29:39 --> Config Class Initialized
INFO - 2023-09-10 08:29:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:39 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:39 --> URI Class Initialized
INFO - 2023-09-10 08:29:39 --> Router Class Initialized
INFO - 2023-09-10 08:29:39 --> Output Class Initialized
INFO - 2023-09-10 08:29:39 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:39 --> Input Class Initialized
INFO - 2023-09-10 08:29:39 --> Language Class Initialized
ERROR - 2023-09-10 08:29:39 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:40 --> Config Class Initialized
INFO - 2023-09-10 08:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:40 --> URI Class Initialized
INFO - 2023-09-10 08:29:40 --> Router Class Initialized
INFO - 2023-09-10 08:29:40 --> Output Class Initialized
INFO - 2023-09-10 08:29:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:40 --> Input Class Initialized
INFO - 2023-09-10 08:29:40 --> Language Class Initialized
ERROR - 2023-09-10 08:29:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:40 --> Config Class Initialized
INFO - 2023-09-10 08:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:40 --> URI Class Initialized
INFO - 2023-09-10 08:29:40 --> Router Class Initialized
INFO - 2023-09-10 08:29:40 --> Output Class Initialized
INFO - 2023-09-10 08:29:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:40 --> Input Class Initialized
INFO - 2023-09-10 08:29:40 --> Language Class Initialized
ERROR - 2023-09-10 08:29:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:40 --> Config Class Initialized
INFO - 2023-09-10 08:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:40 --> URI Class Initialized
INFO - 2023-09-10 08:29:40 --> Router Class Initialized
INFO - 2023-09-10 08:29:40 --> Output Class Initialized
INFO - 2023-09-10 08:29:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:40 --> Input Class Initialized
INFO - 2023-09-10 08:29:40 --> Language Class Initialized
ERROR - 2023-09-10 08:29:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:40 --> Config Class Initialized
INFO - 2023-09-10 08:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:40 --> URI Class Initialized
INFO - 2023-09-10 08:29:40 --> Router Class Initialized
INFO - 2023-09-10 08:29:40 --> Output Class Initialized
INFO - 2023-09-10 08:29:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:40 --> Input Class Initialized
INFO - 2023-09-10 08:29:40 --> Language Class Initialized
ERROR - 2023-09-10 08:29:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:29:40 --> Config Class Initialized
INFO - 2023-09-10 08:29:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:29:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:29:40 --> Utf8 Class Initialized
INFO - 2023-09-10 08:29:40 --> URI Class Initialized
INFO - 2023-09-10 08:29:40 --> Router Class Initialized
INFO - 2023-09-10 08:29:40 --> Output Class Initialized
INFO - 2023-09-10 08:29:40 --> Security Class Initialized
DEBUG - 2023-09-10 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:29:40 --> Input Class Initialized
INFO - 2023-09-10 08:29:41 --> Language Class Initialized
ERROR - 2023-09-10 08:29:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:44:32 --> Config Class Initialized
INFO - 2023-09-10 08:44:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:44:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:44:32 --> Utf8 Class Initialized
INFO - 2023-09-10 08:44:32 --> URI Class Initialized
DEBUG - 2023-09-10 08:44:32 --> No URI present. Default controller set.
INFO - 2023-09-10 08:44:32 --> Router Class Initialized
INFO - 2023-09-10 08:44:32 --> Output Class Initialized
INFO - 2023-09-10 08:44:32 --> Security Class Initialized
DEBUG - 2023-09-10 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:44:32 --> Input Class Initialized
INFO - 2023-09-10 08:44:32 --> Language Class Initialized
INFO - 2023-09-10 08:44:32 --> Loader Class Initialized
INFO - 2023-09-10 08:44:32 --> Helper loaded: url_helper
INFO - 2023-09-10 08:44:32 --> Helper loaded: file_helper
INFO - 2023-09-10 08:44:32 --> Database Driver Class Initialized
INFO - 2023-09-10 08:44:32 --> Email Class Initialized
DEBUG - 2023-09-10 08:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:44:32 --> Controller Class Initialized
INFO - 2023-09-10 08:44:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:44:32 --> Model "Home_model" initialized
INFO - 2023-09-10 08:44:32 --> Helper loaded: download_helper
INFO - 2023-09-10 08:44:32 --> Helper loaded: form_helper
INFO - 2023-09-10 08:44:32 --> Form Validation Class Initialized
INFO - 2023-09-10 08:44:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:44:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:44:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:44:32 --> Final output sent to browser
DEBUG - 2023-09-10 08:44:32 --> Total execution time: 0.4877
INFO - 2023-09-10 08:44:33 --> Config Class Initialized
INFO - 2023-09-10 08:44:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:44:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:44:33 --> Utf8 Class Initialized
INFO - 2023-09-10 08:44:33 --> URI Class Initialized
INFO - 2023-09-10 08:44:33 --> Router Class Initialized
INFO - 2023-09-10 08:44:33 --> Output Class Initialized
INFO - 2023-09-10 08:44:33 --> Security Class Initialized
DEBUG - 2023-09-10 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:44:33 --> Input Class Initialized
INFO - 2023-09-10 08:44:33 --> Language Class Initialized
ERROR - 2023-09-10 08:44:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:47:54 --> Config Class Initialized
INFO - 2023-09-10 08:47:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:47:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:47:54 --> Utf8 Class Initialized
INFO - 2023-09-10 08:47:54 --> URI Class Initialized
DEBUG - 2023-09-10 08:47:54 --> No URI present. Default controller set.
INFO - 2023-09-10 08:47:54 --> Router Class Initialized
INFO - 2023-09-10 08:47:54 --> Output Class Initialized
INFO - 2023-09-10 08:47:54 --> Security Class Initialized
DEBUG - 2023-09-10 08:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:47:54 --> Input Class Initialized
INFO - 2023-09-10 08:47:54 --> Language Class Initialized
INFO - 2023-09-10 08:47:54 --> Loader Class Initialized
INFO - 2023-09-10 08:47:54 --> Helper loaded: url_helper
INFO - 2023-09-10 08:47:54 --> Helper loaded: file_helper
INFO - 2023-09-10 08:47:54 --> Database Driver Class Initialized
INFO - 2023-09-10 08:47:54 --> Email Class Initialized
DEBUG - 2023-09-10 08:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:47:54 --> Controller Class Initialized
INFO - 2023-09-10 08:47:54 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:47:54 --> Model "Home_model" initialized
INFO - 2023-09-10 08:47:54 --> Helper loaded: download_helper
INFO - 2023-09-10 08:47:54 --> Helper loaded: form_helper
INFO - 2023-09-10 08:47:54 --> Form Validation Class Initialized
INFO - 2023-09-10 08:47:54 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:47:54 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:47:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 08:47:54 --> Final output sent to browser
DEBUG - 2023-09-10 08:47:54 --> Total execution time: 0.2865
INFO - 2023-09-10 08:47:58 --> Config Class Initialized
INFO - 2023-09-10 08:47:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:47:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:47:58 --> Utf8 Class Initialized
INFO - 2023-09-10 08:47:58 --> URI Class Initialized
INFO - 2023-09-10 08:47:58 --> Router Class Initialized
INFO - 2023-09-10 08:47:58 --> Output Class Initialized
INFO - 2023-09-10 08:47:58 --> Security Class Initialized
DEBUG - 2023-09-10 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:47:58 --> Input Class Initialized
INFO - 2023-09-10 08:47:58 --> Language Class Initialized
ERROR - 2023-09-10 08:47:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:49:44 --> Config Class Initialized
INFO - 2023-09-10 08:49:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:49:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:49:44 --> Utf8 Class Initialized
INFO - 2023-09-10 08:49:44 --> URI Class Initialized
INFO - 2023-09-10 08:49:44 --> Router Class Initialized
INFO - 2023-09-10 08:49:44 --> Output Class Initialized
INFO - 2023-09-10 08:49:44 --> Security Class Initialized
DEBUG - 2023-09-10 08:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:49:44 --> Input Class Initialized
INFO - 2023-09-10 08:49:44 --> Language Class Initialized
INFO - 2023-09-10 08:49:44 --> Loader Class Initialized
INFO - 2023-09-10 08:49:44 --> Helper loaded: url_helper
INFO - 2023-09-10 08:49:44 --> Helper loaded: file_helper
INFO - 2023-09-10 08:49:44 --> Database Driver Class Initialized
INFO - 2023-09-10 08:49:45 --> Email Class Initialized
DEBUG - 2023-09-10 08:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:49:45 --> Controller Class Initialized
INFO - 2023-09-10 08:49:45 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:49:45 --> Model "Home_model" initialized
INFO - 2023-09-10 08:49:45 --> Helper loaded: download_helper
INFO - 2023-09-10 08:49:45 --> Helper loaded: form_helper
INFO - 2023-09-10 08:49:45 --> Form Validation Class Initialized
INFO - 2023-09-10 08:49:45 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:49:45 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:49:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 08:49:45 --> Final output sent to browser
DEBUG - 2023-09-10 08:49:45 --> Total execution time: 0.5303
INFO - 2023-09-10 08:49:46 --> Config Class Initialized
INFO - 2023-09-10 08:49:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:49:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:49:46 --> Utf8 Class Initialized
INFO - 2023-09-10 08:49:46 --> URI Class Initialized
INFO - 2023-09-10 08:49:46 --> Router Class Initialized
INFO - 2023-09-10 08:49:46 --> Output Class Initialized
INFO - 2023-09-10 08:49:46 --> Security Class Initialized
DEBUG - 2023-09-10 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:49:46 --> Input Class Initialized
INFO - 2023-09-10 08:49:46 --> Language Class Initialized
ERROR - 2023-09-10 08:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:52:19 --> Config Class Initialized
INFO - 2023-09-10 08:52:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:52:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:19 --> Utf8 Class Initialized
INFO - 2023-09-10 08:52:19 --> URI Class Initialized
INFO - 2023-09-10 08:52:19 --> Router Class Initialized
INFO - 2023-09-10 08:52:19 --> Output Class Initialized
INFO - 2023-09-10 08:52:19 --> Security Class Initialized
DEBUG - 2023-09-10 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:19 --> Input Class Initialized
INFO - 2023-09-10 08:52:19 --> Language Class Initialized
INFO - 2023-09-10 08:52:19 --> Loader Class Initialized
INFO - 2023-09-10 08:52:19 --> Helper loaded: url_helper
INFO - 2023-09-10 08:52:19 --> Helper loaded: file_helper
INFO - 2023-09-10 08:52:19 --> Database Driver Class Initialized
INFO - 2023-09-10 08:52:19 --> Email Class Initialized
DEBUG - 2023-09-10 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:52:19 --> Controller Class Initialized
INFO - 2023-09-10 08:52:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:52:19 --> Model "Home_model" initialized
INFO - 2023-09-10 08:52:19 --> Helper loaded: download_helper
INFO - 2023-09-10 08:52:19 --> Helper loaded: form_helper
INFO - 2023-09-10 08:52:19 --> Form Validation Class Initialized
INFO - 2023-09-10 08:52:19 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:52:19 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:52:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 08:52:19 --> Final output sent to browser
DEBUG - 2023-09-10 08:52:20 --> Total execution time: 0.7512
INFO - 2023-09-10 08:52:20 --> Config Class Initialized
INFO - 2023-09-10 08:52:20 --> Config Class Initialized
INFO - 2023-09-10 08:52:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:21 --> Config Class Initialized
INFO - 2023-09-10 08:52:21 --> Utf8 Class Initialized
INFO - 2023-09-10 08:52:21 --> URI Class Initialized
INFO - 2023-09-10 08:52:21 --> Config Class Initialized
INFO - 2023-09-10 08:52:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:21 --> Utf8 Class Initialized
INFO - 2023-09-10 08:52:21 --> URI Class Initialized
INFO - 2023-09-10 08:52:21 --> Router Class Initialized
INFO - 2023-09-10 08:52:21 --> Output Class Initialized
INFO - 2023-09-10 08:52:21 --> Security Class Initialized
DEBUG - 2023-09-10 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:21 --> Input Class Initialized
INFO - 2023-09-10 08:52:21 --> Language Class Initialized
ERROR - 2023-09-10 08:52:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:52:21 --> Hooks Class Initialized
INFO - 2023-09-10 08:52:21 --> Config Class Initialized
INFO - 2023-09-10 08:52:21 --> Hooks Class Initialized
INFO - 2023-09-10 08:52:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:21 --> Router Class Initialized
DEBUG - 2023-09-10 08:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:21 --> Utf8 Class Initialized
INFO - 2023-09-10 08:52:21 --> Utf8 Class Initialized
DEBUG - 2023-09-10 08:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:52:21 --> URI Class Initialized
INFO - 2023-09-10 08:52:21 --> Output Class Initialized
INFO - 2023-09-10 08:52:21 --> URI Class Initialized
INFO - 2023-09-10 08:52:21 --> Router Class Initialized
INFO - 2023-09-10 08:52:21 --> Utf8 Class Initialized
INFO - 2023-09-10 08:52:21 --> Router Class Initialized
INFO - 2023-09-10 08:52:21 --> Security Class Initialized
INFO - 2023-09-10 08:52:21 --> URI Class Initialized
INFO - 2023-09-10 08:52:21 --> Output Class Initialized
DEBUG - 2023-09-10 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:21 --> Output Class Initialized
INFO - 2023-09-10 08:52:21 --> Input Class Initialized
INFO - 2023-09-10 08:52:21 --> Security Class Initialized
INFO - 2023-09-10 08:52:21 --> Language Class Initialized
INFO - 2023-09-10 08:52:21 --> Security Class Initialized
DEBUG - 2023-09-10 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:21 --> Router Class Initialized
ERROR - 2023-09-10 08:52:21 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:21 --> Input Class Initialized
INFO - 2023-09-10 08:52:21 --> Input Class Initialized
INFO - 2023-09-10 08:52:21 --> Language Class Initialized
INFO - 2023-09-10 08:52:21 --> Output Class Initialized
ERROR - 2023-09-10 08:52:21 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 08:52:21 --> Language Class Initialized
INFO - 2023-09-10 08:52:21 --> Security Class Initialized
ERROR - 2023-09-10 08:52:21 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:52:21 --> Input Class Initialized
INFO - 2023-09-10 08:52:21 --> Language Class Initialized
ERROR - 2023-09-10 08:52:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:54:01 --> Config Class Initialized
INFO - 2023-09-10 08:54:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:54:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:54:01 --> Utf8 Class Initialized
INFO - 2023-09-10 08:54:01 --> URI Class Initialized
INFO - 2023-09-10 08:54:01 --> Router Class Initialized
INFO - 2023-09-10 08:54:01 --> Output Class Initialized
INFO - 2023-09-10 08:54:01 --> Security Class Initialized
DEBUG - 2023-09-10 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:54:01 --> Input Class Initialized
INFO - 2023-09-10 08:54:01 --> Language Class Initialized
INFO - 2023-09-10 08:54:01 --> Loader Class Initialized
INFO - 2023-09-10 08:54:01 --> Helper loaded: url_helper
INFO - 2023-09-10 08:54:01 --> Helper loaded: file_helper
INFO - 2023-09-10 08:54:01 --> Database Driver Class Initialized
INFO - 2023-09-10 08:54:01 --> Email Class Initialized
DEBUG - 2023-09-10 08:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:54:01 --> Controller Class Initialized
INFO - 2023-09-10 08:54:01 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:54:01 --> Helper loaded: form_helper
INFO - 2023-09-10 08:54:01 --> Form Validation Class Initialized
INFO - 2023-09-10 08:54:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-09-10 08:54:01 --> Final output sent to browser
DEBUG - 2023-09-10 08:54:01 --> Total execution time: 0.4343
INFO - 2023-09-10 08:54:03 --> Config Class Initialized
INFO - 2023-09-10 08:54:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:54:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:54:03 --> Utf8 Class Initialized
INFO - 2023-09-10 08:54:03 --> URI Class Initialized
INFO - 2023-09-10 08:54:03 --> Router Class Initialized
INFO - 2023-09-10 08:54:03 --> Output Class Initialized
INFO - 2023-09-10 08:54:03 --> Security Class Initialized
DEBUG - 2023-09-10 08:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:54:03 --> Input Class Initialized
INFO - 2023-09-10 08:54:03 --> Language Class Initialized
ERROR - 2023-09-10 08:54:03 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-10 08:57:27 --> Config Class Initialized
INFO - 2023-09-10 08:57:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:57:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:57:27 --> Utf8 Class Initialized
INFO - 2023-09-10 08:57:27 --> URI Class Initialized
INFO - 2023-09-10 08:57:27 --> Router Class Initialized
INFO - 2023-09-10 08:57:27 --> Output Class Initialized
INFO - 2023-09-10 08:57:27 --> Security Class Initialized
DEBUG - 2023-09-10 08:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:57:27 --> Input Class Initialized
INFO - 2023-09-10 08:57:27 --> Language Class Initialized
INFO - 2023-09-10 08:57:27 --> Loader Class Initialized
INFO - 2023-09-10 08:57:27 --> Helper loaded: url_helper
INFO - 2023-09-10 08:57:27 --> Helper loaded: file_helper
INFO - 2023-09-10 08:57:27 --> Database Driver Class Initialized
INFO - 2023-09-10 08:57:27 --> Email Class Initialized
DEBUG - 2023-09-10 08:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:57:28 --> Controller Class Initialized
INFO - 2023-09-10 08:57:28 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:57:28 --> Model "Home_model" initialized
INFO - 2023-09-10 08:57:28 --> Helper loaded: download_helper
INFO - 2023-09-10 08:57:28 --> Helper loaded: form_helper
INFO - 2023-09-10 08:57:28 --> Form Validation Class Initialized
INFO - 2023-09-10 08:57:28 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:57:28 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:57:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 08:57:28 --> Final output sent to browser
DEBUG - 2023-09-10 08:57:28 --> Total execution time: 0.3460
INFO - 2023-09-10 08:57:29 --> Config Class Initialized
INFO - 2023-09-10 08:57:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:57:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:57:29 --> Utf8 Class Initialized
INFO - 2023-09-10 08:57:29 --> URI Class Initialized
INFO - 2023-09-10 08:57:29 --> Router Class Initialized
INFO - 2023-09-10 08:57:29 --> Output Class Initialized
INFO - 2023-09-10 08:57:29 --> Security Class Initialized
DEBUG - 2023-09-10 08:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:57:29 --> Input Class Initialized
INFO - 2023-09-10 08:57:29 --> Language Class Initialized
ERROR - 2023-09-10 08:57:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 08:57:43 --> Config Class Initialized
INFO - 2023-09-10 08:57:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:57:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:57:43 --> Utf8 Class Initialized
INFO - 2023-09-10 08:57:43 --> URI Class Initialized
INFO - 2023-09-10 08:57:43 --> Router Class Initialized
INFO - 2023-09-10 08:57:43 --> Output Class Initialized
INFO - 2023-09-10 08:57:43 --> Security Class Initialized
DEBUG - 2023-09-10 08:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:57:43 --> Input Class Initialized
INFO - 2023-09-10 08:57:43 --> Language Class Initialized
INFO - 2023-09-10 08:57:43 --> Loader Class Initialized
INFO - 2023-09-10 08:57:43 --> Helper loaded: url_helper
INFO - 2023-09-10 08:57:44 --> Helper loaded: file_helper
INFO - 2023-09-10 08:57:44 --> Database Driver Class Initialized
INFO - 2023-09-10 08:57:44 --> Email Class Initialized
DEBUG - 2023-09-10 08:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 08:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 08:57:44 --> Controller Class Initialized
INFO - 2023-09-10 08:57:44 --> Model "Contact_model" initialized
INFO - 2023-09-10 08:57:44 --> Model "Home_model" initialized
INFO - 2023-09-10 08:57:44 --> Helper loaded: download_helper
INFO - 2023-09-10 08:57:44 --> Helper loaded: form_helper
INFO - 2023-09-10 08:57:44 --> Form Validation Class Initialized
INFO - 2023-09-10 08:57:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 08:57:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 08:57:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 08:57:44 --> Final output sent to browser
DEBUG - 2023-09-10 08:57:44 --> Total execution time: 1.5288
INFO - 2023-09-10 08:57:45 --> Config Class Initialized
INFO - 2023-09-10 08:57:45 --> Hooks Class Initialized
DEBUG - 2023-09-10 08:57:45 --> UTF-8 Support Enabled
INFO - 2023-09-10 08:57:45 --> Utf8 Class Initialized
INFO - 2023-09-10 08:57:45 --> URI Class Initialized
INFO - 2023-09-10 08:57:45 --> Router Class Initialized
INFO - 2023-09-10 08:57:45 --> Output Class Initialized
INFO - 2023-09-10 08:57:45 --> Security Class Initialized
DEBUG - 2023-09-10 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 08:57:46 --> Input Class Initialized
INFO - 2023-09-10 08:57:46 --> Language Class Initialized
ERROR - 2023-09-10 08:57:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:02:57 --> Config Class Initialized
INFO - 2023-09-10 09:02:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:02:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:02:57 --> Utf8 Class Initialized
INFO - 2023-09-10 09:02:57 --> URI Class Initialized
DEBUG - 2023-09-10 09:02:57 --> No URI present. Default controller set.
INFO - 2023-09-10 09:02:57 --> Router Class Initialized
INFO - 2023-09-10 09:02:57 --> Output Class Initialized
INFO - 2023-09-10 09:02:57 --> Security Class Initialized
DEBUG - 2023-09-10 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:02:57 --> Input Class Initialized
INFO - 2023-09-10 09:02:57 --> Language Class Initialized
INFO - 2023-09-10 09:02:57 --> Loader Class Initialized
INFO - 2023-09-10 09:02:57 --> Helper loaded: url_helper
INFO - 2023-09-10 09:02:57 --> Helper loaded: file_helper
INFO - 2023-09-10 09:02:57 --> Database Driver Class Initialized
INFO - 2023-09-10 09:02:57 --> Email Class Initialized
DEBUG - 2023-09-10 09:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:02:57 --> Controller Class Initialized
INFO - 2023-09-10 09:02:57 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:02:57 --> Model "Home_model" initialized
INFO - 2023-09-10 09:02:58 --> Helper loaded: download_helper
INFO - 2023-09-10 09:02:58 --> Helper loaded: form_helper
INFO - 2023-09-10 09:02:58 --> Form Validation Class Initialized
INFO - 2023-09-10 09:02:58 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:02:58 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:02:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:02:58 --> Final output sent to browser
DEBUG - 2023-09-10 09:02:58 --> Total execution time: 0.9561
INFO - 2023-09-10 09:02:59 --> Config Class Initialized
INFO - 2023-09-10 09:02:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:02:59 --> Utf8 Class Initialized
INFO - 2023-09-10 09:02:59 --> URI Class Initialized
INFO - 2023-09-10 09:02:59 --> Router Class Initialized
INFO - 2023-09-10 09:02:59 --> Output Class Initialized
INFO - 2023-09-10 09:02:59 --> Security Class Initialized
DEBUG - 2023-09-10 09:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:02:59 --> Input Class Initialized
INFO - 2023-09-10 09:02:59 --> Language Class Initialized
ERROR - 2023-09-10 09:02:59 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:03:03 --> Config Class Initialized
INFO - 2023-09-10 09:03:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:03:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:03:03 --> Utf8 Class Initialized
INFO - 2023-09-10 09:03:03 --> URI Class Initialized
INFO - 2023-09-10 09:03:03 --> Router Class Initialized
INFO - 2023-09-10 09:03:03 --> Output Class Initialized
INFO - 2023-09-10 09:03:03 --> Security Class Initialized
DEBUG - 2023-09-10 09:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:03:03 --> Input Class Initialized
INFO - 2023-09-10 09:03:03 --> Language Class Initialized
INFO - 2023-09-10 09:03:03 --> Loader Class Initialized
INFO - 2023-09-10 09:03:03 --> Helper loaded: url_helper
INFO - 2023-09-10 09:03:03 --> Helper loaded: file_helper
INFO - 2023-09-10 09:03:03 --> Database Driver Class Initialized
INFO - 2023-09-10 09:03:03 --> Email Class Initialized
DEBUG - 2023-09-10 09:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:03:03 --> Controller Class Initialized
INFO - 2023-09-10 09:03:03 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:03:03 --> Model "Home_model" initialized
INFO - 2023-09-10 09:03:03 --> Helper loaded: download_helper
INFO - 2023-09-10 09:03:03 --> Helper loaded: form_helper
INFO - 2023-09-10 09:03:03 --> Form Validation Class Initialized
INFO - 2023-09-10 09:03:03 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:03:03 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:03:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:03:03 --> Final output sent to browser
DEBUG - 2023-09-10 09:03:03 --> Total execution time: 0.1367
INFO - 2023-09-10 09:03:05 --> Config Class Initialized
INFO - 2023-09-10 09:03:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:03:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:03:05 --> Utf8 Class Initialized
INFO - 2023-09-10 09:03:05 --> URI Class Initialized
INFO - 2023-09-10 09:03:05 --> Router Class Initialized
INFO - 2023-09-10 09:03:05 --> Output Class Initialized
INFO - 2023-09-10 09:03:05 --> Security Class Initialized
DEBUG - 2023-09-10 09:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:03:05 --> Input Class Initialized
INFO - 2023-09-10 09:03:05 --> Language Class Initialized
ERROR - 2023-09-10 09:03:05 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:03:13 --> Config Class Initialized
INFO - 2023-09-10 09:03:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:03:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:03:13 --> Utf8 Class Initialized
INFO - 2023-09-10 09:03:13 --> URI Class Initialized
DEBUG - 2023-09-10 09:03:13 --> No URI present. Default controller set.
INFO - 2023-09-10 09:03:13 --> Router Class Initialized
INFO - 2023-09-10 09:03:13 --> Output Class Initialized
INFO - 2023-09-10 09:03:13 --> Security Class Initialized
DEBUG - 2023-09-10 09:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:03:13 --> Input Class Initialized
INFO - 2023-09-10 09:03:13 --> Language Class Initialized
INFO - 2023-09-10 09:03:13 --> Loader Class Initialized
INFO - 2023-09-10 09:03:13 --> Helper loaded: url_helper
INFO - 2023-09-10 09:03:13 --> Helper loaded: file_helper
INFO - 2023-09-10 09:03:13 --> Database Driver Class Initialized
INFO - 2023-09-10 09:03:13 --> Email Class Initialized
DEBUG - 2023-09-10 09:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:03:13 --> Controller Class Initialized
INFO - 2023-09-10 09:03:13 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:03:13 --> Model "Home_model" initialized
INFO - 2023-09-10 09:03:14 --> Helper loaded: download_helper
INFO - 2023-09-10 09:03:14 --> Helper loaded: form_helper
INFO - 2023-09-10 09:03:14 --> Form Validation Class Initialized
INFO - 2023-09-10 09:03:14 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:03:14 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:03:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:03:14 --> Final output sent to browser
DEBUG - 2023-09-10 09:03:14 --> Total execution time: 1.0095
INFO - 2023-09-10 09:14:11 --> Config Class Initialized
INFO - 2023-09-10 09:14:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:14:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:14:11 --> Utf8 Class Initialized
INFO - 2023-09-10 09:14:11 --> URI Class Initialized
DEBUG - 2023-09-10 09:14:11 --> No URI present. Default controller set.
INFO - 2023-09-10 09:14:11 --> Router Class Initialized
INFO - 2023-09-10 09:14:11 --> Output Class Initialized
INFO - 2023-09-10 09:14:11 --> Security Class Initialized
DEBUG - 2023-09-10 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:14:11 --> Input Class Initialized
INFO - 2023-09-10 09:14:12 --> Language Class Initialized
INFO - 2023-09-10 09:14:12 --> Loader Class Initialized
INFO - 2023-09-10 09:14:12 --> Helper loaded: url_helper
INFO - 2023-09-10 09:14:12 --> Helper loaded: file_helper
INFO - 2023-09-10 09:14:12 --> Database Driver Class Initialized
INFO - 2023-09-10 09:14:12 --> Email Class Initialized
DEBUG - 2023-09-10 09:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:14:12 --> Controller Class Initialized
INFO - 2023-09-10 09:14:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:14:12 --> Model "Home_model" initialized
INFO - 2023-09-10 09:14:12 --> Helper loaded: download_helper
INFO - 2023-09-10 09:14:12 --> Helper loaded: form_helper
INFO - 2023-09-10 09:14:12 --> Form Validation Class Initialized
INFO - 2023-09-10 09:14:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:14:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:14:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:14:12 --> Final output sent to browser
DEBUG - 2023-09-10 09:14:12 --> Total execution time: 0.4062
INFO - 2023-09-10 09:14:13 --> Config Class Initialized
INFO - 2023-09-10 09:14:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:14:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:14:13 --> Utf8 Class Initialized
INFO - 2023-09-10 09:14:13 --> URI Class Initialized
INFO - 2023-09-10 09:14:13 --> Router Class Initialized
INFO - 2023-09-10 09:14:13 --> Output Class Initialized
INFO - 2023-09-10 09:14:13 --> Security Class Initialized
DEBUG - 2023-09-10 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:14:13 --> Input Class Initialized
INFO - 2023-09-10 09:14:13 --> Language Class Initialized
ERROR - 2023-09-10 09:14:13 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:20:55 --> Config Class Initialized
INFO - 2023-09-10 09:20:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:20:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:20:55 --> Utf8 Class Initialized
INFO - 2023-09-10 09:20:55 --> URI Class Initialized
INFO - 2023-09-10 09:20:55 --> Router Class Initialized
INFO - 2023-09-10 09:20:55 --> Output Class Initialized
INFO - 2023-09-10 09:20:55 --> Security Class Initialized
DEBUG - 2023-09-10 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:20:55 --> Input Class Initialized
INFO - 2023-09-10 09:20:55 --> Language Class Initialized
INFO - 2023-09-10 09:20:55 --> Loader Class Initialized
INFO - 2023-09-10 09:20:55 --> Helper loaded: url_helper
INFO - 2023-09-10 09:20:55 --> Helper loaded: file_helper
INFO - 2023-09-10 09:20:55 --> Database Driver Class Initialized
INFO - 2023-09-10 09:20:55 --> Email Class Initialized
DEBUG - 2023-09-10 09:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:20:55 --> Controller Class Initialized
INFO - 2023-09-10 09:20:56 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:20:56 --> Model "Home_model" initialized
INFO - 2023-09-10 09:20:56 --> Helper loaded: download_helper
INFO - 2023-09-10 09:20:56 --> Helper loaded: form_helper
INFO - 2023-09-10 09:20:56 --> Form Validation Class Initialized
INFO - 2023-09-10 09:20:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:20:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:20:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 09:20:56 --> Final output sent to browser
DEBUG - 2023-09-10 09:20:56 --> Total execution time: 0.9012
INFO - 2023-09-10 09:20:57 --> Config Class Initialized
INFO - 2023-09-10 09:20:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:20:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:20:57 --> Utf8 Class Initialized
INFO - 2023-09-10 09:20:57 --> URI Class Initialized
INFO - 2023-09-10 09:20:57 --> Router Class Initialized
INFO - 2023-09-10 09:20:57 --> Output Class Initialized
INFO - 2023-09-10 09:20:57 --> Security Class Initialized
DEBUG - 2023-09-10 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:20:57 --> Input Class Initialized
INFO - 2023-09-10 09:20:57 --> Language Class Initialized
ERROR - 2023-09-10 09:20:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:20:59 --> Config Class Initialized
INFO - 2023-09-10 09:20:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:20:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:20:59 --> Utf8 Class Initialized
INFO - 2023-09-10 09:20:59 --> URI Class Initialized
DEBUG - 2023-09-10 09:20:59 --> No URI present. Default controller set.
INFO - 2023-09-10 09:20:59 --> Router Class Initialized
INFO - 2023-09-10 09:20:59 --> Output Class Initialized
INFO - 2023-09-10 09:20:59 --> Security Class Initialized
DEBUG - 2023-09-10 09:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:20:59 --> Input Class Initialized
INFO - 2023-09-10 09:20:59 --> Language Class Initialized
INFO - 2023-09-10 09:20:59 --> Loader Class Initialized
INFO - 2023-09-10 09:20:59 --> Helper loaded: url_helper
INFO - 2023-09-10 09:20:59 --> Helper loaded: file_helper
INFO - 2023-09-10 09:20:59 --> Database Driver Class Initialized
INFO - 2023-09-10 09:20:59 --> Email Class Initialized
DEBUG - 2023-09-10 09:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:20:59 --> Controller Class Initialized
INFO - 2023-09-10 09:20:59 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:20:59 --> Model "Home_model" initialized
INFO - 2023-09-10 09:20:59 --> Helper loaded: download_helper
INFO - 2023-09-10 09:20:59 --> Helper loaded: form_helper
INFO - 2023-09-10 09:20:59 --> Form Validation Class Initialized
INFO - 2023-09-10 09:20:59 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:20:59 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:20:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:20:59 --> Final output sent to browser
DEBUG - 2023-09-10 09:20:59 --> Total execution time: 0.1105
INFO - 2023-09-10 09:26:21 --> Config Class Initialized
INFO - 2023-09-10 09:26:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:26:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:26:21 --> Utf8 Class Initialized
INFO - 2023-09-10 09:26:21 --> URI Class Initialized
INFO - 2023-09-10 09:26:21 --> Router Class Initialized
INFO - 2023-09-10 09:26:21 --> Output Class Initialized
INFO - 2023-09-10 09:26:21 --> Security Class Initialized
DEBUG - 2023-09-10 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:26:21 --> Input Class Initialized
INFO - 2023-09-10 09:26:21 --> Language Class Initialized
INFO - 2023-09-10 09:26:21 --> Loader Class Initialized
INFO - 2023-09-10 09:26:21 --> Helper loaded: url_helper
INFO - 2023-09-10 09:26:21 --> Helper loaded: file_helper
INFO - 2023-09-10 09:26:21 --> Database Driver Class Initialized
INFO - 2023-09-10 09:26:21 --> Email Class Initialized
DEBUG - 2023-09-10 09:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:26:21 --> Controller Class Initialized
INFO - 2023-09-10 09:26:21 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:26:21 --> Model "Home_model" initialized
INFO - 2023-09-10 09:26:21 --> Helper loaded: download_helper
INFO - 2023-09-10 09:26:21 --> Helper loaded: form_helper
INFO - 2023-09-10 09:26:21 --> Form Validation Class Initialized
INFO - 2023-09-10 09:26:21 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:26:21 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:26:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:26:21 --> Final output sent to browser
DEBUG - 2023-09-10 09:26:22 --> Total execution time: 0.3921
INFO - 2023-09-10 09:26:22 --> Config Class Initialized
INFO - 2023-09-10 09:26:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:26:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:26:22 --> Utf8 Class Initialized
INFO - 2023-09-10 09:26:22 --> URI Class Initialized
INFO - 2023-09-10 09:26:22 --> Router Class Initialized
INFO - 2023-09-10 09:26:22 --> Output Class Initialized
INFO - 2023-09-10 09:26:22 --> Security Class Initialized
DEBUG - 2023-09-10 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:26:22 --> Input Class Initialized
INFO - 2023-09-10 09:26:22 --> Language Class Initialized
ERROR - 2023-09-10 09:26:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:26:40 --> Config Class Initialized
INFO - 2023-09-10 09:26:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:26:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:26:40 --> Utf8 Class Initialized
INFO - 2023-09-10 09:26:40 --> URI Class Initialized
INFO - 2023-09-10 09:26:40 --> Router Class Initialized
INFO - 2023-09-10 09:26:40 --> Output Class Initialized
INFO - 2023-09-10 09:26:40 --> Security Class Initialized
DEBUG - 2023-09-10 09:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:26:40 --> Input Class Initialized
INFO - 2023-09-10 09:26:40 --> Language Class Initialized
INFO - 2023-09-10 09:26:40 --> Loader Class Initialized
INFO - 2023-09-10 09:26:40 --> Helper loaded: url_helper
INFO - 2023-09-10 09:26:40 --> Helper loaded: file_helper
INFO - 2023-09-10 09:26:40 --> Database Driver Class Initialized
INFO - 2023-09-10 09:26:40 --> Email Class Initialized
DEBUG - 2023-09-10 09:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:26:40 --> Controller Class Initialized
INFO - 2023-09-10 09:26:40 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:26:40 --> Model "Home_model" initialized
INFO - 2023-09-10 09:26:40 --> Helper loaded: download_helper
INFO - 2023-09-10 09:26:40 --> Helper loaded: form_helper
INFO - 2023-09-10 09:26:40 --> Form Validation Class Initialized
INFO - 2023-09-10 09:26:40 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:26:40 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:26:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:26:40 --> Final output sent to browser
DEBUG - 2023-09-10 09:26:40 --> Total execution time: 0.3499
INFO - 2023-09-10 09:26:41 --> Config Class Initialized
INFO - 2023-09-10 09:26:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:26:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:26:41 --> Utf8 Class Initialized
INFO - 2023-09-10 09:26:41 --> URI Class Initialized
INFO - 2023-09-10 09:26:41 --> Router Class Initialized
INFO - 2023-09-10 09:26:41 --> Output Class Initialized
INFO - 2023-09-10 09:26:41 --> Security Class Initialized
DEBUG - 2023-09-10 09:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:26:41 --> Input Class Initialized
INFO - 2023-09-10 09:26:41 --> Language Class Initialized
ERROR - 2023-09-10 09:26:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:29:20 --> Config Class Initialized
INFO - 2023-09-10 09:29:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:29:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:29:20 --> Utf8 Class Initialized
INFO - 2023-09-10 09:29:20 --> URI Class Initialized
INFO - 2023-09-10 09:29:20 --> Router Class Initialized
INFO - 2023-09-10 09:29:20 --> Output Class Initialized
INFO - 2023-09-10 09:29:20 --> Security Class Initialized
DEBUG - 2023-09-10 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:29:20 --> Input Class Initialized
INFO - 2023-09-10 09:29:20 --> Language Class Initialized
INFO - 2023-09-10 09:29:20 --> Loader Class Initialized
INFO - 2023-09-10 09:29:20 --> Helper loaded: url_helper
INFO - 2023-09-10 09:29:20 --> Helper loaded: file_helper
INFO - 2023-09-10 09:29:20 --> Database Driver Class Initialized
INFO - 2023-09-10 09:29:20 --> Email Class Initialized
DEBUG - 2023-09-10 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:29:20 --> Controller Class Initialized
INFO - 2023-09-10 09:29:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:29:20 --> Model "Home_model" initialized
INFO - 2023-09-10 09:29:20 --> Helper loaded: download_helper
INFO - 2023-09-10 09:29:21 --> Helper loaded: form_helper
INFO - 2023-09-10 09:29:21 --> Form Validation Class Initialized
INFO - 2023-09-10 09:29:21 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:29:21 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:29:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:29:21 --> Final output sent to browser
DEBUG - 2023-09-10 09:29:21 --> Total execution time: 0.3649
INFO - 2023-09-10 09:29:21 --> Config Class Initialized
INFO - 2023-09-10 09:29:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:29:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:29:21 --> Utf8 Class Initialized
INFO - 2023-09-10 09:29:21 --> URI Class Initialized
INFO - 2023-09-10 09:29:21 --> Router Class Initialized
INFO - 2023-09-10 09:29:21 --> Output Class Initialized
INFO - 2023-09-10 09:29:21 --> Security Class Initialized
DEBUG - 2023-09-10 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:29:21 --> Input Class Initialized
INFO - 2023-09-10 09:29:21 --> Language Class Initialized
ERROR - 2023-09-10 09:29:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:31:26 --> Config Class Initialized
INFO - 2023-09-10 09:31:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:31:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:31:26 --> Utf8 Class Initialized
INFO - 2023-09-10 09:31:26 --> URI Class Initialized
INFO - 2023-09-10 09:31:26 --> Router Class Initialized
INFO - 2023-09-10 09:31:26 --> Output Class Initialized
INFO - 2023-09-10 09:31:26 --> Security Class Initialized
DEBUG - 2023-09-10 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:31:26 --> Input Class Initialized
INFO - 2023-09-10 09:31:26 --> Language Class Initialized
INFO - 2023-09-10 09:31:26 --> Loader Class Initialized
INFO - 2023-09-10 09:31:26 --> Helper loaded: url_helper
INFO - 2023-09-10 09:31:26 --> Helper loaded: file_helper
INFO - 2023-09-10 09:31:26 --> Database Driver Class Initialized
INFO - 2023-09-10 09:31:26 --> Email Class Initialized
DEBUG - 2023-09-10 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:31:26 --> Controller Class Initialized
INFO - 2023-09-10 09:31:26 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:31:26 --> Model "Home_model" initialized
INFO - 2023-09-10 09:31:26 --> Helper loaded: download_helper
INFO - 2023-09-10 09:31:26 --> Helper loaded: form_helper
INFO - 2023-09-10 09:31:26 --> Form Validation Class Initialized
INFO - 2023-09-10 09:31:26 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:31:26 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:31:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:31:26 --> Final output sent to browser
DEBUG - 2023-09-10 09:31:26 --> Total execution time: 0.3688
INFO - 2023-09-10 09:31:28 --> Config Class Initialized
INFO - 2023-09-10 09:31:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:31:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:31:28 --> Utf8 Class Initialized
INFO - 2023-09-10 09:31:28 --> URI Class Initialized
INFO - 2023-09-10 09:31:28 --> Router Class Initialized
INFO - 2023-09-10 09:31:28 --> Output Class Initialized
INFO - 2023-09-10 09:31:28 --> Security Class Initialized
DEBUG - 2023-09-10 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:31:28 --> Input Class Initialized
INFO - 2023-09-10 09:31:28 --> Language Class Initialized
ERROR - 2023-09-10 09:31:28 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:31:54 --> Config Class Initialized
INFO - 2023-09-10 09:31:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:31:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:31:54 --> Utf8 Class Initialized
INFO - 2023-09-10 09:31:54 --> URI Class Initialized
INFO - 2023-09-10 09:31:54 --> Router Class Initialized
INFO - 2023-09-10 09:31:54 --> Output Class Initialized
INFO - 2023-09-10 09:31:54 --> Security Class Initialized
DEBUG - 2023-09-10 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:31:54 --> Input Class Initialized
INFO - 2023-09-10 09:31:54 --> Language Class Initialized
INFO - 2023-09-10 09:31:54 --> Loader Class Initialized
INFO - 2023-09-10 09:31:54 --> Helper loaded: url_helper
INFO - 2023-09-10 09:31:54 --> Helper loaded: file_helper
INFO - 2023-09-10 09:31:54 --> Database Driver Class Initialized
INFO - 2023-09-10 09:31:54 --> Email Class Initialized
DEBUG - 2023-09-10 09:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:31:54 --> Controller Class Initialized
INFO - 2023-09-10 09:31:54 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:31:54 --> Model "Home_model" initialized
INFO - 2023-09-10 09:31:54 --> Helper loaded: download_helper
INFO - 2023-09-10 09:31:54 --> Helper loaded: form_helper
INFO - 2023-09-10 09:31:54 --> Form Validation Class Initialized
INFO - 2023-09-10 09:31:54 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:31:54 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:31:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:31:54 --> Final output sent to browser
DEBUG - 2023-09-10 09:31:55 --> Total execution time: 0.1647
INFO - 2023-09-10 09:31:55 --> Config Class Initialized
INFO - 2023-09-10 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:31:55 --> Utf8 Class Initialized
INFO - 2023-09-10 09:31:55 --> URI Class Initialized
INFO - 2023-09-10 09:31:55 --> Router Class Initialized
INFO - 2023-09-10 09:31:56 --> Output Class Initialized
INFO - 2023-09-10 09:31:56 --> Security Class Initialized
DEBUG - 2023-09-10 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:31:56 --> Input Class Initialized
INFO - 2023-09-10 09:31:56 --> Language Class Initialized
ERROR - 2023-09-10 09:31:56 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:32:23 --> Config Class Initialized
INFO - 2023-09-10 09:32:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:32:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:32:23 --> Utf8 Class Initialized
INFO - 2023-09-10 09:32:23 --> URI Class Initialized
INFO - 2023-09-10 09:32:23 --> Router Class Initialized
INFO - 2023-09-10 09:32:23 --> Output Class Initialized
INFO - 2023-09-10 09:32:23 --> Security Class Initialized
DEBUG - 2023-09-10 09:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:32:23 --> Input Class Initialized
INFO - 2023-09-10 09:32:23 --> Language Class Initialized
INFO - 2023-09-10 09:32:23 --> Loader Class Initialized
INFO - 2023-09-10 09:32:23 --> Helper loaded: url_helper
INFO - 2023-09-10 09:32:23 --> Helper loaded: file_helper
INFO - 2023-09-10 09:32:23 --> Database Driver Class Initialized
INFO - 2023-09-10 09:32:23 --> Email Class Initialized
DEBUG - 2023-09-10 09:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:32:23 --> Controller Class Initialized
INFO - 2023-09-10 09:32:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:32:23 --> Model "Home_model" initialized
INFO - 2023-09-10 09:32:23 --> Helper loaded: download_helper
INFO - 2023-09-10 09:32:23 --> Helper loaded: form_helper
INFO - 2023-09-10 09:32:23 --> Form Validation Class Initialized
INFO - 2023-09-10 09:32:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:32:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:32:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 09:32:23 --> Final output sent to browser
DEBUG - 2023-09-10 09:32:24 --> Total execution time: 0.5455
INFO - 2023-09-10 09:32:24 --> Config Class Initialized
INFO - 2023-09-10 09:32:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:32:24 --> Utf8 Class Initialized
INFO - 2023-09-10 09:32:24 --> URI Class Initialized
INFO - 2023-09-10 09:32:24 --> Router Class Initialized
INFO - 2023-09-10 09:32:24 --> Output Class Initialized
INFO - 2023-09-10 09:32:24 --> Security Class Initialized
DEBUG - 2023-09-10 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:32:25 --> Input Class Initialized
INFO - 2023-09-10 09:32:25 --> Language Class Initialized
ERROR - 2023-09-10 09:32:25 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:33:30 --> Config Class Initialized
INFO - 2023-09-10 09:33:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:33:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:33:30 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:30 --> URI Class Initialized
INFO - 2023-09-10 09:33:30 --> Router Class Initialized
INFO - 2023-09-10 09:33:30 --> Output Class Initialized
INFO - 2023-09-10 09:33:30 --> Security Class Initialized
DEBUG - 2023-09-10 09:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:33:30 --> Input Class Initialized
INFO - 2023-09-10 09:33:30 --> Language Class Initialized
INFO - 2023-09-10 09:33:30 --> Loader Class Initialized
INFO - 2023-09-10 09:33:30 --> Helper loaded: url_helper
INFO - 2023-09-10 09:33:30 --> Helper loaded: file_helper
INFO - 2023-09-10 09:33:30 --> Database Driver Class Initialized
INFO - 2023-09-10 09:33:31 --> Email Class Initialized
DEBUG - 2023-09-10 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:33:31 --> Controller Class Initialized
INFO - 2023-09-10 09:33:31 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:33:31 --> Model "Home_model" initialized
INFO - 2023-09-10 09:33:31 --> Helper loaded: download_helper
INFO - 2023-09-10 09:33:31 --> Helper loaded: form_helper
INFO - 2023-09-10 09:33:31 --> Form Validation Class Initialized
INFO - 2023-09-10 09:33:31 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:33:31 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:33:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 09:33:31 --> Final output sent to browser
DEBUG - 2023-09-10 09:33:31 --> Total execution time: 1.0778
INFO - 2023-09-10 09:33:32 --> Config Class Initialized
INFO - 2023-09-10 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:33:32 --> Config Class Initialized
INFO - 2023-09-10 09:33:32 --> Config Class Initialized
INFO - 2023-09-10 09:33:32 --> Config Class Initialized
INFO - 2023-09-10 09:33:32 --> Hooks Class Initialized
INFO - 2023-09-10 09:33:32 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:32 --> Hooks Class Initialized
INFO - 2023-09-10 09:33:33 --> Hooks Class Initialized
INFO - 2023-09-10 09:33:33 --> Config Class Initialized
DEBUG - 2023-09-10 09:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 09:33:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:33:33 --> URI Class Initialized
INFO - 2023-09-10 09:33:33 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:33 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:33 --> Hooks Class Initialized
INFO - 2023-09-10 09:33:33 --> Router Class Initialized
DEBUG - 2023-09-10 09:33:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:33:33 --> URI Class Initialized
INFO - 2023-09-10 09:33:33 --> URI Class Initialized
DEBUG - 2023-09-10 09:33:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:33:33 --> Output Class Initialized
INFO - 2023-09-10 09:33:33 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:33 --> Router Class Initialized
INFO - 2023-09-10 09:33:33 --> Output Class Initialized
INFO - 2023-09-10 09:33:33 --> Security Class Initialized
DEBUG - 2023-09-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:33:33 --> Input Class Initialized
INFO - 2023-09-10 09:33:33 --> Language Class Initialized
ERROR - 2023-09-10 09:33:33 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 09:33:33 --> Router Class Initialized
INFO - 2023-09-10 09:33:33 --> Utf8 Class Initialized
INFO - 2023-09-10 09:33:33 --> Security Class Initialized
INFO - 2023-09-10 09:33:33 --> URI Class Initialized
INFO - 2023-09-10 09:33:33 --> URI Class Initialized
DEBUG - 2023-09-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:33:33 --> Output Class Initialized
INFO - 2023-09-10 09:33:33 --> Input Class Initialized
INFO - 2023-09-10 09:33:33 --> Router Class Initialized
INFO - 2023-09-10 09:33:33 --> Router Class Initialized
INFO - 2023-09-10 09:33:33 --> Output Class Initialized
INFO - 2023-09-10 09:33:33 --> Language Class Initialized
ERROR - 2023-09-10 09:33:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:33:33 --> Security Class Initialized
INFO - 2023-09-10 09:33:33 --> Output Class Initialized
INFO - 2023-09-10 09:33:33 --> Security Class Initialized
INFO - 2023-09-10 09:33:33 --> Security Class Initialized
DEBUG - 2023-09-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:33:33 --> Input Class Initialized
INFO - 2023-09-10 09:33:33 --> Input Class Initialized
INFO - 2023-09-10 09:33:33 --> Language Class Initialized
DEBUG - 2023-09-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 09:33:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:33:33 --> Language Class Initialized
INFO - 2023-09-10 09:33:33 --> Input Class Initialized
ERROR - 2023-09-10 09:33:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:33:33 --> Language Class Initialized
ERROR - 2023-09-10 09:33:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:01 --> Config Class Initialized
INFO - 2023-09-10 09:38:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:01 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:01 --> URI Class Initialized
INFO - 2023-09-10 09:38:01 --> Router Class Initialized
INFO - 2023-09-10 09:38:01 --> Output Class Initialized
INFO - 2023-09-10 09:38:01 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:01 --> Input Class Initialized
INFO - 2023-09-10 09:38:01 --> Language Class Initialized
INFO - 2023-09-10 09:38:01 --> Loader Class Initialized
INFO - 2023-09-10 09:38:01 --> Helper loaded: url_helper
INFO - 2023-09-10 09:38:01 --> Helper loaded: file_helper
INFO - 2023-09-10 09:38:01 --> Database Driver Class Initialized
INFO - 2023-09-10 09:38:01 --> Email Class Initialized
DEBUG - 2023-09-10 09:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:38:01 --> Controller Class Initialized
INFO - 2023-09-10 09:38:01 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:38:01 --> Model "Home_model" initialized
INFO - 2023-09-10 09:38:01 --> Helper loaded: download_helper
INFO - 2023-09-10 09:38:01 --> Helper loaded: form_helper
INFO - 2023-09-10 09:38:01 --> Form Validation Class Initialized
INFO - 2023-09-10 09:38:01 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:38:01 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:38:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 09:38:01 --> Final output sent to browser
DEBUG - 2023-09-10 09:38:01 --> Total execution time: 0.3499
INFO - 2023-09-10 09:38:02 --> Config Class Initialized
INFO - 2023-09-10 09:38:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:02 --> URI Class Initialized
INFO - 2023-09-10 09:38:02 --> Router Class Initialized
INFO - 2023-09-10 09:38:02 --> Output Class Initialized
INFO - 2023-09-10 09:38:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:02 --> Input Class Initialized
INFO - 2023-09-10 09:38:02 --> Language Class Initialized
ERROR - 2023-09-10 09:38:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:02 --> Config Class Initialized
INFO - 2023-09-10 09:38:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:02 --> URI Class Initialized
INFO - 2023-09-10 09:38:02 --> Router Class Initialized
INFO - 2023-09-10 09:38:02 --> Output Class Initialized
INFO - 2023-09-10 09:38:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:02 --> Input Class Initialized
INFO - 2023-09-10 09:38:02 --> Language Class Initialized
ERROR - 2023-09-10 09:38:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:02 --> Config Class Initialized
INFO - 2023-09-10 09:38:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:02 --> URI Class Initialized
INFO - 2023-09-10 09:38:02 --> Router Class Initialized
INFO - 2023-09-10 09:38:02 --> Output Class Initialized
INFO - 2023-09-10 09:38:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:02 --> Input Class Initialized
INFO - 2023-09-10 09:38:02 --> Language Class Initialized
ERROR - 2023-09-10 09:38:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:02 --> Config Class Initialized
INFO - 2023-09-10 09:38:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:03 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:03 --> URI Class Initialized
INFO - 2023-09-10 09:38:03 --> Router Class Initialized
INFO - 2023-09-10 09:38:03 --> Output Class Initialized
INFO - 2023-09-10 09:38:03 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:03 --> Input Class Initialized
INFO - 2023-09-10 09:38:03 --> Language Class Initialized
ERROR - 2023-09-10 09:38:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:03 --> Config Class Initialized
INFO - 2023-09-10 09:38:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:03 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:03 --> URI Class Initialized
INFO - 2023-09-10 09:38:03 --> Router Class Initialized
INFO - 2023-09-10 09:38:03 --> Output Class Initialized
INFO - 2023-09-10 09:38:03 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:03 --> Input Class Initialized
INFO - 2023-09-10 09:38:03 --> Language Class Initialized
ERROR - 2023-09-10 09:38:03 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 09:38:16 --> Config Class Initialized
INFO - 2023-09-10 09:38:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:16 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:16 --> URI Class Initialized
INFO - 2023-09-10 09:38:16 --> Router Class Initialized
INFO - 2023-09-10 09:38:16 --> Output Class Initialized
INFO - 2023-09-10 09:38:16 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:16 --> Input Class Initialized
INFO - 2023-09-10 09:38:16 --> Language Class Initialized
INFO - 2023-09-10 09:38:16 --> Loader Class Initialized
INFO - 2023-09-10 09:38:16 --> Helper loaded: url_helper
INFO - 2023-09-10 09:38:16 --> Helper loaded: file_helper
INFO - 2023-09-10 09:38:16 --> Database Driver Class Initialized
INFO - 2023-09-10 09:38:16 --> Email Class Initialized
DEBUG - 2023-09-10 09:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:38:16 --> Controller Class Initialized
INFO - 2023-09-10 09:38:16 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:38:16 --> Model "Home_model" initialized
INFO - 2023-09-10 09:38:16 --> Helper loaded: download_helper
INFO - 2023-09-10 09:38:16 --> Helper loaded: form_helper
INFO - 2023-09-10 09:38:16 --> Form Validation Class Initialized
INFO - 2023-09-10 09:38:16 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:38:16 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:38:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 09:38:16 --> Final output sent to browser
DEBUG - 2023-09-10 09:38:16 --> Total execution time: 0.3256
INFO - 2023-09-10 09:38:16 --> Config Class Initialized
INFO - 2023-09-10 09:38:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:16 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:16 --> URI Class Initialized
INFO - 2023-09-10 09:38:16 --> Router Class Initialized
INFO - 2023-09-10 09:38:16 --> Output Class Initialized
INFO - 2023-09-10 09:38:16 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:16 --> Input Class Initialized
INFO - 2023-09-10 09:38:16 --> Language Class Initialized
ERROR - 2023-09-10 09:38:16 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:17 --> Config Class Initialized
INFO - 2023-09-10 09:38:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:17 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:17 --> URI Class Initialized
INFO - 2023-09-10 09:38:17 --> Router Class Initialized
INFO - 2023-09-10 09:38:17 --> Output Class Initialized
INFO - 2023-09-10 09:38:18 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:18 --> Input Class Initialized
INFO - 2023-09-10 09:38:18 --> Language Class Initialized
ERROR - 2023-09-10 09:38:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:18 --> Config Class Initialized
INFO - 2023-09-10 09:38:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:18 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:18 --> URI Class Initialized
INFO - 2023-09-10 09:38:18 --> Router Class Initialized
INFO - 2023-09-10 09:38:18 --> Output Class Initialized
INFO - 2023-09-10 09:38:18 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:18 --> Input Class Initialized
INFO - 2023-09-10 09:38:18 --> Language Class Initialized
ERROR - 2023-09-10 09:38:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:18 --> Config Class Initialized
INFO - 2023-09-10 09:38:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:18 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:18 --> URI Class Initialized
INFO - 2023-09-10 09:38:18 --> Router Class Initialized
INFO - 2023-09-10 09:38:18 --> Output Class Initialized
INFO - 2023-09-10 09:38:18 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:18 --> Input Class Initialized
INFO - 2023-09-10 09:38:18 --> Language Class Initialized
ERROR - 2023-09-10 09:38:18 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 09:38:18 --> Config Class Initialized
INFO - 2023-09-10 09:38:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:18 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:18 --> URI Class Initialized
INFO - 2023-09-10 09:38:18 --> Router Class Initialized
INFO - 2023-09-10 09:38:18 --> Output Class Initialized
INFO - 2023-09-10 09:38:18 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:18 --> Input Class Initialized
INFO - 2023-09-10 09:38:18 --> Language Class Initialized
ERROR - 2023-09-10 09:38:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:38:18 --> Config Class Initialized
INFO - 2023-09-10 09:38:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:38:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:38:18 --> Utf8 Class Initialized
INFO - 2023-09-10 09:38:18 --> URI Class Initialized
INFO - 2023-09-10 09:38:18 --> Router Class Initialized
INFO - 2023-09-10 09:38:18 --> Output Class Initialized
INFO - 2023-09-10 09:38:18 --> Security Class Initialized
DEBUG - 2023-09-10 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:38:18 --> Input Class Initialized
INFO - 2023-09-10 09:38:18 --> Language Class Initialized
ERROR - 2023-09-10 09:38:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:00 --> Config Class Initialized
INFO - 2023-09-10 09:39:00 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:00 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:00 --> URI Class Initialized
INFO - 2023-09-10 09:39:00 --> Router Class Initialized
INFO - 2023-09-10 09:39:00 --> Output Class Initialized
INFO - 2023-09-10 09:39:00 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:00 --> Input Class Initialized
INFO - 2023-09-10 09:39:00 --> Language Class Initialized
INFO - 2023-09-10 09:39:00 --> Loader Class Initialized
INFO - 2023-09-10 09:39:00 --> Helper loaded: url_helper
INFO - 2023-09-10 09:39:00 --> Helper loaded: file_helper
INFO - 2023-09-10 09:39:00 --> Database Driver Class Initialized
INFO - 2023-09-10 09:39:00 --> Email Class Initialized
DEBUG - 2023-09-10 09:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:39:00 --> Controller Class Initialized
INFO - 2023-09-10 09:39:00 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:39:00 --> Model "Home_model" initialized
INFO - 2023-09-10 09:39:00 --> Helper loaded: download_helper
INFO - 2023-09-10 09:39:00 --> Helper loaded: form_helper
INFO - 2023-09-10 09:39:00 --> Form Validation Class Initialized
INFO - 2023-09-10 09:39:00 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:39:00 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:39:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 09:39:00 --> Final output sent to browser
DEBUG - 2023-09-10 09:39:01 --> Total execution time: 0.3306
INFO - 2023-09-10 09:39:01 --> Config Class Initialized
INFO - 2023-09-10 09:39:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:01 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:01 --> URI Class Initialized
INFO - 2023-09-10 09:39:01 --> Router Class Initialized
INFO - 2023-09-10 09:39:01 --> Output Class Initialized
INFO - 2023-09-10 09:39:01 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:01 --> Input Class Initialized
INFO - 2023-09-10 09:39:01 --> Language Class Initialized
ERROR - 2023-09-10 09:39:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:01 --> Config Class Initialized
INFO - 2023-09-10 09:39:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:01 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:01 --> URI Class Initialized
INFO - 2023-09-10 09:39:01 --> Router Class Initialized
INFO - 2023-09-10 09:39:01 --> Output Class Initialized
INFO - 2023-09-10 09:39:01 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:01 --> Input Class Initialized
INFO - 2023-09-10 09:39:01 --> Language Class Initialized
ERROR - 2023-09-10 09:39:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:01 --> Config Class Initialized
INFO - 2023-09-10 09:39:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:02 --> URI Class Initialized
INFO - 2023-09-10 09:39:02 --> Router Class Initialized
INFO - 2023-09-10 09:39:02 --> Output Class Initialized
INFO - 2023-09-10 09:39:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:02 --> Input Class Initialized
INFO - 2023-09-10 09:39:02 --> Language Class Initialized
ERROR - 2023-09-10 09:39:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:02 --> Config Class Initialized
INFO - 2023-09-10 09:39:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:02 --> URI Class Initialized
INFO - 2023-09-10 09:39:02 --> Router Class Initialized
INFO - 2023-09-10 09:39:02 --> Output Class Initialized
INFO - 2023-09-10 09:39:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:02 --> Input Class Initialized
INFO - 2023-09-10 09:39:02 --> Language Class Initialized
ERROR - 2023-09-10 09:39:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:02 --> Config Class Initialized
INFO - 2023-09-10 09:39:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:02 --> URI Class Initialized
INFO - 2023-09-10 09:39:02 --> Router Class Initialized
INFO - 2023-09-10 09:39:02 --> Output Class Initialized
INFO - 2023-09-10 09:39:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:02 --> Input Class Initialized
INFO - 2023-09-10 09:39:02 --> Language Class Initialized
ERROR - 2023-09-10 09:39:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:02 --> Config Class Initialized
INFO - 2023-09-10 09:39:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:02 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:02 --> URI Class Initialized
INFO - 2023-09-10 09:39:02 --> Router Class Initialized
INFO - 2023-09-10 09:39:02 --> Output Class Initialized
INFO - 2023-09-10 09:39:02 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:02 --> Input Class Initialized
INFO - 2023-09-10 09:39:02 --> Language Class Initialized
ERROR - 2023-09-10 09:39:02 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 09:39:06 --> Config Class Initialized
INFO - 2023-09-10 09:39:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:06 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:06 --> URI Class Initialized
INFO - 2023-09-10 09:39:06 --> Router Class Initialized
INFO - 2023-09-10 09:39:06 --> Output Class Initialized
INFO - 2023-09-10 09:39:06 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:06 --> Input Class Initialized
INFO - 2023-09-10 09:39:06 --> Language Class Initialized
INFO - 2023-09-10 09:39:06 --> Loader Class Initialized
INFO - 2023-09-10 09:39:06 --> Helper loaded: url_helper
INFO - 2023-09-10 09:39:06 --> Helper loaded: file_helper
INFO - 2023-09-10 09:39:06 --> Database Driver Class Initialized
INFO - 2023-09-10 09:39:06 --> Email Class Initialized
DEBUG - 2023-09-10 09:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:39:06 --> Controller Class Initialized
INFO - 2023-09-10 09:39:06 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:39:06 --> Model "Home_model" initialized
INFO - 2023-09-10 09:39:06 --> Helper loaded: download_helper
INFO - 2023-09-10 09:39:06 --> Helper loaded: form_helper
INFO - 2023-09-10 09:39:06 --> Form Validation Class Initialized
INFO - 2023-09-10 09:39:06 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:39:06 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:39:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 09:39:06 --> Final output sent to browser
DEBUG - 2023-09-10 09:39:06 --> Total execution time: 0.0790
INFO - 2023-09-10 09:39:06 --> Config Class Initialized
INFO - 2023-09-10 09:39:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:06 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:06 --> URI Class Initialized
INFO - 2023-09-10 09:39:06 --> Router Class Initialized
INFO - 2023-09-10 09:39:06 --> Output Class Initialized
INFO - 2023-09-10 09:39:06 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:06 --> Input Class Initialized
INFO - 2023-09-10 09:39:06 --> Language Class Initialized
ERROR - 2023-09-10 09:39:06 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:06 --> Config Class Initialized
INFO - 2023-09-10 09:39:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:06 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:06 --> URI Class Initialized
INFO - 2023-09-10 09:39:06 --> Router Class Initialized
INFO - 2023-09-10 09:39:06 --> Output Class Initialized
INFO - 2023-09-10 09:39:06 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:06 --> Input Class Initialized
INFO - 2023-09-10 09:39:06 --> Language Class Initialized
ERROR - 2023-09-10 09:39:06 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:06 --> Config Class Initialized
INFO - 2023-09-10 09:39:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:06 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:06 --> URI Class Initialized
INFO - 2023-09-10 09:39:06 --> Router Class Initialized
INFO - 2023-09-10 09:39:06 --> Output Class Initialized
INFO - 2023-09-10 09:39:06 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:06 --> Input Class Initialized
INFO - 2023-09-10 09:39:06 --> Language Class Initialized
ERROR - 2023-09-10 09:39:06 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:07 --> Config Class Initialized
INFO - 2023-09-10 09:39:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:07 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:07 --> URI Class Initialized
INFO - 2023-09-10 09:39:07 --> Router Class Initialized
INFO - 2023-09-10 09:39:07 --> Output Class Initialized
INFO - 2023-09-10 09:39:07 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:07 --> Input Class Initialized
INFO - 2023-09-10 09:39:07 --> Language Class Initialized
ERROR - 2023-09-10 09:39:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:07 --> Config Class Initialized
INFO - 2023-09-10 09:39:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:07 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:07 --> URI Class Initialized
INFO - 2023-09-10 09:39:07 --> Router Class Initialized
INFO - 2023-09-10 09:39:07 --> Output Class Initialized
INFO - 2023-09-10 09:39:07 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:07 --> Input Class Initialized
INFO - 2023-09-10 09:39:07 --> Language Class Initialized
ERROR - 2023-09-10 09:39:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:39:07 --> Config Class Initialized
INFO - 2023-09-10 09:39:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:39:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:39:07 --> Utf8 Class Initialized
INFO - 2023-09-10 09:39:07 --> URI Class Initialized
INFO - 2023-09-10 09:39:07 --> Router Class Initialized
INFO - 2023-09-10 09:39:07 --> Output Class Initialized
INFO - 2023-09-10 09:39:07 --> Security Class Initialized
DEBUG - 2023-09-10 09:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:39:07 --> Input Class Initialized
INFO - 2023-09-10 09:39:07 --> Language Class Initialized
ERROR - 2023-09-10 09:39:07 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 09:42:13 --> Config Class Initialized
INFO - 2023-09-10 09:42:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:42:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:42:13 --> Utf8 Class Initialized
INFO - 2023-09-10 09:42:13 --> URI Class Initialized
DEBUG - 2023-09-10 09:42:13 --> No URI present. Default controller set.
INFO - 2023-09-10 09:42:13 --> Router Class Initialized
INFO - 2023-09-10 09:42:13 --> Output Class Initialized
INFO - 2023-09-10 09:42:13 --> Security Class Initialized
DEBUG - 2023-09-10 09:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:42:13 --> Input Class Initialized
INFO - 2023-09-10 09:42:13 --> Language Class Initialized
INFO - 2023-09-10 09:42:13 --> Loader Class Initialized
INFO - 2023-09-10 09:42:13 --> Helper loaded: url_helper
INFO - 2023-09-10 09:42:13 --> Helper loaded: file_helper
INFO - 2023-09-10 09:42:13 --> Database Driver Class Initialized
INFO - 2023-09-10 09:42:13 --> Email Class Initialized
DEBUG - 2023-09-10 09:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:42:13 --> Controller Class Initialized
INFO - 2023-09-10 09:42:13 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:42:13 --> Model "Home_model" initialized
INFO - 2023-09-10 09:42:13 --> Helper loaded: download_helper
INFO - 2023-09-10 09:42:13 --> Helper loaded: form_helper
INFO - 2023-09-10 09:42:13 --> Form Validation Class Initialized
INFO - 2023-09-10 09:42:13 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:42:13 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:42:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:42:13 --> Final output sent to browser
DEBUG - 2023-09-10 09:42:13 --> Total execution time: 0.3488
INFO - 2023-09-10 09:42:14 --> Config Class Initialized
INFO - 2023-09-10 09:42:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:42:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:42:15 --> Utf8 Class Initialized
INFO - 2023-09-10 09:42:15 --> URI Class Initialized
INFO - 2023-09-10 09:42:15 --> Router Class Initialized
INFO - 2023-09-10 09:42:15 --> Output Class Initialized
INFO - 2023-09-10 09:42:15 --> Security Class Initialized
DEBUG - 2023-09-10 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:42:15 --> Input Class Initialized
INFO - 2023-09-10 09:42:15 --> Language Class Initialized
ERROR - 2023-09-10 09:42:15 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:53:48 --> Config Class Initialized
INFO - 2023-09-10 09:53:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:53:48 --> Utf8 Class Initialized
INFO - 2023-09-10 09:53:48 --> URI Class Initialized
DEBUG - 2023-09-10 09:53:48 --> No URI present. Default controller set.
INFO - 2023-09-10 09:53:49 --> Router Class Initialized
INFO - 2023-09-10 09:53:49 --> Output Class Initialized
INFO - 2023-09-10 09:53:49 --> Security Class Initialized
DEBUG - 2023-09-10 09:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:53:49 --> Input Class Initialized
INFO - 2023-09-10 09:53:49 --> Language Class Initialized
INFO - 2023-09-10 09:53:49 --> Loader Class Initialized
INFO - 2023-09-10 09:53:49 --> Helper loaded: url_helper
INFO - 2023-09-10 09:53:49 --> Helper loaded: file_helper
INFO - 2023-09-10 09:53:49 --> Database Driver Class Initialized
INFO - 2023-09-10 09:53:49 --> Email Class Initialized
DEBUG - 2023-09-10 09:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:53:49 --> Controller Class Initialized
INFO - 2023-09-10 09:53:49 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:53:49 --> Model "Home_model" initialized
INFO - 2023-09-10 09:53:49 --> Helper loaded: download_helper
INFO - 2023-09-10 09:53:49 --> Helper loaded: form_helper
INFO - 2023-09-10 09:53:49 --> Form Validation Class Initialized
INFO - 2023-09-10 09:53:49 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:53:49 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:53:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:53:49 --> Final output sent to browser
DEBUG - 2023-09-10 09:53:49 --> Total execution time: 0.6442
INFO - 2023-09-10 09:53:50 --> Config Class Initialized
INFO - 2023-09-10 09:53:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:53:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:53:50 --> Utf8 Class Initialized
INFO - 2023-09-10 09:53:50 --> URI Class Initialized
INFO - 2023-09-10 09:53:50 --> Router Class Initialized
INFO - 2023-09-10 09:53:50 --> Output Class Initialized
INFO - 2023-09-10 09:53:50 --> Security Class Initialized
DEBUG - 2023-09-10 09:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:53:51 --> Input Class Initialized
INFO - 2023-09-10 09:53:51 --> Language Class Initialized
ERROR - 2023-09-10 09:53:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:57:38 --> Config Class Initialized
INFO - 2023-09-10 09:57:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:57:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:57:38 --> Utf8 Class Initialized
INFO - 2023-09-10 09:57:38 --> URI Class Initialized
DEBUG - 2023-09-10 09:57:38 --> No URI present. Default controller set.
INFO - 2023-09-10 09:57:38 --> Router Class Initialized
INFO - 2023-09-10 09:57:38 --> Output Class Initialized
INFO - 2023-09-10 09:57:38 --> Security Class Initialized
DEBUG - 2023-09-10 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:57:38 --> Input Class Initialized
INFO - 2023-09-10 09:57:38 --> Language Class Initialized
INFO - 2023-09-10 09:57:38 --> Loader Class Initialized
INFO - 2023-09-10 09:57:38 --> Helper loaded: url_helper
INFO - 2023-09-10 09:57:38 --> Helper loaded: file_helper
INFO - 2023-09-10 09:57:38 --> Database Driver Class Initialized
INFO - 2023-09-10 09:57:38 --> Email Class Initialized
DEBUG - 2023-09-10 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 09:57:38 --> Controller Class Initialized
INFO - 2023-09-10 09:57:38 --> Model "Contact_model" initialized
INFO - 2023-09-10 09:57:38 --> Model "Home_model" initialized
INFO - 2023-09-10 09:57:38 --> Helper loaded: download_helper
INFO - 2023-09-10 09:57:38 --> Helper loaded: form_helper
INFO - 2023-09-10 09:57:38 --> Form Validation Class Initialized
INFO - 2023-09-10 09:57:38 --> Helper loaded: custom_helper
INFO - 2023-09-10 09:57:38 --> Model "Social_media_model" initialized
INFO - 2023-09-10 09:57:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 09:57:38 --> Final output sent to browser
DEBUG - 2023-09-10 09:57:38 --> Total execution time: 0.5322
INFO - 2023-09-10 09:57:40 --> Config Class Initialized
INFO - 2023-09-10 09:57:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:57:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:57:40 --> Utf8 Class Initialized
INFO - 2023-09-10 09:57:40 --> URI Class Initialized
INFO - 2023-09-10 09:57:40 --> Router Class Initialized
INFO - 2023-09-10 09:57:41 --> Output Class Initialized
INFO - 2023-09-10 09:57:41 --> Security Class Initialized
DEBUG - 2023-09-10 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:57:41 --> Input Class Initialized
INFO - 2023-09-10 09:57:41 --> Language Class Initialized
ERROR - 2023-09-10 09:57:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:58:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 09:58:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:58:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:16 --> Utf8 Class Initialized
INFO - 2023-09-10 09:58:16 --> URI Class Initialized
INFO - 2023-09-10 09:58:16 --> Router Class Initialized
INFO - 2023-09-10 09:58:16 --> Output Class Initialized
INFO - 2023-09-10 09:58:16 --> Security Class Initialized
DEBUG - 2023-09-10 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:16 --> Input Class Initialized
INFO - 2023-09-10 09:58:16 --> Language Class Initialized
ERROR - 2023-09-10 09:58:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 09:58:16 --> Utf8 Class Initialized
DEBUG - 2023-09-10 09:58:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:16 --> Utf8 Class Initialized
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Config Class Initialized
INFO - 2023-09-10 09:58:16 --> Utf8 Class Initialized
INFO - 2023-09-10 09:58:16 --> URI Class Initialized
INFO - 2023-09-10 09:58:16 --> URI Class Initialized
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
INFO - 2023-09-10 09:58:16 --> Hooks Class Initialized
INFO - 2023-09-10 09:58:16 --> Router Class Initialized
INFO - 2023-09-10 09:58:16 --> URI Class Initialized
DEBUG - 2023-09-10 09:58:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:17 --> Utf8 Class Initialized
INFO - 2023-09-10 09:58:17 --> Router Class Initialized
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
INFO - 2023-09-10 09:58:17 --> URI Class Initialized
INFO - 2023-09-10 09:58:17 --> Router Class Initialized
DEBUG - 2023-09-10 09:58:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:17 --> Router Class Initialized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
INFO - 2023-09-10 09:58:17 --> Utf8 Class Initialized
INFO - 2023-09-10 09:58:17 --> Config Class Initialized
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
INFO - 2023-09-10 09:58:17 --> URI Class Initialized
INFO - 2023-09-10 09:58:17 --> Router Class Initialized
INFO - 2023-09-10 09:58:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 09:58:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 09:58:17 --> Utf8 Class Initialized
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:17 --> URI Class Initialized
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:17 --> Router Class Initialized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 09:58:17 --> Output Class Initialized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
INFO - 2023-09-10 09:58:17 --> Security Class Initialized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 09:58:17 --> Input Class Initialized
INFO - 2023-09-10 09:58:17 --> Language Class Initialized
ERROR - 2023-09-10 09:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:00:50 --> Config Class Initialized
INFO - 2023-09-10 10:00:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:00:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:50 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:50 --> URI Class Initialized
DEBUG - 2023-09-10 10:00:50 --> No URI present. Default controller set.
INFO - 2023-09-10 10:00:50 --> Router Class Initialized
INFO - 2023-09-10 10:00:50 --> Output Class Initialized
INFO - 2023-09-10 10:00:50 --> Security Class Initialized
DEBUG - 2023-09-10 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:50 --> Input Class Initialized
INFO - 2023-09-10 10:00:50 --> Language Class Initialized
INFO - 2023-09-10 10:00:50 --> Loader Class Initialized
INFO - 2023-09-10 10:00:50 --> Helper loaded: url_helper
INFO - 2023-09-10 10:00:50 --> Helper loaded: file_helper
INFO - 2023-09-10 10:00:50 --> Database Driver Class Initialized
INFO - 2023-09-10 10:00:50 --> Email Class Initialized
DEBUG - 2023-09-10 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:00:50 --> Controller Class Initialized
INFO - 2023-09-10 10:00:51 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:00:51 --> Model "Home_model" initialized
INFO - 2023-09-10 10:00:51 --> Helper loaded: download_helper
INFO - 2023-09-10 10:00:51 --> Helper loaded: form_helper
INFO - 2023-09-10 10:00:51 --> Form Validation Class Initialized
INFO - 2023-09-10 10:00:51 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:00:51 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:00:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:00:51 --> Final output sent to browser
DEBUG - 2023-09-10 10:00:51 --> Total execution time: 0.9668
INFO - 2023-09-10 10:00:53 --> Config Class Initialized
INFO - 2023-09-10 10:00:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:00:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:53 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:54 --> URI Class Initialized
INFO - 2023-09-10 10:00:54 --> Router Class Initialized
INFO - 2023-09-10 10:00:54 --> Output Class Initialized
INFO - 2023-09-10 10:00:54 --> Security Class Initialized
DEBUG - 2023-09-10 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:54 --> Input Class Initialized
INFO - 2023-09-10 10:00:55 --> Language Class Initialized
ERROR - 2023-09-10 10:00:55 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:00:55 --> Config Class Initialized
INFO - 2023-09-10 10:00:55 --> Hooks Class Initialized
INFO - 2023-09-10 10:00:56 --> Config Class Initialized
INFO - 2023-09-10 10:00:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:00:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:56 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:00:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:56 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:56 --> URI Class Initialized
INFO - 2023-09-10 10:00:56 --> URI Class Initialized
INFO - 2023-09-10 10:00:56 --> Router Class Initialized
INFO - 2023-09-10 10:00:56 --> Router Class Initialized
INFO - 2023-09-10 10:00:56 --> Output Class Initialized
INFO - 2023-09-10 10:00:56 --> Output Class Initialized
INFO - 2023-09-10 10:00:56 --> Security Class Initialized
DEBUG - 2023-09-10 10:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:56 --> Security Class Initialized
INFO - 2023-09-10 10:00:56 --> Input Class Initialized
DEBUG - 2023-09-10 10:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:56 --> Language Class Initialized
INFO - 2023-09-10 10:00:56 --> Input Class Initialized
ERROR - 2023-09-10 10:00:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:00:56 --> Language Class Initialized
INFO - 2023-09-10 10:00:56 --> Config Class Initialized
ERROR - 2023-09-10 10:00:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:00:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:00:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:56 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:56 --> URI Class Initialized
INFO - 2023-09-10 10:00:56 --> Router Class Initialized
INFO - 2023-09-10 10:00:56 --> Output Class Initialized
INFO - 2023-09-10 10:00:56 --> Security Class Initialized
DEBUG - 2023-09-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:57 --> Input Class Initialized
INFO - 2023-09-10 10:00:57 --> Language Class Initialized
ERROR - 2023-09-10 10:00:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:00:57 --> Config Class Initialized
INFO - 2023-09-10 10:00:57 --> Hooks Class Initialized
INFO - 2023-09-10 10:00:57 --> Config Class Initialized
INFO - 2023-09-10 10:00:57 --> Config Class Initialized
INFO - 2023-09-10 10:00:57 --> Hooks Class Initialized
INFO - 2023-09-10 10:00:57 --> Hooks Class Initialized
INFO - 2023-09-10 10:00:57 --> Config Class Initialized
DEBUG - 2023-09-10 10:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:00:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:57 --> URI Class Initialized
INFO - 2023-09-10 10:00:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:57 --> Hooks Class Initialized
INFO - 2023-09-10 10:00:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:57 --> Router Class Initialized
INFO - 2023-09-10 10:00:57 --> URI Class Initialized
INFO - 2023-09-10 10:00:57 --> Output Class Initialized
DEBUG - 2023-09-10 10:00:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:00:57 --> URI Class Initialized
INFO - 2023-09-10 10:00:57 --> Router Class Initialized
INFO - 2023-09-10 10:00:57 --> Security Class Initialized
INFO - 2023-09-10 10:00:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:00:57 --> URI Class Initialized
INFO - 2023-09-10 10:00:57 --> Output Class Initialized
INFO - 2023-09-10 10:00:57 --> Router Class Initialized
DEBUG - 2023-09-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:57 --> Security Class Initialized
INFO - 2023-09-10 10:00:57 --> Router Class Initialized
INFO - 2023-09-10 10:00:57 --> Input Class Initialized
INFO - 2023-09-10 10:00:57 --> Output Class Initialized
DEBUG - 2023-09-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:57 --> Output Class Initialized
INFO - 2023-09-10 10:00:57 --> Security Class Initialized
INFO - 2023-09-10 10:00:57 --> Input Class Initialized
INFO - 2023-09-10 10:00:57 --> Language Class Initialized
INFO - 2023-09-10 10:00:57 --> Security Class Initialized
DEBUG - 2023-09-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 10:00:57 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:00:57 --> Input Class Initialized
INFO - 2023-09-10 10:00:57 --> Language Class Initialized
ERROR - 2023-09-10 10:00:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:00:57 --> Language Class Initialized
INFO - 2023-09-10 10:00:57 --> Input Class Initialized
INFO - 2023-09-10 10:00:57 --> Language Class Initialized
ERROR - 2023-09-10 10:00:57 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:00:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:32 --> Config Class Initialized
INFO - 2023-09-10 10:06:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:32 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:32 --> URI Class Initialized
DEBUG - 2023-09-10 10:06:32 --> No URI present. Default controller set.
INFO - 2023-09-10 10:06:32 --> Router Class Initialized
INFO - 2023-09-10 10:06:32 --> Output Class Initialized
INFO - 2023-09-10 10:06:32 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:32 --> Input Class Initialized
INFO - 2023-09-10 10:06:32 --> Language Class Initialized
INFO - 2023-09-10 10:06:32 --> Loader Class Initialized
INFO - 2023-09-10 10:06:32 --> Helper loaded: url_helper
INFO - 2023-09-10 10:06:32 --> Helper loaded: file_helper
INFO - 2023-09-10 10:06:32 --> Database Driver Class Initialized
INFO - 2023-09-10 10:06:32 --> Email Class Initialized
DEBUG - 2023-09-10 10:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:06:32 --> Controller Class Initialized
INFO - 2023-09-10 10:06:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:06:32 --> Model "Home_model" initialized
INFO - 2023-09-10 10:06:32 --> Helper loaded: download_helper
INFO - 2023-09-10 10:06:32 --> Helper loaded: form_helper
INFO - 2023-09-10 10:06:32 --> Form Validation Class Initialized
INFO - 2023-09-10 10:06:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:06:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:06:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:06:32 --> Final output sent to browser
DEBUG - 2023-09-10 10:06:33 --> Total execution time: 0.7258
INFO - 2023-09-10 10:06:33 --> Config Class Initialized
INFO - 2023-09-10 10:06:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:33 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:33 --> URI Class Initialized
INFO - 2023-09-10 10:06:33 --> Router Class Initialized
INFO - 2023-09-10 10:06:33 --> Output Class Initialized
INFO - 2023-09-10 10:06:33 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:33 --> Input Class Initialized
INFO - 2023-09-10 10:06:33 --> Language Class Initialized
ERROR - 2023-09-10 10:06:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:06:34 --> Config Class Initialized
INFO - 2023-09-10 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:34 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:34 --> URI Class Initialized
INFO - 2023-09-10 10:06:34 --> Router Class Initialized
INFO - 2023-09-10 10:06:34 --> Output Class Initialized
INFO - 2023-09-10 10:06:34 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:34 --> Input Class Initialized
INFO - 2023-09-10 10:06:34 --> Language Class Initialized
ERROR - 2023-09-10 10:06:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:35 --> Config Class Initialized
INFO - 2023-09-10 10:06:35 --> Hooks Class Initialized
INFO - 2023-09-10 10:06:35 --> Config Class Initialized
INFO - 2023-09-10 10:06:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:35 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:35 --> URI Class Initialized
INFO - 2023-09-10 10:06:35 --> Router Class Initialized
INFO - 2023-09-10 10:06:35 --> Output Class Initialized
INFO - 2023-09-10 10:06:35 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:35 --> Input Class Initialized
INFO - 2023-09-10 10:06:35 --> Language Class Initialized
ERROR - 2023-09-10 10:06:35 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:06:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:36 --> Config Class Initialized
INFO - 2023-09-10 10:06:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:36 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:36 --> URI Class Initialized
INFO - 2023-09-10 10:06:36 --> Router Class Initialized
INFO - 2023-09-10 10:06:36 --> Output Class Initialized
INFO - 2023-09-10 10:06:36 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:36 --> Input Class Initialized
INFO - 2023-09-10 10:06:36 --> Language Class Initialized
ERROR - 2023-09-10 10:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:36 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:36 --> URI Class Initialized
INFO - 2023-09-10 10:06:36 --> Router Class Initialized
INFO - 2023-09-10 10:06:36 --> Output Class Initialized
INFO - 2023-09-10 10:06:36 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:36 --> Input Class Initialized
INFO - 2023-09-10 10:06:36 --> Language Class Initialized
ERROR - 2023-09-10 10:06:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:37 --> Config Class Initialized
INFO - 2023-09-10 10:06:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:38 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:38 --> URI Class Initialized
INFO - 2023-09-10 10:06:38 --> Router Class Initialized
INFO - 2023-09-10 10:06:38 --> Output Class Initialized
INFO - 2023-09-10 10:06:38 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:39 --> Input Class Initialized
INFO - 2023-09-10 10:06:39 --> Language Class Initialized
ERROR - 2023-09-10 10:06:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:39 --> Config Class Initialized
INFO - 2023-09-10 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:39 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:39 --> URI Class Initialized
INFO - 2023-09-10 10:06:39 --> Router Class Initialized
INFO - 2023-09-10 10:06:39 --> Output Class Initialized
INFO - 2023-09-10 10:06:39 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:39 --> Input Class Initialized
INFO - 2023-09-10 10:06:39 --> Language Class Initialized
ERROR - 2023-09-10 10:06:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:40 --> Config Class Initialized
INFO - 2023-09-10 10:06:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:40 --> URI Class Initialized
INFO - 2023-09-10 10:06:40 --> Router Class Initialized
INFO - 2023-09-10 10:06:40 --> Output Class Initialized
INFO - 2023-09-10 10:06:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:40 --> Input Class Initialized
INFO - 2023-09-10 10:06:40 --> Language Class Initialized
ERROR - 2023-09-10 10:06:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:41 --> Config Class Initialized
INFO - 2023-09-10 10:06:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:41 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:41 --> URI Class Initialized
DEBUG - 2023-09-10 10:06:41 --> No URI present. Default controller set.
INFO - 2023-09-10 10:06:41 --> Router Class Initialized
INFO - 2023-09-10 10:06:41 --> Output Class Initialized
INFO - 2023-09-10 10:06:41 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:41 --> Input Class Initialized
INFO - 2023-09-10 10:06:41 --> Language Class Initialized
INFO - 2023-09-10 10:06:41 --> Loader Class Initialized
INFO - 2023-09-10 10:06:41 --> Helper loaded: url_helper
INFO - 2023-09-10 10:06:41 --> Helper loaded: file_helper
INFO - 2023-09-10 10:06:41 --> Database Driver Class Initialized
INFO - 2023-09-10 10:06:41 --> Email Class Initialized
DEBUG - 2023-09-10 10:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:06:41 --> Controller Class Initialized
INFO - 2023-09-10 10:06:41 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:06:41 --> Model "Home_model" initialized
INFO - 2023-09-10 10:06:41 --> Helper loaded: download_helper
INFO - 2023-09-10 10:06:41 --> Helper loaded: form_helper
INFO - 2023-09-10 10:06:41 --> Form Validation Class Initialized
INFO - 2023-09-10 10:06:41 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:06:41 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:06:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:06:41 --> Final output sent to browser
DEBUG - 2023-09-10 10:06:41 --> Total execution time: 0.0677
INFO - 2023-09-10 10:06:42 --> Config Class Initialized
INFO - 2023-09-10 10:06:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:42 --> URI Class Initialized
INFO - 2023-09-10 10:06:42 --> Router Class Initialized
INFO - 2023-09-10 10:06:42 --> Output Class Initialized
INFO - 2023-09-10 10:06:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:42 --> Input Class Initialized
INFO - 2023-09-10 10:06:42 --> Language Class Initialized
ERROR - 2023-09-10 10:06:42 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:06:43 --> Config Class Initialized
INFO - 2023-09-10 10:06:44 --> Hooks Class Initialized
INFO - 2023-09-10 10:06:44 --> Config Class Initialized
INFO - 2023-09-10 10:06:44 --> Hooks Class Initialized
INFO - 2023-09-10 10:06:44 --> Config Class Initialized
INFO - 2023-09-10 10:06:44 --> Config Class Initialized
DEBUG - 2023-09-10 10:06:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:44 --> URI Class Initialized
INFO - 2023-09-10 10:06:44 --> Router Class Initialized
INFO - 2023-09-10 10:06:44 --> Output Class Initialized
INFO - 2023-09-10 10:06:44 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:44 --> Input Class Initialized
INFO - 2023-09-10 10:06:44 --> Language Class Initialized
ERROR - 2023-09-10 10:06:44 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:06:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:44 --> Config Class Initialized
INFO - 2023-09-10 10:06:44 --> Hooks Class Initialized
INFO - 2023-09-10 10:06:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:44 --> URI Class Initialized
INFO - 2023-09-10 10:06:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:06:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:06:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:06:44 --> URI Class Initialized
INFO - 2023-09-10 10:06:45 --> URI Class Initialized
INFO - 2023-09-10 10:06:45 --> Router Class Initialized
INFO - 2023-09-10 10:06:45 --> Router Class Initialized
INFO - 2023-09-10 10:06:45 --> Output Class Initialized
INFO - 2023-09-10 10:06:45 --> URI Class Initialized
INFO - 2023-09-10 10:06:45 --> Router Class Initialized
INFO - 2023-09-10 10:06:45 --> Router Class Initialized
INFO - 2023-09-10 10:06:45 --> Output Class Initialized
INFO - 2023-09-10 10:06:45 --> Output Class Initialized
INFO - 2023-09-10 10:06:45 --> Security Class Initialized
INFO - 2023-09-10 10:06:45 --> Security Class Initialized
INFO - 2023-09-10 10:06:45 --> Output Class Initialized
DEBUG - 2023-09-10 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:45 --> Security Class Initialized
DEBUG - 2023-09-10 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:45 --> Input Class Initialized
INFO - 2023-09-10 10:06:45 --> Security Class Initialized
INFO - 2023-09-10 10:06:45 --> Language Class Initialized
DEBUG - 2023-09-10 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:45 --> Input Class Initialized
INFO - 2023-09-10 10:06:45 --> Language Class Initialized
INFO - 2023-09-10 10:06:45 --> Input Class Initialized
DEBUG - 2023-09-10 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:06:45 --> Language Class Initialized
ERROR - 2023-09-10 10:06:45 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:06:45 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:45 --> Input Class Initialized
ERROR - 2023-09-10 10:06:46 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:06:46 --> Language Class Initialized
ERROR - 2023-09-10 10:06:46 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:08:27 --> Config Class Initialized
INFO - 2023-09-10 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:08:27 --> Utf8 Class Initialized
INFO - 2023-09-10 10:08:27 --> URI Class Initialized
DEBUG - 2023-09-10 10:08:27 --> No URI present. Default controller set.
INFO - 2023-09-10 10:08:27 --> Router Class Initialized
INFO - 2023-09-10 10:08:27 --> Output Class Initialized
INFO - 2023-09-10 10:08:27 --> Security Class Initialized
DEBUG - 2023-09-10 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:08:27 --> Input Class Initialized
INFO - 2023-09-10 10:08:27 --> Language Class Initialized
INFO - 2023-09-10 10:08:27 --> Loader Class Initialized
INFO - 2023-09-10 10:08:27 --> Helper loaded: url_helper
INFO - 2023-09-10 10:08:27 --> Helper loaded: file_helper
INFO - 2023-09-10 10:08:27 --> Database Driver Class Initialized
INFO - 2023-09-10 10:08:27 --> Email Class Initialized
DEBUG - 2023-09-10 10:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:08:27 --> Controller Class Initialized
INFO - 2023-09-10 10:08:27 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:08:28 --> Model "Home_model" initialized
INFO - 2023-09-10 10:08:28 --> Helper loaded: download_helper
INFO - 2023-09-10 10:08:28 --> Helper loaded: form_helper
INFO - 2023-09-10 10:08:28 --> Form Validation Class Initialized
INFO - 2023-09-10 10:08:28 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:08:28 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:08:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:08:28 --> Final output sent to browser
DEBUG - 2023-09-10 10:08:28 --> Total execution time: 0.3712
INFO - 2023-09-10 10:08:29 --> Config Class Initialized
INFO - 2023-09-10 10:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:08:29 --> Utf8 Class Initialized
INFO - 2023-09-10 10:08:29 --> URI Class Initialized
INFO - 2023-09-10 10:08:29 --> Router Class Initialized
INFO - 2023-09-10 10:08:29 --> Output Class Initialized
INFO - 2023-09-10 10:08:29 --> Security Class Initialized
DEBUG - 2023-09-10 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:08:29 --> Input Class Initialized
INFO - 2023-09-10 10:08:29 --> Language Class Initialized
ERROR - 2023-09-10 10:08:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:15:38 --> Config Class Initialized
INFO - 2023-09-10 10:15:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:39 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:39 --> URI Class Initialized
INFO - 2023-09-10 10:15:39 --> Router Class Initialized
INFO - 2023-09-10 10:15:39 --> Output Class Initialized
INFO - 2023-09-10 10:15:39 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:39 --> Input Class Initialized
INFO - 2023-09-10 10:15:39 --> Language Class Initialized
INFO - 2023-09-10 10:15:39 --> Loader Class Initialized
INFO - 2023-09-10 10:15:39 --> Helper loaded: url_helper
INFO - 2023-09-10 10:15:39 --> Helper loaded: file_helper
INFO - 2023-09-10 10:15:39 --> Database Driver Class Initialized
INFO - 2023-09-10 10:15:39 --> Email Class Initialized
DEBUG - 2023-09-10 10:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:15:39 --> Controller Class Initialized
INFO - 2023-09-10 10:15:39 --> Model "User_model" initialized
INFO - 2023-09-10 10:15:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-10 10:15:39 --> Final output sent to browser
DEBUG - 2023-09-10 10:15:39 --> Total execution time: 0.3491
INFO - 2023-09-10 10:15:40 --> Config Class Initialized
INFO - 2023-09-10 10:15:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:40 --> URI Class Initialized
INFO - 2023-09-10 10:15:40 --> Router Class Initialized
INFO - 2023-09-10 10:15:40 --> Output Class Initialized
INFO - 2023-09-10 10:15:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:40 --> Input Class Initialized
INFO - 2023-09-10 10:15:40 --> Language Class Initialized
ERROR - 2023-09-10 10:15:40 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-10 10:15:48 --> Config Class Initialized
INFO - 2023-09-10 10:15:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:48 --> URI Class Initialized
INFO - 2023-09-10 10:15:48 --> Router Class Initialized
INFO - 2023-09-10 10:15:48 --> Output Class Initialized
INFO - 2023-09-10 10:15:48 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:48 --> Input Class Initialized
INFO - 2023-09-10 10:15:48 --> Language Class Initialized
INFO - 2023-09-10 10:15:48 --> Loader Class Initialized
INFO - 2023-09-10 10:15:48 --> Helper loaded: url_helper
INFO - 2023-09-10 10:15:48 --> Helper loaded: file_helper
INFO - 2023-09-10 10:15:48 --> Database Driver Class Initialized
INFO - 2023-09-10 10:15:48 --> Email Class Initialized
DEBUG - 2023-09-10 10:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:15:48 --> Controller Class Initialized
INFO - 2023-09-10 10:15:48 --> Model "User_model" initialized
INFO - 2023-09-10 10:15:48 --> Config Class Initialized
INFO - 2023-09-10 10:15:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:48 --> URI Class Initialized
INFO - 2023-09-10 10:15:48 --> Router Class Initialized
INFO - 2023-09-10 10:15:48 --> Output Class Initialized
INFO - 2023-09-10 10:15:48 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:48 --> Input Class Initialized
INFO - 2023-09-10 10:15:48 --> Language Class Initialized
INFO - 2023-09-10 10:15:48 --> Loader Class Initialized
INFO - 2023-09-10 10:15:48 --> Helper loaded: url_helper
INFO - 2023-09-10 10:15:48 --> Helper loaded: file_helper
INFO - 2023-09-10 10:15:48 --> Database Driver Class Initialized
INFO - 2023-09-10 10:15:48 --> Email Class Initialized
DEBUG - 2023-09-10 10:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:15:48 --> Controller Class Initialized
INFO - 2023-09-10 10:15:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-10 10:15:49 --> Final output sent to browser
DEBUG - 2023-09-10 10:15:49 --> Total execution time: 0.4125
INFO - 2023-09-10 10:15:55 --> Config Class Initialized
INFO - 2023-09-10 10:15:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:55 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:55 --> URI Class Initialized
INFO - 2023-09-10 10:15:55 --> Router Class Initialized
INFO - 2023-09-10 10:15:55 --> Output Class Initialized
INFO - 2023-09-10 10:15:55 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:55 --> Input Class Initialized
INFO - 2023-09-10 10:15:55 --> Language Class Initialized
INFO - 2023-09-10 10:15:55 --> Loader Class Initialized
INFO - 2023-09-10 10:15:55 --> Helper loaded: url_helper
INFO - 2023-09-10 10:15:55 --> Helper loaded: file_helper
INFO - 2023-09-10 10:15:55 --> Database Driver Class Initialized
INFO - 2023-09-10 10:15:55 --> Email Class Initialized
DEBUG - 2023-09-10 10:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:15:55 --> Controller Class Initialized
INFO - 2023-09-10 10:15:55 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:15:55 --> Helper loaded: form_helper
INFO - 2023-09-10 10:15:55 --> Form Validation Class Initialized
ERROR - 2023-09-10 10:15:56 --> Severity: Warning --> Undefined array key "mission_image" C:\xampp\htdocs\dw\application\views\admin\social_media_create.php 141
ERROR - 2023-09-10 10:15:56 --> Severity: Warning --> Undefined array key "vision_image" C:\xampp\htdocs\dw\application\views\admin\social_media_create.php 170
ERROR - 2023-09-10 10:15:56 --> Severity: Warning --> Undefined array key "value_image" C:\xampp\htdocs\dw\application\views\admin\social_media_create.php 199
INFO - 2023-09-10 10:15:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-10 10:15:56 --> Final output sent to browser
DEBUG - 2023-09-10 10:15:56 --> Total execution time: 0.4671
INFO - 2023-09-10 10:15:57 --> Config Class Initialized
INFO - 2023-09-10 10:15:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:15:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:15:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:15:57 --> URI Class Initialized
INFO - 2023-09-10 10:15:57 --> Router Class Initialized
INFO - 2023-09-10 10:15:57 --> Output Class Initialized
INFO - 2023-09-10 10:15:57 --> Security Class Initialized
DEBUG - 2023-09-10 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:15:57 --> Input Class Initialized
INFO - 2023-09-10 10:15:57 --> Language Class Initialized
ERROR - 2023-09-10 10:15:57 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-10 10:19:30 --> Config Class Initialized
INFO - 2023-09-10 10:19:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:19:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:19:30 --> Utf8 Class Initialized
INFO - 2023-09-10 10:19:30 --> URI Class Initialized
INFO - 2023-09-10 10:19:30 --> Router Class Initialized
INFO - 2023-09-10 10:19:30 --> Output Class Initialized
INFO - 2023-09-10 10:19:30 --> Security Class Initialized
DEBUG - 2023-09-10 10:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:19:30 --> Input Class Initialized
INFO - 2023-09-10 10:19:30 --> Language Class Initialized
INFO - 2023-09-10 10:19:30 --> Loader Class Initialized
INFO - 2023-09-10 10:19:30 --> Helper loaded: url_helper
INFO - 2023-09-10 10:19:30 --> Helper loaded: file_helper
INFO - 2023-09-10 10:19:30 --> Database Driver Class Initialized
INFO - 2023-09-10 10:19:30 --> Email Class Initialized
DEBUG - 2023-09-10 10:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:19:30 --> Controller Class Initialized
INFO - 2023-09-10 10:19:30 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:19:30 --> Helper loaded: form_helper
INFO - 2023-09-10 10:19:30 --> Form Validation Class Initialized
ERROR - 2023-09-10 10:19:30 --> Query error: Unknown column 'mission_image' in 'field list' - Invalid query: UPDATE `social_media` SET `gmail` = 'xpXgqbzpdRw', `facebook` = '3dtWFZXMnn', `twitter` = 'dJJfIw8Q9M', `instagram` = '3a95TbUbuE', `pinterest` = 'S5i5Vm90Ar', `whatsapp` = 'tC0RtEyc4z', `quora` = 'tceekphwi7', `linkedin` = '7OVCgel1dC', `mission_image` = '', `mission` = 'Our mission is to provide exceptional digital marketing solutions that drive tangible results for our clients. We are committed to helping businesses unlock their full potential in the online landscape through strategic planning, innovative strategies, and data-driven insights. By staying at the forefront of digital marketing trends and technologies, we aim to deliver measurable success, enhance brand visibility, and maximize return on investment for our clients.', `vision_image` = '', `vision` = 'd', `value_image` = '', `value` = 'w', `created_at` = '2023-09-10 10:19:30'
WHERE `id` = '1'
INFO - 2023-09-10 10:19:30 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-10 10:22:33 --> Config Class Initialized
INFO - 2023-09-10 10:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:22:33 --> Utf8 Class Initialized
INFO - 2023-09-10 10:22:33 --> URI Class Initialized
INFO - 2023-09-10 10:22:33 --> Router Class Initialized
INFO - 2023-09-10 10:22:33 --> Output Class Initialized
INFO - 2023-09-10 10:22:33 --> Security Class Initialized
DEBUG - 2023-09-10 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:22:33 --> Input Class Initialized
INFO - 2023-09-10 10:22:33 --> Language Class Initialized
INFO - 2023-09-10 10:22:33 --> Loader Class Initialized
INFO - 2023-09-10 10:22:33 --> Helper loaded: url_helper
INFO - 2023-09-10 10:22:33 --> Helper loaded: file_helper
INFO - 2023-09-10 10:22:33 --> Database Driver Class Initialized
INFO - 2023-09-10 10:22:33 --> Email Class Initialized
DEBUG - 2023-09-10 10:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:22:33 --> Controller Class Initialized
INFO - 2023-09-10 10:22:33 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:22:33 --> Helper loaded: form_helper
INFO - 2023-09-10 10:22:33 --> Form Validation Class Initialized
INFO - 2023-09-10 10:22:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-10 10:22:33 --> Final output sent to browser
DEBUG - 2023-09-10 10:22:33 --> Total execution time: 0.5239
INFO - 2023-09-10 10:24:42 --> Config Class Initialized
INFO - 2023-09-10 10:24:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:24:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:24:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:24:42 --> URI Class Initialized
INFO - 2023-09-10 10:24:42 --> Router Class Initialized
INFO - 2023-09-10 10:24:42 --> Output Class Initialized
INFO - 2023-09-10 10:24:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:24:42 --> Input Class Initialized
INFO - 2023-09-10 10:24:42 --> Language Class Initialized
INFO - 2023-09-10 10:24:42 --> Loader Class Initialized
INFO - 2023-09-10 10:24:42 --> Helper loaded: url_helper
INFO - 2023-09-10 10:24:42 --> Helper loaded: file_helper
INFO - 2023-09-10 10:24:43 --> Database Driver Class Initialized
INFO - 2023-09-10 10:24:43 --> Email Class Initialized
DEBUG - 2023-09-10 10:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:24:43 --> Controller Class Initialized
INFO - 2023-09-10 10:24:43 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:24:43 --> Helper loaded: form_helper
INFO - 2023-09-10 10:24:43 --> Form Validation Class Initialized
INFO - 2023-09-10 10:24:43 --> Config Class Initialized
INFO - 2023-09-10 10:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:24:43 --> Utf8 Class Initialized
INFO - 2023-09-10 10:24:43 --> URI Class Initialized
INFO - 2023-09-10 10:24:43 --> Router Class Initialized
INFO - 2023-09-10 10:24:43 --> Output Class Initialized
INFO - 2023-09-10 10:24:43 --> Security Class Initialized
DEBUG - 2023-09-10 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:24:43 --> Input Class Initialized
INFO - 2023-09-10 10:24:43 --> Language Class Initialized
INFO - 2023-09-10 10:24:43 --> Loader Class Initialized
INFO - 2023-09-10 10:24:43 --> Helper loaded: url_helper
INFO - 2023-09-10 10:24:43 --> Helper loaded: file_helper
INFO - 2023-09-10 10:24:43 --> Database Driver Class Initialized
INFO - 2023-09-10 10:24:43 --> Email Class Initialized
DEBUG - 2023-09-10 10:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:24:43 --> Controller Class Initialized
INFO - 2023-09-10 10:24:43 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:24:43 --> Helper loaded: form_helper
INFO - 2023-09-10 10:24:43 --> Form Validation Class Initialized
INFO - 2023-09-10 10:24:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-10 10:24:43 --> Final output sent to browser
DEBUG - 2023-09-10 10:24:44 --> Total execution time: 0.5085
INFO - 2023-09-10 10:25:03 --> Config Class Initialized
INFO - 2023-09-10 10:25:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:25:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:25:04 --> Utf8 Class Initialized
INFO - 2023-09-10 10:25:04 --> URI Class Initialized
INFO - 2023-09-10 10:25:04 --> Router Class Initialized
INFO - 2023-09-10 10:25:04 --> Output Class Initialized
INFO - 2023-09-10 10:25:04 --> Security Class Initialized
DEBUG - 2023-09-10 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:25:04 --> Input Class Initialized
INFO - 2023-09-10 10:25:04 --> Language Class Initialized
INFO - 2023-09-10 10:25:04 --> Loader Class Initialized
INFO - 2023-09-10 10:25:04 --> Helper loaded: url_helper
INFO - 2023-09-10 10:25:04 --> Helper loaded: file_helper
INFO - 2023-09-10 10:25:04 --> Database Driver Class Initialized
INFO - 2023-09-10 10:25:04 --> Email Class Initialized
DEBUG - 2023-09-10 10:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:25:04 --> Controller Class Initialized
INFO - 2023-09-10 10:25:04 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:25:04 --> Helper loaded: form_helper
INFO - 2023-09-10 10:25:04 --> Form Validation Class Initialized
INFO - 2023-09-10 10:25:04 --> Config Class Initialized
INFO - 2023-09-10 10:25:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:25:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:25:04 --> Utf8 Class Initialized
INFO - 2023-09-10 10:25:04 --> URI Class Initialized
INFO - 2023-09-10 10:25:04 --> Router Class Initialized
INFO - 2023-09-10 10:25:04 --> Output Class Initialized
INFO - 2023-09-10 10:25:04 --> Security Class Initialized
DEBUG - 2023-09-10 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:25:04 --> Input Class Initialized
INFO - 2023-09-10 10:25:04 --> Language Class Initialized
INFO - 2023-09-10 10:25:05 --> Loader Class Initialized
INFO - 2023-09-10 10:25:05 --> Helper loaded: url_helper
INFO - 2023-09-10 10:25:05 --> Helper loaded: file_helper
INFO - 2023-09-10 10:25:05 --> Database Driver Class Initialized
INFO - 2023-09-10 10:25:05 --> Email Class Initialized
DEBUG - 2023-09-10 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:25:05 --> Controller Class Initialized
INFO - 2023-09-10 10:25:05 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:25:05 --> Helper loaded: form_helper
INFO - 2023-09-10 10:25:05 --> Form Validation Class Initialized
INFO - 2023-09-10 10:25:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-10 10:25:05 --> Final output sent to browser
DEBUG - 2023-09-10 10:25:05 --> Total execution time: 0.9767
INFO - 2023-09-10 10:25:20 --> Config Class Initialized
INFO - 2023-09-10 10:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:25:20 --> Utf8 Class Initialized
INFO - 2023-09-10 10:25:20 --> URI Class Initialized
DEBUG - 2023-09-10 10:25:20 --> No URI present. Default controller set.
INFO - 2023-09-10 10:25:20 --> Router Class Initialized
INFO - 2023-09-10 10:25:20 --> Output Class Initialized
INFO - 2023-09-10 10:25:20 --> Security Class Initialized
DEBUG - 2023-09-10 10:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:25:20 --> Input Class Initialized
INFO - 2023-09-10 10:25:20 --> Language Class Initialized
INFO - 2023-09-10 10:25:20 --> Loader Class Initialized
INFO - 2023-09-10 10:25:20 --> Helper loaded: url_helper
INFO - 2023-09-10 10:25:20 --> Helper loaded: file_helper
INFO - 2023-09-10 10:25:20 --> Database Driver Class Initialized
INFO - 2023-09-10 10:25:20 --> Email Class Initialized
DEBUG - 2023-09-10 10:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:25:20 --> Controller Class Initialized
INFO - 2023-09-10 10:25:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:25:21 --> Model "Home_model" initialized
INFO - 2023-09-10 10:25:21 --> Helper loaded: download_helper
INFO - 2023-09-10 10:25:21 --> Helper loaded: form_helper
INFO - 2023-09-10 10:25:21 --> Form Validation Class Initialized
INFO - 2023-09-10 10:25:21 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:25:21 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:25:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:25:21 --> Final output sent to browser
DEBUG - 2023-09-10 10:25:21 --> Total execution time: 0.5745
INFO - 2023-09-10 10:25:21 --> Config Class Initialized
INFO - 2023-09-10 10:25:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:25:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:25:22 --> Utf8 Class Initialized
INFO - 2023-09-10 10:25:22 --> URI Class Initialized
INFO - 2023-09-10 10:25:22 --> Router Class Initialized
INFO - 2023-09-10 10:25:22 --> Output Class Initialized
INFO - 2023-09-10 10:25:22 --> Security Class Initialized
DEBUG - 2023-09-10 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:25:22 --> Input Class Initialized
INFO - 2023-09-10 10:25:22 --> Language Class Initialized
ERROR - 2023-09-10 10:25:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:32:46 --> Config Class Initialized
INFO - 2023-09-10 10:32:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:32:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:32:46 --> Utf8 Class Initialized
INFO - 2023-09-10 10:32:46 --> URI Class Initialized
DEBUG - 2023-09-10 10:32:46 --> No URI present. Default controller set.
INFO - 2023-09-10 10:32:46 --> Router Class Initialized
INFO - 2023-09-10 10:32:46 --> Output Class Initialized
INFO - 2023-09-10 10:32:46 --> Security Class Initialized
DEBUG - 2023-09-10 10:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:32:46 --> Input Class Initialized
INFO - 2023-09-10 10:32:46 --> Language Class Initialized
INFO - 2023-09-10 10:32:46 --> Loader Class Initialized
INFO - 2023-09-10 10:32:46 --> Helper loaded: url_helper
INFO - 2023-09-10 10:32:46 --> Helper loaded: file_helper
INFO - 2023-09-10 10:32:46 --> Database Driver Class Initialized
INFO - 2023-09-10 10:32:46 --> Email Class Initialized
DEBUG - 2023-09-10 10:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:32:46 --> Controller Class Initialized
INFO - 2023-09-10 10:32:46 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:32:46 --> Model "Home_model" initialized
INFO - 2023-09-10 10:32:46 --> Helper loaded: download_helper
INFO - 2023-09-10 10:32:46 --> Helper loaded: form_helper
INFO - 2023-09-10 10:32:46 --> Form Validation Class Initialized
INFO - 2023-09-10 10:32:46 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:32:46 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:32:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:32:47 --> Final output sent to browser
DEBUG - 2023-09-10 10:32:47 --> Total execution time: 0.4624
INFO - 2023-09-10 10:32:49 --> Config Class Initialized
INFO - 2023-09-10 10:32:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:32:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:32:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:32:49 --> URI Class Initialized
INFO - 2023-09-10 10:32:49 --> Router Class Initialized
INFO - 2023-09-10 10:32:49 --> Output Class Initialized
INFO - 2023-09-10 10:32:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:32:49 --> Input Class Initialized
INFO - 2023-09-10 10:32:49 --> Language Class Initialized
ERROR - 2023-09-10 10:32:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:34:57 --> Config Class Initialized
INFO - 2023-09-10 10:34:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:34:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:34:57 --> Utf8 Class Initialized
INFO - 2023-09-10 10:34:57 --> URI Class Initialized
DEBUG - 2023-09-10 10:34:57 --> No URI present. Default controller set.
INFO - 2023-09-10 10:34:57 --> Router Class Initialized
INFO - 2023-09-10 10:34:57 --> Output Class Initialized
INFO - 2023-09-10 10:34:57 --> Security Class Initialized
DEBUG - 2023-09-10 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:34:57 --> Input Class Initialized
INFO - 2023-09-10 10:34:57 --> Language Class Initialized
INFO - 2023-09-10 10:34:57 --> Loader Class Initialized
INFO - 2023-09-10 10:34:57 --> Helper loaded: url_helper
INFO - 2023-09-10 10:34:57 --> Helper loaded: file_helper
INFO - 2023-09-10 10:34:57 --> Database Driver Class Initialized
INFO - 2023-09-10 10:34:57 --> Email Class Initialized
DEBUG - 2023-09-10 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:34:57 --> Controller Class Initialized
INFO - 2023-09-10 10:34:57 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:34:57 --> Model "Home_model" initialized
INFO - 2023-09-10 10:34:57 --> Helper loaded: download_helper
INFO - 2023-09-10 10:34:57 --> Helper loaded: form_helper
INFO - 2023-09-10 10:34:57 --> Form Validation Class Initialized
INFO - 2023-09-10 10:34:57 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:34:57 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:34:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:34:57 --> Final output sent to browser
DEBUG - 2023-09-10 10:34:57 --> Total execution time: 0.4073
INFO - 2023-09-10 10:34:58 --> Config Class Initialized
INFO - 2023-09-10 10:34:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:34:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:34:58 --> Utf8 Class Initialized
INFO - 2023-09-10 10:34:58 --> URI Class Initialized
INFO - 2023-09-10 10:34:58 --> Router Class Initialized
INFO - 2023-09-10 10:34:58 --> Output Class Initialized
INFO - 2023-09-10 10:34:58 --> Security Class Initialized
DEBUG - 2023-09-10 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:34:58 --> Input Class Initialized
INFO - 2023-09-10 10:34:58 --> Language Class Initialized
ERROR - 2023-09-10 10:34:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:35:51 --> Config Class Initialized
INFO - 2023-09-10 10:35:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:35:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:35:51 --> Utf8 Class Initialized
INFO - 2023-09-10 10:35:51 --> URI Class Initialized
DEBUG - 2023-09-10 10:35:51 --> No URI present. Default controller set.
INFO - 2023-09-10 10:35:51 --> Router Class Initialized
INFO - 2023-09-10 10:35:51 --> Output Class Initialized
INFO - 2023-09-10 10:35:52 --> Security Class Initialized
DEBUG - 2023-09-10 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:35:52 --> Input Class Initialized
INFO - 2023-09-10 10:35:52 --> Language Class Initialized
INFO - 2023-09-10 10:35:52 --> Loader Class Initialized
INFO - 2023-09-10 10:35:52 --> Helper loaded: url_helper
INFO - 2023-09-10 10:35:52 --> Helper loaded: file_helper
INFO - 2023-09-10 10:35:52 --> Database Driver Class Initialized
INFO - 2023-09-10 10:35:52 --> Email Class Initialized
DEBUG - 2023-09-10 10:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:35:52 --> Controller Class Initialized
INFO - 2023-09-10 10:35:52 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:35:52 --> Model "Home_model" initialized
INFO - 2023-09-10 10:35:52 --> Helper loaded: download_helper
INFO - 2023-09-10 10:35:52 --> Helper loaded: form_helper
INFO - 2023-09-10 10:35:52 --> Form Validation Class Initialized
INFO - 2023-09-10 10:35:52 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:35:52 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:35:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:35:52 --> Final output sent to browser
DEBUG - 2023-09-10 10:35:52 --> Total execution time: 0.4070
INFO - 2023-09-10 10:35:54 --> Config Class Initialized
INFO - 2023-09-10 10:35:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:35:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:35:54 --> Utf8 Class Initialized
INFO - 2023-09-10 10:35:54 --> URI Class Initialized
INFO - 2023-09-10 10:35:54 --> Router Class Initialized
INFO - 2023-09-10 10:35:54 --> Output Class Initialized
INFO - 2023-09-10 10:35:54 --> Security Class Initialized
DEBUG - 2023-09-10 10:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:35:54 --> Input Class Initialized
INFO - 2023-09-10 10:35:54 --> Language Class Initialized
ERROR - 2023-09-10 10:35:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:36:49 --> Config Class Initialized
INFO - 2023-09-10 10:36:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:36:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:36:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:36:49 --> URI Class Initialized
DEBUG - 2023-09-10 10:36:49 --> No URI present. Default controller set.
INFO - 2023-09-10 10:36:49 --> Router Class Initialized
INFO - 2023-09-10 10:36:49 --> Output Class Initialized
INFO - 2023-09-10 10:36:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:36:49 --> Input Class Initialized
INFO - 2023-09-10 10:36:49 --> Language Class Initialized
INFO - 2023-09-10 10:36:49 --> Loader Class Initialized
INFO - 2023-09-10 10:36:49 --> Helper loaded: url_helper
INFO - 2023-09-10 10:36:49 --> Helper loaded: file_helper
INFO - 2023-09-10 10:36:49 --> Database Driver Class Initialized
INFO - 2023-09-10 10:36:49 --> Email Class Initialized
DEBUG - 2023-09-10 10:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:36:49 --> Controller Class Initialized
INFO - 2023-09-10 10:36:49 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:36:49 --> Model "Home_model" initialized
INFO - 2023-09-10 10:36:49 --> Helper loaded: download_helper
INFO - 2023-09-10 10:36:49 --> Helper loaded: form_helper
INFO - 2023-09-10 10:36:49 --> Form Validation Class Initialized
INFO - 2023-09-10 10:36:49 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:36:49 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:36:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:36:49 --> Final output sent to browser
DEBUG - 2023-09-10 10:36:49 --> Total execution time: 0.3931
INFO - 2023-09-10 10:36:50 --> Config Class Initialized
INFO - 2023-09-10 10:36:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:36:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:36:50 --> Utf8 Class Initialized
INFO - 2023-09-10 10:36:50 --> URI Class Initialized
INFO - 2023-09-10 10:36:50 --> Router Class Initialized
INFO - 2023-09-10 10:36:50 --> Output Class Initialized
INFO - 2023-09-10 10:36:50 --> Security Class Initialized
DEBUG - 2023-09-10 10:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:36:50 --> Input Class Initialized
INFO - 2023-09-10 10:36:50 --> Language Class Initialized
ERROR - 2023-09-10 10:36:50 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:37:07 --> Config Class Initialized
INFO - 2023-09-10 10:37:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:07 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:07 --> URI Class Initialized
INFO - 2023-09-10 10:37:07 --> Router Class Initialized
INFO - 2023-09-10 10:37:07 --> Output Class Initialized
INFO - 2023-09-10 10:37:07 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:07 --> Input Class Initialized
INFO - 2023-09-10 10:37:07 --> Language Class Initialized
ERROR - 2023-09-10 10:37:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:08 --> Config Class Initialized
INFO - 2023-09-10 10:37:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:08 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:08 --> URI Class Initialized
INFO - 2023-09-10 10:37:08 --> Router Class Initialized
INFO - 2023-09-10 10:37:08 --> Output Class Initialized
INFO - 2023-09-10 10:37:08 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:08 --> Input Class Initialized
INFO - 2023-09-10 10:37:08 --> Language Class Initialized
ERROR - 2023-09-10 10:37:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:08 --> Config Class Initialized
INFO - 2023-09-10 10:37:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:08 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:08 --> URI Class Initialized
INFO - 2023-09-10 10:37:08 --> Router Class Initialized
INFO - 2023-09-10 10:37:08 --> Output Class Initialized
INFO - 2023-09-10 10:37:08 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:08 --> Input Class Initialized
INFO - 2023-09-10 10:37:08 --> Language Class Initialized
ERROR - 2023-09-10 10:37:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:08 --> Config Class Initialized
INFO - 2023-09-10 10:37:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:08 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:08 --> URI Class Initialized
INFO - 2023-09-10 10:37:09 --> Router Class Initialized
INFO - 2023-09-10 10:37:09 --> Output Class Initialized
INFO - 2023-09-10 10:37:09 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:10 --> Input Class Initialized
INFO - 2023-09-10 10:37:10 --> Language Class Initialized
ERROR - 2023-09-10 10:37:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:10 --> Config Class Initialized
INFO - 2023-09-10 10:37:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:10 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:10 --> URI Class Initialized
INFO - 2023-09-10 10:37:10 --> Router Class Initialized
INFO - 2023-09-10 10:37:10 --> Output Class Initialized
INFO - 2023-09-10 10:37:10 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:10 --> Input Class Initialized
INFO - 2023-09-10 10:37:10 --> Language Class Initialized
ERROR - 2023-09-10 10:37:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:11 --> Config Class Initialized
INFO - 2023-09-10 10:37:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:11 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:11 --> URI Class Initialized
INFO - 2023-09-10 10:37:11 --> Router Class Initialized
INFO - 2023-09-10 10:37:11 --> Output Class Initialized
INFO - 2023-09-10 10:37:11 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:11 --> Input Class Initialized
INFO - 2023-09-10 10:37:12 --> Language Class Initialized
ERROR - 2023-09-10 10:37:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:12 --> Config Class Initialized
INFO - 2023-09-10 10:37:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:12 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:12 --> URI Class Initialized
INFO - 2023-09-10 10:37:12 --> Router Class Initialized
INFO - 2023-09-10 10:37:12 --> Output Class Initialized
INFO - 2023-09-10 10:37:12 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:12 --> Input Class Initialized
INFO - 2023-09-10 10:37:12 --> Language Class Initialized
ERROR - 2023-09-10 10:37:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:37 --> Config Class Initialized
INFO - 2023-09-10 10:37:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:37 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:37 --> URI Class Initialized
DEBUG - 2023-09-10 10:37:37 --> No URI present. Default controller set.
INFO - 2023-09-10 10:37:37 --> Router Class Initialized
INFO - 2023-09-10 10:37:37 --> Output Class Initialized
INFO - 2023-09-10 10:37:37 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:38 --> Input Class Initialized
INFO - 2023-09-10 10:37:38 --> Language Class Initialized
INFO - 2023-09-10 10:37:38 --> Loader Class Initialized
INFO - 2023-09-10 10:37:38 --> Helper loaded: url_helper
INFO - 2023-09-10 10:37:38 --> Helper loaded: file_helper
INFO - 2023-09-10 10:37:38 --> Database Driver Class Initialized
INFO - 2023-09-10 10:37:38 --> Email Class Initialized
DEBUG - 2023-09-10 10:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:37:38 --> Controller Class Initialized
INFO - 2023-09-10 10:37:38 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:37:38 --> Model "Home_model" initialized
INFO - 2023-09-10 10:37:38 --> Helper loaded: download_helper
INFO - 2023-09-10 10:37:38 --> Helper loaded: form_helper
INFO - 2023-09-10 10:37:38 --> Form Validation Class Initialized
INFO - 2023-09-10 10:37:38 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:37:38 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:37:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:37:38 --> Final output sent to browser
DEBUG - 2023-09-10 10:37:38 --> Total execution time: 0.3978
INFO - 2023-09-10 10:37:40 --> Config Class Initialized
INFO - 2023-09-10 10:37:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:40 --> URI Class Initialized
INFO - 2023-09-10 10:37:40 --> Router Class Initialized
INFO - 2023-09-10 10:37:40 --> Output Class Initialized
INFO - 2023-09-10 10:37:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:40 --> Input Class Initialized
INFO - 2023-09-10 10:37:40 --> Language Class Initialized
ERROR - 2023-09-10 10:37:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:37:40 --> Config Class Initialized
INFO - 2023-09-10 10:37:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:40 --> URI Class Initialized
INFO - 2023-09-10 10:37:40 --> Router Class Initialized
INFO - 2023-09-10 10:37:40 --> Output Class Initialized
INFO - 2023-09-10 10:37:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:40 --> Input Class Initialized
INFO - 2023-09-10 10:37:40 --> Language Class Initialized
ERROR - 2023-09-10 10:37:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:40 --> Config Class Initialized
INFO - 2023-09-10 10:37:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:40 --> URI Class Initialized
INFO - 2023-09-10 10:37:40 --> Router Class Initialized
INFO - 2023-09-10 10:37:40 --> Output Class Initialized
INFO - 2023-09-10 10:37:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:40 --> Input Class Initialized
INFO - 2023-09-10 10:37:40 --> Language Class Initialized
ERROR - 2023-09-10 10:37:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:41 --> Config Class Initialized
INFO - 2023-09-10 10:37:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:41 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:41 --> URI Class Initialized
INFO - 2023-09-10 10:37:41 --> Router Class Initialized
INFO - 2023-09-10 10:37:41 --> Output Class Initialized
INFO - 2023-09-10 10:37:41 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:41 --> Input Class Initialized
INFO - 2023-09-10 10:37:41 --> Language Class Initialized
ERROR - 2023-09-10 10:37:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:41 --> Config Class Initialized
INFO - 2023-09-10 10:37:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:41 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:41 --> URI Class Initialized
INFO - 2023-09-10 10:37:42 --> Router Class Initialized
INFO - 2023-09-10 10:37:42 --> Output Class Initialized
INFO - 2023-09-10 10:37:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:42 --> Input Class Initialized
INFO - 2023-09-10 10:37:42 --> Language Class Initialized
ERROR - 2023-09-10 10:37:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:42 --> Config Class Initialized
INFO - 2023-09-10 10:37:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:42 --> URI Class Initialized
INFO - 2023-09-10 10:37:42 --> Router Class Initialized
INFO - 2023-09-10 10:37:42 --> Output Class Initialized
INFO - 2023-09-10 10:37:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:42 --> Input Class Initialized
INFO - 2023-09-10 10:37:42 --> Language Class Initialized
ERROR - 2023-09-10 10:37:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:42 --> Config Class Initialized
INFO - 2023-09-10 10:37:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:42 --> URI Class Initialized
INFO - 2023-09-10 10:37:42 --> Router Class Initialized
INFO - 2023-09-10 10:37:42 --> Output Class Initialized
INFO - 2023-09-10 10:37:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:42 --> Input Class Initialized
INFO - 2023-09-10 10:37:42 --> Language Class Initialized
ERROR - 2023-09-10 10:37:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:37:42 --> Config Class Initialized
INFO - 2023-09-10 10:37:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:37:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:37:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:37:42 --> URI Class Initialized
INFO - 2023-09-10 10:37:42 --> Router Class Initialized
INFO - 2023-09-10 10:37:42 --> Output Class Initialized
INFO - 2023-09-10 10:37:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:37:42 --> Input Class Initialized
INFO - 2023-09-10 10:37:42 --> Language Class Initialized
ERROR - 2023-09-10 10:37:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:39:47 --> Config Class Initialized
INFO - 2023-09-10 10:39:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:47 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:47 --> URI Class Initialized
DEBUG - 2023-09-10 10:39:47 --> No URI present. Default controller set.
INFO - 2023-09-10 10:39:47 --> Router Class Initialized
INFO - 2023-09-10 10:39:47 --> Output Class Initialized
INFO - 2023-09-10 10:39:47 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:47 --> Input Class Initialized
INFO - 2023-09-10 10:39:47 --> Language Class Initialized
INFO - 2023-09-10 10:39:47 --> Loader Class Initialized
INFO - 2023-09-10 10:39:47 --> Helper loaded: url_helper
INFO - 2023-09-10 10:39:47 --> Helper loaded: file_helper
INFO - 2023-09-10 10:39:47 --> Database Driver Class Initialized
INFO - 2023-09-10 10:39:47 --> Email Class Initialized
DEBUG - 2023-09-10 10:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:39:47 --> Controller Class Initialized
INFO - 2023-09-10 10:39:47 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:39:47 --> Model "Home_model" initialized
INFO - 2023-09-10 10:39:47 --> Helper loaded: download_helper
INFO - 2023-09-10 10:39:47 --> Helper loaded: form_helper
INFO - 2023-09-10 10:39:47 --> Form Validation Class Initialized
INFO - 2023-09-10 10:39:47 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:39:47 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:39:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:39:48 --> Final output sent to browser
DEBUG - 2023-09-10 10:39:48 --> Total execution time: 0.2681
INFO - 2023-09-10 10:39:49 --> Config Class Initialized
INFO - 2023-09-10 10:39:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:49 --> URI Class Initialized
INFO - 2023-09-10 10:39:49 --> Router Class Initialized
INFO - 2023-09-10 10:39:49 --> Output Class Initialized
INFO - 2023-09-10 10:39:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:49 --> Input Class Initialized
INFO - 2023-09-10 10:39:49 --> Language Class Initialized
ERROR - 2023-09-10 10:39:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:39:53 --> Config Class Initialized
INFO - 2023-09-10 10:39:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:53 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:53 --> URI Class Initialized
INFO - 2023-09-10 10:39:53 --> Router Class Initialized
INFO - 2023-09-10 10:39:53 --> Output Class Initialized
INFO - 2023-09-10 10:39:53 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:53 --> Input Class Initialized
INFO - 2023-09-10 10:39:53 --> Language Class Initialized
INFO - 2023-09-10 10:39:53 --> Loader Class Initialized
INFO - 2023-09-10 10:39:53 --> Helper loaded: url_helper
INFO - 2023-09-10 10:39:53 --> Helper loaded: file_helper
INFO - 2023-09-10 10:39:53 --> Database Driver Class Initialized
INFO - 2023-09-10 10:39:53 --> Email Class Initialized
DEBUG - 2023-09-10 10:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:39:53 --> Controller Class Initialized
INFO - 2023-09-10 10:39:53 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:39:53 --> Model "Home_model" initialized
INFO - 2023-09-10 10:39:53 --> Helper loaded: download_helper
INFO - 2023-09-10 10:39:53 --> Helper loaded: form_helper
INFO - 2023-09-10 10:39:53 --> Form Validation Class Initialized
INFO - 2023-09-10 10:39:53 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:39:53 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:39:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-09-10 10:39:53 --> Final output sent to browser
DEBUG - 2023-09-10 10:39:53 --> Total execution time: 0.2990
INFO - 2023-09-10 10:39:53 --> Config Class Initialized
INFO - 2023-09-10 10:39:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:53 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:53 --> URI Class Initialized
INFO - 2023-09-10 10:39:53 --> Router Class Initialized
INFO - 2023-09-10 10:39:53 --> Output Class Initialized
INFO - 2023-09-10 10:39:53 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:53 --> Input Class Initialized
INFO - 2023-09-10 10:39:53 --> Language Class Initialized
ERROR - 2023-09-10 10:39:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:39:54 --> Config Class Initialized
INFO - 2023-09-10 10:39:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:54 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:54 --> URI Class Initialized
INFO - 2023-09-10 10:39:54 --> Router Class Initialized
INFO - 2023-09-10 10:39:54 --> Output Class Initialized
INFO - 2023-09-10 10:39:54 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:54 --> Input Class Initialized
INFO - 2023-09-10 10:39:54 --> Language Class Initialized
ERROR - 2023-09-10 10:39:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:39:59 --> Config Class Initialized
INFO - 2023-09-10 10:39:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:59 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:59 --> URI Class Initialized
INFO - 2023-09-10 10:39:59 --> Router Class Initialized
INFO - 2023-09-10 10:39:59 --> Output Class Initialized
INFO - 2023-09-10 10:39:59 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:59 --> Input Class Initialized
INFO - 2023-09-10 10:39:59 --> Language Class Initialized
INFO - 2023-09-10 10:39:59 --> Loader Class Initialized
INFO - 2023-09-10 10:39:59 --> Helper loaded: url_helper
INFO - 2023-09-10 10:39:59 --> Helper loaded: file_helper
INFO - 2023-09-10 10:39:59 --> Database Driver Class Initialized
INFO - 2023-09-10 10:39:59 --> Email Class Initialized
DEBUG - 2023-09-10 10:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:39:59 --> Controller Class Initialized
INFO - 2023-09-10 10:39:59 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:39:59 --> Model "Home_model" initialized
INFO - 2023-09-10 10:39:59 --> Helper loaded: download_helper
INFO - 2023-09-10 10:39:59 --> Helper loaded: form_helper
INFO - 2023-09-10 10:39:59 --> Form Validation Class Initialized
INFO - 2023-09-10 10:39:59 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:39:59 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:39:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-09-10 10:39:59 --> Final output sent to browser
DEBUG - 2023-09-10 10:39:59 --> Total execution time: 0.0602
INFO - 2023-09-10 10:39:59 --> Config Class Initialized
INFO - 2023-09-10 10:39:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:59 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:59 --> URI Class Initialized
INFO - 2023-09-10 10:39:59 --> Router Class Initialized
INFO - 2023-09-10 10:39:59 --> Output Class Initialized
INFO - 2023-09-10 10:39:59 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:59 --> Input Class Initialized
INFO - 2023-09-10 10:39:59 --> Language Class Initialized
ERROR - 2023-09-10 10:39:59 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:39:59 --> Config Class Initialized
INFO - 2023-09-10 10:39:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:39:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:39:59 --> Utf8 Class Initialized
INFO - 2023-09-10 10:39:59 --> URI Class Initialized
INFO - 2023-09-10 10:39:59 --> Router Class Initialized
INFO - 2023-09-10 10:39:59 --> Output Class Initialized
INFO - 2023-09-10 10:39:59 --> Security Class Initialized
DEBUG - 2023-09-10 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:39:59 --> Input Class Initialized
INFO - 2023-09-10 10:39:59 --> Language Class Initialized
ERROR - 2023-09-10 10:39:59 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:40:04 --> Config Class Initialized
INFO - 2023-09-10 10:40:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:04 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:04 --> URI Class Initialized
DEBUG - 2023-09-10 10:40:04 --> No URI present. Default controller set.
INFO - 2023-09-10 10:40:04 --> Router Class Initialized
INFO - 2023-09-10 10:40:04 --> Output Class Initialized
INFO - 2023-09-10 10:40:04 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:04 --> Input Class Initialized
INFO - 2023-09-10 10:40:04 --> Language Class Initialized
INFO - 2023-09-10 10:40:04 --> Loader Class Initialized
INFO - 2023-09-10 10:40:04 --> Helper loaded: url_helper
INFO - 2023-09-10 10:40:04 --> Helper loaded: file_helper
INFO - 2023-09-10 10:40:04 --> Database Driver Class Initialized
INFO - 2023-09-10 10:40:04 --> Email Class Initialized
DEBUG - 2023-09-10 10:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:40:04 --> Controller Class Initialized
INFO - 2023-09-10 10:40:04 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:40:04 --> Model "Home_model" initialized
INFO - 2023-09-10 10:40:04 --> Helper loaded: download_helper
INFO - 2023-09-10 10:40:04 --> Helper loaded: form_helper
INFO - 2023-09-10 10:40:04 --> Form Validation Class Initialized
INFO - 2023-09-10 10:40:04 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:40:04 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:40:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:40:04 --> Final output sent to browser
DEBUG - 2023-09-10 10:40:04 --> Total execution time: 0.0659
INFO - 2023-09-10 10:40:05 --> Config Class Initialized
INFO - 2023-09-10 10:40:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:05 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:05 --> URI Class Initialized
INFO - 2023-09-10 10:40:05 --> Router Class Initialized
INFO - 2023-09-10 10:40:05 --> Output Class Initialized
INFO - 2023-09-10 10:40:05 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:05 --> Input Class Initialized
INFO - 2023-09-10 10:40:05 --> Language Class Initialized
ERROR - 2023-09-10 10:40:05 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:40:10 --> Config Class Initialized
INFO - 2023-09-10 10:40:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:10 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:10 --> URI Class Initialized
INFO - 2023-09-10 10:40:10 --> Router Class Initialized
INFO - 2023-09-10 10:40:10 --> Output Class Initialized
INFO - 2023-09-10 10:40:10 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:10 --> Input Class Initialized
INFO - 2023-09-10 10:40:10 --> Language Class Initialized
INFO - 2023-09-10 10:40:10 --> Loader Class Initialized
INFO - 2023-09-10 10:40:10 --> Helper loaded: url_helper
INFO - 2023-09-10 10:40:10 --> Helper loaded: file_helper
INFO - 2023-09-10 10:40:10 --> Database Driver Class Initialized
INFO - 2023-09-10 10:40:10 --> Email Class Initialized
DEBUG - 2023-09-10 10:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:40:10 --> Controller Class Initialized
INFO - 2023-09-10 10:40:10 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:40:10 --> Model "Home_model" initialized
INFO - 2023-09-10 10:40:10 --> Helper loaded: download_helper
INFO - 2023-09-10 10:40:10 --> Helper loaded: form_helper
INFO - 2023-09-10 10:40:10 --> Form Validation Class Initialized
INFO - 2023-09-10 10:40:10 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:40:10 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:40:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 10:40:10 --> Final output sent to browser
DEBUG - 2023-09-10 10:40:10 --> Total execution time: 0.2838
INFO - 2023-09-10 10:40:10 --> Config Class Initialized
INFO - 2023-09-10 10:40:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:10 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:11 --> URI Class Initialized
INFO - 2023-09-10 10:40:11 --> Router Class Initialized
INFO - 2023-09-10 10:40:11 --> Output Class Initialized
INFO - 2023-09-10 10:40:11 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:11 --> Input Class Initialized
INFO - 2023-09-10 10:40:11 --> Language Class Initialized
ERROR - 2023-09-10 10:40:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:40:38 --> Config Class Initialized
INFO - 2023-09-10 10:40:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:38 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:38 --> URI Class Initialized
DEBUG - 2023-09-10 10:40:38 --> No URI present. Default controller set.
INFO - 2023-09-10 10:40:38 --> Router Class Initialized
INFO - 2023-09-10 10:40:38 --> Output Class Initialized
INFO - 2023-09-10 10:40:38 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:38 --> Input Class Initialized
INFO - 2023-09-10 10:40:39 --> Language Class Initialized
INFO - 2023-09-10 10:40:39 --> Loader Class Initialized
INFO - 2023-09-10 10:40:39 --> Helper loaded: url_helper
INFO - 2023-09-10 10:40:39 --> Helper loaded: file_helper
INFO - 2023-09-10 10:40:39 --> Database Driver Class Initialized
INFO - 2023-09-10 10:40:39 --> Email Class Initialized
DEBUG - 2023-09-10 10:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:40:39 --> Controller Class Initialized
INFO - 2023-09-10 10:40:39 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:40:39 --> Model "Home_model" initialized
INFO - 2023-09-10 10:40:39 --> Helper loaded: download_helper
INFO - 2023-09-10 10:40:39 --> Helper loaded: form_helper
INFO - 2023-09-10 10:40:39 --> Form Validation Class Initialized
INFO - 2023-09-10 10:40:39 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:40:39 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:40:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:40:39 --> Final output sent to browser
DEBUG - 2023-09-10 10:40:39 --> Total execution time: 0.7532
INFO - 2023-09-10 10:40:40 --> Config Class Initialized
INFO - 2023-09-10 10:40:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:40:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:40:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:40:40 --> URI Class Initialized
INFO - 2023-09-10 10:40:40 --> Router Class Initialized
INFO - 2023-09-10 10:40:40 --> Output Class Initialized
INFO - 2023-09-10 10:40:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:40:40 --> Input Class Initialized
INFO - 2023-09-10 10:40:40 --> Language Class Initialized
ERROR - 2023-09-10 10:40:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:48:04 --> Config Class Initialized
INFO - 2023-09-10 10:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:48:04 --> Utf8 Class Initialized
INFO - 2023-09-10 10:48:04 --> URI Class Initialized
DEBUG - 2023-09-10 10:48:04 --> No URI present. Default controller set.
INFO - 2023-09-10 10:48:04 --> Router Class Initialized
INFO - 2023-09-10 10:48:04 --> Output Class Initialized
INFO - 2023-09-10 10:48:04 --> Security Class Initialized
DEBUG - 2023-09-10 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:48:04 --> Input Class Initialized
INFO - 2023-09-10 10:48:04 --> Language Class Initialized
INFO - 2023-09-10 10:48:04 --> Loader Class Initialized
INFO - 2023-09-10 10:48:04 --> Helper loaded: url_helper
INFO - 2023-09-10 10:48:05 --> Helper loaded: file_helper
INFO - 2023-09-10 10:48:05 --> Database Driver Class Initialized
INFO - 2023-09-10 10:48:05 --> Email Class Initialized
DEBUG - 2023-09-10 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:48:05 --> Controller Class Initialized
INFO - 2023-09-10 10:48:05 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:48:05 --> Model "Home_model" initialized
INFO - 2023-09-10 10:48:05 --> Helper loaded: download_helper
INFO - 2023-09-10 10:48:05 --> Helper loaded: form_helper
INFO - 2023-09-10 10:48:05 --> Form Validation Class Initialized
INFO - 2023-09-10 10:48:05 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:48:05 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:48:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:48:05 --> Final output sent to browser
DEBUG - 2023-09-10 10:48:05 --> Total execution time: 0.5836
INFO - 2023-09-10 10:48:07 --> Config Class Initialized
INFO - 2023-09-10 10:48:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:48:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:48:07 --> Utf8 Class Initialized
INFO - 2023-09-10 10:48:07 --> URI Class Initialized
INFO - 2023-09-10 10:48:07 --> Router Class Initialized
INFO - 2023-09-10 10:48:07 --> Output Class Initialized
INFO - 2023-09-10 10:48:07 --> Security Class Initialized
DEBUG - 2023-09-10 10:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:48:07 --> Input Class Initialized
INFO - 2023-09-10 10:48:07 --> Language Class Initialized
ERROR - 2023-09-10 10:48:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:51:35 --> Config Class Initialized
INFO - 2023-09-10 10:51:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:51:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:36 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:36 --> URI Class Initialized
DEBUG - 2023-09-10 10:51:36 --> No URI present. Default controller set.
INFO - 2023-09-10 10:51:36 --> Router Class Initialized
INFO - 2023-09-10 10:51:36 --> Output Class Initialized
INFO - 2023-09-10 10:51:36 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:36 --> Input Class Initialized
INFO - 2023-09-10 10:51:36 --> Language Class Initialized
INFO - 2023-09-10 10:51:36 --> Loader Class Initialized
INFO - 2023-09-10 10:51:36 --> Helper loaded: url_helper
INFO - 2023-09-10 10:51:36 --> Helper loaded: file_helper
INFO - 2023-09-10 10:51:36 --> Database Driver Class Initialized
INFO - 2023-09-10 10:51:36 --> Email Class Initialized
DEBUG - 2023-09-10 10:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:51:36 --> Controller Class Initialized
INFO - 2023-09-10 10:51:36 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:51:36 --> Model "Home_model" initialized
INFO - 2023-09-10 10:51:36 --> Helper loaded: download_helper
INFO - 2023-09-10 10:51:36 --> Helper loaded: form_helper
INFO - 2023-09-10 10:51:36 --> Form Validation Class Initialized
INFO - 2023-09-10 10:51:36 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:51:36 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:51:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:51:36 --> Final output sent to browser
DEBUG - 2023-09-10 10:51:36 --> Total execution time: 0.4602
INFO - 2023-09-10 10:51:38 --> Config Class Initialized
INFO - 2023-09-10 10:51:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:51:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:38 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:38 --> URI Class Initialized
INFO - 2023-09-10 10:51:38 --> Router Class Initialized
INFO - 2023-09-10 10:51:38 --> Output Class Initialized
INFO - 2023-09-10 10:51:38 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:38 --> Input Class Initialized
INFO - 2023-09-10 10:51:38 --> Language Class Initialized
ERROR - 2023-09-10 10:51:38 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
INFO - 2023-09-10 10:51:48 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:48 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:48 --> URI Class Initialized
INFO - 2023-09-10 10:51:48 --> Router Class Initialized
INFO - 2023-09-10 10:51:48 --> Output Class Initialized
INFO - 2023-09-10 10:51:48 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:48 --> Input Class Initialized
INFO - 2023-09-10 10:51:48 --> Language Class Initialized
ERROR - 2023-09-10 10:51:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:51:48 --> URI Class Initialized
INFO - 2023-09-10 10:51:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:48 --> URI Class Initialized
INFO - 2023-09-10 10:51:48 --> Router Class Initialized
INFO - 2023-09-10 10:51:48 --> Output Class Initialized
INFO - 2023-09-10 10:51:48 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:48 --> Input Class Initialized
INFO - 2023-09-10 10:51:48 --> Language Class Initialized
ERROR - 2023-09-10 10:51:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:51:48 --> Router Class Initialized
INFO - 2023-09-10 10:51:48 --> URI Class Initialized
INFO - 2023-09-10 10:51:48 --> Config Class Initialized
INFO - 2023-09-10 10:51:48 --> URI Class Initialized
INFO - 2023-09-10 10:51:48 --> Hooks Class Initialized
INFO - 2023-09-10 10:51:48 --> Router Class Initialized
DEBUG - 2023-09-10 10:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:48 --> Output Class Initialized
INFO - 2023-09-10 10:51:48 --> Security Class Initialized
INFO - 2023-09-10 10:51:48 --> Router Class Initialized
INFO - 2023-09-10 10:51:48 --> Output Class Initialized
INFO - 2023-09-10 10:51:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:49 --> Output Class Initialized
DEBUG - 2023-09-10 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:49 --> Security Class Initialized
INFO - 2023-09-10 10:51:49 --> URI Class Initialized
INFO - 2023-09-10 10:51:49 --> Router Class Initialized
INFO - 2023-09-10 10:51:49 --> Output Class Initialized
INFO - 2023-09-10 10:51:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:49 --> Input Class Initialized
INFO - 2023-09-10 10:51:49 --> Language Class Initialized
ERROR - 2023-09-10 10:51:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:51:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:49 --> Input Class Initialized
INFO - 2023-09-10 10:51:49 --> Language Class Initialized
ERROR - 2023-09-10 10:51:49 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:49 --> Input Class Initialized
INFO - 2023-09-10 10:51:49 --> Input Class Initialized
INFO - 2023-09-10 10:51:49 --> Language Class Initialized
INFO - 2023-09-10 10:51:49 --> Language Class Initialized
ERROR - 2023-09-10 10:51:49 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:51:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:51:49 --> Config Class Initialized
INFO - 2023-09-10 10:51:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:51:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:51:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:51:49 --> URI Class Initialized
INFO - 2023-09-10 10:51:49 --> Router Class Initialized
INFO - 2023-09-10 10:51:49 --> Output Class Initialized
INFO - 2023-09-10 10:51:49 --> Security Class Initialized
DEBUG - 2023-09-10 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:51:49 --> Input Class Initialized
INFO - 2023-09-10 10:51:49 --> Language Class Initialized
ERROR - 2023-09-10 10:51:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:11 --> Config Class Initialized
INFO - 2023-09-10 10:54:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:11 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:11 --> URI Class Initialized
DEBUG - 2023-09-10 10:54:11 --> No URI present. Default controller set.
INFO - 2023-09-10 10:54:11 --> Router Class Initialized
INFO - 2023-09-10 10:54:11 --> Output Class Initialized
INFO - 2023-09-10 10:54:12 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:12 --> Input Class Initialized
INFO - 2023-09-10 10:54:12 --> Language Class Initialized
INFO - 2023-09-10 10:54:12 --> Loader Class Initialized
INFO - 2023-09-10 10:54:12 --> Helper loaded: url_helper
INFO - 2023-09-10 10:54:12 --> Helper loaded: file_helper
INFO - 2023-09-10 10:54:12 --> Database Driver Class Initialized
INFO - 2023-09-10 10:54:12 --> Email Class Initialized
DEBUG - 2023-09-10 10:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:54:13 --> Controller Class Initialized
INFO - 2023-09-10 10:54:13 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:54:13 --> Model "Home_model" initialized
INFO - 2023-09-10 10:54:14 --> Helper loaded: download_helper
INFO - 2023-09-10 10:54:14 --> Helper loaded: form_helper
INFO - 2023-09-10 10:54:14 --> Form Validation Class Initialized
INFO - 2023-09-10 10:54:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:54:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:54:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:54:16 --> Final output sent to browser
DEBUG - 2023-09-10 10:54:16 --> Total execution time: 5.4176
INFO - 2023-09-10 10:54:17 --> Config Class Initialized
INFO - 2023-09-10 10:54:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:19 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:19 --> URI Class Initialized
INFO - 2023-09-10 10:54:19 --> Config Class Initialized
INFO - 2023-09-10 10:54:19 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:19 --> Router Class Initialized
INFO - 2023-09-10 10:54:19 --> Output Class Initialized
DEBUG - 2023-09-10 10:54:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:20 --> Config Class Initialized
INFO - 2023-09-10 10:54:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:20 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:21 --> Security Class Initialized
INFO - 2023-09-10 10:54:21 --> URI Class Initialized
INFO - 2023-09-10 10:54:21 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:21 --> Config Class Initialized
DEBUG - 2023-09-10 10:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:22 --> Router Class Initialized
INFO - 2023-09-10 10:54:22 --> Input Class Initialized
INFO - 2023-09-10 10:54:22 --> URI Class Initialized
INFO - 2023-09-10 10:54:22 --> Language Class Initialized
INFO - 2023-09-10 10:54:22 --> Hooks Class Initialized
ERROR - 2023-09-10 10:54:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:22 --> Output Class Initialized
INFO - 2023-09-10 10:54:22 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:22 --> Router Class Initialized
INFO - 2023-09-10 10:54:22 --> Input Class Initialized
INFO - 2023-09-10 10:54:22 --> Config Class Initialized
INFO - 2023-09-10 10:54:22 --> Output Class Initialized
INFO - 2023-09-10 10:54:22 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:22 --> Language Class Initialized
DEBUG - 2023-09-10 10:54:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:54:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:22 --> Security Class Initialized
ERROR - 2023-09-10 10:54:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:22 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:22 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:22 --> URI Class Initialized
INFO - 2023-09-10 10:54:22 --> Config Class Initialized
DEBUG - 2023-09-10 10:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:22 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:22 --> URI Class Initialized
INFO - 2023-09-10 10:54:22 --> Input Class Initialized
INFO - 2023-09-10 10:54:22 --> Router Class Initialized
DEBUG - 2023-09-10 10:54:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:22 --> Language Class Initialized
INFO - 2023-09-10 10:54:23 --> Config Class Initialized
INFO - 2023-09-10 10:54:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:23 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:23 --> URI Class Initialized
INFO - 2023-09-10 10:54:23 --> Router Class Initialized
INFO - 2023-09-10 10:54:23 --> Output Class Initialized
INFO - 2023-09-10 10:54:23 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:23 --> Input Class Initialized
INFO - 2023-09-10 10:54:23 --> Language Class Initialized
ERROR - 2023-09-10 10:54:23 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:54:23 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:54:23 --> Config Class Initialized
INFO - 2023-09-10 10:54:23 --> Router Class Initialized
INFO - 2023-09-10 10:54:23 --> Output Class Initialized
INFO - 2023-09-10 10:54:23 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:23 --> Security Class Initialized
INFO - 2023-09-10 10:54:23 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:23 --> Output Class Initialized
INFO - 2023-09-10 10:54:23 --> URI Class Initialized
DEBUG - 2023-09-10 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:24 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:24 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:24 --> Input Class Initialized
INFO - 2023-09-10 10:54:25 --> Input Class Initialized
INFO - 2023-09-10 10:54:25 --> Router Class Initialized
INFO - 2023-09-10 10:54:25 --> URI Class Initialized
INFO - 2023-09-10 10:54:25 --> Language Class Initialized
INFO - 2023-09-10 10:54:26 --> Language Class Initialized
ERROR - 2023-09-10 10:54:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:26 --> Router Class Initialized
INFO - 2023-09-10 10:54:26 --> Output Class Initialized
ERROR - 2023-09-10 10:54:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:27 --> Output Class Initialized
INFO - 2023-09-10 10:54:27 --> Security Class Initialized
INFO - 2023-09-10 10:54:27 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 10:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:27 --> Input Class Initialized
INFO - 2023-09-10 10:54:27 --> Language Class Initialized
INFO - 2023-09-10 10:54:27 --> Input Class Initialized
ERROR - 2023-09-10 10:54:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:27 --> Language Class Initialized
ERROR - 2023-09-10 10:54:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:40 --> Config Class Initialized
INFO - 2023-09-10 10:54:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:40 --> URI Class Initialized
INFO - 2023-09-10 10:54:40 --> Router Class Initialized
INFO - 2023-09-10 10:54:40 --> Output Class Initialized
INFO - 2023-09-10 10:54:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:40 --> Input Class Initialized
INFO - 2023-09-10 10:54:40 --> Language Class Initialized
INFO - 2023-09-10 10:54:40 --> Loader Class Initialized
INFO - 2023-09-10 10:54:40 --> Helper loaded: url_helper
INFO - 2023-09-10 10:54:40 --> Helper loaded: file_helper
INFO - 2023-09-10 10:54:40 --> Database Driver Class Initialized
INFO - 2023-09-10 10:54:40 --> Email Class Initialized
DEBUG - 2023-09-10 10:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:54:41 --> Controller Class Initialized
INFO - 2023-09-10 10:54:41 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:54:41 --> Model "Home_model" initialized
INFO - 2023-09-10 10:54:41 --> Helper loaded: download_helper
INFO - 2023-09-10 10:54:41 --> Helper loaded: form_helper
INFO - 2023-09-10 10:54:41 --> Form Validation Class Initialized
INFO - 2023-09-10 10:54:41 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:54:41 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:54:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 10:54:41 --> Final output sent to browser
DEBUG - 2023-09-10 10:54:41 --> Total execution time: 1.5815
INFO - 2023-09-10 10:54:43 --> Config Class Initialized
INFO - 2023-09-10 10:54:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:44 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:44 --> URI Class Initialized
INFO - 2023-09-10 10:54:45 --> Config Class Initialized
INFO - 2023-09-10 10:54:45 --> Router Class Initialized
INFO - 2023-09-10 10:54:45 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:45 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:45 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:46 --> URI Class Initialized
INFO - 2023-09-10 10:54:46 --> Output Class Initialized
INFO - 2023-09-10 10:54:46 --> Router Class Initialized
INFO - 2023-09-10 10:54:46 --> Output Class Initialized
INFO - 2023-09-10 10:54:46 --> Security Class Initialized
INFO - 2023-09-10 10:54:46 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 10:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:46 --> Input Class Initialized
INFO - 2023-09-10 10:54:47 --> Language Class Initialized
INFO - 2023-09-10 10:54:47 --> Input Class Initialized
ERROR - 2023-09-10 10:54:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:47 --> Language Class Initialized
ERROR - 2023-09-10 10:54:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
INFO - 2023-09-10 10:54:47 --> Security Class Initialized
DEBUG - 2023-09-10 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:47 --> Input Class Initialized
INFO - 2023-09-10 10:54:47 --> Language Class Initialized
ERROR - 2023-09-10 10:54:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Security Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
DEBUG - 2023-09-10 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:47 --> Input Class Initialized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
INFO - 2023-09-10 10:54:47 --> Security Class Initialized
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:54:47 --> Config Class Initialized
INFO - 2023-09-10 10:54:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:54:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Utf8 Class Initialized
INFO - 2023-09-10 10:54:47 --> Language Class Initialized
INFO - 2023-09-10 10:54:47 --> Security Class Initialized
INFO - 2023-09-10 10:54:47 --> URI Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
ERROR - 2023-09-10 10:54:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
INFO - 2023-09-10 10:54:47 --> Router Class Initialized
DEBUG - 2023-09-10 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:47 --> Security Class Initialized
INFO - 2023-09-10 10:54:47 --> Output Class Initialized
DEBUG - 2023-09-10 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:48 --> Input Class Initialized
INFO - 2023-09-10 10:54:48 --> Input Class Initialized
INFO - 2023-09-10 10:54:48 --> Security Class Initialized
INFO - 2023-09-10 10:54:48 --> Language Class Initialized
INFO - 2023-09-10 10:54:48 --> Language Class Initialized
ERROR - 2023-09-10 10:54:48 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:54:48 --> Input Class Initialized
ERROR - 2023-09-10 10:54:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 10:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:54:48 --> Language Class Initialized
INFO - 2023-09-10 10:54:48 --> Input Class Initialized
INFO - 2023-09-10 10:54:48 --> Language Class Initialized
ERROR - 2023-09-10 10:54:48 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:54:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:40 --> Config Class Initialized
INFO - 2023-09-10 10:55:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:55:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:40 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:40 --> URI Class Initialized
INFO - 2023-09-10 10:55:40 --> Router Class Initialized
INFO - 2023-09-10 10:55:40 --> Output Class Initialized
INFO - 2023-09-10 10:55:40 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:40 --> Input Class Initialized
INFO - 2023-09-10 10:55:40 --> Language Class Initialized
INFO - 2023-09-10 10:55:40 --> Loader Class Initialized
INFO - 2023-09-10 10:55:40 --> Helper loaded: url_helper
INFO - 2023-09-10 10:55:40 --> Helper loaded: file_helper
INFO - 2023-09-10 10:55:40 --> Database Driver Class Initialized
INFO - 2023-09-10 10:55:40 --> Email Class Initialized
DEBUG - 2023-09-10 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:55:41 --> Controller Class Initialized
INFO - 2023-09-10 10:55:41 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:55:41 --> Model "Home_model" initialized
INFO - 2023-09-10 10:55:41 --> Helper loaded: download_helper
INFO - 2023-09-10 10:55:41 --> Helper loaded: form_helper
INFO - 2023-09-10 10:55:41 --> Form Validation Class Initialized
INFO - 2023-09-10 10:55:41 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:55:41 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:55:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 10:55:41 --> Final output sent to browser
DEBUG - 2023-09-10 10:55:41 --> Total execution time: 1.2833
INFO - 2023-09-10 10:55:42 --> Config Class Initialized
INFO - 2023-09-10 10:55:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:55:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:42 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:42 --> URI Class Initialized
INFO - 2023-09-10 10:55:42 --> Router Class Initialized
INFO - 2023-09-10 10:55:42 --> Output Class Initialized
INFO - 2023-09-10 10:55:42 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:42 --> Input Class Initialized
INFO - 2023-09-10 10:55:42 --> Language Class Initialized
ERROR - 2023-09-10 10:55:42 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:43 --> Config Class Initialized
INFO - 2023-09-10 10:55:44 --> Config Class Initialized
INFO - 2023-09-10 10:55:44 --> Hooks Class Initialized
INFO - 2023-09-10 10:55:44 --> Hooks Class Initialized
INFO - 2023-09-10 10:55:46 --> Config Class Initialized
INFO - 2023-09-10 10:55:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:55:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:46 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:46 --> URI Class Initialized
INFO - 2023-09-10 10:55:46 --> Router Class Initialized
INFO - 2023-09-10 10:55:46 --> Output Class Initialized
INFO - 2023-09-10 10:55:46 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:46 --> Input Class Initialized
INFO - 2023-09-10 10:55:46 --> Language Class Initialized
ERROR - 2023-09-10 10:55:46 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:46 --> Config Class Initialized
INFO - 2023-09-10 10:55:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:55:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:46 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:46 --> URI Class Initialized
INFO - 2023-09-10 10:55:46 --> Router Class Initialized
INFO - 2023-09-10 10:55:46 --> Output Class Initialized
INFO - 2023-09-10 10:55:46 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:46 --> Input Class Initialized
INFO - 2023-09-10 10:55:46 --> Language Class Initialized
ERROR - 2023-09-10 10:55:46 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:46 --> Config Class Initialized
DEBUG - 2023-09-10 10:55:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:47 --> Hooks Class Initialized
INFO - 2023-09-10 10:55:47 --> Config Class Initialized
INFO - 2023-09-10 10:55:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:55:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:48 --> Utf8 Class Initialized
DEBUG - 2023-09-10 10:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 10:55:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:48 --> URI Class Initialized
INFO - 2023-09-10 10:55:48 --> Router Class Initialized
INFO - 2023-09-10 10:55:48 --> Output Class Initialized
INFO - 2023-09-10 10:55:48 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:48 --> Input Class Initialized
INFO - 2023-09-10 10:55:48 --> Language Class Initialized
ERROR - 2023-09-10 10:55:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:48 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:49 --> Config Class Initialized
INFO - 2023-09-10 10:55:49 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:49 --> URI Class Initialized
INFO - 2023-09-10 10:55:49 --> URI Class Initialized
INFO - 2023-09-10 10:55:49 --> Hooks Class Initialized
INFO - 2023-09-10 10:55:49 --> URI Class Initialized
INFO - 2023-09-10 10:55:49 --> Router Class Initialized
INFO - 2023-09-10 10:55:50 --> Router Class Initialized
INFO - 2023-09-10 10:55:50 --> Router Class Initialized
INFO - 2023-09-10 10:55:50 --> Output Class Initialized
DEBUG - 2023-09-10 10:55:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:55:50 --> Output Class Initialized
INFO - 2023-09-10 10:55:50 --> Security Class Initialized
INFO - 2023-09-10 10:55:50 --> Output Class Initialized
INFO - 2023-09-10 10:55:50 --> Security Class Initialized
INFO - 2023-09-10 10:55:50 --> Utf8 Class Initialized
INFO - 2023-09-10 10:55:50 --> Security Class Initialized
DEBUG - 2023-09-10 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:50 --> URI Class Initialized
INFO - 2023-09-10 10:55:50 --> Router Class Initialized
DEBUG - 2023-09-10 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:50 --> Output Class Initialized
DEBUG - 2023-09-10 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:50 --> Input Class Initialized
INFO - 2023-09-10 10:55:50 --> Input Class Initialized
INFO - 2023-09-10 10:55:50 --> Language Class Initialized
INFO - 2023-09-10 10:55:50 --> Security Class Initialized
ERROR - 2023-09-10 10:55:50 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 10:55:50 --> Input Class Initialized
DEBUG - 2023-09-10 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:55:50 --> Language Class Initialized
INFO - 2023-09-10 10:55:50 --> Input Class Initialized
INFO - 2023-09-10 10:55:50 --> Language Class Initialized
ERROR - 2023-09-10 10:55:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:55:51 --> Language Class Initialized
ERROR - 2023-09-10 10:55:51 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 10:55:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 10:58:09 --> Config Class Initialized
INFO - 2023-09-10 10:58:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:58:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:58:09 --> Utf8 Class Initialized
INFO - 2023-09-10 10:58:09 --> URI Class Initialized
DEBUG - 2023-09-10 10:58:09 --> No URI present. Default controller set.
INFO - 2023-09-10 10:58:09 --> Router Class Initialized
INFO - 2023-09-10 10:58:09 --> Output Class Initialized
INFO - 2023-09-10 10:58:09 --> Security Class Initialized
DEBUG - 2023-09-10 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:58:09 --> Input Class Initialized
INFO - 2023-09-10 10:58:09 --> Language Class Initialized
INFO - 2023-09-10 10:58:09 --> Loader Class Initialized
INFO - 2023-09-10 10:58:09 --> Helper loaded: url_helper
INFO - 2023-09-10 10:58:09 --> Helper loaded: file_helper
INFO - 2023-09-10 10:58:09 --> Database Driver Class Initialized
INFO - 2023-09-10 10:58:09 --> Email Class Initialized
DEBUG - 2023-09-10 10:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 10:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 10:58:09 --> Controller Class Initialized
INFO - 2023-09-10 10:58:09 --> Model "Contact_model" initialized
INFO - 2023-09-10 10:58:09 --> Model "Home_model" initialized
INFO - 2023-09-10 10:58:09 --> Helper loaded: download_helper
INFO - 2023-09-10 10:58:09 --> Helper loaded: form_helper
INFO - 2023-09-10 10:58:09 --> Form Validation Class Initialized
INFO - 2023-09-10 10:58:09 --> Helper loaded: custom_helper
INFO - 2023-09-10 10:58:09 --> Model "Social_media_model" initialized
INFO - 2023-09-10 10:58:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 10:58:09 --> Final output sent to browser
DEBUG - 2023-09-10 10:58:09 --> Total execution time: 0.4307
INFO - 2023-09-10 10:58:10 --> Config Class Initialized
INFO - 2023-09-10 10:58:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 10:58:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 10:58:11 --> Utf8 Class Initialized
INFO - 2023-09-10 10:58:11 --> URI Class Initialized
INFO - 2023-09-10 10:58:11 --> Router Class Initialized
INFO - 2023-09-10 10:58:11 --> Output Class Initialized
INFO - 2023-09-10 10:58:11 --> Security Class Initialized
DEBUG - 2023-09-10 10:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 10:58:11 --> Input Class Initialized
INFO - 2023-09-10 10:58:11 --> Language Class Initialized
ERROR - 2023-09-10 10:58:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:00:21 --> Config Class Initialized
INFO - 2023-09-10 11:00:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:00:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:00:21 --> Utf8 Class Initialized
INFO - 2023-09-10 11:00:21 --> URI Class Initialized
DEBUG - 2023-09-10 11:00:21 --> No URI present. Default controller set.
INFO - 2023-09-10 11:00:21 --> Router Class Initialized
INFO - 2023-09-10 11:00:21 --> Output Class Initialized
INFO - 2023-09-10 11:00:21 --> Security Class Initialized
DEBUG - 2023-09-10 11:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:00:21 --> Input Class Initialized
INFO - 2023-09-10 11:00:21 --> Language Class Initialized
INFO - 2023-09-10 11:00:21 --> Loader Class Initialized
INFO - 2023-09-10 11:00:21 --> Helper loaded: url_helper
INFO - 2023-09-10 11:00:21 --> Helper loaded: file_helper
INFO - 2023-09-10 11:00:21 --> Database Driver Class Initialized
INFO - 2023-09-10 11:00:21 --> Email Class Initialized
DEBUG - 2023-09-10 11:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:00:21 --> Controller Class Initialized
INFO - 2023-09-10 11:00:21 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:00:21 --> Model "Home_model" initialized
INFO - 2023-09-10 11:00:21 --> Helper loaded: download_helper
INFO - 2023-09-10 11:00:21 --> Helper loaded: form_helper
INFO - 2023-09-10 11:00:21 --> Form Validation Class Initialized
INFO - 2023-09-10 11:00:21 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:00:21 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:00:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:00:21 --> Final output sent to browser
DEBUG - 2023-09-10 11:00:22 --> Total execution time: 0.5480
INFO - 2023-09-10 11:00:23 --> Config Class Initialized
INFO - 2023-09-10 11:00:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:00:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:00:23 --> Utf8 Class Initialized
INFO - 2023-09-10 11:00:23 --> URI Class Initialized
INFO - 2023-09-10 11:00:23 --> Router Class Initialized
INFO - 2023-09-10 11:00:23 --> Output Class Initialized
INFO - 2023-09-10 11:00:23 --> Security Class Initialized
DEBUG - 2023-09-10 11:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:00:23 --> Input Class Initialized
INFO - 2023-09-10 11:00:23 --> Language Class Initialized
ERROR - 2023-09-10 11:00:23 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:04:29 --> Config Class Initialized
INFO - 2023-09-10 11:04:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:04:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:04:29 --> Utf8 Class Initialized
INFO - 2023-09-10 11:04:29 --> URI Class Initialized
DEBUG - 2023-09-10 11:04:29 --> No URI present. Default controller set.
INFO - 2023-09-10 11:04:29 --> Router Class Initialized
INFO - 2023-09-10 11:04:29 --> Output Class Initialized
INFO - 2023-09-10 11:04:29 --> Security Class Initialized
DEBUG - 2023-09-10 11:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:04:29 --> Input Class Initialized
INFO - 2023-09-10 11:04:29 --> Language Class Initialized
INFO - 2023-09-10 11:04:29 --> Loader Class Initialized
INFO - 2023-09-10 11:04:29 --> Helper loaded: url_helper
INFO - 2023-09-10 11:04:29 --> Helper loaded: file_helper
INFO - 2023-09-10 11:04:29 --> Database Driver Class Initialized
INFO - 2023-09-10 11:04:29 --> Email Class Initialized
DEBUG - 2023-09-10 11:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:04:29 --> Controller Class Initialized
INFO - 2023-09-10 11:04:30 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:04:30 --> Model "Home_model" initialized
INFO - 2023-09-10 11:04:30 --> Helper loaded: download_helper
INFO - 2023-09-10 11:04:30 --> Helper loaded: form_helper
INFO - 2023-09-10 11:04:30 --> Form Validation Class Initialized
INFO - 2023-09-10 11:04:30 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:04:30 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:04:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:04:30 --> Final output sent to browser
DEBUG - 2023-09-10 11:04:30 --> Total execution time: 1.3029
INFO - 2023-09-10 11:04:30 --> Config Class Initialized
INFO - 2023-09-10 11:04:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:04:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:04:30 --> Utf8 Class Initialized
INFO - 2023-09-10 11:04:30 --> URI Class Initialized
INFO - 2023-09-10 11:04:30 --> Router Class Initialized
INFO - 2023-09-10 11:04:30 --> Output Class Initialized
INFO - 2023-09-10 11:04:30 --> Security Class Initialized
DEBUG - 2023-09-10 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:04:30 --> Input Class Initialized
INFO - 2023-09-10 11:04:30 --> Language Class Initialized
ERROR - 2023-09-10 11:04:30 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:05:18 --> Config Class Initialized
INFO - 2023-09-10 11:05:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:05:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:05:18 --> Utf8 Class Initialized
INFO - 2023-09-10 11:05:18 --> URI Class Initialized
DEBUG - 2023-09-10 11:05:18 --> No URI present. Default controller set.
INFO - 2023-09-10 11:05:18 --> Router Class Initialized
INFO - 2023-09-10 11:05:18 --> Output Class Initialized
INFO - 2023-09-10 11:05:18 --> Security Class Initialized
DEBUG - 2023-09-10 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:05:18 --> Input Class Initialized
INFO - 2023-09-10 11:05:18 --> Language Class Initialized
INFO - 2023-09-10 11:05:18 --> Loader Class Initialized
INFO - 2023-09-10 11:05:18 --> Helper loaded: url_helper
INFO - 2023-09-10 11:05:18 --> Helper loaded: file_helper
INFO - 2023-09-10 11:05:18 --> Database Driver Class Initialized
INFO - 2023-09-10 11:05:18 --> Email Class Initialized
DEBUG - 2023-09-10 11:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:05:18 --> Controller Class Initialized
INFO - 2023-09-10 11:05:18 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:05:18 --> Model "Home_model" initialized
INFO - 2023-09-10 11:05:18 --> Helper loaded: download_helper
INFO - 2023-09-10 11:05:18 --> Helper loaded: form_helper
INFO - 2023-09-10 11:05:19 --> Form Validation Class Initialized
INFO - 2023-09-10 11:05:19 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:05:19 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:05:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:05:19 --> Final output sent to browser
DEBUG - 2023-09-10 11:05:19 --> Total execution time: 1.0292
INFO - 2023-09-10 11:05:21 --> Config Class Initialized
INFO - 2023-09-10 11:05:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:05:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:05:21 --> Utf8 Class Initialized
INFO - 2023-09-10 11:05:21 --> URI Class Initialized
INFO - 2023-09-10 11:05:29 --> Config Class Initialized
INFO - 2023-09-10 11:05:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:05:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:05:29 --> Utf8 Class Initialized
INFO - 2023-09-10 11:05:29 --> URI Class Initialized
DEBUG - 2023-09-10 11:05:29 --> No URI present. Default controller set.
INFO - 2023-09-10 11:05:29 --> Router Class Initialized
INFO - 2023-09-10 11:05:29 --> Output Class Initialized
INFO - 2023-09-10 11:05:29 --> Security Class Initialized
DEBUG - 2023-09-10 11:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:05:29 --> Input Class Initialized
INFO - 2023-09-10 11:05:29 --> Language Class Initialized
INFO - 2023-09-10 11:05:29 --> Loader Class Initialized
INFO - 2023-09-10 11:05:29 --> Helper loaded: url_helper
INFO - 2023-09-10 11:05:29 --> Helper loaded: file_helper
INFO - 2023-09-10 11:05:29 --> Database Driver Class Initialized
INFO - 2023-09-10 11:05:29 --> Email Class Initialized
DEBUG - 2023-09-10 11:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:05:29 --> Controller Class Initialized
INFO - 2023-09-10 11:05:29 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:05:29 --> Model "Home_model" initialized
INFO - 2023-09-10 11:05:29 --> Helper loaded: download_helper
INFO - 2023-09-10 11:05:29 --> Helper loaded: form_helper
INFO - 2023-09-10 11:05:29 --> Form Validation Class Initialized
INFO - 2023-09-10 11:05:29 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:05:29 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:05:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:05:30 --> Final output sent to browser
DEBUG - 2023-09-10 11:05:30 --> Total execution time: 1.0482
INFO - 2023-09-10 11:05:31 --> Config Class Initialized
INFO - 2023-09-10 11:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:05:31 --> Utf8 Class Initialized
INFO - 2023-09-10 11:05:31 --> URI Class Initialized
INFO - 2023-09-10 11:05:31 --> Router Class Initialized
INFO - 2023-09-10 11:05:31 --> Output Class Initialized
INFO - 2023-09-10 11:05:31 --> Security Class Initialized
DEBUG - 2023-09-10 11:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:05:31 --> Input Class Initialized
INFO - 2023-09-10 11:05:31 --> Language Class Initialized
ERROR - 2023-09-10 11:05:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:06:59 --> Config Class Initialized
INFO - 2023-09-10 11:06:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:06:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:00 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:00 --> URI Class Initialized
DEBUG - 2023-09-10 11:07:00 --> No URI present. Default controller set.
INFO - 2023-09-10 11:07:00 --> Router Class Initialized
INFO - 2023-09-10 11:07:00 --> Output Class Initialized
INFO - 2023-09-10 11:07:00 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:00 --> Input Class Initialized
INFO - 2023-09-10 11:07:00 --> Language Class Initialized
INFO - 2023-09-10 11:07:00 --> Loader Class Initialized
INFO - 2023-09-10 11:07:00 --> Helper loaded: url_helper
INFO - 2023-09-10 11:07:00 --> Helper loaded: file_helper
INFO - 2023-09-10 11:07:00 --> Database Driver Class Initialized
INFO - 2023-09-10 11:07:00 --> Email Class Initialized
DEBUG - 2023-09-10 11:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:07:00 --> Controller Class Initialized
INFO - 2023-09-10 11:07:00 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:07:00 --> Model "Home_model" initialized
INFO - 2023-09-10 11:07:01 --> Helper loaded: download_helper
INFO - 2023-09-10 11:07:01 --> Helper loaded: form_helper
INFO - 2023-09-10 11:07:01 --> Form Validation Class Initialized
INFO - 2023-09-10 11:07:01 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:07:01 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:07:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:07:01 --> Final output sent to browser
DEBUG - 2023-09-10 11:07:01 --> Total execution time: 1.3665
INFO - 2023-09-10 11:07:04 --> Config Class Initialized
INFO - 2023-09-10 11:07:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:04 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:04 --> URI Class Initialized
INFO - 2023-09-10 11:07:04 --> Router Class Initialized
INFO - 2023-09-10 11:07:04 --> Output Class Initialized
INFO - 2023-09-10 11:07:04 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:04 --> Input Class Initialized
INFO - 2023-09-10 11:07:04 --> Language Class Initialized
ERROR - 2023-09-10 11:07:04 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:07:25 --> Config Class Initialized
INFO - 2023-09-10 11:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:25 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:25 --> URI Class Initialized
INFO - 2023-09-10 11:07:25 --> Router Class Initialized
INFO - 2023-09-10 11:07:25 --> Output Class Initialized
INFO - 2023-09-10 11:07:25 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:25 --> Input Class Initialized
INFO - 2023-09-10 11:07:25 --> Language Class Initialized
ERROR - 2023-09-10 11:07:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:25 --> Config Class Initialized
INFO - 2023-09-10 11:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:25 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:25 --> URI Class Initialized
INFO - 2023-09-10 11:07:25 --> Router Class Initialized
INFO - 2023-09-10 11:07:25 --> Output Class Initialized
INFO - 2023-09-10 11:07:25 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:25 --> Input Class Initialized
INFO - 2023-09-10 11:07:25 --> Language Class Initialized
ERROR - 2023-09-10 11:07:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:26 --> Config Class Initialized
INFO - 2023-09-10 11:07:26 --> Config Class Initialized
INFO - 2023-09-10 11:07:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:27 --> URI Class Initialized
INFO - 2023-09-10 11:07:27 --> Config Class Initialized
INFO - 2023-09-10 11:07:27 --> Config Class Initialized
INFO - 2023-09-10 11:07:27 --> Config Class Initialized
INFO - 2023-09-10 11:07:27 --> Router Class Initialized
INFO - 2023-09-10 11:07:27 --> URI Class Initialized
INFO - 2023-09-10 11:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:27 --> URI Class Initialized
INFO - 2023-09-10 11:07:27 --> Router Class Initialized
INFO - 2023-09-10 11:07:27 --> Output Class Initialized
INFO - 2023-09-10 11:07:27 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:27 --> Input Class Initialized
INFO - 2023-09-10 11:07:27 --> Language Class Initialized
ERROR - 2023-09-10 11:07:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:27 --> Router Class Initialized
INFO - 2023-09-10 11:07:27 --> Output Class Initialized
INFO - 2023-09-10 11:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:27 --> Hooks Class Initialized
INFO - 2023-09-10 11:07:27 --> Output Class Initialized
INFO - 2023-09-10 11:07:27 --> Security Class Initialized
INFO - 2023-09-10 11:07:27 --> Security Class Initialized
INFO - 2023-09-10 11:07:27 --> Utf8 Class Initialized
DEBUG - 2023-09-10 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 11:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:07:27 --> Input Class Initialized
DEBUG - 2023-09-10 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:27 --> URI Class Initialized
INFO - 2023-09-10 11:07:27 --> Input Class Initialized
INFO - 2023-09-10 11:07:28 --> Language Class Initialized
ERROR - 2023-09-10 11:07:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:28 --> Language Class Initialized
INFO - 2023-09-10 11:07:28 --> Router Class Initialized
INFO - 2023-09-10 11:07:28 --> Utf8 Class Initialized
INFO - 2023-09-10 11:07:28 --> URI Class Initialized
ERROR - 2023-09-10 11:07:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:28 --> Router Class Initialized
INFO - 2023-09-10 11:07:28 --> Output Class Initialized
INFO - 2023-09-10 11:07:28 --> Output Class Initialized
INFO - 2023-09-10 11:07:28 --> Security Class Initialized
DEBUG - 2023-09-10 11:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:28 --> Security Class Initialized
INFO - 2023-09-10 11:07:28 --> Input Class Initialized
DEBUG - 2023-09-10 11:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:07:28 --> Language Class Initialized
INFO - 2023-09-10 11:07:28 --> Input Class Initialized
ERROR - 2023-09-10 11:07:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:07:28 --> Language Class Initialized
ERROR - 2023-09-10 11:07:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 11:08:19 --> Config Class Initialized
INFO - 2023-09-10 11:08:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:08:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:08:19 --> Utf8 Class Initialized
INFO - 2023-09-10 11:08:19 --> URI Class Initialized
DEBUG - 2023-09-10 11:08:19 --> No URI present. Default controller set.
INFO - 2023-09-10 11:08:19 --> Router Class Initialized
INFO - 2023-09-10 11:08:19 --> Output Class Initialized
INFO - 2023-09-10 11:08:19 --> Security Class Initialized
DEBUG - 2023-09-10 11:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:08:20 --> Input Class Initialized
INFO - 2023-09-10 11:08:20 --> Language Class Initialized
INFO - 2023-09-10 11:08:20 --> Loader Class Initialized
INFO - 2023-09-10 11:08:20 --> Helper loaded: url_helper
INFO - 2023-09-10 11:08:20 --> Helper loaded: file_helper
INFO - 2023-09-10 11:08:20 --> Database Driver Class Initialized
INFO - 2023-09-10 11:08:20 --> Email Class Initialized
DEBUG - 2023-09-10 11:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:08:20 --> Controller Class Initialized
INFO - 2023-09-10 11:08:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:08:20 --> Model "Home_model" initialized
INFO - 2023-09-10 11:08:20 --> Helper loaded: download_helper
INFO - 2023-09-10 11:08:20 --> Helper loaded: form_helper
INFO - 2023-09-10 11:08:20 --> Form Validation Class Initialized
INFO - 2023-09-10 11:08:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:08:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:08:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:08:20 --> Final output sent to browser
DEBUG - 2023-09-10 11:08:20 --> Total execution time: 0.8344
INFO - 2023-09-10 11:08:21 --> Config Class Initialized
INFO - 2023-09-10 11:08:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:08:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:08:22 --> Utf8 Class Initialized
INFO - 2023-09-10 11:08:22 --> URI Class Initialized
INFO - 2023-09-10 11:08:22 --> Router Class Initialized
INFO - 2023-09-10 11:08:22 --> Output Class Initialized
INFO - 2023-09-10 11:08:22 --> Security Class Initialized
DEBUG - 2023-09-10 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:08:22 --> Input Class Initialized
INFO - 2023-09-10 11:08:22 --> Language Class Initialized
ERROR - 2023-09-10 11:08:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:10:19 --> Config Class Initialized
INFO - 2023-09-10 11:10:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:10:19 --> Utf8 Class Initialized
INFO - 2023-09-10 11:10:19 --> URI Class Initialized
DEBUG - 2023-09-10 11:10:19 --> No URI present. Default controller set.
INFO - 2023-09-10 11:10:19 --> Router Class Initialized
INFO - 2023-09-10 11:10:19 --> Output Class Initialized
INFO - 2023-09-10 11:10:19 --> Security Class Initialized
DEBUG - 2023-09-10 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:10:19 --> Input Class Initialized
INFO - 2023-09-10 11:10:19 --> Language Class Initialized
INFO - 2023-09-10 11:10:19 --> Loader Class Initialized
INFO - 2023-09-10 11:10:19 --> Helper loaded: url_helper
INFO - 2023-09-10 11:10:19 --> Helper loaded: file_helper
INFO - 2023-09-10 11:10:19 --> Database Driver Class Initialized
INFO - 2023-09-10 11:10:19 --> Email Class Initialized
DEBUG - 2023-09-10 11:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:10:19 --> Controller Class Initialized
INFO - 2023-09-10 11:10:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:10:19 --> Model "Home_model" initialized
INFO - 2023-09-10 11:10:19 --> Helper loaded: download_helper
INFO - 2023-09-10 11:10:19 --> Helper loaded: form_helper
INFO - 2023-09-10 11:10:19 --> Form Validation Class Initialized
INFO - 2023-09-10 11:10:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:10:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:10:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:10:20 --> Final output sent to browser
DEBUG - 2023-09-10 11:10:20 --> Total execution time: 0.9394
INFO - 2023-09-10 11:10:21 --> Config Class Initialized
INFO - 2023-09-10 11:10:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:10:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:10:21 --> Utf8 Class Initialized
INFO - 2023-09-10 11:10:21 --> URI Class Initialized
INFO - 2023-09-10 11:10:21 --> Router Class Initialized
INFO - 2023-09-10 11:10:21 --> Output Class Initialized
INFO - 2023-09-10 11:10:21 --> Security Class Initialized
DEBUG - 2023-09-10 11:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:10:21 --> Input Class Initialized
INFO - 2023-09-10 11:10:21 --> Language Class Initialized
ERROR - 2023-09-10 11:10:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:11:22 --> Config Class Initialized
INFO - 2023-09-10 11:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:11:22 --> Utf8 Class Initialized
INFO - 2023-09-10 11:11:22 --> URI Class Initialized
DEBUG - 2023-09-10 11:11:22 --> No URI present. Default controller set.
INFO - 2023-09-10 11:11:22 --> Router Class Initialized
INFO - 2023-09-10 11:11:22 --> Output Class Initialized
INFO - 2023-09-10 11:11:22 --> Security Class Initialized
DEBUG - 2023-09-10 11:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:11:22 --> Input Class Initialized
INFO - 2023-09-10 11:11:22 --> Language Class Initialized
INFO - 2023-09-10 11:11:22 --> Loader Class Initialized
INFO - 2023-09-10 11:11:22 --> Helper loaded: url_helper
INFO - 2023-09-10 11:11:22 --> Helper loaded: file_helper
INFO - 2023-09-10 11:11:22 --> Database Driver Class Initialized
INFO - 2023-09-10 11:11:22 --> Email Class Initialized
DEBUG - 2023-09-10 11:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:11:22 --> Controller Class Initialized
INFO - 2023-09-10 11:11:22 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:11:22 --> Model "Home_model" initialized
INFO - 2023-09-10 11:11:22 --> Helper loaded: download_helper
INFO - 2023-09-10 11:11:22 --> Helper loaded: form_helper
INFO - 2023-09-10 11:11:22 --> Form Validation Class Initialized
INFO - 2023-09-10 11:11:22 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:11:22 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:11:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:11:22 --> Final output sent to browser
DEBUG - 2023-09-10 11:11:22 --> Total execution time: 0.5608
INFO - 2023-09-10 11:11:23 --> Config Class Initialized
INFO - 2023-09-10 11:11:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:11:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:11:24 --> Utf8 Class Initialized
INFO - 2023-09-10 11:11:24 --> URI Class Initialized
INFO - 2023-09-10 11:11:24 --> Router Class Initialized
INFO - 2023-09-10 11:11:24 --> Output Class Initialized
INFO - 2023-09-10 11:11:24 --> Security Class Initialized
DEBUG - 2023-09-10 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:11:24 --> Input Class Initialized
INFO - 2023-09-10 11:11:24 --> Language Class Initialized
ERROR - 2023-09-10 11:11:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:11:45 --> Config Class Initialized
INFO - 2023-09-10 11:11:45 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:11:45 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:11:45 --> Utf8 Class Initialized
INFO - 2023-09-10 11:11:45 --> URI Class Initialized
DEBUG - 2023-09-10 11:11:45 --> No URI present. Default controller set.
INFO - 2023-09-10 11:11:45 --> Router Class Initialized
INFO - 2023-09-10 11:11:45 --> Output Class Initialized
INFO - 2023-09-10 11:11:46 --> Security Class Initialized
DEBUG - 2023-09-10 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:11:46 --> Input Class Initialized
INFO - 2023-09-10 11:11:46 --> Language Class Initialized
INFO - 2023-09-10 11:11:46 --> Loader Class Initialized
INFO - 2023-09-10 11:11:46 --> Helper loaded: url_helper
INFO - 2023-09-10 11:11:46 --> Helper loaded: file_helper
INFO - 2023-09-10 11:11:46 --> Database Driver Class Initialized
INFO - 2023-09-10 11:11:46 --> Email Class Initialized
DEBUG - 2023-09-10 11:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:11:46 --> Controller Class Initialized
INFO - 2023-09-10 11:11:46 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:11:46 --> Model "Home_model" initialized
INFO - 2023-09-10 11:11:46 --> Helper loaded: download_helper
INFO - 2023-09-10 11:11:46 --> Helper loaded: form_helper
INFO - 2023-09-10 11:11:46 --> Form Validation Class Initialized
INFO - 2023-09-10 11:11:46 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:11:46 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:11:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:11:46 --> Final output sent to browser
DEBUG - 2023-09-10 11:11:46 --> Total execution time: 0.7688
INFO - 2023-09-10 11:11:47 --> Config Class Initialized
INFO - 2023-09-10 11:11:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:11:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:11:47 --> Utf8 Class Initialized
INFO - 2023-09-10 11:11:47 --> URI Class Initialized
INFO - 2023-09-10 11:11:47 --> Router Class Initialized
INFO - 2023-09-10 11:11:47 --> Output Class Initialized
INFO - 2023-09-10 11:11:47 --> Security Class Initialized
DEBUG - 2023-09-10 11:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:11:48 --> Input Class Initialized
INFO - 2023-09-10 11:11:48 --> Language Class Initialized
ERROR - 2023-09-10 11:11:48 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:12:04 --> Config Class Initialized
INFO - 2023-09-10 11:12:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:04 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:04 --> URI Class Initialized
DEBUG - 2023-09-10 11:12:04 --> No URI present. Default controller set.
INFO - 2023-09-10 11:12:04 --> Router Class Initialized
INFO - 2023-09-10 11:12:04 --> Output Class Initialized
INFO - 2023-09-10 11:12:04 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:04 --> Input Class Initialized
INFO - 2023-09-10 11:12:04 --> Language Class Initialized
INFO - 2023-09-10 11:12:04 --> Loader Class Initialized
INFO - 2023-09-10 11:12:04 --> Helper loaded: url_helper
INFO - 2023-09-10 11:12:04 --> Helper loaded: file_helper
INFO - 2023-09-10 11:12:04 --> Database Driver Class Initialized
INFO - 2023-09-10 11:12:04 --> Email Class Initialized
DEBUG - 2023-09-10 11:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:12:04 --> Controller Class Initialized
INFO - 2023-09-10 11:12:04 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:12:04 --> Model "Home_model" initialized
INFO - 2023-09-10 11:12:04 --> Helper loaded: download_helper
INFO - 2023-09-10 11:12:04 --> Helper loaded: form_helper
INFO - 2023-09-10 11:12:04 --> Form Validation Class Initialized
INFO - 2023-09-10 11:12:04 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:12:04 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:12:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:12:04 --> Final output sent to browser
DEBUG - 2023-09-10 11:12:04 --> Total execution time: 0.1914
INFO - 2023-09-10 11:12:04 --> Config Class Initialized
INFO - 2023-09-10 11:12:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:04 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:04 --> URI Class Initialized
INFO - 2023-09-10 11:12:04 --> Router Class Initialized
INFO - 2023-09-10 11:12:04 --> Output Class Initialized
INFO - 2023-09-10 11:12:04 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:04 --> Input Class Initialized
INFO - 2023-09-10 11:12:04 --> Language Class Initialized
ERROR - 2023-09-10 11:12:04 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:12:23 --> Config Class Initialized
INFO - 2023-09-10 11:12:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:23 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:23 --> URI Class Initialized
DEBUG - 2023-09-10 11:12:23 --> No URI present. Default controller set.
INFO - 2023-09-10 11:12:23 --> Router Class Initialized
INFO - 2023-09-10 11:12:23 --> Output Class Initialized
INFO - 2023-09-10 11:12:23 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:23 --> Input Class Initialized
INFO - 2023-09-10 11:12:23 --> Language Class Initialized
INFO - 2023-09-10 11:12:23 --> Loader Class Initialized
INFO - 2023-09-10 11:12:23 --> Helper loaded: url_helper
INFO - 2023-09-10 11:12:23 --> Helper loaded: file_helper
INFO - 2023-09-10 11:12:23 --> Database Driver Class Initialized
INFO - 2023-09-10 11:12:23 --> Email Class Initialized
DEBUG - 2023-09-10 11:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:12:23 --> Controller Class Initialized
INFO - 2023-09-10 11:12:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:12:23 --> Model "Home_model" initialized
INFO - 2023-09-10 11:12:23 --> Helper loaded: download_helper
INFO - 2023-09-10 11:12:23 --> Helper loaded: form_helper
INFO - 2023-09-10 11:12:23 --> Form Validation Class Initialized
INFO - 2023-09-10 11:12:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:12:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:12:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:12:23 --> Final output sent to browser
DEBUG - 2023-09-10 11:12:23 --> Total execution time: 0.2004
INFO - 2023-09-10 11:12:24 --> Config Class Initialized
INFO - 2023-09-10 11:12:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:24 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:24 --> URI Class Initialized
INFO - 2023-09-10 11:12:24 --> Router Class Initialized
INFO - 2023-09-10 11:12:24 --> Output Class Initialized
INFO - 2023-09-10 11:12:24 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:24 --> Input Class Initialized
INFO - 2023-09-10 11:12:24 --> Language Class Initialized
ERROR - 2023-09-10 11:12:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:12:53 --> Config Class Initialized
INFO - 2023-09-10 11:12:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:53 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:53 --> URI Class Initialized
DEBUG - 2023-09-10 11:12:53 --> No URI present. Default controller set.
INFO - 2023-09-10 11:12:53 --> Router Class Initialized
INFO - 2023-09-10 11:12:53 --> Output Class Initialized
INFO - 2023-09-10 11:12:53 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:53 --> Input Class Initialized
INFO - 2023-09-10 11:12:53 --> Language Class Initialized
INFO - 2023-09-10 11:12:53 --> Loader Class Initialized
INFO - 2023-09-10 11:12:53 --> Helper loaded: url_helper
INFO - 2023-09-10 11:12:53 --> Helper loaded: file_helper
INFO - 2023-09-10 11:12:53 --> Database Driver Class Initialized
INFO - 2023-09-10 11:12:53 --> Email Class Initialized
DEBUG - 2023-09-10 11:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:12:53 --> Controller Class Initialized
INFO - 2023-09-10 11:12:53 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:12:53 --> Model "Home_model" initialized
INFO - 2023-09-10 11:12:53 --> Helper loaded: download_helper
INFO - 2023-09-10 11:12:53 --> Helper loaded: form_helper
INFO - 2023-09-10 11:12:53 --> Form Validation Class Initialized
INFO - 2023-09-10 11:12:53 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:12:53 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:12:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:12:54 --> Final output sent to browser
DEBUG - 2023-09-10 11:12:54 --> Total execution time: 0.8249
INFO - 2023-09-10 11:12:54 --> Config Class Initialized
INFO - 2023-09-10 11:12:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:12:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:12:55 --> Utf8 Class Initialized
INFO - 2023-09-10 11:12:55 --> URI Class Initialized
INFO - 2023-09-10 11:12:55 --> Router Class Initialized
INFO - 2023-09-10 11:12:55 --> Output Class Initialized
INFO - 2023-09-10 11:12:55 --> Security Class Initialized
DEBUG - 2023-09-10 11:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:12:55 --> Input Class Initialized
INFO - 2023-09-10 11:12:55 --> Language Class Initialized
ERROR - 2023-09-10 11:12:55 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:15:12 --> Config Class Initialized
INFO - 2023-09-10 11:15:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:15:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:15:12 --> Utf8 Class Initialized
INFO - 2023-09-10 11:15:12 --> URI Class Initialized
DEBUG - 2023-09-10 11:15:12 --> No URI present. Default controller set.
INFO - 2023-09-10 11:15:12 --> Router Class Initialized
INFO - 2023-09-10 11:15:12 --> Output Class Initialized
INFO - 2023-09-10 11:15:12 --> Security Class Initialized
DEBUG - 2023-09-10 11:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:15:12 --> Input Class Initialized
INFO - 2023-09-10 11:15:12 --> Language Class Initialized
INFO - 2023-09-10 11:15:12 --> Loader Class Initialized
INFO - 2023-09-10 11:15:12 --> Helper loaded: url_helper
INFO - 2023-09-10 11:15:12 --> Helper loaded: file_helper
INFO - 2023-09-10 11:15:12 --> Database Driver Class Initialized
INFO - 2023-09-10 11:15:12 --> Email Class Initialized
DEBUG - 2023-09-10 11:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:15:12 --> Controller Class Initialized
INFO - 2023-09-10 11:15:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:15:13 --> Model "Home_model" initialized
INFO - 2023-09-10 11:15:13 --> Helper loaded: download_helper
INFO - 2023-09-10 11:15:13 --> Helper loaded: form_helper
INFO - 2023-09-10 11:15:13 --> Form Validation Class Initialized
INFO - 2023-09-10 11:15:13 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:15:13 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:15:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:15:13 --> Final output sent to browser
DEBUG - 2023-09-10 11:15:13 --> Total execution time: 0.9227
INFO - 2023-09-10 11:15:14 --> Config Class Initialized
INFO - 2023-09-10 11:15:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:15:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:15:14 --> Utf8 Class Initialized
INFO - 2023-09-10 11:15:14 --> URI Class Initialized
INFO - 2023-09-10 11:15:14 --> Router Class Initialized
INFO - 2023-09-10 11:15:14 --> Output Class Initialized
INFO - 2023-09-10 11:15:14 --> Security Class Initialized
DEBUG - 2023-09-10 11:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:15:15 --> Input Class Initialized
INFO - 2023-09-10 11:15:15 --> Language Class Initialized
ERROR - 2023-09-10 11:15:15 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:16:22 --> Config Class Initialized
INFO - 2023-09-10 11:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:16:22 --> Utf8 Class Initialized
INFO - 2023-09-10 11:16:22 --> URI Class Initialized
DEBUG - 2023-09-10 11:16:22 --> No URI present. Default controller set.
INFO - 2023-09-10 11:16:22 --> Router Class Initialized
INFO - 2023-09-10 11:16:22 --> Output Class Initialized
INFO - 2023-09-10 11:16:22 --> Security Class Initialized
DEBUG - 2023-09-10 11:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:16:23 --> Input Class Initialized
INFO - 2023-09-10 11:16:23 --> Language Class Initialized
INFO - 2023-09-10 11:16:23 --> Loader Class Initialized
INFO - 2023-09-10 11:16:23 --> Helper loaded: url_helper
INFO - 2023-09-10 11:16:23 --> Helper loaded: file_helper
INFO - 2023-09-10 11:16:23 --> Database Driver Class Initialized
INFO - 2023-09-10 11:16:23 --> Email Class Initialized
DEBUG - 2023-09-10 11:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:16:23 --> Controller Class Initialized
INFO - 2023-09-10 11:16:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:16:23 --> Model "Home_model" initialized
INFO - 2023-09-10 11:16:23 --> Helper loaded: download_helper
INFO - 2023-09-10 11:16:23 --> Helper loaded: form_helper
INFO - 2023-09-10 11:16:23 --> Form Validation Class Initialized
INFO - 2023-09-10 11:16:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:16:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:16:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:16:23 --> Final output sent to browser
DEBUG - 2023-09-10 11:16:23 --> Total execution time: 0.9308
INFO - 2023-09-10 11:16:25 --> Config Class Initialized
INFO - 2023-09-10 11:16:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:16:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:16:25 --> Utf8 Class Initialized
INFO - 2023-09-10 11:16:25 --> URI Class Initialized
INFO - 2023-09-10 11:16:25 --> Router Class Initialized
INFO - 2023-09-10 11:16:25 --> Output Class Initialized
INFO - 2023-09-10 11:16:25 --> Security Class Initialized
DEBUG - 2023-09-10 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:16:25 --> Input Class Initialized
INFO - 2023-09-10 11:16:25 --> Language Class Initialized
ERROR - 2023-09-10 11:16:25 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:50:12 --> Config Class Initialized
INFO - 2023-09-10 11:50:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:50:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:50:12 --> Utf8 Class Initialized
INFO - 2023-09-10 11:50:12 --> URI Class Initialized
DEBUG - 2023-09-10 11:50:12 --> No URI present. Default controller set.
INFO - 2023-09-10 11:50:12 --> Router Class Initialized
INFO - 2023-09-10 11:50:12 --> Output Class Initialized
INFO - 2023-09-10 11:50:12 --> Security Class Initialized
DEBUG - 2023-09-10 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:50:12 --> Input Class Initialized
INFO - 2023-09-10 11:50:12 --> Language Class Initialized
INFO - 2023-09-10 11:50:12 --> Loader Class Initialized
INFO - 2023-09-10 11:50:12 --> Helper loaded: url_helper
INFO - 2023-09-10 11:50:12 --> Helper loaded: file_helper
INFO - 2023-09-10 11:50:12 --> Database Driver Class Initialized
INFO - 2023-09-10 11:50:12 --> Email Class Initialized
DEBUG - 2023-09-10 11:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:50:12 --> Controller Class Initialized
INFO - 2023-09-10 11:50:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:50:12 --> Model "Home_model" initialized
INFO - 2023-09-10 11:50:12 --> Helper loaded: download_helper
INFO - 2023-09-10 11:50:12 --> Helper loaded: form_helper
INFO - 2023-09-10 11:50:12 --> Form Validation Class Initialized
INFO - 2023-09-10 11:50:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:50:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:50:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:50:12 --> Final output sent to browser
DEBUG - 2023-09-10 11:50:12 --> Total execution time: 0.4556
INFO - 2023-09-10 11:50:14 --> Config Class Initialized
INFO - 2023-09-10 11:50:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:50:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:50:15 --> Utf8 Class Initialized
INFO - 2023-09-10 11:50:15 --> URI Class Initialized
INFO - 2023-09-10 11:50:15 --> Router Class Initialized
INFO - 2023-09-10 11:50:15 --> Output Class Initialized
INFO - 2023-09-10 11:50:15 --> Security Class Initialized
DEBUG - 2023-09-10 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:50:15 --> Input Class Initialized
INFO - 2023-09-10 11:50:15 --> Language Class Initialized
ERROR - 2023-09-10 11:50:15 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:57:11 --> Config Class Initialized
INFO - 2023-09-10 11:57:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:57:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:57:11 --> Utf8 Class Initialized
INFO - 2023-09-10 11:57:11 --> URI Class Initialized
DEBUG - 2023-09-10 11:57:11 --> No URI present. Default controller set.
INFO - 2023-09-10 11:57:11 --> Router Class Initialized
INFO - 2023-09-10 11:57:11 --> Output Class Initialized
INFO - 2023-09-10 11:57:11 --> Security Class Initialized
DEBUG - 2023-09-10 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:57:11 --> Input Class Initialized
INFO - 2023-09-10 11:57:11 --> Language Class Initialized
INFO - 2023-09-10 11:57:11 --> Loader Class Initialized
INFO - 2023-09-10 11:57:11 --> Helper loaded: url_helper
INFO - 2023-09-10 11:57:11 --> Helper loaded: file_helper
INFO - 2023-09-10 11:57:11 --> Database Driver Class Initialized
INFO - 2023-09-10 11:57:11 --> Email Class Initialized
DEBUG - 2023-09-10 11:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:57:11 --> Controller Class Initialized
INFO - 2023-09-10 11:57:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:57:12 --> Model "Home_model" initialized
INFO - 2023-09-10 11:57:12 --> Helper loaded: download_helper
INFO - 2023-09-10 11:57:12 --> Helper loaded: form_helper
INFO - 2023-09-10 11:57:12 --> Form Validation Class Initialized
INFO - 2023-09-10 11:57:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:57:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:57:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:57:12 --> Final output sent to browser
DEBUG - 2023-09-10 11:57:12 --> Total execution time: 1.1284
INFO - 2023-09-10 11:57:13 --> Config Class Initialized
INFO - 2023-09-10 11:57:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:57:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:57:14 --> Utf8 Class Initialized
INFO - 2023-09-10 11:57:14 --> URI Class Initialized
INFO - 2023-09-10 11:57:14 --> Router Class Initialized
INFO - 2023-09-10 11:57:14 --> Output Class Initialized
INFO - 2023-09-10 11:57:14 --> Security Class Initialized
DEBUG - 2023-09-10 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:57:14 --> Input Class Initialized
INFO - 2023-09-10 11:57:14 --> Language Class Initialized
ERROR - 2023-09-10 11:57:14 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 11:58:12 --> Config Class Initialized
INFO - 2023-09-10 11:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:58:12 --> Utf8 Class Initialized
INFO - 2023-09-10 11:58:12 --> URI Class Initialized
DEBUG - 2023-09-10 11:58:12 --> No URI present. Default controller set.
INFO - 2023-09-10 11:58:12 --> Router Class Initialized
INFO - 2023-09-10 11:58:12 --> Output Class Initialized
INFO - 2023-09-10 11:58:12 --> Security Class Initialized
DEBUG - 2023-09-10 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:58:12 --> Input Class Initialized
INFO - 2023-09-10 11:58:12 --> Language Class Initialized
INFO - 2023-09-10 11:58:12 --> Loader Class Initialized
INFO - 2023-09-10 11:58:12 --> Helper loaded: url_helper
INFO - 2023-09-10 11:58:12 --> Helper loaded: file_helper
INFO - 2023-09-10 11:58:12 --> Database Driver Class Initialized
INFO - 2023-09-10 11:58:12 --> Email Class Initialized
DEBUG - 2023-09-10 11:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 11:58:12 --> Controller Class Initialized
INFO - 2023-09-10 11:58:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 11:58:12 --> Model "Home_model" initialized
INFO - 2023-09-10 11:58:12 --> Helper loaded: download_helper
INFO - 2023-09-10 11:58:12 --> Helper loaded: form_helper
INFO - 2023-09-10 11:58:12 --> Form Validation Class Initialized
INFO - 2023-09-10 11:58:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 11:58:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 11:58:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 11:58:12 --> Final output sent to browser
DEBUG - 2023-09-10 11:58:12 --> Total execution time: 0.1972
INFO - 2023-09-10 11:58:13 --> Config Class Initialized
INFO - 2023-09-10 11:58:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 11:58:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 11:58:13 --> Utf8 Class Initialized
INFO - 2023-09-10 11:58:13 --> URI Class Initialized
INFO - 2023-09-10 11:58:13 --> Router Class Initialized
INFO - 2023-09-10 11:58:13 --> Output Class Initialized
INFO - 2023-09-10 11:58:13 --> Security Class Initialized
DEBUG - 2023-09-10 11:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 11:58:13 --> Input Class Initialized
INFO - 2023-09-10 11:58:13 --> Language Class Initialized
ERROR - 2023-09-10 11:58:13 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:04:26 --> Config Class Initialized
INFO - 2023-09-10 12:04:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:04:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:04:27 --> Utf8 Class Initialized
INFO - 2023-09-10 12:04:27 --> URI Class Initialized
DEBUG - 2023-09-10 12:04:27 --> No URI present. Default controller set.
INFO - 2023-09-10 12:04:27 --> Router Class Initialized
INFO - 2023-09-10 12:04:27 --> Output Class Initialized
INFO - 2023-09-10 12:04:27 --> Security Class Initialized
DEBUG - 2023-09-10 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:04:27 --> Input Class Initialized
INFO - 2023-09-10 12:04:27 --> Language Class Initialized
INFO - 2023-09-10 12:04:27 --> Loader Class Initialized
INFO - 2023-09-10 12:04:27 --> Helper loaded: url_helper
INFO - 2023-09-10 12:04:27 --> Helper loaded: file_helper
INFO - 2023-09-10 12:04:27 --> Database Driver Class Initialized
INFO - 2023-09-10 12:04:27 --> Email Class Initialized
DEBUG - 2023-09-10 12:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:04:27 --> Controller Class Initialized
INFO - 2023-09-10 12:04:27 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:04:28 --> Model "Home_model" initialized
INFO - 2023-09-10 12:04:28 --> Helper loaded: download_helper
INFO - 2023-09-10 12:04:28 --> Helper loaded: form_helper
INFO - 2023-09-10 12:04:28 --> Form Validation Class Initialized
INFO - 2023-09-10 12:04:28 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:04:28 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:04:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:04:28 --> Final output sent to browser
DEBUG - 2023-09-10 12:04:28 --> Total execution time: 1.2715
INFO - 2023-09-10 12:04:28 --> Config Class Initialized
INFO - 2023-09-10 12:04:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:04:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:04:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:04:28 --> URI Class Initialized
INFO - 2023-09-10 12:04:28 --> Router Class Initialized
INFO - 2023-09-10 12:04:28 --> Output Class Initialized
INFO - 2023-09-10 12:04:28 --> Security Class Initialized
DEBUG - 2023-09-10 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:04:28 --> Input Class Initialized
INFO - 2023-09-10 12:04:28 --> Language Class Initialized
ERROR - 2023-09-10 12:04:28 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:05:19 --> Config Class Initialized
INFO - 2023-09-10 12:05:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:05:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:05:20 --> Utf8 Class Initialized
INFO - 2023-09-10 12:05:20 --> URI Class Initialized
DEBUG - 2023-09-10 12:05:20 --> No URI present. Default controller set.
INFO - 2023-09-10 12:05:20 --> Router Class Initialized
INFO - 2023-09-10 12:05:20 --> Output Class Initialized
INFO - 2023-09-10 12:05:20 --> Security Class Initialized
DEBUG - 2023-09-10 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:05:20 --> Input Class Initialized
INFO - 2023-09-10 12:05:20 --> Language Class Initialized
INFO - 2023-09-10 12:05:20 --> Loader Class Initialized
INFO - 2023-09-10 12:05:20 --> Helper loaded: url_helper
INFO - 2023-09-10 12:05:20 --> Helper loaded: file_helper
INFO - 2023-09-10 12:05:20 --> Database Driver Class Initialized
INFO - 2023-09-10 12:05:20 --> Email Class Initialized
DEBUG - 2023-09-10 12:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:05:20 --> Controller Class Initialized
INFO - 2023-09-10 12:05:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:05:20 --> Model "Home_model" initialized
INFO - 2023-09-10 12:05:20 --> Helper loaded: download_helper
INFO - 2023-09-10 12:05:20 --> Helper loaded: form_helper
INFO - 2023-09-10 12:05:20 --> Form Validation Class Initialized
INFO - 2023-09-10 12:05:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:05:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:05:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:05:21 --> Final output sent to browser
DEBUG - 2023-09-10 12:05:21 --> Total execution time: 1.0730
INFO - 2023-09-10 12:05:21 --> Config Class Initialized
INFO - 2023-09-10 12:05:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:05:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:05:22 --> Utf8 Class Initialized
INFO - 2023-09-10 12:05:22 --> URI Class Initialized
INFO - 2023-09-10 12:05:22 --> Router Class Initialized
INFO - 2023-09-10 12:05:22 --> Output Class Initialized
INFO - 2023-09-10 12:05:22 --> Security Class Initialized
DEBUG - 2023-09-10 12:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:05:22 --> Input Class Initialized
INFO - 2023-09-10 12:05:22 --> Language Class Initialized
ERROR - 2023-09-10 12:05:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:06:56 --> Config Class Initialized
INFO - 2023-09-10 12:06:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:06:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:06:56 --> Utf8 Class Initialized
INFO - 2023-09-10 12:06:56 --> URI Class Initialized
DEBUG - 2023-09-10 12:06:56 --> No URI present. Default controller set.
INFO - 2023-09-10 12:06:56 --> Router Class Initialized
INFO - 2023-09-10 12:06:56 --> Output Class Initialized
INFO - 2023-09-10 12:06:56 --> Security Class Initialized
DEBUG - 2023-09-10 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:06:56 --> Input Class Initialized
INFO - 2023-09-10 12:06:56 --> Language Class Initialized
INFO - 2023-09-10 12:06:56 --> Loader Class Initialized
INFO - 2023-09-10 12:06:56 --> Helper loaded: url_helper
INFO - 2023-09-10 12:06:56 --> Helper loaded: file_helper
INFO - 2023-09-10 12:06:57 --> Database Driver Class Initialized
INFO - 2023-09-10 12:06:57 --> Email Class Initialized
DEBUG - 2023-09-10 12:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:06:57 --> Controller Class Initialized
INFO - 2023-09-10 12:06:57 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:06:57 --> Model "Home_model" initialized
INFO - 2023-09-10 12:06:57 --> Helper loaded: download_helper
INFO - 2023-09-10 12:06:57 --> Helper loaded: form_helper
INFO - 2023-09-10 12:06:57 --> Form Validation Class Initialized
INFO - 2023-09-10 12:06:57 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:06:57 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:06:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:06:57 --> Final output sent to browser
DEBUG - 2023-09-10 12:06:57 --> Total execution time: 0.9090
INFO - 2023-09-10 12:06:58 --> Config Class Initialized
INFO - 2023-09-10 12:06:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:06:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:06:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:06:58 --> URI Class Initialized
INFO - 2023-09-10 12:06:58 --> Router Class Initialized
INFO - 2023-09-10 12:06:58 --> Output Class Initialized
INFO - 2023-09-10 12:06:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:06:58 --> Input Class Initialized
INFO - 2023-09-10 12:06:58 --> Language Class Initialized
ERROR - 2023-09-10 12:06:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:08:32 --> Config Class Initialized
INFO - 2023-09-10 12:08:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:08:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:08:32 --> Utf8 Class Initialized
INFO - 2023-09-10 12:08:32 --> URI Class Initialized
DEBUG - 2023-09-10 12:08:32 --> No URI present. Default controller set.
INFO - 2023-09-10 12:08:32 --> Router Class Initialized
INFO - 2023-09-10 12:08:32 --> Output Class Initialized
INFO - 2023-09-10 12:08:32 --> Security Class Initialized
DEBUG - 2023-09-10 12:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:08:32 --> Input Class Initialized
INFO - 2023-09-10 12:08:32 --> Language Class Initialized
INFO - 2023-09-10 12:08:32 --> Loader Class Initialized
INFO - 2023-09-10 12:08:32 --> Helper loaded: url_helper
INFO - 2023-09-10 12:08:32 --> Helper loaded: file_helper
INFO - 2023-09-10 12:08:32 --> Database Driver Class Initialized
INFO - 2023-09-10 12:08:32 --> Email Class Initialized
DEBUG - 2023-09-10 12:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:08:32 --> Controller Class Initialized
INFO - 2023-09-10 12:08:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:08:33 --> Model "Home_model" initialized
INFO - 2023-09-10 12:08:33 --> Helper loaded: download_helper
INFO - 2023-09-10 12:08:33 --> Helper loaded: form_helper
INFO - 2023-09-10 12:08:33 --> Form Validation Class Initialized
INFO - 2023-09-10 12:08:33 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:08:33 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:08:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:08:33 --> Final output sent to browser
DEBUG - 2023-09-10 12:08:33 --> Total execution time: 0.9507
INFO - 2023-09-10 12:08:35 --> Config Class Initialized
INFO - 2023-09-10 12:08:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:08:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:08:35 --> Utf8 Class Initialized
INFO - 2023-09-10 12:08:36 --> URI Class Initialized
INFO - 2023-09-10 12:08:36 --> Router Class Initialized
INFO - 2023-09-10 12:08:36 --> Output Class Initialized
INFO - 2023-09-10 12:08:36 --> Security Class Initialized
DEBUG - 2023-09-10 12:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:08:36 --> Input Class Initialized
INFO - 2023-09-10 12:08:36 --> Language Class Initialized
ERROR - 2023-09-10 12:08:36 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:09:03 --> Config Class Initialized
INFO - 2023-09-10 12:09:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:09:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:09:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:09:03 --> URI Class Initialized
DEBUG - 2023-09-10 12:09:03 --> No URI present. Default controller set.
INFO - 2023-09-10 12:09:03 --> Router Class Initialized
INFO - 2023-09-10 12:09:03 --> Output Class Initialized
INFO - 2023-09-10 12:09:04 --> Security Class Initialized
DEBUG - 2023-09-10 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:09:04 --> Input Class Initialized
INFO - 2023-09-10 12:09:04 --> Language Class Initialized
INFO - 2023-09-10 12:09:04 --> Loader Class Initialized
INFO - 2023-09-10 12:09:04 --> Helper loaded: url_helper
INFO - 2023-09-10 12:09:04 --> Helper loaded: file_helper
INFO - 2023-09-10 12:09:04 --> Database Driver Class Initialized
INFO - 2023-09-10 12:09:04 --> Email Class Initialized
DEBUG - 2023-09-10 12:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:09:04 --> Controller Class Initialized
INFO - 2023-09-10 12:09:04 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:09:04 --> Model "Home_model" initialized
INFO - 2023-09-10 12:09:04 --> Helper loaded: download_helper
INFO - 2023-09-10 12:09:04 --> Helper loaded: form_helper
INFO - 2023-09-10 12:09:04 --> Form Validation Class Initialized
INFO - 2023-09-10 12:09:04 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:09:04 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:09:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:09:05 --> Final output sent to browser
DEBUG - 2023-09-10 12:09:05 --> Total execution time: 1.7545
INFO - 2023-09-10 12:09:06 --> Config Class Initialized
INFO - 2023-09-10 12:09:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:09:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:09:06 --> Utf8 Class Initialized
INFO - 2023-09-10 12:09:06 --> URI Class Initialized
INFO - 2023-09-10 12:09:06 --> Router Class Initialized
INFO - 2023-09-10 12:09:06 --> Output Class Initialized
INFO - 2023-09-10 12:09:06 --> Security Class Initialized
DEBUG - 2023-09-10 12:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:09:07 --> Input Class Initialized
INFO - 2023-09-10 12:09:07 --> Language Class Initialized
ERROR - 2023-09-10 12:09:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:11:03 --> Config Class Initialized
INFO - 2023-09-10 12:11:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:11:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:11:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:11:03 --> URI Class Initialized
DEBUG - 2023-09-10 12:11:03 --> No URI present. Default controller set.
INFO - 2023-09-10 12:11:03 --> Router Class Initialized
INFO - 2023-09-10 12:11:04 --> Output Class Initialized
INFO - 2023-09-10 12:11:04 --> Security Class Initialized
DEBUG - 2023-09-10 12:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:11:04 --> Input Class Initialized
INFO - 2023-09-10 12:11:04 --> Language Class Initialized
INFO - 2023-09-10 12:11:04 --> Loader Class Initialized
INFO - 2023-09-10 12:11:04 --> Helper loaded: url_helper
INFO - 2023-09-10 12:11:04 --> Helper loaded: file_helper
INFO - 2023-09-10 12:11:04 --> Database Driver Class Initialized
INFO - 2023-09-10 12:11:04 --> Email Class Initialized
DEBUG - 2023-09-10 12:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:11:04 --> Controller Class Initialized
INFO - 2023-09-10 12:11:04 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:11:04 --> Model "Home_model" initialized
INFO - 2023-09-10 12:11:04 --> Helper loaded: download_helper
INFO - 2023-09-10 12:11:04 --> Helper loaded: form_helper
INFO - 2023-09-10 12:11:04 --> Form Validation Class Initialized
INFO - 2023-09-10 12:11:04 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:11:04 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:11:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:11:04 --> Final output sent to browser
DEBUG - 2023-09-10 12:11:04 --> Total execution time: 0.6411
INFO - 2023-09-10 12:11:06 --> Config Class Initialized
INFO - 2023-09-10 12:11:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:11:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:11:07 --> Utf8 Class Initialized
INFO - 2023-09-10 12:11:07 --> URI Class Initialized
INFO - 2023-09-10 12:11:07 --> Router Class Initialized
INFO - 2023-09-10 12:11:07 --> Output Class Initialized
INFO - 2023-09-10 12:11:07 --> Security Class Initialized
DEBUG - 2023-09-10 12:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:11:07 --> Input Class Initialized
INFO - 2023-09-10 12:11:07 --> Language Class Initialized
ERROR - 2023-09-10 12:11:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:11:31 --> Config Class Initialized
INFO - 2023-09-10 12:11:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:11:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:11:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:11:31 --> URI Class Initialized
DEBUG - 2023-09-10 12:11:31 --> No URI present. Default controller set.
INFO - 2023-09-10 12:11:31 --> Router Class Initialized
INFO - 2023-09-10 12:11:31 --> Output Class Initialized
INFO - 2023-09-10 12:11:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:11:31 --> Input Class Initialized
INFO - 2023-09-10 12:11:31 --> Language Class Initialized
INFO - 2023-09-10 12:11:31 --> Loader Class Initialized
INFO - 2023-09-10 12:11:32 --> Helper loaded: url_helper
INFO - 2023-09-10 12:11:32 --> Helper loaded: file_helper
INFO - 2023-09-10 12:11:32 --> Database Driver Class Initialized
INFO - 2023-09-10 12:11:32 --> Email Class Initialized
DEBUG - 2023-09-10 12:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:11:32 --> Controller Class Initialized
INFO - 2023-09-10 12:11:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:11:32 --> Model "Home_model" initialized
INFO - 2023-09-10 12:11:32 --> Helper loaded: download_helper
INFO - 2023-09-10 12:11:32 --> Helper loaded: form_helper
INFO - 2023-09-10 12:11:32 --> Form Validation Class Initialized
INFO - 2023-09-10 12:11:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:11:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:11:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:11:32 --> Final output sent to browser
DEBUG - 2023-09-10 12:11:32 --> Total execution time: 1.2464
INFO - 2023-09-10 12:11:34 --> Config Class Initialized
INFO - 2023-09-10 12:11:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:11:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:11:35 --> Utf8 Class Initialized
INFO - 2023-09-10 12:11:35 --> URI Class Initialized
INFO - 2023-09-10 12:11:35 --> Router Class Initialized
INFO - 2023-09-10 12:11:35 --> Output Class Initialized
INFO - 2023-09-10 12:11:35 --> Security Class Initialized
DEBUG - 2023-09-10 12:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:11:35 --> Input Class Initialized
INFO - 2023-09-10 12:11:35 --> Language Class Initialized
ERROR - 2023-09-10 12:11:35 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:12:52 --> Config Class Initialized
INFO - 2023-09-10 12:12:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:52 --> URI Class Initialized
INFO - 2023-09-10 12:12:52 --> Router Class Initialized
INFO - 2023-09-10 12:12:52 --> Output Class Initialized
INFO - 2023-09-10 12:12:52 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:53 --> Input Class Initialized
INFO - 2023-09-10 12:12:53 --> Language Class Initialized
ERROR - 2023-09-10 12:12:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:53 --> Config Class Initialized
INFO - 2023-09-10 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:53 --> URI Class Initialized
INFO - 2023-09-10 12:12:53 --> Router Class Initialized
INFO - 2023-09-10 12:12:53 --> Output Class Initialized
INFO - 2023-09-10 12:12:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:53 --> Input Class Initialized
INFO - 2023-09-10 12:12:53 --> Language Class Initialized
ERROR - 2023-09-10 12:12:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:53 --> Config Class Initialized
INFO - 2023-09-10 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:53 --> URI Class Initialized
INFO - 2023-09-10 12:12:54 --> Router Class Initialized
INFO - 2023-09-10 12:12:54 --> Output Class Initialized
INFO - 2023-09-10 12:12:54 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:54 --> Input Class Initialized
INFO - 2023-09-10 12:12:54 --> Language Class Initialized
ERROR - 2023-09-10 12:12:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:55 --> Config Class Initialized
INFO - 2023-09-10 12:12:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:56 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:56 --> URI Class Initialized
INFO - 2023-09-10 12:12:56 --> Router Class Initialized
INFO - 2023-09-10 12:12:56 --> Output Class Initialized
INFO - 2023-09-10 12:12:56 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:56 --> Input Class Initialized
INFO - 2023-09-10 12:12:56 --> Language Class Initialized
ERROR - 2023-09-10 12:12:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:56 --> Config Class Initialized
INFO - 2023-09-10 12:12:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:56 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:56 --> URI Class Initialized
INFO - 2023-09-10 12:12:56 --> Router Class Initialized
INFO - 2023-09-10 12:12:56 --> Output Class Initialized
INFO - 2023-09-10 12:12:56 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:56 --> Input Class Initialized
INFO - 2023-09-10 12:12:56 --> Language Class Initialized
ERROR - 2023-09-10 12:12:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:56 --> Config Class Initialized
INFO - 2023-09-10 12:12:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:57 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:57 --> URI Class Initialized
INFO - 2023-09-10 12:12:57 --> Router Class Initialized
INFO - 2023-09-10 12:12:57 --> Output Class Initialized
INFO - 2023-09-10 12:12:57 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:57 --> Input Class Initialized
INFO - 2023-09-10 12:12:57 --> Language Class Initialized
ERROR - 2023-09-10 12:12:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:12:57 --> Config Class Initialized
INFO - 2023-09-10 12:12:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:12:57 --> Utf8 Class Initialized
INFO - 2023-09-10 12:12:57 --> URI Class Initialized
INFO - 2023-09-10 12:12:57 --> Router Class Initialized
INFO - 2023-09-10 12:12:57 --> Output Class Initialized
INFO - 2023-09-10 12:12:57 --> Security Class Initialized
DEBUG - 2023-09-10 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:12:57 --> Input Class Initialized
INFO - 2023-09-10 12:12:57 --> Language Class Initialized
ERROR - 2023-09-10 12:12:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:23:05 --> Config Class Initialized
INFO - 2023-09-10 12:23:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:23:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:23:05 --> Utf8 Class Initialized
INFO - 2023-09-10 12:23:05 --> URI Class Initialized
DEBUG - 2023-09-10 12:23:05 --> No URI present. Default controller set.
INFO - 2023-09-10 12:23:05 --> Router Class Initialized
INFO - 2023-09-10 12:23:05 --> Output Class Initialized
INFO - 2023-09-10 12:23:05 --> Security Class Initialized
DEBUG - 2023-09-10 12:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:23:05 --> Input Class Initialized
INFO - 2023-09-10 12:23:05 --> Language Class Initialized
INFO - 2023-09-10 12:23:05 --> Loader Class Initialized
INFO - 2023-09-10 12:23:05 --> Helper loaded: url_helper
INFO - 2023-09-10 12:23:05 --> Helper loaded: file_helper
INFO - 2023-09-10 12:23:05 --> Database Driver Class Initialized
INFO - 2023-09-10 12:23:05 --> Email Class Initialized
DEBUG - 2023-09-10 12:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:23:06 --> Controller Class Initialized
INFO - 2023-09-10 12:23:06 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:23:06 --> Model "Home_model" initialized
INFO - 2023-09-10 12:23:06 --> Helper loaded: download_helper
INFO - 2023-09-10 12:23:06 --> Helper loaded: form_helper
INFO - 2023-09-10 12:23:06 --> Form Validation Class Initialized
INFO - 2023-09-10 12:23:06 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:23:06 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:23:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:23:06 --> Final output sent to browser
DEBUG - 2023-09-10 12:23:06 --> Total execution time: 0.5693
INFO - 2023-09-10 12:23:07 --> Config Class Initialized
INFO - 2023-09-10 12:23:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:23:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:23:07 --> Utf8 Class Initialized
INFO - 2023-09-10 12:23:07 --> URI Class Initialized
INFO - 2023-09-10 12:23:07 --> Router Class Initialized
INFO - 2023-09-10 12:23:07 --> Output Class Initialized
INFO - 2023-09-10 12:23:07 --> Security Class Initialized
DEBUG - 2023-09-10 12:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:23:07 --> Input Class Initialized
INFO - 2023-09-10 12:23:07 --> Language Class Initialized
ERROR - 2023-09-10 12:23:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:24:50 --> Config Class Initialized
INFO - 2023-09-10 12:24:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:24:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:51 --> URI Class Initialized
INFO - 2023-09-10 12:24:51 --> Router Class Initialized
INFO - 2023-09-10 12:24:51 --> Output Class Initialized
INFO - 2023-09-10 12:24:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:51 --> Input Class Initialized
INFO - 2023-09-10 12:24:51 --> Language Class Initialized
ERROR - 2023-09-10 12:24:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
DEBUG - 2023-09-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:24:52 --> URI Class Initialized
INFO - 2023-09-10 12:24:52 --> Router Class Initialized
DEBUG - 2023-09-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:52 --> Output Class Initialized
INFO - 2023-09-10 12:24:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:52 --> Security Class Initialized
INFO - 2023-09-10 12:24:52 --> URI Class Initialized
DEBUG - 2023-09-10 12:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:52 --> Router Class Initialized
INFO - 2023-09-10 12:24:52 --> Input Class Initialized
INFO - 2023-09-10 12:24:52 --> Output Class Initialized
INFO - 2023-09-10 12:24:52 --> Language Class Initialized
INFO - 2023-09-10 12:24:52 --> Security Class Initialized
ERROR - 2023-09-10 12:24:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 12:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:52 --> Input Class Initialized
INFO - 2023-09-10 12:24:52 --> Language Class Initialized
ERROR - 2023-09-10 12:24:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
INFO - 2023-09-10 12:24:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:52 --> Config Class Initialized
DEBUG - 2023-09-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:52 --> URI Class Initialized
INFO - 2023-09-10 12:24:52 --> Router Class Initialized
INFO - 2023-09-10 12:24:52 --> Output Class Initialized
INFO - 2023-09-10 12:24:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:24:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:52 --> URI Class Initialized
INFO - 2023-09-10 12:24:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:24:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:24:53 --> URI Class Initialized
INFO - 2023-09-10 12:24:53 --> Router Class Initialized
INFO - 2023-09-10 12:24:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:24:53 --> Router Class Initialized
INFO - 2023-09-10 12:24:53 --> Output Class Initialized
DEBUG - 2023-09-10 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:53 --> URI Class Initialized
INFO - 2023-09-10 12:24:53 --> Output Class Initialized
INFO - 2023-09-10 12:24:53 --> Router Class Initialized
INFO - 2023-09-10 12:24:53 --> Security Class Initialized
INFO - 2023-09-10 12:24:53 --> Input Class Initialized
INFO - 2023-09-10 12:24:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:53 --> Output Class Initialized
INFO - 2023-09-10 12:24:53 --> Language Class Initialized
INFO - 2023-09-10 12:24:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:24:53 --> Input Class Initialized
INFO - 2023-09-10 12:24:53 --> Language Class Initialized
ERROR - 2023-09-10 12:24:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:24:53 --> Input Class Initialized
INFO - 2023-09-10 12:24:53 --> Language Class Initialized
INFO - 2023-09-10 12:24:53 --> Input Class Initialized
INFO - 2023-09-10 12:24:53 --> Language Class Initialized
ERROR - 2023-09-10 12:24:53 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 12:24:53 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 12:24:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:39 --> Config Class Initialized
INFO - 2023-09-10 12:26:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:26:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:39 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:39 --> URI Class Initialized
DEBUG - 2023-09-10 12:26:39 --> No URI present. Default controller set.
INFO - 2023-09-10 12:26:39 --> Router Class Initialized
INFO - 2023-09-10 12:26:39 --> Output Class Initialized
INFO - 2023-09-10 12:26:39 --> Security Class Initialized
DEBUG - 2023-09-10 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:39 --> Input Class Initialized
INFO - 2023-09-10 12:26:39 --> Language Class Initialized
INFO - 2023-09-10 12:26:39 --> Loader Class Initialized
INFO - 2023-09-10 12:26:39 --> Helper loaded: url_helper
INFO - 2023-09-10 12:26:39 --> Helper loaded: file_helper
INFO - 2023-09-10 12:26:39 --> Database Driver Class Initialized
INFO - 2023-09-10 12:26:39 --> Email Class Initialized
DEBUG - 2023-09-10 12:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:26:39 --> Controller Class Initialized
INFO - 2023-09-10 12:26:39 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:26:39 --> Model "Home_model" initialized
INFO - 2023-09-10 12:26:39 --> Helper loaded: download_helper
INFO - 2023-09-10 12:26:39 --> Helper loaded: form_helper
INFO - 2023-09-10 12:26:39 --> Form Validation Class Initialized
INFO - 2023-09-10 12:26:39 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:26:39 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:26:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:26:40 --> Final output sent to browser
DEBUG - 2023-09-10 12:26:40 --> Total execution time: 0.7562
INFO - 2023-09-10 12:26:44 --> Config Class Initialized
INFO - 2023-09-10 12:26:44 --> Hooks Class Initialized
INFO - 2023-09-10 12:26:45 --> Config Class Initialized
INFO - 2023-09-10 12:26:45 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:26:45 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:45 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:45 --> Config Class Initialized
INFO - 2023-09-10 12:26:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:26:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:46 --> URI Class Initialized
INFO - 2023-09-10 12:26:46 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:46 --> URI Class Initialized
DEBUG - 2023-09-10 12:26:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:46 --> Router Class Initialized
INFO - 2023-09-10 12:26:47 --> Output Class Initialized
INFO - 2023-09-10 12:26:47 --> Router Class Initialized
INFO - 2023-09-10 12:26:47 --> Security Class Initialized
INFO - 2023-09-10 12:26:47 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:48 --> URI Class Initialized
DEBUG - 2023-09-10 12:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:49 --> Output Class Initialized
INFO - 2023-09-10 12:26:49 --> Config Class Initialized
INFO - 2023-09-10 12:26:50 --> Router Class Initialized
INFO - 2023-09-10 12:26:50 --> Input Class Initialized
INFO - 2023-09-10 12:26:50 --> Config Class Initialized
INFO - 2023-09-10 12:26:50 --> Output Class Initialized
INFO - 2023-09-10 12:26:50 --> Security Class Initialized
DEBUG - 2023-09-10 12:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:50 --> Input Class Initialized
INFO - 2023-09-10 12:26:50 --> Language Class Initialized
ERROR - 2023-09-10 12:26:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:51 --> Config Class Initialized
INFO - 2023-09-10 12:26:51 --> Security Class Initialized
INFO - 2023-09-10 12:26:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:51 --> URI Class Initialized
INFO - 2023-09-10 12:26:51 --> Router Class Initialized
INFO - 2023-09-10 12:26:51 --> Output Class Initialized
INFO - 2023-09-10 12:26:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:51 --> Input Class Initialized
INFO - 2023-09-10 12:26:51 --> Language Class Initialized
ERROR - 2023-09-10 12:26:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:51 --> Config Class Initialized
INFO - 2023-09-10 12:26:51 --> Language Class Initialized
DEBUG - 2023-09-10 12:26:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:26:52 --> Input Class Initialized
INFO - 2023-09-10 12:26:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:26:52 --> Utf8 Class Initialized
ERROR - 2023-09-10 12:26:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:52 --> Config Class Initialized
DEBUG - 2023-09-10 12:26:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:52 --> Hooks Class Initialized
INFO - 2023-09-10 12:26:52 --> Language Class Initialized
INFO - 2023-09-10 12:26:53 --> URI Class Initialized
DEBUG - 2023-09-10 12:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 12:26:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:26:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:53 --> Utf8 Class Initialized
ERROR - 2023-09-10 12:26:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:53 --> URI Class Initialized
INFO - 2023-09-10 12:26:53 --> Router Class Initialized
INFO - 2023-09-10 12:26:53 --> Output Class Initialized
INFO - 2023-09-10 12:26:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:53 --> Input Class Initialized
INFO - 2023-09-10 12:26:53 --> Language Class Initialized
ERROR - 2023-09-10 12:26:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:26:53 --> URI Class Initialized
INFO - 2023-09-10 12:26:53 --> Router Class Initialized
INFO - 2023-09-10 12:26:54 --> Router Class Initialized
INFO - 2023-09-10 12:26:54 --> Output Class Initialized
INFO - 2023-09-10 12:26:54 --> URI Class Initialized
INFO - 2023-09-10 12:26:54 --> Security Class Initialized
INFO - 2023-09-10 12:26:54 --> Router Class Initialized
INFO - 2023-09-10 12:26:54 --> Output Class Initialized
INFO - 2023-09-10 12:26:54 --> Output Class Initialized
INFO - 2023-09-10 12:26:54 --> Security Class Initialized
INFO - 2023-09-10 12:26:54 --> Security Class Initialized
DEBUG - 2023-09-10 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:26:54 --> Input Class Initialized
INFO - 2023-09-10 12:26:54 --> Input Class Initialized
INFO - 2023-09-10 12:26:54 --> Language Class Initialized
INFO - 2023-09-10 12:26:54 --> Input Class Initialized
ERROR - 2023-09-10 12:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:26:54 --> Language Class Initialized
ERROR - 2023-09-10 12:26:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:26:54 --> Language Class Initialized
ERROR - 2023-09-10 12:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:20 --> Config Class Initialized
INFO - 2023-09-10 12:27:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:20 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:20 --> URI Class Initialized
DEBUG - 2023-09-10 12:27:20 --> No URI present. Default controller set.
INFO - 2023-09-10 12:27:20 --> Router Class Initialized
INFO - 2023-09-10 12:27:20 --> Output Class Initialized
INFO - 2023-09-10 12:27:20 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:20 --> Input Class Initialized
INFO - 2023-09-10 12:27:20 --> Language Class Initialized
INFO - 2023-09-10 12:27:20 --> Loader Class Initialized
INFO - 2023-09-10 12:27:20 --> Helper loaded: url_helper
INFO - 2023-09-10 12:27:20 --> Helper loaded: file_helper
INFO - 2023-09-10 12:27:20 --> Database Driver Class Initialized
INFO - 2023-09-10 12:27:20 --> Email Class Initialized
DEBUG - 2023-09-10 12:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:27:20 --> Controller Class Initialized
INFO - 2023-09-10 12:27:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:27:20 --> Model "Home_model" initialized
INFO - 2023-09-10 12:27:20 --> Helper loaded: download_helper
INFO - 2023-09-10 12:27:20 --> Helper loaded: form_helper
INFO - 2023-09-10 12:27:20 --> Form Validation Class Initialized
INFO - 2023-09-10 12:27:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:27:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:27:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:27:20 --> Final output sent to browser
DEBUG - 2023-09-10 12:27:20 --> Total execution time: 0.6758
INFO - 2023-09-10 12:27:23 --> Config Class Initialized
INFO - 2023-09-10 12:27:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:24 --> Config Class Initialized
INFO - 2023-09-10 12:27:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:24 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:24 --> URI Class Initialized
INFO - 2023-09-10 12:27:24 --> Router Class Initialized
INFO - 2023-09-10 12:27:24 --> Output Class Initialized
INFO - 2023-09-10 12:27:24 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:24 --> Input Class Initialized
INFO - 2023-09-10 12:27:24 --> Language Class Initialized
ERROR - 2023-09-10 12:27:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:24 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:25 --> URI Class Initialized
INFO - 2023-09-10 12:27:25 --> Router Class Initialized
INFO - 2023-09-10 12:27:25 --> Output Class Initialized
INFO - 2023-09-10 12:27:25 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:25 --> Input Class Initialized
INFO - 2023-09-10 12:27:25 --> Language Class Initialized
ERROR - 2023-09-10 12:27:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:25 --> Config Class Initialized
INFO - 2023-09-10 12:27:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:26 --> Config Class Initialized
INFO - 2023-09-10 12:27:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:26 --> URI Class Initialized
INFO - 2023-09-10 12:27:26 --> Router Class Initialized
INFO - 2023-09-10 12:27:26 --> Output Class Initialized
INFO - 2023-09-10 12:27:26 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:26 --> Input Class Initialized
INFO - 2023-09-10 12:27:26 --> Language Class Initialized
ERROR - 2023-09-10 12:27:26 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:27:26 --> Config Class Initialized
INFO - 2023-09-10 12:27:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:26 --> URI Class Initialized
INFO - 2023-09-10 12:27:26 --> Router Class Initialized
INFO - 2023-09-10 12:27:26 --> Output Class Initialized
INFO - 2023-09-10 12:27:26 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:26 --> Input Class Initialized
INFO - 2023-09-10 12:27:26 --> Language Class Initialized
ERROR - 2023-09-10 12:27:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:27 --> Config Class Initialized
INFO - 2023-09-10 12:27:27 --> URI Class Initialized
INFO - 2023-09-10 12:27:27 --> Config Class Initialized
INFO - 2023-09-10 12:27:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:27 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:27 --> URI Class Initialized
INFO - 2023-09-10 12:27:27 --> Router Class Initialized
INFO - 2023-09-10 12:27:27 --> Output Class Initialized
INFO - 2023-09-10 12:27:27 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:27 --> Input Class Initialized
INFO - 2023-09-10 12:27:27 --> Language Class Initialized
ERROR - 2023-09-10 12:27:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:27 --> Router Class Initialized
INFO - 2023-09-10 12:27:27 --> Hooks Class Initialized
INFO - 2023-09-10 12:27:28 --> Config Class Initialized
DEBUG - 2023-09-10 12:27:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:28 --> Output Class Initialized
INFO - 2023-09-10 12:27:28 --> Security Class Initialized
INFO - 2023-09-10 12:27:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:29 --> URI Class Initialized
DEBUG - 2023-09-10 12:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:27:30 --> Utf8 Class Initialized
INFO - 2023-09-10 12:27:30 --> Input Class Initialized
INFO - 2023-09-10 12:27:30 --> URI Class Initialized
INFO - 2023-09-10 12:27:30 --> Router Class Initialized
INFO - 2023-09-10 12:27:30 --> Router Class Initialized
INFO - 2023-09-10 12:27:30 --> Output Class Initialized
INFO - 2023-09-10 12:27:31 --> Language Class Initialized
INFO - 2023-09-10 12:27:31 --> Security Class Initialized
ERROR - 2023-09-10 12:27:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:31 --> Output Class Initialized
INFO - 2023-09-10 12:27:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:31 --> Input Class Initialized
DEBUG - 2023-09-10 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:27:31 --> Language Class Initialized
INFO - 2023-09-10 12:27:31 --> Input Class Initialized
ERROR - 2023-09-10 12:27:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:27:31 --> Language Class Initialized
ERROR - 2023-09-10 12:27:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:28:43 --> Config Class Initialized
INFO - 2023-09-10 12:28:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:43 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:43 --> URI Class Initialized
DEBUG - 2023-09-10 12:28:43 --> No URI present. Default controller set.
INFO - 2023-09-10 12:28:43 --> Router Class Initialized
INFO - 2023-09-10 12:28:43 --> Output Class Initialized
INFO - 2023-09-10 12:28:43 --> Security Class Initialized
DEBUG - 2023-09-10 12:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:43 --> Input Class Initialized
INFO - 2023-09-10 12:28:43 --> Language Class Initialized
INFO - 2023-09-10 12:28:43 --> Loader Class Initialized
INFO - 2023-09-10 12:28:44 --> Helper loaded: url_helper
INFO - 2023-09-10 12:28:44 --> Helper loaded: file_helper
INFO - 2023-09-10 12:28:44 --> Database Driver Class Initialized
INFO - 2023-09-10 12:28:44 --> Email Class Initialized
DEBUG - 2023-09-10 12:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:28:44 --> Controller Class Initialized
INFO - 2023-09-10 12:28:44 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:28:44 --> Model "Home_model" initialized
INFO - 2023-09-10 12:28:44 --> Helper loaded: download_helper
INFO - 2023-09-10 12:28:44 --> Helper loaded: form_helper
INFO - 2023-09-10 12:28:44 --> Form Validation Class Initialized
INFO - 2023-09-10 12:28:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:28:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:28:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:28:44 --> Final output sent to browser
DEBUG - 2023-09-10 12:28:44 --> Total execution time: 0.7435
INFO - 2023-09-10 12:28:46 --> Config Class Initialized
INFO - 2023-09-10 12:28:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:46 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:46 --> URI Class Initialized
INFO - 2023-09-10 12:28:46 --> Router Class Initialized
INFO - 2023-09-10 12:28:46 --> Output Class Initialized
INFO - 2023-09-10 12:28:46 --> Security Class Initialized
DEBUG - 2023-09-10 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:46 --> Input Class Initialized
INFO - 2023-09-10 12:28:46 --> Language Class Initialized
ERROR - 2023-09-10 12:28:46 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:28:47 --> Config Class Initialized
INFO - 2023-09-10 12:28:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:47 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:47 --> URI Class Initialized
INFO - 2023-09-10 12:28:47 --> Router Class Initialized
INFO - 2023-09-10 12:28:47 --> Output Class Initialized
INFO - 2023-09-10 12:28:47 --> Security Class Initialized
DEBUG - 2023-09-10 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:47 --> Input Class Initialized
INFO - 2023-09-10 12:28:47 --> Language Class Initialized
ERROR - 2023-09-10 12:28:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:28:47 --> Config Class Initialized
INFO - 2023-09-10 12:28:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:47 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:47 --> URI Class Initialized
INFO - 2023-09-10 12:28:47 --> Router Class Initialized
INFO - 2023-09-10 12:28:47 --> Output Class Initialized
INFO - 2023-09-10 12:28:48 --> Config Class Initialized
INFO - 2023-09-10 12:28:48 --> Config Class Initialized
INFO - 2023-09-10 12:28:48 --> Security Class Initialized
INFO - 2023-09-10 12:28:48 --> Hooks Class Initialized
INFO - 2023-09-10 12:28:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:49 --> Config Class Initialized
INFO - 2023-09-10 12:28:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:49 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:49 --> URI Class Initialized
INFO - 2023-09-10 12:28:49 --> Router Class Initialized
INFO - 2023-09-10 12:28:49 --> Output Class Initialized
INFO - 2023-09-10 12:28:49 --> Security Class Initialized
DEBUG - 2023-09-10 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:49 --> Input Class Initialized
INFO - 2023-09-10 12:28:49 --> Language Class Initialized
ERROR - 2023-09-10 12:28:49 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 12:28:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:49 --> Config Class Initialized
INFO - 2023-09-10 12:28:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:49 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:49 --> URI Class Initialized
INFO - 2023-09-10 12:28:49 --> Router Class Initialized
INFO - 2023-09-10 12:28:49 --> Output Class Initialized
INFO - 2023-09-10 12:28:49 --> Security Class Initialized
DEBUG - 2023-09-10 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:49 --> Input Class Initialized
INFO - 2023-09-10 12:28:49 --> Language Class Initialized
ERROR - 2023-09-10 12:28:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:28:49 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:49 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:50 --> Config Class Initialized
INFO - 2023-09-10 12:28:50 --> URI Class Initialized
INFO - 2023-09-10 12:28:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:28:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:28:50 --> URI Class Initialized
DEBUG - 2023-09-10 12:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:51 --> Router Class Initialized
INFO - 2023-09-10 12:28:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:28:51 --> Router Class Initialized
INFO - 2023-09-10 12:28:51 --> Output Class Initialized
INFO - 2023-09-10 12:28:51 --> Input Class Initialized
INFO - 2023-09-10 12:28:51 --> Security Class Initialized
INFO - 2023-09-10 12:28:51 --> URI Class Initialized
INFO - 2023-09-10 12:28:51 --> Output Class Initialized
DEBUG - 2023-09-10 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:28:51 --> Input Class Initialized
INFO - 2023-09-10 12:28:51 --> Language Class Initialized
ERROR - 2023-09-10 12:28:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:29:11 --> Config Class Initialized
INFO - 2023-09-10 12:29:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:29:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:29:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:29:11 --> URI Class Initialized
DEBUG - 2023-09-10 12:29:11 --> No URI present. Default controller set.
INFO - 2023-09-10 12:29:11 --> Router Class Initialized
INFO - 2023-09-10 12:29:11 --> Output Class Initialized
INFO - 2023-09-10 12:29:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:29:11 --> Input Class Initialized
INFO - 2023-09-10 12:29:11 --> Language Class Initialized
INFO - 2023-09-10 12:29:11 --> Loader Class Initialized
INFO - 2023-09-10 12:29:11 --> Helper loaded: url_helper
INFO - 2023-09-10 12:29:11 --> Helper loaded: file_helper
INFO - 2023-09-10 12:29:11 --> Database Driver Class Initialized
INFO - 2023-09-10 12:29:11 --> Email Class Initialized
DEBUG - 2023-09-10 12:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:29:11 --> Controller Class Initialized
INFO - 2023-09-10 12:29:11 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:29:11 --> Model "Home_model" initialized
INFO - 2023-09-10 12:29:11 --> Helper loaded: download_helper
INFO - 2023-09-10 12:29:11 --> Helper loaded: form_helper
INFO - 2023-09-10 12:29:11 --> Form Validation Class Initialized
INFO - 2023-09-10 12:29:11 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:29:11 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:29:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:29:11 --> Final output sent to browser
DEBUG - 2023-09-10 12:29:11 --> Total execution time: 0.5618
INFO - 2023-09-10 12:29:13 --> Config Class Initialized
INFO - 2023-09-10 12:29:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:29:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:29:15 --> Config Class Initialized
INFO - 2023-09-10 12:29:15 --> Utf8 Class Initialized
INFO - 2023-09-10 12:29:15 --> URI Class Initialized
INFO - 2023-09-10 12:29:15 --> Hooks Class Initialized
INFO - 2023-09-10 12:29:15 --> Config Class Initialized
INFO - 2023-09-10 12:29:15 --> Router Class Initialized
DEBUG - 2023-09-10 12:29:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:29:15 --> Output Class Initialized
INFO - 2023-09-10 12:29:15 --> Utf8 Class Initialized
INFO - 2023-09-10 12:29:15 --> Security Class Initialized
INFO - 2023-09-10 12:29:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:29:15 --> URI Class Initialized
DEBUG - 2023-09-10 12:29:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:29:15 --> Router Class Initialized
INFO - 2023-09-10 12:29:15 --> Utf8 Class Initialized
INFO - 2023-09-10 12:29:15 --> Input Class Initialized
INFO - 2023-09-10 12:29:16 --> Language Class Initialized
INFO - 2023-09-10 12:29:16 --> Output Class Initialized
INFO - 2023-09-10 12:29:16 --> URI Class Initialized
INFO - 2023-09-10 12:29:16 --> Security Class Initialized
INFO - 2023-09-10 12:29:16 --> Router Class Initialized
ERROR - 2023-09-10 12:29:16 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:29:16 --> Output Class Initialized
INFO - 2023-09-10 12:29:16 --> Security Class Initialized
DEBUG - 2023-09-10 12:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:29:16 --> Input Class Initialized
INFO - 2023-09-10 12:29:16 --> Language Class Initialized
INFO - 2023-09-10 12:29:16 --> Input Class Initialized
ERROR - 2023-09-10 12:29:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:29:16 --> Language Class Initialized
ERROR - 2023-09-10 12:29:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:33:16 --> Config Class Initialized
INFO - 2023-09-10 12:33:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:33:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:33:16 --> Utf8 Class Initialized
INFO - 2023-09-10 12:33:16 --> URI Class Initialized
DEBUG - 2023-09-10 12:33:16 --> No URI present. Default controller set.
INFO - 2023-09-10 12:33:16 --> Router Class Initialized
INFO - 2023-09-10 12:33:16 --> Output Class Initialized
INFO - 2023-09-10 12:33:16 --> Security Class Initialized
DEBUG - 2023-09-10 12:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:33:16 --> Input Class Initialized
INFO - 2023-09-10 12:33:16 --> Language Class Initialized
INFO - 2023-09-10 12:33:16 --> Loader Class Initialized
INFO - 2023-09-10 12:33:16 --> Helper loaded: url_helper
INFO - 2023-09-10 12:33:16 --> Helper loaded: file_helper
INFO - 2023-09-10 12:33:16 --> Database Driver Class Initialized
INFO - 2023-09-10 12:33:16 --> Email Class Initialized
DEBUG - 2023-09-10 12:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:33:16 --> Controller Class Initialized
INFO - 2023-09-10 12:33:16 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:33:16 --> Model "Home_model" initialized
INFO - 2023-09-10 12:33:16 --> Helper loaded: download_helper
INFO - 2023-09-10 12:33:16 --> Helper loaded: form_helper
INFO - 2023-09-10 12:33:16 --> Form Validation Class Initialized
INFO - 2023-09-10 12:33:17 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:33:17 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:33:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:33:17 --> Final output sent to browser
DEBUG - 2023-09-10 12:33:17 --> Total execution time: 0.8326
INFO - 2023-09-10 12:33:18 --> Config Class Initialized
INFO - 2023-09-10 12:33:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:33:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:33:18 --> Utf8 Class Initialized
INFO - 2023-09-10 12:33:18 --> URI Class Initialized
INFO - 2023-09-10 12:33:18 --> Router Class Initialized
INFO - 2023-09-10 12:33:18 --> Output Class Initialized
INFO - 2023-09-10 12:33:18 --> Security Class Initialized
DEBUG - 2023-09-10 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:33:18 --> Input Class Initialized
INFO - 2023-09-10 12:33:18 --> Language Class Initialized
ERROR - 2023-09-10 12:33:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:36:58 --> Config Class Initialized
INFO - 2023-09-10 12:36:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:36:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:36:59 --> Utf8 Class Initialized
INFO - 2023-09-10 12:36:59 --> URI Class Initialized
DEBUG - 2023-09-10 12:36:59 --> No URI present. Default controller set.
INFO - 2023-09-10 12:36:59 --> Router Class Initialized
INFO - 2023-09-10 12:36:59 --> Output Class Initialized
INFO - 2023-09-10 12:36:59 --> Security Class Initialized
DEBUG - 2023-09-10 12:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:36:59 --> Input Class Initialized
INFO - 2023-09-10 12:36:59 --> Language Class Initialized
INFO - 2023-09-10 12:36:59 --> Loader Class Initialized
INFO - 2023-09-10 12:36:59 --> Helper loaded: url_helper
INFO - 2023-09-10 12:36:59 --> Helper loaded: file_helper
INFO - 2023-09-10 12:36:59 --> Database Driver Class Initialized
INFO - 2023-09-10 12:36:59 --> Email Class Initialized
DEBUG - 2023-09-10 12:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:36:59 --> Controller Class Initialized
INFO - 2023-09-10 12:36:59 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:36:59 --> Model "Home_model" initialized
INFO - 2023-09-10 12:36:59 --> Helper loaded: download_helper
INFO - 2023-09-10 12:36:59 --> Helper loaded: form_helper
INFO - 2023-09-10 12:36:59 --> Form Validation Class Initialized
INFO - 2023-09-10 12:36:59 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:36:59 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:36:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:36:59 --> Final output sent to browser
DEBUG - 2023-09-10 12:36:59 --> Total execution time: 0.8622
INFO - 2023-09-10 12:37:02 --> Config Class Initialized
INFO - 2023-09-10 12:37:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:02 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:02 --> URI Class Initialized
INFO - 2023-09-10 12:37:02 --> Router Class Initialized
INFO - 2023-09-10 12:37:02 --> Output Class Initialized
INFO - 2023-09-10 12:37:02 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:02 --> Input Class Initialized
INFO - 2023-09-10 12:37:02 --> Language Class Initialized
ERROR - 2023-09-10 12:37:02 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:37:23 --> Config Class Initialized
INFO - 2023-09-10 12:37:23 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:25 --> Config Class Initialized
DEBUG - 2023-09-10 12:37:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:25 --> Config Class Initialized
INFO - 2023-09-10 12:37:25 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:25 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:25 --> URI Class Initialized
INFO - 2023-09-10 12:37:25 --> Router Class Initialized
INFO - 2023-09-10 12:37:25 --> Output Class Initialized
INFO - 2023-09-10 12:37:25 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:25 --> Input Class Initialized
INFO - 2023-09-10 12:37:25 --> Language Class Initialized
ERROR - 2023-09-10 12:37:25 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 12:37:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:25 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:26 --> Config Class Initialized
INFO - 2023-09-10 12:37:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:26 --> URI Class Initialized
INFO - 2023-09-10 12:37:26 --> Router Class Initialized
INFO - 2023-09-10 12:37:26 --> Output Class Initialized
INFO - 2023-09-10 12:37:26 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:26 --> Input Class Initialized
INFO - 2023-09-10 12:37:26 --> Language Class Initialized
ERROR - 2023-09-10 12:37:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:26 --> URI Class Initialized
INFO - 2023-09-10 12:37:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:27 --> Router Class Initialized
INFO - 2023-09-10 12:37:27 --> URI Class Initialized
INFO - 2023-09-10 12:37:27 --> Output Class Initialized
INFO - 2023-09-10 12:37:27 --> Config Class Initialized
INFO - 2023-09-10 12:37:28 --> Config Class Initialized
INFO - 2023-09-10 12:37:28 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:28 --> Config Class Initialized
DEBUG - 2023-09-10 12:37:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:28 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:28 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:28 --> URI Class Initialized
DEBUG - 2023-09-10 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 12:37:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:28 --> URI Class Initialized
INFO - 2023-09-10 12:37:28 --> Router Class Initialized
INFO - 2023-09-10 12:37:28 --> URI Class Initialized
INFO - 2023-09-10 12:37:28 --> Output Class Initialized
INFO - 2023-09-10 12:37:28 --> Router Class Initialized
INFO - 2023-09-10 12:37:28 --> Router Class Initialized
INFO - 2023-09-10 12:37:28 --> Security Class Initialized
INFO - 2023-09-10 12:37:28 --> Output Class Initialized
DEBUG - 2023-09-10 12:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:28 --> Security Class Initialized
INFO - 2023-09-10 12:37:28 --> Input Class Initialized
INFO - 2023-09-10 12:37:28 --> Output Class Initialized
INFO - 2023-09-10 12:37:28 --> Language Class Initialized
ERROR - 2023-09-10 12:37:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:28 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:28 --> Input Class Initialized
INFO - 2023-09-10 12:37:28 --> Language Class Initialized
INFO - 2023-09-10 12:37:28 --> Input Class Initialized
ERROR - 2023-09-10 12:37:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:28 --> Language Class Initialized
ERROR - 2023-09-10 12:37:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:31 --> Config Class Initialized
INFO - 2023-09-10 12:37:33 --> Config Class Initialized
INFO - 2023-09-10 12:37:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:34 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:35 --> URI Class Initialized
INFO - 2023-09-10 12:37:35 --> Router Class Initialized
INFO - 2023-09-10 12:37:35 --> Output Class Initialized
INFO - 2023-09-10 12:37:35 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:35 --> Input Class Initialized
INFO - 2023-09-10 12:37:35 --> Language Class Initialized
ERROR - 2023-09-10 12:37:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:35 --> Config Class Initialized
INFO - 2023-09-10 12:37:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:35 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:35 --> URI Class Initialized
INFO - 2023-09-10 12:37:35 --> Router Class Initialized
INFO - 2023-09-10 12:37:35 --> Output Class Initialized
INFO - 2023-09-10 12:37:35 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:35 --> Input Class Initialized
INFO - 2023-09-10 12:37:35 --> Language Class Initialized
ERROR - 2023-09-10 12:37:35 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:37:35 --> Config Class Initialized
INFO - 2023-09-10 12:37:35 --> Config Class Initialized
INFO - 2023-09-10 12:37:35 --> Config Class Initialized
INFO - 2023-09-10 12:37:36 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:36 --> Config Class Initialized
INFO - 2023-09-10 12:37:36 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:36 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:36 --> URI Class Initialized
INFO - 2023-09-10 12:37:36 --> Router Class Initialized
INFO - 2023-09-10 12:37:36 --> Output Class Initialized
INFO - 2023-09-10 12:37:36 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:36 --> Input Class Initialized
INFO - 2023-09-10 12:37:36 --> Language Class Initialized
ERROR - 2023-09-10 12:37:36 --> 404 Page Not Found: Service-detail/assets
DEBUG - 2023-09-10 12:37:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:36 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:36 --> URI Class Initialized
INFO - 2023-09-10 12:37:36 --> Config Class Initialized
INFO - 2023-09-10 12:37:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:37 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:37 --> Router Class Initialized
INFO - 2023-09-10 12:37:37 --> Config Class Initialized
INFO - 2023-09-10 12:37:37 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:37 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:37 --> Output Class Initialized
DEBUG - 2023-09-10 12:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:37 --> URI Class Initialized
DEBUG - 2023-09-10 12:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:37 --> Config Class Initialized
INFO - 2023-09-10 12:37:37 --> Security Class Initialized
INFO - 2023-09-10 12:37:37 --> URI Class Initialized
INFO - 2023-09-10 12:37:37 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:37 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:37 --> Router Class Initialized
DEBUG - 2023-09-10 12:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:37 --> Input Class Initialized
INFO - 2023-09-10 12:37:37 --> Language Class Initialized
ERROR - 2023-09-10 12:37:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:37 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:37 --> URI Class Initialized
INFO - 2023-09-10 12:37:37 --> Router Class Initialized
INFO - 2023-09-10 12:37:37 --> URI Class Initialized
INFO - 2023-09-10 12:37:37 --> Output Class Initialized
INFO - 2023-09-10 12:37:37 --> Security Class Initialized
INFO - 2023-09-10 12:37:37 --> Output Class Initialized
INFO - 2023-09-10 12:37:37 --> Router Class Initialized
DEBUG - 2023-09-10 12:37:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 12:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:37 --> Security Class Initialized
INFO - 2023-09-10 12:37:37 --> Router Class Initialized
INFO - 2023-09-10 12:37:37 --> Config Class Initialized
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
INFO - 2023-09-10 12:37:38 --> Utf8 Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
INFO - 2023-09-10 12:37:38 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
INFO - 2023-09-10 12:37:38 --> URI Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 12:37:38 --> UTF-8 Support Enabled
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:37:38 --> Router Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> URI Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
INFO - 2023-09-10 12:37:38 --> Config Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:38 --> Router Class Initialized
INFO - 2023-09-10 12:37:38 --> Config Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:38 --> Hooks Class Initialized
INFO - 2023-09-10 12:37:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:37:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 12:37:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:37:38 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Utf8 Class Initialized
INFO - 2023-09-10 12:37:38 --> URI Class Initialized
INFO - 2023-09-10 12:37:38 --> URI Class Initialized
INFO - 2023-09-10 12:37:38 --> Router Class Initialized
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:37:38 --> Router Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:37:38 --> Output Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:38 --> Security Class Initialized
DEBUG - 2023-09-10 12:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Input Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
INFO - 2023-09-10 12:37:38 --> Language Class Initialized
ERROR - 2023-09-10 12:37:38 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 12:37:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:38:04 --> Config Class Initialized
INFO - 2023-09-10 12:38:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:38:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:38:04 --> Utf8 Class Initialized
INFO - 2023-09-10 12:38:04 --> URI Class Initialized
INFO - 2023-09-10 12:38:04 --> Router Class Initialized
INFO - 2023-09-10 12:38:04 --> Output Class Initialized
INFO - 2023-09-10 12:38:05 --> Security Class Initialized
DEBUG - 2023-09-10 12:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:38:05 --> Input Class Initialized
INFO - 2023-09-10 12:38:05 --> Language Class Initialized
ERROR - 2023-09-10 12:38:05 --> 404 Page Not Found: admin/Social_media/apps
INFO - 2023-09-10 12:38:07 --> Config Class Initialized
INFO - 2023-09-10 12:38:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:38:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:38:07 --> Utf8 Class Initialized
INFO - 2023-09-10 12:38:07 --> URI Class Initialized
INFO - 2023-09-10 12:38:07 --> Router Class Initialized
INFO - 2023-09-10 12:38:07 --> Output Class Initialized
INFO - 2023-09-10 12:38:07 --> Security Class Initialized
DEBUG - 2023-09-10 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:38:07 --> Input Class Initialized
INFO - 2023-09-10 12:38:07 --> Language Class Initialized
INFO - 2023-09-10 12:38:07 --> Loader Class Initialized
INFO - 2023-09-10 12:38:08 --> Helper loaded: url_helper
INFO - 2023-09-10 12:38:08 --> Helper loaded: file_helper
INFO - 2023-09-10 12:38:08 --> Database Driver Class Initialized
INFO - 2023-09-10 12:38:08 --> Email Class Initialized
DEBUG - 2023-09-10 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:38:08 --> Controller Class Initialized
INFO - 2023-09-10 12:38:08 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:38:08 --> Helper loaded: form_helper
INFO - 2023-09-10 12:38:08 --> Form Validation Class Initialized
INFO - 2023-09-10 12:38:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-10 12:38:08 --> Final output sent to browser
DEBUG - 2023-09-10 12:38:08 --> Total execution time: 0.3625
INFO - 2023-09-10 12:38:09 --> Config Class Initialized
INFO - 2023-09-10 12:38:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:38:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:38:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:38:09 --> URI Class Initialized
INFO - 2023-09-10 12:38:10 --> Router Class Initialized
INFO - 2023-09-10 12:38:10 --> Output Class Initialized
INFO - 2023-09-10 12:38:10 --> Security Class Initialized
DEBUG - 2023-09-10 12:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:38:10 --> Input Class Initialized
INFO - 2023-09-10 12:38:10 --> Language Class Initialized
ERROR - 2023-09-10 12:38:10 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-10 12:38:12 --> Config Class Initialized
INFO - 2023-09-10 12:38:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:38:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:38:12 --> Utf8 Class Initialized
INFO - 2023-09-10 12:38:12 --> URI Class Initialized
INFO - 2023-09-10 12:38:12 --> Router Class Initialized
INFO - 2023-09-10 12:38:12 --> Output Class Initialized
INFO - 2023-09-10 12:38:12 --> Security Class Initialized
DEBUG - 2023-09-10 12:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:38:12 --> Input Class Initialized
INFO - 2023-09-10 12:38:12 --> Language Class Initialized
INFO - 2023-09-10 12:38:12 --> Loader Class Initialized
INFO - 2023-09-10 12:38:12 --> Helper loaded: url_helper
INFO - 2023-09-10 12:38:12 --> Helper loaded: file_helper
INFO - 2023-09-10 12:38:12 --> Database Driver Class Initialized
INFO - 2023-09-10 12:38:12 --> Email Class Initialized
DEBUG - 2023-09-10 12:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:38:12 --> Controller Class Initialized
INFO - 2023-09-10 12:38:12 --> Model "Gallery_model" initialized
INFO - 2023-09-10 12:38:12 --> Helper loaded: form_helper
INFO - 2023-09-10 12:38:12 --> Form Validation Class Initialized
INFO - 2023-09-10 12:38:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/gallery_list.php
INFO - 2023-09-10 12:38:13 --> Final output sent to browser
DEBUG - 2023-09-10 12:38:13 --> Total execution time: 0.7617
INFO - 2023-09-10 12:38:14 --> Config Class Initialized
INFO - 2023-09-10 12:38:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:38:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:38:14 --> Utf8 Class Initialized
INFO - 2023-09-10 12:38:14 --> URI Class Initialized
INFO - 2023-09-10 12:38:14 --> Router Class Initialized
INFO - 2023-09-10 12:38:14 --> Output Class Initialized
INFO - 2023-09-10 12:38:14 --> Security Class Initialized
DEBUG - 2023-09-10 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:38:14 --> Input Class Initialized
INFO - 2023-09-10 12:38:14 --> Language Class Initialized
ERROR - 2023-09-10 12:38:14 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-10 12:43:16 --> Config Class Initialized
INFO - 2023-09-10 12:43:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:16 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:16 --> URI Class Initialized
INFO - 2023-09-10 12:43:16 --> Router Class Initialized
INFO - 2023-09-10 12:43:16 --> Output Class Initialized
INFO - 2023-09-10 12:43:16 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:16 --> Input Class Initialized
INFO - 2023-09-10 12:43:16 --> Language Class Initialized
INFO - 2023-09-10 12:43:16 --> Loader Class Initialized
INFO - 2023-09-10 12:43:16 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:16 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:16 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:16 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:16 --> Controller Class Initialized
INFO - 2023-09-10 12:43:16 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:16 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:16 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:43:16 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:16 --> Total execution time: 0.1514
INFO - 2023-09-10 12:43:17 --> Config Class Initialized
INFO - 2023-09-10 12:43:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:17 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:17 --> URI Class Initialized
INFO - 2023-09-10 12:43:17 --> Router Class Initialized
INFO - 2023-09-10 12:43:17 --> Output Class Initialized
INFO - 2023-09-10 12:43:17 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:17 --> Input Class Initialized
INFO - 2023-09-10 12:43:17 --> Language Class Initialized
ERROR - 2023-09-10 12:43:17 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:18 --> Config Class Initialized
INFO - 2023-09-10 12:43:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:18 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:18 --> URI Class Initialized
INFO - 2023-09-10 12:43:18 --> Router Class Initialized
INFO - 2023-09-10 12:43:18 --> Output Class Initialized
INFO - 2023-09-10 12:43:18 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:18 --> Input Class Initialized
INFO - 2023-09-10 12:43:18 --> Language Class Initialized
ERROR - 2023-09-10 12:43:18 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:18 --> Config Class Initialized
INFO - 2023-09-10 12:43:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:19 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:19 --> URI Class Initialized
INFO - 2023-09-10 12:43:19 --> Router Class Initialized
INFO - 2023-09-10 12:43:19 --> Output Class Initialized
INFO - 2023-09-10 12:43:19 --> Config Class Initialized
INFO - 2023-09-10 12:43:19 --> Security Class Initialized
INFO - 2023-09-10 12:43:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:19 --> Config Class Initialized
DEBUG - 2023-09-10 12:43:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:19 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:19 --> URI Class Initialized
INFO - 2023-09-10 12:43:19 --> Router Class Initialized
INFO - 2023-09-10 12:43:19 --> Output Class Initialized
INFO - 2023-09-10 12:43:19 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:19 --> Input Class Initialized
INFO - 2023-09-10 12:43:19 --> Language Class Initialized
ERROR - 2023-09-10 12:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:19 --> Hooks Class Initialized
INFO - 2023-09-10 12:43:19 --> Config Class Initialized
INFO - 2023-09-10 12:43:19 --> Input Class Initialized
INFO - 2023-09-10 12:43:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 12:43:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:19 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:19 --> URI Class Initialized
INFO - 2023-09-10 12:43:19 --> Router Class Initialized
INFO - 2023-09-10 12:43:19 --> Output Class Initialized
INFO - 2023-09-10 12:43:19 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:19 --> Input Class Initialized
INFO - 2023-09-10 12:43:19 --> Language Class Initialized
ERROR - 2023-09-10 12:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:19 --> Language Class Initialized
INFO - 2023-09-10 12:43:19 --> Utf8 Class Initialized
ERROR - 2023-09-10 12:43:19 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:19 --> URI Class Initialized
INFO - 2023-09-10 12:43:19 --> Router Class Initialized
INFO - 2023-09-10 12:43:19 --> Output Class Initialized
INFO - 2023-09-10 12:43:20 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:20 --> Input Class Initialized
INFO - 2023-09-10 12:43:20 --> Language Class Initialized
ERROR - 2023-09-10 12:43:20 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:23 --> Config Class Initialized
INFO - 2023-09-10 12:43:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:23 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:23 --> URI Class Initialized
INFO - 2023-09-10 12:43:23 --> Router Class Initialized
INFO - 2023-09-10 12:43:23 --> Output Class Initialized
INFO - 2023-09-10 12:43:23 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:23 --> Input Class Initialized
INFO - 2023-09-10 12:43:23 --> Language Class Initialized
INFO - 2023-09-10 12:43:23 --> Loader Class Initialized
INFO - 2023-09-10 12:43:23 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:23 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:23 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:23 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:23 --> Controller Class Initialized
INFO - 2023-09-10 12:43:23 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:23 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:23 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:23 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:23 --> Total execution time: 0.2891
INFO - 2023-09-10 12:43:23 --> Config Class Initialized
INFO - 2023-09-10 12:43:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:23 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:23 --> URI Class Initialized
INFO - 2023-09-10 12:43:23 --> Router Class Initialized
INFO - 2023-09-10 12:43:23 --> Output Class Initialized
INFO - 2023-09-10 12:43:23 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:23 --> Input Class Initialized
INFO - 2023-09-10 12:43:23 --> Language Class Initialized
ERROR - 2023-09-10 12:43:23 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:24 --> Config Class Initialized
INFO - 2023-09-10 12:43:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:24 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:24 --> URI Class Initialized
INFO - 2023-09-10 12:43:24 --> Router Class Initialized
INFO - 2023-09-10 12:43:24 --> Output Class Initialized
INFO - 2023-09-10 12:43:24 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:24 --> Input Class Initialized
INFO - 2023-09-10 12:43:24 --> Language Class Initialized
ERROR - 2023-09-10 12:43:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:24 --> Config Class Initialized
INFO - 2023-09-10 12:43:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:24 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:24 --> URI Class Initialized
INFO - 2023-09-10 12:43:24 --> Router Class Initialized
INFO - 2023-09-10 12:43:24 --> Output Class Initialized
INFO - 2023-09-10 12:43:24 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:24 --> Input Class Initialized
INFO - 2023-09-10 12:43:24 --> Language Class Initialized
ERROR - 2023-09-10 12:43:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:24 --> Config Class Initialized
INFO - 2023-09-10 12:43:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:24 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:24 --> URI Class Initialized
INFO - 2023-09-10 12:43:24 --> Router Class Initialized
INFO - 2023-09-10 12:43:24 --> Output Class Initialized
INFO - 2023-09-10 12:43:24 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:24 --> Input Class Initialized
INFO - 2023-09-10 12:43:24 --> Language Class Initialized
INFO - 2023-09-10 12:43:24 --> Loader Class Initialized
INFO - 2023-09-10 12:43:24 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:24 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:24 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:24 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:24 --> Controller Class Initialized
INFO - 2023-09-10 12:43:24 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:24 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:24 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:43:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:43:24 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:24 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:24 --> Total execution time: 0.0618
INFO - 2023-09-10 12:43:30 --> Config Class Initialized
INFO - 2023-09-10 12:43:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:30 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:30 --> URI Class Initialized
INFO - 2023-09-10 12:43:30 --> Router Class Initialized
INFO - 2023-09-10 12:43:30 --> Output Class Initialized
INFO - 2023-09-10 12:43:30 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:30 --> Input Class Initialized
INFO - 2023-09-10 12:43:30 --> Language Class Initialized
INFO - 2023-09-10 12:43:30 --> Loader Class Initialized
INFO - 2023-09-10 12:43:30 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:30 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:30 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:30 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:30 --> Controller Class Initialized
INFO - 2023-09-10 12:43:30 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:30 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:30 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:43:30 --> Config Class Initialized
INFO - 2023-09-10 12:43:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:30 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:30 --> URI Class Initialized
INFO - 2023-09-10 12:43:30 --> Router Class Initialized
INFO - 2023-09-10 12:43:30 --> Output Class Initialized
INFO - 2023-09-10 12:43:30 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:30 --> Input Class Initialized
INFO - 2023-09-10 12:43:30 --> Language Class Initialized
INFO - 2023-09-10 12:43:30 --> Loader Class Initialized
INFO - 2023-09-10 12:43:30 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:30 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:30 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:30 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:30 --> Controller Class Initialized
INFO - 2023-09-10 12:43:30 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:30 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:30 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:43:30 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:30 --> Total execution time: 0.0485
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:31 --> Config Class Initialized
INFO - 2023-09-10 12:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:31 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:31 --> URI Class Initialized
INFO - 2023-09-10 12:43:31 --> Router Class Initialized
INFO - 2023-09-10 12:43:31 --> Output Class Initialized
INFO - 2023-09-10 12:43:31 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:31 --> Input Class Initialized
INFO - 2023-09-10 12:43:31 --> Language Class Initialized
ERROR - 2023-09-10 12:43:31 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:34 --> Config Class Initialized
INFO - 2023-09-10 12:43:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:34 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:34 --> URI Class Initialized
INFO - 2023-09-10 12:43:34 --> Router Class Initialized
INFO - 2023-09-10 12:43:34 --> Output Class Initialized
INFO - 2023-09-10 12:43:34 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:34 --> Input Class Initialized
INFO - 2023-09-10 12:43:34 --> Language Class Initialized
INFO - 2023-09-10 12:43:34 --> Loader Class Initialized
INFO - 2023-09-10 12:43:34 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:34 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:34 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:34 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:34 --> Controller Class Initialized
INFO - 2023-09-10 12:43:34 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:34 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:34 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:34 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:34 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:34 --> Total execution time: 0.0597
INFO - 2023-09-10 12:43:34 --> Config Class Initialized
INFO - 2023-09-10 12:43:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:34 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:34 --> URI Class Initialized
INFO - 2023-09-10 12:43:34 --> Router Class Initialized
INFO - 2023-09-10 12:43:34 --> Output Class Initialized
INFO - 2023-09-10 12:43:34 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:34 --> Input Class Initialized
INFO - 2023-09-10 12:43:34 --> Language Class Initialized
ERROR - 2023-09-10 12:43:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:34 --> Config Class Initialized
INFO - 2023-09-10 12:43:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:34 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:34 --> URI Class Initialized
INFO - 2023-09-10 12:43:34 --> Router Class Initialized
INFO - 2023-09-10 12:43:34 --> Output Class Initialized
INFO - 2023-09-10 12:43:34 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:34 --> Input Class Initialized
INFO - 2023-09-10 12:43:34 --> Language Class Initialized
ERROR - 2023-09-10 12:43:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:34 --> Config Class Initialized
INFO - 2023-09-10 12:43:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:34 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:34 --> URI Class Initialized
INFO - 2023-09-10 12:43:34 --> Router Class Initialized
INFO - 2023-09-10 12:43:34 --> Output Class Initialized
INFO - 2023-09-10 12:43:34 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:34 --> Input Class Initialized
INFO - 2023-09-10 12:43:34 --> Language Class Initialized
ERROR - 2023-09-10 12:43:34 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:35 --> Config Class Initialized
INFO - 2023-09-10 12:43:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:35 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:35 --> URI Class Initialized
INFO - 2023-09-10 12:43:35 --> Router Class Initialized
INFO - 2023-09-10 12:43:35 --> Output Class Initialized
INFO - 2023-09-10 12:43:35 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:35 --> Input Class Initialized
INFO - 2023-09-10 12:43:35 --> Language Class Initialized
INFO - 2023-09-10 12:43:35 --> Loader Class Initialized
INFO - 2023-09-10 12:43:35 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:35 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:35 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:35 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:35 --> Controller Class Initialized
INFO - 2023-09-10 12:43:35 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:35 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:35 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:43:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:43:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:35 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:35 --> Total execution time: 0.0606
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
INFO - 2023-09-10 12:43:41 --> Loader Class Initialized
INFO - 2023-09-10 12:43:41 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:41 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:41 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:41 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:41 --> Controller Class Initialized
INFO - 2023-09-10 12:43:41 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:41 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:41 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
INFO - 2023-09-10 12:43:41 --> Loader Class Initialized
INFO - 2023-09-10 12:43:41 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:41 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:41 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:41 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:41 --> Controller Class Initialized
INFO - 2023-09-10 12:43:41 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:41 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:41 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:43:41 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:41 --> Total execution time: 0.0530
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:41 --> Config Class Initialized
INFO - 2023-09-10 12:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:41 --> URI Class Initialized
INFO - 2023-09-10 12:43:41 --> Router Class Initialized
INFO - 2023-09-10 12:43:41 --> Output Class Initialized
INFO - 2023-09-10 12:43:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:41 --> Input Class Initialized
INFO - 2023-09-10 12:43:41 --> Language Class Initialized
ERROR - 2023-09-10 12:43:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:49 --> Config Class Initialized
INFO - 2023-09-10 12:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:49 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:49 --> URI Class Initialized
INFO - 2023-09-10 12:43:49 --> Router Class Initialized
INFO - 2023-09-10 12:43:49 --> Output Class Initialized
INFO - 2023-09-10 12:43:49 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:49 --> Input Class Initialized
INFO - 2023-09-10 12:43:49 --> Language Class Initialized
INFO - 2023-09-10 12:43:49 --> Loader Class Initialized
INFO - 2023-09-10 12:43:49 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:49 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:50 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:50 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:50 --> Controller Class Initialized
INFO - 2023-09-10 12:43:50 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:50 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:50 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:50 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:50 --> Total execution time: 0.8487
INFO - 2023-09-10 12:43:50 --> Config Class Initialized
INFO - 2023-09-10 12:43:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:50 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:50 --> URI Class Initialized
INFO - 2023-09-10 12:43:50 --> Router Class Initialized
INFO - 2023-09-10 12:43:50 --> Output Class Initialized
INFO - 2023-09-10 12:43:50 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:50 --> Input Class Initialized
INFO - 2023-09-10 12:43:50 --> Language Class Initialized
ERROR - 2023-09-10 12:43:50 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:51 --> Config Class Initialized
INFO - 2023-09-10 12:43:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:51 --> URI Class Initialized
INFO - 2023-09-10 12:43:51 --> Router Class Initialized
INFO - 2023-09-10 12:43:51 --> Output Class Initialized
INFO - 2023-09-10 12:43:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:51 --> Input Class Initialized
INFO - 2023-09-10 12:43:51 --> Language Class Initialized
ERROR - 2023-09-10 12:43:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:51 --> Config Class Initialized
INFO - 2023-09-10 12:43:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:51 --> URI Class Initialized
INFO - 2023-09-10 12:43:51 --> Router Class Initialized
INFO - 2023-09-10 12:43:52 --> Output Class Initialized
INFO - 2023-09-10 12:43:52 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:52 --> Input Class Initialized
INFO - 2023-09-10 12:43:52 --> Language Class Initialized
ERROR - 2023-09-10 12:43:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:52 --> Config Class Initialized
INFO - 2023-09-10 12:43:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:52 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:52 --> URI Class Initialized
INFO - 2023-09-10 12:43:52 --> Router Class Initialized
INFO - 2023-09-10 12:43:52 --> Output Class Initialized
INFO - 2023-09-10 12:43:52 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:52 --> Input Class Initialized
INFO - 2023-09-10 12:43:52 --> Language Class Initialized
INFO - 2023-09-10 12:43:52 --> Loader Class Initialized
INFO - 2023-09-10 12:43:52 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:52 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:52 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:52 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:52 --> Controller Class Initialized
INFO - 2023-09-10 12:43:52 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:52 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:52 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:43:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:43:52 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:52 --> Total execution time: 0.0698
INFO - 2023-09-10 12:43:57 --> Config Class Initialized
INFO - 2023-09-10 12:43:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:57 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:57 --> URI Class Initialized
INFO - 2023-09-10 12:43:57 --> Router Class Initialized
INFO - 2023-09-10 12:43:57 --> Output Class Initialized
INFO - 2023-09-10 12:43:57 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:57 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
INFO - 2023-09-10 12:43:58 --> Loader Class Initialized
INFO - 2023-09-10 12:43:58 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:58 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:58 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:58 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:58 --> Controller Class Initialized
INFO - 2023-09-10 12:43:58 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:58 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:58 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
INFO - 2023-09-10 12:43:58 --> Loader Class Initialized
INFO - 2023-09-10 12:43:58 --> Helper loaded: url_helper
INFO - 2023-09-10 12:43:58 --> Helper loaded: file_helper
INFO - 2023-09-10 12:43:58 --> Database Driver Class Initialized
INFO - 2023-09-10 12:43:58 --> Email Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:43:58 --> Controller Class Initialized
INFO - 2023-09-10 12:43:58 --> Model "Services_model" initialized
INFO - 2023-09-10 12:43:58 --> Helper loaded: form_helper
INFO - 2023-09-10 12:43:58 --> Form Validation Class Initialized
INFO - 2023-09-10 12:43:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:43:58 --> Final output sent to browser
DEBUG - 2023-09-10 12:43:58 --> Total execution time: 0.0545
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:43:58 --> Config Class Initialized
INFO - 2023-09-10 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:43:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:43:58 --> URI Class Initialized
INFO - 2023-09-10 12:43:58 --> Router Class Initialized
INFO - 2023-09-10 12:43:58 --> Output Class Initialized
INFO - 2023-09-10 12:43:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:43:58 --> Input Class Initialized
INFO - 2023-09-10 12:43:58 --> Language Class Initialized
ERROR - 2023-09-10 12:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:02 --> Config Class Initialized
INFO - 2023-09-10 12:44:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:02 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:02 --> URI Class Initialized
INFO - 2023-09-10 12:44:02 --> Router Class Initialized
INFO - 2023-09-10 12:44:02 --> Output Class Initialized
INFO - 2023-09-10 12:44:02 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:02 --> Input Class Initialized
INFO - 2023-09-10 12:44:02 --> Language Class Initialized
INFO - 2023-09-10 12:44:02 --> Loader Class Initialized
INFO - 2023-09-10 12:44:02 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:02 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:02 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:02 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:02 --> Controller Class Initialized
INFO - 2023-09-10 12:44:02 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:02 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:02 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:02 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:02 --> Total execution time: 0.0524
INFO - 2023-09-10 12:44:03 --> Config Class Initialized
INFO - 2023-09-10 12:44:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:03 --> URI Class Initialized
INFO - 2023-09-10 12:44:03 --> Router Class Initialized
INFO - 2023-09-10 12:44:03 --> Output Class Initialized
INFO - 2023-09-10 12:44:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:03 --> Input Class Initialized
INFO - 2023-09-10 12:44:03 --> Language Class Initialized
ERROR - 2023-09-10 12:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:03 --> Config Class Initialized
INFO - 2023-09-10 12:44:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:03 --> URI Class Initialized
INFO - 2023-09-10 12:44:03 --> Router Class Initialized
INFO - 2023-09-10 12:44:03 --> Output Class Initialized
INFO - 2023-09-10 12:44:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:03 --> Input Class Initialized
INFO - 2023-09-10 12:44:03 --> Language Class Initialized
ERROR - 2023-09-10 12:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:03 --> Config Class Initialized
INFO - 2023-09-10 12:44:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:03 --> URI Class Initialized
INFO - 2023-09-10 12:44:03 --> Router Class Initialized
INFO - 2023-09-10 12:44:03 --> Output Class Initialized
INFO - 2023-09-10 12:44:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:03 --> Input Class Initialized
INFO - 2023-09-10 12:44:03 --> Language Class Initialized
ERROR - 2023-09-10 12:44:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:03 --> Config Class Initialized
INFO - 2023-09-10 12:44:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:03 --> URI Class Initialized
INFO - 2023-09-10 12:44:03 --> Router Class Initialized
INFO - 2023-09-10 12:44:03 --> Output Class Initialized
INFO - 2023-09-10 12:44:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:03 --> Input Class Initialized
INFO - 2023-09-10 12:44:03 --> Language Class Initialized
INFO - 2023-09-10 12:44:03 --> Loader Class Initialized
INFO - 2023-09-10 12:44:03 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:03 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:03 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:03 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:03 --> Controller Class Initialized
INFO - 2023-09-10 12:44:03 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:03 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:03 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:44:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:03 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:03 --> Total execution time: 0.0660
INFO - 2023-09-10 12:44:09 --> Config Class Initialized
INFO - 2023-09-10 12:44:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:09 --> URI Class Initialized
INFO - 2023-09-10 12:44:09 --> Router Class Initialized
INFO - 2023-09-10 12:44:09 --> Output Class Initialized
INFO - 2023-09-10 12:44:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:09 --> Input Class Initialized
INFO - 2023-09-10 12:44:09 --> Language Class Initialized
INFO - 2023-09-10 12:44:09 --> Loader Class Initialized
INFO - 2023-09-10 12:44:09 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:09 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:09 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:09 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:09 --> Controller Class Initialized
INFO - 2023-09-10 12:44:09 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:09 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:09 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:44:10 --> Config Class Initialized
INFO - 2023-09-10 12:44:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:10 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:10 --> URI Class Initialized
INFO - 2023-09-10 12:44:10 --> Router Class Initialized
INFO - 2023-09-10 12:44:10 --> Output Class Initialized
INFO - 2023-09-10 12:44:10 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:10 --> Input Class Initialized
INFO - 2023-09-10 12:44:10 --> Language Class Initialized
INFO - 2023-09-10 12:44:10 --> Loader Class Initialized
INFO - 2023-09-10 12:44:10 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:10 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:10 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:10 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:10 --> Controller Class Initialized
INFO - 2023-09-10 12:44:10 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:10 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:10 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:44:10 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:10 --> Total execution time: 0.0531
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:11 --> URI Class Initialized
INFO - 2023-09-10 12:44:11 --> Router Class Initialized
INFO - 2023-09-10 12:44:11 --> Output Class Initialized
INFO - 2023-09-10 12:44:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:11 --> Input Class Initialized
INFO - 2023-09-10 12:44:11 --> Language Class Initialized
ERROR - 2023-09-10 12:44:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:11 --> URI Class Initialized
INFO - 2023-09-10 12:44:11 --> Router Class Initialized
INFO - 2023-09-10 12:44:11 --> Output Class Initialized
INFO - 2023-09-10 12:44:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:11 --> Input Class Initialized
INFO - 2023-09-10 12:44:11 --> Language Class Initialized
ERROR - 2023-09-10 12:44:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:11 --> URI Class Initialized
INFO - 2023-09-10 12:44:11 --> Router Class Initialized
INFO - 2023-09-10 12:44:11 --> Output Class Initialized
INFO - 2023-09-10 12:44:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:11 --> Input Class Initialized
INFO - 2023-09-10 12:44:11 --> Language Class Initialized
ERROR - 2023-09-10 12:44:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:11 --> URI Class Initialized
INFO - 2023-09-10 12:44:11 --> Router Class Initialized
INFO - 2023-09-10 12:44:11 --> Output Class Initialized
INFO - 2023-09-10 12:44:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:11 --> Input Class Initialized
INFO - 2023-09-10 12:44:11 --> Language Class Initialized
ERROR - 2023-09-10 12:44:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:11 --> URI Class Initialized
INFO - 2023-09-10 12:44:11 --> Router Class Initialized
INFO - 2023-09-10 12:44:11 --> Output Class Initialized
INFO - 2023-09-10 12:44:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:11 --> Input Class Initialized
INFO - 2023-09-10 12:44:11 --> Language Class Initialized
ERROR - 2023-09-10 12:44:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:11 --> Config Class Initialized
INFO - 2023-09-10 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:12 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:12 --> URI Class Initialized
INFO - 2023-09-10 12:44:12 --> Router Class Initialized
INFO - 2023-09-10 12:44:12 --> Output Class Initialized
INFO - 2023-09-10 12:44:12 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:12 --> Input Class Initialized
INFO - 2023-09-10 12:44:12 --> Language Class Initialized
ERROR - 2023-09-10 12:44:12 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:20 --> Config Class Initialized
INFO - 2023-09-10 12:44:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:20 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:20 --> URI Class Initialized
INFO - 2023-09-10 12:44:20 --> Router Class Initialized
INFO - 2023-09-10 12:44:20 --> Output Class Initialized
INFO - 2023-09-10 12:44:20 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:20 --> Input Class Initialized
INFO - 2023-09-10 12:44:20 --> Language Class Initialized
INFO - 2023-09-10 12:44:20 --> Loader Class Initialized
INFO - 2023-09-10 12:44:20 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:20 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:20 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:20 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:20 --> Controller Class Initialized
INFO - 2023-09-10 12:44:20 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:20 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:20 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:20 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:20 --> Total execution time: 0.6123
INFO - 2023-09-10 12:44:21 --> Config Class Initialized
INFO - 2023-09-10 12:44:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:21 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:21 --> URI Class Initialized
INFO - 2023-09-10 12:44:21 --> Router Class Initialized
INFO - 2023-09-10 12:44:21 --> Output Class Initialized
INFO - 2023-09-10 12:44:21 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:21 --> Input Class Initialized
INFO - 2023-09-10 12:44:21 --> Language Class Initialized
ERROR - 2023-09-10 12:44:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:21 --> Config Class Initialized
INFO - 2023-09-10 12:44:21 --> Config Class Initialized
INFO - 2023-09-10 12:44:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:21 --> Hooks Class Initialized
INFO - 2023-09-10 12:44:21 --> Utf8 Class Initialized
DEBUG - 2023-09-10 12:44:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:21 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:21 --> URI Class Initialized
INFO - 2023-09-10 12:44:21 --> Router Class Initialized
INFO - 2023-09-10 12:44:21 --> Output Class Initialized
INFO - 2023-09-10 12:44:21 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:21 --> Input Class Initialized
INFO - 2023-09-10 12:44:21 --> Language Class Initialized
ERROR - 2023-09-10 12:44:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:21 --> URI Class Initialized
INFO - 2023-09-10 12:44:22 --> Router Class Initialized
INFO - 2023-09-10 12:44:22 --> Output Class Initialized
INFO - 2023-09-10 12:44:22 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:22 --> Input Class Initialized
INFO - 2023-09-10 12:44:22 --> Language Class Initialized
ERROR - 2023-09-10 12:44:22 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:22 --> Config Class Initialized
INFO - 2023-09-10 12:44:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:22 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:22 --> URI Class Initialized
INFO - 2023-09-10 12:44:22 --> Router Class Initialized
INFO - 2023-09-10 12:44:22 --> Output Class Initialized
INFO - 2023-09-10 12:44:22 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:22 --> Input Class Initialized
INFO - 2023-09-10 12:44:22 --> Language Class Initialized
INFO - 2023-09-10 12:44:22 --> Loader Class Initialized
INFO - 2023-09-10 12:44:22 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:22 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:22 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:22 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:22 --> Controller Class Initialized
INFO - 2023-09-10 12:44:22 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:22 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:22 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:44:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:22 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:22 --> Total execution time: 0.1011
INFO - 2023-09-10 12:44:28 --> Config Class Initialized
INFO - 2023-09-10 12:44:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:28 --> URI Class Initialized
INFO - 2023-09-10 12:44:28 --> Router Class Initialized
INFO - 2023-09-10 12:44:28 --> Output Class Initialized
INFO - 2023-09-10 12:44:28 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:28 --> Input Class Initialized
INFO - 2023-09-10 12:44:28 --> Language Class Initialized
INFO - 2023-09-10 12:44:28 --> Loader Class Initialized
INFO - 2023-09-10 12:44:28 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:28 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:28 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:28 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:28 --> Controller Class Initialized
INFO - 2023-09-10 12:44:28 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:28 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:28 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:44:28 --> Config Class Initialized
INFO - 2023-09-10 12:44:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:28 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:28 --> URI Class Initialized
INFO - 2023-09-10 12:44:28 --> Router Class Initialized
INFO - 2023-09-10 12:44:28 --> Output Class Initialized
INFO - 2023-09-10 12:44:28 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:28 --> Input Class Initialized
INFO - 2023-09-10 12:44:28 --> Language Class Initialized
INFO - 2023-09-10 12:44:28 --> Loader Class Initialized
INFO - 2023-09-10 12:44:28 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:28 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:28 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:28 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:28 --> Controller Class Initialized
INFO - 2023-09-10 12:44:28 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:28 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:28 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:44:28 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:28 --> Total execution time: 0.0542
INFO - 2023-09-10 12:44:29 --> Config Class Initialized
INFO - 2023-09-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:29 --> URI Class Initialized
INFO - 2023-09-10 12:44:29 --> Router Class Initialized
INFO - 2023-09-10 12:44:29 --> Output Class Initialized
INFO - 2023-09-10 12:44:29 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:29 --> Input Class Initialized
INFO - 2023-09-10 12:44:29 --> Language Class Initialized
ERROR - 2023-09-10 12:44:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:29 --> Config Class Initialized
INFO - 2023-09-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:29 --> URI Class Initialized
INFO - 2023-09-10 12:44:29 --> Router Class Initialized
INFO - 2023-09-10 12:44:29 --> Output Class Initialized
INFO - 2023-09-10 12:44:29 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:29 --> Input Class Initialized
INFO - 2023-09-10 12:44:29 --> Language Class Initialized
ERROR - 2023-09-10 12:44:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:29 --> Config Class Initialized
INFO - 2023-09-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:29 --> URI Class Initialized
INFO - 2023-09-10 12:44:29 --> Router Class Initialized
INFO - 2023-09-10 12:44:29 --> Output Class Initialized
INFO - 2023-09-10 12:44:29 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:29 --> Input Class Initialized
INFO - 2023-09-10 12:44:29 --> Language Class Initialized
ERROR - 2023-09-10 12:44:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:29 --> Config Class Initialized
INFO - 2023-09-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:29 --> URI Class Initialized
INFO - 2023-09-10 12:44:29 --> Router Class Initialized
INFO - 2023-09-10 12:44:29 --> Output Class Initialized
INFO - 2023-09-10 12:44:29 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:29 --> Input Class Initialized
INFO - 2023-09-10 12:44:29 --> Language Class Initialized
ERROR - 2023-09-10 12:44:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:29 --> Config Class Initialized
INFO - 2023-09-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:30 --> URI Class Initialized
INFO - 2023-09-10 12:44:30 --> Router Class Initialized
INFO - 2023-09-10 12:44:30 --> Output Class Initialized
INFO - 2023-09-10 12:44:30 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:30 --> Input Class Initialized
INFO - 2023-09-10 12:44:30 --> Language Class Initialized
ERROR - 2023-09-10 12:44:30 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:30 --> Config Class Initialized
INFO - 2023-09-10 12:44:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:30 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:30 --> URI Class Initialized
INFO - 2023-09-10 12:44:30 --> Router Class Initialized
INFO - 2023-09-10 12:44:30 --> Output Class Initialized
INFO - 2023-09-10 12:44:30 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:30 --> Input Class Initialized
INFO - 2023-09-10 12:44:30 --> Language Class Initialized
ERROR - 2023-09-10 12:44:30 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:41 --> Config Class Initialized
INFO - 2023-09-10 12:44:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:41 --> URI Class Initialized
INFO - 2023-09-10 12:44:42 --> Router Class Initialized
INFO - 2023-09-10 12:44:42 --> Output Class Initialized
INFO - 2023-09-10 12:44:42 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:42 --> Input Class Initialized
INFO - 2023-09-10 12:44:42 --> Language Class Initialized
INFO - 2023-09-10 12:44:42 --> Loader Class Initialized
INFO - 2023-09-10 12:44:42 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:42 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:42 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:42 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:42 --> Controller Class Initialized
INFO - 2023-09-10 12:44:42 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:42 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:42 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:42 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:42 --> Total execution time: 0.8344
INFO - 2023-09-10 12:44:42 --> Config Class Initialized
INFO - 2023-09-10 12:44:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:42 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:42 --> URI Class Initialized
INFO - 2023-09-10 12:44:42 --> Router Class Initialized
INFO - 2023-09-10 12:44:42 --> Output Class Initialized
INFO - 2023-09-10 12:44:42 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:42 --> Input Class Initialized
INFO - 2023-09-10 12:44:42 --> Language Class Initialized
ERROR - 2023-09-10 12:44:42 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:42 --> Config Class Initialized
INFO - 2023-09-10 12:44:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:42 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:42 --> URI Class Initialized
INFO - 2023-09-10 12:44:42 --> Router Class Initialized
INFO - 2023-09-10 12:44:42 --> Output Class Initialized
INFO - 2023-09-10 12:44:42 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:42 --> Input Class Initialized
INFO - 2023-09-10 12:44:42 --> Language Class Initialized
ERROR - 2023-09-10 12:44:42 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:43 --> Config Class Initialized
INFO - 2023-09-10 12:44:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:43 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:43 --> URI Class Initialized
INFO - 2023-09-10 12:44:43 --> Router Class Initialized
INFO - 2023-09-10 12:44:43 --> Output Class Initialized
INFO - 2023-09-10 12:44:43 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:43 --> Input Class Initialized
INFO - 2023-09-10 12:44:43 --> Language Class Initialized
ERROR - 2023-09-10 12:44:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:43 --> Config Class Initialized
INFO - 2023-09-10 12:44:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:43 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:43 --> URI Class Initialized
INFO - 2023-09-10 12:44:44 --> Router Class Initialized
INFO - 2023-09-10 12:44:44 --> Output Class Initialized
INFO - 2023-09-10 12:44:44 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:44 --> Input Class Initialized
INFO - 2023-09-10 12:44:44 --> Language Class Initialized
INFO - 2023-09-10 12:44:44 --> Loader Class Initialized
INFO - 2023-09-10 12:44:44 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:44 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:44 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:44 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:44 --> Controller Class Initialized
INFO - 2023-09-10 12:44:44 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:44 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:44 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:44:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:44:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:44 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:44 --> Total execution time: 0.0820
INFO - 2023-09-10 12:44:50 --> Config Class Initialized
INFO - 2023-09-10 12:44:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:50 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:50 --> URI Class Initialized
INFO - 2023-09-10 12:44:50 --> Router Class Initialized
INFO - 2023-09-10 12:44:50 --> Output Class Initialized
INFO - 2023-09-10 12:44:50 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:50 --> Input Class Initialized
INFO - 2023-09-10 12:44:50 --> Language Class Initialized
INFO - 2023-09-10 12:44:50 --> Loader Class Initialized
INFO - 2023-09-10 12:44:50 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:50 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:50 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:50 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:50 --> Controller Class Initialized
INFO - 2023-09-10 12:44:50 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:50 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:50 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:44:50 --> Config Class Initialized
INFO - 2023-09-10 12:44:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:50 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:50 --> URI Class Initialized
INFO - 2023-09-10 12:44:50 --> Router Class Initialized
INFO - 2023-09-10 12:44:50 --> Output Class Initialized
INFO - 2023-09-10 12:44:50 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:50 --> Input Class Initialized
INFO - 2023-09-10 12:44:50 --> Language Class Initialized
INFO - 2023-09-10 12:44:50 --> Loader Class Initialized
INFO - 2023-09-10 12:44:50 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:50 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:51 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:51 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:51 --> Controller Class Initialized
INFO - 2023-09-10 12:44:51 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:51 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:51 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:44:51 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:51 --> Total execution time: 0.0662
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:51 --> Config Class Initialized
INFO - 2023-09-10 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:51 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:51 --> URI Class Initialized
INFO - 2023-09-10 12:44:51 --> Router Class Initialized
INFO - 2023-09-10 12:44:51 --> Output Class Initialized
INFO - 2023-09-10 12:44:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:51 --> Input Class Initialized
INFO - 2023-09-10 12:44:51 --> Language Class Initialized
ERROR - 2023-09-10 12:44:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:58 --> Config Class Initialized
INFO - 2023-09-10 12:44:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:58 --> URI Class Initialized
INFO - 2023-09-10 12:44:58 --> Router Class Initialized
INFO - 2023-09-10 12:44:58 --> Output Class Initialized
INFO - 2023-09-10 12:44:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:58 --> Input Class Initialized
INFO - 2023-09-10 12:44:58 --> Language Class Initialized
INFO - 2023-09-10 12:44:58 --> Loader Class Initialized
INFO - 2023-09-10 12:44:58 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:58 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:58 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:58 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:58 --> Controller Class Initialized
INFO - 2023-09-10 12:44:58 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:58 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:58 --> Form Validation Class Initialized
INFO - 2023-09-10 12:44:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:58 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:58 --> Total execution time: 0.0688
INFO - 2023-09-10 12:44:58 --> Config Class Initialized
INFO - 2023-09-10 12:44:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:58 --> URI Class Initialized
INFO - 2023-09-10 12:44:58 --> Router Class Initialized
INFO - 2023-09-10 12:44:58 --> Output Class Initialized
INFO - 2023-09-10 12:44:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:58 --> Input Class Initialized
INFO - 2023-09-10 12:44:58 --> Language Class Initialized
ERROR - 2023-09-10 12:44:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:58 --> Config Class Initialized
INFO - 2023-09-10 12:44:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:58 --> URI Class Initialized
INFO - 2023-09-10 12:44:58 --> Router Class Initialized
INFO - 2023-09-10 12:44:58 --> Output Class Initialized
INFO - 2023-09-10 12:44:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:58 --> Input Class Initialized
INFO - 2023-09-10 12:44:58 --> Language Class Initialized
ERROR - 2023-09-10 12:44:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:58 --> Config Class Initialized
INFO - 2023-09-10 12:44:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:58 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:58 --> URI Class Initialized
INFO - 2023-09-10 12:44:58 --> Router Class Initialized
INFO - 2023-09-10 12:44:58 --> Output Class Initialized
INFO - 2023-09-10 12:44:58 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:58 --> Input Class Initialized
INFO - 2023-09-10 12:44:58 --> Language Class Initialized
ERROR - 2023-09-10 12:44:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:44:59 --> Config Class Initialized
INFO - 2023-09-10 12:44:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:44:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:44:59 --> Utf8 Class Initialized
INFO - 2023-09-10 12:44:59 --> URI Class Initialized
INFO - 2023-09-10 12:44:59 --> Router Class Initialized
INFO - 2023-09-10 12:44:59 --> Output Class Initialized
INFO - 2023-09-10 12:44:59 --> Security Class Initialized
DEBUG - 2023-09-10 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:44:59 --> Input Class Initialized
INFO - 2023-09-10 12:44:59 --> Language Class Initialized
INFO - 2023-09-10 12:44:59 --> Loader Class Initialized
INFO - 2023-09-10 12:44:59 --> Helper loaded: url_helper
INFO - 2023-09-10 12:44:59 --> Helper loaded: file_helper
INFO - 2023-09-10 12:44:59 --> Database Driver Class Initialized
INFO - 2023-09-10 12:44:59 --> Email Class Initialized
DEBUG - 2023-09-10 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:44:59 --> Controller Class Initialized
INFO - 2023-09-10 12:44:59 --> Model "Services_model" initialized
INFO - 2023-09-10 12:44:59 --> Helper loaded: form_helper
INFO - 2023-09-10 12:44:59 --> Form Validation Class Initialized
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 86
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 87
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 117
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 129
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 141
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 154
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 164
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 177
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 187
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 200
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 210
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 220
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 222
ERROR - 2023-09-10 12:44:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 224
INFO - 2023-09-10 12:44:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-10 12:44:59 --> Final output sent to browser
DEBUG - 2023-09-10 12:44:59 --> Total execution time: 0.1018
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
INFO - 2023-09-10 12:45:03 --> Loader Class Initialized
INFO - 2023-09-10 12:45:03 --> Helper loaded: url_helper
INFO - 2023-09-10 12:45:03 --> Helper loaded: file_helper
INFO - 2023-09-10 12:45:03 --> Database Driver Class Initialized
INFO - 2023-09-10 12:45:03 --> Email Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:45:03 --> Controller Class Initialized
INFO - 2023-09-10 12:45:03 --> Model "Services_model" initialized
INFO - 2023-09-10 12:45:03 --> Helper loaded: form_helper
INFO - 2023-09-10 12:45:03 --> Form Validation Class Initialized
INFO - 2023-09-10 12:45:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
INFO - 2023-09-10 12:45:03 --> Loader Class Initialized
INFO - 2023-09-10 12:45:03 --> Helper loaded: url_helper
INFO - 2023-09-10 12:45:03 --> Helper loaded: file_helper
INFO - 2023-09-10 12:45:03 --> Database Driver Class Initialized
INFO - 2023-09-10 12:45:03 --> Email Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:45:03 --> Controller Class Initialized
INFO - 2023-09-10 12:45:03 --> Model "Services_model" initialized
INFO - 2023-09-10 12:45:03 --> Helper loaded: form_helper
INFO - 2023-09-10 12:45:03 --> Form Validation Class Initialized
INFO - 2023-09-10 12:45:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-10 12:45:03 --> Final output sent to browser
DEBUG - 2023-09-10 12:45:03 --> Total execution time: 0.0709
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:03 --> Config Class Initialized
INFO - 2023-09-10 12:45:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:03 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:03 --> URI Class Initialized
INFO - 2023-09-10 12:45:03 --> Router Class Initialized
INFO - 2023-09-10 12:45:03 --> Output Class Initialized
INFO - 2023-09-10 12:45:03 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:03 --> Input Class Initialized
INFO - 2023-09-10 12:45:03 --> Language Class Initialized
ERROR - 2023-09-10 12:45:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:07 --> Config Class Initialized
INFO - 2023-09-10 12:45:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:07 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:07 --> URI Class Initialized
INFO - 2023-09-10 12:45:07 --> Router Class Initialized
INFO - 2023-09-10 12:45:07 --> Output Class Initialized
INFO - 2023-09-10 12:45:07 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:07 --> Input Class Initialized
INFO - 2023-09-10 12:45:07 --> Language Class Initialized
INFO - 2023-09-10 12:45:07 --> Loader Class Initialized
INFO - 2023-09-10 12:45:07 --> Helper loaded: url_helper
INFO - 2023-09-10 12:45:07 --> Helper loaded: file_helper
INFO - 2023-09-10 12:45:07 --> Database Driver Class Initialized
INFO - 2023-09-10 12:45:07 --> Email Class Initialized
DEBUG - 2023-09-10 12:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:45:07 --> Controller Class Initialized
INFO - 2023-09-10 12:45:07 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:45:07 --> Model "Home_model" initialized
INFO - 2023-09-10 12:45:07 --> Helper loaded: download_helper
INFO - 2023-09-10 12:45:07 --> Helper loaded: form_helper
INFO - 2023-09-10 12:45:07 --> Form Validation Class Initialized
INFO - 2023-09-10 12:45:07 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:45:07 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:45:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 12:45:07 --> Final output sent to browser
DEBUG - 2023-09-10 12:45:07 --> Total execution time: 0.0601
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:45:09 --> Config Class Initialized
INFO - 2023-09-10 12:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:09 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:09 --> URI Class Initialized
INFO - 2023-09-10 12:45:09 --> Router Class Initialized
INFO - 2023-09-10 12:45:09 --> Output Class Initialized
INFO - 2023-09-10 12:45:09 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:09 --> Input Class Initialized
INFO - 2023-09-10 12:45:09 --> Language Class Initialized
ERROR - 2023-09-10 12:45:09 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-10 12:45:10 --> Config Class Initialized
INFO - 2023-09-10 12:45:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:10 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:10 --> URI Class Initialized
INFO - 2023-09-10 12:45:10 --> Router Class Initialized
INFO - 2023-09-10 12:45:10 --> Output Class Initialized
INFO - 2023-09-10 12:45:10 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:10 --> Input Class Initialized
INFO - 2023-09-10 12:45:10 --> Language Class Initialized
ERROR - 2023-09-10 12:45:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:45:11 --> Config Class Initialized
INFO - 2023-09-10 12:45:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:11 --> URI Class Initialized
INFO - 2023-09-10 12:45:11 --> Router Class Initialized
INFO - 2023-09-10 12:45:11 --> Output Class Initialized
INFO - 2023-09-10 12:45:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:11 --> Input Class Initialized
INFO - 2023-09-10 12:45:11 --> Language Class Initialized
ERROR - 2023-09-10 12:45:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:45:11 --> Config Class Initialized
INFO - 2023-09-10 12:45:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:45:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:45:11 --> Utf8 Class Initialized
INFO - 2023-09-10 12:45:11 --> URI Class Initialized
INFO - 2023-09-10 12:45:11 --> Router Class Initialized
INFO - 2023-09-10 12:45:11 --> Output Class Initialized
INFO - 2023-09-10 12:45:11 --> Security Class Initialized
DEBUG - 2023-09-10 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:45:11 --> Input Class Initialized
INFO - 2023-09-10 12:45:11 --> Language Class Initialized
ERROR - 2023-09-10 12:45:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 12:56:26 --> Config Class Initialized
INFO - 2023-09-10 12:56:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:56:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:56:26 --> Utf8 Class Initialized
INFO - 2023-09-10 12:56:26 --> URI Class Initialized
INFO - 2023-09-10 12:56:26 --> Router Class Initialized
INFO - 2023-09-10 12:56:26 --> Output Class Initialized
INFO - 2023-09-10 12:56:26 --> Security Class Initialized
DEBUG - 2023-09-10 12:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:56:26 --> Input Class Initialized
INFO - 2023-09-10 12:56:26 --> Language Class Initialized
INFO - 2023-09-10 12:56:27 --> Loader Class Initialized
INFO - 2023-09-10 12:56:27 --> Helper loaded: url_helper
INFO - 2023-09-10 12:56:27 --> Helper loaded: file_helper
INFO - 2023-09-10 12:56:27 --> Database Driver Class Initialized
INFO - 2023-09-10 12:56:27 --> Email Class Initialized
DEBUG - 2023-09-10 12:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:56:27 --> Controller Class Initialized
INFO - 2023-09-10 12:56:27 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:56:27 --> Model "Home_model" initialized
INFO - 2023-09-10 12:56:27 --> Helper loaded: download_helper
INFO - 2023-09-10 12:56:27 --> Helper loaded: form_helper
INFO - 2023-09-10 12:56:27 --> Form Validation Class Initialized
INFO - 2023-09-10 12:56:27 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:56:27 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:56:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 12:56:27 --> Final output sent to browser
DEBUG - 2023-09-10 12:56:27 --> Total execution time: 1.1967
INFO - 2023-09-10 12:56:30 --> Config Class Initialized
INFO - 2023-09-10 12:56:30 --> Hooks Class Initialized
INFO - 2023-09-10 12:56:38 --> Config Class Initialized
INFO - 2023-09-10 12:56:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:56:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:56:38 --> Utf8 Class Initialized
INFO - 2023-09-10 12:56:38 --> URI Class Initialized
INFO - 2023-09-10 12:56:38 --> Router Class Initialized
INFO - 2023-09-10 12:56:38 --> Output Class Initialized
INFO - 2023-09-10 12:56:38 --> Security Class Initialized
DEBUG - 2023-09-10 12:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:56:38 --> Input Class Initialized
INFO - 2023-09-10 12:56:38 --> Language Class Initialized
INFO - 2023-09-10 12:56:38 --> Loader Class Initialized
INFO - 2023-09-10 12:56:38 --> Helper loaded: url_helper
INFO - 2023-09-10 12:56:38 --> Helper loaded: file_helper
INFO - 2023-09-10 12:56:38 --> Database Driver Class Initialized
INFO - 2023-09-10 12:56:38 --> Email Class Initialized
DEBUG - 2023-09-10 12:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:56:39 --> Controller Class Initialized
INFO - 2023-09-10 12:56:39 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:56:39 --> Model "Home_model" initialized
INFO - 2023-09-10 12:56:39 --> Helper loaded: download_helper
INFO - 2023-09-10 12:56:39 --> Helper loaded: form_helper
INFO - 2023-09-10 12:56:39 --> Form Validation Class Initialized
INFO - 2023-09-10 12:56:39 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:56:39 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:56:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-10 12:56:39 --> Final output sent to browser
DEBUG - 2023-09-10 12:56:40 --> Total execution time: 1.4809
INFO - 2023-09-10 12:56:40 --> Config Class Initialized
INFO - 2023-09-10 12:56:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:56:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:56:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:56:41 --> URI Class Initialized
INFO - 2023-09-10 12:56:41 --> Router Class Initialized
INFO - 2023-09-10 12:56:41 --> Output Class Initialized
INFO - 2023-09-10 12:56:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:56:41 --> Input Class Initialized
INFO - 2023-09-10 12:56:41 --> Language Class Initialized
ERROR - 2023-09-10 12:56:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:56:50 --> Config Class Initialized
INFO - 2023-09-10 12:56:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:56:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:56:50 --> Utf8 Class Initialized
INFO - 2023-09-10 12:56:50 --> URI Class Initialized
INFO - 2023-09-10 12:56:50 --> Router Class Initialized
INFO - 2023-09-10 12:56:50 --> Output Class Initialized
INFO - 2023-09-10 12:56:51 --> Security Class Initialized
DEBUG - 2023-09-10 12:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:56:51 --> Input Class Initialized
INFO - 2023-09-10 12:56:51 --> Language Class Initialized
INFO - 2023-09-10 12:56:51 --> Loader Class Initialized
INFO - 2023-09-10 12:56:51 --> Helper loaded: url_helper
INFO - 2023-09-10 12:56:51 --> Helper loaded: file_helper
INFO - 2023-09-10 12:56:51 --> Database Driver Class Initialized
INFO - 2023-09-10 12:56:51 --> Email Class Initialized
DEBUG - 2023-09-10 12:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:56:51 --> Controller Class Initialized
INFO - 2023-09-10 12:56:51 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:56:51 --> Model "Home_model" initialized
INFO - 2023-09-10 12:56:51 --> Helper loaded: download_helper
INFO - 2023-09-10 12:56:51 --> Helper loaded: form_helper
INFO - 2023-09-10 12:56:51 --> Form Validation Class Initialized
INFO - 2023-09-10 12:56:51 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:56:51 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:56:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-10 12:56:51 --> Final output sent to browser
DEBUG - 2023-09-10 12:56:52 --> Total execution time: 1.5091
INFO - 2023-09-10 12:56:52 --> Config Class Initialized
INFO - 2023-09-10 12:56:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:56:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:56:53 --> Utf8 Class Initialized
INFO - 2023-09-10 12:56:53 --> URI Class Initialized
INFO - 2023-09-10 12:56:53 --> Router Class Initialized
INFO - 2023-09-10 12:56:53 --> Output Class Initialized
INFO - 2023-09-10 12:56:53 --> Security Class Initialized
DEBUG - 2023-09-10 12:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:56:53 --> Input Class Initialized
INFO - 2023-09-10 12:56:53 --> Language Class Initialized
ERROR - 2023-09-10 12:56:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 12:59:41 --> Config Class Initialized
INFO - 2023-09-10 12:59:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:59:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:59:41 --> Utf8 Class Initialized
INFO - 2023-09-10 12:59:41 --> URI Class Initialized
DEBUG - 2023-09-10 12:59:41 --> No URI present. Default controller set.
INFO - 2023-09-10 12:59:41 --> Router Class Initialized
INFO - 2023-09-10 12:59:41 --> Output Class Initialized
INFO - 2023-09-10 12:59:41 --> Security Class Initialized
DEBUG - 2023-09-10 12:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:59:42 --> Input Class Initialized
INFO - 2023-09-10 12:59:42 --> Language Class Initialized
INFO - 2023-09-10 12:59:42 --> Loader Class Initialized
INFO - 2023-09-10 12:59:42 --> Helper loaded: url_helper
INFO - 2023-09-10 12:59:42 --> Helper loaded: file_helper
INFO - 2023-09-10 12:59:42 --> Database Driver Class Initialized
INFO - 2023-09-10 12:59:42 --> Email Class Initialized
DEBUG - 2023-09-10 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 12:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 12:59:42 --> Controller Class Initialized
INFO - 2023-09-10 12:59:42 --> Model "Contact_model" initialized
INFO - 2023-09-10 12:59:42 --> Model "Home_model" initialized
INFO - 2023-09-10 12:59:42 --> Helper loaded: download_helper
INFO - 2023-09-10 12:59:42 --> Helper loaded: form_helper
INFO - 2023-09-10 12:59:42 --> Form Validation Class Initialized
INFO - 2023-09-10 12:59:42 --> Helper loaded: custom_helper
INFO - 2023-09-10 12:59:42 --> Model "Social_media_model" initialized
INFO - 2023-09-10 12:59:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 12:59:42 --> Final output sent to browser
DEBUG - 2023-09-10 12:59:43 --> Total execution time: 1.3184
INFO - 2023-09-10 12:59:44 --> Config Class Initialized
INFO - 2023-09-10 12:59:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 12:59:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 12:59:44 --> Utf8 Class Initialized
INFO - 2023-09-10 12:59:44 --> URI Class Initialized
INFO - 2023-09-10 12:59:44 --> Router Class Initialized
INFO - 2023-09-10 12:59:44 --> Output Class Initialized
INFO - 2023-09-10 12:59:44 --> Security Class Initialized
DEBUG - 2023-09-10 12:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 12:59:44 --> Input Class Initialized
INFO - 2023-09-10 12:59:44 --> Language Class Initialized
ERROR - 2023-09-10 12:59:44 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:00:40 --> Config Class Initialized
INFO - 2023-09-10 13:00:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:00:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:00:40 --> Utf8 Class Initialized
INFO - 2023-09-10 13:00:40 --> URI Class Initialized
DEBUG - 2023-09-10 13:00:40 --> No URI present. Default controller set.
INFO - 2023-09-10 13:00:40 --> Router Class Initialized
INFO - 2023-09-10 13:00:41 --> Output Class Initialized
INFO - 2023-09-10 13:00:41 --> Security Class Initialized
DEBUG - 2023-09-10 13:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:00:41 --> Input Class Initialized
INFO - 2023-09-10 13:00:41 --> Language Class Initialized
INFO - 2023-09-10 13:00:41 --> Loader Class Initialized
INFO - 2023-09-10 13:00:41 --> Helper loaded: url_helper
INFO - 2023-09-10 13:00:41 --> Helper loaded: file_helper
INFO - 2023-09-10 13:00:41 --> Database Driver Class Initialized
INFO - 2023-09-10 13:00:41 --> Email Class Initialized
DEBUG - 2023-09-10 13:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:00:41 --> Controller Class Initialized
INFO - 2023-09-10 13:00:41 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:00:42 --> Model "Home_model" initialized
INFO - 2023-09-10 13:00:42 --> Helper loaded: download_helper
INFO - 2023-09-10 13:00:42 --> Helper loaded: form_helper
INFO - 2023-09-10 13:00:42 --> Form Validation Class Initialized
INFO - 2023-09-10 13:00:42 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:00:42 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:00:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:00:42 --> Final output sent to browser
DEBUG - 2023-09-10 13:00:42 --> Total execution time: 1.8188
INFO - 2023-09-10 13:00:43 --> Config Class Initialized
INFO - 2023-09-10 13:00:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:00:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:00:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:00:43 --> URI Class Initialized
INFO - 2023-09-10 13:00:43 --> Router Class Initialized
INFO - 2023-09-10 13:00:43 --> Output Class Initialized
INFO - 2023-09-10 13:00:43 --> Security Class Initialized
DEBUG - 2023-09-10 13:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:00:43 --> Input Class Initialized
INFO - 2023-09-10 13:00:43 --> Language Class Initialized
ERROR - 2023-09-10 13:00:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:04:32 --> Config Class Initialized
INFO - 2023-09-10 13:04:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:04:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:04:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:04:32 --> URI Class Initialized
DEBUG - 2023-09-10 13:04:32 --> No URI present. Default controller set.
INFO - 2023-09-10 13:04:32 --> Router Class Initialized
INFO - 2023-09-10 13:04:32 --> Output Class Initialized
INFO - 2023-09-10 13:04:32 --> Security Class Initialized
DEBUG - 2023-09-10 13:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:04:32 --> Input Class Initialized
INFO - 2023-09-10 13:04:32 --> Language Class Initialized
INFO - 2023-09-10 13:04:32 --> Loader Class Initialized
INFO - 2023-09-10 13:04:32 --> Helper loaded: url_helper
INFO - 2023-09-10 13:04:32 --> Helper loaded: file_helper
INFO - 2023-09-10 13:04:32 --> Database Driver Class Initialized
INFO - 2023-09-10 13:04:32 --> Email Class Initialized
DEBUG - 2023-09-10 13:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:04:33 --> Controller Class Initialized
INFO - 2023-09-10 13:04:33 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:04:33 --> Model "Home_model" initialized
INFO - 2023-09-10 13:04:33 --> Helper loaded: download_helper
INFO - 2023-09-10 13:04:33 --> Helper loaded: form_helper
INFO - 2023-09-10 13:04:33 --> Form Validation Class Initialized
INFO - 2023-09-10 13:04:33 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:04:33 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:04:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:04:33 --> Final output sent to browser
DEBUG - 2023-09-10 13:04:33 --> Total execution time: 1.4829
INFO - 2023-09-10 13:08:31 --> Config Class Initialized
INFO - 2023-09-10 13:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:08:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:08:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:08:33 --> URI Class Initialized
DEBUG - 2023-09-10 13:08:33 --> No URI present. Default controller set.
INFO - 2023-09-10 13:08:33 --> Router Class Initialized
INFO - 2023-09-10 13:08:34 --> Output Class Initialized
INFO - 2023-09-10 13:08:34 --> Security Class Initialized
DEBUG - 2023-09-10 13:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:08:34 --> Input Class Initialized
INFO - 2023-09-10 13:08:34 --> Language Class Initialized
INFO - 2023-09-10 13:08:34 --> Loader Class Initialized
INFO - 2023-09-10 13:08:34 --> Helper loaded: url_helper
INFO - 2023-09-10 13:08:34 --> Helper loaded: file_helper
INFO - 2023-09-10 13:08:34 --> Database Driver Class Initialized
INFO - 2023-09-10 13:08:34 --> Email Class Initialized
DEBUG - 2023-09-10 13:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:08:34 --> Controller Class Initialized
INFO - 2023-09-10 13:08:34 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:08:34 --> Model "Home_model" initialized
INFO - 2023-09-10 13:08:34 --> Helper loaded: download_helper
INFO - 2023-09-10 13:08:34 --> Helper loaded: form_helper
INFO - 2023-09-10 13:08:34 --> Form Validation Class Initialized
INFO - 2023-09-10 13:08:34 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:08:34 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:08:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:08:35 --> Final output sent to browser
DEBUG - 2023-09-10 13:08:35 --> Total execution time: 6.2989
INFO - 2023-09-10 13:09:23 --> Config Class Initialized
INFO - 2023-09-10 13:09:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:25 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:25 --> URI Class Initialized
INFO - 2023-09-10 13:09:25 --> Router Class Initialized
INFO - 2023-09-10 13:09:25 --> Output Class Initialized
INFO - 2023-09-10 13:09:26 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:26 --> Input Class Initialized
INFO - 2023-09-10 13:09:26 --> Language Class Initialized
ERROR - 2023-09-10 13:09:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:09:28 --> Config Class Initialized
INFO - 2023-09-10 13:09:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:28 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:28 --> URI Class Initialized
INFO - 2023-09-10 13:09:28 --> Router Class Initialized
INFO - 2023-09-10 13:09:28 --> Output Class Initialized
INFO - 2023-09-10 13:09:28 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:28 --> Input Class Initialized
INFO - 2023-09-10 13:09:28 --> Language Class Initialized
ERROR - 2023-09-10 13:09:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:09:29 --> Config Class Initialized
INFO - 2023-09-10 13:09:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:29 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:29 --> URI Class Initialized
INFO - 2023-09-10 13:09:29 --> Router Class Initialized
INFO - 2023-09-10 13:09:29 --> Output Class Initialized
INFO - 2023-09-10 13:09:29 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:29 --> Input Class Initialized
INFO - 2023-09-10 13:09:29 --> Language Class Initialized
ERROR - 2023-09-10 13:09:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:09:30 --> Config Class Initialized
INFO - 2023-09-10 13:09:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:30 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:30 --> URI Class Initialized
INFO - 2023-09-10 13:09:30 --> Router Class Initialized
INFO - 2023-09-10 13:09:30 --> Output Class Initialized
INFO - 2023-09-10 13:09:30 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:30 --> Input Class Initialized
INFO - 2023-09-10 13:09:30 --> Language Class Initialized
ERROR - 2023-09-10 13:09:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:09:30 --> Config Class Initialized
INFO - 2023-09-10 13:09:31 --> Hooks Class Initialized
INFO - 2023-09-10 13:09:31 --> Config Class Initialized
INFO - 2023-09-10 13:09:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:31 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:31 --> URI Class Initialized
INFO - 2023-09-10 13:09:31 --> Router Class Initialized
INFO - 2023-09-10 13:09:31 --> Output Class Initialized
INFO - 2023-09-10 13:09:31 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:31 --> Input Class Initialized
INFO - 2023-09-10 13:09:31 --> Language Class Initialized
ERROR - 2023-09-10 13:09:31 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:09:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:32 --> Config Class Initialized
INFO - 2023-09-10 13:09:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:09:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:09:33 --> URI Class Initialized
INFO - 2023-09-10 13:09:34 --> Router Class Initialized
INFO - 2023-09-10 13:09:34 --> Utf8 Class Initialized
INFO - 2023-09-10 13:09:34 --> URI Class Initialized
INFO - 2023-09-10 13:09:34 --> Output Class Initialized
INFO - 2023-09-10 13:09:34 --> Router Class Initialized
INFO - 2023-09-10 13:09:34 --> Security Class Initialized
INFO - 2023-09-10 13:09:34 --> Output Class Initialized
INFO - 2023-09-10 13:09:35 --> Security Class Initialized
DEBUG - 2023-09-10 13:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 13:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:09:35 --> Input Class Initialized
INFO - 2023-09-10 13:09:35 --> Input Class Initialized
INFO - 2023-09-10 13:09:35 --> Language Class Initialized
INFO - 2023-09-10 13:09:35 --> Language Class Initialized
ERROR - 2023-09-10 13:09:35 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:09:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:07 --> Config Class Initialized
INFO - 2023-09-10 13:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:07 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:08 --> URI Class Initialized
INFO - 2023-09-10 13:13:09 --> Router Class Initialized
INFO - 2023-09-10 13:13:09 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:10 --> Config Class Initialized
INFO - 2023-09-10 13:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:10 --> URI Class Initialized
INFO - 2023-09-10 13:13:10 --> Router Class Initialized
INFO - 2023-09-10 13:13:10 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:10 --> Config Class Initialized
INFO - 2023-09-10 13:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:10 --> URI Class Initialized
INFO - 2023-09-10 13:13:10 --> Router Class Initialized
INFO - 2023-09-10 13:13:10 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:10 --> Config Class Initialized
INFO - 2023-09-10 13:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:10 --> URI Class Initialized
INFO - 2023-09-10 13:13:10 --> Router Class Initialized
INFO - 2023-09-10 13:13:10 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:10 --> Config Class Initialized
INFO - 2023-09-10 13:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:10 --> URI Class Initialized
INFO - 2023-09-10 13:13:10 --> Router Class Initialized
INFO - 2023-09-10 13:13:10 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:10 --> Config Class Initialized
INFO - 2023-09-10 13:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:10 --> URI Class Initialized
INFO - 2023-09-10 13:13:10 --> Router Class Initialized
INFO - 2023-09-10 13:13:10 --> Output Class Initialized
INFO - 2023-09-10 13:13:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:10 --> Input Class Initialized
INFO - 2023-09-10 13:13:10 --> Language Class Initialized
ERROR - 2023-09-10 13:13:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:13:11 --> Config Class Initialized
INFO - 2023-09-10 13:13:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:13:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:13:13 --> Utf8 Class Initialized
INFO - 2023-09-10 13:13:13 --> URI Class Initialized
INFO - 2023-09-10 13:13:14 --> Router Class Initialized
INFO - 2023-09-10 13:13:15 --> Output Class Initialized
INFO - 2023-09-10 13:13:15 --> Security Class Initialized
DEBUG - 2023-09-10 13:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:13:16 --> Input Class Initialized
INFO - 2023-09-10 13:13:16 --> Language Class Initialized
ERROR - 2023-09-10 13:13:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:15:28 --> Config Class Initialized
INFO - 2023-09-10 13:15:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:15:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:15:29 --> Utf8 Class Initialized
INFO - 2023-09-10 13:15:29 --> URI Class Initialized
DEBUG - 2023-09-10 13:15:29 --> No URI present. Default controller set.
INFO - 2023-09-10 13:15:29 --> Router Class Initialized
INFO - 2023-09-10 13:15:29 --> Output Class Initialized
INFO - 2023-09-10 13:15:29 --> Security Class Initialized
DEBUG - 2023-09-10 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:15:29 --> Input Class Initialized
INFO - 2023-09-10 13:15:29 --> Language Class Initialized
INFO - 2023-09-10 13:15:29 --> Loader Class Initialized
INFO - 2023-09-10 13:15:29 --> Helper loaded: url_helper
INFO - 2023-09-10 13:15:29 --> Helper loaded: file_helper
INFO - 2023-09-10 13:15:29 --> Database Driver Class Initialized
INFO - 2023-09-10 13:15:29 --> Email Class Initialized
DEBUG - 2023-09-10 13:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:15:29 --> Controller Class Initialized
INFO - 2023-09-10 13:15:30 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:15:30 --> Model "Home_model" initialized
INFO - 2023-09-10 13:15:30 --> Helper loaded: download_helper
INFO - 2023-09-10 13:15:30 --> Helper loaded: form_helper
INFO - 2023-09-10 13:15:30 --> Form Validation Class Initialized
INFO - 2023-09-10 13:15:30 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:15:30 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:15:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:15:30 --> Final output sent to browser
DEBUG - 2023-09-10 13:15:30 --> Total execution time: 2.8844
INFO - 2023-09-10 13:16:42 --> Config Class Initialized
INFO - 2023-09-10 13:16:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:16:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:16:42 --> Utf8 Class Initialized
INFO - 2023-09-10 13:16:42 --> URI Class Initialized
DEBUG - 2023-09-10 13:16:42 --> No URI present. Default controller set.
INFO - 2023-09-10 13:16:42 --> Router Class Initialized
INFO - 2023-09-10 13:16:42 --> Output Class Initialized
INFO - 2023-09-10 13:16:42 --> Security Class Initialized
DEBUG - 2023-09-10 13:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:16:43 --> Input Class Initialized
INFO - 2023-09-10 13:16:43 --> Language Class Initialized
INFO - 2023-09-10 13:16:43 --> Loader Class Initialized
INFO - 2023-09-10 13:16:43 --> Helper loaded: url_helper
INFO - 2023-09-10 13:16:43 --> Helper loaded: file_helper
INFO - 2023-09-10 13:16:43 --> Database Driver Class Initialized
INFO - 2023-09-10 13:16:43 --> Email Class Initialized
DEBUG - 2023-09-10 13:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:16:43 --> Controller Class Initialized
INFO - 2023-09-10 13:16:43 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:16:43 --> Model "Home_model" initialized
INFO - 2023-09-10 13:16:43 --> Helper loaded: download_helper
INFO - 2023-09-10 13:16:43 --> Helper loaded: form_helper
INFO - 2023-09-10 13:16:43 --> Form Validation Class Initialized
INFO - 2023-09-10 13:16:43 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:16:43 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:16:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:16:46 --> Final output sent to browser
DEBUG - 2023-09-10 13:16:47 --> Total execution time: 3.4828
INFO - 2023-09-10 13:18:02 --> Config Class Initialized
INFO - 2023-09-10 13:18:02 --> Hooks Class Initialized
INFO - 2023-09-10 13:18:02 --> Config Class Initialized
INFO - 2023-09-10 13:18:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:18:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:02 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:02 --> URI Class Initialized
INFO - 2023-09-10 13:18:02 --> Router Class Initialized
INFO - 2023-09-10 13:18:02 --> Output Class Initialized
INFO - 2023-09-10 13:18:02 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:03 --> Config Class Initialized
INFO - 2023-09-10 13:18:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:03 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:03 --> URI Class Initialized
INFO - 2023-09-10 13:18:03 --> Router Class Initialized
INFO - 2023-09-10 13:18:03 --> Output Class Initialized
INFO - 2023-09-10 13:18:03 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:03 --> Input Class Initialized
INFO - 2023-09-10 13:18:03 --> Language Class Initialized
ERROR - 2023-09-10 13:18:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:03 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:03 --> URI Class Initialized
INFO - 2023-09-10 13:18:03 --> Router Class Initialized
INFO - 2023-09-10 13:18:03 --> Output Class Initialized
INFO - 2023-09-10 13:18:03 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:03 --> Input Class Initialized
INFO - 2023-09-10 13:18:03 --> Language Class Initialized
ERROR - 2023-09-10 13:18:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:18:03 --> Config Class Initialized
INFO - 2023-09-10 13:18:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:03 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:03 --> URI Class Initialized
INFO - 2023-09-10 13:18:03 --> Router Class Initialized
INFO - 2023-09-10 13:18:03 --> Output Class Initialized
INFO - 2023-09-10 13:18:03 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:03 --> Input Class Initialized
INFO - 2023-09-10 13:18:03 --> Language Class Initialized
INFO - 2023-09-10 13:18:03 --> Input Class Initialized
ERROR - 2023-09-10 13:18:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:18:04 --> Config Class Initialized
INFO - 2023-09-10 13:18:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:18:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:04 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:04 --> URI Class Initialized
INFO - 2023-09-10 13:18:04 --> Router Class Initialized
INFO - 2023-09-10 13:18:04 --> Output Class Initialized
INFO - 2023-09-10 13:18:04 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:04 --> Input Class Initialized
INFO - 2023-09-10 13:18:04 --> Language Class Initialized
ERROR - 2023-09-10 13:18:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:18:04 --> Language Class Initialized
ERROR - 2023-09-10 13:18:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:18:12 --> Config Class Initialized
INFO - 2023-09-10 13:18:12 --> Hooks Class Initialized
INFO - 2023-09-10 13:18:13 --> Config Class Initialized
DEBUG - 2023-09-10 13:18:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:13 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:13 --> URI Class Initialized
INFO - 2023-09-10 13:18:13 --> Router Class Initialized
INFO - 2023-09-10 13:18:13 --> Output Class Initialized
INFO - 2023-09-10 13:18:13 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:13 --> Input Class Initialized
INFO - 2023-09-10 13:18:13 --> Language Class Initialized
ERROR - 2023-09-10 13:18:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:18:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:18:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:18:13 --> Utf8 Class Initialized
INFO - 2023-09-10 13:18:13 --> URI Class Initialized
INFO - 2023-09-10 13:18:13 --> Router Class Initialized
INFO - 2023-09-10 13:18:13 --> Output Class Initialized
INFO - 2023-09-10 13:18:13 --> Security Class Initialized
DEBUG - 2023-09-10 13:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:18:13 --> Input Class Initialized
INFO - 2023-09-10 13:18:13 --> Language Class Initialized
ERROR - 2023-09-10 13:18:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:20:49 --> Config Class Initialized
INFO - 2023-09-10 13:20:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:20:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:20:50 --> Utf8 Class Initialized
INFO - 2023-09-10 13:20:50 --> URI Class Initialized
DEBUG - 2023-09-10 13:20:50 --> No URI present. Default controller set.
INFO - 2023-09-10 13:20:50 --> Router Class Initialized
INFO - 2023-09-10 13:20:50 --> Output Class Initialized
INFO - 2023-09-10 13:20:50 --> Security Class Initialized
DEBUG - 2023-09-10 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:20:50 --> Input Class Initialized
INFO - 2023-09-10 13:20:50 --> Language Class Initialized
INFO - 2023-09-10 13:20:50 --> Loader Class Initialized
INFO - 2023-09-10 13:20:50 --> Helper loaded: url_helper
INFO - 2023-09-10 13:20:50 --> Helper loaded: file_helper
INFO - 2023-09-10 13:20:50 --> Database Driver Class Initialized
INFO - 2023-09-10 13:20:50 --> Email Class Initialized
DEBUG - 2023-09-10 13:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:20:50 --> Controller Class Initialized
INFO - 2023-09-10 13:20:50 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:20:50 --> Model "Home_model" initialized
INFO - 2023-09-10 13:20:50 --> Helper loaded: download_helper
INFO - 2023-09-10 13:20:50 --> Helper loaded: form_helper
INFO - 2023-09-10 13:20:50 --> Form Validation Class Initialized
INFO - 2023-09-10 13:20:50 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:20:50 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:20:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:20:50 --> Final output sent to browser
DEBUG - 2023-09-10 13:20:50 --> Total execution time: 4.2695
INFO - 2023-09-10 13:20:55 --> Config Class Initialized
INFO - 2023-09-10 13:20:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:20:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:20:55 --> Utf8 Class Initialized
INFO - 2023-09-10 13:20:55 --> URI Class Initialized
INFO - 2023-09-10 13:20:55 --> Router Class Initialized
INFO - 2023-09-10 13:20:55 --> Output Class Initialized
INFO - 2023-09-10 13:20:55 --> Security Class Initialized
DEBUG - 2023-09-10 13:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:20:55 --> Input Class Initialized
INFO - 2023-09-10 13:20:55 --> Language Class Initialized
ERROR - 2023-09-10 13:20:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:20:56 --> Config Class Initialized
INFO - 2023-09-10 13:20:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:20:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:20:56 --> Utf8 Class Initialized
INFO - 2023-09-10 13:20:56 --> URI Class Initialized
INFO - 2023-09-10 13:20:56 --> Router Class Initialized
INFO - 2023-09-10 13:20:56 --> Output Class Initialized
INFO - 2023-09-10 13:20:56 --> Security Class Initialized
DEBUG - 2023-09-10 13:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:20:56 --> Input Class Initialized
INFO - 2023-09-10 13:20:56 --> Language Class Initialized
ERROR - 2023-09-10 13:20:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:20:56 --> Config Class Initialized
INFO - 2023-09-10 13:20:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:20:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:20:56 --> Utf8 Class Initialized
INFO - 2023-09-10 13:20:56 --> URI Class Initialized
INFO - 2023-09-10 13:20:56 --> Router Class Initialized
INFO - 2023-09-10 13:20:56 --> Output Class Initialized
INFO - 2023-09-10 13:20:56 --> Security Class Initialized
DEBUG - 2023-09-10 13:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:20:56 --> Input Class Initialized
INFO - 2023-09-10 13:20:56 --> Language Class Initialized
ERROR - 2023-09-10 13:20:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:00 --> Config Class Initialized
INFO - 2023-09-10 13:21:00 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:01 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:02 --> URI Class Initialized
INFO - 2023-09-10 13:21:03 --> Config Class Initialized
INFO - 2023-09-10 13:21:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:03 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:03 --> URI Class Initialized
INFO - 2023-09-10 13:21:03 --> Router Class Initialized
INFO - 2023-09-10 13:21:03 --> Output Class Initialized
INFO - 2023-09-10 13:21:03 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:03 --> Input Class Initialized
INFO - 2023-09-10 13:21:03 --> Language Class Initialized
ERROR - 2023-09-10 13:21:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:03 --> Config Class Initialized
INFO - 2023-09-10 13:21:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:04 --> Router Class Initialized
INFO - 2023-09-10 13:21:07 --> Config Class Initialized
INFO - 2023-09-10 13:21:08 --> Output Class Initialized
INFO - 2023-09-10 13:21:18 --> Config Class Initialized
INFO - 2023-09-10 13:21:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:21 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:21 --> Config Class Initialized
INFO - 2023-09-10 13:21:25 --> Config Class Initialized
INFO - 2023-09-10 13:21:25 --> Config Class Initialized
INFO - 2023-09-10 13:21:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:25 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:25 --> URI Class Initialized
INFO - 2023-09-10 13:21:25 --> Router Class Initialized
INFO - 2023-09-10 13:21:25 --> Output Class Initialized
INFO - 2023-09-10 13:21:25 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:25 --> Input Class Initialized
INFO - 2023-09-10 13:21:25 --> Language Class Initialized
ERROR - 2023-09-10 13:21:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:25 --> Config Class Initialized
INFO - 2023-09-10 13:21:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:25 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:25 --> URI Class Initialized
INFO - 2023-09-10 13:21:25 --> Router Class Initialized
INFO - 2023-09-10 13:21:25 --> Output Class Initialized
INFO - 2023-09-10 13:21:25 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:25 --> Input Class Initialized
INFO - 2023-09-10 13:21:25 --> Language Class Initialized
ERROR - 2023-09-10 13:21:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:25 --> URI Class Initialized
INFO - 2023-09-10 13:21:25 --> Config Class Initialized
INFO - 2023-09-10 13:21:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:25 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:25 --> URI Class Initialized
INFO - 2023-09-10 13:21:25 --> Router Class Initialized
INFO - 2023-09-10 13:21:25 --> Output Class Initialized
INFO - 2023-09-10 13:21:25 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:25 --> Input Class Initialized
INFO - 2023-09-10 13:21:25 --> Language Class Initialized
ERROR - 2023-09-10 13:21:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:26 --> Hooks Class Initialized
INFO - 2023-09-10 13:21:27 --> Config Class Initialized
INFO - 2023-09-10 13:21:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:27 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:27 --> URI Class Initialized
INFO - 2023-09-10 13:21:27 --> Router Class Initialized
INFO - 2023-09-10 13:21:27 --> Output Class Initialized
INFO - 2023-09-10 13:21:27 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:27 --> Input Class Initialized
INFO - 2023-09-10 13:21:27 --> Language Class Initialized
ERROR - 2023-09-10 13:21:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:27 --> Router Class Initialized
INFO - 2023-09-10 13:21:27 --> Output Class Initialized
INFO - 2023-09-10 13:21:27 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:27 --> Input Class Initialized
INFO - 2023-09-10 13:21:27 --> Language Class Initialized
ERROR - 2023-09-10 13:21:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:29 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:30 --> URI Class Initialized
INFO - 2023-09-10 13:21:30 --> Router Class Initialized
INFO - 2023-09-10 13:21:30 --> Output Class Initialized
INFO - 2023-09-10 13:21:30 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:30 --> Input Class Initialized
INFO - 2023-09-10 13:21:30 --> Language Class Initialized
ERROR - 2023-09-10 13:21:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:21:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:32 --> URI Class Initialized
INFO - 2023-09-10 13:21:32 --> Router Class Initialized
INFO - 2023-09-10 13:21:32 --> Output Class Initialized
INFO - 2023-09-10 13:21:33 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:34 --> Input Class Initialized
INFO - 2023-09-10 13:21:34 --> Language Class Initialized
ERROR - 2023-09-10 13:21:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:21:47 --> Config Class Initialized
INFO - 2023-09-10 13:21:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:21:47 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:21:47 --> Utf8 Class Initialized
INFO - 2023-09-10 13:21:47 --> URI Class Initialized
DEBUG - 2023-09-10 13:21:47 --> No URI present. Default controller set.
INFO - 2023-09-10 13:21:47 --> Router Class Initialized
INFO - 2023-09-10 13:21:47 --> Output Class Initialized
INFO - 2023-09-10 13:21:47 --> Security Class Initialized
DEBUG - 2023-09-10 13:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:21:47 --> Input Class Initialized
INFO - 2023-09-10 13:21:47 --> Language Class Initialized
INFO - 2023-09-10 13:21:47 --> Loader Class Initialized
INFO - 2023-09-10 13:21:47 --> Helper loaded: url_helper
INFO - 2023-09-10 13:21:47 --> Helper loaded: file_helper
INFO - 2023-09-10 13:21:48 --> Database Driver Class Initialized
INFO - 2023-09-10 13:21:48 --> Email Class Initialized
DEBUG - 2023-09-10 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:21:48 --> Controller Class Initialized
INFO - 2023-09-10 13:21:48 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:21:48 --> Model "Home_model" initialized
INFO - 2023-09-10 13:21:48 --> Helper loaded: download_helper
INFO - 2023-09-10 13:21:48 --> Helper loaded: form_helper
INFO - 2023-09-10 13:21:48 --> Form Validation Class Initialized
INFO - 2023-09-10 13:21:48 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:21:48 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:21:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:21:48 --> Final output sent to browser
DEBUG - 2023-09-10 13:21:48 --> Total execution time: 0.7793
INFO - 2023-09-10 13:22:04 --> Config Class Initialized
INFO - 2023-09-10 13:22:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:04 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:04 --> URI Class Initialized
DEBUG - 2023-09-10 13:22:04 --> No URI present. Default controller set.
INFO - 2023-09-10 13:22:04 --> Router Class Initialized
INFO - 2023-09-10 13:22:04 --> Output Class Initialized
INFO - 2023-09-10 13:22:04 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:04 --> Input Class Initialized
INFO - 2023-09-10 13:22:04 --> Language Class Initialized
INFO - 2023-09-10 13:22:04 --> Loader Class Initialized
INFO - 2023-09-10 13:22:04 --> Helper loaded: url_helper
INFO - 2023-09-10 13:22:04 --> Helper loaded: file_helper
INFO - 2023-09-10 13:22:04 --> Database Driver Class Initialized
INFO - 2023-09-10 13:22:04 --> Email Class Initialized
DEBUG - 2023-09-10 13:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:22:05 --> Controller Class Initialized
INFO - 2023-09-10 13:22:05 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:22:05 --> Model "Home_model" initialized
INFO - 2023-09-10 13:22:05 --> Helper loaded: download_helper
INFO - 2023-09-10 13:22:05 --> Helper loaded: form_helper
INFO - 2023-09-10 13:22:05 --> Form Validation Class Initialized
INFO - 2023-09-10 13:22:05 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:22:05 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:22:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:22:05 --> Final output sent to browser
DEBUG - 2023-09-10 13:22:05 --> Total execution time: 1.0439
INFO - 2023-09-10 13:22:31 --> Config Class Initialized
INFO - 2023-09-10 13:22:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:32 --> URI Class Initialized
INFO - 2023-09-10 13:22:32 --> Router Class Initialized
INFO - 2023-09-10 13:22:32 --> Output Class Initialized
INFO - 2023-09-10 13:22:32 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:32 --> Input Class Initialized
INFO - 2023-09-10 13:22:32 --> Language Class Initialized
ERROR - 2023-09-10 13:22:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:32 --> Config Class Initialized
INFO - 2023-09-10 13:22:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:32 --> URI Class Initialized
INFO - 2023-09-10 13:22:32 --> Router Class Initialized
INFO - 2023-09-10 13:22:32 --> Output Class Initialized
INFO - 2023-09-10 13:22:32 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:32 --> Input Class Initialized
INFO - 2023-09-10 13:22:32 --> Language Class Initialized
ERROR - 2023-09-10 13:22:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:32 --> Config Class Initialized
INFO - 2023-09-10 13:22:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:32 --> URI Class Initialized
INFO - 2023-09-10 13:22:32 --> Router Class Initialized
INFO - 2023-09-10 13:22:32 --> Output Class Initialized
INFO - 2023-09-10 13:22:32 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:32 --> Input Class Initialized
INFO - 2023-09-10 13:22:32 --> Language Class Initialized
ERROR - 2023-09-10 13:22:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:33 --> Config Class Initialized
INFO - 2023-09-10 13:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:33 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:33 --> URI Class Initialized
INFO - 2023-09-10 13:22:33 --> Router Class Initialized
INFO - 2023-09-10 13:22:33 --> Output Class Initialized
INFO - 2023-09-10 13:22:33 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:33 --> Input Class Initialized
INFO - 2023-09-10 13:22:33 --> Language Class Initialized
ERROR - 2023-09-10 13:22:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:34 --> Config Class Initialized
INFO - 2023-09-10 13:22:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:34 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:34 --> URI Class Initialized
INFO - 2023-09-10 13:22:34 --> Router Class Initialized
INFO - 2023-09-10 13:22:34 --> Output Class Initialized
INFO - 2023-09-10 13:22:34 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:34 --> Input Class Initialized
INFO - 2023-09-10 13:22:34 --> Language Class Initialized
ERROR - 2023-09-10 13:22:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:34 --> Config Class Initialized
INFO - 2023-09-10 13:22:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:35 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:35 --> URI Class Initialized
INFO - 2023-09-10 13:22:35 --> Router Class Initialized
INFO - 2023-09-10 13:22:35 --> Output Class Initialized
INFO - 2023-09-10 13:22:35 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:35 --> Input Class Initialized
INFO - 2023-09-10 13:22:35 --> Language Class Initialized
ERROR - 2023-09-10 13:22:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:22:35 --> Config Class Initialized
INFO - 2023-09-10 13:22:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:22:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:22:36 --> Utf8 Class Initialized
INFO - 2023-09-10 13:22:37 --> URI Class Initialized
INFO - 2023-09-10 13:22:38 --> Router Class Initialized
INFO - 2023-09-10 13:22:39 --> Output Class Initialized
INFO - 2023-09-10 13:22:39 --> Security Class Initialized
DEBUG - 2023-09-10 13:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:22:39 --> Input Class Initialized
INFO - 2023-09-10 13:22:39 --> Language Class Initialized
ERROR - 2023-09-10 13:22:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:26:34 --> Config Class Initialized
INFO - 2023-09-10 13:26:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:26:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:26:34 --> Utf8 Class Initialized
INFO - 2023-09-10 13:26:34 --> URI Class Initialized
DEBUG - 2023-09-10 13:26:34 --> No URI present. Default controller set.
INFO - 2023-09-10 13:26:34 --> Router Class Initialized
INFO - 2023-09-10 13:26:34 --> Output Class Initialized
INFO - 2023-09-10 13:26:34 --> Security Class Initialized
DEBUG - 2023-09-10 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:26:34 --> Input Class Initialized
INFO - 2023-09-10 13:26:34 --> Language Class Initialized
INFO - 2023-09-10 13:26:34 --> Loader Class Initialized
INFO - 2023-09-10 13:26:34 --> Helper loaded: url_helper
INFO - 2023-09-10 13:26:34 --> Helper loaded: file_helper
INFO - 2023-09-10 13:26:34 --> Database Driver Class Initialized
INFO - 2023-09-10 13:26:34 --> Email Class Initialized
DEBUG - 2023-09-10 13:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:26:34 --> Controller Class Initialized
INFO - 2023-09-10 13:26:34 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:26:34 --> Model "Home_model" initialized
INFO - 2023-09-10 13:26:34 --> Helper loaded: download_helper
INFO - 2023-09-10 13:26:34 --> Helper loaded: form_helper
INFO - 2023-09-10 13:26:34 --> Form Validation Class Initialized
INFO - 2023-09-10 13:26:35 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:26:35 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:26:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:26:35 --> Final output sent to browser
DEBUG - 2023-09-10 13:26:35 --> Total execution time: 0.5465
INFO - 2023-09-10 13:28:54 --> Config Class Initialized
INFO - 2023-09-10 13:28:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:28:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:28:54 --> Utf8 Class Initialized
INFO - 2023-09-10 13:28:54 --> URI Class Initialized
DEBUG - 2023-09-10 13:28:54 --> No URI present. Default controller set.
INFO - 2023-09-10 13:28:54 --> Router Class Initialized
INFO - 2023-09-10 13:28:54 --> Output Class Initialized
INFO - 2023-09-10 13:28:54 --> Security Class Initialized
DEBUG - 2023-09-10 13:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:28:54 --> Input Class Initialized
INFO - 2023-09-10 13:28:54 --> Language Class Initialized
INFO - 2023-09-10 13:28:54 --> Loader Class Initialized
INFO - 2023-09-10 13:28:54 --> Helper loaded: url_helper
INFO - 2023-09-10 13:28:54 --> Helper loaded: file_helper
INFO - 2023-09-10 13:28:54 --> Database Driver Class Initialized
INFO - 2023-09-10 13:28:54 --> Email Class Initialized
DEBUG - 2023-09-10 13:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:28:54 --> Controller Class Initialized
INFO - 2023-09-10 13:28:54 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:28:54 --> Model "Home_model" initialized
INFO - 2023-09-10 13:28:55 --> Helper loaded: download_helper
INFO - 2023-09-10 13:28:55 --> Helper loaded: form_helper
INFO - 2023-09-10 13:28:55 --> Form Validation Class Initialized
INFO - 2023-09-10 13:28:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:28:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:28:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:28:57 --> Final output sent to browser
DEBUG - 2023-09-10 13:28:57 --> Total execution time: 3.1228
INFO - 2023-09-10 13:29:02 --> Config Class Initialized
INFO - 2023-09-10 13:29:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:29:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:02 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:02 --> URI Class Initialized
INFO - 2023-09-10 13:29:02 --> Router Class Initialized
INFO - 2023-09-10 13:29:02 --> Output Class Initialized
INFO - 2023-09-10 13:29:02 --> Security Class Initialized
DEBUG - 2023-09-10 13:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:29:02 --> Input Class Initialized
INFO - 2023-09-10 13:29:02 --> Language Class Initialized
ERROR - 2023-09-10 13:29:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:29:05 --> Config Class Initialized
INFO - 2023-09-10 13:29:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:08 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:08 --> Config Class Initialized
INFO - 2023-09-10 13:29:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:29:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:08 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:08 --> URI Class Initialized
INFO - 2023-09-10 13:29:08 --> Router Class Initialized
INFO - 2023-09-10 13:29:08 --> Output Class Initialized
INFO - 2023-09-10 13:29:08 --> Security Class Initialized
DEBUG - 2023-09-10 13:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:29:08 --> Input Class Initialized
INFO - 2023-09-10 13:29:08 --> Language Class Initialized
ERROR - 2023-09-10 13:29:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:29:10 --> Config Class Initialized
INFO - 2023-09-10 13:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:10 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:10 --> URI Class Initialized
INFO - 2023-09-10 13:29:10 --> Router Class Initialized
INFO - 2023-09-10 13:29:10 --> Output Class Initialized
INFO - 2023-09-10 13:29:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:29:10 --> Input Class Initialized
INFO - 2023-09-10 13:29:10 --> Language Class Initialized
ERROR - 2023-09-10 13:29:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:29:14 --> Config Class Initialized
INFO - 2023-09-10 13:29:14 --> Hooks Class Initialized
INFO - 2023-09-10 13:29:15 --> Config Class Initialized
DEBUG - 2023-09-10 13:29:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:15 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:29:16 --> URI Class Initialized
INFO - 2023-09-10 13:29:16 --> Utf8 Class Initialized
INFO - 2023-09-10 13:29:16 --> Router Class Initialized
INFO - 2023-09-10 13:29:16 --> URI Class Initialized
INFO - 2023-09-10 13:29:16 --> Output Class Initialized
INFO - 2023-09-10 13:29:16 --> Router Class Initialized
INFO - 2023-09-10 13:29:16 --> Security Class Initialized
INFO - 2023-09-10 13:29:16 --> Output Class Initialized
DEBUG - 2023-09-10 13:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:29:16 --> Security Class Initialized
INFO - 2023-09-10 13:29:16 --> Input Class Initialized
DEBUG - 2023-09-10 13:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:29:16 --> Language Class Initialized
INFO - 2023-09-10 13:29:16 --> Input Class Initialized
INFO - 2023-09-10 13:29:16 --> Language Class Initialized
ERROR - 2023-09-10 13:29:16 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:29:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:30:13 --> Config Class Initialized
INFO - 2023-09-10 13:30:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:30:14 --> Utf8 Class Initialized
INFO - 2023-09-10 13:30:14 --> URI Class Initialized
DEBUG - 2023-09-10 13:30:14 --> No URI present. Default controller set.
INFO - 2023-09-10 13:30:14 --> Router Class Initialized
INFO - 2023-09-10 13:30:14 --> Output Class Initialized
INFO - 2023-09-10 13:30:14 --> Security Class Initialized
DEBUG - 2023-09-10 13:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:30:14 --> Input Class Initialized
INFO - 2023-09-10 13:30:14 --> Language Class Initialized
INFO - 2023-09-10 13:30:14 --> Loader Class Initialized
INFO - 2023-09-10 13:30:14 --> Helper loaded: url_helper
INFO - 2023-09-10 13:30:14 --> Helper loaded: file_helper
INFO - 2023-09-10 13:30:14 --> Database Driver Class Initialized
INFO - 2023-09-10 13:30:14 --> Email Class Initialized
DEBUG - 2023-09-10 13:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:30:15 --> Controller Class Initialized
INFO - 2023-09-10 13:30:15 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:30:15 --> Model "Home_model" initialized
INFO - 2023-09-10 13:30:15 --> Helper loaded: download_helper
INFO - 2023-09-10 13:30:15 --> Helper loaded: form_helper
INFO - 2023-09-10 13:30:15 --> Form Validation Class Initialized
INFO - 2023-09-10 13:30:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:30:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:30:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:30:15 --> Final output sent to browser
DEBUG - 2023-09-10 13:30:15 --> Total execution time: 1.8596
INFO - 2023-09-10 13:31:38 --> Config Class Initialized
INFO - 2023-09-10 13:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:31:39 --> Utf8 Class Initialized
INFO - 2023-09-10 13:31:39 --> URI Class Initialized
DEBUG - 2023-09-10 13:31:40 --> No URI present. Default controller set.
INFO - 2023-09-10 13:31:40 --> Router Class Initialized
INFO - 2023-09-10 13:31:40 --> Output Class Initialized
INFO - 2023-09-10 13:31:41 --> Security Class Initialized
DEBUG - 2023-09-10 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:31:42 --> Input Class Initialized
INFO - 2023-09-10 13:31:42 --> Language Class Initialized
INFO - 2023-09-10 13:31:43 --> Loader Class Initialized
INFO - 2023-09-10 13:31:43 --> Helper loaded: url_helper
INFO - 2023-09-10 13:31:43 --> Helper loaded: file_helper
INFO - 2023-09-10 13:31:43 --> Database Driver Class Initialized
INFO - 2023-09-10 13:31:44 --> Email Class Initialized
DEBUG - 2023-09-10 13:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:31:44 --> Controller Class Initialized
INFO - 2023-09-10 13:31:44 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:31:44 --> Model "Home_model" initialized
INFO - 2023-09-10 13:31:44 --> Helper loaded: download_helper
INFO - 2023-09-10 13:31:44 --> Helper loaded: form_helper
INFO - 2023-09-10 13:31:44 --> Form Validation Class Initialized
INFO - 2023-09-10 13:31:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:31:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:31:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:31:45 --> Final output sent to browser
DEBUG - 2023-09-10 13:31:45 --> Total execution time: 8.6290
INFO - 2023-09-10 13:32:40 --> Config Class Initialized
INFO - 2023-09-10 13:32:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:32:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:32:44 --> Utf8 Class Initialized
INFO - 2023-09-10 13:32:45 --> URI Class Initialized
DEBUG - 2023-09-10 13:32:45 --> No URI present. Default controller set.
INFO - 2023-09-10 13:32:46 --> Router Class Initialized
INFO - 2023-09-10 13:32:46 --> Output Class Initialized
INFO - 2023-09-10 13:32:47 --> Security Class Initialized
DEBUG - 2023-09-10 13:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:32:47 --> Input Class Initialized
INFO - 2023-09-10 13:32:48 --> Language Class Initialized
INFO - 2023-09-10 13:32:48 --> Loader Class Initialized
INFO - 2023-09-10 13:32:49 --> Helper loaded: url_helper
INFO - 2023-09-10 13:32:49 --> Helper loaded: file_helper
INFO - 2023-09-10 13:32:49 --> Database Driver Class Initialized
INFO - 2023-09-10 13:32:49 --> Email Class Initialized
DEBUG - 2023-09-10 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:32:49 --> Controller Class Initialized
INFO - 2023-09-10 13:32:49 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:32:49 --> Model "Home_model" initialized
INFO - 2023-09-10 13:32:49 --> Helper loaded: download_helper
INFO - 2023-09-10 13:32:49 --> Helper loaded: form_helper
INFO - 2023-09-10 13:32:49 --> Form Validation Class Initialized
INFO - 2023-09-10 13:32:49 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:32:49 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:32:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:32:52 --> Final output sent to browser
DEBUG - 2023-09-10 13:32:52 --> Total execution time: 12.1484
INFO - 2023-09-10 13:33:18 --> Config Class Initialized
INFO - 2023-09-10 13:33:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:33:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:33:18 --> Utf8 Class Initialized
INFO - 2023-09-10 13:33:18 --> URI Class Initialized
DEBUG - 2023-09-10 13:33:18 --> No URI present. Default controller set.
INFO - 2023-09-10 13:33:18 --> Router Class Initialized
INFO - 2023-09-10 13:33:18 --> Output Class Initialized
INFO - 2023-09-10 13:33:18 --> Security Class Initialized
DEBUG - 2023-09-10 13:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:33:18 --> Input Class Initialized
INFO - 2023-09-10 13:33:18 --> Language Class Initialized
INFO - 2023-09-10 13:33:18 --> Loader Class Initialized
INFO - 2023-09-10 13:33:18 --> Helper loaded: url_helper
INFO - 2023-09-10 13:33:18 --> Helper loaded: file_helper
INFO - 2023-09-10 13:33:18 --> Database Driver Class Initialized
INFO - 2023-09-10 13:33:18 --> Email Class Initialized
DEBUG - 2023-09-10 13:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:33:19 --> Controller Class Initialized
INFO - 2023-09-10 13:33:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:33:20 --> Model "Home_model" initialized
INFO - 2023-09-10 13:33:20 --> Helper loaded: download_helper
INFO - 2023-09-10 13:33:20 --> Helper loaded: form_helper
INFO - 2023-09-10 13:33:20 --> Form Validation Class Initialized
INFO - 2023-09-10 13:33:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:33:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:33:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:33:20 --> Final output sent to browser
DEBUG - 2023-09-10 13:33:20 --> Total execution time: 1.4519
INFO - 2023-09-10 13:33:51 --> Config Class Initialized
INFO - 2023-09-10 13:33:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:33:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:33:51 --> Utf8 Class Initialized
INFO - 2023-09-10 13:33:51 --> URI Class Initialized
DEBUG - 2023-09-10 13:33:51 --> No URI present. Default controller set.
INFO - 2023-09-10 13:33:51 --> Router Class Initialized
INFO - 2023-09-10 13:33:51 --> Output Class Initialized
INFO - 2023-09-10 13:33:51 --> Security Class Initialized
DEBUG - 2023-09-10 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:33:51 --> Input Class Initialized
INFO - 2023-09-10 13:33:51 --> Language Class Initialized
INFO - 2023-09-10 13:33:51 --> Loader Class Initialized
INFO - 2023-09-10 13:33:51 --> Helper loaded: url_helper
INFO - 2023-09-10 13:33:51 --> Helper loaded: file_helper
INFO - 2023-09-10 13:33:51 --> Database Driver Class Initialized
INFO - 2023-09-10 13:33:51 --> Email Class Initialized
DEBUG - 2023-09-10 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:33:51 --> Controller Class Initialized
INFO - 2023-09-10 13:33:51 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:33:51 --> Model "Home_model" initialized
INFO - 2023-09-10 13:33:51 --> Helper loaded: download_helper
INFO - 2023-09-10 13:33:51 --> Helper loaded: form_helper
INFO - 2023-09-10 13:33:51 --> Form Validation Class Initialized
INFO - 2023-09-10 13:33:52 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:33:52 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:33:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:33:52 --> Final output sent to browser
DEBUG - 2023-09-10 13:33:52 --> Total execution time: 0.9275
INFO - 2023-09-10 13:34:34 --> Config Class Initialized
INFO - 2023-09-10 13:34:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:34:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:34:34 --> Utf8 Class Initialized
INFO - 2023-09-10 13:34:34 --> URI Class Initialized
DEBUG - 2023-09-10 13:34:34 --> No URI present. Default controller set.
INFO - 2023-09-10 13:34:34 --> Router Class Initialized
INFO - 2023-09-10 13:34:34 --> Output Class Initialized
INFO - 2023-09-10 13:34:34 --> Security Class Initialized
DEBUG - 2023-09-10 13:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:34:34 --> Input Class Initialized
INFO - 2023-09-10 13:34:34 --> Language Class Initialized
INFO - 2023-09-10 13:34:34 --> Loader Class Initialized
INFO - 2023-09-10 13:34:34 --> Helper loaded: url_helper
INFO - 2023-09-10 13:34:34 --> Helper loaded: file_helper
INFO - 2023-09-10 13:34:34 --> Database Driver Class Initialized
INFO - 2023-09-10 13:34:34 --> Email Class Initialized
DEBUG - 2023-09-10 13:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:34:34 --> Controller Class Initialized
INFO - 2023-09-10 13:34:34 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:34:34 --> Model "Home_model" initialized
INFO - 2023-09-10 13:34:34 --> Helper loaded: download_helper
INFO - 2023-09-10 13:34:34 --> Helper loaded: form_helper
INFO - 2023-09-10 13:34:34 --> Form Validation Class Initialized
INFO - 2023-09-10 13:34:34 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:34:34 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:34:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:34:35 --> Final output sent to browser
DEBUG - 2023-09-10 13:34:35 --> Total execution time: 0.8338
INFO - 2023-09-10 13:34:51 --> Config Class Initialized
INFO - 2023-09-10 13:34:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:34:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:34:51 --> Utf8 Class Initialized
INFO - 2023-09-10 13:34:51 --> URI Class Initialized
DEBUG - 2023-09-10 13:34:51 --> No URI present. Default controller set.
INFO - 2023-09-10 13:34:51 --> Router Class Initialized
INFO - 2023-09-10 13:34:51 --> Output Class Initialized
INFO - 2023-09-10 13:34:51 --> Security Class Initialized
DEBUG - 2023-09-10 13:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:34:51 --> Input Class Initialized
INFO - 2023-09-10 13:34:51 --> Language Class Initialized
INFO - 2023-09-10 13:34:51 --> Loader Class Initialized
INFO - 2023-09-10 13:34:51 --> Helper loaded: url_helper
INFO - 2023-09-10 13:34:51 --> Helper loaded: file_helper
INFO - 2023-09-10 13:34:51 --> Database Driver Class Initialized
INFO - 2023-09-10 13:34:51 --> Email Class Initialized
DEBUG - 2023-09-10 13:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:34:52 --> Controller Class Initialized
INFO - 2023-09-10 13:34:52 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:34:52 --> Model "Home_model" initialized
INFO - 2023-09-10 13:34:52 --> Helper loaded: download_helper
INFO - 2023-09-10 13:34:52 --> Helper loaded: form_helper
INFO - 2023-09-10 13:34:52 --> Form Validation Class Initialized
INFO - 2023-09-10 13:34:52 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:34:52 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:34:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:34:52 --> Final output sent to browser
DEBUG - 2023-09-10 13:34:52 --> Total execution time: 1.2956
INFO - 2023-09-10 13:35:22 --> Config Class Initialized
INFO - 2023-09-10 13:35:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:35:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:35:23 --> Utf8 Class Initialized
INFO - 2023-09-10 13:35:23 --> URI Class Initialized
DEBUG - 2023-09-10 13:35:23 --> No URI present. Default controller set.
INFO - 2023-09-10 13:35:23 --> Router Class Initialized
INFO - 2023-09-10 13:35:23 --> Output Class Initialized
INFO - 2023-09-10 13:35:23 --> Security Class Initialized
DEBUG - 2023-09-10 13:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:35:23 --> Input Class Initialized
INFO - 2023-09-10 13:35:23 --> Language Class Initialized
INFO - 2023-09-10 13:35:23 --> Loader Class Initialized
INFO - 2023-09-10 13:35:23 --> Helper loaded: url_helper
INFO - 2023-09-10 13:35:23 --> Helper loaded: file_helper
INFO - 2023-09-10 13:35:23 --> Database Driver Class Initialized
INFO - 2023-09-10 13:35:23 --> Email Class Initialized
DEBUG - 2023-09-10 13:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:35:23 --> Controller Class Initialized
INFO - 2023-09-10 13:35:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:35:23 --> Model "Home_model" initialized
INFO - 2023-09-10 13:35:23 --> Helper loaded: download_helper
INFO - 2023-09-10 13:35:24 --> Helper loaded: form_helper
INFO - 2023-09-10 13:35:24 --> Form Validation Class Initialized
INFO - 2023-09-10 13:35:24 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:35:24 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:35:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:35:24 --> Final output sent to browser
DEBUG - 2023-09-10 13:35:24 --> Total execution time: 1.3333
INFO - 2023-09-10 13:35:38 --> Config Class Initialized
INFO - 2023-09-10 13:35:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:35:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:35:38 --> Utf8 Class Initialized
INFO - 2023-09-10 13:35:38 --> URI Class Initialized
DEBUG - 2023-09-10 13:35:38 --> No URI present. Default controller set.
INFO - 2023-09-10 13:35:38 --> Router Class Initialized
INFO - 2023-09-10 13:35:38 --> Output Class Initialized
INFO - 2023-09-10 13:35:38 --> Security Class Initialized
DEBUG - 2023-09-10 13:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:35:38 --> Input Class Initialized
INFO - 2023-09-10 13:35:38 --> Language Class Initialized
INFO - 2023-09-10 13:35:38 --> Loader Class Initialized
INFO - 2023-09-10 13:35:38 --> Helper loaded: url_helper
INFO - 2023-09-10 13:35:38 --> Helper loaded: file_helper
INFO - 2023-09-10 13:35:38 --> Database Driver Class Initialized
INFO - 2023-09-10 13:35:38 --> Email Class Initialized
DEBUG - 2023-09-10 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:35:38 --> Controller Class Initialized
INFO - 2023-09-10 13:35:39 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:35:39 --> Model "Home_model" initialized
INFO - 2023-09-10 13:35:39 --> Helper loaded: download_helper
INFO - 2023-09-10 13:35:39 --> Helper loaded: form_helper
INFO - 2023-09-10 13:35:39 --> Form Validation Class Initialized
INFO - 2023-09-10 13:35:39 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:35:39 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:35:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:35:39 --> Final output sent to browser
DEBUG - 2023-09-10 13:35:39 --> Total execution time: 1.3005
INFO - 2023-09-10 13:36:24 --> Config Class Initialized
INFO - 2023-09-10 13:36:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:36:24 --> Utf8 Class Initialized
INFO - 2023-09-10 13:36:24 --> URI Class Initialized
DEBUG - 2023-09-10 13:36:25 --> No URI present. Default controller set.
INFO - 2023-09-10 13:36:25 --> Router Class Initialized
INFO - 2023-09-10 13:36:25 --> Output Class Initialized
INFO - 2023-09-10 13:36:25 --> Security Class Initialized
DEBUG - 2023-09-10 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:36:25 --> Input Class Initialized
INFO - 2023-09-10 13:36:25 --> Language Class Initialized
INFO - 2023-09-10 13:36:25 --> Loader Class Initialized
INFO - 2023-09-10 13:36:25 --> Helper loaded: url_helper
INFO - 2023-09-10 13:36:25 --> Helper loaded: file_helper
INFO - 2023-09-10 13:36:25 --> Database Driver Class Initialized
INFO - 2023-09-10 13:36:25 --> Email Class Initialized
DEBUG - 2023-09-10 13:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:36:25 --> Controller Class Initialized
INFO - 2023-09-10 13:36:25 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:36:25 --> Model "Home_model" initialized
INFO - 2023-09-10 13:36:25 --> Helper loaded: download_helper
INFO - 2023-09-10 13:36:25 --> Helper loaded: form_helper
INFO - 2023-09-10 13:36:25 --> Form Validation Class Initialized
INFO - 2023-09-10 13:36:25 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:36:25 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:36:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:36:26 --> Final output sent to browser
DEBUG - 2023-09-10 13:36:26 --> Total execution time: 1.3003
INFO - 2023-09-10 13:37:04 --> Config Class Initialized
INFO - 2023-09-10 13:37:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:04 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:04 --> URI Class Initialized
INFO - 2023-09-10 13:37:04 --> Router Class Initialized
INFO - 2023-09-10 13:37:04 --> Output Class Initialized
INFO - 2023-09-10 13:37:05 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:05 --> Input Class Initialized
INFO - 2023-09-10 13:37:05 --> Language Class Initialized
ERROR - 2023-09-10 13:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:05 --> Config Class Initialized
INFO - 2023-09-10 13:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:05 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:05 --> URI Class Initialized
INFO - 2023-09-10 13:37:05 --> Router Class Initialized
INFO - 2023-09-10 13:37:05 --> Output Class Initialized
INFO - 2023-09-10 13:37:05 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:05 --> Input Class Initialized
INFO - 2023-09-10 13:37:05 --> Language Class Initialized
ERROR - 2023-09-10 13:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:05 --> Config Class Initialized
INFO - 2023-09-10 13:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:05 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:05 --> URI Class Initialized
INFO - 2023-09-10 13:37:05 --> Router Class Initialized
INFO - 2023-09-10 13:37:05 --> Output Class Initialized
INFO - 2023-09-10 13:37:05 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:05 --> Input Class Initialized
INFO - 2023-09-10 13:37:05 --> Language Class Initialized
ERROR - 2023-09-10 13:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:06 --> Config Class Initialized
INFO - 2023-09-10 13:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:06 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:06 --> URI Class Initialized
INFO - 2023-09-10 13:37:06 --> Router Class Initialized
INFO - 2023-09-10 13:37:06 --> Output Class Initialized
INFO - 2023-09-10 13:37:06 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:06 --> Input Class Initialized
INFO - 2023-09-10 13:37:06 --> Language Class Initialized
ERROR - 2023-09-10 13:37:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:06 --> Config Class Initialized
INFO - 2023-09-10 13:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:06 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:06 --> URI Class Initialized
INFO - 2023-09-10 13:37:06 --> Router Class Initialized
INFO - 2023-09-10 13:37:06 --> Output Class Initialized
INFO - 2023-09-10 13:37:06 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:06 --> Input Class Initialized
INFO - 2023-09-10 13:37:06 --> Language Class Initialized
ERROR - 2023-09-10 13:37:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:06 --> Config Class Initialized
INFO - 2023-09-10 13:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:06 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:06 --> URI Class Initialized
INFO - 2023-09-10 13:37:06 --> Router Class Initialized
INFO - 2023-09-10 13:37:06 --> Output Class Initialized
INFO - 2023-09-10 13:37:06 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:06 --> Input Class Initialized
INFO - 2023-09-10 13:37:06 --> Language Class Initialized
ERROR - 2023-09-10 13:37:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:07 --> Config Class Initialized
INFO - 2023-09-10 13:37:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:07 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:07 --> URI Class Initialized
INFO - 2023-09-10 13:37:07 --> Router Class Initialized
INFO - 2023-09-10 13:37:08 --> Output Class Initialized
INFO - 2023-09-10 13:37:08 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:08 --> Input Class Initialized
INFO - 2023-09-10 13:37:08 --> Language Class Initialized
ERROR - 2023-09-10 13:37:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:44 --> Config Class Initialized
INFO - 2023-09-10 13:37:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:44 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:45 --> URI Class Initialized
DEBUG - 2023-09-10 13:37:45 --> No URI present. Default controller set.
INFO - 2023-09-10 13:37:45 --> Router Class Initialized
INFO - 2023-09-10 13:37:45 --> Output Class Initialized
INFO - 2023-09-10 13:37:45 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:45 --> Input Class Initialized
INFO - 2023-09-10 13:37:45 --> Language Class Initialized
INFO - 2023-09-10 13:37:45 --> Loader Class Initialized
INFO - 2023-09-10 13:37:45 --> Helper loaded: url_helper
INFO - 2023-09-10 13:37:45 --> Helper loaded: file_helper
INFO - 2023-09-10 13:37:45 --> Database Driver Class Initialized
INFO - 2023-09-10 13:37:45 --> Email Class Initialized
DEBUG - 2023-09-10 13:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:37:45 --> Controller Class Initialized
INFO - 2023-09-10 13:37:46 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:37:46 --> Model "Home_model" initialized
INFO - 2023-09-10 13:37:46 --> Helper loaded: download_helper
INFO - 2023-09-10 13:37:46 --> Helper loaded: form_helper
INFO - 2023-09-10 13:37:46 --> Form Validation Class Initialized
INFO - 2023-09-10 13:37:46 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:37:46 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:37:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:37:46 --> Final output sent to browser
DEBUG - 2023-09-10 13:37:46 --> Total execution time: 1.5001
INFO - 2023-09-10 13:37:49 --> Config Class Initialized
INFO - 2023-09-10 13:37:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:50 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:50 --> URI Class Initialized
INFO - 2023-09-10 13:37:51 --> Router Class Initialized
INFO - 2023-09-10 13:37:51 --> Output Class Initialized
INFO - 2023-09-10 13:37:51 --> Config Class Initialized
INFO - 2023-09-10 13:37:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:51 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:51 --> URI Class Initialized
INFO - 2023-09-10 13:37:51 --> Router Class Initialized
INFO - 2023-09-10 13:37:51 --> Output Class Initialized
INFO - 2023-09-10 13:37:52 --> Security Class Initialized
INFO - 2023-09-10 13:37:52 --> Config Class Initialized
INFO - 2023-09-10 13:37:52 --> Config Class Initialized
INFO - 2023-09-10 13:37:52 --> Hooks Class Initialized
INFO - 2023-09-10 13:37:52 --> Config Class Initialized
INFO - 2023-09-10 13:37:52 --> Hooks Class Initialized
INFO - 2023-09-10 13:37:52 --> Security Class Initialized
INFO - 2023-09-10 13:37:52 --> Config Class Initialized
DEBUG - 2023-09-10 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:53 --> Utf8 Class Initialized
DEBUG - 2023-09-10 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:53 --> Input Class Initialized
DEBUG - 2023-09-10 13:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:53 --> Hooks Class Initialized
INFO - 2023-09-10 13:37:53 --> Input Class Initialized
INFO - 2023-09-10 13:37:53 --> URI Class Initialized
INFO - 2023-09-10 13:37:54 --> Language Class Initialized
DEBUG - 2023-09-10 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:54 --> Language Class Initialized
DEBUG - 2023-09-10 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:54 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:54 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:54 --> URI Class Initialized
INFO - 2023-09-10 13:37:54 --> Router Class Initialized
INFO - 2023-09-10 13:37:54 --> Output Class Initialized
INFO - 2023-09-10 13:37:54 --> Security Class Initialized
DEBUG - 2023-09-10 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:54 --> Input Class Initialized
INFO - 2023-09-10 13:37:54 --> Language Class Initialized
ERROR - 2023-09-10 13:37:54 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:37:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:54 --> Router Class Initialized
INFO - 2023-09-10 13:37:54 --> Output Class Initialized
INFO - 2023-09-10 13:37:54 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:54 --> Config Class Initialized
INFO - 2023-09-10 13:37:54 --> URI Class Initialized
INFO - 2023-09-10 13:37:54 --> URI Class Initialized
INFO - 2023-09-10 13:37:54 --> Security Class Initialized
INFO - 2023-09-10 13:37:54 --> Router Class Initialized
INFO - 2023-09-10 13:37:54 --> Hooks Class Initialized
INFO - 2023-09-10 13:37:54 --> Router Class Initialized
ERROR - 2023-09-10 13:37:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:37:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:37:54 --> Utf8 Class Initialized
INFO - 2023-09-10 13:37:54 --> Output Class Initialized
DEBUG - 2023-09-10 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:54 --> Security Class Initialized
INFO - 2023-09-10 13:37:54 --> URI Class Initialized
DEBUG - 2023-09-10 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:54 --> Input Class Initialized
INFO - 2023-09-10 13:37:54 --> Output Class Initialized
INFO - 2023-09-10 13:37:54 --> Input Class Initialized
INFO - 2023-09-10 13:37:54 --> Router Class Initialized
INFO - 2023-09-10 13:37:54 --> Language Class Initialized
INFO - 2023-09-10 13:37:54 --> Language Class Initialized
INFO - 2023-09-10 13:37:54 --> Output Class Initialized
INFO - 2023-09-10 13:37:54 --> Security Class Initialized
ERROR - 2023-09-10 13:37:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:54 --> Security Class Initialized
ERROR - 2023-09-10 13:37:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:37:55 --> Input Class Initialized
INFO - 2023-09-10 13:37:55 --> Language Class Initialized
ERROR - 2023-09-10 13:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:37:55 --> Input Class Initialized
INFO - 2023-09-10 13:37:55 --> Language Class Initialized
ERROR - 2023-09-10 13:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:38:43 --> Config Class Initialized
INFO - 2023-09-10 13:38:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:38:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:43 --> URI Class Initialized
DEBUG - 2023-09-10 13:38:43 --> No URI present. Default controller set.
INFO - 2023-09-10 13:38:43 --> Router Class Initialized
INFO - 2023-09-10 13:38:43 --> Output Class Initialized
INFO - 2023-09-10 13:38:43 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:43 --> Input Class Initialized
INFO - 2023-09-10 13:38:43 --> Language Class Initialized
INFO - 2023-09-10 13:38:43 --> Loader Class Initialized
INFO - 2023-09-10 13:38:43 --> Helper loaded: url_helper
INFO - 2023-09-10 13:38:43 --> Helper loaded: file_helper
INFO - 2023-09-10 13:38:43 --> Database Driver Class Initialized
INFO - 2023-09-10 13:38:43 --> Email Class Initialized
DEBUG - 2023-09-10 13:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:38:44 --> Controller Class Initialized
INFO - 2023-09-10 13:38:44 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:38:44 --> Model "Home_model" initialized
INFO - 2023-09-10 13:38:44 --> Helper loaded: download_helper
INFO - 2023-09-10 13:38:44 --> Helper loaded: form_helper
INFO - 2023-09-10 13:38:44 --> Form Validation Class Initialized
INFO - 2023-09-10 13:38:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:38:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:38:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:38:44 --> Final output sent to browser
DEBUG - 2023-09-10 13:38:44 --> Total execution time: 1.0949
INFO - 2023-09-10 13:38:46 --> Config Class Initialized
INFO - 2023-09-10 13:38:47 --> Hooks Class Initialized
INFO - 2023-09-10 13:38:47 --> Config Class Initialized
INFO - 2023-09-10 13:38:47 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:38:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:48 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:48 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:48 --> URI Class Initialized
INFO - 2023-09-10 13:38:48 --> URI Class Initialized
INFO - 2023-09-10 13:38:48 --> Router Class Initialized
INFO - 2023-09-10 13:38:48 --> Router Class Initialized
INFO - 2023-09-10 13:38:48 --> Output Class Initialized
INFO - 2023-09-10 13:38:48 --> Output Class Initialized
INFO - 2023-09-10 13:38:48 --> Security Class Initialized
INFO - 2023-09-10 13:38:48 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:48 --> Input Class Initialized
INFO - 2023-09-10 13:38:48 --> Input Class Initialized
INFO - 2023-09-10 13:38:48 --> Language Class Initialized
INFO - 2023-09-10 13:38:48 --> Language Class Initialized
ERROR - 2023-09-10 13:38:48 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:38:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:38:49 --> Config Class Initialized
INFO - 2023-09-10 13:38:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:38:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:49 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:49 --> URI Class Initialized
INFO - 2023-09-10 13:38:49 --> Router Class Initialized
INFO - 2023-09-10 13:38:49 --> Output Class Initialized
INFO - 2023-09-10 13:38:49 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:49 --> Input Class Initialized
INFO - 2023-09-10 13:38:49 --> Language Class Initialized
ERROR - 2023-09-10 13:38:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:38:49 --> Config Class Initialized
INFO - 2023-09-10 13:38:49 --> Hooks Class Initialized
INFO - 2023-09-10 13:38:50 --> Config Class Initialized
INFO - 2023-09-10 13:38:50 --> Config Class Initialized
INFO - 2023-09-10 13:38:51 --> Config Class Initialized
INFO - 2023-09-10 13:38:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:38:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:51 --> Hooks Class Initialized
INFO - 2023-09-10 13:38:51 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:38:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:52 --> URI Class Initialized
INFO - 2023-09-10 13:38:52 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:52 --> URI Class Initialized
INFO - 2023-09-10 13:38:52 --> Router Class Initialized
INFO - 2023-09-10 13:38:52 --> Output Class Initialized
INFO - 2023-09-10 13:38:52 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:52 --> Input Class Initialized
INFO - 2023-09-10 13:38:52 --> Language Class Initialized
ERROR - 2023-09-10 13:38:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:38:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:38:52 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:52 --> Utf8 Class Initialized
INFO - 2023-09-10 13:38:52 --> URI Class Initialized
INFO - 2023-09-10 13:38:52 --> Router Class Initialized
INFO - 2023-09-10 13:38:52 --> Router Class Initialized
INFO - 2023-09-10 13:38:53 --> URI Class Initialized
INFO - 2023-09-10 13:38:53 --> Router Class Initialized
INFO - 2023-09-10 13:38:53 --> Output Class Initialized
INFO - 2023-09-10 13:38:53 --> Output Class Initialized
INFO - 2023-09-10 13:38:53 --> Output Class Initialized
INFO - 2023-09-10 13:38:53 --> Security Class Initialized
INFO - 2023-09-10 13:38:53 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:53 --> Security Class Initialized
DEBUG - 2023-09-10 13:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:38:53 --> Input Class Initialized
INFO - 2023-09-10 13:38:53 --> Language Class Initialized
INFO - 2023-09-10 13:38:53 --> Input Class Initialized
ERROR - 2023-09-10 13:38:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:38:53 --> Language Class Initialized
INFO - 2023-09-10 13:38:53 --> Input Class Initialized
INFO - 2023-09-10 13:38:53 --> Language Class Initialized
ERROR - 2023-09-10 13:38:53 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:38:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:39:19 --> Config Class Initialized
INFO - 2023-09-10 13:39:19 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:39:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:39:19 --> Utf8 Class Initialized
INFO - 2023-09-10 13:39:19 --> URI Class Initialized
INFO - 2023-09-10 13:39:19 --> Router Class Initialized
INFO - 2023-09-10 13:39:19 --> Output Class Initialized
INFO - 2023-09-10 13:39:19 --> Security Class Initialized
DEBUG - 2023-09-10 13:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:39:19 --> Input Class Initialized
INFO - 2023-09-10 13:39:19 --> Language Class Initialized
INFO - 2023-09-10 13:39:19 --> Loader Class Initialized
INFO - 2023-09-10 13:39:20 --> Helper loaded: url_helper
INFO - 2023-09-10 13:39:20 --> Helper loaded: file_helper
INFO - 2023-09-10 13:39:20 --> Database Driver Class Initialized
INFO - 2023-09-10 13:39:20 --> Email Class Initialized
DEBUG - 2023-09-10 13:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:39:20 --> Controller Class Initialized
INFO - 2023-09-10 13:39:20 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:39:20 --> Model "Home_model" initialized
INFO - 2023-09-10 13:39:20 --> Helper loaded: download_helper
INFO - 2023-09-10 13:39:20 --> Helper loaded: form_helper
INFO - 2023-09-10 13:39:20 --> Form Validation Class Initialized
INFO - 2023-09-10 13:39:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:39:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:39:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-10 13:39:20 --> Final output sent to browser
DEBUG - 2023-09-10 13:39:20 --> Total execution time: 1.0365
INFO - 2023-09-10 13:44:48 --> Config Class Initialized
INFO - 2023-09-10 13:44:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:44:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:44:48 --> Utf8 Class Initialized
INFO - 2023-09-10 13:44:48 --> URI Class Initialized
DEBUG - 2023-09-10 13:44:48 --> No URI present. Default controller set.
INFO - 2023-09-10 13:44:48 --> Router Class Initialized
INFO - 2023-09-10 13:44:48 --> Output Class Initialized
INFO - 2023-09-10 13:44:48 --> Security Class Initialized
DEBUG - 2023-09-10 13:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:44:48 --> Input Class Initialized
INFO - 2023-09-10 13:44:48 --> Language Class Initialized
INFO - 2023-09-10 13:44:48 --> Loader Class Initialized
INFO - 2023-09-10 13:44:48 --> Helper loaded: url_helper
INFO - 2023-09-10 13:44:48 --> Helper loaded: file_helper
INFO - 2023-09-10 13:44:48 --> Database Driver Class Initialized
INFO - 2023-09-10 13:44:48 --> Email Class Initialized
DEBUG - 2023-09-10 13:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:44:49 --> Controller Class Initialized
INFO - 2023-09-10 13:44:49 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:44:49 --> Model "Home_model" initialized
INFO - 2023-09-10 13:44:49 --> Helper loaded: download_helper
INFO - 2023-09-10 13:44:49 --> Helper loaded: form_helper
INFO - 2023-09-10 13:44:49 --> Form Validation Class Initialized
INFO - 2023-09-10 13:44:49 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:44:49 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:44:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:44:50 --> Final output sent to browser
DEBUG - 2023-09-10 13:44:50 --> Total execution time: 1.7488
INFO - 2023-09-10 13:45:31 --> Config Class Initialized
INFO - 2023-09-10 13:45:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:45:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:45:31 --> Utf8 Class Initialized
INFO - 2023-09-10 13:45:31 --> URI Class Initialized
DEBUG - 2023-09-10 13:45:31 --> No URI present. Default controller set.
INFO - 2023-09-10 13:45:31 --> Router Class Initialized
INFO - 2023-09-10 13:45:31 --> Output Class Initialized
INFO - 2023-09-10 13:45:31 --> Security Class Initialized
DEBUG - 2023-09-10 13:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:45:31 --> Input Class Initialized
INFO - 2023-09-10 13:45:31 --> Language Class Initialized
INFO - 2023-09-10 13:45:31 --> Loader Class Initialized
INFO - 2023-09-10 13:45:31 --> Helper loaded: url_helper
INFO - 2023-09-10 13:45:31 --> Helper loaded: file_helper
INFO - 2023-09-10 13:45:31 --> Database Driver Class Initialized
INFO - 2023-09-10 13:45:31 --> Email Class Initialized
DEBUG - 2023-09-10 13:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:45:31 --> Controller Class Initialized
INFO - 2023-09-10 13:45:31 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:45:32 --> Model "Home_model" initialized
INFO - 2023-09-10 13:45:32 --> Helper loaded: download_helper
INFO - 2023-09-10 13:45:32 --> Helper loaded: form_helper
INFO - 2023-09-10 13:45:32 --> Form Validation Class Initialized
INFO - 2023-09-10 13:45:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:45:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:45:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:45:32 --> Final output sent to browser
DEBUG - 2023-09-10 13:45:32 --> Total execution time: 1.2824
INFO - 2023-09-10 13:45:39 --> Config Class Initialized
INFO - 2023-09-10 13:45:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:45:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:45:39 --> Utf8 Class Initialized
INFO - 2023-09-10 13:45:39 --> URI Class Initialized
INFO - 2023-09-10 13:45:39 --> Router Class Initialized
INFO - 2023-09-10 13:45:39 --> Output Class Initialized
INFO - 2023-09-10 13:45:39 --> Security Class Initialized
DEBUG - 2023-09-10 13:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:45:39 --> Input Class Initialized
INFO - 2023-09-10 13:45:39 --> Language Class Initialized
ERROR - 2023-09-10 13:45:39 --> 404 Page Not Found: DJJfIw8Q9M/index
INFO - 2023-09-10 13:45:43 --> Config Class Initialized
INFO - 2023-09-10 13:45:43 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:45:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:45:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:45:43 --> URI Class Initialized
DEBUG - 2023-09-10 13:45:43 --> No URI present. Default controller set.
INFO - 2023-09-10 13:45:43 --> Router Class Initialized
INFO - 2023-09-10 13:45:43 --> Output Class Initialized
INFO - 2023-09-10 13:45:43 --> Security Class Initialized
DEBUG - 2023-09-10 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:45:43 --> Input Class Initialized
INFO - 2023-09-10 13:45:43 --> Language Class Initialized
INFO - 2023-09-10 13:45:43 --> Loader Class Initialized
INFO - 2023-09-10 13:45:43 --> Helper loaded: url_helper
INFO - 2023-09-10 13:45:43 --> Helper loaded: file_helper
INFO - 2023-09-10 13:45:43 --> Database Driver Class Initialized
INFO - 2023-09-10 13:45:43 --> Email Class Initialized
DEBUG - 2023-09-10 13:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:45:43 --> Controller Class Initialized
INFO - 2023-09-10 13:45:43 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:45:43 --> Model "Home_model" initialized
INFO - 2023-09-10 13:45:43 --> Helper loaded: download_helper
INFO - 2023-09-10 13:45:43 --> Helper loaded: form_helper
INFO - 2023-09-10 13:45:43 --> Form Validation Class Initialized
INFO - 2023-09-10 13:45:43 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:45:43 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:45:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:45:43 --> Final output sent to browser
DEBUG - 2023-09-10 13:45:44 --> Total execution time: 0.9154
INFO - 2023-09-10 13:46:56 --> Config Class Initialized
INFO - 2023-09-10 13:46:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:46:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:46:56 --> Utf8 Class Initialized
INFO - 2023-09-10 13:46:57 --> URI Class Initialized
DEBUG - 2023-09-10 13:46:58 --> No URI present. Default controller set.
INFO - 2023-09-10 13:46:58 --> Router Class Initialized
INFO - 2023-09-10 13:46:58 --> Output Class Initialized
INFO - 2023-09-10 13:46:58 --> Security Class Initialized
DEBUG - 2023-09-10 13:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:46:58 --> Input Class Initialized
INFO - 2023-09-10 13:46:58 --> Language Class Initialized
INFO - 2023-09-10 13:46:59 --> Loader Class Initialized
INFO - 2023-09-10 13:46:59 --> Helper loaded: url_helper
INFO - 2023-09-10 13:46:59 --> Helper loaded: file_helper
INFO - 2023-09-10 13:46:59 --> Database Driver Class Initialized
INFO - 2023-09-10 13:46:59 --> Email Class Initialized
DEBUG - 2023-09-10 13:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:46:59 --> Controller Class Initialized
INFO - 2023-09-10 13:47:00 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:47:00 --> Model "Home_model" initialized
INFO - 2023-09-10 13:47:01 --> Helper loaded: download_helper
INFO - 2023-09-10 13:47:02 --> Helper loaded: form_helper
INFO - 2023-09-10 13:47:02 --> Form Validation Class Initialized
INFO - 2023-09-10 13:47:05 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:51:55 --> Config Class Initialized
INFO - 2023-09-10 13:51:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:51:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:55 --> Utf8 Class Initialized
INFO - 2023-09-10 13:51:55 --> URI Class Initialized
DEBUG - 2023-09-10 13:51:55 --> No URI present. Default controller set.
INFO - 2023-09-10 13:51:55 --> Router Class Initialized
INFO - 2023-09-10 13:51:55 --> Output Class Initialized
INFO - 2023-09-10 13:51:55 --> Security Class Initialized
DEBUG - 2023-09-10 13:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:55 --> Input Class Initialized
INFO - 2023-09-10 13:51:55 --> Language Class Initialized
INFO - 2023-09-10 13:51:55 --> Loader Class Initialized
INFO - 2023-09-10 13:51:55 --> Helper loaded: url_helper
INFO - 2023-09-10 13:51:55 --> Helper loaded: file_helper
INFO - 2023-09-10 13:51:55 --> Database Driver Class Initialized
INFO - 2023-09-10 13:51:55 --> Email Class Initialized
DEBUG - 2023-09-10 13:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:51:55 --> Controller Class Initialized
INFO - 2023-09-10 13:51:55 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:51:55 --> Model "Home_model" initialized
INFO - 2023-09-10 13:51:55 --> Helper loaded: download_helper
INFO - 2023-09-10 13:51:55 --> Helper loaded: form_helper
INFO - 2023-09-10 13:51:55 --> Form Validation Class Initialized
INFO - 2023-09-10 13:51:55 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:51:55 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:51:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:51:55 --> Final output sent to browser
DEBUG - 2023-09-10 13:51:56 --> Total execution time: 0.9507
INFO - 2023-09-10 13:51:57 --> Config Class Initialized
INFO - 2023-09-10 13:51:57 --> Config Class Initialized
INFO - 2023-09-10 13:51:58 --> Config Class Initialized
INFO - 2023-09-10 13:51:58 --> Hooks Class Initialized
INFO - 2023-09-10 13:51:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:51:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:51:58 --> URI Class Initialized
INFO - 2023-09-10 13:51:58 --> Router Class Initialized
INFO - 2023-09-10 13:51:58 --> Output Class Initialized
INFO - 2023-09-10 13:51:58 --> Security Class Initialized
DEBUG - 2023-09-10 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:58 --> Input Class Initialized
INFO - 2023-09-10 13:51:58 --> Language Class Initialized
ERROR - 2023-09-10 13:51:58 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 13:51:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:58 --> Hooks Class Initialized
INFO - 2023-09-10 13:51:58 --> Config Class Initialized
DEBUG - 2023-09-10 13:51:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:58 --> Hooks Class Initialized
INFO - 2023-09-10 13:51:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:51:58 --> Utf8 Class Initialized
DEBUG - 2023-09-10 13:51:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:58 --> URI Class Initialized
INFO - 2023-09-10 13:51:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:51:58 --> URI Class Initialized
INFO - 2023-09-10 13:51:58 --> Router Class Initialized
INFO - 2023-09-10 13:51:58 --> URI Class Initialized
INFO - 2023-09-10 13:51:58 --> Router Class Initialized
INFO - 2023-09-10 13:51:58 --> Output Class Initialized
INFO - 2023-09-10 13:51:58 --> Security Class Initialized
INFO - 2023-09-10 13:51:58 --> Output Class Initialized
INFO - 2023-09-10 13:51:58 --> Security Class Initialized
DEBUG - 2023-09-10 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:58 --> Router Class Initialized
DEBUG - 2023-09-10 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:58 --> Output Class Initialized
INFO - 2023-09-10 13:51:58 --> Input Class Initialized
INFO - 2023-09-10 13:51:58 --> Security Class Initialized
INFO - 2023-09-10 13:51:58 --> Language Class Initialized
INFO - 2023-09-10 13:51:58 --> Input Class Initialized
ERROR - 2023-09-10 13:51:58 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:58 --> Language Class Initialized
INFO - 2023-09-10 13:51:58 --> Input Class Initialized
INFO - 2023-09-10 13:51:58 --> Language Class Initialized
ERROR - 2023-09-10 13:51:58 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 13:51:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:51:59 --> Config Class Initialized
INFO - 2023-09-10 13:51:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:51:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:51:59 --> Utf8 Class Initialized
INFO - 2023-09-10 13:51:59 --> URI Class Initialized
INFO - 2023-09-10 13:51:59 --> Router Class Initialized
INFO - 2023-09-10 13:51:59 --> Output Class Initialized
INFO - 2023-09-10 13:51:59 --> Security Class Initialized
DEBUG - 2023-09-10 13:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:51:59 --> Input Class Initialized
INFO - 2023-09-10 13:51:59 --> Language Class Initialized
ERROR - 2023-09-10 13:51:59 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:51:59 --> Config Class Initialized
INFO - 2023-09-10 13:52:00 --> Config Class Initialized
INFO - 2023-09-10 13:52:00 --> Hooks Class Initialized
INFO - 2023-09-10 13:52:00 --> Config Class Initialized
INFO - 2023-09-10 13:52:00 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:52:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:52:00 --> Utf8 Class Initialized
INFO - 2023-09-10 13:52:00 --> URI Class Initialized
INFO - 2023-09-10 13:55:08 --> Config Class Initialized
INFO - 2023-09-10 13:55:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:55:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:55:08 --> Utf8 Class Initialized
INFO - 2023-09-10 13:55:08 --> URI Class Initialized
DEBUG - 2023-09-10 13:55:08 --> No URI present. Default controller set.
INFO - 2023-09-10 13:55:08 --> Router Class Initialized
INFO - 2023-09-10 13:55:08 --> Output Class Initialized
INFO - 2023-09-10 13:55:08 --> Security Class Initialized
DEBUG - 2023-09-10 13:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:55:08 --> Input Class Initialized
INFO - 2023-09-10 13:55:08 --> Language Class Initialized
INFO - 2023-09-10 13:55:08 --> Loader Class Initialized
INFO - 2023-09-10 13:55:08 --> Helper loaded: url_helper
INFO - 2023-09-10 13:55:08 --> Helper loaded: file_helper
INFO - 2023-09-10 13:55:08 --> Database Driver Class Initialized
INFO - 2023-09-10 13:55:08 --> Email Class Initialized
DEBUG - 2023-09-10 13:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:55:08 --> Controller Class Initialized
INFO - 2023-09-10 13:55:08 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:55:08 --> Model "Home_model" initialized
INFO - 2023-09-10 13:55:08 --> Helper loaded: download_helper
INFO - 2023-09-10 13:55:08 --> Helper loaded: form_helper
INFO - 2023-09-10 13:55:08 --> Form Validation Class Initialized
INFO - 2023-09-10 13:55:08 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:55:08 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:55:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:55:09 --> Final output sent to browser
DEBUG - 2023-09-10 13:55:09 --> Total execution time: 0.7902
INFO - 2023-09-10 13:55:09 --> Config Class Initialized
INFO - 2023-09-10 13:55:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:55:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:55:09 --> Utf8 Class Initialized
INFO - 2023-09-10 13:55:09 --> URI Class Initialized
INFO - 2023-09-10 13:55:10 --> Router Class Initialized
INFO - 2023-09-10 13:55:10 --> Output Class Initialized
INFO - 2023-09-10 13:55:10 --> Security Class Initialized
DEBUG - 2023-09-10 13:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:55:10 --> Input Class Initialized
INFO - 2023-09-10 13:55:10 --> Language Class Initialized
ERROR - 2023-09-10 13:55:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:55:11 --> Config Class Initialized
INFO - 2023-09-10 13:55:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:55:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:55:11 --> Utf8 Class Initialized
INFO - 2023-09-10 13:55:11 --> URI Class Initialized
INFO - 2023-09-10 13:55:11 --> Router Class Initialized
INFO - 2023-09-10 13:55:11 --> Output Class Initialized
INFO - 2023-09-10 13:55:11 --> Security Class Initialized
DEBUG - 2023-09-10 13:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:55:11 --> Input Class Initialized
INFO - 2023-09-10 13:55:11 --> Language Class Initialized
ERROR - 2023-09-10 13:55:11 --> 404 Page Not Found: Assets/images
INFO - 2023-09-10 13:55:45 --> Config Class Initialized
INFO - 2023-09-10 13:55:45 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:55:45 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:55:45 --> Utf8 Class Initialized
INFO - 2023-09-10 13:55:45 --> URI Class Initialized
DEBUG - 2023-09-10 13:55:45 --> No URI present. Default controller set.
INFO - 2023-09-10 13:55:45 --> Router Class Initialized
INFO - 2023-09-10 13:55:45 --> Output Class Initialized
INFO - 2023-09-10 13:55:45 --> Security Class Initialized
DEBUG - 2023-09-10 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:55:45 --> Input Class Initialized
INFO - 2023-09-10 13:55:45 --> Language Class Initialized
INFO - 2023-09-10 13:55:45 --> Loader Class Initialized
INFO - 2023-09-10 13:55:45 --> Helper loaded: url_helper
INFO - 2023-09-10 13:55:45 --> Helper loaded: file_helper
INFO - 2023-09-10 13:55:45 --> Database Driver Class Initialized
INFO - 2023-09-10 13:55:45 --> Email Class Initialized
DEBUG - 2023-09-10 13:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:55:45 --> Controller Class Initialized
INFO - 2023-09-10 13:55:45 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:55:45 --> Model "Home_model" initialized
INFO - 2023-09-10 13:55:45 --> Helper loaded: download_helper
INFO - 2023-09-10 13:55:45 --> Helper loaded: form_helper
INFO - 2023-09-10 13:55:46 --> Form Validation Class Initialized
INFO - 2023-09-10 13:55:46 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:55:46 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:55:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:55:46 --> Final output sent to browser
DEBUG - 2023-09-10 13:55:46 --> Total execution time: 0.5330
INFO - 2023-09-10 13:56:18 --> Config Class Initialized
INFO - 2023-09-10 13:56:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:56:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:18 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:18 --> URI Class Initialized
DEBUG - 2023-09-10 13:56:18 --> No URI present. Default controller set.
INFO - 2023-09-10 13:56:18 --> Router Class Initialized
INFO - 2023-09-10 13:56:18 --> Output Class Initialized
INFO - 2023-09-10 13:56:18 --> Security Class Initialized
DEBUG - 2023-09-10 13:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:18 --> Input Class Initialized
INFO - 2023-09-10 13:56:18 --> Language Class Initialized
INFO - 2023-09-10 13:56:18 --> Loader Class Initialized
INFO - 2023-09-10 13:56:18 --> Helper loaded: url_helper
INFO - 2023-09-10 13:56:18 --> Helper loaded: file_helper
INFO - 2023-09-10 13:56:18 --> Database Driver Class Initialized
INFO - 2023-09-10 13:56:19 --> Email Class Initialized
DEBUG - 2023-09-10 13:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:56:19 --> Controller Class Initialized
INFO - 2023-09-10 13:56:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:56:19 --> Model "Home_model" initialized
INFO - 2023-09-10 13:56:19 --> Helper loaded: download_helper
INFO - 2023-09-10 13:56:19 --> Helper loaded: form_helper
INFO - 2023-09-10 13:56:19 --> Form Validation Class Initialized
INFO - 2023-09-10 13:56:19 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:56:19 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:56:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:56:19 --> Final output sent to browser
DEBUG - 2023-09-10 13:56:19 --> Total execution time: 0.7959
INFO - 2023-09-10 13:56:38 --> Config Class Initialized
INFO - 2023-09-10 13:56:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:56:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:38 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:38 --> URI Class Initialized
INFO - 2023-09-10 13:56:38 --> Router Class Initialized
INFO - 2023-09-10 13:56:38 --> Output Class Initialized
INFO - 2023-09-10 13:56:38 --> Security Class Initialized
DEBUG - 2023-09-10 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:38 --> Input Class Initialized
INFO - 2023-09-10 13:56:38 --> Language Class Initialized
ERROR - 2023-09-10 13:56:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:56:39 --> Config Class Initialized
INFO - 2023-09-10 13:56:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:56:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:39 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:39 --> URI Class Initialized
INFO - 2023-09-10 13:56:39 --> Router Class Initialized
INFO - 2023-09-10 13:56:39 --> Output Class Initialized
INFO - 2023-09-10 13:56:39 --> Security Class Initialized
DEBUG - 2023-09-10 13:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:39 --> Input Class Initialized
INFO - 2023-09-10 13:56:39 --> Language Class Initialized
ERROR - 2023-09-10 13:56:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:56:40 --> Config Class Initialized
INFO - 2023-09-10 13:56:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:56:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:40 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:40 --> URI Class Initialized
INFO - 2023-09-10 13:56:40 --> Router Class Initialized
INFO - 2023-09-10 13:56:40 --> Output Class Initialized
INFO - 2023-09-10 13:56:40 --> Security Class Initialized
DEBUG - 2023-09-10 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:40 --> Input Class Initialized
INFO - 2023-09-10 13:56:40 --> Language Class Initialized
ERROR - 2023-09-10 13:56:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:56:40 --> Config Class Initialized
INFO - 2023-09-10 13:56:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:56:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:41 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:41 --> URI Class Initialized
INFO - 2023-09-10 13:56:42 --> Config Class Initialized
INFO - 2023-09-10 13:56:42 --> Hooks Class Initialized
INFO - 2023-09-10 13:56:42 --> Config Class Initialized
INFO - 2023-09-10 13:56:42 --> Hooks Class Initialized
INFO - 2023-09-10 13:56:42 --> Router Class Initialized
DEBUG - 2023-09-10 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:56:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:43 --> Output Class Initialized
INFO - 2023-09-10 13:56:43 --> Config Class Initialized
INFO - 2023-09-10 13:56:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:43 --> Security Class Initialized
INFO - 2023-09-10 13:56:43 --> Hooks Class Initialized
INFO - 2023-09-10 13:56:43 --> URI Class Initialized
INFO - 2023-09-10 13:56:43 --> URI Class Initialized
INFO - 2023-09-10 13:56:43 --> Router Class Initialized
DEBUG - 2023-09-10 13:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 13:56:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:56:43 --> Utf8 Class Initialized
INFO - 2023-09-10 13:56:43 --> Router Class Initialized
INFO - 2023-09-10 13:56:43 --> Output Class Initialized
INFO - 2023-09-10 13:56:43 --> Security Class Initialized
INFO - 2023-09-10 13:56:43 --> Input Class Initialized
INFO - 2023-09-10 13:56:43 --> Output Class Initialized
INFO - 2023-09-10 13:56:43 --> URI Class Initialized
DEBUG - 2023-09-10 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:44 --> Security Class Initialized
INFO - 2023-09-10 13:56:44 --> Language Class Initialized
INFO - 2023-09-10 13:56:44 --> Router Class Initialized
ERROR - 2023-09-10 13:56:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:56:44 --> Output Class Initialized
INFO - 2023-09-10 13:56:44 --> Input Class Initialized
DEBUG - 2023-09-10 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:44 --> Language Class Initialized
ERROR - 2023-09-10 13:56:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:56:44 --> Security Class Initialized
DEBUG - 2023-09-10 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:56:44 --> Input Class Initialized
INFO - 2023-09-10 13:56:44 --> Input Class Initialized
INFO - 2023-09-10 13:56:44 --> Language Class Initialized
INFO - 2023-09-10 13:56:44 --> Language Class Initialized
ERROR - 2023-09-10 13:56:44 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 13:56:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:24 --> Config Class Initialized
INFO - 2023-09-10 13:57:24 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:57:24 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:24 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:24 --> URI Class Initialized
DEBUG - 2023-09-10 13:57:24 --> No URI present. Default controller set.
INFO - 2023-09-10 13:57:24 --> Router Class Initialized
INFO - 2023-09-10 13:57:24 --> Output Class Initialized
INFO - 2023-09-10 13:57:24 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:24 --> Input Class Initialized
INFO - 2023-09-10 13:57:24 --> Language Class Initialized
INFO - 2023-09-10 13:57:24 --> Loader Class Initialized
INFO - 2023-09-10 13:57:24 --> Helper loaded: url_helper
INFO - 2023-09-10 13:57:24 --> Helper loaded: file_helper
INFO - 2023-09-10 13:57:24 --> Database Driver Class Initialized
INFO - 2023-09-10 13:57:24 --> Email Class Initialized
DEBUG - 2023-09-10 13:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:57:25 --> Controller Class Initialized
INFO - 2023-09-10 13:57:25 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:57:25 --> Model "Home_model" initialized
INFO - 2023-09-10 13:57:25 --> Helper loaded: download_helper
INFO - 2023-09-10 13:57:25 --> Helper loaded: form_helper
INFO - 2023-09-10 13:57:25 --> Form Validation Class Initialized
INFO - 2023-09-10 13:57:25 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:57:25 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:57:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:57:25 --> Final output sent to browser
DEBUG - 2023-09-10 13:57:26 --> Total execution time: 1.1148
INFO - 2023-09-10 13:57:29 --> Config Class Initialized
INFO - 2023-09-10 13:57:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:57:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:29 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:29 --> URI Class Initialized
INFO - 2023-09-10 13:57:29 --> Router Class Initialized
INFO - 2023-09-10 13:57:29 --> Output Class Initialized
INFO - 2023-09-10 13:57:29 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:29 --> Input Class Initialized
INFO - 2023-09-10 13:57:29 --> Language Class Initialized
ERROR - 2023-09-10 13:57:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:30 --> Config Class Initialized
INFO - 2023-09-10 13:57:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:57:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:30 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:30 --> URI Class Initialized
INFO - 2023-09-10 13:57:31 --> Config Class Initialized
INFO - 2023-09-10 13:57:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:57:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:31 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:31 --> URI Class Initialized
INFO - 2023-09-10 13:57:31 --> Router Class Initialized
INFO - 2023-09-10 13:57:31 --> Output Class Initialized
INFO - 2023-09-10 13:57:31 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:31 --> Input Class Initialized
INFO - 2023-09-10 13:57:31 --> Language Class Initialized
ERROR - 2023-09-10 13:57:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:31 --> Config Class Initialized
INFO - 2023-09-10 13:57:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:57:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:32 --> Router Class Initialized
INFO - 2023-09-10 13:57:32 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:32 --> Output Class Initialized
INFO - 2023-09-10 13:57:32 --> URI Class Initialized
INFO - 2023-09-10 13:57:32 --> Router Class Initialized
INFO - 2023-09-10 13:57:32 --> Security Class Initialized
INFO - 2023-09-10 13:57:33 --> Output Class Initialized
INFO - 2023-09-10 13:57:33 --> Config Class Initialized
INFO - 2023-09-10 13:57:34 --> Config Class Initialized
INFO - 2023-09-10 13:57:34 --> Hooks Class Initialized
INFO - 2023-09-10 13:57:34 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:34 --> Hooks Class Initialized
INFO - 2023-09-10 13:57:35 --> Config Class Initialized
DEBUG - 2023-09-10 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:35 --> Input Class Initialized
DEBUG - 2023-09-10 13:57:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:36 --> Hooks Class Initialized
INFO - 2023-09-10 13:57:36 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:36 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:36 --> Input Class Initialized
DEBUG - 2023-09-10 13:57:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:57:37 --> URI Class Initialized
INFO - 2023-09-10 13:57:37 --> Language Class Initialized
INFO - 2023-09-10 13:57:37 --> URI Class Initialized
ERROR - 2023-09-10 13:57:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:37 --> Language Class Initialized
INFO - 2023-09-10 13:57:37 --> Router Class Initialized
INFO - 2023-09-10 13:57:37 --> Router Class Initialized
ERROR - 2023-09-10 13:57:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:38 --> Utf8 Class Initialized
INFO - 2023-09-10 13:57:38 --> Output Class Initialized
INFO - 2023-09-10 13:57:38 --> Output Class Initialized
INFO - 2023-09-10 13:57:38 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:38 --> Input Class Initialized
INFO - 2023-09-10 13:57:38 --> Language Class Initialized
ERROR - 2023-09-10 13:57:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:38 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:38 --> URI Class Initialized
INFO - 2023-09-10 13:57:38 --> Input Class Initialized
INFO - 2023-09-10 13:57:38 --> Router Class Initialized
INFO - 2023-09-10 13:57:38 --> Language Class Initialized
INFO - 2023-09-10 13:57:38 --> Output Class Initialized
ERROR - 2023-09-10 13:57:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:57:38 --> Security Class Initialized
DEBUG - 2023-09-10 13:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:57:39 --> Input Class Initialized
INFO - 2023-09-10 13:57:39 --> Language Class Initialized
ERROR - 2023-09-10 13:57:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:01 --> Config Class Initialized
INFO - 2023-09-10 13:58:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:58:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:01 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:01 --> URI Class Initialized
DEBUG - 2023-09-10 13:58:01 --> No URI present. Default controller set.
INFO - 2023-09-10 13:58:01 --> Router Class Initialized
INFO - 2023-09-10 13:58:01 --> Output Class Initialized
INFO - 2023-09-10 13:58:01 --> Security Class Initialized
DEBUG - 2023-09-10 13:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:01 --> Input Class Initialized
INFO - 2023-09-10 13:58:01 --> Language Class Initialized
INFO - 2023-09-10 13:58:01 --> Loader Class Initialized
INFO - 2023-09-10 13:58:01 --> Helper loaded: url_helper
INFO - 2023-09-10 13:58:01 --> Helper loaded: file_helper
INFO - 2023-09-10 13:58:01 --> Database Driver Class Initialized
INFO - 2023-09-10 13:58:01 --> Email Class Initialized
DEBUG - 2023-09-10 13:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:58:01 --> Controller Class Initialized
INFO - 2023-09-10 13:58:01 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:58:01 --> Model "Home_model" initialized
INFO - 2023-09-10 13:58:02 --> Helper loaded: download_helper
INFO - 2023-09-10 13:58:02 --> Helper loaded: form_helper
INFO - 2023-09-10 13:58:02 --> Form Validation Class Initialized
INFO - 2023-09-10 13:58:02 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:58:02 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:58:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:58:02 --> Final output sent to browser
DEBUG - 2023-09-10 13:58:02 --> Total execution time: 1.6363
INFO - 2023-09-10 13:58:07 --> Config Class Initialized
INFO - 2023-09-10 13:58:07 --> Hooks Class Initialized
INFO - 2023-09-10 13:58:08 --> Config Class Initialized
INFO - 2023-09-10 13:58:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:58:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:08 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:08 --> URI Class Initialized
INFO - 2023-09-10 13:58:08 --> Router Class Initialized
INFO - 2023-09-10 13:58:08 --> Output Class Initialized
INFO - 2023-09-10 13:58:08 --> Security Class Initialized
DEBUG - 2023-09-10 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:08 --> Input Class Initialized
INFO - 2023-09-10 13:58:08 --> Language Class Initialized
ERROR - 2023-09-10 13:58:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 13:58:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:09 --> Config Class Initialized
INFO - 2023-09-10 13:58:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:58:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:09 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:09 --> URI Class Initialized
INFO - 2023-09-10 13:58:09 --> Router Class Initialized
INFO - 2023-09-10 13:58:09 --> Output Class Initialized
INFO - 2023-09-10 13:58:09 --> Security Class Initialized
DEBUG - 2023-09-10 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:09 --> Input Class Initialized
INFO - 2023-09-10 13:58:09 --> Language Class Initialized
ERROR - 2023-09-10 13:58:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:09 --> Config Class Initialized
INFO - 2023-09-10 13:58:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:58:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:09 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:09 --> URI Class Initialized
INFO - 2023-09-10 13:58:09 --> Router Class Initialized
INFO - 2023-09-10 13:58:09 --> Output Class Initialized
INFO - 2023-09-10 13:58:09 --> Security Class Initialized
DEBUG - 2023-09-10 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:09 --> Input Class Initialized
INFO - 2023-09-10 13:58:09 --> Language Class Initialized
ERROR - 2023-09-10 13:58:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:09 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:10 --> Config Class Initialized
INFO - 2023-09-10 13:58:10 --> Hooks Class Initialized
INFO - 2023-09-10 13:58:10 --> URI Class Initialized
DEBUG - 2023-09-10 13:58:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:11 --> Router Class Initialized
INFO - 2023-09-10 13:58:11 --> Config Class Initialized
INFO - 2023-09-10 13:58:11 --> Config Class Initialized
INFO - 2023-09-10 13:58:11 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:11 --> Output Class Initialized
INFO - 2023-09-10 13:58:11 --> Hooks Class Initialized
INFO - 2023-09-10 13:58:11 --> URI Class Initialized
INFO - 2023-09-10 13:58:12 --> Hooks Class Initialized
INFO - 2023-09-10 13:58:12 --> Security Class Initialized
DEBUG - 2023-09-10 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 13:58:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:58:13 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:13 --> Router Class Initialized
DEBUG - 2023-09-10 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:14 --> Input Class Initialized
INFO - 2023-09-10 13:58:14 --> Language Class Initialized
ERROR - 2023-09-10 13:58:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:14 --> Output Class Initialized
INFO - 2023-09-10 13:58:14 --> Security Class Initialized
INFO - 2023-09-10 13:58:14 --> URI Class Initialized
INFO - 2023-09-10 13:58:14 --> Utf8 Class Initialized
INFO - 2023-09-10 13:58:15 --> Router Class Initialized
DEBUG - 2023-09-10 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:15 --> URI Class Initialized
INFO - 2023-09-10 13:58:16 --> Output Class Initialized
INFO - 2023-09-10 13:58:16 --> Input Class Initialized
INFO - 2023-09-10 13:58:16 --> Security Class Initialized
INFO - 2023-09-10 13:58:16 --> Router Class Initialized
DEBUG - 2023-09-10 13:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:58:17 --> Output Class Initialized
INFO - 2023-09-10 13:58:17 --> Security Class Initialized
INFO - 2023-09-10 13:58:17 --> Language Class Initialized
INFO - 2023-09-10 13:58:17 --> Input Class Initialized
ERROR - 2023-09-10 13:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:17 --> Language Class Initialized
DEBUG - 2023-09-10 13:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 13:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:58:17 --> Input Class Initialized
INFO - 2023-09-10 13:58:17 --> Language Class Initialized
ERROR - 2023-09-10 13:58:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:59:50 --> Config Class Initialized
INFO - 2023-09-10 13:59:50 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:59:50 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:59:50 --> Utf8 Class Initialized
INFO - 2023-09-10 13:59:50 --> URI Class Initialized
DEBUG - 2023-09-10 13:59:50 --> No URI present. Default controller set.
INFO - 2023-09-10 13:59:50 --> Router Class Initialized
INFO - 2023-09-10 13:59:50 --> Output Class Initialized
INFO - 2023-09-10 13:59:50 --> Security Class Initialized
DEBUG - 2023-09-10 13:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:59:50 --> Input Class Initialized
INFO - 2023-09-10 13:59:50 --> Language Class Initialized
INFO - 2023-09-10 13:59:50 --> Loader Class Initialized
INFO - 2023-09-10 13:59:50 --> Helper loaded: url_helper
INFO - 2023-09-10 13:59:50 --> Helper loaded: file_helper
INFO - 2023-09-10 13:59:50 --> Database Driver Class Initialized
INFO - 2023-09-10 13:59:50 --> Email Class Initialized
DEBUG - 2023-09-10 13:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 13:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 13:59:50 --> Controller Class Initialized
INFO - 2023-09-10 13:59:50 --> Model "Contact_model" initialized
INFO - 2023-09-10 13:59:50 --> Model "Home_model" initialized
INFO - 2023-09-10 13:59:50 --> Helper loaded: download_helper
INFO - 2023-09-10 13:59:50 --> Helper loaded: form_helper
INFO - 2023-09-10 13:59:51 --> Form Validation Class Initialized
INFO - 2023-09-10 13:59:51 --> Helper loaded: custom_helper
INFO - 2023-09-10 13:59:51 --> Model "Social_media_model" initialized
INFO - 2023-09-10 13:59:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 13:59:51 --> Final output sent to browser
DEBUG - 2023-09-10 13:59:51 --> Total execution time: 0.9752
INFO - 2023-09-10 13:59:55 --> Config Class Initialized
INFO - 2023-09-10 13:59:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:59:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:59:55 --> Utf8 Class Initialized
INFO - 2023-09-10 13:59:55 --> URI Class Initialized
INFO - 2023-09-10 13:59:55 --> Router Class Initialized
INFO - 2023-09-10 13:59:55 --> Output Class Initialized
INFO - 2023-09-10 13:59:55 --> Security Class Initialized
INFO - 2023-09-10 13:59:57 --> Config Class Initialized
INFO - 2023-09-10 13:59:57 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:59:57 --> Input Class Initialized
INFO - 2023-09-10 13:59:57 --> Language Class Initialized
ERROR - 2023-09-10 13:59:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:59:57 --> Config Class Initialized
DEBUG - 2023-09-10 13:59:57 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:59:58 --> Config Class Initialized
INFO - 2023-09-10 13:59:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:59:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:59:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:59:58 --> URI Class Initialized
INFO - 2023-09-10 13:59:58 --> Router Class Initialized
INFO - 2023-09-10 13:59:58 --> Output Class Initialized
INFO - 2023-09-10 13:59:58 --> Security Class Initialized
DEBUG - 2023-09-10 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:59:58 --> Input Class Initialized
INFO - 2023-09-10 13:59:58 --> Language Class Initialized
ERROR - 2023-09-10 13:59:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:59:58 --> Config Class Initialized
INFO - 2023-09-10 13:59:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:59:58 --> URI Class Initialized
INFO - 2023-09-10 13:59:58 --> Hooks Class Initialized
INFO - 2023-09-10 13:59:58 --> Hooks Class Initialized
DEBUG - 2023-09-10 13:59:58 --> UTF-8 Support Enabled
INFO - 2023-09-10 13:59:58 --> Utf8 Class Initialized
INFO - 2023-09-10 13:59:58 --> URI Class Initialized
INFO - 2023-09-10 13:59:58 --> Router Class Initialized
INFO - 2023-09-10 13:59:58 --> Output Class Initialized
INFO - 2023-09-10 13:59:58 --> Security Class Initialized
DEBUG - 2023-09-10 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:59:58 --> Input Class Initialized
INFO - 2023-09-10 13:59:58 --> Language Class Initialized
ERROR - 2023-09-10 13:59:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:59:59 --> Router Class Initialized
INFO - 2023-09-10 13:59:59 --> Output Class Initialized
INFO - 2023-09-10 13:59:59 --> Security Class Initialized
DEBUG - 2023-09-10 13:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 13:59:59 --> Input Class Initialized
INFO - 2023-09-10 13:59:59 --> Language Class Initialized
ERROR - 2023-09-10 13:59:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 13:59:59 --> Config Class Initialized
INFO - 2023-09-10 13:59:59 --> Hooks Class Initialized
INFO - 2023-09-10 13:59:59 --> Config Class Initialized
DEBUG - 2023-09-10 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:00:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:00:00 --> Utf8 Class Initialized
INFO - 2023-09-10 14:00:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:00:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:00:01 --> Utf8 Class Initialized
INFO - 2023-09-10 14:00:01 --> URI Class Initialized
INFO - 2023-09-10 14:00:01 --> Router Class Initialized
INFO - 2023-09-10 14:00:01 --> Output Class Initialized
INFO - 2023-09-10 14:00:01 --> Security Class Initialized
DEBUG - 2023-09-10 14:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:00:01 --> Input Class Initialized
INFO - 2023-09-10 14:00:01 --> Language Class Initialized
ERROR - 2023-09-10 14:00:01 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:00:01 --> Utf8 Class Initialized
INFO - 2023-09-10 14:00:01 --> URI Class Initialized
INFO - 2023-09-10 14:00:01 --> URI Class Initialized
INFO - 2023-09-10 14:00:01 --> Router Class Initialized
INFO - 2023-09-10 14:00:01 --> Router Class Initialized
INFO - 2023-09-10 14:00:02 --> Output Class Initialized
INFO - 2023-09-10 14:00:02 --> Output Class Initialized
INFO - 2023-09-10 14:00:02 --> Security Class Initialized
INFO - 2023-09-10 14:00:02 --> Security Class Initialized
DEBUG - 2023-09-10 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 14:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:00:02 --> Input Class Initialized
INFO - 2023-09-10 14:00:02 --> Input Class Initialized
INFO - 2023-09-10 14:00:02 --> Language Class Initialized
ERROR - 2023-09-10 14:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:00:03 --> Language Class Initialized
ERROR - 2023-09-10 14:00:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:06 --> Config Class Initialized
INFO - 2023-09-10 14:01:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:06 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:06 --> URI Class Initialized
DEBUG - 2023-09-10 14:01:06 --> No URI present. Default controller set.
INFO - 2023-09-10 14:01:06 --> Router Class Initialized
INFO - 2023-09-10 14:01:07 --> Output Class Initialized
INFO - 2023-09-10 14:01:07 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:07 --> Input Class Initialized
INFO - 2023-09-10 14:01:07 --> Language Class Initialized
INFO - 2023-09-10 14:01:07 --> Loader Class Initialized
INFO - 2023-09-10 14:01:07 --> Helper loaded: url_helper
INFO - 2023-09-10 14:01:07 --> Helper loaded: file_helper
INFO - 2023-09-10 14:01:07 --> Database Driver Class Initialized
INFO - 2023-09-10 14:01:07 --> Email Class Initialized
DEBUG - 2023-09-10 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:01:07 --> Controller Class Initialized
INFO - 2023-09-10 14:01:07 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:01:07 --> Model "Home_model" initialized
INFO - 2023-09-10 14:01:07 --> Helper loaded: download_helper
INFO - 2023-09-10 14:01:07 --> Helper loaded: form_helper
INFO - 2023-09-10 14:01:07 --> Form Validation Class Initialized
INFO - 2023-09-10 14:01:07 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:01:07 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:01:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:01:07 --> Final output sent to browser
DEBUG - 2023-09-10 14:01:08 --> Total execution time: 0.9162
INFO - 2023-09-10 14:01:10 --> Config Class Initialized
INFO - 2023-09-10 14:01:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:10 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:10 --> URI Class Initialized
INFO - 2023-09-10 14:01:10 --> Router Class Initialized
INFO - 2023-09-10 14:01:10 --> Output Class Initialized
INFO - 2023-09-10 14:01:10 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:11 --> Input Class Initialized
INFO - 2023-09-10 14:01:11 --> Language Class Initialized
INFO - 2023-09-10 14:01:12 --> Config Class Initialized
INFO - 2023-09-10 14:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:12 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:12 --> URI Class Initialized
INFO - 2023-09-10 14:01:12 --> Router Class Initialized
INFO - 2023-09-10 14:01:12 --> Output Class Initialized
INFO - 2023-09-10 14:01:12 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:12 --> Input Class Initialized
INFO - 2023-09-10 14:01:12 --> Language Class Initialized
ERROR - 2023-09-10 14:01:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:12 --> Config Class Initialized
INFO - 2023-09-10 14:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:12 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:12 --> URI Class Initialized
INFO - 2023-09-10 14:01:12 --> Router Class Initialized
INFO - 2023-09-10 14:01:12 --> Output Class Initialized
INFO - 2023-09-10 14:01:12 --> Security Class Initialized
ERROR - 2023-09-10 14:01:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:12 --> Config Class Initialized
INFO - 2023-09-10 14:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:12 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:12 --> URI Class Initialized
INFO - 2023-09-10 14:01:12 --> Router Class Initialized
INFO - 2023-09-10 14:01:12 --> Output Class Initialized
INFO - 2023-09-10 14:01:12 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:12 --> Input Class Initialized
INFO - 2023-09-10 14:01:12 --> Language Class Initialized
ERROR - 2023-09-10 14:01:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:12 --> Config Class Initialized
INFO - 2023-09-10 14:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 14:01:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:13 --> Config Class Initialized
INFO - 2023-09-10 14:01:14 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:14 --> Input Class Initialized
INFO - 2023-09-10 14:01:14 --> Config Class Initialized
INFO - 2023-09-10 14:01:15 --> Language Class Initialized
ERROR - 2023-09-10 14:01:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:15 --> Hooks Class Initialized
INFO - 2023-09-10 14:01:15 --> URI Class Initialized
INFO - 2023-09-10 14:01:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:01:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:15 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:15 --> URI Class Initialized
INFO - 2023-09-10 14:01:15 --> Router Class Initialized
INFO - 2023-09-10 14:01:15 --> Output Class Initialized
INFO - 2023-09-10 14:01:15 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:15 --> Input Class Initialized
INFO - 2023-09-10 14:01:15 --> Language Class Initialized
ERROR - 2023-09-10 14:01:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:16 --> Router Class Initialized
DEBUG - 2023-09-10 14:01:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:01:16 --> Output Class Initialized
INFO - 2023-09-10 14:01:16 --> Utf8 Class Initialized
INFO - 2023-09-10 14:01:16 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:17 --> URI Class Initialized
INFO - 2023-09-10 14:01:17 --> Input Class Initialized
INFO - 2023-09-10 14:01:17 --> Language Class Initialized
INFO - 2023-09-10 14:01:17 --> Router Class Initialized
ERROR - 2023-09-10 14:01:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:01:18 --> Output Class Initialized
INFO - 2023-09-10 14:01:18 --> Security Class Initialized
DEBUG - 2023-09-10 14:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:01:19 --> Input Class Initialized
INFO - 2023-09-10 14:01:19 --> Language Class Initialized
ERROR - 2023-09-10 14:01:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:15 --> Config Class Initialized
INFO - 2023-09-10 14:04:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:15 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:15 --> URI Class Initialized
DEBUG - 2023-09-10 14:04:15 --> No URI present. Default controller set.
INFO - 2023-09-10 14:04:15 --> Router Class Initialized
INFO - 2023-09-10 14:04:15 --> Output Class Initialized
INFO - 2023-09-10 14:04:15 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:16 --> Input Class Initialized
INFO - 2023-09-10 14:04:16 --> Language Class Initialized
INFO - 2023-09-10 14:04:16 --> Loader Class Initialized
INFO - 2023-09-10 14:04:16 --> Helper loaded: url_helper
INFO - 2023-09-10 14:04:16 --> Helper loaded: file_helper
INFO - 2023-09-10 14:04:16 --> Database Driver Class Initialized
INFO - 2023-09-10 14:04:16 --> Email Class Initialized
DEBUG - 2023-09-10 14:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:04:16 --> Controller Class Initialized
INFO - 2023-09-10 14:04:16 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:04:16 --> Model "Home_model" initialized
INFO - 2023-09-10 14:04:16 --> Helper loaded: download_helper
INFO - 2023-09-10 14:04:16 --> Helper loaded: form_helper
INFO - 2023-09-10 14:04:16 --> Form Validation Class Initialized
INFO - 2023-09-10 14:04:16 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:04:16 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:04:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:04:17 --> Final output sent to browser
DEBUG - 2023-09-10 14:04:17 --> Total execution time: 1.6184
INFO - 2023-09-10 14:04:20 --> Config Class Initialized
INFO - 2023-09-10 14:04:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:20 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:20 --> URI Class Initialized
INFO - 2023-09-10 14:04:20 --> Router Class Initialized
INFO - 2023-09-10 14:04:20 --> Output Class Initialized
INFO - 2023-09-10 14:04:20 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:20 --> Input Class Initialized
INFO - 2023-09-10 14:04:20 --> Language Class Initialized
ERROR - 2023-09-10 14:04:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:21 --> Config Class Initialized
INFO - 2023-09-10 14:04:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:21 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:21 --> URI Class Initialized
INFO - 2023-09-10 14:04:21 --> Router Class Initialized
INFO - 2023-09-10 14:04:21 --> Output Class Initialized
INFO - 2023-09-10 14:04:21 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:21 --> Input Class Initialized
INFO - 2023-09-10 14:04:22 --> Language Class Initialized
ERROR - 2023-09-10 14:04:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:26 --> Config Class Initialized
INFO - 2023-09-10 14:04:26 --> Hooks Class Initialized
INFO - 2023-09-10 14:04:27 --> Config Class Initialized
INFO - 2023-09-10 14:04:27 --> Config Class Initialized
INFO - 2023-09-10 14:04:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:28 --> Config Class Initialized
INFO - 2023-09-10 14:04:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:28 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:29 --> URI Class Initialized
INFO - 2023-09-10 14:04:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:04:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:04:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:04:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:30 --> Config Class Initialized
INFO - 2023-09-10 14:04:30 --> URI Class Initialized
INFO - 2023-09-10 14:04:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:30 --> Router Class Initialized
INFO - 2023-09-10 14:04:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:31 --> Router Class Initialized
INFO - 2023-09-10 14:04:31 --> Output Class Initialized
INFO - 2023-09-10 14:04:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:31 --> Input Class Initialized
INFO - 2023-09-10 14:04:31 --> Language Class Initialized
ERROR - 2023-09-10 14:04:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:31 --> URI Class Initialized
INFO - 2023-09-10 14:04:31 --> URI Class Initialized
INFO - 2023-09-10 14:04:31 --> Router Class Initialized
INFO - 2023-09-10 14:04:31 --> Output Class Initialized
INFO - 2023-09-10 14:04:31 --> Hooks Class Initialized
INFO - 2023-09-10 14:04:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:31 --> Output Class Initialized
INFO - 2023-09-10 14:04:32 --> Utf8 Class Initialized
INFO - 2023-09-10 14:04:32 --> Router Class Initialized
INFO - 2023-09-10 14:04:32 --> URI Class Initialized
INFO - 2023-09-10 14:04:32 --> Input Class Initialized
INFO - 2023-09-10 14:04:32 --> Output Class Initialized
INFO - 2023-09-10 14:04:32 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:32 --> Input Class Initialized
INFO - 2023-09-10 14:04:32 --> Language Class Initialized
ERROR - 2023-09-10 14:04:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:32 --> Language Class Initialized
INFO - 2023-09-10 14:04:32 --> Router Class Initialized
INFO - 2023-09-10 14:04:32 --> Output Class Initialized
INFO - 2023-09-10 14:04:32 --> Security Class Initialized
DEBUG - 2023-09-10 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:32 --> Input Class Initialized
INFO - 2023-09-10 14:04:32 --> Language Class Initialized
ERROR - 2023-09-10 14:04:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:04:32 --> Security Class Initialized
ERROR - 2023-09-10 14:04:32 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:04:32 --> Input Class Initialized
INFO - 2023-09-10 14:04:32 --> Language Class Initialized
ERROR - 2023-09-10 14:04:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:06:20 --> Config Class Initialized
INFO - 2023-09-10 14:06:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:06:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:20 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:20 --> URI Class Initialized
DEBUG - 2023-09-10 14:06:20 --> No URI present. Default controller set.
INFO - 2023-09-10 14:06:20 --> Router Class Initialized
INFO - 2023-09-10 14:06:20 --> Output Class Initialized
INFO - 2023-09-10 14:06:20 --> Security Class Initialized
DEBUG - 2023-09-10 14:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:20 --> Input Class Initialized
INFO - 2023-09-10 14:06:20 --> Language Class Initialized
INFO - 2023-09-10 14:06:20 --> Loader Class Initialized
INFO - 2023-09-10 14:06:20 --> Helper loaded: url_helper
INFO - 2023-09-10 14:06:20 --> Helper loaded: file_helper
INFO - 2023-09-10 14:06:20 --> Database Driver Class Initialized
INFO - 2023-09-10 14:06:20 --> Email Class Initialized
DEBUG - 2023-09-10 14:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:06:21 --> Controller Class Initialized
INFO - 2023-09-10 14:06:21 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:06:21 --> Model "Home_model" initialized
INFO - 2023-09-10 14:06:21 --> Helper loaded: download_helper
INFO - 2023-09-10 14:06:21 --> Helper loaded: form_helper
INFO - 2023-09-10 14:06:21 --> Form Validation Class Initialized
INFO - 2023-09-10 14:06:21 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:06:21 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:06:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:06:21 --> Final output sent to browser
DEBUG - 2023-09-10 14:06:21 --> Total execution time: 1.2376
INFO - 2023-09-10 14:06:25 --> Language Class Initialized
INFO - 2023-09-10 14:06:26 --> Config Class Initialized
ERROR - 2023-09-10 14:06:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:06:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:06:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:27 --> Config Class Initialized
INFO - 2023-09-10 14:06:28 --> Hooks Class Initialized
INFO - 2023-09-10 14:06:29 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:30 --> URI Class Initialized
INFO - 2023-09-10 14:06:30 --> Config Class Initialized
INFO - 2023-09-10 14:06:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:06:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:30 --> URI Class Initialized
INFO - 2023-09-10 14:06:30 --> Router Class Initialized
INFO - 2023-09-10 14:06:30 --> Output Class Initialized
INFO - 2023-09-10 14:06:30 --> Security Class Initialized
DEBUG - 2023-09-10 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:30 --> Input Class Initialized
INFO - 2023-09-10 14:06:30 --> Language Class Initialized
ERROR - 2023-09-10 14:06:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:06:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:30 --> Config Class Initialized
INFO - 2023-09-10 14:06:31 --> Config Class Initialized
INFO - 2023-09-10 14:06:31 --> Config Class Initialized
INFO - 2023-09-10 14:06:31 --> Router Class Initialized
INFO - 2023-09-10 14:06:31 --> Hooks Class Initialized
INFO - 2023-09-10 14:06:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:31 --> Output Class Initialized
INFO - 2023-09-10 14:06:31 --> Hooks Class Initialized
INFO - 2023-09-10 14:06:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:06:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:06:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:31 --> URI Class Initialized
INFO - 2023-09-10 14:06:31 --> Router Class Initialized
INFO - 2023-09-10 14:06:31 --> Output Class Initialized
INFO - 2023-09-10 14:06:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:31 --> Input Class Initialized
INFO - 2023-09-10 14:06:31 --> Language Class Initialized
ERROR - 2023-09-10 14:06:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:06:32 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:32 --> URI Class Initialized
DEBUG - 2023-09-10 14:06:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:06:32 --> Router Class Initialized
DEBUG - 2023-09-10 14:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:32 --> URI Class Initialized
INFO - 2023-09-10 14:06:32 --> Utf8 Class Initialized
INFO - 2023-09-10 14:06:33 --> Output Class Initialized
INFO - 2023-09-10 14:06:33 --> Router Class Initialized
INFO - 2023-09-10 14:06:33 --> Input Class Initialized
INFO - 2023-09-10 14:06:34 --> Language Class Initialized
ERROR - 2023-09-10 14:06:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:06:34 --> URI Class Initialized
INFO - 2023-09-10 14:06:34 --> Output Class Initialized
INFO - 2023-09-10 14:06:34 --> Router Class Initialized
INFO - 2023-09-10 14:06:34 --> Security Class Initialized
INFO - 2023-09-10 14:06:34 --> Output Class Initialized
DEBUG - 2023-09-10 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:34 --> Input Class Initialized
INFO - 2023-09-10 14:06:34 --> Security Class Initialized
INFO - 2023-09-10 14:06:34 --> Security Class Initialized
DEBUG - 2023-09-10 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:34 --> Language Class Initialized
INFO - 2023-09-10 14:06:34 --> Input Class Initialized
DEBUG - 2023-09-10 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:06:35 --> Language Class Initialized
ERROR - 2023-09-10 14:06:35 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 14:06:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:06:35 --> Input Class Initialized
INFO - 2023-09-10 14:06:35 --> Language Class Initialized
ERROR - 2023-09-10 14:06:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:21 --> Config Class Initialized
INFO - 2023-09-10 14:07:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:21 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:21 --> URI Class Initialized
DEBUG - 2023-09-10 14:07:21 --> No URI present. Default controller set.
INFO - 2023-09-10 14:07:21 --> Router Class Initialized
INFO - 2023-09-10 14:07:21 --> Output Class Initialized
INFO - 2023-09-10 14:07:21 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:22 --> Input Class Initialized
INFO - 2023-09-10 14:07:22 --> Language Class Initialized
INFO - 2023-09-10 14:07:22 --> Loader Class Initialized
INFO - 2023-09-10 14:07:22 --> Helper loaded: url_helper
INFO - 2023-09-10 14:07:22 --> Helper loaded: file_helper
INFO - 2023-09-10 14:07:22 --> Database Driver Class Initialized
INFO - 2023-09-10 14:07:22 --> Email Class Initialized
DEBUG - 2023-09-10 14:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:07:22 --> Controller Class Initialized
INFO - 2023-09-10 14:07:22 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:07:22 --> Model "Home_model" initialized
INFO - 2023-09-10 14:07:22 --> Helper loaded: download_helper
INFO - 2023-09-10 14:07:22 --> Helper loaded: form_helper
INFO - 2023-09-10 14:07:22 --> Form Validation Class Initialized
INFO - 2023-09-10 14:07:22 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:07:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:07:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:07:23 --> Final output sent to browser
DEBUG - 2023-09-10 14:07:23 --> Total execution time: 1.9537
INFO - 2023-09-10 14:07:25 --> Config Class Initialized
INFO - 2023-09-10 14:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:26 --> Config Class Initialized
INFO - 2023-09-10 14:07:27 --> Config Class Initialized
INFO - 2023-09-10 14:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:27 --> URI Class Initialized
INFO - 2023-09-10 14:07:27 --> Router Class Initialized
INFO - 2023-09-10 14:07:27 --> Output Class Initialized
INFO - 2023-09-10 14:07:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:27 --> Input Class Initialized
INFO - 2023-09-10 14:07:27 --> Language Class Initialized
ERROR - 2023-09-10 14:07:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:27 --> Config Class Initialized
INFO - 2023-09-10 14:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:27 --> URI Class Initialized
INFO - 2023-09-10 14:07:27 --> Router Class Initialized
INFO - 2023-09-10 14:07:27 --> Output Class Initialized
INFO - 2023-09-10 14:07:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:27 --> Input Class Initialized
INFO - 2023-09-10 14:07:27 --> Language Class Initialized
ERROR - 2023-09-10 14:07:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:27 --> Config Class Initialized
INFO - 2023-09-10 14:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:27 --> URI Class Initialized
INFO - 2023-09-10 14:07:27 --> Router Class Initialized
INFO - 2023-09-10 14:07:27 --> Output Class Initialized
INFO - 2023-09-10 14:07:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:27 --> Input Class Initialized
INFO - 2023-09-10 14:07:27 --> Language Class Initialized
ERROR - 2023-09-10 14:07:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:29 --> Hooks Class Initialized
INFO - 2023-09-10 14:07:31 --> URI Class Initialized
DEBUG - 2023-09-10 14:07:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:32 --> Router Class Initialized
INFO - 2023-09-10 14:07:32 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:32 --> URI Class Initialized
INFO - 2023-09-10 14:07:32 --> Router Class Initialized
INFO - 2023-09-10 14:07:32 --> Output Class Initialized
INFO - 2023-09-10 14:07:32 --> Config Class Initialized
INFO - 2023-09-10 14:07:32 --> Output Class Initialized
INFO - 2023-09-10 14:07:33 --> Hooks Class Initialized
INFO - 2023-09-10 14:07:33 --> Security Class Initialized
INFO - 2023-09-10 14:07:33 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 14:07:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:33 --> Input Class Initialized
INFO - 2023-09-10 14:07:33 --> Utf8 Class Initialized
DEBUG - 2023-09-10 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:33 --> URI Class Initialized
INFO - 2023-09-10 14:07:33 --> Language Class Initialized
INFO - 2023-09-10 14:07:33 --> Input Class Initialized
ERROR - 2023-09-10 14:07:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:33 --> Language Class Initialized
ERROR - 2023-09-10 14:07:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:33 --> Router Class Initialized
INFO - 2023-09-10 14:07:33 --> Output Class Initialized
INFO - 2023-09-10 14:07:33 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:34 --> Input Class Initialized
INFO - 2023-09-10 14:07:34 --> Language Class Initialized
ERROR - 2023-09-10 14:07:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:34 --> Config Class Initialized
INFO - 2023-09-10 14:07:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:34 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:34 --> URI Class Initialized
INFO - 2023-09-10 14:07:34 --> Router Class Initialized
INFO - 2023-09-10 14:07:34 --> Output Class Initialized
INFO - 2023-09-10 14:07:34 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:34 --> Input Class Initialized
INFO - 2023-09-10 14:07:34 --> Language Class Initialized
ERROR - 2023-09-10 14:07:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:07:56 --> Config Class Initialized
INFO - 2023-09-10 14:07:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:07:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:07:56 --> Utf8 Class Initialized
INFO - 2023-09-10 14:07:56 --> URI Class Initialized
DEBUG - 2023-09-10 14:07:56 --> No URI present. Default controller set.
INFO - 2023-09-10 14:07:56 --> Router Class Initialized
INFO - 2023-09-10 14:07:56 --> Output Class Initialized
INFO - 2023-09-10 14:07:56 --> Security Class Initialized
DEBUG - 2023-09-10 14:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:07:56 --> Input Class Initialized
INFO - 2023-09-10 14:07:56 --> Language Class Initialized
INFO - 2023-09-10 14:07:56 --> Loader Class Initialized
INFO - 2023-09-10 14:07:56 --> Helper loaded: url_helper
INFO - 2023-09-10 14:07:56 --> Helper loaded: file_helper
INFO - 2023-09-10 14:07:56 --> Database Driver Class Initialized
INFO - 2023-09-10 14:07:56 --> Email Class Initialized
DEBUG - 2023-09-10 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:07:57 --> Controller Class Initialized
INFO - 2023-09-10 14:07:57 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:07:57 --> Model "Home_model" initialized
INFO - 2023-09-10 14:07:57 --> Helper loaded: download_helper
INFO - 2023-09-10 14:07:57 --> Helper loaded: form_helper
INFO - 2023-09-10 14:07:57 --> Form Validation Class Initialized
INFO - 2023-09-10 14:07:57 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:07:57 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:07:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:07:57 --> Final output sent to browser
DEBUG - 2023-09-10 14:07:58 --> Total execution time: 1.4902
INFO - 2023-09-10 14:08:01 --> Config Class Initialized
INFO - 2023-09-10 14:08:02 --> Hooks Class Initialized
INFO - 2023-09-10 14:08:02 --> Config Class Initialized
INFO - 2023-09-10 14:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:02 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:02 --> URI Class Initialized
INFO - 2023-09-10 14:08:02 --> Router Class Initialized
INFO - 2023-09-10 14:08:02 --> Output Class Initialized
INFO - 2023-09-10 14:08:02 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:02 --> Input Class Initialized
INFO - 2023-09-10 14:08:02 --> Language Class Initialized
ERROR - 2023-09-10 14:08:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:08:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:04 --> Config Class Initialized
INFO - 2023-09-10 14:08:04 --> Config Class Initialized
INFO - 2023-09-10 14:08:05 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:05 --> URI Class Initialized
INFO - 2023-09-10 14:08:05 --> Hooks Class Initialized
INFO - 2023-09-10 14:08:05 --> Router Class Initialized
DEBUG - 2023-09-10 14:08:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:08:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:06 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:07 --> URI Class Initialized
INFO - 2023-09-10 14:08:07 --> Router Class Initialized
INFO - 2023-09-10 14:08:07 --> Output Class Initialized
INFO - 2023-09-10 14:08:07 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:07 --> Input Class Initialized
INFO - 2023-09-10 14:08:07 --> Language Class Initialized
ERROR - 2023-09-10 14:08:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:08:07 --> Output Class Initialized
INFO - 2023-09-10 14:08:08 --> Config Class Initialized
INFO - 2023-09-10 14:08:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:08:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:08 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:08 --> URI Class Initialized
INFO - 2023-09-10 14:08:08 --> Router Class Initialized
INFO - 2023-09-10 14:08:08 --> Output Class Initialized
INFO - 2023-09-10 14:08:08 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:08 --> Input Class Initialized
INFO - 2023-09-10 14:08:08 --> Language Class Initialized
ERROR - 2023-09-10 14:08:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:08:08 --> Config Class Initialized
INFO - 2023-09-10 14:08:09 --> Hooks Class Initialized
INFO - 2023-09-10 14:08:09 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:10 --> URI Class Initialized
INFO - 2023-09-10 14:08:10 --> Router Class Initialized
INFO - 2023-09-10 14:08:10 --> Output Class Initialized
INFO - 2023-09-10 14:08:10 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:10 --> Input Class Initialized
INFO - 2023-09-10 14:08:10 --> Language Class Initialized
ERROR - 2023-09-10 14:08:10 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:08:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:10 --> Security Class Initialized
INFO - 2023-09-10 14:08:10 --> Config Class Initialized
DEBUG - 2023-09-10 14:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:10 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:10 --> URI Class Initialized
INFO - 2023-09-10 14:08:10 --> Input Class Initialized
INFO - 2023-09-10 14:08:10 --> Router Class Initialized
INFO - 2023-09-10 14:08:10 --> Hooks Class Initialized
INFO - 2023-09-10 14:08:10 --> Output Class Initialized
INFO - 2023-09-10 14:08:11 --> Language Class Initialized
ERROR - 2023-09-10 14:08:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:08:11 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:11 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:11 --> Input Class Initialized
INFO - 2023-09-10 14:08:11 --> URI Class Initialized
INFO - 2023-09-10 14:08:11 --> Router Class Initialized
INFO - 2023-09-10 14:08:11 --> Language Class Initialized
INFO - 2023-09-10 14:08:11 --> Output Class Initialized
ERROR - 2023-09-10 14:08:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:08:11 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:11 --> Input Class Initialized
INFO - 2023-09-10 14:08:11 --> Language Class Initialized
ERROR - 2023-09-10 14:08:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:08:55 --> Config Class Initialized
INFO - 2023-09-10 14:08:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:08:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:08:55 --> Utf8 Class Initialized
INFO - 2023-09-10 14:08:55 --> URI Class Initialized
DEBUG - 2023-09-10 14:08:55 --> No URI present. Default controller set.
INFO - 2023-09-10 14:08:55 --> Router Class Initialized
INFO - 2023-09-10 14:08:55 --> Output Class Initialized
INFO - 2023-09-10 14:08:55 --> Security Class Initialized
DEBUG - 2023-09-10 14:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:08:55 --> Input Class Initialized
INFO - 2023-09-10 14:08:55 --> Language Class Initialized
INFO - 2023-09-10 14:08:55 --> Loader Class Initialized
INFO - 2023-09-10 14:08:55 --> Helper loaded: url_helper
INFO - 2023-09-10 14:08:55 --> Helper loaded: file_helper
INFO - 2023-09-10 14:08:55 --> Database Driver Class Initialized
INFO - 2023-09-10 14:08:55 --> Email Class Initialized
DEBUG - 2023-09-10 14:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:08:55 --> Controller Class Initialized
INFO - 2023-09-10 14:08:55 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:08:55 --> Model "Home_model" initialized
INFO - 2023-09-10 14:08:55 --> Helper loaded: download_helper
INFO - 2023-09-10 14:08:55 --> Helper loaded: form_helper
INFO - 2023-09-10 14:08:55 --> Form Validation Class Initialized
INFO - 2023-09-10 14:08:55 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:08:55 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:08:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:08:55 --> Final output sent to browser
DEBUG - 2023-09-10 14:08:56 --> Total execution time: 0.6439
INFO - 2023-09-10 14:10:46 --> Config Class Initialized
INFO - 2023-09-10 14:10:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:10:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:10:46 --> Utf8 Class Initialized
INFO - 2023-09-10 14:10:47 --> URI Class Initialized
DEBUG - 2023-09-10 14:10:47 --> No URI present. Default controller set.
INFO - 2023-09-10 14:10:47 --> Router Class Initialized
INFO - 2023-09-10 14:10:47 --> Output Class Initialized
INFO - 2023-09-10 14:10:47 --> Security Class Initialized
DEBUG - 2023-09-10 14:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:10:47 --> Input Class Initialized
INFO - 2023-09-10 14:10:47 --> Language Class Initialized
INFO - 2023-09-10 14:10:47 --> Loader Class Initialized
INFO - 2023-09-10 14:10:47 --> Helper loaded: url_helper
INFO - 2023-09-10 14:10:47 --> Helper loaded: file_helper
INFO - 2023-09-10 14:10:47 --> Database Driver Class Initialized
INFO - 2023-09-10 14:10:47 --> Email Class Initialized
DEBUG - 2023-09-10 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:10:47 --> Controller Class Initialized
INFO - 2023-09-10 14:10:47 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:10:47 --> Model "Home_model" initialized
INFO - 2023-09-10 14:10:47 --> Helper loaded: download_helper
INFO - 2023-09-10 14:10:47 --> Helper loaded: form_helper
INFO - 2023-09-10 14:10:47 --> Form Validation Class Initialized
INFO - 2023-09-10 14:10:47 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:10:47 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:10:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:10:48 --> Final output sent to browser
DEBUG - 2023-09-10 14:10:48 --> Total execution time: 1.1590
INFO - 2023-09-10 14:11:26 --> Config Class Initialized
INFO - 2023-09-10 14:11:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:27 --> URI Class Initialized
INFO - 2023-09-10 14:11:27 --> Router Class Initialized
INFO - 2023-09-10 14:11:27 --> Output Class Initialized
INFO - 2023-09-10 14:11:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:27 --> Input Class Initialized
INFO - 2023-09-10 14:11:27 --> Language Class Initialized
ERROR - 2023-09-10 14:11:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:28 --> Config Class Initialized
INFO - 2023-09-10 14:11:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:28 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:28 --> URI Class Initialized
INFO - 2023-09-10 14:11:28 --> Router Class Initialized
INFO - 2023-09-10 14:11:28 --> Output Class Initialized
INFO - 2023-09-10 14:11:28 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:28 --> Input Class Initialized
INFO - 2023-09-10 14:11:28 --> Language Class Initialized
ERROR - 2023-09-10 14:11:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:28 --> Config Class Initialized
INFO - 2023-09-10 14:11:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:29 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:29 --> URI Class Initialized
INFO - 2023-09-10 14:11:29 --> Router Class Initialized
INFO - 2023-09-10 14:11:29 --> Output Class Initialized
INFO - 2023-09-10 14:11:30 --> Security Class Initialized
INFO - 2023-09-10 14:11:30 --> Config Class Initialized
DEBUG - 2023-09-10 14:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:31 --> Hooks Class Initialized
INFO - 2023-09-10 14:11:31 --> Input Class Initialized
DEBUG - 2023-09-10 14:11:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:31 --> URI Class Initialized
INFO - 2023-09-10 14:11:31 --> Router Class Initialized
INFO - 2023-09-10 14:11:31 --> Output Class Initialized
INFO - 2023-09-10 14:11:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:31 --> Input Class Initialized
INFO - 2023-09-10 14:11:31 --> Language Class Initialized
ERROR - 2023-09-10 14:11:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:31 --> Language Class Initialized
ERROR - 2023-09-10 14:11:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:33 --> Config Class Initialized
INFO - 2023-09-10 14:11:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:34 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:34 --> URI Class Initialized
INFO - 2023-09-10 14:11:34 --> Router Class Initialized
INFO - 2023-09-10 14:11:34 --> Output Class Initialized
INFO - 2023-09-10 14:11:34 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:34 --> Input Class Initialized
INFO - 2023-09-10 14:11:34 --> Language Class Initialized
ERROR - 2023-09-10 14:11:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:34 --> Config Class Initialized
INFO - 2023-09-10 14:11:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:35 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:35 --> URI Class Initialized
INFO - 2023-09-10 14:11:35 --> Router Class Initialized
INFO - 2023-09-10 14:11:35 --> Output Class Initialized
INFO - 2023-09-10 14:11:35 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:35 --> Input Class Initialized
INFO - 2023-09-10 14:11:35 --> Language Class Initialized
ERROR - 2023-09-10 14:11:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:11:35 --> Config Class Initialized
INFO - 2023-09-10 14:11:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:11:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:11:35 --> Utf8 Class Initialized
INFO - 2023-09-10 14:11:35 --> URI Class Initialized
INFO - 2023-09-10 14:11:35 --> Router Class Initialized
INFO - 2023-09-10 14:11:35 --> Output Class Initialized
INFO - 2023-09-10 14:11:35 --> Security Class Initialized
DEBUG - 2023-09-10 14:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:11:35 --> Input Class Initialized
INFO - 2023-09-10 14:11:35 --> Language Class Initialized
ERROR - 2023-09-10 14:11:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:09 --> Config Class Initialized
INFO - 2023-09-10 14:12:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:10 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:10 --> URI Class Initialized
DEBUG - 2023-09-10 14:12:10 --> No URI present. Default controller set.
INFO - 2023-09-10 14:12:10 --> Router Class Initialized
INFO - 2023-09-10 14:12:10 --> Output Class Initialized
INFO - 2023-09-10 14:12:10 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:10 --> Input Class Initialized
INFO - 2023-09-10 14:12:10 --> Language Class Initialized
INFO - 2023-09-10 14:12:10 --> Loader Class Initialized
INFO - 2023-09-10 14:12:10 --> Helper loaded: url_helper
INFO - 2023-09-10 14:12:10 --> Helper loaded: file_helper
INFO - 2023-09-10 14:12:11 --> Database Driver Class Initialized
INFO - 2023-09-10 14:12:11 --> Email Class Initialized
DEBUG - 2023-09-10 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:12:11 --> Controller Class Initialized
INFO - 2023-09-10 14:12:11 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:12:11 --> Model "Home_model" initialized
INFO - 2023-09-10 14:12:11 --> Helper loaded: download_helper
INFO - 2023-09-10 14:12:11 --> Helper loaded: form_helper
INFO - 2023-09-10 14:12:11 --> Form Validation Class Initialized
INFO - 2023-09-10 14:12:11 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:12:11 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:12:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:12:11 --> Final output sent to browser
DEBUG - 2023-09-10 14:12:11 --> Total execution time: 2.4855
INFO - 2023-09-10 14:12:33 --> Config Class Initialized
INFO - 2023-09-10 14:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:33 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:33 --> URI Class Initialized
INFO - 2023-09-10 14:12:33 --> Router Class Initialized
INFO - 2023-09-10 14:12:33 --> Output Class Initialized
INFO - 2023-09-10 14:12:33 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:33 --> Input Class Initialized
INFO - 2023-09-10 14:12:33 --> Language Class Initialized
ERROR - 2023-09-10 14:12:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:34 --> Config Class Initialized
INFO - 2023-09-10 14:12:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:34 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:34 --> URI Class Initialized
INFO - 2023-09-10 14:12:34 --> Router Class Initialized
INFO - 2023-09-10 14:12:34 --> Output Class Initialized
INFO - 2023-09-10 14:12:34 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:34 --> Input Class Initialized
INFO - 2023-09-10 14:12:34 --> Language Class Initialized
ERROR - 2023-09-10 14:12:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:34 --> Config Class Initialized
INFO - 2023-09-10 14:12:34 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:34 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:34 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:35 --> URI Class Initialized
INFO - 2023-09-10 14:12:35 --> Router Class Initialized
INFO - 2023-09-10 14:12:35 --> Output Class Initialized
INFO - 2023-09-10 14:12:35 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:35 --> Input Class Initialized
INFO - 2023-09-10 14:12:35 --> Language Class Initialized
ERROR - 2023-09-10 14:12:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:37 --> Config Class Initialized
INFO - 2023-09-10 14:12:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:37 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:37 --> URI Class Initialized
INFO - 2023-09-10 14:12:37 --> Router Class Initialized
INFO - 2023-09-10 14:12:37 --> Output Class Initialized
INFO - 2023-09-10 14:12:37 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:37 --> Input Class Initialized
INFO - 2023-09-10 14:12:37 --> Language Class Initialized
ERROR - 2023-09-10 14:12:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:37 --> Config Class Initialized
INFO - 2023-09-10 14:12:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:12:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:39 --> Config Class Initialized
INFO - 2023-09-10 14:12:39 --> Hooks Class Initialized
INFO - 2023-09-10 14:12:39 --> Utf8 Class Initialized
DEBUG - 2023-09-10 14:12:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:40 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:40 --> Config Class Initialized
INFO - 2023-09-10 14:12:41 --> URI Class Initialized
INFO - 2023-09-10 14:12:42 --> Router Class Initialized
INFO - 2023-09-10 14:12:42 --> Output Class Initialized
INFO - 2023-09-10 14:12:42 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:43 --> URI Class Initialized
INFO - 2023-09-10 14:12:43 --> Hooks Class Initialized
INFO - 2023-09-10 14:12:43 --> Input Class Initialized
DEBUG - 2023-09-10 14:12:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:12:43 --> Language Class Initialized
ERROR - 2023-09-10 14:12:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:43 --> Utf8 Class Initialized
INFO - 2023-09-10 14:12:43 --> URI Class Initialized
INFO - 2023-09-10 14:12:43 --> Router Class Initialized
INFO - 2023-09-10 14:12:43 --> Output Class Initialized
INFO - 2023-09-10 14:12:43 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:43 --> Input Class Initialized
INFO - 2023-09-10 14:12:43 --> Language Class Initialized
ERROR - 2023-09-10 14:12:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:12:43 --> Router Class Initialized
INFO - 2023-09-10 14:12:44 --> Output Class Initialized
INFO - 2023-09-10 14:12:44 --> Security Class Initialized
DEBUG - 2023-09-10 14:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:12:44 --> Input Class Initialized
INFO - 2023-09-10 14:12:44 --> Language Class Initialized
ERROR - 2023-09-10 14:12:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:21 --> Config Class Initialized
INFO - 2023-09-10 14:13:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:22 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:22 --> URI Class Initialized
DEBUG - 2023-09-10 14:13:22 --> No URI present. Default controller set.
INFO - 2023-09-10 14:13:22 --> Router Class Initialized
INFO - 2023-09-10 14:13:22 --> Output Class Initialized
INFO - 2023-09-10 14:13:22 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:22 --> Input Class Initialized
INFO - 2023-09-10 14:13:22 --> Language Class Initialized
INFO - 2023-09-10 14:13:22 --> Loader Class Initialized
INFO - 2023-09-10 14:13:22 --> Helper loaded: url_helper
INFO - 2023-09-10 14:13:22 --> Helper loaded: file_helper
INFO - 2023-09-10 14:13:22 --> Database Driver Class Initialized
INFO - 2023-09-10 14:13:22 --> Email Class Initialized
DEBUG - 2023-09-10 14:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:13:23 --> Controller Class Initialized
INFO - 2023-09-10 14:13:23 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:13:23 --> Model "Home_model" initialized
INFO - 2023-09-10 14:13:23 --> Helper loaded: download_helper
INFO - 2023-09-10 14:13:23 --> Helper loaded: form_helper
INFO - 2023-09-10 14:13:23 --> Form Validation Class Initialized
INFO - 2023-09-10 14:13:23 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:13:23 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:13:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:13:23 --> Final output sent to browser
DEBUG - 2023-09-10 14:13:24 --> Total execution time: 1.5973
INFO - 2023-09-10 14:13:28 --> Config Class Initialized
INFO - 2023-09-10 14:13:28 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:28 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:28 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:28 --> URI Class Initialized
INFO - 2023-09-10 14:13:28 --> Router Class Initialized
INFO - 2023-09-10 14:13:28 --> Output Class Initialized
INFO - 2023-09-10 14:13:28 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:28 --> Input Class Initialized
INFO - 2023-09-10 14:13:28 --> Language Class Initialized
ERROR - 2023-09-10 14:13:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:29 --> Config Class Initialized
INFO - 2023-09-10 14:13:29 --> Hooks Class Initialized
INFO - 2023-09-10 14:13:29 --> Config Class Initialized
INFO - 2023-09-10 14:13:29 --> Hooks Class Initialized
INFO - 2023-09-10 14:13:29 --> Config Class Initialized
INFO - 2023-09-10 14:13:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:29 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:29 --> URI Class Initialized
INFO - 2023-09-10 14:13:30 --> Config Class Initialized
INFO - 2023-09-10 14:13:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:30 --> URI Class Initialized
INFO - 2023-09-10 14:13:30 --> Router Class Initialized
INFO - 2023-09-10 14:13:30 --> Output Class Initialized
INFO - 2023-09-10 14:13:30 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:30 --> Input Class Initialized
INFO - 2023-09-10 14:13:30 --> Language Class Initialized
ERROR - 2023-09-10 14:13:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:30 --> Config Class Initialized
INFO - 2023-09-10 14:13:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:30 --> URI Class Initialized
INFO - 2023-09-10 14:13:30 --> Router Class Initialized
INFO - 2023-09-10 14:13:30 --> Output Class Initialized
INFO - 2023-09-10 14:13:30 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:30 --> Input Class Initialized
INFO - 2023-09-10 14:13:30 --> Language Class Initialized
ERROR - 2023-09-10 14:13:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:13:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:31 --> URI Class Initialized
INFO - 2023-09-10 14:13:31 --> Router Class Initialized
INFO - 2023-09-10 14:13:31 --> Output Class Initialized
INFO - 2023-09-10 14:13:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:31 --> Input Class Initialized
INFO - 2023-09-10 14:13:31 --> Language Class Initialized
ERROR - 2023-09-10 14:13:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:31 --> Router Class Initialized
INFO - 2023-09-10 14:13:31 --> Output Class Initialized
INFO - 2023-09-10 14:13:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:31 --> Input Class Initialized
INFO - 2023-09-10 14:13:31 --> Language Class Initialized
ERROR - 2023-09-10 14:13:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:13:31 --> URI Class Initialized
INFO - 2023-09-10 14:13:31 --> Router Class Initialized
INFO - 2023-09-10 14:13:31 --> Output Class Initialized
INFO - 2023-09-10 14:13:32 --> Config Class Initialized
INFO - 2023-09-10 14:13:32 --> Security Class Initialized
INFO - 2023-09-10 14:13:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:13:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:13:32 --> Utf8 Class Initialized
DEBUG - 2023-09-10 14:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:33 --> URI Class Initialized
INFO - 2023-09-10 14:13:33 --> Input Class Initialized
INFO - 2023-09-10 14:13:34 --> Router Class Initialized
INFO - 2023-09-10 14:13:34 --> Output Class Initialized
INFO - 2023-09-10 14:13:34 --> Language Class Initialized
INFO - 2023-09-10 14:13:34 --> Security Class Initialized
DEBUG - 2023-09-10 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:13:35 --> Input Class Initialized
ERROR - 2023-09-10 14:13:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:13:35 --> Language Class Initialized
ERROR - 2023-09-10 14:13:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:16:36 --> Config Class Initialized
INFO - 2023-09-10 14:16:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:16:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:16:36 --> Utf8 Class Initialized
INFO - 2023-09-10 14:16:36 --> URI Class Initialized
DEBUG - 2023-09-10 14:16:36 --> No URI present. Default controller set.
INFO - 2023-09-10 14:16:36 --> Router Class Initialized
INFO - 2023-09-10 14:16:36 --> Output Class Initialized
INFO - 2023-09-10 14:16:37 --> Security Class Initialized
DEBUG - 2023-09-10 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:16:37 --> Input Class Initialized
INFO - 2023-09-10 14:16:37 --> Language Class Initialized
INFO - 2023-09-10 14:16:37 --> Loader Class Initialized
INFO - 2023-09-10 14:16:37 --> Helper loaded: url_helper
INFO - 2023-09-10 14:16:37 --> Helper loaded: file_helper
INFO - 2023-09-10 14:16:37 --> Database Driver Class Initialized
INFO - 2023-09-10 14:16:37 --> Email Class Initialized
DEBUG - 2023-09-10 14:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:16:37 --> Controller Class Initialized
INFO - 2023-09-10 14:16:37 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:16:38 --> Model "Home_model" initialized
INFO - 2023-09-10 14:16:38 --> Helper loaded: download_helper
INFO - 2023-09-10 14:16:38 --> Helper loaded: form_helper
INFO - 2023-09-10 14:16:38 --> Form Validation Class Initialized
INFO - 2023-09-10 14:16:38 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:16:38 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:16:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:16:38 --> Final output sent to browser
DEBUG - 2023-09-10 14:16:38 --> Total execution time: 1.9327
INFO - 2023-09-10 14:17:25 --> Config Class Initialized
INFO - 2023-09-10 14:17:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:17:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:17:25 --> Utf8 Class Initialized
INFO - 2023-09-10 14:17:25 --> URI Class Initialized
DEBUG - 2023-09-10 14:17:25 --> No URI present. Default controller set.
INFO - 2023-09-10 14:17:25 --> Router Class Initialized
INFO - 2023-09-10 14:17:25 --> Output Class Initialized
INFO - 2023-09-10 14:17:25 --> Security Class Initialized
DEBUG - 2023-09-10 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:17:25 --> Input Class Initialized
INFO - 2023-09-10 14:17:25 --> Language Class Initialized
INFO - 2023-09-10 14:17:25 --> Loader Class Initialized
INFO - 2023-09-10 14:17:25 --> Helper loaded: url_helper
INFO - 2023-09-10 14:17:25 --> Helper loaded: file_helper
INFO - 2023-09-10 14:17:25 --> Database Driver Class Initialized
INFO - 2023-09-10 14:17:25 --> Email Class Initialized
DEBUG - 2023-09-10 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:17:25 --> Controller Class Initialized
INFO - 2023-09-10 14:17:25 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:17:25 --> Model "Home_model" initialized
INFO - 2023-09-10 14:17:25 --> Helper loaded: download_helper
INFO - 2023-09-10 14:17:25 --> Helper loaded: form_helper
INFO - 2023-09-10 14:17:25 --> Form Validation Class Initialized
INFO - 2023-09-10 14:17:25 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:17:25 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:17:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:17:25 --> Final output sent to browser
DEBUG - 2023-09-10 14:17:26 --> Total execution time: 0.4243
INFO - 2023-09-10 14:17:29 --> Config Class Initialized
INFO - 2023-09-10 14:17:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:17:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:17:30 --> Utf8 Class Initialized
INFO - 2023-09-10 14:17:30 --> URI Class Initialized
DEBUG - 2023-09-10 14:17:30 --> No URI present. Default controller set.
INFO - 2023-09-10 14:17:30 --> Router Class Initialized
INFO - 2023-09-10 14:17:30 --> Output Class Initialized
INFO - 2023-09-10 14:17:30 --> Security Class Initialized
DEBUG - 2023-09-10 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:17:30 --> Input Class Initialized
INFO - 2023-09-10 14:17:30 --> Language Class Initialized
INFO - 2023-09-10 14:17:30 --> Loader Class Initialized
INFO - 2023-09-10 14:17:30 --> Helper loaded: url_helper
INFO - 2023-09-10 14:17:30 --> Helper loaded: file_helper
INFO - 2023-09-10 14:17:30 --> Database Driver Class Initialized
INFO - 2023-09-10 14:17:30 --> Email Class Initialized
DEBUG - 2023-09-10 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:17:30 --> Controller Class Initialized
INFO - 2023-09-10 14:17:30 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:17:30 --> Model "Home_model" initialized
INFO - 2023-09-10 14:17:30 --> Helper loaded: download_helper
INFO - 2023-09-10 14:17:31 --> Helper loaded: form_helper
INFO - 2023-09-10 14:17:31 --> Form Validation Class Initialized
INFO - 2023-09-10 14:17:31 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:17:31 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:17:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:17:31 --> Final output sent to browser
DEBUG - 2023-09-10 14:17:31 --> Total execution time: 1.4486
INFO - 2023-09-10 14:19:04 --> Config Class Initialized
INFO - 2023-09-10 14:19:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:19:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:19:04 --> Utf8 Class Initialized
INFO - 2023-09-10 14:19:04 --> URI Class Initialized
DEBUG - 2023-09-10 14:19:05 --> No URI present. Default controller set.
INFO - 2023-09-10 14:19:05 --> Router Class Initialized
INFO - 2023-09-10 14:19:05 --> Output Class Initialized
INFO - 2023-09-10 14:19:05 --> Security Class Initialized
DEBUG - 2023-09-10 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:19:05 --> Input Class Initialized
INFO - 2023-09-10 14:19:05 --> Language Class Initialized
INFO - 2023-09-10 14:19:05 --> Loader Class Initialized
INFO - 2023-09-10 14:19:05 --> Helper loaded: url_helper
INFO - 2023-09-10 14:19:05 --> Helper loaded: file_helper
INFO - 2023-09-10 14:19:05 --> Database Driver Class Initialized
INFO - 2023-09-10 14:19:05 --> Email Class Initialized
DEBUG - 2023-09-10 14:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:19:05 --> Controller Class Initialized
INFO - 2023-09-10 14:19:05 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:19:05 --> Model "Home_model" initialized
INFO - 2023-09-10 14:19:05 --> Helper loaded: download_helper
INFO - 2023-09-10 14:19:05 --> Helper loaded: form_helper
INFO - 2023-09-10 14:19:05 --> Form Validation Class Initialized
INFO - 2023-09-10 14:19:05 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:19:05 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:19:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:19:05 --> Final output sent to browser
DEBUG - 2023-09-10 14:19:06 --> Total execution time: 0.9973
INFO - 2023-09-10 14:20:23 --> Config Class Initialized
INFO - 2023-09-10 14:20:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:20:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:20:23 --> Utf8 Class Initialized
INFO - 2023-09-10 14:20:23 --> URI Class Initialized
DEBUG - 2023-09-10 14:20:23 --> No URI present. Default controller set.
INFO - 2023-09-10 14:20:23 --> Router Class Initialized
INFO - 2023-09-10 14:20:23 --> Output Class Initialized
INFO - 2023-09-10 14:20:23 --> Security Class Initialized
DEBUG - 2023-09-10 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:20:23 --> Input Class Initialized
INFO - 2023-09-10 14:20:23 --> Language Class Initialized
INFO - 2023-09-10 14:20:23 --> Loader Class Initialized
INFO - 2023-09-10 14:20:24 --> Helper loaded: url_helper
INFO - 2023-09-10 14:20:24 --> Helper loaded: file_helper
INFO - 2023-09-10 14:20:24 --> Database Driver Class Initialized
INFO - 2023-09-10 14:20:24 --> Email Class Initialized
DEBUG - 2023-09-10 14:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:20:24 --> Controller Class Initialized
INFO - 2023-09-10 14:20:24 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:20:24 --> Model "Home_model" initialized
INFO - 2023-09-10 14:20:24 --> Helper loaded: download_helper
INFO - 2023-09-10 14:20:24 --> Helper loaded: form_helper
INFO - 2023-09-10 14:20:24 --> Form Validation Class Initialized
INFO - 2023-09-10 14:20:24 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:20:24 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:20:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:20:25 --> Final output sent to browser
DEBUG - 2023-09-10 14:20:25 --> Total execution time: 1.6447
INFO - 2023-09-10 14:20:52 --> Config Class Initialized
INFO - 2023-09-10 14:20:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:20:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:20:52 --> Utf8 Class Initialized
INFO - 2023-09-10 14:20:52 --> URI Class Initialized
INFO - 2023-09-10 14:20:52 --> Router Class Initialized
INFO - 2023-09-10 14:20:52 --> Output Class Initialized
INFO - 2023-09-10 14:20:52 --> Security Class Initialized
DEBUG - 2023-09-10 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:20:53 --> Input Class Initialized
INFO - 2023-09-10 14:20:53 --> Language Class Initialized
INFO - 2023-09-10 14:20:53 --> Loader Class Initialized
INFO - 2023-09-10 14:20:53 --> Helper loaded: url_helper
INFO - 2023-09-10 14:20:53 --> Helper loaded: file_helper
INFO - 2023-09-10 14:20:53 --> Database Driver Class Initialized
INFO - 2023-09-10 14:20:53 --> Email Class Initialized
DEBUG - 2023-09-10 14:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:20:54 --> Controller Class Initialized
INFO - 2023-09-10 14:20:54 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:20:54 --> Model "Home_model" initialized
INFO - 2023-09-10 14:20:54 --> Helper loaded: download_helper
INFO - 2023-09-10 14:20:54 --> Helper loaded: form_helper
INFO - 2023-09-10 14:20:54 --> Form Validation Class Initialized
INFO - 2023-09-10 14:20:54 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:20:54 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:20:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:20:54 --> Final output sent to browser
DEBUG - 2023-09-10 14:20:54 --> Total execution time: 2.3267
INFO - 2023-09-10 14:22:14 --> Config Class Initialized
INFO - 2023-09-10 14:22:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:22:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:22:14 --> Utf8 Class Initialized
INFO - 2023-09-10 14:22:14 --> URI Class Initialized
INFO - 2023-09-10 14:22:14 --> Router Class Initialized
INFO - 2023-09-10 14:22:14 --> Output Class Initialized
INFO - 2023-09-10 14:22:14 --> Security Class Initialized
DEBUG - 2023-09-10 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:22:14 --> Input Class Initialized
INFO - 2023-09-10 14:22:14 --> Language Class Initialized
INFO - 2023-09-10 14:22:14 --> Loader Class Initialized
INFO - 2023-09-10 14:22:14 --> Helper loaded: url_helper
INFO - 2023-09-10 14:22:14 --> Helper loaded: file_helper
INFO - 2023-09-10 14:22:14 --> Database Driver Class Initialized
INFO - 2023-09-10 14:22:14 --> Email Class Initialized
DEBUG - 2023-09-10 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:22:15 --> Controller Class Initialized
INFO - 2023-09-10 14:22:15 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:22:15 --> Model "Home_model" initialized
INFO - 2023-09-10 14:22:15 --> Helper loaded: download_helper
INFO - 2023-09-10 14:22:15 --> Helper loaded: form_helper
INFO - 2023-09-10 14:22:15 --> Form Validation Class Initialized
INFO - 2023-09-10 14:22:15 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:22:15 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:22:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:22:15 --> Final output sent to browser
DEBUG - 2023-09-10 14:22:15 --> Total execution time: 1.2079
INFO - 2023-09-10 14:24:22 --> Config Class Initialized
INFO - 2023-09-10 14:24:22 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:24:22 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:24:22 --> Utf8 Class Initialized
INFO - 2023-09-10 14:24:22 --> URI Class Initialized
INFO - 2023-09-10 14:24:22 --> Router Class Initialized
INFO - 2023-09-10 14:24:22 --> Output Class Initialized
INFO - 2023-09-10 14:24:22 --> Security Class Initialized
DEBUG - 2023-09-10 14:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:24:22 --> Input Class Initialized
INFO - 2023-09-10 14:24:22 --> Language Class Initialized
INFO - 2023-09-10 14:24:22 --> Loader Class Initialized
INFO - 2023-09-10 14:24:22 --> Helper loaded: url_helper
INFO - 2023-09-10 14:24:22 --> Helper loaded: file_helper
INFO - 2023-09-10 14:24:22 --> Database Driver Class Initialized
INFO - 2023-09-10 14:24:22 --> Email Class Initialized
DEBUG - 2023-09-10 14:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:24:22 --> Controller Class Initialized
INFO - 2023-09-10 14:24:22 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:24:22 --> Model "Home_model" initialized
INFO - 2023-09-10 14:24:22 --> Helper loaded: download_helper
INFO - 2023-09-10 14:24:22 --> Helper loaded: form_helper
INFO - 2023-09-10 14:24:22 --> Form Validation Class Initialized
INFO - 2023-09-10 14:24:22 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:24:22 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:24:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:24:22 --> Final output sent to browser
DEBUG - 2023-09-10 14:24:22 --> Total execution time: 0.2223
INFO - 2023-09-10 14:25:18 --> Config Class Initialized
INFO - 2023-09-10 14:25:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:25:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:25:19 --> Utf8 Class Initialized
INFO - 2023-09-10 14:25:19 --> URI Class Initialized
INFO - 2023-09-10 14:25:19 --> Router Class Initialized
INFO - 2023-09-10 14:25:19 --> Output Class Initialized
INFO - 2023-09-10 14:25:19 --> Security Class Initialized
DEBUG - 2023-09-10 14:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:25:19 --> Input Class Initialized
INFO - 2023-09-10 14:25:19 --> Language Class Initialized
INFO - 2023-09-10 14:25:19 --> Loader Class Initialized
INFO - 2023-09-10 14:25:19 --> Helper loaded: url_helper
INFO - 2023-09-10 14:25:19 --> Helper loaded: file_helper
INFO - 2023-09-10 14:25:19 --> Database Driver Class Initialized
INFO - 2023-09-10 14:25:19 --> Email Class Initialized
DEBUG - 2023-09-10 14:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:25:19 --> Controller Class Initialized
INFO - 2023-09-10 14:25:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:25:19 --> Model "Home_model" initialized
INFO - 2023-09-10 14:25:20 --> Helper loaded: download_helper
INFO - 2023-09-10 14:25:20 --> Helper loaded: form_helper
INFO - 2023-09-10 14:25:20 --> Form Validation Class Initialized
INFO - 2023-09-10 14:25:20 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:25:20 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:25:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:25:20 --> Final output sent to browser
DEBUG - 2023-09-10 14:25:20 --> Total execution time: 1.4130
INFO - 2023-09-10 14:25:27 --> Config Class Initialized
INFO - 2023-09-10 14:25:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:25:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:25:27 --> URI Class Initialized
INFO - 2023-09-10 14:25:27 --> Router Class Initialized
INFO - 2023-09-10 14:25:27 --> Output Class Initialized
INFO - 2023-09-10 14:25:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:25:27 --> Input Class Initialized
INFO - 2023-09-10 14:25:27 --> Language Class Initialized
INFO - 2023-09-10 14:25:27 --> Loader Class Initialized
INFO - 2023-09-10 14:25:27 --> Helper loaded: url_helper
INFO - 2023-09-10 14:25:27 --> Helper loaded: file_helper
INFO - 2023-09-10 14:25:27 --> Database Driver Class Initialized
INFO - 2023-09-10 14:25:27 --> Email Class Initialized
DEBUG - 2023-09-10 14:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:25:27 --> Controller Class Initialized
INFO - 2023-09-10 14:25:27 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:25:27 --> Model "Home_model" initialized
INFO - 2023-09-10 14:25:27 --> Helper loaded: download_helper
INFO - 2023-09-10 14:25:27 --> Helper loaded: form_helper
INFO - 2023-09-10 14:25:27 --> Form Validation Class Initialized
INFO - 2023-09-10 14:25:27 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:25:27 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:25:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:25:27 --> Final output sent to browser
DEBUG - 2023-09-10 14:25:27 --> Total execution time: 0.0809
INFO - 2023-09-10 14:25:32 --> Config Class Initialized
INFO - 2023-09-10 14:25:32 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:25:32 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:25:32 --> Utf8 Class Initialized
INFO - 2023-09-10 14:25:32 --> URI Class Initialized
DEBUG - 2023-09-10 14:25:32 --> No URI present. Default controller set.
INFO - 2023-09-10 14:25:32 --> Router Class Initialized
INFO - 2023-09-10 14:25:32 --> Output Class Initialized
INFO - 2023-09-10 14:25:32 --> Security Class Initialized
DEBUG - 2023-09-10 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:25:32 --> Input Class Initialized
INFO - 2023-09-10 14:25:32 --> Language Class Initialized
INFO - 2023-09-10 14:25:32 --> Loader Class Initialized
INFO - 2023-09-10 14:25:32 --> Helper loaded: url_helper
INFO - 2023-09-10 14:25:32 --> Helper loaded: file_helper
INFO - 2023-09-10 14:25:32 --> Database Driver Class Initialized
INFO - 2023-09-10 14:25:33 --> Email Class Initialized
DEBUG - 2023-09-10 14:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:25:33 --> Controller Class Initialized
INFO - 2023-09-10 14:25:33 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:25:33 --> Model "Home_model" initialized
INFO - 2023-09-10 14:25:33 --> Helper loaded: download_helper
INFO - 2023-09-10 14:25:33 --> Helper loaded: form_helper
INFO - 2023-09-10 14:25:33 --> Form Validation Class Initialized
INFO - 2023-09-10 14:25:33 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:25:33 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:25:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:25:33 --> Final output sent to browser
DEBUG - 2023-09-10 14:25:33 --> Total execution time: 0.0705
INFO - 2023-09-10 14:26:03 --> Config Class Initialized
INFO - 2023-09-10 14:26:04 --> Config Class Initialized
INFO - 2023-09-10 14:26:04 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 14:26:05 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:05 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:05 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:05 --> URI Class Initialized
INFO - 2023-09-10 14:26:05 --> Router Class Initialized
INFO - 2023-09-10 14:26:05 --> URI Class Initialized
INFO - 2023-09-10 14:26:05 --> Output Class Initialized
INFO - 2023-09-10 14:26:06 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:06 --> Router Class Initialized
INFO - 2023-09-10 14:26:06 --> Input Class Initialized
INFO - 2023-09-10 14:26:06 --> Output Class Initialized
INFO - 2023-09-10 14:26:06 --> Language Class Initialized
INFO - 2023-09-10 14:26:06 --> Security Class Initialized
ERROR - 2023-09-10 14:26:06 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:06 --> Input Class Initialized
INFO - 2023-09-10 14:26:06 --> Language Class Initialized
ERROR - 2023-09-10 14:26:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:06 --> Config Class Initialized
INFO - 2023-09-10 14:26:06 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:06 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:06 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:06 --> URI Class Initialized
INFO - 2023-09-10 14:26:06 --> Router Class Initialized
INFO - 2023-09-10 14:26:06 --> Output Class Initialized
INFO - 2023-09-10 14:26:06 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:06 --> Input Class Initialized
INFO - 2023-09-10 14:26:06 --> Language Class Initialized
ERROR - 2023-09-10 14:26:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:06 --> Config Class Initialized
INFO - 2023-09-10 14:26:06 --> Config Class Initialized
INFO - 2023-09-10 14:26:06 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:06 --> Config Class Initialized
DEBUG - 2023-09-10 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:07 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:07 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:07 --> Config Class Initialized
DEBUG - 2023-09-10 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:07 --> URI Class Initialized
INFO - 2023-09-10 14:26:07 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:07 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:07 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:07 --> URI Class Initialized
INFO - 2023-09-10 14:26:07 --> Router Class Initialized
INFO - 2023-09-10 14:26:07 --> Output Class Initialized
INFO - 2023-09-10 14:26:07 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:07 --> Input Class Initialized
INFO - 2023-09-10 14:26:07 --> Language Class Initialized
ERROR - 2023-09-10 14:26:07 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:07 --> Router Class Initialized
INFO - 2023-09-10 14:26:07 --> Output Class Initialized
DEBUG - 2023-09-10 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:07 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:07 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:07 --> URI Class Initialized
INFO - 2023-09-10 14:26:07 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:07 --> Router Class Initialized
INFO - 2023-09-10 14:26:07 --> URI Class Initialized
INFO - 2023-09-10 14:26:07 --> Input Class Initialized
INFO - 2023-09-10 14:26:07 --> Output Class Initialized
INFO - 2023-09-10 14:26:07 --> Language Class Initialized
INFO - 2023-09-10 14:26:07 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 14:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:07 --> Router Class Initialized
INFO - 2023-09-10 14:26:07 --> Output Class Initialized
INFO - 2023-09-10 14:26:07 --> Input Class Initialized
INFO - 2023-09-10 14:26:07 --> Security Class Initialized
INFO - 2023-09-10 14:26:07 --> Language Class Initialized
ERROR - 2023-09-10 14:26:07 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:07 --> Input Class Initialized
INFO - 2023-09-10 14:26:07 --> Language Class Initialized
ERROR - 2023-09-10 14:26:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:42 --> Config Class Initialized
INFO - 2023-09-10 14:26:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:42 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:42 --> URI Class Initialized
DEBUG - 2023-09-10 14:26:43 --> No URI present. Default controller set.
INFO - 2023-09-10 14:26:43 --> Router Class Initialized
INFO - 2023-09-10 14:26:43 --> Output Class Initialized
INFO - 2023-09-10 14:26:43 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:43 --> Input Class Initialized
INFO - 2023-09-10 14:26:43 --> Language Class Initialized
INFO - 2023-09-10 14:26:43 --> Loader Class Initialized
INFO - 2023-09-10 14:26:43 --> Helper loaded: url_helper
INFO - 2023-09-10 14:26:43 --> Helper loaded: file_helper
INFO - 2023-09-10 14:26:43 --> Database Driver Class Initialized
INFO - 2023-09-10 14:26:43 --> Email Class Initialized
DEBUG - 2023-09-10 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:26:43 --> Controller Class Initialized
INFO - 2023-09-10 14:26:43 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:26:43 --> Model "Home_model" initialized
INFO - 2023-09-10 14:26:43 --> Helper loaded: download_helper
INFO - 2023-09-10 14:26:43 --> Helper loaded: form_helper
INFO - 2023-09-10 14:26:44 --> Form Validation Class Initialized
INFO - 2023-09-10 14:26:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:26:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:26:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:26:44 --> Final output sent to browser
DEBUG - 2023-09-10 14:26:44 --> Total execution time: 1.8094
INFO - 2023-09-10 14:26:48 --> Config Class Initialized
INFO - 2023-09-10 14:26:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:48 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:48 --> URI Class Initialized
INFO - 2023-09-10 14:26:48 --> Router Class Initialized
INFO - 2023-09-10 14:26:48 --> Output Class Initialized
INFO - 2023-09-10 14:26:48 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:48 --> Input Class Initialized
INFO - 2023-09-10 14:26:48 --> Language Class Initialized
ERROR - 2023-09-10 14:26:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:48 --> Config Class Initialized
INFO - 2023-09-10 14:26:48 --> Config Class Initialized
INFO - 2023-09-10 14:26:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:48 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:48 --> URI Class Initialized
INFO - 2023-09-10 14:26:48 --> Router Class Initialized
INFO - 2023-09-10 14:26:48 --> Output Class Initialized
INFO - 2023-09-10 14:26:48 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:48 --> Input Class Initialized
INFO - 2023-09-10 14:26:48 --> Language Class Initialized
ERROR - 2023-09-10 14:26:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:48 --> Hooks Class Initialized
INFO - 2023-09-10 14:26:49 --> Config Class Initialized
INFO - 2023-09-10 14:26:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:49 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:49 --> URI Class Initialized
INFO - 2023-09-10 14:26:49 --> Router Class Initialized
INFO - 2023-09-10 14:26:49 --> Output Class Initialized
INFO - 2023-09-10 14:26:49 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:49 --> Input Class Initialized
INFO - 2023-09-10 14:26:49 --> Language Class Initialized
ERROR - 2023-09-10 14:26:49 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:26:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:49 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:49 --> URI Class Initialized
INFO - 2023-09-10 14:26:50 --> Router Class Initialized
INFO - 2023-09-10 14:26:50 --> Output Class Initialized
INFO - 2023-09-10 14:26:50 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:51 --> Input Class Initialized
INFO - 2023-09-10 14:26:51 --> Language Class Initialized
ERROR - 2023-09-10 14:26:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:51 --> Config Class Initialized
INFO - 2023-09-10 14:26:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:51 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:51 --> URI Class Initialized
INFO - 2023-09-10 14:26:51 --> Router Class Initialized
INFO - 2023-09-10 14:26:51 --> Output Class Initialized
INFO - 2023-09-10 14:26:51 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:26:52 --> Input Class Initialized
INFO - 2023-09-10 14:26:52 --> Language Class Initialized
ERROR - 2023-09-10 14:26:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:26:59 --> Config Class Initialized
INFO - 2023-09-10 14:26:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:26:59 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:26:59 --> Utf8 Class Initialized
INFO - 2023-09-10 14:26:59 --> URI Class Initialized
INFO - 2023-09-10 14:26:59 --> Router Class Initialized
INFO - 2023-09-10 14:26:59 --> Output Class Initialized
INFO - 2023-09-10 14:26:59 --> Security Class Initialized
DEBUG - 2023-09-10 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:27:00 --> Input Class Initialized
INFO - 2023-09-10 14:27:00 --> Language Class Initialized
INFO - 2023-09-10 14:27:00 --> Loader Class Initialized
INFO - 2023-09-10 14:27:00 --> Helper loaded: url_helper
INFO - 2023-09-10 14:27:00 --> Helper loaded: file_helper
INFO - 2023-09-10 14:27:00 --> Database Driver Class Initialized
INFO - 2023-09-10 14:27:00 --> Email Class Initialized
DEBUG - 2023-09-10 14:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:27:01 --> Controller Class Initialized
INFO - 2023-09-10 14:27:01 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:27:01 --> Model "Home_model" initialized
INFO - 2023-09-10 14:27:01 --> Helper loaded: download_helper
INFO - 2023-09-10 14:27:01 --> Helper loaded: form_helper
INFO - 2023-09-10 14:27:01 --> Form Validation Class Initialized
INFO - 2023-09-10 14:27:01 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:27:01 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:27:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 14:27:01 --> Final output sent to browser
DEBUG - 2023-09-10 14:27:02 --> Total execution time: 2.8168
INFO - 2023-09-10 14:27:13 --> Config Class Initialized
INFO - 2023-09-10 14:27:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:27:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:27:13 --> Utf8 Class Initialized
INFO - 2023-09-10 14:27:13 --> URI Class Initialized
DEBUG - 2023-09-10 14:27:13 --> No URI present. Default controller set.
INFO - 2023-09-10 14:27:13 --> Router Class Initialized
INFO - 2023-09-10 14:27:13 --> Output Class Initialized
INFO - 2023-09-10 14:27:13 --> Security Class Initialized
DEBUG - 2023-09-10 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:27:13 --> Input Class Initialized
INFO - 2023-09-10 14:27:13 --> Language Class Initialized
INFO - 2023-09-10 14:27:13 --> Loader Class Initialized
INFO - 2023-09-10 14:27:13 --> Helper loaded: url_helper
INFO - 2023-09-10 14:27:13 --> Helper loaded: file_helper
INFO - 2023-09-10 14:27:13 --> Database Driver Class Initialized
INFO - 2023-09-10 14:27:13 --> Email Class Initialized
DEBUG - 2023-09-10 14:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:27:13 --> Controller Class Initialized
INFO - 2023-09-10 14:27:13 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:27:13 --> Model "Home_model" initialized
INFO - 2023-09-10 14:27:13 --> Helper loaded: download_helper
INFO - 2023-09-10 14:27:14 --> Helper loaded: form_helper
INFO - 2023-09-10 14:27:14 --> Form Validation Class Initialized
INFO - 2023-09-10 14:27:14 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:27:14 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:27:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:27:14 --> Final output sent to browser
DEBUG - 2023-09-10 14:27:14 --> Total execution time: 1.0533
INFO - 2023-09-10 14:27:20 --> Config Class Initialized
INFO - 2023-09-10 14:27:21 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:27:21 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:27:21 --> Utf8 Class Initialized
INFO - 2023-09-10 14:27:21 --> URI Class Initialized
INFO - 2023-09-10 14:27:21 --> Router Class Initialized
INFO - 2023-09-10 14:27:21 --> Output Class Initialized
INFO - 2023-09-10 14:27:21 --> Security Class Initialized
DEBUG - 2023-09-10 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:27:21 --> Input Class Initialized
INFO - 2023-09-10 14:27:21 --> Language Class Initialized
INFO - 2023-09-10 14:27:21 --> Loader Class Initialized
INFO - 2023-09-10 14:27:21 --> Helper loaded: url_helper
INFO - 2023-09-10 14:27:21 --> Helper loaded: file_helper
INFO - 2023-09-10 14:27:21 --> Database Driver Class Initialized
INFO - 2023-09-10 14:27:21 --> Email Class Initialized
DEBUG - 2023-09-10 14:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:27:22 --> Controller Class Initialized
INFO - 2023-09-10 14:27:22 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:27:22 --> Model "Home_model" initialized
INFO - 2023-09-10 14:27:22 --> Helper loaded: download_helper
INFO - 2023-09-10 14:27:22 --> Helper loaded: form_helper
INFO - 2023-09-10 14:27:22 --> Form Validation Class Initialized
INFO - 2023-09-10 14:27:22 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:27:22 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:27:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:27:22 --> Final output sent to browser
DEBUG - 2023-09-10 14:27:22 --> Total execution time: 1.5463
INFO - 2023-09-10 14:27:29 --> Config Class Initialized
INFO - 2023-09-10 14:27:29 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:27:29 --> Utf8 Class Initialized
INFO - 2023-09-10 14:27:29 --> URI Class Initialized
DEBUG - 2023-09-10 14:27:29 --> No URI present. Default controller set.
INFO - 2023-09-10 14:27:29 --> Router Class Initialized
INFO - 2023-09-10 14:27:29 --> Output Class Initialized
INFO - 2023-09-10 14:27:29 --> Security Class Initialized
DEBUG - 2023-09-10 14:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:27:29 --> Input Class Initialized
INFO - 2023-09-10 14:27:29 --> Language Class Initialized
INFO - 2023-09-10 14:27:29 --> Loader Class Initialized
INFO - 2023-09-10 14:27:29 --> Helper loaded: url_helper
INFO - 2023-09-10 14:27:30 --> Helper loaded: file_helper
INFO - 2023-09-10 14:27:30 --> Database Driver Class Initialized
INFO - 2023-09-10 14:27:30 --> Email Class Initialized
DEBUG - 2023-09-10 14:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:27:30 --> Controller Class Initialized
INFO - 2023-09-10 14:27:30 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:27:30 --> Model "Home_model" initialized
INFO - 2023-09-10 14:27:30 --> Helper loaded: download_helper
INFO - 2023-09-10 14:27:30 --> Helper loaded: form_helper
INFO - 2023-09-10 14:27:30 --> Form Validation Class Initialized
INFO - 2023-09-10 14:27:30 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:27:30 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:27:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:27:30 --> Final output sent to browser
DEBUG - 2023-09-10 14:27:30 --> Total execution time: 1.2883
INFO - 2023-09-10 14:32:17 --> Config Class Initialized
INFO - 2023-09-10 14:32:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:32:17 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:32:17 --> Utf8 Class Initialized
INFO - 2023-09-10 14:32:17 --> URI Class Initialized
DEBUG - 2023-09-10 14:32:17 --> No URI present. Default controller set.
INFO - 2023-09-10 14:32:17 --> Router Class Initialized
INFO - 2023-09-10 14:32:17 --> Output Class Initialized
INFO - 2023-09-10 14:32:17 --> Security Class Initialized
DEBUG - 2023-09-10 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:32:17 --> Input Class Initialized
INFO - 2023-09-10 14:32:17 --> Language Class Initialized
INFO - 2023-09-10 14:32:17 --> Loader Class Initialized
INFO - 2023-09-10 14:32:17 --> Helper loaded: url_helper
INFO - 2023-09-10 14:32:18 --> Helper loaded: file_helper
INFO - 2023-09-10 14:32:18 --> Database Driver Class Initialized
INFO - 2023-09-10 14:32:18 --> Email Class Initialized
DEBUG - 2023-09-10 14:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:32:18 --> Controller Class Initialized
INFO - 2023-09-10 14:32:18 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:32:18 --> Model "Home_model" initialized
INFO - 2023-09-10 14:32:18 --> Helper loaded: download_helper
INFO - 2023-09-10 14:32:18 --> Helper loaded: form_helper
INFO - 2023-09-10 14:32:18 --> Form Validation Class Initialized
INFO - 2023-09-10 14:32:18 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:32:18 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:32:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:32:18 --> Final output sent to browser
DEBUG - 2023-09-10 14:32:18 --> Total execution time: 0.8088
INFO - 2023-09-10 14:33:56 --> Config Class Initialized
INFO - 2023-09-10 14:33:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:33:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:33:57 --> Utf8 Class Initialized
INFO - 2023-09-10 14:33:57 --> URI Class Initialized
INFO - 2023-09-10 14:33:57 --> Router Class Initialized
INFO - 2023-09-10 14:33:57 --> Output Class Initialized
INFO - 2023-09-10 14:33:57 --> Security Class Initialized
DEBUG - 2023-09-10 14:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:33:57 --> Input Class Initialized
INFO - 2023-09-10 14:33:58 --> Language Class Initialized
INFO - 2023-09-10 14:33:58 --> Loader Class Initialized
INFO - 2023-09-10 14:33:58 --> Helper loaded: url_helper
INFO - 2023-09-10 14:33:58 --> Helper loaded: file_helper
INFO - 2023-09-10 14:33:58 --> Database Driver Class Initialized
INFO - 2023-09-10 14:33:58 --> Email Class Initialized
DEBUG - 2023-09-10 14:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:33:58 --> Controller Class Initialized
INFO - 2023-09-10 14:33:58 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:33:58 --> Model "Home_model" initialized
INFO - 2023-09-10 14:33:59 --> Helper loaded: download_helper
INFO - 2023-09-10 14:33:59 --> Helper loaded: form_helper
INFO - 2023-09-10 14:33:59 --> Form Validation Class Initialized
INFO - 2023-09-10 14:33:59 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:33:59 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:33:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-10 14:33:59 --> Final output sent to browser
DEBUG - 2023-09-10 14:33:59 --> Total execution time: 2.8835
INFO - 2023-09-10 14:36:18 --> Config Class Initialized
INFO - 2023-09-10 14:36:18 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:36:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:36:18 --> Utf8 Class Initialized
INFO - 2023-09-10 14:36:18 --> URI Class Initialized
INFO - 2023-09-10 14:36:19 --> Router Class Initialized
INFO - 2023-09-10 14:36:19 --> Output Class Initialized
INFO - 2023-09-10 14:36:19 --> Security Class Initialized
DEBUG - 2023-09-10 14:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:36:19 --> Input Class Initialized
INFO - 2023-09-10 14:36:19 --> Language Class Initialized
INFO - 2023-09-10 14:36:19 --> Loader Class Initialized
INFO - 2023-09-10 14:36:19 --> Helper loaded: url_helper
INFO - 2023-09-10 14:36:19 --> Helper loaded: file_helper
INFO - 2023-09-10 14:36:19 --> Database Driver Class Initialized
INFO - 2023-09-10 14:36:19 --> Email Class Initialized
DEBUG - 2023-09-10 14:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:36:19 --> Controller Class Initialized
INFO - 2023-09-10 14:36:19 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:36:19 --> Model "Home_model" initialized
INFO - 2023-09-10 14:36:19 --> Helper loaded: download_helper
INFO - 2023-09-10 14:36:19 --> Helper loaded: form_helper
INFO - 2023-09-10 14:36:19 --> Form Validation Class Initialized
INFO - 2023-09-10 14:36:19 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:36:19 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:36:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-10 14:36:19 --> Final output sent to browser
DEBUG - 2023-09-10 14:36:19 --> Total execution time: 0.5157
INFO - 2023-09-10 14:44:31 --> Config Class Initialized
INFO - 2023-09-10 14:44:31 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:44:31 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:44:31 --> Utf8 Class Initialized
INFO - 2023-09-10 14:44:31 --> URI Class Initialized
DEBUG - 2023-09-10 14:44:31 --> No URI present. Default controller set.
INFO - 2023-09-10 14:44:31 --> Router Class Initialized
INFO - 2023-09-10 14:44:31 --> Output Class Initialized
INFO - 2023-09-10 14:44:31 --> Security Class Initialized
DEBUG - 2023-09-10 14:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:44:31 --> Input Class Initialized
INFO - 2023-09-10 14:44:32 --> Language Class Initialized
INFO - 2023-09-10 14:44:32 --> Loader Class Initialized
INFO - 2023-09-10 14:44:32 --> Helper loaded: url_helper
INFO - 2023-09-10 14:44:32 --> Helper loaded: file_helper
INFO - 2023-09-10 14:44:32 --> Database Driver Class Initialized
INFO - 2023-09-10 14:44:32 --> Email Class Initialized
DEBUG - 2023-09-10 14:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:44:32 --> Controller Class Initialized
INFO - 2023-09-10 14:44:32 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:44:32 --> Model "Home_model" initialized
INFO - 2023-09-10 14:44:32 --> Helper loaded: download_helper
INFO - 2023-09-10 14:44:32 --> Helper loaded: form_helper
INFO - 2023-09-10 14:44:32 --> Form Validation Class Initialized
INFO - 2023-09-10 14:44:32 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:44:32 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:44:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:44:32 --> Final output sent to browser
DEBUG - 2023-09-10 14:44:33 --> Total execution time: 1.4039
INFO - 2023-09-10 14:51:08 --> Config Class Initialized
INFO - 2023-09-10 14:51:08 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:51:08 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:51:08 --> Utf8 Class Initialized
INFO - 2023-09-10 14:51:08 --> URI Class Initialized
INFO - 2023-09-10 14:51:08 --> Router Class Initialized
INFO - 2023-09-10 14:51:08 --> Output Class Initialized
INFO - 2023-09-10 14:51:08 --> Security Class Initialized
DEBUG - 2023-09-10 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:51:08 --> Input Class Initialized
INFO - 2023-09-10 14:51:08 --> Language Class Initialized
INFO - 2023-09-10 14:51:08 --> Loader Class Initialized
INFO - 2023-09-10 14:51:08 --> Helper loaded: url_helper
INFO - 2023-09-10 14:51:08 --> Helper loaded: file_helper
INFO - 2023-09-10 14:51:08 --> Database Driver Class Initialized
INFO - 2023-09-10 14:51:08 --> Email Class Initialized
DEBUG - 2023-09-10 14:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:51:08 --> Controller Class Initialized
INFO - 2023-09-10 14:51:08 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:51:08 --> Model "Home_model" initialized
INFO - 2023-09-10 14:51:08 --> Helper loaded: download_helper
INFO - 2023-09-10 14:51:08 --> Helper loaded: form_helper
INFO - 2023-09-10 14:51:08 --> Form Validation Class Initialized
INFO - 2023-09-10 14:51:08 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:51:09 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:51:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 14:51:09 --> Final output sent to browser
DEBUG - 2023-09-10 14:51:09 --> Total execution time: 0.7285
INFO - 2023-09-10 14:51:43 --> Config Class Initialized
INFO - 2023-09-10 14:51:44 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:51:44 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:51:44 --> Utf8 Class Initialized
INFO - 2023-09-10 14:51:44 --> URI Class Initialized
DEBUG - 2023-09-10 14:51:44 --> No URI present. Default controller set.
INFO - 2023-09-10 14:51:44 --> Router Class Initialized
INFO - 2023-09-10 14:51:44 --> Output Class Initialized
INFO - 2023-09-10 14:51:44 --> Security Class Initialized
DEBUG - 2023-09-10 14:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:51:44 --> Input Class Initialized
INFO - 2023-09-10 14:51:44 --> Language Class Initialized
INFO - 2023-09-10 14:51:44 --> Loader Class Initialized
INFO - 2023-09-10 14:51:44 --> Helper loaded: url_helper
INFO - 2023-09-10 14:51:44 --> Helper loaded: file_helper
INFO - 2023-09-10 14:51:44 --> Database Driver Class Initialized
INFO - 2023-09-10 14:51:44 --> Email Class Initialized
DEBUG - 2023-09-10 14:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:51:44 --> Controller Class Initialized
INFO - 2023-09-10 14:51:44 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:51:44 --> Model "Home_model" initialized
INFO - 2023-09-10 14:51:44 --> Helper loaded: download_helper
INFO - 2023-09-10 14:51:44 --> Helper loaded: form_helper
INFO - 2023-09-10 14:51:44 --> Form Validation Class Initialized
INFO - 2023-09-10 14:51:44 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:51:44 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:51:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:51:44 --> Final output sent to browser
DEBUG - 2023-09-10 14:51:44 --> Total execution time: 0.8012
INFO - 2023-09-10 14:55:36 --> Config Class Initialized
INFO - 2023-09-10 14:55:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:55:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:55:36 --> Utf8 Class Initialized
INFO - 2023-09-10 14:55:36 --> URI Class Initialized
DEBUG - 2023-09-10 14:55:36 --> No URI present. Default controller set.
INFO - 2023-09-10 14:55:36 --> Router Class Initialized
INFO - 2023-09-10 14:55:36 --> Output Class Initialized
INFO - 2023-09-10 14:55:36 --> Security Class Initialized
DEBUG - 2023-09-10 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:55:36 --> Input Class Initialized
INFO - 2023-09-10 14:55:36 --> Language Class Initialized
INFO - 2023-09-10 14:55:36 --> Loader Class Initialized
INFO - 2023-09-10 14:55:36 --> Helper loaded: url_helper
INFO - 2023-09-10 14:55:36 --> Helper loaded: file_helper
INFO - 2023-09-10 14:55:36 --> Database Driver Class Initialized
INFO - 2023-09-10 14:55:36 --> Email Class Initialized
DEBUG - 2023-09-10 14:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:55:36 --> Controller Class Initialized
INFO - 2023-09-10 14:55:36 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:55:36 --> Model "Home_model" initialized
INFO - 2023-09-10 14:55:36 --> Helper loaded: download_helper
INFO - 2023-09-10 14:55:36 --> Helper loaded: form_helper
INFO - 2023-09-10 14:55:36 --> Form Validation Class Initialized
INFO - 2023-09-10 14:55:36 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:55:36 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:55:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:55:36 --> Final output sent to browser
DEBUG - 2023-09-10 14:55:36 --> Total execution time: 0.5222
INFO - 2023-09-10 14:56:12 --> Config Class Initialized
INFO - 2023-09-10 14:56:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:56:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:56:12 --> Utf8 Class Initialized
INFO - 2023-09-10 14:56:12 --> URI Class Initialized
DEBUG - 2023-09-10 14:56:12 --> No URI present. Default controller set.
INFO - 2023-09-10 14:56:12 --> Router Class Initialized
INFO - 2023-09-10 14:56:12 --> Output Class Initialized
INFO - 2023-09-10 14:56:12 --> Security Class Initialized
DEBUG - 2023-09-10 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:56:12 --> Input Class Initialized
INFO - 2023-09-10 14:56:12 --> Language Class Initialized
INFO - 2023-09-10 14:56:12 --> Loader Class Initialized
INFO - 2023-09-10 14:56:12 --> Helper loaded: url_helper
INFO - 2023-09-10 14:56:12 --> Helper loaded: file_helper
INFO - 2023-09-10 14:56:12 --> Database Driver Class Initialized
INFO - 2023-09-10 14:56:12 --> Email Class Initialized
DEBUG - 2023-09-10 14:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:56:12 --> Controller Class Initialized
INFO - 2023-09-10 14:56:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:56:12 --> Model "Home_model" initialized
INFO - 2023-09-10 14:56:12 --> Helper loaded: download_helper
INFO - 2023-09-10 14:56:12 --> Helper loaded: form_helper
INFO - 2023-09-10 14:56:12 --> Form Validation Class Initialized
INFO - 2023-09-10 14:56:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:56:13 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:56:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:56:13 --> Final output sent to browser
DEBUG - 2023-09-10 14:56:13 --> Total execution time: 1.1017
INFO - 2023-09-10 14:57:00 --> Config Class Initialized
INFO - 2023-09-10 14:57:00 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:57:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:57:00 --> Utf8 Class Initialized
INFO - 2023-09-10 14:57:00 --> URI Class Initialized
DEBUG - 2023-09-10 14:57:00 --> No URI present. Default controller set.
INFO - 2023-09-10 14:57:00 --> Router Class Initialized
INFO - 2023-09-10 14:57:00 --> Output Class Initialized
INFO - 2023-09-10 14:57:00 --> Security Class Initialized
DEBUG - 2023-09-10 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:57:00 --> Input Class Initialized
INFO - 2023-09-10 14:57:01 --> Language Class Initialized
INFO - 2023-09-10 14:57:01 --> Loader Class Initialized
INFO - 2023-09-10 14:57:01 --> Helper loaded: url_helper
INFO - 2023-09-10 14:57:01 --> Helper loaded: file_helper
INFO - 2023-09-10 14:57:01 --> Database Driver Class Initialized
INFO - 2023-09-10 14:57:01 --> Email Class Initialized
DEBUG - 2023-09-10 14:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:57:01 --> Controller Class Initialized
INFO - 2023-09-10 14:57:01 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:57:01 --> Model "Home_model" initialized
INFO - 2023-09-10 14:57:01 --> Helper loaded: download_helper
INFO - 2023-09-10 14:57:01 --> Helper loaded: form_helper
INFO - 2023-09-10 14:57:01 --> Form Validation Class Initialized
INFO - 2023-09-10 14:57:01 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:57:01 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:57:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:57:01 --> Final output sent to browser
DEBUG - 2023-09-10 14:57:01 --> Total execution time: 0.8778
INFO - 2023-09-10 14:58:09 --> Config Class Initialized
INFO - 2023-09-10 14:58:09 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:58:09 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:58:09 --> Utf8 Class Initialized
INFO - 2023-09-10 14:58:09 --> URI Class Initialized
DEBUG - 2023-09-10 14:58:10 --> No URI present. Default controller set.
INFO - 2023-09-10 14:58:10 --> Router Class Initialized
INFO - 2023-09-10 14:58:10 --> Output Class Initialized
INFO - 2023-09-10 14:58:10 --> Security Class Initialized
DEBUG - 2023-09-10 14:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:58:10 --> Input Class Initialized
INFO - 2023-09-10 14:58:10 --> Language Class Initialized
INFO - 2023-09-10 14:58:10 --> Loader Class Initialized
INFO - 2023-09-10 14:58:10 --> Helper loaded: url_helper
INFO - 2023-09-10 14:58:10 --> Helper loaded: file_helper
INFO - 2023-09-10 14:58:10 --> Database Driver Class Initialized
INFO - 2023-09-10 14:58:10 --> Email Class Initialized
DEBUG - 2023-09-10 14:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:58:10 --> Controller Class Initialized
INFO - 2023-09-10 14:58:10 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:58:10 --> Model "Home_model" initialized
INFO - 2023-09-10 14:58:10 --> Helper loaded: download_helper
INFO - 2023-09-10 14:58:10 --> Helper loaded: form_helper
INFO - 2023-09-10 14:58:10 --> Form Validation Class Initialized
INFO - 2023-09-10 14:58:10 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:58:10 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:58:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:58:10 --> Final output sent to browser
DEBUG - 2023-09-10 14:58:10 --> Total execution time: 0.8261
INFO - 2023-09-10 14:58:27 --> Config Class Initialized
INFO - 2023-09-10 14:58:27 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:58:27 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:58:27 --> Utf8 Class Initialized
INFO - 2023-09-10 14:58:27 --> URI Class Initialized
DEBUG - 2023-09-10 14:58:27 --> No URI present. Default controller set.
INFO - 2023-09-10 14:58:27 --> Router Class Initialized
INFO - 2023-09-10 14:58:27 --> Output Class Initialized
INFO - 2023-09-10 14:58:27 --> Security Class Initialized
DEBUG - 2023-09-10 14:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:58:27 --> Input Class Initialized
INFO - 2023-09-10 14:58:27 --> Language Class Initialized
INFO - 2023-09-10 14:58:27 --> Loader Class Initialized
INFO - 2023-09-10 14:58:27 --> Helper loaded: url_helper
INFO - 2023-09-10 14:58:27 --> Helper loaded: file_helper
INFO - 2023-09-10 14:58:27 --> Database Driver Class Initialized
INFO - 2023-09-10 14:58:27 --> Email Class Initialized
DEBUG - 2023-09-10 14:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:58:27 --> Controller Class Initialized
INFO - 2023-09-10 14:58:27 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:58:27 --> Model "Home_model" initialized
INFO - 2023-09-10 14:58:27 --> Helper loaded: download_helper
INFO - 2023-09-10 14:58:27 --> Helper loaded: form_helper
INFO - 2023-09-10 14:58:27 --> Form Validation Class Initialized
INFO - 2023-09-10 14:58:28 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:58:28 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:58:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:58:28 --> Final output sent to browser
DEBUG - 2023-09-10 14:58:28 --> Total execution time: 0.5721
INFO - 2023-09-10 14:59:12 --> Config Class Initialized
INFO - 2023-09-10 14:59:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:59:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:12 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:12 --> URI Class Initialized
DEBUG - 2023-09-10 14:59:12 --> No URI present. Default controller set.
INFO - 2023-09-10 14:59:12 --> Router Class Initialized
INFO - 2023-09-10 14:59:12 --> Output Class Initialized
INFO - 2023-09-10 14:59:12 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:12 --> Input Class Initialized
INFO - 2023-09-10 14:59:12 --> Language Class Initialized
INFO - 2023-09-10 14:59:12 --> Loader Class Initialized
INFO - 2023-09-10 14:59:12 --> Helper loaded: url_helper
INFO - 2023-09-10 14:59:12 --> Helper loaded: file_helper
INFO - 2023-09-10 14:59:12 --> Database Driver Class Initialized
INFO - 2023-09-10 14:59:12 --> Email Class Initialized
DEBUG - 2023-09-10 14:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 14:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 14:59:12 --> Controller Class Initialized
INFO - 2023-09-10 14:59:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 14:59:12 --> Model "Home_model" initialized
INFO - 2023-09-10 14:59:12 --> Helper loaded: download_helper
INFO - 2023-09-10 14:59:12 --> Helper loaded: form_helper
INFO - 2023-09-10 14:59:12 --> Form Validation Class Initialized
INFO - 2023-09-10 14:59:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 14:59:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 14:59:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 14:59:12 --> Final output sent to browser
DEBUG - 2023-09-10 14:59:12 --> Total execution time: 0.6838
INFO - 2023-09-10 14:59:25 --> Config Class Initialized
INFO - 2023-09-10 14:59:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:59:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:25 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:25 --> URI Class Initialized
INFO - 2023-09-10 14:59:25 --> Router Class Initialized
INFO - 2023-09-10 14:59:25 --> Output Class Initialized
INFO - 2023-09-10 14:59:25 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:25 --> Input Class Initialized
INFO - 2023-09-10 14:59:25 --> Language Class Initialized
ERROR - 2023-09-10 14:59:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:59:25 --> Config Class Initialized
INFO - 2023-09-10 14:59:25 --> Config Class Initialized
INFO - 2023-09-10 14:59:25 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:59:25 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:25 --> Config Class Initialized
INFO - 2023-09-10 14:59:25 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:25 --> URI Class Initialized
INFO - 2023-09-10 14:59:25 --> Hooks Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> Hooks Class Initialized
INFO - 2023-09-10 14:59:26 --> Config Class Initialized
INFO - 2023-09-10 14:59:26 --> Config Class Initialized
INFO - 2023-09-10 14:59:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 14:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
DEBUG - 2023-09-10 14:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:26 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:26 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:26 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:26 --> URI Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:26 --> Input Class Initialized
INFO - 2023-09-10 14:59:26 --> Language Class Initialized
ERROR - 2023-09-10 14:59:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:59:26 --> Utf8 Class Initialized
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:26 --> URI Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> URI Class Initialized
INFO - 2023-09-10 14:59:26 --> Input Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> Config Class Initialized
INFO - 2023-09-10 14:59:26 --> URI Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
INFO - 2023-09-10 14:59:26 --> Language Class Initialized
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
INFO - 2023-09-10 14:59:26 --> Hooks Class Initialized
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:26 --> Input Class Initialized
INFO - 2023-09-10 14:59:26 --> Language Class Initialized
ERROR - 2023-09-10 14:59:26 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 14:59:26 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 14:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 14:59:26 --> Utf8 Class Initialized
INFO - 2023-09-10 14:59:26 --> URI Class Initialized
INFO - 2023-09-10 14:59:26 --> Router Class Initialized
INFO - 2023-09-10 14:59:26 --> Output Class Initialized
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:26 --> Input Class Initialized
INFO - 2023-09-10 14:59:26 --> Language Class Initialized
ERROR - 2023-09-10 14:59:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 14:59:26 --> Security Class Initialized
INFO - 2023-09-10 14:59:26 --> Input Class Initialized
DEBUG - 2023-09-10 14:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 14:59:26 --> Language Class Initialized
INFO - 2023-09-10 14:59:27 --> Input Class Initialized
INFO - 2023-09-10 14:59:27 --> Language Class Initialized
ERROR - 2023-09-10 14:59:27 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 14:59:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:01:55 --> Config Class Initialized
INFO - 2023-09-10 15:01:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:01:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:01:55 --> Utf8 Class Initialized
INFO - 2023-09-10 15:01:55 --> URI Class Initialized
DEBUG - 2023-09-10 15:01:55 --> No URI present. Default controller set.
INFO - 2023-09-10 15:01:55 --> Router Class Initialized
INFO - 2023-09-10 15:01:55 --> Output Class Initialized
INFO - 2023-09-10 15:01:55 --> Security Class Initialized
DEBUG - 2023-09-10 15:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:01:55 --> Input Class Initialized
INFO - 2023-09-10 15:01:55 --> Language Class Initialized
INFO - 2023-09-10 15:01:55 --> Loader Class Initialized
INFO - 2023-09-10 15:01:56 --> Helper loaded: url_helper
INFO - 2023-09-10 15:01:56 --> Helper loaded: file_helper
INFO - 2023-09-10 15:01:56 --> Database Driver Class Initialized
INFO - 2023-09-10 15:01:56 --> Email Class Initialized
DEBUG - 2023-09-10 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:01:56 --> Controller Class Initialized
INFO - 2023-09-10 15:01:56 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:01:56 --> Model "Home_model" initialized
INFO - 2023-09-10 15:01:56 --> Helper loaded: download_helper
INFO - 2023-09-10 15:01:56 --> Helper loaded: form_helper
INFO - 2023-09-10 15:01:56 --> Form Validation Class Initialized
INFO - 2023-09-10 15:01:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:01:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:01:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:01:56 --> Final output sent to browser
DEBUG - 2023-09-10 15:01:56 --> Total execution time: 0.9215
INFO - 2023-09-10 15:01:58 --> Config Class Initialized
INFO - 2023-09-10 15:02:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:01 --> Config Class Initialized
INFO - 2023-09-10 15:02:02 --> Config Class Initialized
INFO - 2023-09-10 15:02:02 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:02 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:02 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:02 --> URI Class Initialized
INFO - 2023-09-10 15:02:02 --> Router Class Initialized
INFO - 2023-09-10 15:02:02 --> Output Class Initialized
INFO - 2023-09-10 15:02:02 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:02 --> Input Class Initialized
INFO - 2023-09-10 15:02:02 --> Language Class Initialized
ERROR - 2023-09-10 15:02:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:02 --> Config Class Initialized
INFO - 2023-09-10 15:02:02 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:02 --> URI Class Initialized
INFO - 2023-09-10 15:02:02 --> Router Class Initialized
INFO - 2023-09-10 15:02:02 --> Output Class Initialized
INFO - 2023-09-10 15:02:02 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:02 --> Input Class Initialized
INFO - 2023-09-10 15:02:02 --> Language Class Initialized
ERROR - 2023-09-10 15:02:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:03 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:03 --> Config Class Initialized
DEBUG - 2023-09-10 15:02:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:03 --> Config Class Initialized
INFO - 2023-09-10 15:02:03 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:03 --> Config Class Initialized
INFO - 2023-09-10 15:02:03 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:03 --> URI Class Initialized
INFO - 2023-09-10 15:02:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:04 --> URI Class Initialized
INFO - 2023-09-10 15:02:04 --> Router Class Initialized
DEBUG - 2023-09-10 15:02:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:04 --> Router Class Initialized
INFO - 2023-09-10 15:02:04 --> Output Class Initialized
INFO - 2023-09-10 15:02:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:04 --> Input Class Initialized
INFO - 2023-09-10 15:02:04 --> Language Class Initialized
ERROR - 2023-09-10 15:02:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:04 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:02:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:04 --> Output Class Initialized
INFO - 2023-09-10 15:02:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:04 --> URI Class Initialized
INFO - 2023-09-10 15:02:04 --> Security Class Initialized
INFO - 2023-09-10 15:02:04 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:04 --> Router Class Initialized
INFO - 2023-09-10 15:02:04 --> URI Class Initialized
INFO - 2023-09-10 15:02:04 --> Output Class Initialized
INFO - 2023-09-10 15:02:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:04 --> Input Class Initialized
INFO - 2023-09-10 15:02:04 --> Language Class Initialized
ERROR - 2023-09-10 15:02:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:04 --> Router Class Initialized
INFO - 2023-09-10 15:02:04 --> URI Class Initialized
INFO - 2023-09-10 15:02:04 --> Router Class Initialized
INFO - 2023-09-10 15:02:04 --> Input Class Initialized
INFO - 2023-09-10 15:02:04 --> Output Class Initialized
INFO - 2023-09-10 15:02:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:04 --> Input Class Initialized
INFO - 2023-09-10 15:02:04 --> Language Class Initialized
ERROR - 2023-09-10 15:02:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:04 --> Output Class Initialized
INFO - 2023-09-10 15:02:04 --> Security Class Initialized
INFO - 2023-09-10 15:02:04 --> Language Class Initialized
DEBUG - 2023-09-10 15:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 15:02:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:04 --> Input Class Initialized
INFO - 2023-09-10 15:02:04 --> Language Class Initialized
ERROR - 2023-09-10 15:02:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:12 --> Config Class Initialized
INFO - 2023-09-10 15:02:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:12 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:12 --> URI Class Initialized
DEBUG - 2023-09-10 15:02:12 --> No URI present. Default controller set.
INFO - 2023-09-10 15:02:12 --> Router Class Initialized
INFO - 2023-09-10 15:02:12 --> Output Class Initialized
INFO - 2023-09-10 15:02:12 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:12 --> Input Class Initialized
INFO - 2023-09-10 15:02:12 --> Language Class Initialized
INFO - 2023-09-10 15:02:12 --> Loader Class Initialized
INFO - 2023-09-10 15:02:12 --> Helper loaded: url_helper
INFO - 2023-09-10 15:02:12 --> Helper loaded: file_helper
INFO - 2023-09-10 15:02:12 --> Database Driver Class Initialized
INFO - 2023-09-10 15:02:12 --> Email Class Initialized
DEBUG - 2023-09-10 15:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:02:13 --> Controller Class Initialized
INFO - 2023-09-10 15:02:13 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:02:13 --> Model "Home_model" initialized
INFO - 2023-09-10 15:02:13 --> Helper loaded: download_helper
INFO - 2023-09-10 15:02:13 --> Helper loaded: form_helper
INFO - 2023-09-10 15:02:13 --> Form Validation Class Initialized
INFO - 2023-09-10 15:02:13 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:02:13 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:02:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:02:13 --> Final output sent to browser
DEBUG - 2023-09-10 15:02:13 --> Total execution time: 1.1179
INFO - 2023-09-10 15:02:16 --> Config Class Initialized
INFO - 2023-09-10 15:02:16 --> Config Class Initialized
INFO - 2023-09-10 15:02:16 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:17 --> Config Class Initialized
INFO - 2023-09-10 15:02:17 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:17 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:18 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:18 --> Config Class Initialized
DEBUG - 2023-09-10 15:02:18 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:18 --> Config Class Initialized
INFO - 2023-09-10 15:02:18 --> Config Class Initialized
DEBUG - 2023-09-10 15:02:19 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:20 --> URI Class Initialized
INFO - 2023-09-10 15:02:20 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:20 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:20 --> URI Class Initialized
INFO - 2023-09-10 15:02:20 --> Router Class Initialized
INFO - 2023-09-10 15:02:20 --> Output Class Initialized
INFO - 2023-09-10 15:02:20 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:20 --> Input Class Initialized
INFO - 2023-09-10 15:02:20 --> Language Class Initialized
ERROR - 2023-09-10 15:02:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:20 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:20 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:20 --> URI Class Initialized
INFO - 2023-09-10 15:02:20 --> Router Class Initialized
INFO - 2023-09-10 15:02:20 --> Output Class Initialized
INFO - 2023-09-10 15:02:20 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:20 --> Input Class Initialized
INFO - 2023-09-10 15:02:20 --> Language Class Initialized
ERROR - 2023-09-10 15:02:20 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:20 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:20 --> Config Class Initialized
INFO - 2023-09-10 15:02:20 --> Router Class Initialized
INFO - 2023-09-10 15:02:21 --> URI Class Initialized
INFO - 2023-09-10 15:02:21 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:21 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:21 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:21 --> Output Class Initialized
INFO - 2023-09-10 15:02:21 --> Router Class Initialized
INFO - 2023-09-10 15:02:21 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:21 --> Input Class Initialized
INFO - 2023-09-10 15:02:21 --> Language Class Initialized
ERROR - 2023-09-10 15:02:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:21 --> URI Class Initialized
INFO - 2023-09-10 15:02:21 --> Router Class Initialized
INFO - 2023-09-10 15:02:21 --> Output Class Initialized
INFO - 2023-09-10 15:02:21 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:21 --> Input Class Initialized
INFO - 2023-09-10 15:02:21 --> Language Class Initialized
ERROR - 2023-09-10 15:02:21 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:21 --> Output Class Initialized
INFO - 2023-09-10 15:02:21 --> URI Class Initialized
INFO - 2023-09-10 15:02:22 --> Security Class Initialized
INFO - 2023-09-10 15:02:22 --> Router Class Initialized
INFO - 2023-09-10 15:02:22 --> Output Class Initialized
DEBUG - 2023-09-10 15:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:22 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:23 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:23 --> Input Class Initialized
INFO - 2023-09-10 15:02:23 --> Language Class Initialized
ERROR - 2023-09-10 15:02:23 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:23 --> Input Class Initialized
INFO - 2023-09-10 15:02:23 --> URI Class Initialized
INFO - 2023-09-10 15:02:23 --> Language Class Initialized
INFO - 2023-09-10 15:02:23 --> Router Class Initialized
ERROR - 2023-09-10 15:02:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:23 --> Output Class Initialized
INFO - 2023-09-10 15:02:23 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:23 --> Input Class Initialized
INFO - 2023-09-10 15:02:23 --> Language Class Initialized
ERROR - 2023-09-10 15:02:23 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:46 --> Config Class Initialized
INFO - 2023-09-10 15:02:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:46 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:46 --> URI Class Initialized
DEBUG - 2023-09-10 15:02:46 --> No URI present. Default controller set.
INFO - 2023-09-10 15:02:46 --> Router Class Initialized
INFO - 2023-09-10 15:02:46 --> Output Class Initialized
INFO - 2023-09-10 15:02:46 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:46 --> Input Class Initialized
INFO - 2023-09-10 15:02:46 --> Language Class Initialized
INFO - 2023-09-10 15:02:46 --> Loader Class Initialized
INFO - 2023-09-10 15:02:46 --> Helper loaded: url_helper
INFO - 2023-09-10 15:02:46 --> Helper loaded: file_helper
INFO - 2023-09-10 15:02:46 --> Database Driver Class Initialized
INFO - 2023-09-10 15:02:46 --> Email Class Initialized
DEBUG - 2023-09-10 15:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:02:46 --> Controller Class Initialized
INFO - 2023-09-10 15:02:46 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:02:46 --> Model "Home_model" initialized
INFO - 2023-09-10 15:02:46 --> Helper loaded: download_helper
INFO - 2023-09-10 15:02:46 --> Helper loaded: form_helper
INFO - 2023-09-10 15:02:46 --> Form Validation Class Initialized
INFO - 2023-09-10 15:02:46 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:02:47 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:02:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:02:47 --> Final output sent to browser
DEBUG - 2023-09-10 15:02:47 --> Total execution time: 0.8149
INFO - 2023-09-10 15:02:49 --> Config Class Initialized
INFO - 2023-09-10 15:02:49 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:49 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:50 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:50 --> URI Class Initialized
INFO - 2023-09-10 15:02:50 --> Router Class Initialized
INFO - 2023-09-10 15:02:51 --> Output Class Initialized
INFO - 2023-09-10 15:02:51 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:52 --> Input Class Initialized
INFO - 2023-09-10 15:02:52 --> Language Class Initialized
ERROR - 2023-09-10 15:02:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:52 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:53 --> URI Class Initialized
INFO - 2023-09-10 15:02:53 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:53 --> Router Class Initialized
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:53 --> Output Class Initialized
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:53 --> Security Class Initialized
INFO - 2023-09-10 15:02:53 --> URI Class Initialized
DEBUG - 2023-09-10 15:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:53 --> Router Class Initialized
INFO - 2023-09-10 15:02:53 --> Input Class Initialized
INFO - 2023-09-10 15:02:53 --> Output Class Initialized
INFO - 2023-09-10 15:02:53 --> Language Class Initialized
INFO - 2023-09-10 15:02:53 --> Security Class Initialized
ERROR - 2023-09-10 15:02:53 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:53 --> Input Class Initialized
INFO - 2023-09-10 15:02:53 --> Language Class Initialized
ERROR - 2023-09-10 15:02:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:53 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:53 --> URI Class Initialized
INFO - 2023-09-10 15:02:53 --> Router Class Initialized
INFO - 2023-09-10 15:02:53 --> Output Class Initialized
INFO - 2023-09-10 15:02:53 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:53 --> Input Class Initialized
INFO - 2023-09-10 15:02:53 --> Language Class Initialized
ERROR - 2023-09-10 15:02:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:53 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:53 --> URI Class Initialized
INFO - 2023-09-10 15:02:53 --> Router Class Initialized
INFO - 2023-09-10 15:02:53 --> Output Class Initialized
INFO - 2023-09-10 15:02:53 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:53 --> Input Class Initialized
INFO - 2023-09-10 15:02:53 --> Language Class Initialized
ERROR - 2023-09-10 15:02:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:02:53 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
INFO - 2023-09-10 15:02:53 --> Config Class Initialized
INFO - 2023-09-10 15:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 15:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:53 --> URI Class Initialized
INFO - 2023-09-10 15:02:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:02:54 --> Router Class Initialized
INFO - 2023-09-10 15:02:54 --> URI Class Initialized
INFO - 2023-09-10 15:02:54 --> Output Class Initialized
INFO - 2023-09-10 15:02:54 --> Router Class Initialized
INFO - 2023-09-10 15:02:54 --> Output Class Initialized
INFO - 2023-09-10 15:02:54 --> Security Class Initialized
INFO - 2023-09-10 15:02:54 --> Security Class Initialized
DEBUG - 2023-09-10 15:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:02:54 --> Input Class Initialized
INFO - 2023-09-10 15:02:54 --> Input Class Initialized
INFO - 2023-09-10 15:02:54 --> Language Class Initialized
INFO - 2023-09-10 15:02:54 --> Language Class Initialized
ERROR - 2023-09-10 15:02:54 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:02:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:03:07 --> Config Class Initialized
INFO - 2023-09-10 15:03:07 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:03:07 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:07 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:07 --> URI Class Initialized
DEBUG - 2023-09-10 15:03:07 --> No URI present. Default controller set.
INFO - 2023-09-10 15:03:07 --> Router Class Initialized
INFO - 2023-09-10 15:03:07 --> Output Class Initialized
INFO - 2023-09-10 15:03:07 --> Security Class Initialized
DEBUG - 2023-09-10 15:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:07 --> Input Class Initialized
INFO - 2023-09-10 15:03:07 --> Language Class Initialized
INFO - 2023-09-10 15:03:07 --> Loader Class Initialized
INFO - 2023-09-10 15:03:07 --> Helper loaded: url_helper
INFO - 2023-09-10 15:03:07 --> Helper loaded: file_helper
INFO - 2023-09-10 15:03:07 --> Database Driver Class Initialized
INFO - 2023-09-10 15:03:07 --> Email Class Initialized
DEBUG - 2023-09-10 15:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:03:07 --> Controller Class Initialized
INFO - 2023-09-10 15:03:07 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:03:08 --> Model "Home_model" initialized
INFO - 2023-09-10 15:03:08 --> Helper loaded: download_helper
INFO - 2023-09-10 15:03:08 --> Helper loaded: form_helper
INFO - 2023-09-10 15:03:08 --> Form Validation Class Initialized
INFO - 2023-09-10 15:03:08 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:03:08 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:03:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:03:08 --> Final output sent to browser
DEBUG - 2023-09-10 15:03:08 --> Total execution time: 0.8629
INFO - 2023-09-10 15:03:10 --> Config Class Initialized
INFO - 2023-09-10 15:03:10 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:03:10 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:10 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:10 --> URI Class Initialized
INFO - 2023-09-10 15:03:10 --> Config Class Initialized
INFO - 2023-09-10 15:03:11 --> Router Class Initialized
INFO - 2023-09-10 15:03:11 --> Output Class Initialized
INFO - 2023-09-10 15:03:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:03:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:12 --> Security Class Initialized
DEBUG - 2023-09-10 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:13 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:13 --> Config Class Initialized
INFO - 2023-09-10 15:03:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:03:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:13 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:13 --> URI Class Initialized
INFO - 2023-09-10 15:03:13 --> Router Class Initialized
INFO - 2023-09-10 15:03:13 --> Output Class Initialized
INFO - 2023-09-10 15:03:13 --> Security Class Initialized
DEBUG - 2023-09-10 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:13 --> Input Class Initialized
INFO - 2023-09-10 15:03:13 --> Language Class Initialized
ERROR - 2023-09-10 15:03:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:03:13 --> Input Class Initialized
INFO - 2023-09-10 15:03:14 --> Config Class Initialized
INFO - 2023-09-10 15:03:15 --> Language Class Initialized
INFO - 2023-09-10 15:03:15 --> Hooks Class Initialized
INFO - 2023-09-10 15:03:15 --> Config Class Initialized
INFO - 2023-09-10 15:03:15 --> Config Class Initialized
INFO - 2023-09-10 15:03:15 --> URI Class Initialized
INFO - 2023-09-10 15:03:15 --> Config Class Initialized
INFO - 2023-09-10 15:03:15 --> Hooks Class Initialized
INFO - 2023-09-10 15:03:15 --> Hooks Class Initialized
ERROR - 2023-09-10 15:03:15 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:16 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:16 --> URI Class Initialized
INFO - 2023-09-10 15:03:16 --> Router Class Initialized
INFO - 2023-09-10 15:03:16 --> Output Class Initialized
INFO - 2023-09-10 15:03:16 --> Security Class Initialized
DEBUG - 2023-09-10 15:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:16 --> Input Class Initialized
INFO - 2023-09-10 15:03:16 --> Language Class Initialized
ERROR - 2023-09-10 15:03:16 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 15:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:16 --> Hooks Class Initialized
INFO - 2023-09-10 15:03:16 --> Router Class Initialized
INFO - 2023-09-10 15:03:16 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:16 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:03:16 --> URI Class Initialized
INFO - 2023-09-10 15:03:17 --> Utf8 Class Initialized
INFO - 2023-09-10 15:03:17 --> URI Class Initialized
INFO - 2023-09-10 15:03:17 --> Output Class Initialized
INFO - 2023-09-10 15:03:17 --> Router Class Initialized
INFO - 2023-09-10 15:03:17 --> URI Class Initialized
INFO - 2023-09-10 15:03:17 --> Security Class Initialized
INFO - 2023-09-10 15:03:17 --> Router Class Initialized
INFO - 2023-09-10 15:03:17 --> Router Class Initialized
INFO - 2023-09-10 15:03:17 --> Output Class Initialized
INFO - 2023-09-10 15:03:17 --> Output Class Initialized
INFO - 2023-09-10 15:03:17 --> Output Class Initialized
DEBUG - 2023-09-10 15:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:17 --> Security Class Initialized
INFO - 2023-09-10 15:03:17 --> Security Class Initialized
INFO - 2023-09-10 15:03:17 --> Security Class Initialized
DEBUG - 2023-09-10 15:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:17 --> Input Class Initialized
DEBUG - 2023-09-10 15:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:17 --> Input Class Initialized
INFO - 2023-09-10 15:03:17 --> Input Class Initialized
INFO - 2023-09-10 15:03:18 --> Language Class Initialized
ERROR - 2023-09-10 15:03:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:03:18 --> Language Class Initialized
INFO - 2023-09-10 15:03:18 --> Language Class Initialized
DEBUG - 2023-09-10 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:03:18 --> Input Class Initialized
INFO - 2023-09-10 15:03:18 --> Language Class Initialized
ERROR - 2023-09-10 15:03:18 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:03:18 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:03:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:04:55 --> Config Class Initialized
INFO - 2023-09-10 15:04:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:04:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:04:55 --> Utf8 Class Initialized
INFO - 2023-09-10 15:04:55 --> URI Class Initialized
INFO - 2023-09-10 15:04:56 --> Router Class Initialized
INFO - 2023-09-10 15:04:56 --> Output Class Initialized
INFO - 2023-09-10 15:04:56 --> Security Class Initialized
DEBUG - 2023-09-10 15:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:04:56 --> Input Class Initialized
INFO - 2023-09-10 15:04:56 --> Language Class Initialized
INFO - 2023-09-10 15:04:56 --> Loader Class Initialized
INFO - 2023-09-10 15:04:56 --> Helper loaded: url_helper
INFO - 2023-09-10 15:04:56 --> Helper loaded: file_helper
INFO - 2023-09-10 15:04:56 --> Database Driver Class Initialized
INFO - 2023-09-10 15:04:56 --> Email Class Initialized
DEBUG - 2023-09-10 15:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:04:56 --> Controller Class Initialized
INFO - 2023-09-10 15:04:56 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:04:56 --> Model "Home_model" initialized
INFO - 2023-09-10 15:04:56 --> Helper loaded: download_helper
INFO - 2023-09-10 15:04:56 --> Helper loaded: form_helper
INFO - 2023-09-10 15:04:56 --> Form Validation Class Initialized
INFO - 2023-09-10 15:04:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:04:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:04:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-10 15:04:56 --> Final output sent to browser
DEBUG - 2023-09-10 15:04:56 --> Total execution time: 0.5759
INFO - 2023-09-10 15:05:37 --> Config Class Initialized
INFO - 2023-09-10 15:05:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:05:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:05:37 --> Utf8 Class Initialized
INFO - 2023-09-10 15:05:37 --> URI Class Initialized
DEBUG - 2023-09-10 15:05:37 --> No URI present. Default controller set.
INFO - 2023-09-10 15:05:37 --> Router Class Initialized
INFO - 2023-09-10 15:05:37 --> Output Class Initialized
INFO - 2023-09-10 15:05:37 --> Security Class Initialized
DEBUG - 2023-09-10 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:05:37 --> Input Class Initialized
INFO - 2023-09-10 15:05:37 --> Language Class Initialized
INFO - 2023-09-10 15:05:37 --> Loader Class Initialized
INFO - 2023-09-10 15:05:37 --> Helper loaded: url_helper
INFO - 2023-09-10 15:05:37 --> Helper loaded: file_helper
INFO - 2023-09-10 15:05:37 --> Database Driver Class Initialized
INFO - 2023-09-10 15:05:37 --> Email Class Initialized
DEBUG - 2023-09-10 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:05:37 --> Controller Class Initialized
INFO - 2023-09-10 15:05:38 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:05:38 --> Model "Home_model" initialized
INFO - 2023-09-10 15:05:38 --> Helper loaded: download_helper
INFO - 2023-09-10 15:05:38 --> Helper loaded: form_helper
INFO - 2023-09-10 15:05:38 --> Form Validation Class Initialized
INFO - 2023-09-10 15:05:38 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:05:38 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:05:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:05:38 --> Final output sent to browser
DEBUG - 2023-09-10 15:05:38 --> Total execution time: 0.9293
INFO - 2023-09-10 15:06:12 --> Config Class Initialized
INFO - 2023-09-10 15:06:12 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:12 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:13 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:13 --> URI Class Initialized
INFO - 2023-09-10 15:06:13 --> Router Class Initialized
INFO - 2023-09-10 15:06:13 --> Output Class Initialized
INFO - 2023-09-10 15:06:13 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:13 --> Input Class Initialized
INFO - 2023-09-10 15:06:13 --> Language Class Initialized
ERROR - 2023-09-10 15:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:13 --> Config Class Initialized
INFO - 2023-09-10 15:06:13 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:13 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:13 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:13 --> URI Class Initialized
INFO - 2023-09-10 15:06:13 --> Router Class Initialized
INFO - 2023-09-10 15:06:13 --> Output Class Initialized
INFO - 2023-09-10 15:06:13 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:13 --> Input Class Initialized
INFO - 2023-09-10 15:06:13 --> Language Class Initialized
ERROR - 2023-09-10 15:06:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:14 --> Config Class Initialized
INFO - 2023-09-10 15:06:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:14 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:14 --> URI Class Initialized
INFO - 2023-09-10 15:06:14 --> Router Class Initialized
INFO - 2023-09-10 15:06:14 --> Output Class Initialized
INFO - 2023-09-10 15:06:14 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:14 --> Input Class Initialized
INFO - 2023-09-10 15:06:14 --> Language Class Initialized
ERROR - 2023-09-10 15:06:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:14 --> Config Class Initialized
INFO - 2023-09-10 15:06:14 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:14 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:14 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:14 --> URI Class Initialized
INFO - 2023-09-10 15:06:14 --> Router Class Initialized
INFO - 2023-09-10 15:06:15 --> Output Class Initialized
INFO - 2023-09-10 15:06:15 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:15 --> Input Class Initialized
INFO - 2023-09-10 15:06:15 --> Language Class Initialized
ERROR - 2023-09-10 15:06:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:15 --> Config Class Initialized
INFO - 2023-09-10 15:06:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:15 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:15 --> URI Class Initialized
INFO - 2023-09-10 15:06:15 --> Router Class Initialized
INFO - 2023-09-10 15:06:15 --> Output Class Initialized
INFO - 2023-09-10 15:06:15 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:15 --> Input Class Initialized
INFO - 2023-09-10 15:06:15 --> Language Class Initialized
ERROR - 2023-09-10 15:06:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:15 --> Config Class Initialized
INFO - 2023-09-10 15:06:15 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:15 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:15 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:15 --> URI Class Initialized
INFO - 2023-09-10 15:06:15 --> Router Class Initialized
INFO - 2023-09-10 15:06:15 --> Output Class Initialized
INFO - 2023-09-10 15:06:15 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:15 --> Input Class Initialized
INFO - 2023-09-10 15:06:16 --> Language Class Initialized
ERROR - 2023-09-10 15:06:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:06:16 --> Config Class Initialized
INFO - 2023-09-10 15:06:16 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:06:16 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:06:16 --> Utf8 Class Initialized
INFO - 2023-09-10 15:06:16 --> URI Class Initialized
INFO - 2023-09-10 15:06:16 --> Router Class Initialized
INFO - 2023-09-10 15:06:16 --> Output Class Initialized
INFO - 2023-09-10 15:06:16 --> Security Class Initialized
DEBUG - 2023-09-10 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:06:16 --> Input Class Initialized
INFO - 2023-09-10 15:06:16 --> Language Class Initialized
ERROR - 2023-09-10 15:06:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:26 --> Config Class Initialized
INFO - 2023-09-10 15:13:26 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:26 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:26 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:26 --> URI Class Initialized
DEBUG - 2023-09-10 15:13:26 --> No URI present. Default controller set.
INFO - 2023-09-10 15:13:26 --> Router Class Initialized
INFO - 2023-09-10 15:13:26 --> Output Class Initialized
INFO - 2023-09-10 15:13:26 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:26 --> Input Class Initialized
INFO - 2023-09-10 15:13:26 --> Language Class Initialized
INFO - 2023-09-10 15:13:26 --> Loader Class Initialized
INFO - 2023-09-10 15:13:26 --> Helper loaded: url_helper
INFO - 2023-09-10 15:13:26 --> Helper loaded: file_helper
INFO - 2023-09-10 15:13:26 --> Database Driver Class Initialized
INFO - 2023-09-10 15:13:26 --> Email Class Initialized
DEBUG - 2023-09-10 15:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:13:26 --> Controller Class Initialized
INFO - 2023-09-10 15:13:26 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:13:26 --> Model "Home_model" initialized
INFO - 2023-09-10 15:13:27 --> Helper loaded: download_helper
INFO - 2023-09-10 15:13:27 --> Helper loaded: form_helper
INFO - 2023-09-10 15:13:27 --> Form Validation Class Initialized
INFO - 2023-09-10 15:13:27 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:13:27 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:13:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:13:27 --> Final output sent to browser
DEBUG - 2023-09-10 15:13:27 --> Total execution time: 0.4903
INFO - 2023-09-10 15:13:30 --> Config Class Initialized
INFO - 2023-09-10 15:13:30 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:30 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:30 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:30 --> URI Class Initialized
INFO - 2023-09-10 15:13:30 --> Router Class Initialized
INFO - 2023-09-10 15:13:30 --> Output Class Initialized
INFO - 2023-09-10 15:13:30 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:30 --> Input Class Initialized
INFO - 2023-09-10 15:13:30 --> Language Class Initialized
ERROR - 2023-09-10 15:13:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:35 --> Config Class Initialized
INFO - 2023-09-10 15:13:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:35 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:35 --> URI Class Initialized
INFO - 2023-09-10 15:13:35 --> Router Class Initialized
INFO - 2023-09-10 15:13:35 --> Output Class Initialized
INFO - 2023-09-10 15:13:35 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:35 --> Config Class Initialized
INFO - 2023-09-10 15:13:35 --> Config Class Initialized
INFO - 2023-09-10 15:13:35 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:35 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:35 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:35 --> URI Class Initialized
INFO - 2023-09-10 15:13:35 --> Router Class Initialized
INFO - 2023-09-10 15:13:35 --> Output Class Initialized
INFO - 2023-09-10 15:13:35 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:35 --> Input Class Initialized
INFO - 2023-09-10 15:13:35 --> Language Class Initialized
ERROR - 2023-09-10 15:13:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:36 --> Config Class Initialized
INFO - 2023-09-10 15:13:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:36 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:36 --> URI Class Initialized
INFO - 2023-09-10 15:13:36 --> Router Class Initialized
INFO - 2023-09-10 15:13:36 --> Output Class Initialized
INFO - 2023-09-10 15:13:36 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:36 --> Input Class Initialized
INFO - 2023-09-10 15:13:36 --> Language Class Initialized
INFO - 2023-09-10 15:13:36 --> Hooks Class Initialized
INFO - 2023-09-10 15:13:36 --> Config Class Initialized
INFO - 2023-09-10 15:13:38 --> Hooks Class Initialized
INFO - 2023-09-10 15:13:39 --> Config Class Initialized
INFO - 2023-09-10 15:13:39 --> Hooks Class Initialized
ERROR - 2023-09-10 15:13:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:39 --> Input Class Initialized
DEBUG - 2023-09-10 15:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 15:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:39 --> Language Class Initialized
DEBUG - 2023-09-10 15:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:39 --> Config Class Initialized
INFO - 2023-09-10 15:13:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:40 --> URI Class Initialized
INFO - 2023-09-10 15:13:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:13:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:13:40 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:40 --> URI Class Initialized
INFO - 2023-09-10 15:13:40 --> Router Class Initialized
ERROR - 2023-09-10 15:13:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:41 --> Router Class Initialized
INFO - 2023-09-10 15:13:41 --> URI Class Initialized
INFO - 2023-09-10 15:13:41 --> Utf8 Class Initialized
INFO - 2023-09-10 15:13:41 --> Output Class Initialized
INFO - 2023-09-10 15:13:41 --> Router Class Initialized
INFO - 2023-09-10 15:13:41 --> Output Class Initialized
INFO - 2023-09-10 15:13:41 --> Output Class Initialized
INFO - 2023-09-10 15:13:41 --> URI Class Initialized
INFO - 2023-09-10 15:13:41 --> Router Class Initialized
INFO - 2023-09-10 15:13:41 --> Security Class Initialized
INFO - 2023-09-10 15:13:41 --> Output Class Initialized
INFO - 2023-09-10 15:13:41 --> Security Class Initialized
INFO - 2023-09-10 15:13:41 --> Security Class Initialized
DEBUG - 2023-09-10 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:41 --> Input Class Initialized
INFO - 2023-09-10 15:13:41 --> Security Class Initialized
INFO - 2023-09-10 15:13:41 --> Input Class Initialized
DEBUG - 2023-09-10 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:13:41 --> Language Class Initialized
INFO - 2023-09-10 15:13:41 --> Input Class Initialized
INFO - 2023-09-10 15:13:41 --> Language Class Initialized
INFO - 2023-09-10 15:13:41 --> Input Class Initialized
INFO - 2023-09-10 15:13:41 --> Language Class Initialized
ERROR - 2023-09-10 15:13:41 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:13:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:13:41 --> Language Class Initialized
ERROR - 2023-09-10 15:13:41 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:13:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:36 --> Config Class Initialized
INFO - 2023-09-10 15:14:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:14:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:36 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:36 --> URI Class Initialized
DEBUG - 2023-09-10 15:14:36 --> No URI present. Default controller set.
INFO - 2023-09-10 15:14:36 --> Router Class Initialized
INFO - 2023-09-10 15:14:36 --> Output Class Initialized
INFO - 2023-09-10 15:14:36 --> Security Class Initialized
DEBUG - 2023-09-10 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:36 --> Input Class Initialized
INFO - 2023-09-10 15:14:36 --> Language Class Initialized
INFO - 2023-09-10 15:14:36 --> Loader Class Initialized
INFO - 2023-09-10 15:14:36 --> Helper loaded: url_helper
INFO - 2023-09-10 15:14:36 --> Helper loaded: file_helper
INFO - 2023-09-10 15:14:36 --> Database Driver Class Initialized
INFO - 2023-09-10 15:14:36 --> Email Class Initialized
DEBUG - 2023-09-10 15:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:14:36 --> Controller Class Initialized
INFO - 2023-09-10 15:14:36 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:14:36 --> Model "Home_model" initialized
INFO - 2023-09-10 15:14:36 --> Helper loaded: download_helper
INFO - 2023-09-10 15:14:36 --> Helper loaded: form_helper
INFO - 2023-09-10 15:14:36 --> Form Validation Class Initialized
INFO - 2023-09-10 15:14:37 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:14:37 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:14:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:14:37 --> Final output sent to browser
DEBUG - 2023-09-10 15:14:37 --> Total execution time: 0.8819
INFO - 2023-09-10 15:14:38 --> Config Class Initialized
INFO - 2023-09-10 15:14:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:14:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:38 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:38 --> URI Class Initialized
INFO - 2023-09-10 15:14:38 --> Router Class Initialized
INFO - 2023-09-10 15:14:38 --> Output Class Initialized
INFO - 2023-09-10 15:14:38 --> Security Class Initialized
DEBUG - 2023-09-10 15:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:38 --> Input Class Initialized
INFO - 2023-09-10 15:14:38 --> Language Class Initialized
ERROR - 2023-09-10 15:14:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:47 --> Config Class Initialized
INFO - 2023-09-10 15:14:48 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:14:48 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:48 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:49 --> URI Class Initialized
INFO - 2023-09-10 15:14:49 --> Router Class Initialized
INFO - 2023-09-10 15:14:49 --> Output Class Initialized
INFO - 2023-09-10 15:14:49 --> Security Class Initialized
DEBUG - 2023-09-10 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:50 --> Input Class Initialized
INFO - 2023-09-10 15:14:50 --> Language Class Initialized
ERROR - 2023-09-10 15:14:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:50 --> Config Class Initialized
INFO - 2023-09-10 15:14:50 --> Hooks Class Initialized
INFO - 2023-09-10 15:14:51 --> Config Class Initialized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:51 --> Hooks Class Initialized
INFO - 2023-09-10 15:14:51 --> URI Class Initialized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:51 --> Router Class Initialized
INFO - 2023-09-10 15:14:51 --> Config Class Initialized
INFO - 2023-09-10 15:14:51 --> Hooks Class Initialized
INFO - 2023-09-10 15:14:51 --> Config Class Initialized
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:51 --> Output Class Initialized
INFO - 2023-09-10 15:14:51 --> Hooks Class Initialized
INFO - 2023-09-10 15:14:51 --> Config Class Initialized
INFO - 2023-09-10 15:14:51 --> Security Class Initialized
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:51 --> Hooks Class Initialized
INFO - 2023-09-10 15:14:51 --> URI Class Initialized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 15:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:51 --> URI Class Initialized
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:51 --> Input Class Initialized
INFO - 2023-09-10 15:14:51 --> Router Class Initialized
INFO - 2023-09-10 15:14:51 --> Config Class Initialized
INFO - 2023-09-10 15:14:51 --> Language Class Initialized
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
INFO - 2023-09-10 15:14:51 --> Router Class Initialized
INFO - 2023-09-10 15:14:51 --> URI Class Initialized
ERROR - 2023-09-10 15:14:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:51 --> URI Class Initialized
INFO - 2023-09-10 15:14:51 --> Output Class Initialized
INFO - 2023-09-10 15:14:51 --> Output Class Initialized
INFO - 2023-09-10 15:14:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:14:51 --> Security Class Initialized
INFO - 2023-09-10 15:14:51 --> Router Class Initialized
INFO - 2023-09-10 15:14:51 --> Router Class Initialized
INFO - 2023-09-10 15:14:51 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:51 --> Security Class Initialized
INFO - 2023-09-10 15:14:51 --> Output Class Initialized
INFO - 2023-09-10 15:14:51 --> Output Class Initialized
DEBUG - 2023-09-10 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:52 --> URI Class Initialized
INFO - 2023-09-10 15:14:52 --> Input Class Initialized
INFO - 2023-09-10 15:14:52 --> Security Class Initialized
INFO - 2023-09-10 15:14:52 --> Security Class Initialized
INFO - 2023-09-10 15:14:52 --> Router Class Initialized
INFO - 2023-09-10 15:14:52 --> Input Class Initialized
DEBUG - 2023-09-10 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:52 --> Language Class Initialized
DEBUG - 2023-09-10 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:53 --> Output Class Initialized
ERROR - 2023-09-10 15:14:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:53 --> Security Class Initialized
INFO - 2023-09-10 15:14:54 --> Input Class Initialized
INFO - 2023-09-10 15:14:54 --> Input Class Initialized
INFO - 2023-09-10 15:14:54 --> Language Class Initialized
DEBUG - 2023-09-10 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:14:55 --> Language Class Initialized
INFO - 2023-09-10 15:14:55 --> Language Class Initialized
ERROR - 2023-09-10 15:14:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:55 --> Input Class Initialized
ERROR - 2023-09-10 15:14:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:14:55 --> Language Class Initialized
ERROR - 2023-09-10 15:14:55 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-10 15:14:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:15:55 --> Config Class Initialized
INFO - 2023-09-10 15:15:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:15:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:15:55 --> Utf8 Class Initialized
INFO - 2023-09-10 15:15:55 --> URI Class Initialized
DEBUG - 2023-09-10 15:15:55 --> No URI present. Default controller set.
INFO - 2023-09-10 15:15:55 --> Router Class Initialized
INFO - 2023-09-10 15:15:55 --> Output Class Initialized
INFO - 2023-09-10 15:15:55 --> Security Class Initialized
DEBUG - 2023-09-10 15:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:15:55 --> Input Class Initialized
INFO - 2023-09-10 15:15:55 --> Language Class Initialized
INFO - 2023-09-10 15:15:55 --> Loader Class Initialized
INFO - 2023-09-10 15:15:55 --> Helper loaded: url_helper
INFO - 2023-09-10 15:15:55 --> Helper loaded: file_helper
INFO - 2023-09-10 15:15:56 --> Database Driver Class Initialized
INFO - 2023-09-10 15:15:56 --> Email Class Initialized
DEBUG - 2023-09-10 15:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:15:56 --> Controller Class Initialized
INFO - 2023-09-10 15:15:56 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:15:56 --> Model "Home_model" initialized
INFO - 2023-09-10 15:15:56 --> Helper loaded: download_helper
INFO - 2023-09-10 15:15:56 --> Helper loaded: form_helper
INFO - 2023-09-10 15:15:56 --> Form Validation Class Initialized
INFO - 2023-09-10 15:15:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:15:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:15:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:15:56 --> Final output sent to browser
DEBUG - 2023-09-10 15:15:56 --> Total execution time: 0.8390
INFO - 2023-09-10 15:15:59 --> Config Class Initialized
INFO - 2023-09-10 15:15:59 --> Config Class Initialized
INFO - 2023-09-10 15:15:59 --> Hooks Class Initialized
INFO - 2023-09-10 15:15:59 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:00 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:16:00 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:00 --> URI Class Initialized
INFO - 2023-09-10 15:16:01 --> Router Class Initialized
INFO - 2023-09-10 15:16:01 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:01 --> Output Class Initialized
INFO - 2023-09-10 15:16:02 --> URI Class Initialized
INFO - 2023-09-10 15:16:02 --> Config Class Initialized
INFO - 2023-09-10 15:16:03 --> Config Class Initialized
INFO - 2023-09-10 15:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:03 --> URI Class Initialized
INFO - 2023-09-10 15:16:03 --> Router Class Initialized
INFO - 2023-09-10 15:16:03 --> Output Class Initialized
INFO - 2023-09-10 15:16:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:03 --> Input Class Initialized
INFO - 2023-09-10 15:16:03 --> Language Class Initialized
ERROR - 2023-09-10 15:16:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:03 --> Router Class Initialized
INFO - 2023-09-10 15:16:03 --> Config Class Initialized
INFO - 2023-09-10 15:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:03 --> URI Class Initialized
INFO - 2023-09-10 15:16:03 --> Router Class Initialized
INFO - 2023-09-10 15:16:03 --> Output Class Initialized
INFO - 2023-09-10 15:16:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:03 --> Input Class Initialized
INFO - 2023-09-10 15:16:03 --> Language Class Initialized
ERROR - 2023-09-10 15:16:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:03 --> Config Class Initialized
INFO - 2023-09-10 15:16:03 --> Config Class Initialized
INFO - 2023-09-10 15:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:03 --> URI Class Initialized
INFO - 2023-09-10 15:16:03 --> Router Class Initialized
INFO - 2023-09-10 15:16:03 --> Output Class Initialized
INFO - 2023-09-10 15:16:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:03 --> Input Class Initialized
INFO - 2023-09-10 15:16:03 --> Language Class Initialized
ERROR - 2023-09-10 15:16:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:03 --> Input Class Initialized
INFO - 2023-09-10 15:16:03 --> Language Class Initialized
ERROR - 2023-09-10 15:16:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:03 --> URI Class Initialized
INFO - 2023-09-10 15:16:03 --> Router Class Initialized
INFO - 2023-09-10 15:16:03 --> Output Class Initialized
INFO - 2023-09-10 15:16:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:04 --> Input Class Initialized
INFO - 2023-09-10 15:16:04 --> Language Class Initialized
ERROR - 2023-09-10 15:16:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:04 --> Output Class Initialized
INFO - 2023-09-10 15:16:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:04 --> Input Class Initialized
INFO - 2023-09-10 15:16:04 --> Language Class Initialized
ERROR - 2023-09-10 15:16:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:16:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:16:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:16:04 --> URI Class Initialized
INFO - 2023-09-10 15:16:04 --> Router Class Initialized
INFO - 2023-09-10 15:16:04 --> Output Class Initialized
INFO - 2023-09-10 15:16:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:16:04 --> Input Class Initialized
INFO - 2023-09-10 15:16:04 --> Language Class Initialized
ERROR - 2023-09-10 15:16:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:18:46 --> Config Class Initialized
INFO - 2023-09-10 15:18:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:18:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:18:46 --> Utf8 Class Initialized
INFO - 2023-09-10 15:18:46 --> URI Class Initialized
DEBUG - 2023-09-10 15:18:46 --> No URI present. Default controller set.
INFO - 2023-09-10 15:18:46 --> Router Class Initialized
INFO - 2023-09-10 15:18:46 --> Output Class Initialized
INFO - 2023-09-10 15:18:46 --> Security Class Initialized
DEBUG - 2023-09-10 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:18:46 --> Input Class Initialized
INFO - 2023-09-10 15:18:46 --> Language Class Initialized
INFO - 2023-09-10 15:18:47 --> Loader Class Initialized
INFO - 2023-09-10 15:18:47 --> Helper loaded: url_helper
INFO - 2023-09-10 15:18:47 --> Helper loaded: file_helper
INFO - 2023-09-10 15:18:47 --> Database Driver Class Initialized
INFO - 2023-09-10 15:18:47 --> Email Class Initialized
DEBUG - 2023-09-10 15:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:18:47 --> Controller Class Initialized
INFO - 2023-09-10 15:18:47 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:18:47 --> Model "Home_model" initialized
INFO - 2023-09-10 15:18:47 --> Helper loaded: download_helper
INFO - 2023-09-10 15:18:47 --> Helper loaded: form_helper
INFO - 2023-09-10 15:18:47 --> Form Validation Class Initialized
INFO - 2023-09-10 15:18:48 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:18:48 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:18:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:18:48 --> Final output sent to browser
DEBUG - 2023-09-10 15:18:48 --> Total execution time: 1.9374
INFO - 2023-09-10 15:18:53 --> Config Class Initialized
INFO - 2023-09-10 15:18:53 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:18:53 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:18:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:18:53 --> URI Class Initialized
INFO - 2023-09-10 15:18:53 --> Router Class Initialized
INFO - 2023-09-10 15:18:53 --> Output Class Initialized
INFO - 2023-09-10 15:18:53 --> Security Class Initialized
DEBUG - 2023-09-10 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:18:53 --> Input Class Initialized
INFO - 2023-09-10 15:18:53 --> Language Class Initialized
INFO - 2023-09-10 15:18:54 --> Loader Class Initialized
INFO - 2023-09-10 15:18:54 --> Helper loaded: url_helper
INFO - 2023-09-10 15:18:54 --> Helper loaded: file_helper
INFO - 2023-09-10 15:18:54 --> Database Driver Class Initialized
INFO - 2023-09-10 15:18:54 --> Email Class Initialized
DEBUG - 2023-09-10 15:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:18:54 --> Controller Class Initialized
INFO - 2023-09-10 15:18:54 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:18:54 --> Model "Home_model" initialized
INFO - 2023-09-10 15:18:54 --> Helper loaded: download_helper
INFO - 2023-09-10 15:18:54 --> Helper loaded: form_helper
INFO - 2023-09-10 15:18:54 --> Form Validation Class Initialized
INFO - 2023-09-10 15:18:54 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:18:55 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:18:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 15:18:55 --> Final output sent to browser
DEBUG - 2023-09-10 15:18:55 --> Total execution time: 1.7219
INFO - 2023-09-10 15:19:51 --> Config Class Initialized
INFO - 2023-09-10 15:19:51 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:19:51 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:19:51 --> Utf8 Class Initialized
INFO - 2023-09-10 15:19:51 --> URI Class Initialized
INFO - 2023-09-10 15:19:51 --> Router Class Initialized
INFO - 2023-09-10 15:19:51 --> Output Class Initialized
INFO - 2023-09-10 15:19:51 --> Security Class Initialized
DEBUG - 2023-09-10 15:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:19:52 --> Input Class Initialized
INFO - 2023-09-10 15:19:52 --> Language Class Initialized
INFO - 2023-09-10 15:19:52 --> Loader Class Initialized
INFO - 2023-09-10 15:19:52 --> Helper loaded: url_helper
INFO - 2023-09-10 15:19:52 --> Helper loaded: file_helper
INFO - 2023-09-10 15:19:52 --> Database Driver Class Initialized
INFO - 2023-09-10 15:19:52 --> Email Class Initialized
DEBUG - 2023-09-10 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:19:52 --> Controller Class Initialized
INFO - 2023-09-10 15:19:52 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:19:52 --> Model "Home_model" initialized
INFO - 2023-09-10 15:19:52 --> Helper loaded: download_helper
INFO - 2023-09-10 15:19:52 --> Helper loaded: form_helper
INFO - 2023-09-10 15:19:52 --> Form Validation Class Initialized
INFO - 2023-09-10 15:19:52 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:19:52 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:19:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 15:19:52 --> Final output sent to browser
DEBUG - 2023-09-10 15:19:53 --> Total execution time: 1.2363
INFO - 2023-09-10 15:20:38 --> Config Class Initialized
INFO - 2023-09-10 15:20:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:20:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:20:38 --> Utf8 Class Initialized
INFO - 2023-09-10 15:20:38 --> URI Class Initialized
INFO - 2023-09-10 15:20:38 --> Router Class Initialized
INFO - 2023-09-10 15:20:38 --> Output Class Initialized
INFO - 2023-09-10 15:20:38 --> Security Class Initialized
DEBUG - 2023-09-10 15:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:20:38 --> Input Class Initialized
INFO - 2023-09-10 15:20:38 --> Language Class Initialized
INFO - 2023-09-10 15:20:38 --> Loader Class Initialized
INFO - 2023-09-10 15:20:38 --> Helper loaded: url_helper
INFO - 2023-09-10 15:20:38 --> Helper loaded: file_helper
INFO - 2023-09-10 15:20:38 --> Database Driver Class Initialized
INFO - 2023-09-10 15:20:38 --> Email Class Initialized
DEBUG - 2023-09-10 15:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:20:39 --> Controller Class Initialized
INFO - 2023-09-10 15:20:39 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:20:39 --> Model "Home_model" initialized
INFO - 2023-09-10 15:20:39 --> Helper loaded: download_helper
INFO - 2023-09-10 15:20:39 --> Helper loaded: form_helper
INFO - 2023-09-10 15:20:39 --> Form Validation Class Initialized
INFO - 2023-09-10 15:20:39 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:20:39 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:20:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 15:20:39 --> Final output sent to browser
DEBUG - 2023-09-10 15:20:39 --> Total execution time: 1.2483
INFO - 2023-09-10 15:21:01 --> Config Class Initialized
INFO - 2023-09-10 15:21:01 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:21:01 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:21:01 --> Utf8 Class Initialized
INFO - 2023-09-10 15:21:01 --> URI Class Initialized
DEBUG - 2023-09-10 15:21:01 --> No URI present. Default controller set.
INFO - 2023-09-10 15:21:01 --> Router Class Initialized
INFO - 2023-09-10 15:21:01 --> Output Class Initialized
INFO - 2023-09-10 15:21:01 --> Security Class Initialized
DEBUG - 2023-09-10 15:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:21:01 --> Input Class Initialized
INFO - 2023-09-10 15:21:01 --> Language Class Initialized
INFO - 2023-09-10 15:21:01 --> Loader Class Initialized
INFO - 2023-09-10 15:21:01 --> Helper loaded: url_helper
INFO - 2023-09-10 15:21:01 --> Helper loaded: file_helper
INFO - 2023-09-10 15:21:01 --> Database Driver Class Initialized
INFO - 2023-09-10 15:21:02 --> Email Class Initialized
DEBUG - 2023-09-10 15:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:21:02 --> Controller Class Initialized
INFO - 2023-09-10 15:21:02 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:21:02 --> Model "Home_model" initialized
INFO - 2023-09-10 15:21:02 --> Helper loaded: download_helper
INFO - 2023-09-10 15:21:02 --> Helper loaded: form_helper
INFO - 2023-09-10 15:21:02 --> Form Validation Class Initialized
INFO - 2023-09-10 15:21:02 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:21:02 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:21:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:21:02 --> Final output sent to browser
DEBUG - 2023-09-10 15:21:03 --> Total execution time: 1.5580
INFO - 2023-09-10 15:22:01 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:22:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:03 --> URI Class Initialized
INFO - 2023-09-10 15:22:03 --> Router Class Initialized
INFO - 2023-09-10 15:22:03 --> Output Class Initialized
INFO - 2023-09-10 15:22:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:03 --> Input Class Initialized
INFO - 2023-09-10 15:22:03 --> Language Class Initialized
ERROR - 2023-09-10 15:22:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:22:03 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:22:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:03 --> URI Class Initialized
INFO - 2023-09-10 15:22:03 --> Router Class Initialized
INFO - 2023-09-10 15:22:03 --> Output Class Initialized
INFO - 2023-09-10 15:22:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:03 --> Input Class Initialized
INFO - 2023-09-10 15:22:03 --> Language Class Initialized
ERROR - 2023-09-10 15:22:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:22:03 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:22:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:03 --> Config Class Initialized
INFO - 2023-09-10 15:22:03 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:22:03 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:03 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:03 --> URI Class Initialized
INFO - 2023-09-10 15:22:03 --> Router Class Initialized
INFO - 2023-09-10 15:22:03 --> Output Class Initialized
INFO - 2023-09-10 15:22:03 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:03 --> Input Class Initialized
INFO - 2023-09-10 15:22:03 --> Language Class Initialized
ERROR - 2023-09-10 15:22:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:22:03 --> Hooks Class Initialized
INFO - 2023-09-10 15:22:04 --> Hooks Class Initialized
INFO - 2023-09-10 15:22:04 --> Utf8 Class Initialized
DEBUG - 2023-09-10 15:22:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:04 --> Config Class Initialized
INFO - 2023-09-10 15:22:04 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:22:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:04 --> URI Class Initialized
INFO - 2023-09-10 15:22:04 --> Router Class Initialized
INFO - 2023-09-10 15:22:04 --> Output Class Initialized
INFO - 2023-09-10 15:22:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:04 --> Input Class Initialized
INFO - 2023-09-10 15:22:04 --> Language Class Initialized
ERROR - 2023-09-10 15:22:04 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-10 15:22:04 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:22:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:04 --> Utf8 Class Initialized
INFO - 2023-09-10 15:22:04 --> URI Class Initialized
INFO - 2023-09-10 15:22:04 --> Router Class Initialized
INFO - 2023-09-10 15:22:04 --> Output Class Initialized
INFO - 2023-09-10 15:22:04 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:04 --> Input Class Initialized
INFO - 2023-09-10 15:22:04 --> Language Class Initialized
ERROR - 2023-09-10 15:22:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:22:04 --> URI Class Initialized
INFO - 2023-09-10 15:22:04 --> URI Class Initialized
INFO - 2023-09-10 15:22:04 --> Router Class Initialized
INFO - 2023-09-10 15:22:05 --> Router Class Initialized
INFO - 2023-09-10 15:22:05 --> Output Class Initialized
INFO - 2023-09-10 15:22:05 --> Security Class Initialized
INFO - 2023-09-10 15:22:05 --> Output Class Initialized
DEBUG - 2023-09-10 15:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:06 --> Security Class Initialized
DEBUG - 2023-09-10 15:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:22:06 --> Input Class Initialized
INFO - 2023-09-10 15:22:06 --> Language Class Initialized
ERROR - 2023-09-10 15:22:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:22:06 --> Input Class Initialized
INFO - 2023-09-10 15:22:06 --> Language Class Initialized
ERROR - 2023-09-10 15:22:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:36 --> Config Class Initialized
INFO - 2023-09-10 15:24:36 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:36 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:36 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:36 --> URI Class Initialized
INFO - 2023-09-10 15:24:36 --> Router Class Initialized
INFO - 2023-09-10 15:24:36 --> Output Class Initialized
INFO - 2023-09-10 15:24:36 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:36 --> Input Class Initialized
INFO - 2023-09-10 15:24:36 --> Language Class Initialized
INFO - 2023-09-10 15:24:36 --> Loader Class Initialized
INFO - 2023-09-10 15:24:36 --> Helper loaded: url_helper
INFO - 2023-09-10 15:24:36 --> Helper loaded: file_helper
INFO - 2023-09-10 15:24:36 --> Database Driver Class Initialized
INFO - 2023-09-10 15:24:36 --> Email Class Initialized
DEBUG - 2023-09-10 15:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:24:37 --> Controller Class Initialized
INFO - 2023-09-10 15:24:37 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:24:37 --> Model "Home_model" initialized
INFO - 2023-09-10 15:24:37 --> Helper loaded: download_helper
INFO - 2023-09-10 15:24:37 --> Helper loaded: form_helper
INFO - 2023-09-10 15:24:37 --> Form Validation Class Initialized
INFO - 2023-09-10 15:24:37 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:24:37 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:24:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-10 15:24:37 --> Final output sent to browser
DEBUG - 2023-09-10 15:24:37 --> Total execution time: 1.4187
INFO - 2023-09-10 15:24:39 --> Config Class Initialized
INFO - 2023-09-10 15:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:39 --> URI Class Initialized
INFO - 2023-09-10 15:24:39 --> Router Class Initialized
INFO - 2023-09-10 15:24:39 --> Output Class Initialized
INFO - 2023-09-10 15:24:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:39 --> Input Class Initialized
INFO - 2023-09-10 15:24:39 --> Language Class Initialized
ERROR - 2023-09-10 15:24:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:39 --> Config Class Initialized
INFO - 2023-09-10 15:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:39 --> URI Class Initialized
INFO - 2023-09-10 15:24:39 --> Router Class Initialized
INFO - 2023-09-10 15:24:39 --> Output Class Initialized
INFO - 2023-09-10 15:24:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:39 --> Input Class Initialized
INFO - 2023-09-10 15:24:39 --> Language Class Initialized
ERROR - 2023-09-10 15:24:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:39 --> Config Class Initialized
INFO - 2023-09-10 15:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:39 --> URI Class Initialized
INFO - 2023-09-10 15:24:39 --> Router Class Initialized
INFO - 2023-09-10 15:24:39 --> Output Class Initialized
INFO - 2023-09-10 15:24:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:39 --> Input Class Initialized
INFO - 2023-09-10 15:24:39 --> Language Class Initialized
ERROR - 2023-09-10 15:24:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:39 --> Config Class Initialized
INFO - 2023-09-10 15:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:39 --> URI Class Initialized
INFO - 2023-09-10 15:24:39 --> Router Class Initialized
INFO - 2023-09-10 15:24:39 --> Output Class Initialized
INFO - 2023-09-10 15:24:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:39 --> Input Class Initialized
INFO - 2023-09-10 15:24:39 --> Language Class Initialized
ERROR - 2023-09-10 15:24:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:41 --> Config Class Initialized
INFO - 2023-09-10 15:24:41 --> Config Class Initialized
INFO - 2023-09-10 15:24:41 --> Config Class Initialized
INFO - 2023-09-10 15:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:41 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:41 --> URI Class Initialized
INFO - 2023-09-10 15:24:41 --> Router Class Initialized
INFO - 2023-09-10 15:24:41 --> Output Class Initialized
INFO - 2023-09-10 15:24:41 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:41 --> Input Class Initialized
INFO - 2023-09-10 15:24:41 --> Language Class Initialized
ERROR - 2023-09-10 15:24:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:42 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:42 --> Hooks Class Initialized
INFO - 2023-09-10 15:24:43 --> URI Class Initialized
INFO - 2023-09-10 15:24:43 --> Router Class Initialized
DEBUG - 2023-09-10 15:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:43 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:43 --> Output Class Initialized
INFO - 2023-09-10 15:24:43 --> URI Class Initialized
INFO - 2023-09-10 15:24:44 --> Router Class Initialized
INFO - 2023-09-10 15:24:44 --> Security Class Initialized
INFO - 2023-09-10 15:24:44 --> Output Class Initialized
DEBUG - 2023-09-10 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:44 --> Input Class Initialized
INFO - 2023-09-10 15:24:44 --> Security Class Initialized
INFO - 2023-09-10 15:24:44 --> Language Class Initialized
DEBUG - 2023-09-10 15:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 15:24:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:44 --> Input Class Initialized
INFO - 2023-09-10 15:24:44 --> Language Class Initialized
ERROR - 2023-09-10 15:24:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:24:46 --> Config Class Initialized
INFO - 2023-09-10 15:24:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:47 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:47 --> URI Class Initialized
INFO - 2023-09-10 15:24:47 --> Router Class Initialized
INFO - 2023-09-10 15:24:47 --> Output Class Initialized
INFO - 2023-09-10 15:24:47 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:48 --> Input Class Initialized
INFO - 2023-09-10 15:24:48 --> Language Class Initialized
INFO - 2023-09-10 15:24:48 --> Loader Class Initialized
INFO - 2023-09-10 15:24:48 --> Helper loaded: url_helper
INFO - 2023-09-10 15:24:48 --> Helper loaded: file_helper
INFO - 2023-09-10 15:24:48 --> Database Driver Class Initialized
INFO - 2023-09-10 15:24:48 --> Email Class Initialized
DEBUG - 2023-09-10 15:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:24:48 --> Controller Class Initialized
INFO - 2023-09-10 15:24:48 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:24:48 --> Model "Home_model" initialized
INFO - 2023-09-10 15:24:48 --> Helper loaded: download_helper
INFO - 2023-09-10 15:24:48 --> Helper loaded: form_helper
INFO - 2023-09-10 15:24:48 --> Form Validation Class Initialized
INFO - 2023-09-10 15:24:48 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:24:48 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:24:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 15:24:49 --> Final output sent to browser
DEBUG - 2023-09-10 15:24:49 --> Total execution time: 2.2473
INFO - 2023-09-10 15:24:55 --> Config Class Initialized
INFO - 2023-09-10 15:24:55 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:24:55 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:24:55 --> Utf8 Class Initialized
INFO - 2023-09-10 15:24:55 --> URI Class Initialized
INFO - 2023-09-10 15:24:55 --> Router Class Initialized
INFO - 2023-09-10 15:24:55 --> Output Class Initialized
INFO - 2023-09-10 15:24:55 --> Security Class Initialized
DEBUG - 2023-09-10 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:24:55 --> Input Class Initialized
INFO - 2023-09-10 15:24:55 --> Language Class Initialized
INFO - 2023-09-10 15:24:55 --> Loader Class Initialized
INFO - 2023-09-10 15:24:55 --> Helper loaded: url_helper
INFO - 2023-09-10 15:24:55 --> Helper loaded: file_helper
INFO - 2023-09-10 15:24:56 --> Database Driver Class Initialized
INFO - 2023-09-10 15:24:56 --> Email Class Initialized
DEBUG - 2023-09-10 15:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:24:56 --> Controller Class Initialized
INFO - 2023-09-10 15:24:56 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:24:56 --> Model "Home_model" initialized
INFO - 2023-09-10 15:24:56 --> Helper loaded: download_helper
INFO - 2023-09-10 15:24:56 --> Helper loaded: form_helper
INFO - 2023-09-10 15:24:56 --> Form Validation Class Initialized
INFO - 2023-09-10 15:24:56 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:24:56 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:24:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-10 15:24:56 --> Final output sent to browser
DEBUG - 2023-09-10 15:24:56 --> Total execution time: 1.6063
INFO - 2023-09-10 15:25:42 --> Config Class Initialized
INFO - 2023-09-10 15:25:42 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:25:42 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:25:42 --> Utf8 Class Initialized
INFO - 2023-09-10 15:25:42 --> URI Class Initialized
DEBUG - 2023-09-10 15:25:42 --> No URI present. Default controller set.
INFO - 2023-09-10 15:25:42 --> Router Class Initialized
INFO - 2023-09-10 15:25:42 --> Output Class Initialized
INFO - 2023-09-10 15:25:42 --> Security Class Initialized
DEBUG - 2023-09-10 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:25:42 --> Input Class Initialized
INFO - 2023-09-10 15:25:42 --> Language Class Initialized
INFO - 2023-09-10 15:25:42 --> Loader Class Initialized
INFO - 2023-09-10 15:25:42 --> Helper loaded: url_helper
INFO - 2023-09-10 15:25:42 --> Helper loaded: file_helper
INFO - 2023-09-10 15:25:42 --> Database Driver Class Initialized
INFO - 2023-09-10 15:25:42 --> Email Class Initialized
DEBUG - 2023-09-10 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:25:42 --> Controller Class Initialized
INFO - 2023-09-10 15:25:43 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:25:43 --> Model "Home_model" initialized
INFO - 2023-09-10 15:25:43 --> Helper loaded: download_helper
INFO - 2023-09-10 15:25:43 --> Helper loaded: form_helper
INFO - 2023-09-10 15:25:43 --> Form Validation Class Initialized
INFO - 2023-09-10 15:25:43 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:25:43 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:25:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:25:43 --> Final output sent to browser
DEBUG - 2023-09-10 15:25:43 --> Total execution time: 1.1004
INFO - 2023-09-10 15:26:56 --> Config Class Initialized
INFO - 2023-09-10 15:26:56 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:26:56 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:26:57 --> Utf8 Class Initialized
INFO - 2023-09-10 15:26:57 --> URI Class Initialized
INFO - 2023-09-10 15:26:57 --> Router Class Initialized
INFO - 2023-09-10 15:26:57 --> Output Class Initialized
INFO - 2023-09-10 15:26:57 --> Security Class Initialized
DEBUG - 2023-09-10 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:26:57 --> Input Class Initialized
INFO - 2023-09-10 15:26:57 --> Language Class Initialized
INFO - 2023-09-10 15:26:57 --> Loader Class Initialized
INFO - 2023-09-10 15:26:58 --> Helper loaded: url_helper
INFO - 2023-09-10 15:26:58 --> Helper loaded: file_helper
INFO - 2023-09-10 15:26:58 --> Database Driver Class Initialized
INFO - 2023-09-10 15:26:58 --> Email Class Initialized
DEBUG - 2023-09-10 15:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:26:58 --> Controller Class Initialized
INFO - 2023-09-10 15:26:58 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:26:58 --> Model "Home_model" initialized
INFO - 2023-09-10 15:26:58 --> Helper loaded: download_helper
INFO - 2023-09-10 15:26:58 --> Helper loaded: form_helper
INFO - 2023-09-10 15:26:58 --> Form Validation Class Initialized
INFO - 2023-09-10 15:26:58 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:26:58 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:26:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-10 15:26:58 --> Final output sent to browser
DEBUG - 2023-09-10 15:26:59 --> Total execution time: 2.1157
INFO - 2023-09-10 15:27:11 --> Config Class Initialized
INFO - 2023-09-10 15:27:11 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:27:11 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:27:11 --> Utf8 Class Initialized
INFO - 2023-09-10 15:27:11 --> URI Class Initialized
INFO - 2023-09-10 15:27:11 --> Router Class Initialized
INFO - 2023-09-10 15:27:11 --> Output Class Initialized
INFO - 2023-09-10 15:27:11 --> Security Class Initialized
DEBUG - 2023-09-10 15:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:27:11 --> Input Class Initialized
INFO - 2023-09-10 15:27:11 --> Language Class Initialized
INFO - 2023-09-10 15:27:11 --> Loader Class Initialized
INFO - 2023-09-10 15:27:11 --> Helper loaded: url_helper
INFO - 2023-09-10 15:27:12 --> Helper loaded: file_helper
INFO - 2023-09-10 15:27:12 --> Database Driver Class Initialized
INFO - 2023-09-10 15:27:12 --> Email Class Initialized
DEBUG - 2023-09-10 15:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:27:12 --> Controller Class Initialized
INFO - 2023-09-10 15:27:12 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:27:12 --> Model "Home_model" initialized
INFO - 2023-09-10 15:27:12 --> Helper loaded: download_helper
INFO - 2023-09-10 15:27:12 --> Helper loaded: form_helper
INFO - 2023-09-10 15:27:12 --> Form Validation Class Initialized
INFO - 2023-09-10 15:27:12 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:27:12 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:27:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-10 15:27:12 --> Final output sent to browser
DEBUG - 2023-09-10 15:27:12 --> Total execution time: 0.4984
INFO - 2023-09-10 15:27:46 --> Config Class Initialized
INFO - 2023-09-10 15:27:46 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:27:46 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:27:46 --> Utf8 Class Initialized
INFO - 2023-09-10 15:27:46 --> URI Class Initialized
INFO - 2023-09-10 15:27:46 --> Router Class Initialized
INFO - 2023-09-10 15:27:46 --> Output Class Initialized
INFO - 2023-09-10 15:27:46 --> Security Class Initialized
DEBUG - 2023-09-10 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:27:46 --> Input Class Initialized
INFO - 2023-09-10 15:27:46 --> Language Class Initialized
INFO - 2023-09-10 15:27:46 --> Loader Class Initialized
INFO - 2023-09-10 15:27:46 --> Helper loaded: url_helper
INFO - 2023-09-10 15:27:46 --> Helper loaded: file_helper
INFO - 2023-09-10 15:27:46 --> Database Driver Class Initialized
INFO - 2023-09-10 15:27:46 --> Email Class Initialized
DEBUG - 2023-09-10 15:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:27:47 --> Controller Class Initialized
INFO - 2023-09-10 15:27:47 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:27:47 --> Model "Home_model" initialized
INFO - 2023-09-10 15:27:47 --> Helper loaded: download_helper
INFO - 2023-09-10 15:27:47 --> Helper loaded: form_helper
INFO - 2023-09-10 15:27:47 --> Form Validation Class Initialized
INFO - 2023-09-10 15:27:47 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:27:47 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:27:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-10 15:27:47 --> Final output sent to browser
DEBUG - 2023-09-10 15:27:47 --> Total execution time: 1.1280
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:52 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:52 --> URI Class Initialized
INFO - 2023-09-10 15:30:52 --> Router Class Initialized
INFO - 2023-09-10 15:30:52 --> Output Class Initialized
INFO - 2023-09-10 15:30:52 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:52 --> Input Class Initialized
INFO - 2023-09-10 15:30:52 --> Language Class Initialized
ERROR - 2023-09-10 15:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:52 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:52 --> URI Class Initialized
INFO - 2023-09-10 15:30:52 --> Router Class Initialized
INFO - 2023-09-10 15:30:52 --> Output Class Initialized
INFO - 2023-09-10 15:30:52 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:52 --> Input Class Initialized
INFO - 2023-09-10 15:30:52 --> Language Class Initialized
ERROR - 2023-09-10 15:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:52 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:52 --> URI Class Initialized
INFO - 2023-09-10 15:30:52 --> Router Class Initialized
INFO - 2023-09-10 15:30:52 --> Output Class Initialized
INFO - 2023-09-10 15:30:52 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:52 --> Input Class Initialized
INFO - 2023-09-10 15:30:52 --> Language Class Initialized
ERROR - 2023-09-10 15:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:52 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:52 --> URI Class Initialized
INFO - 2023-09-10 15:30:52 --> Router Class Initialized
INFO - 2023-09-10 15:30:52 --> Output Class Initialized
INFO - 2023-09-10 15:30:52 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:52 --> Input Class Initialized
INFO - 2023-09-10 15:30:52 --> Language Class Initialized
ERROR - 2023-09-10 15:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:52 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:52 --> URI Class Initialized
INFO - 2023-09-10 15:30:52 --> Router Class Initialized
INFO - 2023-09-10 15:30:52 --> Output Class Initialized
INFO - 2023-09-10 15:30:52 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:52 --> Input Class Initialized
INFO - 2023-09-10 15:30:52 --> Language Class Initialized
ERROR - 2023-09-10 15:30:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:52 --> Config Class Initialized
INFO - 2023-09-10 15:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:53 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:54 --> Config Class Initialized
INFO - 2023-09-10 15:30:54 --> URI Class Initialized
INFO - 2023-09-10 15:30:54 --> Router Class Initialized
INFO - 2023-09-10 15:30:54 --> Output Class Initialized
INFO - 2023-09-10 15:30:54 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:54 --> Input Class Initialized
INFO - 2023-09-10 15:30:54 --> Language Class Initialized
ERROR - 2023-09-10 15:30:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:30:54 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:30:54 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:30:54 --> Utf8 Class Initialized
INFO - 2023-09-10 15:30:54 --> URI Class Initialized
INFO - 2023-09-10 15:30:55 --> Router Class Initialized
INFO - 2023-09-10 15:30:55 --> Output Class Initialized
INFO - 2023-09-10 15:30:55 --> Security Class Initialized
DEBUG - 2023-09-10 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:30:55 --> Input Class Initialized
INFO - 2023-09-10 15:30:55 --> Language Class Initialized
ERROR - 2023-09-10 15:30:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:31:23 --> Config Class Initialized
INFO - 2023-09-10 15:31:23 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:31:23 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:31:23 --> Utf8 Class Initialized
INFO - 2023-09-10 15:31:23 --> URI Class Initialized
DEBUG - 2023-09-10 15:31:23 --> No URI present. Default controller set.
INFO - 2023-09-10 15:31:23 --> Router Class Initialized
INFO - 2023-09-10 15:31:23 --> Output Class Initialized
INFO - 2023-09-10 15:31:23 --> Security Class Initialized
DEBUG - 2023-09-10 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:31:24 --> Input Class Initialized
INFO - 2023-09-10 15:31:24 --> Language Class Initialized
INFO - 2023-09-10 15:31:24 --> Loader Class Initialized
INFO - 2023-09-10 15:31:24 --> Helper loaded: url_helper
INFO - 2023-09-10 15:31:24 --> Helper loaded: file_helper
INFO - 2023-09-10 15:31:24 --> Database Driver Class Initialized
INFO - 2023-09-10 15:31:24 --> Email Class Initialized
DEBUG - 2023-09-10 15:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:31:24 --> Controller Class Initialized
INFO - 2023-09-10 15:31:24 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:31:24 --> Model "Home_model" initialized
INFO - 2023-09-10 15:31:24 --> Helper loaded: download_helper
INFO - 2023-09-10 15:31:24 --> Helper loaded: form_helper
INFO - 2023-09-10 15:31:24 --> Form Validation Class Initialized
INFO - 2023-09-10 15:31:25 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:31:25 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:31:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:31:25 --> Final output sent to browser
DEBUG - 2023-09-10 15:31:25 --> Total execution time: 1.6130
INFO - 2023-09-10 15:34:37 --> Config Class Initialized
INFO - 2023-09-10 15:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:37 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:37 --> URI Class Initialized
INFO - 2023-09-10 15:34:37 --> Router Class Initialized
INFO - 2023-09-10 15:34:37 --> Output Class Initialized
INFO - 2023-09-10 15:34:37 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:37 --> Input Class Initialized
INFO - 2023-09-10 15:34:37 --> Language Class Initialized
ERROR - 2023-09-10 15:34:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:37 --> Config Class Initialized
INFO - 2023-09-10 15:34:38 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:38 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:38 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:38 --> URI Class Initialized
INFO - 2023-09-10 15:34:38 --> Router Class Initialized
INFO - 2023-09-10 15:34:38 --> Output Class Initialized
INFO - 2023-09-10 15:34:38 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:38 --> Input Class Initialized
INFO - 2023-09-10 15:34:38 --> Language Class Initialized
ERROR - 2023-09-10 15:34:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:39 --> Config Class Initialized
INFO - 2023-09-10 15:34:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:39 --> URI Class Initialized
INFO - 2023-09-10 15:34:39 --> Router Class Initialized
INFO - 2023-09-10 15:34:39 --> Output Class Initialized
INFO - 2023-09-10 15:34:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:39 --> Input Class Initialized
INFO - 2023-09-10 15:34:39 --> Language Class Initialized
ERROR - 2023-09-10 15:34:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:39 --> Config Class Initialized
INFO - 2023-09-10 15:34:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:39 --> URI Class Initialized
INFO - 2023-09-10 15:34:39 --> Router Class Initialized
INFO - 2023-09-10 15:34:39 --> Output Class Initialized
INFO - 2023-09-10 15:34:39 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:39 --> Input Class Initialized
INFO - 2023-09-10 15:34:39 --> Language Class Initialized
ERROR - 2023-09-10 15:34:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:40 --> Config Class Initialized
INFO - 2023-09-10 15:34:40 --> Config Class Initialized
INFO - 2023-09-10 15:34:40 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:40 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:40 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:40 --> URI Class Initialized
INFO - 2023-09-10 15:34:40 --> Router Class Initialized
INFO - 2023-09-10 15:34:40 --> Output Class Initialized
INFO - 2023-09-10 15:34:40 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:40 --> Input Class Initialized
INFO - 2023-09-10 15:34:40 --> Language Class Initialized
ERROR - 2023-09-10 15:34:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:41 --> Config Class Initialized
INFO - 2023-09-10 15:34:41 --> Hooks Class Initialized
INFO - 2023-09-10 15:34:41 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 15:34:41 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:34:42 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:42 --> Utf8 Class Initialized
INFO - 2023-09-10 15:34:42 --> URI Class Initialized
INFO - 2023-09-10 15:34:42 --> URI Class Initialized
INFO - 2023-09-10 15:34:42 --> Router Class Initialized
INFO - 2023-09-10 15:34:42 --> Router Class Initialized
INFO - 2023-09-10 15:34:42 --> Output Class Initialized
INFO - 2023-09-10 15:34:42 --> Output Class Initialized
INFO - 2023-09-10 15:34:42 --> Security Class Initialized
INFO - 2023-09-10 15:34:42 --> Security Class Initialized
DEBUG - 2023-09-10 15:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:34:43 --> Input Class Initialized
INFO - 2023-09-10 15:34:43 --> Language Class Initialized
INFO - 2023-09-10 15:34:43 --> Input Class Initialized
ERROR - 2023-09-10 15:34:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:34:44 --> Language Class Initialized
ERROR - 2023-09-10 15:34:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-10 15:43:39 --> Config Class Initialized
INFO - 2023-09-10 15:43:39 --> Hooks Class Initialized
DEBUG - 2023-09-10 15:43:39 --> UTF-8 Support Enabled
INFO - 2023-09-10 15:43:39 --> Utf8 Class Initialized
INFO - 2023-09-10 15:43:40 --> URI Class Initialized
DEBUG - 2023-09-10 15:43:40 --> No URI present. Default controller set.
INFO - 2023-09-10 15:43:40 --> Router Class Initialized
INFO - 2023-09-10 15:43:40 --> Output Class Initialized
INFO - 2023-09-10 15:43:40 --> Security Class Initialized
DEBUG - 2023-09-10 15:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-10 15:43:40 --> Input Class Initialized
INFO - 2023-09-10 15:43:40 --> Language Class Initialized
INFO - 2023-09-10 15:43:40 --> Loader Class Initialized
INFO - 2023-09-10 15:43:40 --> Helper loaded: url_helper
INFO - 2023-09-10 15:43:40 --> Helper loaded: file_helper
INFO - 2023-09-10 15:43:40 --> Database Driver Class Initialized
INFO - 2023-09-10 15:43:40 --> Email Class Initialized
DEBUG - 2023-09-10 15:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-10 15:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-10 15:43:41 --> Controller Class Initialized
INFO - 2023-09-10 15:43:41 --> Model "Contact_model" initialized
INFO - 2023-09-10 15:43:41 --> Model "Home_model" initialized
INFO - 2023-09-10 15:43:41 --> Helper loaded: download_helper
INFO - 2023-09-10 15:43:41 --> Helper loaded: form_helper
INFO - 2023-09-10 15:43:41 --> Form Validation Class Initialized
INFO - 2023-09-10 15:43:41 --> Helper loaded: custom_helper
INFO - 2023-09-10 15:43:41 --> Model "Social_media_model" initialized
INFO - 2023-09-10 15:43:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-10 15:43:42 --> Final output sent to browser
DEBUG - 2023-09-10 15:43:42 --> Total execution time: 2.4838
