<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-25 16:53:56 --> Config Class Initialized
INFO - 2023-09-25 16:53:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 16:53:57 --> UTF-8 Support Enabled
INFO - 2023-09-25 16:53:57 --> Utf8 Class Initialized
INFO - 2023-09-25 16:53:57 --> URI Class Initialized
DEBUG - 2023-09-25 16:53:57 --> No URI present. Default controller set.
INFO - 2023-09-25 16:53:57 --> Router Class Initialized
INFO - 2023-09-25 16:53:58 --> Output Class Initialized
INFO - 2023-09-25 16:53:58 --> Security Class Initialized
DEBUG - 2023-09-25 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 16:53:58 --> Input Class Initialized
INFO - 2023-09-25 16:53:58 --> Language Class Initialized
INFO - 2023-09-25 16:53:58 --> Loader Class Initialized
INFO - 2023-09-25 16:53:59 --> Helper loaded: url_helper
INFO - 2023-09-25 16:53:59 --> Helper loaded: file_helper
INFO - 2023-09-25 16:53:59 --> Database Driver Class Initialized
INFO - 2023-09-25 16:54:00 --> Email Class Initialized
DEBUG - 2023-09-25 16:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 16:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 16:54:01 --> Controller Class Initialized
INFO - 2023-09-25 16:54:01 --> Model "Contact_model" initialized
INFO - 2023-09-25 16:54:01 --> Model "Home_model" initialized
INFO - 2023-09-25 16:54:01 --> Helper loaded: download_helper
INFO - 2023-09-25 16:54:02 --> Helper loaded: form_helper
INFO - 2023-09-25 16:54:02 --> Form Validation Class Initialized
INFO - 2023-09-25 16:54:05 --> Helper loaded: custom_helper
INFO - 2023-09-25 16:54:05 --> Model "Social_media_model" initialized
INFO - 2023-09-25 16:54:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-25 16:54:07 --> Final output sent to browser
DEBUG - 2023-09-25 16:54:07 --> Total execution time: 11.2191
INFO - 2023-09-25 17:00:02 --> Config Class Initialized
INFO - 2023-09-25 17:00:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:02 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:02 --> URI Class Initialized
INFO - 2023-09-25 17:00:02 --> Router Class Initialized
INFO - 2023-09-25 17:00:02 --> Output Class Initialized
INFO - 2023-09-25 17:00:02 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:02 --> Input Class Initialized
INFO - 2023-09-25 17:00:02 --> Language Class Initialized
INFO - 2023-09-25 17:00:02 --> Loader Class Initialized
INFO - 2023-09-25 17:00:02 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:02 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:03 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:03 --> Config Class Initialized
INFO - 2023-09-25 17:00:03 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:03 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:03 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:03 --> URI Class Initialized
INFO - 2023-09-25 17:00:03 --> Router Class Initialized
INFO - 2023-09-25 17:00:03 --> Output Class Initialized
INFO - 2023-09-25 17:00:03 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:03 --> Input Class Initialized
INFO - 2023-09-25 17:00:03 --> Language Class Initialized
INFO - 2023-09-25 17:00:03 --> Loader Class Initialized
INFO - 2023-09-25 17:00:03 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:03 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:03 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:03 --> Email Class Initialized
INFO - 2023-09-25 17:00:03 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:03 --> Controller Class Initialized
INFO - 2023-09-25 17:00:03 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:03 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:03 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:03 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:03 --> Form Validation Class Initialized
DEBUG - 2023-09-25 17:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:03 --> Controller Class Initialized
INFO - 2023-09-25 17:00:03 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:03 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:03 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:03 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:03 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:04 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:04 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:04 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:04 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:04 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:04 --> Total execution time: 2.5009
INFO - 2023-09-25 17:00:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:04 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:04 --> Total execution time: 1.7459
INFO - 2023-09-25 17:00:12 --> Config Class Initialized
INFO - 2023-09-25 17:00:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:12 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:12 --> URI Class Initialized
INFO - 2023-09-25 17:00:12 --> Router Class Initialized
INFO - 2023-09-25 17:00:12 --> Output Class Initialized
INFO - 2023-09-25 17:00:12 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:12 --> Input Class Initialized
INFO - 2023-09-25 17:00:12 --> Language Class Initialized
INFO - 2023-09-25 17:00:12 --> Loader Class Initialized
INFO - 2023-09-25 17:00:12 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:12 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:12 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:12 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:13 --> Controller Class Initialized
INFO - 2023-09-25 17:00:13 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:13 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:13 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:13 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:13 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:13 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:13 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:13 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:13 --> Total execution time: 0.1407
INFO - 2023-09-25 17:00:19 --> Config Class Initialized
INFO - 2023-09-25 17:00:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:19 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:19 --> URI Class Initialized
INFO - 2023-09-25 17:00:19 --> Router Class Initialized
INFO - 2023-09-25 17:00:19 --> Output Class Initialized
INFO - 2023-09-25 17:00:19 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:19 --> Input Class Initialized
INFO - 2023-09-25 17:00:19 --> Language Class Initialized
INFO - 2023-09-25 17:00:19 --> Loader Class Initialized
INFO - 2023-09-25 17:00:19 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:19 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:19 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:19 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:19 --> Controller Class Initialized
INFO - 2023-09-25 17:00:19 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:19 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:19 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:19 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:19 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:19 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:19 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:19 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:19 --> Total execution time: 0.0612
INFO - 2023-09-25 17:00:25 --> Config Class Initialized
INFO - 2023-09-25 17:00:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:25 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:25 --> URI Class Initialized
INFO - 2023-09-25 17:00:25 --> Router Class Initialized
INFO - 2023-09-25 17:00:25 --> Output Class Initialized
INFO - 2023-09-25 17:00:25 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:25 --> Input Class Initialized
INFO - 2023-09-25 17:00:25 --> Language Class Initialized
INFO - 2023-09-25 17:00:25 --> Loader Class Initialized
INFO - 2023-09-25 17:00:25 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:25 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:25 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:25 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:25 --> Controller Class Initialized
INFO - 2023-09-25 17:00:25 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:25 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:25 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:25 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:25 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:25 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:25 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:25 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:25 --> Total execution time: 0.0523
INFO - 2023-09-25 17:00:31 --> Config Class Initialized
INFO - 2023-09-25 17:00:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:31 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:31 --> URI Class Initialized
INFO - 2023-09-25 17:00:31 --> Router Class Initialized
INFO - 2023-09-25 17:00:31 --> Output Class Initialized
INFO - 2023-09-25 17:00:31 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:31 --> Input Class Initialized
INFO - 2023-09-25 17:00:31 --> Language Class Initialized
INFO - 2023-09-25 17:00:31 --> Loader Class Initialized
INFO - 2023-09-25 17:00:31 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:31 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:31 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:31 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:31 --> Controller Class Initialized
INFO - 2023-09-25 17:00:31 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:31 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:31 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:31 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:31 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:31 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:31 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:31 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:31 --> Total execution time: 0.0572
INFO - 2023-09-25 17:00:39 --> Config Class Initialized
INFO - 2023-09-25 17:00:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:39 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:39 --> URI Class Initialized
INFO - 2023-09-25 17:00:39 --> Router Class Initialized
INFO - 2023-09-25 17:00:39 --> Output Class Initialized
INFO - 2023-09-25 17:00:39 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:39 --> Input Class Initialized
INFO - 2023-09-25 17:00:39 --> Language Class Initialized
INFO - 2023-09-25 17:00:39 --> Loader Class Initialized
INFO - 2023-09-25 17:00:39 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:39 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:39 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:39 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:39 --> Controller Class Initialized
INFO - 2023-09-25 17:00:39 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:39 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:39 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:39 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:39 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:39 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:39 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:39 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:39 --> Total execution time: 0.0661
INFO - 2023-09-25 17:00:46 --> Config Class Initialized
INFO - 2023-09-25 17:00:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:46 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:46 --> URI Class Initialized
INFO - 2023-09-25 17:00:46 --> Router Class Initialized
INFO - 2023-09-25 17:00:46 --> Output Class Initialized
INFO - 2023-09-25 17:00:46 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:46 --> Input Class Initialized
INFO - 2023-09-25 17:00:46 --> Language Class Initialized
INFO - 2023-09-25 17:00:46 --> Loader Class Initialized
INFO - 2023-09-25 17:00:46 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:46 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:46 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:46 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:47 --> Controller Class Initialized
INFO - 2023-09-25 17:00:47 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:47 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:47 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:47 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:47 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:47 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:47 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:47 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:47 --> Total execution time: 0.1266
INFO - 2023-09-25 17:00:52 --> Config Class Initialized
INFO - 2023-09-25 17:00:52 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:52 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:52 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:52 --> URI Class Initialized
INFO - 2023-09-25 17:00:52 --> Router Class Initialized
INFO - 2023-09-25 17:00:52 --> Output Class Initialized
INFO - 2023-09-25 17:00:52 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:52 --> Input Class Initialized
INFO - 2023-09-25 17:00:52 --> Language Class Initialized
INFO - 2023-09-25 17:00:52 --> Loader Class Initialized
INFO - 2023-09-25 17:00:52 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:52 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:52 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:52 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:52 --> Controller Class Initialized
INFO - 2023-09-25 17:00:52 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:52 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:52 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:52 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:52 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:52 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:52 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:52 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:52 --> Total execution time: 0.0559
INFO - 2023-09-25 17:00:59 --> Config Class Initialized
INFO - 2023-09-25 17:00:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:00:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:00:59 --> Utf8 Class Initialized
INFO - 2023-09-25 17:00:59 --> URI Class Initialized
INFO - 2023-09-25 17:00:59 --> Router Class Initialized
INFO - 2023-09-25 17:00:59 --> Output Class Initialized
INFO - 2023-09-25 17:00:59 --> Security Class Initialized
DEBUG - 2023-09-25 17:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:00:59 --> Input Class Initialized
INFO - 2023-09-25 17:00:59 --> Language Class Initialized
INFO - 2023-09-25 17:00:59 --> Loader Class Initialized
INFO - 2023-09-25 17:00:59 --> Helper loaded: url_helper
INFO - 2023-09-25 17:00:59 --> Helper loaded: file_helper
INFO - 2023-09-25 17:00:59 --> Database Driver Class Initialized
INFO - 2023-09-25 17:00:59 --> Email Class Initialized
DEBUG - 2023-09-25 17:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:00:59 --> Controller Class Initialized
INFO - 2023-09-25 17:00:59 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:00:59 --> Model "Home_model" initialized
INFO - 2023-09-25 17:00:59 --> Helper loaded: download_helper
INFO - 2023-09-25 17:00:59 --> Helper loaded: form_helper
INFO - 2023-09-25 17:00:59 --> Form Validation Class Initialized
INFO - 2023-09-25 17:00:59 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:00:59 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:00:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:00:59 --> Final output sent to browser
DEBUG - 2023-09-25 17:00:59 --> Total execution time: 0.0564
INFO - 2023-09-25 17:01:05 --> Config Class Initialized
INFO - 2023-09-25 17:01:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:05 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:05 --> URI Class Initialized
INFO - 2023-09-25 17:01:05 --> Router Class Initialized
INFO - 2023-09-25 17:01:05 --> Output Class Initialized
INFO - 2023-09-25 17:01:05 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:05 --> Input Class Initialized
INFO - 2023-09-25 17:01:05 --> Language Class Initialized
INFO - 2023-09-25 17:01:05 --> Loader Class Initialized
INFO - 2023-09-25 17:01:05 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:05 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:05 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:05 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:05 --> Controller Class Initialized
INFO - 2023-09-25 17:01:05 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:05 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:05 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:05 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:05 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:05 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:05 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:05 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:05 --> Total execution time: 0.0691
INFO - 2023-09-25 17:01:10 --> Config Class Initialized
INFO - 2023-09-25 17:01:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:10 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:10 --> URI Class Initialized
INFO - 2023-09-25 17:01:10 --> Router Class Initialized
INFO - 2023-09-25 17:01:10 --> Output Class Initialized
INFO - 2023-09-25 17:01:10 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:10 --> Input Class Initialized
INFO - 2023-09-25 17:01:10 --> Language Class Initialized
INFO - 2023-09-25 17:01:10 --> Loader Class Initialized
INFO - 2023-09-25 17:01:10 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:10 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:10 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:10 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:10 --> Controller Class Initialized
INFO - 2023-09-25 17:01:10 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:10 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:10 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:10 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:10 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:10 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:10 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:10 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:10 --> Total execution time: 0.0620
INFO - 2023-09-25 17:01:17 --> Config Class Initialized
INFO - 2023-09-25 17:01:17 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:17 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:17 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:17 --> URI Class Initialized
INFO - 2023-09-25 17:01:17 --> Router Class Initialized
INFO - 2023-09-25 17:01:17 --> Output Class Initialized
INFO - 2023-09-25 17:01:17 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:17 --> Input Class Initialized
INFO - 2023-09-25 17:01:17 --> Language Class Initialized
INFO - 2023-09-25 17:01:17 --> Loader Class Initialized
INFO - 2023-09-25 17:01:17 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:17 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:17 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:17 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:17 --> Controller Class Initialized
INFO - 2023-09-25 17:01:17 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:17 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:17 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:17 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:17 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:17 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:17 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:17 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:17 --> Total execution time: 0.0630
INFO - 2023-09-25 17:01:23 --> Config Class Initialized
INFO - 2023-09-25 17:01:23 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:23 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:23 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:23 --> URI Class Initialized
INFO - 2023-09-25 17:01:23 --> Router Class Initialized
INFO - 2023-09-25 17:01:23 --> Output Class Initialized
INFO - 2023-09-25 17:01:23 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:23 --> Input Class Initialized
INFO - 2023-09-25 17:01:23 --> Language Class Initialized
INFO - 2023-09-25 17:01:23 --> Loader Class Initialized
INFO - 2023-09-25 17:01:23 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:23 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:23 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:23 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:23 --> Controller Class Initialized
INFO - 2023-09-25 17:01:23 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:23 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:23 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:23 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:23 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:23 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:23 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:23 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:23 --> Total execution time: 0.0652
INFO - 2023-09-25 17:01:28 --> Config Class Initialized
INFO - 2023-09-25 17:01:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:28 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:28 --> URI Class Initialized
INFO - 2023-09-25 17:01:28 --> Router Class Initialized
INFO - 2023-09-25 17:01:28 --> Output Class Initialized
INFO - 2023-09-25 17:01:28 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:28 --> Input Class Initialized
INFO - 2023-09-25 17:01:28 --> Language Class Initialized
INFO - 2023-09-25 17:01:28 --> Loader Class Initialized
INFO - 2023-09-25 17:01:28 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:28 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:28 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:28 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:28 --> Controller Class Initialized
INFO - 2023-09-25 17:01:28 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:28 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:28 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:28 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:28 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:28 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:28 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:28 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:28 --> Total execution time: 0.0590
INFO - 2023-09-25 17:01:33 --> Config Class Initialized
INFO - 2023-09-25 17:01:33 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:33 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:33 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:33 --> URI Class Initialized
INFO - 2023-09-25 17:01:33 --> Router Class Initialized
INFO - 2023-09-25 17:01:33 --> Output Class Initialized
INFO - 2023-09-25 17:01:33 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:33 --> Input Class Initialized
INFO - 2023-09-25 17:01:33 --> Language Class Initialized
INFO - 2023-09-25 17:01:33 --> Loader Class Initialized
INFO - 2023-09-25 17:01:33 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:33 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:33 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:33 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:33 --> Controller Class Initialized
INFO - 2023-09-25 17:01:33 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:33 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:33 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:33 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:33 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:33 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:33 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:33 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:33 --> Total execution time: 0.0792
INFO - 2023-09-25 17:01:40 --> Config Class Initialized
INFO - 2023-09-25 17:01:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:40 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:40 --> URI Class Initialized
INFO - 2023-09-25 17:01:40 --> Router Class Initialized
INFO - 2023-09-25 17:01:40 --> Output Class Initialized
INFO - 2023-09-25 17:01:40 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:40 --> Input Class Initialized
INFO - 2023-09-25 17:01:40 --> Language Class Initialized
INFO - 2023-09-25 17:01:40 --> Loader Class Initialized
INFO - 2023-09-25 17:01:40 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:40 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:40 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:40 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:40 --> Controller Class Initialized
INFO - 2023-09-25 17:01:40 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:40 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:40 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:40 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:40 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:40 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:40 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:40 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:40 --> Total execution time: 0.0619
INFO - 2023-09-25 17:01:44 --> Config Class Initialized
INFO - 2023-09-25 17:01:44 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:44 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:44 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:44 --> URI Class Initialized
INFO - 2023-09-25 17:01:44 --> Router Class Initialized
INFO - 2023-09-25 17:01:44 --> Output Class Initialized
INFO - 2023-09-25 17:01:44 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:44 --> Input Class Initialized
INFO - 2023-09-25 17:01:44 --> Language Class Initialized
INFO - 2023-09-25 17:01:44 --> Loader Class Initialized
INFO - 2023-09-25 17:01:44 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:44 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:44 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:44 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:44 --> Controller Class Initialized
INFO - 2023-09-25 17:01:44 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:44 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:44 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:44 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:44 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:44 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:44 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:44 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:44 --> Total execution time: 0.0547
INFO - 2023-09-25 17:01:49 --> Config Class Initialized
INFO - 2023-09-25 17:01:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:49 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:49 --> URI Class Initialized
INFO - 2023-09-25 17:01:49 --> Router Class Initialized
INFO - 2023-09-25 17:01:49 --> Output Class Initialized
INFO - 2023-09-25 17:01:49 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:49 --> Input Class Initialized
INFO - 2023-09-25 17:01:49 --> Language Class Initialized
INFO - 2023-09-25 17:01:49 --> Loader Class Initialized
INFO - 2023-09-25 17:01:49 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:49 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:49 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:49 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:49 --> Controller Class Initialized
INFO - 2023-09-25 17:01:49 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:49 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:49 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:49 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:49 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:49 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:49 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:49 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:49 --> Total execution time: 0.0619
INFO - 2023-09-25 17:01:54 --> Config Class Initialized
INFO - 2023-09-25 17:01:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:54 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:54 --> URI Class Initialized
INFO - 2023-09-25 17:01:54 --> Router Class Initialized
INFO - 2023-09-25 17:01:54 --> Output Class Initialized
INFO - 2023-09-25 17:01:54 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:54 --> Input Class Initialized
INFO - 2023-09-25 17:01:54 --> Language Class Initialized
INFO - 2023-09-25 17:01:54 --> Loader Class Initialized
INFO - 2023-09-25 17:01:54 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:54 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:54 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:54 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:54 --> Controller Class Initialized
INFO - 2023-09-25 17:01:54 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:54 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:54 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:54 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:54 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:54 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:54 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:54 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:54 --> Total execution time: 0.0642
INFO - 2023-09-25 17:01:59 --> Config Class Initialized
INFO - 2023-09-25 17:01:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:01:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:01:59 --> Utf8 Class Initialized
INFO - 2023-09-25 17:01:59 --> URI Class Initialized
INFO - 2023-09-25 17:01:59 --> Router Class Initialized
INFO - 2023-09-25 17:01:59 --> Output Class Initialized
INFO - 2023-09-25 17:01:59 --> Security Class Initialized
DEBUG - 2023-09-25 17:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:01:59 --> Input Class Initialized
INFO - 2023-09-25 17:01:59 --> Language Class Initialized
INFO - 2023-09-25 17:01:59 --> Loader Class Initialized
INFO - 2023-09-25 17:01:59 --> Helper loaded: url_helper
INFO - 2023-09-25 17:01:59 --> Helper loaded: file_helper
INFO - 2023-09-25 17:01:59 --> Database Driver Class Initialized
INFO - 2023-09-25 17:01:59 --> Email Class Initialized
DEBUG - 2023-09-25 17:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:01:59 --> Controller Class Initialized
INFO - 2023-09-25 17:01:59 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:01:59 --> Model "Home_model" initialized
INFO - 2023-09-25 17:01:59 --> Helper loaded: download_helper
INFO - 2023-09-25 17:01:59 --> Helper loaded: form_helper
INFO - 2023-09-25 17:01:59 --> Form Validation Class Initialized
INFO - 2023-09-25 17:01:59 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:01:59 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:01:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:01:59 --> Final output sent to browser
DEBUG - 2023-09-25 17:01:59 --> Total execution time: 0.0608
INFO - 2023-09-25 17:02:05 --> Config Class Initialized
INFO - 2023-09-25 17:02:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:05 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:05 --> URI Class Initialized
INFO - 2023-09-25 17:02:05 --> Router Class Initialized
INFO - 2023-09-25 17:02:05 --> Output Class Initialized
INFO - 2023-09-25 17:02:05 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:05 --> Input Class Initialized
INFO - 2023-09-25 17:02:05 --> Language Class Initialized
INFO - 2023-09-25 17:02:05 --> Loader Class Initialized
INFO - 2023-09-25 17:02:05 --> Helper loaded: url_helper
INFO - 2023-09-25 17:02:05 --> Helper loaded: file_helper
INFO - 2023-09-25 17:02:05 --> Database Driver Class Initialized
INFO - 2023-09-25 17:02:05 --> Email Class Initialized
DEBUG - 2023-09-25 17:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:02:05 --> Controller Class Initialized
INFO - 2023-09-25 17:02:05 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:02:05 --> Model "Home_model" initialized
INFO - 2023-09-25 17:02:05 --> Helper loaded: download_helper
INFO - 2023-09-25 17:02:05 --> Helper loaded: form_helper
INFO - 2023-09-25 17:02:05 --> Form Validation Class Initialized
INFO - 2023-09-25 17:02:05 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:02:05 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:02:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:02:05 --> Final output sent to browser
DEBUG - 2023-09-25 17:02:05 --> Total execution time: 0.0817
INFO - 2023-09-25 17:02:37 --> Config Class Initialized
INFO - 2023-09-25 17:02:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:37 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:37 --> URI Class Initialized
INFO - 2023-09-25 17:02:37 --> Router Class Initialized
INFO - 2023-09-25 17:02:37 --> Output Class Initialized
INFO - 2023-09-25 17:02:37 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:37 --> Input Class Initialized
INFO - 2023-09-25 17:02:37 --> Language Class Initialized
INFO - 2023-09-25 17:02:37 --> Config Class Initialized
INFO - 2023-09-25 17:02:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:37 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:37 --> URI Class Initialized
INFO - 2023-09-25 17:02:37 --> Router Class Initialized
INFO - 2023-09-25 17:02:37 --> Output Class Initialized
INFO - 2023-09-25 17:02:37 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:37 --> Input Class Initialized
INFO - 2023-09-25 17:02:37 --> Language Class Initialized
INFO - 2023-09-25 17:02:37 --> Config Class Initialized
INFO - 2023-09-25 17:02:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:37 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:37 --> URI Class Initialized
INFO - 2023-09-25 17:02:37 --> Router Class Initialized
INFO - 2023-09-25 17:02:37 --> Output Class Initialized
INFO - 2023-09-25 17:02:37 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:37 --> Input Class Initialized
INFO - 2023-09-25 17:02:37 --> Language Class Initialized
INFO - 2023-09-25 17:02:38 --> Config Class Initialized
INFO - 2023-09-25 17:02:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:38 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:38 --> URI Class Initialized
INFO - 2023-09-25 17:02:38 --> Router Class Initialized
INFO - 2023-09-25 17:02:38 --> Output Class Initialized
INFO - 2023-09-25 17:02:38 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:38 --> Input Class Initialized
INFO - 2023-09-25 17:02:38 --> Language Class Initialized
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:02:38 --> Config Class Initialized
INFO - 2023-09-25 17:02:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:38 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:38 --> URI Class Initialized
INFO - 2023-09-25 17:02:38 --> Router Class Initialized
INFO - 2023-09-25 17:02:38 --> Output Class Initialized
INFO - 2023-09-25 17:02:38 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:38 --> Input Class Initialized
INFO - 2023-09-25 17:02:38 --> Language Class Initialized
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:02:38 --> Config Class Initialized
INFO - 2023-09-25 17:02:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:38 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:38 --> URI Class Initialized
INFO - 2023-09-25 17:02:38 --> Router Class Initialized
INFO - 2023-09-25 17:02:38 --> Output Class Initialized
INFO - 2023-09-25 17:02:38 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:38 --> Input Class Initialized
INFO - 2023-09-25 17:02:38 --> Language Class Initialized
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:02:38 --> Config Class Initialized
INFO - 2023-09-25 17:02:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:02:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:02:38 --> Utf8 Class Initialized
INFO - 2023-09-25 17:02:38 --> URI Class Initialized
INFO - 2023-09-25 17:02:38 --> Router Class Initialized
INFO - 2023-09-25 17:02:38 --> Output Class Initialized
INFO - 2023-09-25 17:02:38 --> Security Class Initialized
DEBUG - 2023-09-25 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:02:38 --> Input Class Initialized
INFO - 2023-09-25 17:02:38 --> Language Class Initialized
ERROR - 2023-09-25 17:02:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:10 --> Config Class Initialized
INFO - 2023-09-25 17:08:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:10 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:10 --> URI Class Initialized
INFO - 2023-09-25 17:08:10 --> Router Class Initialized
INFO - 2023-09-25 17:08:10 --> Output Class Initialized
INFO - 2023-09-25 17:08:10 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:10 --> Input Class Initialized
INFO - 2023-09-25 17:08:10 --> Language Class Initialized
INFO - 2023-09-25 17:08:10 --> Loader Class Initialized
INFO - 2023-09-25 17:08:10 --> Helper loaded: url_helper
INFO - 2023-09-25 17:08:10 --> Helper loaded: file_helper
INFO - 2023-09-25 17:08:10 --> Database Driver Class Initialized
INFO - 2023-09-25 17:08:10 --> Email Class Initialized
DEBUG - 2023-09-25 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:08:10 --> Controller Class Initialized
INFO - 2023-09-25 17:08:10 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:08:10 --> Model "Home_model" initialized
INFO - 2023-09-25 17:08:10 --> Helper loaded: download_helper
INFO - 2023-09-25 17:08:10 --> Helper loaded: form_helper
INFO - 2023-09-25 17:08:10 --> Form Validation Class Initialized
INFO - 2023-09-25 17:08:10 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:08:10 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:08:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:08:10 --> Final output sent to browser
DEBUG - 2023-09-25 17:08:10 --> Total execution time: 1.1348
INFO - 2023-09-25 17:08:12 --> Config Class Initialized
INFO - 2023-09-25 17:08:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:12 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:12 --> URI Class Initialized
INFO - 2023-09-25 17:08:12 --> Router Class Initialized
INFO - 2023-09-25 17:08:12 --> Output Class Initialized
INFO - 2023-09-25 17:08:12 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:12 --> Input Class Initialized
INFO - 2023-09-25 17:08:12 --> Language Class Initialized
ERROR - 2023-09-25 17:08:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:12 --> Config Class Initialized
INFO - 2023-09-25 17:08:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:12 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:12 --> URI Class Initialized
INFO - 2023-09-25 17:08:12 --> Router Class Initialized
INFO - 2023-09-25 17:08:12 --> Output Class Initialized
INFO - 2023-09-25 17:08:12 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:12 --> Input Class Initialized
INFO - 2023-09-25 17:08:12 --> Language Class Initialized
ERROR - 2023-09-25 17:08:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:13 --> Config Class Initialized
INFO - 2023-09-25 17:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:13 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:13 --> URI Class Initialized
INFO - 2023-09-25 17:08:13 --> Router Class Initialized
INFO - 2023-09-25 17:08:13 --> Output Class Initialized
INFO - 2023-09-25 17:08:13 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:13 --> Input Class Initialized
INFO - 2023-09-25 17:08:13 --> Language Class Initialized
ERROR - 2023-09-25 17:08:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:13 --> Config Class Initialized
INFO - 2023-09-25 17:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:13 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:13 --> URI Class Initialized
INFO - 2023-09-25 17:08:13 --> Router Class Initialized
INFO - 2023-09-25 17:08:13 --> Output Class Initialized
INFO - 2023-09-25 17:08:13 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:13 --> Input Class Initialized
INFO - 2023-09-25 17:08:13 --> Language Class Initialized
ERROR - 2023-09-25 17:08:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:13 --> Config Class Initialized
INFO - 2023-09-25 17:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:13 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:13 --> URI Class Initialized
INFO - 2023-09-25 17:08:13 --> Router Class Initialized
INFO - 2023-09-25 17:08:13 --> Output Class Initialized
INFO - 2023-09-25 17:08:13 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:13 --> Input Class Initialized
INFO - 2023-09-25 17:08:13 --> Language Class Initialized
ERROR - 2023-09-25 17:08:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:14 --> Config Class Initialized
INFO - 2023-09-25 17:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:14 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:14 --> URI Class Initialized
INFO - 2023-09-25 17:08:14 --> Router Class Initialized
INFO - 2023-09-25 17:08:14 --> Output Class Initialized
INFO - 2023-09-25 17:08:14 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:14 --> Input Class Initialized
INFO - 2023-09-25 17:08:14 --> Language Class Initialized
ERROR - 2023-09-25 17:08:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:08:14 --> Config Class Initialized
INFO - 2023-09-25 17:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:08:14 --> Utf8 Class Initialized
INFO - 2023-09-25 17:08:14 --> URI Class Initialized
INFO - 2023-09-25 17:08:14 --> Router Class Initialized
INFO - 2023-09-25 17:08:14 --> Output Class Initialized
INFO - 2023-09-25 17:08:14 --> Security Class Initialized
DEBUG - 2023-09-25 17:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:08:14 --> Input Class Initialized
INFO - 2023-09-25 17:08:14 --> Language Class Initialized
ERROR - 2023-09-25 17:08:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:47 --> Config Class Initialized
INFO - 2023-09-25 17:22:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:47 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:47 --> URI Class Initialized
INFO - 2023-09-25 17:22:47 --> Router Class Initialized
INFO - 2023-09-25 17:22:47 --> Output Class Initialized
INFO - 2023-09-25 17:22:47 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:47 --> Input Class Initialized
INFO - 2023-09-25 17:22:47 --> Language Class Initialized
INFO - 2023-09-25 17:22:47 --> Loader Class Initialized
INFO - 2023-09-25 17:22:47 --> Helper loaded: url_helper
INFO - 2023-09-25 17:22:47 --> Helper loaded: file_helper
INFO - 2023-09-25 17:22:47 --> Database Driver Class Initialized
INFO - 2023-09-25 17:22:47 --> Email Class Initialized
DEBUG - 2023-09-25 17:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 17:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 17:22:47 --> Controller Class Initialized
INFO - 2023-09-25 17:22:47 --> Model "Contact_model" initialized
INFO - 2023-09-25 17:22:48 --> Model "Home_model" initialized
INFO - 2023-09-25 17:22:48 --> Helper loaded: download_helper
INFO - 2023-09-25 17:22:48 --> Helper loaded: form_helper
INFO - 2023-09-25 17:22:48 --> Form Validation Class Initialized
INFO - 2023-09-25 17:22:48 --> Helper loaded: custom_helper
INFO - 2023-09-25 17:22:48 --> Model "Social_media_model" initialized
INFO - 2023-09-25 17:22:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 17:22:48 --> Final output sent to browser
DEBUG - 2023-09-25 17:22:48 --> Total execution time: 0.9936
INFO - 2023-09-25 17:22:51 --> Config Class Initialized
INFO - 2023-09-25 17:22:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:51 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:51 --> URI Class Initialized
INFO - 2023-09-25 17:22:51 --> Router Class Initialized
INFO - 2023-09-25 17:22:51 --> Output Class Initialized
INFO - 2023-09-25 17:22:51 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:51 --> Input Class Initialized
INFO - 2023-09-25 17:22:51 --> Language Class Initialized
ERROR - 2023-09-25 17:22:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:52 --> Config Class Initialized
INFO - 2023-09-25 17:22:52 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:52 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:52 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:52 --> URI Class Initialized
INFO - 2023-09-25 17:22:52 --> Router Class Initialized
INFO - 2023-09-25 17:22:52 --> Output Class Initialized
INFO - 2023-09-25 17:22:52 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:52 --> Input Class Initialized
INFO - 2023-09-25 17:22:52 --> Language Class Initialized
ERROR - 2023-09-25 17:22:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:53 --> Config Class Initialized
INFO - 2023-09-25 17:22:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:53 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:53 --> URI Class Initialized
INFO - 2023-09-25 17:22:53 --> Router Class Initialized
INFO - 2023-09-25 17:22:53 --> Output Class Initialized
INFO - 2023-09-25 17:22:53 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:53 --> Input Class Initialized
INFO - 2023-09-25 17:22:53 --> Language Class Initialized
ERROR - 2023-09-25 17:22:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:53 --> Config Class Initialized
INFO - 2023-09-25 17:22:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:53 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:53 --> URI Class Initialized
INFO - 2023-09-25 17:22:53 --> Router Class Initialized
INFO - 2023-09-25 17:22:53 --> Output Class Initialized
INFO - 2023-09-25 17:22:53 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:53 --> Input Class Initialized
INFO - 2023-09-25 17:22:53 --> Language Class Initialized
ERROR - 2023-09-25 17:22:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:55 --> Config Class Initialized
INFO - 2023-09-25 17:22:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:55 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:55 --> URI Class Initialized
INFO - 2023-09-25 17:22:55 --> Router Class Initialized
INFO - 2023-09-25 17:22:55 --> Output Class Initialized
INFO - 2023-09-25 17:22:55 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:55 --> Input Class Initialized
INFO - 2023-09-25 17:22:55 --> Language Class Initialized
ERROR - 2023-09-25 17:22:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:55 --> Config Class Initialized
INFO - 2023-09-25 17:22:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:55 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:55 --> URI Class Initialized
INFO - 2023-09-25 17:22:55 --> Router Class Initialized
INFO - 2023-09-25 17:22:55 --> Output Class Initialized
INFO - 2023-09-25 17:22:55 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:55 --> Input Class Initialized
INFO - 2023-09-25 17:22:55 --> Language Class Initialized
ERROR - 2023-09-25 17:22:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 17:22:55 --> Config Class Initialized
INFO - 2023-09-25 17:22:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 17:22:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 17:22:55 --> Utf8 Class Initialized
INFO - 2023-09-25 17:22:55 --> URI Class Initialized
INFO - 2023-09-25 17:22:55 --> Router Class Initialized
INFO - 2023-09-25 17:22:55 --> Output Class Initialized
INFO - 2023-09-25 17:22:55 --> Security Class Initialized
DEBUG - 2023-09-25 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 17:22:55 --> Input Class Initialized
INFO - 2023-09-25 17:22:55 --> Language Class Initialized
ERROR - 2023-09-25 17:22:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-25 19:48:04 --> Config Class Initialized
INFO - 2023-09-25 19:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:48:04 --> Utf8 Class Initialized
INFO - 2023-09-25 19:48:04 --> URI Class Initialized
DEBUG - 2023-09-25 19:48:04 --> No URI present. Default controller set.
INFO - 2023-09-25 19:48:04 --> Router Class Initialized
INFO - 2023-09-25 19:48:04 --> Output Class Initialized
INFO - 2023-09-25 19:48:04 --> Security Class Initialized
DEBUG - 2023-09-25 19:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:48:04 --> Input Class Initialized
INFO - 2023-09-25 19:48:04 --> Language Class Initialized
INFO - 2023-09-25 19:48:04 --> Loader Class Initialized
INFO - 2023-09-25 19:48:04 --> Helper loaded: url_helper
INFO - 2023-09-25 19:48:04 --> Helper loaded: file_helper
INFO - 2023-09-25 19:48:04 --> Database Driver Class Initialized
INFO - 2023-09-25 19:48:04 --> Email Class Initialized
DEBUG - 2023-09-25 19:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:48:04 --> Controller Class Initialized
INFO - 2023-09-25 19:48:04 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:48:04 --> Model "Home_model" initialized
INFO - 2023-09-25 19:48:04 --> Helper loaded: download_helper
INFO - 2023-09-25 19:48:04 --> Helper loaded: form_helper
INFO - 2023-09-25 19:48:04 --> Form Validation Class Initialized
INFO - 2023-09-25 19:48:04 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:48:04 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:48:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-25 19:48:04 --> Final output sent to browser
DEBUG - 2023-09-25 19:48:04 --> Total execution time: 0.0550
INFO - 2023-09-25 19:48:11 --> Config Class Initialized
INFO - 2023-09-25 19:48:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:48:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:48:12 --> Utf8 Class Initialized
INFO - 2023-09-25 19:48:12 --> URI Class Initialized
INFO - 2023-09-25 19:48:12 --> Router Class Initialized
INFO - 2023-09-25 19:48:12 --> Output Class Initialized
INFO - 2023-09-25 19:48:12 --> Security Class Initialized
DEBUG - 2023-09-25 19:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:48:12 --> Input Class Initialized
INFO - 2023-09-25 19:48:12 --> Language Class Initialized
INFO - 2023-09-25 19:48:12 --> Loader Class Initialized
INFO - 2023-09-25 19:48:12 --> Helper loaded: url_helper
INFO - 2023-09-25 19:48:12 --> Helper loaded: file_helper
INFO - 2023-09-25 19:48:12 --> Database Driver Class Initialized
INFO - 2023-09-25 19:48:12 --> Email Class Initialized
DEBUG - 2023-09-25 19:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:48:12 --> Controller Class Initialized
INFO - 2023-09-25 19:48:12 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:48:12 --> Model "Home_model" initialized
INFO - 2023-09-25 19:48:12 --> Helper loaded: download_helper
INFO - 2023-09-25 19:48:12 --> Helper loaded: form_helper
INFO - 2023-09-25 19:48:12 --> Form Validation Class Initialized
INFO - 2023-09-25 19:48:12 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:48:12 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:48:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-25 19:48:12 --> Final output sent to browser
DEBUG - 2023-09-25 19:48:12 --> Total execution time: 0.0986
INFO - 2023-09-25 19:48:15 --> Config Class Initialized
INFO - 2023-09-25 19:48:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:48:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:48:15 --> Utf8 Class Initialized
INFO - 2023-09-25 19:48:15 --> URI Class Initialized
INFO - 2023-09-25 19:48:15 --> Router Class Initialized
INFO - 2023-09-25 19:48:15 --> Output Class Initialized
INFO - 2023-09-25 19:48:15 --> Security Class Initialized
DEBUG - 2023-09-25 19:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:48:15 --> Input Class Initialized
INFO - 2023-09-25 19:48:15 --> Language Class Initialized
INFO - 2023-09-25 19:48:15 --> Loader Class Initialized
INFO - 2023-09-25 19:48:15 --> Helper loaded: url_helper
INFO - 2023-09-25 19:48:15 --> Helper loaded: file_helper
INFO - 2023-09-25 19:48:15 --> Database Driver Class Initialized
INFO - 2023-09-25 19:48:15 --> Email Class Initialized
DEBUG - 2023-09-25 19:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:48:15 --> Controller Class Initialized
INFO - 2023-09-25 19:48:15 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:48:15 --> Model "Home_model" initialized
INFO - 2023-09-25 19:48:15 --> Helper loaded: download_helper
INFO - 2023-09-25 19:48:15 --> Helper loaded: form_helper
INFO - 2023-09-25 19:48:15 --> Form Validation Class Initialized
INFO - 2023-09-25 19:48:15 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:48:15 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:48:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 19:48:15 --> Final output sent to browser
DEBUG - 2023-09-25 19:48:15 --> Total execution time: 0.0900
INFO - 2023-09-25 19:48:22 --> Config Class Initialized
INFO - 2023-09-25 19:48:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:48:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:48:22 --> Utf8 Class Initialized
INFO - 2023-09-25 19:48:22 --> URI Class Initialized
INFO - 2023-09-25 19:48:22 --> Router Class Initialized
INFO - 2023-09-25 19:48:22 --> Output Class Initialized
INFO - 2023-09-25 19:48:22 --> Security Class Initialized
DEBUG - 2023-09-25 19:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:48:22 --> Input Class Initialized
INFO - 2023-09-25 19:48:22 --> Language Class Initialized
INFO - 2023-09-25 19:48:22 --> Loader Class Initialized
INFO - 2023-09-25 19:48:22 --> Helper loaded: url_helper
INFO - 2023-09-25 19:48:22 --> Helper loaded: file_helper
INFO - 2023-09-25 19:48:22 --> Database Driver Class Initialized
INFO - 2023-09-25 19:48:22 --> Email Class Initialized
DEBUG - 2023-09-25 19:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:48:22 --> Controller Class Initialized
INFO - 2023-09-25 19:48:22 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:48:22 --> Model "Home_model" initialized
INFO - 2023-09-25 19:48:22 --> Helper loaded: download_helper
INFO - 2023-09-25 19:48:22 --> Helper loaded: form_helper
INFO - 2023-09-25 19:48:22 --> Form Validation Class Initialized
INFO - 2023-09-25 19:48:22 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:48:22 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:48:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 19:48:22 --> Final output sent to browser
DEBUG - 2023-09-25 19:48:22 --> Total execution time: 0.0680
INFO - 2023-09-25 19:48:39 --> Config Class Initialized
INFO - 2023-09-25 19:48:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:48:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:48:39 --> Utf8 Class Initialized
INFO - 2023-09-25 19:48:39 --> URI Class Initialized
INFO - 2023-09-25 19:48:39 --> Router Class Initialized
INFO - 2023-09-25 19:48:39 --> Output Class Initialized
INFO - 2023-09-25 19:48:39 --> Security Class Initialized
DEBUG - 2023-09-25 19:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:48:39 --> Input Class Initialized
INFO - 2023-09-25 19:48:39 --> Language Class Initialized
INFO - 2023-09-25 19:48:39 --> Loader Class Initialized
INFO - 2023-09-25 19:48:39 --> Helper loaded: url_helper
INFO - 2023-09-25 19:48:39 --> Helper loaded: file_helper
INFO - 2023-09-25 19:48:39 --> Database Driver Class Initialized
INFO - 2023-09-25 19:48:39 --> Email Class Initialized
DEBUG - 2023-09-25 19:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:48:39 --> Controller Class Initialized
INFO - 2023-09-25 19:48:39 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:48:39 --> Model "Home_model" initialized
INFO - 2023-09-25 19:48:39 --> Helper loaded: download_helper
INFO - 2023-09-25 19:48:39 --> Helper loaded: form_helper
INFO - 2023-09-25 19:48:39 --> Form Validation Class Initialized
INFO - 2023-09-25 19:48:39 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:48:39 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:48:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 19:48:39 --> Final output sent to browser
DEBUG - 2023-09-25 19:48:39 --> Total execution time: 0.2840
INFO - 2023-09-25 19:49:11 --> Config Class Initialized
INFO - 2023-09-25 19:49:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 19:49:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 19:49:11 --> Utf8 Class Initialized
INFO - 2023-09-25 19:49:11 --> URI Class Initialized
INFO - 2023-09-25 19:49:11 --> Router Class Initialized
INFO - 2023-09-25 19:49:11 --> Output Class Initialized
INFO - 2023-09-25 19:49:11 --> Security Class Initialized
DEBUG - 2023-09-25 19:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 19:49:11 --> Input Class Initialized
INFO - 2023-09-25 19:49:11 --> Language Class Initialized
INFO - 2023-09-25 19:49:11 --> Loader Class Initialized
INFO - 2023-09-25 19:49:11 --> Helper loaded: url_helper
INFO - 2023-09-25 19:49:11 --> Helper loaded: file_helper
INFO - 2023-09-25 19:49:11 --> Database Driver Class Initialized
INFO - 2023-09-25 19:49:11 --> Email Class Initialized
DEBUG - 2023-09-25 19:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-25 19:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 19:49:11 --> Controller Class Initialized
INFO - 2023-09-25 19:49:11 --> Model "Contact_model" initialized
INFO - 2023-09-25 19:49:11 --> Model "Home_model" initialized
INFO - 2023-09-25 19:49:11 --> Helper loaded: download_helper
INFO - 2023-09-25 19:49:11 --> Helper loaded: form_helper
INFO - 2023-09-25 19:49:11 --> Form Validation Class Initialized
INFO - 2023-09-25 19:49:11 --> Helper loaded: custom_helper
INFO - 2023-09-25 19:49:11 --> Model "Social_media_model" initialized
INFO - 2023-09-25 19:49:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-25 19:49:11 --> Final output sent to browser
DEBUG - 2023-09-25 19:49:11 --> Total execution time: 0.0971
