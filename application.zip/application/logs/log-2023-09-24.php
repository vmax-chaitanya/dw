<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-24 09:59:26 --> Config Class Initialized
INFO - 2023-09-24 09:59:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 09:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 09:59:26 --> Utf8 Class Initialized
INFO - 2023-09-24 09:59:26 --> URI Class Initialized
DEBUG - 2023-09-24 09:59:27 --> No URI present. Default controller set.
INFO - 2023-09-24 09:59:27 --> Router Class Initialized
INFO - 2023-09-24 09:59:27 --> Output Class Initialized
INFO - 2023-09-24 09:59:27 --> Security Class Initialized
DEBUG - 2023-09-24 09:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 09:59:27 --> Input Class Initialized
INFO - 2023-09-24 09:59:27 --> Language Class Initialized
INFO - 2023-09-24 09:59:27 --> Loader Class Initialized
INFO - 2023-09-24 09:59:27 --> Helper loaded: url_helper
INFO - 2023-09-24 09:59:27 --> Helper loaded: file_helper
INFO - 2023-09-24 09:59:27 --> Database Driver Class Initialized
INFO - 2023-09-24 09:59:27 --> Email Class Initialized
DEBUG - 2023-09-24 09:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 09:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 09:59:27 --> Controller Class Initialized
INFO - 2023-09-24 09:59:27 --> Model "Contact_model" initialized
INFO - 2023-09-24 09:59:27 --> Model "Home_model" initialized
INFO - 2023-09-24 09:59:27 --> Helper loaded: download_helper
INFO - 2023-09-24 09:59:27 --> Helper loaded: form_helper
INFO - 2023-09-24 09:59:27 --> Form Validation Class Initialized
INFO - 2023-09-24 09:59:27 --> Helper loaded: custom_helper
INFO - 2023-09-24 09:59:27 --> Model "Social_media_model" initialized
INFO - 2023-09-24 09:59:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-24 09:59:27 --> Final output sent to browser
DEBUG - 2023-09-24 09:59:27 --> Total execution time: 0.4554
INFO - 2023-09-24 10:00:45 --> Config Class Initialized
INFO - 2023-09-24 10:00:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:00:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:00:54 --> Utf8 Class Initialized
INFO - 2023-09-24 10:00:54 --> URI Class Initialized
DEBUG - 2023-09-24 10:00:55 --> No URI present. Default controller set.
INFO - 2023-09-24 10:00:55 --> Router Class Initialized
INFO - 2023-09-24 10:00:57 --> Output Class Initialized
INFO - 2023-09-24 10:01:07 --> Security Class Initialized
DEBUG - 2023-09-24 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:01:08 --> Input Class Initialized
INFO - 2023-09-24 10:01:09 --> Language Class Initialized
INFO - 2023-09-24 10:01:10 --> Loader Class Initialized
INFO - 2023-09-24 10:01:10 --> Helper loaded: url_helper
INFO - 2023-09-24 10:01:10 --> Helper loaded: file_helper
INFO - 2023-09-24 10:01:11 --> Database Driver Class Initialized
INFO - 2023-09-24 10:01:11 --> Email Class Initialized
DEBUG - 2023-09-24 10:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:01:11 --> Controller Class Initialized
INFO - 2023-09-24 10:01:11 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:01:11 --> Model "Home_model" initialized
INFO - 2023-09-24 10:01:11 --> Helper loaded: download_helper
INFO - 2023-09-24 10:01:11 --> Helper loaded: form_helper
INFO - 2023-09-24 10:01:11 --> Form Validation Class Initialized
INFO - 2023-09-24 10:01:11 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:01:11 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:01:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-24 10:01:11 --> Final output sent to browser
DEBUG - 2023-09-24 10:01:11 --> Total execution time: 29.1134
INFO - 2023-09-24 10:02:20 --> Config Class Initialized
INFO - 2023-09-24 10:02:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:02:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:02:20 --> Utf8 Class Initialized
INFO - 2023-09-24 10:02:20 --> URI Class Initialized
INFO - 2023-09-24 10:02:20 --> Router Class Initialized
INFO - 2023-09-24 10:02:20 --> Output Class Initialized
INFO - 2023-09-24 10:02:20 --> Security Class Initialized
DEBUG - 2023-09-24 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:02:20 --> Input Class Initialized
INFO - 2023-09-24 10:02:20 --> Language Class Initialized
INFO - 2023-09-24 10:02:20 --> Loader Class Initialized
INFO - 2023-09-24 10:02:20 --> Helper loaded: url_helper
INFO - 2023-09-24 10:02:20 --> Helper loaded: file_helper
INFO - 2023-09-24 10:02:20 --> Database Driver Class Initialized
INFO - 2023-09-24 10:02:20 --> Email Class Initialized
DEBUG - 2023-09-24 10:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:02:20 --> Controller Class Initialized
INFO - 2023-09-24 10:02:20 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:02:20 --> Model "Home_model" initialized
INFO - 2023-09-24 10:02:20 --> Helper loaded: download_helper
INFO - 2023-09-24 10:02:20 --> Helper loaded: form_helper
INFO - 2023-09-24 10:02:20 --> Form Validation Class Initialized
INFO - 2023-09-24 10:02:20 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:02:20 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:02:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-24 10:02:20 --> Final output sent to browser
DEBUG - 2023-09-24 10:02:20 --> Total execution time: 0.1640
INFO - 2023-09-24 10:02:36 --> Config Class Initialized
INFO - 2023-09-24 10:02:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:02:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:02:36 --> Utf8 Class Initialized
INFO - 2023-09-24 10:02:36 --> URI Class Initialized
INFO - 2023-09-24 10:02:36 --> Router Class Initialized
INFO - 2023-09-24 10:02:36 --> Output Class Initialized
INFO - 2023-09-24 10:02:36 --> Security Class Initialized
DEBUG - 2023-09-24 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:02:36 --> Input Class Initialized
INFO - 2023-09-24 10:02:36 --> Language Class Initialized
INFO - 2023-09-24 10:02:36 --> Loader Class Initialized
INFO - 2023-09-24 10:02:36 --> Helper loaded: url_helper
INFO - 2023-09-24 10:02:36 --> Helper loaded: file_helper
INFO - 2023-09-24 10:02:36 --> Database Driver Class Initialized
INFO - 2023-09-24 10:02:36 --> Email Class Initialized
DEBUG - 2023-09-24 10:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:02:36 --> Controller Class Initialized
INFO - 2023-09-24 10:02:36 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:02:36 --> Model "Home_model" initialized
INFO - 2023-09-24 10:02:36 --> Helper loaded: download_helper
INFO - 2023-09-24 10:02:37 --> Helper loaded: form_helper
INFO - 2023-09-24 10:02:37 --> Form Validation Class Initialized
INFO - 2023-09-24 10:02:38 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:02:38 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:02:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-24 10:02:38 --> Final output sent to browser
DEBUG - 2023-09-24 10:02:38 --> Total execution time: 1.6253
INFO - 2023-09-24 10:09:52 --> Config Class Initialized
INFO - 2023-09-24 10:09:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:09:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:09:52 --> Utf8 Class Initialized
INFO - 2023-09-24 10:09:52 --> URI Class Initialized
INFO - 2023-09-24 10:09:52 --> Router Class Initialized
INFO - 2023-09-24 10:09:53 --> Output Class Initialized
INFO - 2023-09-24 10:09:53 --> Security Class Initialized
DEBUG - 2023-09-24 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:09:53 --> Input Class Initialized
INFO - 2023-09-24 10:09:53 --> Language Class Initialized
INFO - 2023-09-24 10:09:53 --> Loader Class Initialized
INFO - 2023-09-24 10:09:53 --> Helper loaded: url_helper
INFO - 2023-09-24 10:09:53 --> Helper loaded: file_helper
INFO - 2023-09-24 10:09:53 --> Database Driver Class Initialized
INFO - 2023-09-24 10:09:53 --> Email Class Initialized
DEBUG - 2023-09-24 10:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:09:53 --> Controller Class Initialized
INFO - 2023-09-24 10:09:53 --> Model "User_model" initialized
INFO - 2023-09-24 10:09:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-24 10:09:53 --> Final output sent to browser
DEBUG - 2023-09-24 10:09:53 --> Total execution time: 0.9854
INFO - 2023-09-24 10:09:55 --> Config Class Initialized
INFO - 2023-09-24 10:09:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:09:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:09:55 --> Utf8 Class Initialized
INFO - 2023-09-24 10:09:55 --> URI Class Initialized
INFO - 2023-09-24 10:09:55 --> Router Class Initialized
INFO - 2023-09-24 10:09:55 --> Output Class Initialized
INFO - 2023-09-24 10:09:55 --> Security Class Initialized
DEBUG - 2023-09-24 10:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:09:55 --> Input Class Initialized
INFO - 2023-09-24 10:09:55 --> Language Class Initialized
ERROR - 2023-09-24 10:09:55 --> 404 Page Not Found: admin/Login/images
INFO - 2023-09-24 10:10:02 --> Config Class Initialized
INFO - 2023-09-24 10:10:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:02 --> URI Class Initialized
INFO - 2023-09-24 10:10:02 --> Router Class Initialized
INFO - 2023-09-24 10:10:02 --> Output Class Initialized
INFO - 2023-09-24 10:10:02 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:02 --> Input Class Initialized
INFO - 2023-09-24 10:10:02 --> Language Class Initialized
INFO - 2023-09-24 10:10:02 --> Loader Class Initialized
INFO - 2023-09-24 10:10:02 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:02 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:02 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:02 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:02 --> Controller Class Initialized
INFO - 2023-09-24 10:10:02 --> Model "User_model" initialized
INFO - 2023-09-24 10:10:02 --> Config Class Initialized
INFO - 2023-09-24 10:10:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:02 --> URI Class Initialized
INFO - 2023-09-24 10:10:02 --> Router Class Initialized
INFO - 2023-09-24 10:10:02 --> Output Class Initialized
INFO - 2023-09-24 10:10:02 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:02 --> Input Class Initialized
INFO - 2023-09-24 10:10:02 --> Language Class Initialized
INFO - 2023-09-24 10:10:02 --> Loader Class Initialized
INFO - 2023-09-24 10:10:02 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:02 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:02 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:02 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:02 --> Controller Class Initialized
INFO - 2023-09-24 10:10:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-24 10:10:02 --> Final output sent to browser
DEBUG - 2023-09-24 10:10:02 --> Total execution time: 0.1204
INFO - 2023-09-24 10:10:03 --> Config Class Initialized
INFO - 2023-09-24 10:10:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:03 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:03 --> URI Class Initialized
INFO - 2023-09-24 10:10:03 --> Router Class Initialized
INFO - 2023-09-24 10:10:03 --> Output Class Initialized
INFO - 2023-09-24 10:10:03 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:03 --> Input Class Initialized
INFO - 2023-09-24 10:10:03 --> Language Class Initialized
ERROR - 2023-09-24 10:10:03 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-24 10:10:08 --> Config Class Initialized
INFO - 2023-09-24 10:10:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:08 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:08 --> URI Class Initialized
INFO - 2023-09-24 10:10:08 --> Router Class Initialized
INFO - 2023-09-24 10:10:08 --> Output Class Initialized
INFO - 2023-09-24 10:10:08 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:08 --> Input Class Initialized
INFO - 2023-09-24 10:10:08 --> Language Class Initialized
INFO - 2023-09-24 10:10:08 --> Loader Class Initialized
INFO - 2023-09-24 10:10:08 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:08 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:08 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:08 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:08 --> Controller Class Initialized
INFO - 2023-09-24 10:10:08 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:10:08 --> Helper loaded: form_helper
INFO - 2023-09-24 10:10:08 --> Form Validation Class Initialized
INFO - 2023-09-24 10:10:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-24 10:10:08 --> Final output sent to browser
DEBUG - 2023-09-24 10:10:08 --> Total execution time: 0.0550
INFO - 2023-09-24 10:10:10 --> Config Class Initialized
INFO - 2023-09-24 10:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:10 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:10 --> URI Class Initialized
INFO - 2023-09-24 10:10:10 --> Router Class Initialized
INFO - 2023-09-24 10:10:10 --> Output Class Initialized
INFO - 2023-09-24 10:10:10 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:10 --> Input Class Initialized
INFO - 2023-09-24 10:10:10 --> Language Class Initialized
ERROR - 2023-09-24 10:10:10 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-24 10:10:49 --> Config Class Initialized
INFO - 2023-09-24 10:10:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:49 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:49 --> URI Class Initialized
INFO - 2023-09-24 10:10:49 --> Router Class Initialized
INFO - 2023-09-24 10:10:49 --> Output Class Initialized
INFO - 2023-09-24 10:10:49 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:49 --> Input Class Initialized
INFO - 2023-09-24 10:10:49 --> Language Class Initialized
INFO - 2023-09-24 10:10:49 --> Loader Class Initialized
INFO - 2023-09-24 10:10:49 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:49 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:49 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:49 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:49 --> Controller Class Initialized
INFO - 2023-09-24 10:10:49 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:10:49 --> Helper loaded: form_helper
INFO - 2023-09-24 10:10:49 --> Form Validation Class Initialized
INFO - 2023-09-24 10:10:49 --> Config Class Initialized
INFO - 2023-09-24 10:10:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:49 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:49 --> URI Class Initialized
INFO - 2023-09-24 10:10:49 --> Router Class Initialized
INFO - 2023-09-24 10:10:49 --> Output Class Initialized
INFO - 2023-09-24 10:10:49 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:49 --> Input Class Initialized
INFO - 2023-09-24 10:10:49 --> Language Class Initialized
INFO - 2023-09-24 10:10:49 --> Loader Class Initialized
INFO - 2023-09-24 10:10:49 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:49 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:49 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:49 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:49 --> Controller Class Initialized
INFO - 2023-09-24 10:10:49 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:10:49 --> Helper loaded: form_helper
INFO - 2023-09-24 10:10:49 --> Form Validation Class Initialized
INFO - 2023-09-24 10:10:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-24 10:10:49 --> Final output sent to browser
DEBUG - 2023-09-24 10:10:49 --> Total execution time: 0.0690
INFO - 2023-09-24 10:10:54 --> Config Class Initialized
INFO - 2023-09-24 10:10:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:10:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:10:54 --> Utf8 Class Initialized
INFO - 2023-09-24 10:10:54 --> URI Class Initialized
INFO - 2023-09-24 10:10:54 --> Router Class Initialized
INFO - 2023-09-24 10:10:54 --> Output Class Initialized
INFO - 2023-09-24 10:10:54 --> Security Class Initialized
DEBUG - 2023-09-24 10:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:10:54 --> Input Class Initialized
INFO - 2023-09-24 10:10:54 --> Language Class Initialized
INFO - 2023-09-24 10:10:54 --> Loader Class Initialized
INFO - 2023-09-24 10:10:54 --> Helper loaded: url_helper
INFO - 2023-09-24 10:10:54 --> Helper loaded: file_helper
INFO - 2023-09-24 10:10:54 --> Database Driver Class Initialized
INFO - 2023-09-24 10:10:54 --> Email Class Initialized
DEBUG - 2023-09-24 10:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:10:54 --> Controller Class Initialized
INFO - 2023-09-24 10:10:54 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:10:54 --> Model "Home_model" initialized
INFO - 2023-09-24 10:10:54 --> Helper loaded: download_helper
INFO - 2023-09-24 10:10:54 --> Helper loaded: form_helper
INFO - 2023-09-24 10:10:54 --> Form Validation Class Initialized
INFO - 2023-09-24 10:10:54 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:10:54 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:10:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-24 10:10:54 --> Final output sent to browser
DEBUG - 2023-09-24 10:10:54 --> Total execution time: 0.2854
INFO - 2023-09-24 10:11:38 --> Config Class Initialized
INFO - 2023-09-24 10:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:11:38 --> Utf8 Class Initialized
INFO - 2023-09-24 10:11:38 --> URI Class Initialized
INFO - 2023-09-24 10:11:39 --> Router Class Initialized
INFO - 2023-09-24 10:11:39 --> Output Class Initialized
INFO - 2023-09-24 10:11:39 --> Security Class Initialized
DEBUG - 2023-09-24 10:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:11:39 --> Input Class Initialized
INFO - 2023-09-24 10:11:39 --> Language Class Initialized
INFO - 2023-09-24 10:11:39 --> Loader Class Initialized
INFO - 2023-09-24 10:11:39 --> Helper loaded: url_helper
INFO - 2023-09-24 10:11:39 --> Helper loaded: file_helper
INFO - 2023-09-24 10:11:39 --> Database Driver Class Initialized
INFO - 2023-09-24 10:11:39 --> Email Class Initialized
DEBUG - 2023-09-24 10:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:11:40 --> Controller Class Initialized
INFO - 2023-09-24 10:11:40 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:11:40 --> Model "Home_model" initialized
INFO - 2023-09-24 10:11:40 --> Helper loaded: download_helper
INFO - 2023-09-24 10:11:40 --> Helper loaded: form_helper
INFO - 2023-09-24 10:11:40 --> Form Validation Class Initialized
INFO - 2023-09-24 10:11:40 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:11:40 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:11:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-24 10:11:40 --> Final output sent to browser
DEBUG - 2023-09-24 10:11:40 --> Total execution time: 2.1506
INFO - 2023-09-24 10:12:48 --> Config Class Initialized
INFO - 2023-09-24 10:12:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:12:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:12:49 --> Utf8 Class Initialized
INFO - 2023-09-24 10:12:49 --> URI Class Initialized
INFO - 2023-09-24 10:12:49 --> Router Class Initialized
INFO - 2023-09-24 10:12:49 --> Output Class Initialized
INFO - 2023-09-24 10:12:49 --> Security Class Initialized
DEBUG - 2023-09-24 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:12:49 --> Input Class Initialized
INFO - 2023-09-24 10:12:49 --> Language Class Initialized
INFO - 2023-09-24 10:12:49 --> Loader Class Initialized
INFO - 2023-09-24 10:12:50 --> Helper loaded: url_helper
INFO - 2023-09-24 10:12:50 --> Helper loaded: file_helper
INFO - 2023-09-24 10:12:50 --> Database Driver Class Initialized
INFO - 2023-09-24 10:12:50 --> Email Class Initialized
DEBUG - 2023-09-24 10:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:12:50 --> Controller Class Initialized
INFO - 2023-09-24 10:12:50 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:12:50 --> Model "Home_model" initialized
INFO - 2023-09-24 10:12:50 --> Helper loaded: download_helper
INFO - 2023-09-24 10:12:50 --> Helper loaded: form_helper
INFO - 2023-09-24 10:12:50 --> Form Validation Class Initialized
INFO - 2023-09-24 10:12:51 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:12:51 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:12:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-24 10:12:51 --> Final output sent to browser
DEBUG - 2023-09-24 10:12:51 --> Total execution time: 3.1503
INFO - 2023-09-24 10:12:59 --> Config Class Initialized
INFO - 2023-09-24 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:12:59 --> Utf8 Class Initialized
INFO - 2023-09-24 10:12:59 --> URI Class Initialized
INFO - 2023-09-24 10:13:00 --> Router Class Initialized
INFO - 2023-09-24 10:13:00 --> Output Class Initialized
INFO - 2023-09-24 10:13:00 --> Security Class Initialized
DEBUG - 2023-09-24 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:13:00 --> Input Class Initialized
INFO - 2023-09-24 10:13:00 --> Language Class Initialized
INFO - 2023-09-24 10:13:00 --> Loader Class Initialized
INFO - 2023-09-24 10:13:00 --> Helper loaded: url_helper
INFO - 2023-09-24 10:13:00 --> Helper loaded: file_helper
INFO - 2023-09-24 10:13:00 --> Database Driver Class Initialized
INFO - 2023-09-24 10:13:00 --> Email Class Initialized
DEBUG - 2023-09-24 10:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:13:00 --> Controller Class Initialized
INFO - 2023-09-24 10:13:01 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:13:01 --> Model "Home_model" initialized
INFO - 2023-09-24 10:13:01 --> Helper loaded: download_helper
INFO - 2023-09-24 10:13:01 --> Helper loaded: form_helper
INFO - 2023-09-24 10:13:01 --> Form Validation Class Initialized
INFO - 2023-09-24 10:13:01 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:13:01 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:13:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-24 10:13:01 --> Final output sent to browser
DEBUG - 2023-09-24 10:13:02 --> Total execution time: 2.3501
INFO - 2023-09-24 10:13:57 --> Config Class Initialized
INFO - 2023-09-24 10:13:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:13:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:13:57 --> Utf8 Class Initialized
INFO - 2023-09-24 10:13:57 --> URI Class Initialized
INFO - 2023-09-24 10:13:58 --> Router Class Initialized
INFO - 2023-09-24 10:13:58 --> Output Class Initialized
INFO - 2023-09-24 10:13:58 --> Security Class Initialized
DEBUG - 2023-09-24 10:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:13:58 --> Input Class Initialized
INFO - 2023-09-24 10:13:58 --> Language Class Initialized
INFO - 2023-09-24 10:13:58 --> Loader Class Initialized
INFO - 2023-09-24 10:13:58 --> Helper loaded: url_helper
INFO - 2023-09-24 10:13:58 --> Helper loaded: file_helper
INFO - 2023-09-24 10:13:58 --> Database Driver Class Initialized
INFO - 2023-09-24 10:13:58 --> Email Class Initialized
DEBUG - 2023-09-24 10:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:13:59 --> Controller Class Initialized
INFO - 2023-09-24 10:13:59 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:13:59 --> Model "Home_model" initialized
INFO - 2023-09-24 10:13:59 --> Helper loaded: download_helper
INFO - 2023-09-24 10:13:59 --> Helper loaded: form_helper
INFO - 2023-09-24 10:13:59 --> Form Validation Class Initialized
INFO - 2023-09-24 10:17:02 --> Config Class Initialized
INFO - 2023-09-24 10:17:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:17:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:17:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:17:02 --> URI Class Initialized
INFO - 2023-09-24 10:17:02 --> Router Class Initialized
INFO - 2023-09-24 10:17:03 --> Output Class Initialized
INFO - 2023-09-24 10:17:03 --> Security Class Initialized
DEBUG - 2023-09-24 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:17:03 --> Input Class Initialized
INFO - 2023-09-24 10:17:03 --> Language Class Initialized
INFO - 2023-09-24 10:17:03 --> Loader Class Initialized
INFO - 2023-09-24 10:17:03 --> Helper loaded: url_helper
INFO - 2023-09-24 10:17:03 --> Helper loaded: file_helper
INFO - 2023-09-24 10:17:04 --> Database Driver Class Initialized
INFO - 2023-09-24 10:17:04 --> Email Class Initialized
DEBUG - 2023-09-24 10:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:17:04 --> Controller Class Initialized
INFO - 2023-09-24 10:17:04 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:17:04 --> Model "Home_model" initialized
INFO - 2023-09-24 10:17:04 --> Helper loaded: download_helper
INFO - 2023-09-24 10:17:04 --> Helper loaded: form_helper
INFO - 2023-09-24 10:17:04 --> Form Validation Class Initialized
INFO - 2023-09-24 10:17:04 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:17:04 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:17:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:17:04 --> Final output sent to browser
DEBUG - 2023-09-24 10:17:05 --> Total execution time: 2.3710
INFO - 2023-09-24 10:26:35 --> Config Class Initialized
INFO - 2023-09-24 10:26:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:26:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:26:35 --> Utf8 Class Initialized
INFO - 2023-09-24 10:26:35 --> URI Class Initialized
INFO - 2023-09-24 10:26:35 --> Router Class Initialized
INFO - 2023-09-24 10:26:35 --> Output Class Initialized
INFO - 2023-09-24 10:26:35 --> Security Class Initialized
DEBUG - 2023-09-24 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:26:35 --> Input Class Initialized
INFO - 2023-09-24 10:26:35 --> Language Class Initialized
INFO - 2023-09-24 10:26:35 --> Loader Class Initialized
INFO - 2023-09-24 10:26:35 --> Helper loaded: url_helper
INFO - 2023-09-24 10:26:35 --> Helper loaded: file_helper
INFO - 2023-09-24 10:26:35 --> Database Driver Class Initialized
INFO - 2023-09-24 10:26:36 --> Email Class Initialized
DEBUG - 2023-09-24 10:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:26:36 --> Controller Class Initialized
INFO - 2023-09-24 10:26:36 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:26:36 --> Model "Home_model" initialized
INFO - 2023-09-24 10:26:36 --> Helper loaded: download_helper
INFO - 2023-09-24 10:26:36 --> Helper loaded: form_helper
INFO - 2023-09-24 10:26:36 --> Form Validation Class Initialized
INFO - 2023-09-24 10:26:36 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:26:36 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:26:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:26:36 --> Final output sent to browser
DEBUG - 2023-09-24 10:26:36 --> Total execution time: 1.7868
INFO - 2023-09-24 10:26:51 --> Config Class Initialized
INFO - 2023-09-24 10:26:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:26:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:26:51 --> Utf8 Class Initialized
INFO - 2023-09-24 10:26:51 --> URI Class Initialized
INFO - 2023-09-24 10:26:51 --> Router Class Initialized
INFO - 2023-09-24 10:26:51 --> Output Class Initialized
INFO - 2023-09-24 10:26:51 --> Security Class Initialized
DEBUG - 2023-09-24 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:26:51 --> Input Class Initialized
INFO - 2023-09-24 10:26:51 --> Language Class Initialized
INFO - 2023-09-24 10:26:51 --> Loader Class Initialized
INFO - 2023-09-24 10:26:51 --> Helper loaded: url_helper
INFO - 2023-09-24 10:26:51 --> Helper loaded: file_helper
INFO - 2023-09-24 10:26:51 --> Database Driver Class Initialized
INFO - 2023-09-24 10:26:51 --> Email Class Initialized
DEBUG - 2023-09-24 10:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:26:51 --> Controller Class Initialized
INFO - 2023-09-24 10:26:51 --> Model "Services_model" initialized
INFO - 2023-09-24 10:26:51 --> Helper loaded: form_helper
INFO - 2023-09-24 10:26:51 --> Form Validation Class Initialized
INFO - 2023-09-24 10:26:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:26:51 --> Final output sent to browser
DEBUG - 2023-09-24 10:26:51 --> Total execution time: 0.1328
INFO - 2023-09-24 10:26:55 --> Config Class Initialized
INFO - 2023-09-24 10:26:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:26:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:26:55 --> Utf8 Class Initialized
INFO - 2023-09-24 10:26:55 --> URI Class Initialized
INFO - 2023-09-24 10:26:55 --> Router Class Initialized
INFO - 2023-09-24 10:26:55 --> Output Class Initialized
INFO - 2023-09-24 10:26:55 --> Security Class Initialized
DEBUG - 2023-09-24 10:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:26:55 --> Input Class Initialized
INFO - 2023-09-24 10:26:55 --> Language Class Initialized
ERROR - 2023-09-24 10:26:55 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-24 10:27:02 --> Config Class Initialized
INFO - 2023-09-24 10:27:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:02 --> URI Class Initialized
INFO - 2023-09-24 10:27:02 --> Router Class Initialized
INFO - 2023-09-24 10:27:02 --> Output Class Initialized
INFO - 2023-09-24 10:27:03 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:03 --> Input Class Initialized
INFO - 2023-09-24 10:27:03 --> Language Class Initialized
INFO - 2023-09-24 10:27:03 --> Loader Class Initialized
INFO - 2023-09-24 10:27:03 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:03 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:03 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:03 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:03 --> Controller Class Initialized
INFO - 2023-09-24 10:27:03 --> Model "Services_model" initialized
INFO - 2023-09-24 10:27:03 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:03 --> Form Validation Class Initialized
INFO - 2023-09-24 10:27:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:27:04 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:04 --> Total execution time: 1.5880
INFO - 2023-09-24 10:27:06 --> Config Class Initialized
INFO - 2023-09-24 10:27:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:06 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:06 --> URI Class Initialized
INFO - 2023-09-24 10:27:06 --> Router Class Initialized
INFO - 2023-09-24 10:27:06 --> Output Class Initialized
INFO - 2023-09-24 10:27:06 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:06 --> Input Class Initialized
INFO - 2023-09-24 10:27:06 --> Language Class Initialized
INFO - 2023-09-24 10:27:06 --> Loader Class Initialized
INFO - 2023-09-24 10:27:06 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:06 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:06 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:06 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:06 --> Controller Class Initialized
INFO - 2023-09-24 10:27:06 --> Model "Services_model" initialized
INFO - 2023-09-24 10:27:06 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:06 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:27:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:27:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:27:06 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:06 --> Total execution time: 0.1098
INFO - 2023-09-24 10:27:29 --> Config Class Initialized
INFO - 2023-09-24 10:27:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:29 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:29 --> URI Class Initialized
INFO - 2023-09-24 10:27:29 --> Router Class Initialized
INFO - 2023-09-24 10:27:29 --> Output Class Initialized
INFO - 2023-09-24 10:27:29 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:29 --> Input Class Initialized
INFO - 2023-09-24 10:27:29 --> Language Class Initialized
INFO - 2023-09-24 10:27:29 --> Loader Class Initialized
INFO - 2023-09-24 10:27:29 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:29 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:29 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:29 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:29 --> Controller Class Initialized
INFO - 2023-09-24 10:27:29 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:27:29 --> Model "Home_model" initialized
INFO - 2023-09-24 10:27:29 --> Helper loaded: download_helper
INFO - 2023-09-24 10:27:29 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:29 --> Form Validation Class Initialized
INFO - 2023-09-24 10:27:29 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:27:29 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:27:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:27:29 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:29 --> Total execution time: 0.2147
INFO - 2023-09-24 10:27:35 --> Config Class Initialized
INFO - 2023-09-24 10:27:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:35 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:35 --> URI Class Initialized
INFO - 2023-09-24 10:27:35 --> Router Class Initialized
INFO - 2023-09-24 10:27:35 --> Output Class Initialized
INFO - 2023-09-24 10:27:35 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:35 --> Input Class Initialized
INFO - 2023-09-24 10:27:35 --> Language Class Initialized
INFO - 2023-09-24 10:27:35 --> Loader Class Initialized
INFO - 2023-09-24 10:27:35 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:35 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:35 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:35 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:35 --> Controller Class Initialized
INFO - 2023-09-24 10:27:35 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:27:35 --> Model "Home_model" initialized
INFO - 2023-09-24 10:27:35 --> Helper loaded: download_helper
INFO - 2023-09-24 10:27:35 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:35 --> Form Validation Class Initialized
INFO - 2023-09-24 10:27:35 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:27:35 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:27:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:27:35 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:35 --> Total execution time: 0.0621
INFO - 2023-09-24 10:27:50 --> Config Class Initialized
INFO - 2023-09-24 10:27:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:50 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:50 --> URI Class Initialized
INFO - 2023-09-24 10:27:51 --> Router Class Initialized
INFO - 2023-09-24 10:27:51 --> Output Class Initialized
INFO - 2023-09-24 10:27:51 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:51 --> Input Class Initialized
INFO - 2023-09-24 10:27:51 --> Language Class Initialized
INFO - 2023-09-24 10:27:51 --> Loader Class Initialized
INFO - 2023-09-24 10:27:51 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:51 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:51 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:51 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:51 --> Controller Class Initialized
INFO - 2023-09-24 10:27:51 --> Model "Services_model" initialized
INFO - 2023-09-24 10:27:51 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:51 --> Form Validation Class Initialized
INFO - 2023-09-24 10:27:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:27:51 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:51 --> Total execution time: 1.0770
INFO - 2023-09-24 10:27:57 --> Config Class Initialized
INFO - 2023-09-24 10:27:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:57 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:57 --> URI Class Initialized
INFO - 2023-09-24 10:27:57 --> Router Class Initialized
INFO - 2023-09-24 10:27:57 --> Output Class Initialized
INFO - 2023-09-24 10:27:57 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:57 --> Input Class Initialized
INFO - 2023-09-24 10:27:57 --> Language Class Initialized
INFO - 2023-09-24 10:27:57 --> Loader Class Initialized
INFO - 2023-09-24 10:27:57 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:57 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:57 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:57 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:57 --> Controller Class Initialized
INFO - 2023-09-24 10:27:57 --> Model "Services_model" initialized
INFO - 2023-09-24 10:27:57 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:57 --> Form Validation Class Initialized
INFO - 2023-09-24 10:27:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:27:57 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:57 --> Total execution time: 0.0759
INFO - 2023-09-24 10:27:58 --> Config Class Initialized
INFO - 2023-09-24 10:27:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:27:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:27:58 --> Utf8 Class Initialized
INFO - 2023-09-24 10:27:58 --> URI Class Initialized
INFO - 2023-09-24 10:27:58 --> Router Class Initialized
INFO - 2023-09-24 10:27:58 --> Output Class Initialized
INFO - 2023-09-24 10:27:58 --> Security Class Initialized
DEBUG - 2023-09-24 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:27:58 --> Input Class Initialized
INFO - 2023-09-24 10:27:58 --> Language Class Initialized
INFO - 2023-09-24 10:27:58 --> Loader Class Initialized
INFO - 2023-09-24 10:27:58 --> Helper loaded: url_helper
INFO - 2023-09-24 10:27:58 --> Helper loaded: file_helper
INFO - 2023-09-24 10:27:59 --> Database Driver Class Initialized
INFO - 2023-09-24 10:27:59 --> Email Class Initialized
DEBUG - 2023-09-24 10:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:27:59 --> Controller Class Initialized
INFO - 2023-09-24 10:27:59 --> Model "Services_model" initialized
INFO - 2023-09-24 10:27:59 --> Helper loaded: form_helper
INFO - 2023-09-24 10:27:59 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:27:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:27:59 --> Final output sent to browser
DEBUG - 2023-09-24 10:27:59 --> Total execution time: 0.0703
INFO - 2023-09-24 10:28:08 --> Config Class Initialized
INFO - 2023-09-24 10:28:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:08 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:08 --> URI Class Initialized
INFO - 2023-09-24 10:28:09 --> Router Class Initialized
INFO - 2023-09-24 10:28:09 --> Output Class Initialized
INFO - 2023-09-24 10:28:09 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:09 --> Input Class Initialized
INFO - 2023-09-24 10:28:09 --> Language Class Initialized
INFO - 2023-09-24 10:28:09 --> Loader Class Initialized
INFO - 2023-09-24 10:28:09 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:10 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:10 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:10 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:10 --> Controller Class Initialized
INFO - 2023-09-24 10:28:10 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:10 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:10 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:28:10 --> Config Class Initialized
INFO - 2023-09-24 10:28:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:10 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:10 --> URI Class Initialized
INFO - 2023-09-24 10:28:10 --> Router Class Initialized
INFO - 2023-09-24 10:28:10 --> Output Class Initialized
INFO - 2023-09-24 10:28:10 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:10 --> Input Class Initialized
INFO - 2023-09-24 10:28:10 --> Language Class Initialized
INFO - 2023-09-24 10:28:10 --> Loader Class Initialized
INFO - 2023-09-24 10:28:10 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:10 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:10 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:10 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:10 --> Controller Class Initialized
INFO - 2023-09-24 10:28:10 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:10 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:10 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:28:11 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:11 --> Total execution time: 0.1474
INFO - 2023-09-24 10:28:13 --> Config Class Initialized
INFO - 2023-09-24 10:28:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:13 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:13 --> URI Class Initialized
INFO - 2023-09-24 10:28:13 --> Router Class Initialized
INFO - 2023-09-24 10:28:13 --> Output Class Initialized
INFO - 2023-09-24 10:28:13 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:13 --> Input Class Initialized
INFO - 2023-09-24 10:28:13 --> Language Class Initialized
INFO - 2023-09-24 10:28:13 --> Loader Class Initialized
INFO - 2023-09-24 10:28:13 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:13 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:13 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:13 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:13 --> Controller Class Initialized
INFO - 2023-09-24 10:28:13 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:28:13 --> Model "Home_model" initialized
INFO - 2023-09-24 10:28:13 --> Helper loaded: download_helper
INFO - 2023-09-24 10:28:13 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:13 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:13 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:28:13 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:28:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:28:13 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:13 --> Total execution time: 0.1848
INFO - 2023-09-24 10:28:20 --> Config Class Initialized
INFO - 2023-09-24 10:28:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:20 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:20 --> URI Class Initialized
INFO - 2023-09-24 10:28:20 --> Router Class Initialized
INFO - 2023-09-24 10:28:20 --> Output Class Initialized
INFO - 2023-09-24 10:28:20 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:20 --> Input Class Initialized
INFO - 2023-09-24 10:28:20 --> Language Class Initialized
INFO - 2023-09-24 10:28:20 --> Loader Class Initialized
INFO - 2023-09-24 10:28:20 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:20 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:20 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:20 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:20 --> Controller Class Initialized
INFO - 2023-09-24 10:28:20 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:28:20 --> Model "Home_model" initialized
INFO - 2023-09-24 10:28:20 --> Helper loaded: download_helper
INFO - 2023-09-24 10:28:20 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:20 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:20 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:28:20 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:28:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:28:20 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:20 --> Total execution time: 0.0669
INFO - 2023-09-24 10:28:37 --> Config Class Initialized
INFO - 2023-09-24 10:28:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:37 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:37 --> URI Class Initialized
INFO - 2023-09-24 10:28:37 --> Router Class Initialized
INFO - 2023-09-24 10:28:37 --> Output Class Initialized
INFO - 2023-09-24 10:28:37 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:37 --> Input Class Initialized
INFO - 2023-09-24 10:28:37 --> Language Class Initialized
INFO - 2023-09-24 10:28:37 --> Loader Class Initialized
INFO - 2023-09-24 10:28:38 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:38 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:38 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:38 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:38 --> Controller Class Initialized
INFO - 2023-09-24 10:28:38 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:38 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:38 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:28:38 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:38 --> Total execution time: 1.6465
INFO - 2023-09-24 10:28:40 --> Config Class Initialized
INFO - 2023-09-24 10:28:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:40 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:40 --> URI Class Initialized
INFO - 2023-09-24 10:28:40 --> Router Class Initialized
INFO - 2023-09-24 10:28:40 --> Output Class Initialized
INFO - 2023-09-24 10:28:40 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:40 --> Input Class Initialized
INFO - 2023-09-24 10:28:40 --> Language Class Initialized
INFO - 2023-09-24 10:28:40 --> Loader Class Initialized
INFO - 2023-09-24 10:28:40 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:40 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:40 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:40 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:40 --> Controller Class Initialized
INFO - 2023-09-24 10:28:40 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:41 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:41 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:28:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:28:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:28:41 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:41 --> Total execution time: 0.0884
INFO - 2023-09-24 10:28:47 --> Config Class Initialized
INFO - 2023-09-24 10:28:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:47 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:47 --> URI Class Initialized
INFO - 2023-09-24 10:28:47 --> Router Class Initialized
INFO - 2023-09-24 10:28:47 --> Output Class Initialized
INFO - 2023-09-24 10:28:47 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:47 --> Input Class Initialized
INFO - 2023-09-24 10:28:47 --> Language Class Initialized
INFO - 2023-09-24 10:28:47 --> Loader Class Initialized
INFO - 2023-09-24 10:28:47 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:47 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:47 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:47 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:47 --> Controller Class Initialized
INFO - 2023-09-24 10:28:47 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:47 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:47 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:28:48 --> Config Class Initialized
INFO - 2023-09-24 10:28:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:48 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:48 --> URI Class Initialized
INFO - 2023-09-24 10:28:48 --> Router Class Initialized
INFO - 2023-09-24 10:28:48 --> Output Class Initialized
INFO - 2023-09-24 10:28:48 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:48 --> Input Class Initialized
INFO - 2023-09-24 10:28:48 --> Language Class Initialized
INFO - 2023-09-24 10:28:48 --> Loader Class Initialized
INFO - 2023-09-24 10:28:48 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:48 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:48 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:48 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:48 --> Controller Class Initialized
INFO - 2023-09-24 10:28:48 --> Model "Services_model" initialized
INFO - 2023-09-24 10:28:48 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:48 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:28:48 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:48 --> Total execution time: 0.0628
INFO - 2023-09-24 10:28:51 --> Config Class Initialized
INFO - 2023-09-24 10:28:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:51 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:51 --> URI Class Initialized
INFO - 2023-09-24 10:28:51 --> Router Class Initialized
INFO - 2023-09-24 10:28:51 --> Output Class Initialized
INFO - 2023-09-24 10:28:51 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:51 --> Input Class Initialized
INFO - 2023-09-24 10:28:51 --> Language Class Initialized
INFO - 2023-09-24 10:28:51 --> Loader Class Initialized
INFO - 2023-09-24 10:28:51 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:51 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:51 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:51 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:51 --> Controller Class Initialized
INFO - 2023-09-24 10:28:51 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:28:51 --> Model "Home_model" initialized
INFO - 2023-09-24 10:28:51 --> Helper loaded: download_helper
INFO - 2023-09-24 10:28:51 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:51 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:51 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:28:51 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:28:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:28:51 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:51 --> Total execution time: 0.0806
INFO - 2023-09-24 10:28:59 --> Config Class Initialized
INFO - 2023-09-24 10:28:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:28:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:28:59 --> Utf8 Class Initialized
INFO - 2023-09-24 10:28:59 --> URI Class Initialized
INFO - 2023-09-24 10:28:59 --> Router Class Initialized
INFO - 2023-09-24 10:28:59 --> Output Class Initialized
INFO - 2023-09-24 10:28:59 --> Security Class Initialized
DEBUG - 2023-09-24 10:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:28:59 --> Input Class Initialized
INFO - 2023-09-24 10:28:59 --> Language Class Initialized
INFO - 2023-09-24 10:28:59 --> Loader Class Initialized
INFO - 2023-09-24 10:28:59 --> Helper loaded: url_helper
INFO - 2023-09-24 10:28:59 --> Helper loaded: file_helper
INFO - 2023-09-24 10:28:59 --> Database Driver Class Initialized
INFO - 2023-09-24 10:28:59 --> Email Class Initialized
DEBUG - 2023-09-24 10:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:28:59 --> Controller Class Initialized
INFO - 2023-09-24 10:28:59 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:28:59 --> Model "Home_model" initialized
INFO - 2023-09-24 10:28:59 --> Helper loaded: download_helper
INFO - 2023-09-24 10:28:59 --> Helper loaded: form_helper
INFO - 2023-09-24 10:28:59 --> Form Validation Class Initialized
INFO - 2023-09-24 10:28:59 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:28:59 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:28:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:28:59 --> Final output sent to browser
DEBUG - 2023-09-24 10:28:59 --> Total execution time: 0.0706
INFO - 2023-09-24 10:29:07 --> Config Class Initialized
INFO - 2023-09-24 10:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:07 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:07 --> URI Class Initialized
INFO - 2023-09-24 10:29:07 --> Router Class Initialized
INFO - 2023-09-24 10:29:07 --> Output Class Initialized
INFO - 2023-09-24 10:29:07 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:07 --> Input Class Initialized
INFO - 2023-09-24 10:29:07 --> Language Class Initialized
INFO - 2023-09-24 10:29:07 --> Loader Class Initialized
INFO - 2023-09-24 10:29:07 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:07 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:07 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:07 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:07 --> Controller Class Initialized
INFO - 2023-09-24 10:29:07 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:29:07 --> Model "Home_model" initialized
INFO - 2023-09-24 10:29:07 --> Helper loaded: download_helper
INFO - 2023-09-24 10:29:07 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:07 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:07 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:29:07 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:29:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:29:07 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:07 --> Total execution time: 0.0727
INFO - 2023-09-24 10:29:13 --> Config Class Initialized
INFO - 2023-09-24 10:29:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:13 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:13 --> URI Class Initialized
INFO - 2023-09-24 10:29:13 --> Router Class Initialized
INFO - 2023-09-24 10:29:13 --> Output Class Initialized
INFO - 2023-09-24 10:29:13 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:13 --> Input Class Initialized
INFO - 2023-09-24 10:29:13 --> Language Class Initialized
INFO - 2023-09-24 10:29:13 --> Loader Class Initialized
INFO - 2023-09-24 10:29:13 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:13 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:13 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:13 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:13 --> Controller Class Initialized
INFO - 2023-09-24 10:29:13 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:29:13 --> Model "Home_model" initialized
INFO - 2023-09-24 10:29:13 --> Helper loaded: download_helper
INFO - 2023-09-24 10:29:13 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:13 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:13 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:29:13 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:29:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:29:13 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:13 --> Total execution time: 0.0688
INFO - 2023-09-24 10:29:18 --> Config Class Initialized
INFO - 2023-09-24 10:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:18 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:18 --> URI Class Initialized
INFO - 2023-09-24 10:29:18 --> Router Class Initialized
INFO - 2023-09-24 10:29:18 --> Output Class Initialized
INFO - 2023-09-24 10:29:18 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:18 --> Input Class Initialized
INFO - 2023-09-24 10:29:18 --> Language Class Initialized
INFO - 2023-09-24 10:29:18 --> Loader Class Initialized
INFO - 2023-09-24 10:29:18 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:18 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:18 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:18 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:18 --> Controller Class Initialized
INFO - 2023-09-24 10:29:18 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:29:18 --> Model "Home_model" initialized
INFO - 2023-09-24 10:29:18 --> Helper loaded: download_helper
INFO - 2023-09-24 10:29:18 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:18 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:18 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:29:18 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:29:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:29:18 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:18 --> Total execution time: 0.0782
INFO - 2023-09-24 10:29:34 --> Config Class Initialized
INFO - 2023-09-24 10:29:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:34 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:34 --> URI Class Initialized
INFO - 2023-09-24 10:29:34 --> Router Class Initialized
INFO - 2023-09-24 10:29:35 --> Output Class Initialized
INFO - 2023-09-24 10:29:35 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:35 --> Input Class Initialized
INFO - 2023-09-24 10:29:35 --> Language Class Initialized
INFO - 2023-09-24 10:29:35 --> Loader Class Initialized
INFO - 2023-09-24 10:29:35 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:35 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:35 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:35 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:35 --> Controller Class Initialized
INFO - 2023-09-24 10:29:35 --> Model "Services_model" initialized
INFO - 2023-09-24 10:29:35 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:36 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:29:36 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:36 --> Total execution time: 1.6310
INFO - 2023-09-24 10:29:37 --> Config Class Initialized
INFO - 2023-09-24 10:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:37 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:37 --> URI Class Initialized
INFO - 2023-09-24 10:29:37 --> Router Class Initialized
INFO - 2023-09-24 10:29:37 --> Output Class Initialized
INFO - 2023-09-24 10:29:37 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:37 --> Input Class Initialized
INFO - 2023-09-24 10:29:37 --> Language Class Initialized
INFO - 2023-09-24 10:29:37 --> Loader Class Initialized
INFO - 2023-09-24 10:29:37 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:37 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:37 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:37 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:37 --> Controller Class Initialized
INFO - 2023-09-24 10:29:37 --> Model "Services_model" initialized
INFO - 2023-09-24 10:29:37 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:37 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:29:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:29:37 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:37 --> Total execution time: 0.0673
INFO - 2023-09-24 10:29:46 --> Config Class Initialized
INFO - 2023-09-24 10:29:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:46 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:47 --> URI Class Initialized
INFO - 2023-09-24 10:29:47 --> Router Class Initialized
INFO - 2023-09-24 10:29:47 --> Output Class Initialized
INFO - 2023-09-24 10:29:47 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:48 --> Input Class Initialized
INFO - 2023-09-24 10:29:48 --> Language Class Initialized
INFO - 2023-09-24 10:29:48 --> Loader Class Initialized
INFO - 2023-09-24 10:29:48 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:48 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:48 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:48 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:48 --> Controller Class Initialized
INFO - 2023-09-24 10:29:48 --> Model "Services_model" initialized
INFO - 2023-09-24 10:29:48 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:48 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:29:49 --> Config Class Initialized
INFO - 2023-09-24 10:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:49 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:49 --> URI Class Initialized
INFO - 2023-09-24 10:29:49 --> Router Class Initialized
INFO - 2023-09-24 10:29:49 --> Output Class Initialized
INFO - 2023-09-24 10:29:49 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:49 --> Input Class Initialized
INFO - 2023-09-24 10:29:49 --> Language Class Initialized
INFO - 2023-09-24 10:29:49 --> Loader Class Initialized
INFO - 2023-09-24 10:29:49 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:49 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:49 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:49 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:49 --> Controller Class Initialized
INFO - 2023-09-24 10:29:49 --> Model "Services_model" initialized
INFO - 2023-09-24 10:29:49 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:49 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:29:49 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:49 --> Total execution time: 0.1247
INFO - 2023-09-24 10:29:51 --> Config Class Initialized
INFO - 2023-09-24 10:29:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:29:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:29:51 --> Utf8 Class Initialized
INFO - 2023-09-24 10:29:51 --> URI Class Initialized
INFO - 2023-09-24 10:29:51 --> Router Class Initialized
INFO - 2023-09-24 10:29:51 --> Output Class Initialized
INFO - 2023-09-24 10:29:51 --> Security Class Initialized
DEBUG - 2023-09-24 10:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:29:51 --> Input Class Initialized
INFO - 2023-09-24 10:29:51 --> Language Class Initialized
INFO - 2023-09-24 10:29:51 --> Loader Class Initialized
INFO - 2023-09-24 10:29:51 --> Helper loaded: url_helper
INFO - 2023-09-24 10:29:51 --> Helper loaded: file_helper
INFO - 2023-09-24 10:29:51 --> Database Driver Class Initialized
INFO - 2023-09-24 10:29:51 --> Email Class Initialized
DEBUG - 2023-09-24 10:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:29:51 --> Controller Class Initialized
INFO - 2023-09-24 10:29:51 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:29:51 --> Model "Home_model" initialized
INFO - 2023-09-24 10:29:51 --> Helper loaded: download_helper
INFO - 2023-09-24 10:29:51 --> Helper loaded: form_helper
INFO - 2023-09-24 10:29:51 --> Form Validation Class Initialized
INFO - 2023-09-24 10:29:51 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:29:52 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:29:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:29:52 --> Final output sent to browser
DEBUG - 2023-09-24 10:29:52 --> Total execution time: 0.0734
INFO - 2023-09-24 10:30:10 --> Config Class Initialized
INFO - 2023-09-24 10:30:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:30:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:30:10 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:10 --> URI Class Initialized
INFO - 2023-09-24 10:30:10 --> Router Class Initialized
INFO - 2023-09-24 10:30:10 --> Output Class Initialized
INFO - 2023-09-24 10:30:10 --> Security Class Initialized
DEBUG - 2023-09-24 10:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:30:10 --> Input Class Initialized
INFO - 2023-09-24 10:30:11 --> Language Class Initialized
INFO - 2023-09-24 10:30:11 --> Loader Class Initialized
INFO - 2023-09-24 10:30:11 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:11 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:11 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:11 --> Email Class Initialized
DEBUG - 2023-09-24 10:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:11 --> Controller Class Initialized
INFO - 2023-09-24 10:30:11 --> Model "Services_model" initialized
INFO - 2023-09-24 10:30:11 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:11 --> Form Validation Class Initialized
INFO - 2023-09-24 10:30:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:30:11 --> Final output sent to browser
DEBUG - 2023-09-24 10:30:12 --> Total execution time: 1.8825
INFO - 2023-09-24 10:30:13 --> Config Class Initialized
INFO - 2023-09-24 10:30:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:30:13 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:13 --> URI Class Initialized
INFO - 2023-09-24 10:30:13 --> Router Class Initialized
INFO - 2023-09-24 10:30:13 --> Output Class Initialized
INFO - 2023-09-24 10:30:13 --> Security Class Initialized
DEBUG - 2023-09-24 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:30:14 --> Input Class Initialized
INFO - 2023-09-24 10:30:14 --> Language Class Initialized
INFO - 2023-09-24 10:30:14 --> Loader Class Initialized
INFO - 2023-09-24 10:30:14 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:14 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:14 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:14 --> Email Class Initialized
DEBUG - 2023-09-24 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:14 --> Controller Class Initialized
INFO - 2023-09-24 10:30:14 --> Model "Services_model" initialized
INFO - 2023-09-24 10:30:14 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:14 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:30:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:30:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:30:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:30:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:30:16 --> Final output sent to browser
DEBUG - 2023-09-24 10:30:16 --> Total execution time: 3.5472
INFO - 2023-09-24 10:30:28 --> Config Class Initialized
INFO - 2023-09-24 10:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:30:28 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:28 --> URI Class Initialized
INFO - 2023-09-24 10:30:28 --> Router Class Initialized
INFO - 2023-09-24 10:30:28 --> Output Class Initialized
INFO - 2023-09-24 10:30:28 --> Security Class Initialized
DEBUG - 2023-09-24 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:30:29 --> Input Class Initialized
INFO - 2023-09-24 10:30:29 --> Language Class Initialized
INFO - 2023-09-24 10:30:29 --> Loader Class Initialized
INFO - 2023-09-24 10:30:30 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:30 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:30 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:30 --> Email Class Initialized
DEBUG - 2023-09-24 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:31 --> Controller Class Initialized
INFO - 2023-09-24 10:30:31 --> Model "Services_model" initialized
INFO - 2023-09-24 10:30:31 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:31 --> Form Validation Class Initialized
INFO - 2023-09-24 10:30:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:30:32 --> Config Class Initialized
INFO - 2023-09-24 10:30:32 --> Config Class Initialized
INFO - 2023-09-24 10:30:32 --> Hooks Class Initialized
INFO - 2023-09-24 10:30:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 10:30:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:30:32 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:32 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:32 --> URI Class Initialized
INFO - 2023-09-24 10:30:32 --> URI Class Initialized
INFO - 2023-09-24 10:30:33 --> Router Class Initialized
INFO - 2023-09-24 10:30:33 --> Router Class Initialized
INFO - 2023-09-24 10:30:33 --> Output Class Initialized
INFO - 2023-09-24 10:30:33 --> Output Class Initialized
INFO - 2023-09-24 10:30:33 --> Security Class Initialized
INFO - 2023-09-24 10:30:33 --> Security Class Initialized
DEBUG - 2023-09-24 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:30:33 --> Input Class Initialized
INFO - 2023-09-24 10:30:33 --> Input Class Initialized
INFO - 2023-09-24 10:30:33 --> Language Class Initialized
INFO - 2023-09-24 10:30:33 --> Language Class Initialized
INFO - 2023-09-24 10:30:33 --> Loader Class Initialized
INFO - 2023-09-24 10:30:33 --> Loader Class Initialized
INFO - 2023-09-24 10:30:33 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:33 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:33 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:33 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:33 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:33 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:33 --> Email Class Initialized
INFO - 2023-09-24 10:30:33 --> Email Class Initialized
DEBUG - 2023-09-24 10:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-09-24 10:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:34 --> Controller Class Initialized
INFO - 2023-09-24 10:30:34 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:30:34 --> Model "Home_model" initialized
INFO - 2023-09-24 10:30:34 --> Helper loaded: download_helper
INFO - 2023-09-24 10:30:34 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:34 --> Form Validation Class Initialized
INFO - 2023-09-24 10:30:34 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:30:34 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:30:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:30:34 --> Final output sent to browser
DEBUG - 2023-09-24 10:30:34 --> Total execution time: 2.3791
INFO - 2023-09-24 10:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:35 --> Controller Class Initialized
INFO - 2023-09-24 10:30:35 --> Model "Services_model" initialized
INFO - 2023-09-24 10:30:36 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:36 --> Form Validation Class Initialized
INFO - 2023-09-24 10:30:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:30:36 --> Final output sent to browser
DEBUG - 2023-09-24 10:30:36 --> Total execution time: 4.8846
INFO - 2023-09-24 10:30:40 --> Config Class Initialized
INFO - 2023-09-24 10:30:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:30:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:30:41 --> Utf8 Class Initialized
INFO - 2023-09-24 10:30:41 --> URI Class Initialized
INFO - 2023-09-24 10:30:41 --> Router Class Initialized
INFO - 2023-09-24 10:30:41 --> Output Class Initialized
INFO - 2023-09-24 10:30:41 --> Security Class Initialized
DEBUG - 2023-09-24 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:30:41 --> Input Class Initialized
INFO - 2023-09-24 10:30:41 --> Language Class Initialized
INFO - 2023-09-24 10:30:41 --> Loader Class Initialized
INFO - 2023-09-24 10:30:41 --> Helper loaded: url_helper
INFO - 2023-09-24 10:30:41 --> Helper loaded: file_helper
INFO - 2023-09-24 10:30:41 --> Database Driver Class Initialized
INFO - 2023-09-24 10:30:41 --> Email Class Initialized
DEBUG - 2023-09-24 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:30:42 --> Controller Class Initialized
INFO - 2023-09-24 10:30:42 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:30:42 --> Model "Home_model" initialized
INFO - 2023-09-24 10:30:42 --> Helper loaded: download_helper
INFO - 2023-09-24 10:30:42 --> Helper loaded: form_helper
INFO - 2023-09-24 10:30:42 --> Form Validation Class Initialized
INFO - 2023-09-24 10:30:42 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:30:42 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:30:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:30:42 --> Final output sent to browser
DEBUG - 2023-09-24 10:30:43 --> Total execution time: 2.0903
INFO - 2023-09-24 10:31:03 --> Config Class Initialized
INFO - 2023-09-24 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:31:03 --> Utf8 Class Initialized
INFO - 2023-09-24 10:31:03 --> URI Class Initialized
INFO - 2023-09-24 10:31:03 --> Router Class Initialized
INFO - 2023-09-24 10:31:03 --> Output Class Initialized
INFO - 2023-09-24 10:31:03 --> Security Class Initialized
DEBUG - 2023-09-24 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:31:04 --> Input Class Initialized
INFO - 2023-09-24 10:31:04 --> Language Class Initialized
INFO - 2023-09-24 10:31:04 --> Loader Class Initialized
INFO - 2023-09-24 10:31:04 --> Helper loaded: url_helper
INFO - 2023-09-24 10:31:04 --> Helper loaded: file_helper
INFO - 2023-09-24 10:31:04 --> Database Driver Class Initialized
INFO - 2023-09-24 10:31:04 --> Email Class Initialized
DEBUG - 2023-09-24 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:31:04 --> Controller Class Initialized
INFO - 2023-09-24 10:31:04 --> Model "Services_model" initialized
INFO - 2023-09-24 10:31:05 --> Helper loaded: form_helper
INFO - 2023-09-24 10:31:05 --> Form Validation Class Initialized
INFO - 2023-09-24 10:31:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:31:05 --> Final output sent to browser
DEBUG - 2023-09-24 10:31:05 --> Total execution time: 1.9426
INFO - 2023-09-24 10:31:06 --> Config Class Initialized
INFO - 2023-09-24 10:31:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:31:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:31:06 --> Utf8 Class Initialized
INFO - 2023-09-24 10:31:06 --> URI Class Initialized
INFO - 2023-09-24 10:31:06 --> Router Class Initialized
INFO - 2023-09-24 10:31:06 --> Output Class Initialized
INFO - 2023-09-24 10:31:06 --> Security Class Initialized
DEBUG - 2023-09-24 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:31:07 --> Input Class Initialized
INFO - 2023-09-24 10:31:07 --> Language Class Initialized
INFO - 2023-09-24 10:31:07 --> Loader Class Initialized
INFO - 2023-09-24 10:31:07 --> Helper loaded: url_helper
INFO - 2023-09-24 10:31:07 --> Helper loaded: file_helper
INFO - 2023-09-24 10:31:07 --> Database Driver Class Initialized
INFO - 2023-09-24 10:31:07 --> Email Class Initialized
DEBUG - 2023-09-24 10:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:31:07 --> Controller Class Initialized
INFO - 2023-09-24 10:31:07 --> Model "Services_model" initialized
INFO - 2023-09-24 10:31:07 --> Helper loaded: form_helper
INFO - 2023-09-24 10:31:08 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:31:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:31:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:31:09 --> Final output sent to browser
DEBUG - 2023-09-24 10:31:09 --> Total execution time: 3.7006
INFO - 2023-09-24 10:31:12 --> Config Class Initialized
INFO - 2023-09-24 10:31:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:31:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:31:12 --> Utf8 Class Initialized
INFO - 2023-09-24 10:31:12 --> URI Class Initialized
INFO - 2023-09-24 10:31:13 --> Router Class Initialized
INFO - 2023-09-24 10:31:13 --> Output Class Initialized
INFO - 2023-09-24 10:31:13 --> Security Class Initialized
DEBUG - 2023-09-24 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:31:13 --> Input Class Initialized
INFO - 2023-09-24 10:31:13 --> Language Class Initialized
INFO - 2023-09-24 10:31:13 --> Loader Class Initialized
INFO - 2023-09-24 10:31:13 --> Helper loaded: url_helper
INFO - 2023-09-24 10:31:13 --> Helper loaded: file_helper
INFO - 2023-09-24 10:31:13 --> Database Driver Class Initialized
INFO - 2023-09-24 10:31:13 --> Email Class Initialized
DEBUG - 2023-09-24 10:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:31:14 --> Controller Class Initialized
INFO - 2023-09-24 10:31:14 --> Model "Services_model" initialized
INFO - 2023-09-24 10:31:14 --> Helper loaded: form_helper
INFO - 2023-09-24 10:31:14 --> Form Validation Class Initialized
INFO - 2023-09-24 10:31:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:31:15 --> Config Class Initialized
INFO - 2023-09-24 10:31:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:31:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:31:16 --> Utf8 Class Initialized
INFO - 2023-09-24 10:31:16 --> URI Class Initialized
INFO - 2023-09-24 10:31:16 --> Router Class Initialized
INFO - 2023-09-24 10:31:16 --> Output Class Initialized
INFO - 2023-09-24 10:31:16 --> Security Class Initialized
DEBUG - 2023-09-24 10:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:31:16 --> Input Class Initialized
INFO - 2023-09-24 10:31:16 --> Language Class Initialized
INFO - 2023-09-24 10:31:16 --> Loader Class Initialized
INFO - 2023-09-24 10:31:16 --> Helper loaded: url_helper
INFO - 2023-09-24 10:31:17 --> Helper loaded: file_helper
INFO - 2023-09-24 10:31:17 --> Database Driver Class Initialized
INFO - 2023-09-24 10:31:17 --> Email Class Initialized
DEBUG - 2023-09-24 10:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:31:18 --> Controller Class Initialized
INFO - 2023-09-24 10:31:18 --> Model "Services_model" initialized
INFO - 2023-09-24 10:31:18 --> Helper loaded: form_helper
INFO - 2023-09-24 10:31:18 --> Form Validation Class Initialized
INFO - 2023-09-24 10:31:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:31:18 --> Final output sent to browser
DEBUG - 2023-09-24 10:31:18 --> Total execution time: 3.3048
INFO - 2023-09-24 10:31:20 --> Config Class Initialized
INFO - 2023-09-24 10:31:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:31:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:31:20 --> Utf8 Class Initialized
INFO - 2023-09-24 10:31:20 --> URI Class Initialized
INFO - 2023-09-24 10:31:20 --> Router Class Initialized
INFO - 2023-09-24 10:31:20 --> Output Class Initialized
INFO - 2023-09-24 10:31:20 --> Security Class Initialized
DEBUG - 2023-09-24 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:31:21 --> Input Class Initialized
INFO - 2023-09-24 10:31:21 --> Language Class Initialized
INFO - 2023-09-24 10:31:21 --> Loader Class Initialized
INFO - 2023-09-24 10:31:21 --> Helper loaded: url_helper
INFO - 2023-09-24 10:31:21 --> Helper loaded: file_helper
INFO - 2023-09-24 10:31:21 --> Database Driver Class Initialized
INFO - 2023-09-24 10:31:21 --> Email Class Initialized
DEBUG - 2023-09-24 10:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:31:21 --> Controller Class Initialized
INFO - 2023-09-24 10:31:21 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:31:21 --> Model "Home_model" initialized
INFO - 2023-09-24 10:31:21 --> Helper loaded: download_helper
INFO - 2023-09-24 10:31:21 --> Helper loaded: form_helper
INFO - 2023-09-24 10:31:21 --> Form Validation Class Initialized
INFO - 2023-09-24 10:31:22 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:31:22 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:31:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:31:22 --> Final output sent to browser
DEBUG - 2023-09-24 10:31:22 --> Total execution time: 2.3640
INFO - 2023-09-24 10:32:18 --> Config Class Initialized
INFO - 2023-09-24 10:32:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:32:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:32:18 --> Utf8 Class Initialized
INFO - 2023-09-24 10:32:18 --> URI Class Initialized
INFO - 2023-09-24 10:32:18 --> Router Class Initialized
INFO - 2023-09-24 10:32:18 --> Output Class Initialized
INFO - 2023-09-24 10:32:18 --> Security Class Initialized
DEBUG - 2023-09-24 10:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:32:18 --> Input Class Initialized
INFO - 2023-09-24 10:32:18 --> Language Class Initialized
INFO - 2023-09-24 10:32:18 --> Loader Class Initialized
INFO - 2023-09-24 10:32:18 --> Helper loaded: url_helper
INFO - 2023-09-24 10:32:19 --> Helper loaded: file_helper
INFO - 2023-09-24 10:32:19 --> Database Driver Class Initialized
INFO - 2023-09-24 10:32:19 --> Email Class Initialized
DEBUG - 2023-09-24 10:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:32:19 --> Controller Class Initialized
INFO - 2023-09-24 10:32:19 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:32:19 --> Model "Home_model" initialized
INFO - 2023-09-24 10:32:19 --> Helper loaded: download_helper
INFO - 2023-09-24 10:32:19 --> Helper loaded: form_helper
INFO - 2023-09-24 10:32:19 --> Form Validation Class Initialized
INFO - 2023-09-24 10:32:19 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:32:20 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:32:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:32:20 --> Final output sent to browser
DEBUG - 2023-09-24 10:32:20 --> Total execution time: 2.4140
INFO - 2023-09-24 10:32:31 --> Config Class Initialized
INFO - 2023-09-24 10:32:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:32:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:32:31 --> Utf8 Class Initialized
INFO - 2023-09-24 10:32:31 --> URI Class Initialized
INFO - 2023-09-24 10:32:31 --> Router Class Initialized
INFO - 2023-09-24 10:32:31 --> Output Class Initialized
INFO - 2023-09-24 10:32:31 --> Security Class Initialized
DEBUG - 2023-09-24 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:32:32 --> Input Class Initialized
INFO - 2023-09-24 10:32:32 --> Language Class Initialized
INFO - 2023-09-24 10:32:32 --> Loader Class Initialized
INFO - 2023-09-24 10:32:32 --> Helper loaded: url_helper
INFO - 2023-09-24 10:32:32 --> Helper loaded: file_helper
INFO - 2023-09-24 10:32:32 --> Database Driver Class Initialized
INFO - 2023-09-24 10:32:32 --> Email Class Initialized
DEBUG - 2023-09-24 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:32:32 --> Controller Class Initialized
INFO - 2023-09-24 10:32:32 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:32:32 --> Model "Home_model" initialized
INFO - 2023-09-24 10:32:33 --> Helper loaded: download_helper
INFO - 2023-09-24 10:32:33 --> Helper loaded: form_helper
INFO - 2023-09-24 10:32:33 --> Form Validation Class Initialized
INFO - 2023-09-24 10:32:33 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:32:33 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:32:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:32:33 --> Final output sent to browser
DEBUG - 2023-09-24 10:32:33 --> Total execution time: 2.2509
INFO - 2023-09-24 10:32:40 --> Config Class Initialized
INFO - 2023-09-24 10:32:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:32:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:32:40 --> Utf8 Class Initialized
INFO - 2023-09-24 10:32:40 --> URI Class Initialized
INFO - 2023-09-24 10:32:40 --> Router Class Initialized
INFO - 2023-09-24 10:32:40 --> Output Class Initialized
INFO - 2023-09-24 10:32:40 --> Security Class Initialized
DEBUG - 2023-09-24 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:32:40 --> Input Class Initialized
INFO - 2023-09-24 10:32:40 --> Language Class Initialized
INFO - 2023-09-24 10:32:40 --> Loader Class Initialized
INFO - 2023-09-24 10:32:40 --> Helper loaded: url_helper
INFO - 2023-09-24 10:32:40 --> Helper loaded: file_helper
INFO - 2023-09-24 10:32:40 --> Database Driver Class Initialized
INFO - 2023-09-24 10:32:41 --> Email Class Initialized
DEBUG - 2023-09-24 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:32:41 --> Controller Class Initialized
INFO - 2023-09-24 10:32:41 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:32:41 --> Model "Home_model" initialized
INFO - 2023-09-24 10:32:41 --> Helper loaded: download_helper
INFO - 2023-09-24 10:32:41 --> Helper loaded: form_helper
INFO - 2023-09-24 10:32:41 --> Form Validation Class Initialized
INFO - 2023-09-24 10:32:41 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:32:41 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:32:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:32:41 --> Final output sent to browser
DEBUG - 2023-09-24 10:32:42 --> Total execution time: 2.0665
INFO - 2023-09-24 10:32:47 --> Config Class Initialized
INFO - 2023-09-24 10:32:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:32:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:32:48 --> Utf8 Class Initialized
INFO - 2023-09-24 10:32:48 --> URI Class Initialized
INFO - 2023-09-24 10:32:48 --> Router Class Initialized
INFO - 2023-09-24 10:32:48 --> Output Class Initialized
INFO - 2023-09-24 10:32:48 --> Security Class Initialized
DEBUG - 2023-09-24 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:32:48 --> Input Class Initialized
INFO - 2023-09-24 10:32:48 --> Language Class Initialized
INFO - 2023-09-24 10:32:48 --> Loader Class Initialized
INFO - 2023-09-24 10:32:48 --> Helper loaded: url_helper
INFO - 2023-09-24 10:32:48 --> Helper loaded: file_helper
INFO - 2023-09-24 10:32:48 --> Database Driver Class Initialized
INFO - 2023-09-24 10:32:49 --> Email Class Initialized
DEBUG - 2023-09-24 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:32:49 --> Controller Class Initialized
INFO - 2023-09-24 10:32:49 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:32:49 --> Model "Home_model" initialized
INFO - 2023-09-24 10:32:49 --> Helper loaded: download_helper
INFO - 2023-09-24 10:32:49 --> Helper loaded: form_helper
INFO - 2023-09-24 10:32:49 --> Form Validation Class Initialized
INFO - 2023-09-24 10:32:49 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:32:49 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:32:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:32:50 --> Final output sent to browser
DEBUG - 2023-09-24 10:32:50 --> Total execution time: 2.3811
INFO - 2023-09-24 10:33:00 --> Config Class Initialized
INFO - 2023-09-24 10:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:33:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:33:01 --> Utf8 Class Initialized
INFO - 2023-09-24 10:33:01 --> URI Class Initialized
INFO - 2023-09-24 10:33:02 --> Router Class Initialized
INFO - 2023-09-24 10:33:02 --> Output Class Initialized
INFO - 2023-09-24 10:33:02 --> Security Class Initialized
DEBUG - 2023-09-24 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:33:03 --> Input Class Initialized
INFO - 2023-09-24 10:33:03 --> Language Class Initialized
INFO - 2023-09-24 10:33:03 --> Loader Class Initialized
INFO - 2023-09-24 10:33:03 --> Helper loaded: url_helper
INFO - 2023-09-24 10:33:04 --> Helper loaded: file_helper
INFO - 2023-09-24 10:33:04 --> Database Driver Class Initialized
INFO - 2023-09-24 10:33:04 --> Email Class Initialized
DEBUG - 2023-09-24 10:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:33:05 --> Controller Class Initialized
INFO - 2023-09-24 10:33:05 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:33:05 --> Model "Home_model" initialized
INFO - 2023-09-24 10:33:06 --> Helper loaded: download_helper
INFO - 2023-09-24 10:33:06 --> Helper loaded: form_helper
INFO - 2023-09-24 10:33:06 --> Form Validation Class Initialized
INFO - 2023-09-24 10:33:06 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:33:06 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:33:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:33:06 --> Final output sent to browser
DEBUG - 2023-09-24 10:33:06 --> Total execution time: 7.0902
INFO - 2023-09-24 10:33:47 --> Config Class Initialized
INFO - 2023-09-24 10:33:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:33:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:33:47 --> Utf8 Class Initialized
INFO - 2023-09-24 10:33:47 --> URI Class Initialized
INFO - 2023-09-24 10:33:47 --> Router Class Initialized
INFO - 2023-09-24 10:33:47 --> Output Class Initialized
INFO - 2023-09-24 10:33:47 --> Security Class Initialized
DEBUG - 2023-09-24 10:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:33:48 --> Input Class Initialized
INFO - 2023-09-24 10:33:48 --> Language Class Initialized
INFO - 2023-09-24 10:33:48 --> Loader Class Initialized
INFO - 2023-09-24 10:33:48 --> Helper loaded: url_helper
INFO - 2023-09-24 10:33:48 --> Helper loaded: file_helper
INFO - 2023-09-24 10:33:48 --> Database Driver Class Initialized
INFO - 2023-09-24 10:33:48 --> Email Class Initialized
DEBUG - 2023-09-24 10:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:33:48 --> Controller Class Initialized
INFO - 2023-09-24 10:33:48 --> Model "Services_model" initialized
INFO - 2023-09-24 10:33:48 --> Helper loaded: form_helper
INFO - 2023-09-24 10:33:48 --> Form Validation Class Initialized
INFO - 2023-09-24 10:33:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:33:48 --> Final output sent to browser
DEBUG - 2023-09-24 10:33:49 --> Total execution time: 1.6100
INFO - 2023-09-24 10:33:50 --> Config Class Initialized
INFO - 2023-09-24 10:33:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:33:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:33:50 --> Utf8 Class Initialized
INFO - 2023-09-24 10:33:50 --> URI Class Initialized
INFO - 2023-09-24 10:33:50 --> Router Class Initialized
INFO - 2023-09-24 10:33:50 --> Output Class Initialized
INFO - 2023-09-24 10:33:50 --> Security Class Initialized
DEBUG - 2023-09-24 10:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:33:50 --> Input Class Initialized
INFO - 2023-09-24 10:33:50 --> Language Class Initialized
INFO - 2023-09-24 10:33:51 --> Loader Class Initialized
INFO - 2023-09-24 10:33:51 --> Helper loaded: url_helper
INFO - 2023-09-24 10:33:51 --> Helper loaded: file_helper
INFO - 2023-09-24 10:33:51 --> Database Driver Class Initialized
INFO - 2023-09-24 10:33:51 --> Email Class Initialized
DEBUG - 2023-09-24 10:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:33:51 --> Controller Class Initialized
INFO - 2023-09-24 10:33:51 --> Model "Services_model" initialized
INFO - 2023-09-24 10:33:51 --> Helper loaded: form_helper
INFO - 2023-09-24 10:33:51 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:33:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:33:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:33:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:33:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:33:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:33:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:33:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:33:53 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:33:53 --> Final output sent to browser
DEBUG - 2023-09-24 10:33:53 --> Total execution time: 3.2060
INFO - 2023-09-24 10:33:59 --> Config Class Initialized
INFO - 2023-09-24 10:33:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:33:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:33:59 --> Utf8 Class Initialized
INFO - 2023-09-24 10:33:59 --> URI Class Initialized
INFO - 2023-09-24 10:33:59 --> Router Class Initialized
INFO - 2023-09-24 10:33:59 --> Output Class Initialized
INFO - 2023-09-24 10:33:59 --> Security Class Initialized
DEBUG - 2023-09-24 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:34:00 --> Input Class Initialized
INFO - 2023-09-24 10:34:00 --> Language Class Initialized
INFO - 2023-09-24 10:34:00 --> Loader Class Initialized
INFO - 2023-09-24 10:34:00 --> Helper loaded: url_helper
INFO - 2023-09-24 10:34:00 --> Helper loaded: file_helper
INFO - 2023-09-24 10:34:01 --> Database Driver Class Initialized
INFO - 2023-09-24 10:34:01 --> Email Class Initialized
DEBUG - 2023-09-24 10:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:34:01 --> Controller Class Initialized
INFO - 2023-09-24 10:34:01 --> Model "Services_model" initialized
INFO - 2023-09-24 10:34:01 --> Helper loaded: form_helper
INFO - 2023-09-24 10:34:01 --> Form Validation Class Initialized
INFO - 2023-09-24 10:34:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:34:01 --> Config Class Initialized
INFO - 2023-09-24 10:34:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:34:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:34:01 --> Utf8 Class Initialized
INFO - 2023-09-24 10:34:01 --> URI Class Initialized
INFO - 2023-09-24 10:34:01 --> Router Class Initialized
INFO - 2023-09-24 10:34:01 --> Output Class Initialized
INFO - 2023-09-24 10:34:01 --> Security Class Initialized
DEBUG - 2023-09-24 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:34:01 --> Input Class Initialized
INFO - 2023-09-24 10:34:01 --> Language Class Initialized
INFO - 2023-09-24 10:34:01 --> Loader Class Initialized
INFO - 2023-09-24 10:34:01 --> Helper loaded: url_helper
INFO - 2023-09-24 10:34:01 --> Helper loaded: file_helper
INFO - 2023-09-24 10:34:01 --> Database Driver Class Initialized
INFO - 2023-09-24 10:34:01 --> Email Class Initialized
DEBUG - 2023-09-24 10:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:34:01 --> Controller Class Initialized
INFO - 2023-09-24 10:34:01 --> Model "Services_model" initialized
INFO - 2023-09-24 10:34:01 --> Helper loaded: form_helper
INFO - 2023-09-24 10:34:01 --> Form Validation Class Initialized
INFO - 2023-09-24 10:34:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:34:01 --> Final output sent to browser
DEBUG - 2023-09-24 10:34:01 --> Total execution time: 0.1902
INFO - 2023-09-24 10:34:06 --> Config Class Initialized
INFO - 2023-09-24 10:34:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:34:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:34:06 --> Utf8 Class Initialized
INFO - 2023-09-24 10:34:06 --> URI Class Initialized
INFO - 2023-09-24 10:34:06 --> Router Class Initialized
INFO - 2023-09-24 10:34:06 --> Output Class Initialized
INFO - 2023-09-24 10:34:06 --> Security Class Initialized
DEBUG - 2023-09-24 10:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:34:06 --> Input Class Initialized
INFO - 2023-09-24 10:34:06 --> Language Class Initialized
INFO - 2023-09-24 10:34:06 --> Loader Class Initialized
INFO - 2023-09-24 10:34:06 --> Helper loaded: url_helper
INFO - 2023-09-24 10:34:06 --> Helper loaded: file_helper
INFO - 2023-09-24 10:34:06 --> Database Driver Class Initialized
INFO - 2023-09-24 10:34:06 --> Email Class Initialized
DEBUG - 2023-09-24 10:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:34:07 --> Controller Class Initialized
INFO - 2023-09-24 10:34:07 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:34:07 --> Model "Home_model" initialized
INFO - 2023-09-24 10:34:07 --> Helper loaded: download_helper
INFO - 2023-09-24 10:34:07 --> Helper loaded: form_helper
INFO - 2023-09-24 10:34:07 --> Form Validation Class Initialized
INFO - 2023-09-24 10:34:07 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:34:07 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:34:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:34:07 --> Final output sent to browser
DEBUG - 2023-09-24 10:34:07 --> Total execution time: 0.2030
INFO - 2023-09-24 10:34:40 --> Config Class Initialized
INFO - 2023-09-24 10:34:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:34:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:34:40 --> Utf8 Class Initialized
INFO - 2023-09-24 10:34:40 --> URI Class Initialized
INFO - 2023-09-24 10:34:40 --> Router Class Initialized
INFO - 2023-09-24 10:34:40 --> Output Class Initialized
INFO - 2023-09-24 10:34:40 --> Security Class Initialized
DEBUG - 2023-09-24 10:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:34:41 --> Input Class Initialized
INFO - 2023-09-24 10:34:41 --> Language Class Initialized
INFO - 2023-09-24 10:34:41 --> Loader Class Initialized
INFO - 2023-09-24 10:34:41 --> Helper loaded: url_helper
INFO - 2023-09-24 10:34:41 --> Helper loaded: file_helper
INFO - 2023-09-24 10:34:41 --> Database Driver Class Initialized
INFO - 2023-09-24 10:34:41 --> Email Class Initialized
DEBUG - 2023-09-24 10:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:34:41 --> Controller Class Initialized
INFO - 2023-09-24 10:34:41 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:34:42 --> Model "Home_model" initialized
INFO - 2023-09-24 10:34:42 --> Helper loaded: download_helper
INFO - 2023-09-24 10:34:42 --> Helper loaded: form_helper
INFO - 2023-09-24 10:34:42 --> Form Validation Class Initialized
INFO - 2023-09-24 10:34:42 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:34:42 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:34:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:34:42 --> Final output sent to browser
DEBUG - 2023-09-24 10:34:43 --> Total execution time: 2.7476
INFO - 2023-09-24 10:35:23 --> Config Class Initialized
INFO - 2023-09-24 10:35:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:35:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:35:23 --> Utf8 Class Initialized
INFO - 2023-09-24 10:35:23 --> URI Class Initialized
INFO - 2023-09-24 10:35:23 --> Router Class Initialized
INFO - 2023-09-24 10:35:23 --> Output Class Initialized
INFO - 2023-09-24 10:35:23 --> Security Class Initialized
DEBUG - 2023-09-24 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:35:24 --> Input Class Initialized
INFO - 2023-09-24 10:35:24 --> Language Class Initialized
INFO - 2023-09-24 10:35:24 --> Loader Class Initialized
INFO - 2023-09-24 10:35:24 --> Helper loaded: url_helper
INFO - 2023-09-24 10:35:24 --> Helper loaded: file_helper
INFO - 2023-09-24 10:35:24 --> Database Driver Class Initialized
INFO - 2023-09-24 10:35:24 --> Email Class Initialized
DEBUG - 2023-09-24 10:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:35:24 --> Controller Class Initialized
INFO - 2023-09-24 10:35:24 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:35:24 --> Model "Home_model" initialized
INFO - 2023-09-24 10:35:24 --> Helper loaded: download_helper
INFO - 2023-09-24 10:35:24 --> Helper loaded: form_helper
INFO - 2023-09-24 10:35:24 --> Form Validation Class Initialized
INFO - 2023-09-24 10:35:25 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:35:25 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:35:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:35:25 --> Final output sent to browser
DEBUG - 2023-09-24 10:35:25 --> Total execution time: 2.1833
INFO - 2023-09-24 10:35:48 --> Config Class Initialized
INFO - 2023-09-24 10:35:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:35:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:35:49 --> Utf8 Class Initialized
INFO - 2023-09-24 10:35:49 --> URI Class Initialized
INFO - 2023-09-24 10:35:49 --> Router Class Initialized
INFO - 2023-09-24 10:35:49 --> Output Class Initialized
INFO - 2023-09-24 10:35:49 --> Security Class Initialized
DEBUG - 2023-09-24 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:35:49 --> Input Class Initialized
INFO - 2023-09-24 10:35:49 --> Language Class Initialized
INFO - 2023-09-24 10:35:49 --> Loader Class Initialized
INFO - 2023-09-24 10:35:49 --> Helper loaded: url_helper
INFO - 2023-09-24 10:35:49 --> Helper loaded: file_helper
INFO - 2023-09-24 10:35:49 --> Database Driver Class Initialized
INFO - 2023-09-24 10:35:49 --> Email Class Initialized
DEBUG - 2023-09-24 10:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:35:50 --> Controller Class Initialized
INFO - 2023-09-24 10:35:50 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:35:50 --> Model "Home_model" initialized
INFO - 2023-09-24 10:35:50 --> Helper loaded: download_helper
INFO - 2023-09-24 10:35:50 --> Helper loaded: form_helper
INFO - 2023-09-24 10:35:50 --> Form Validation Class Initialized
INFO - 2023-09-24 10:35:50 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:35:50 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:35:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:35:51 --> Final output sent to browser
DEBUG - 2023-09-24 10:35:51 --> Total execution time: 2.2639
INFO - 2023-09-24 10:36:24 --> Config Class Initialized
INFO - 2023-09-24 10:36:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:36:24 --> Utf8 Class Initialized
INFO - 2023-09-24 10:36:24 --> URI Class Initialized
INFO - 2023-09-24 10:36:24 --> Router Class Initialized
INFO - 2023-09-24 10:36:24 --> Output Class Initialized
INFO - 2023-09-24 10:36:24 --> Security Class Initialized
DEBUG - 2023-09-24 10:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:36:25 --> Input Class Initialized
INFO - 2023-09-24 10:36:25 --> Language Class Initialized
INFO - 2023-09-24 10:36:25 --> Loader Class Initialized
INFO - 2023-09-24 10:36:25 --> Helper loaded: url_helper
INFO - 2023-09-24 10:36:25 --> Helper loaded: file_helper
INFO - 2023-09-24 10:36:25 --> Database Driver Class Initialized
INFO - 2023-09-24 10:36:25 --> Email Class Initialized
DEBUG - 2023-09-24 10:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:36:25 --> Controller Class Initialized
INFO - 2023-09-24 10:36:25 --> Model "Services_model" initialized
INFO - 2023-09-24 10:36:25 --> Helper loaded: form_helper
INFO - 2023-09-24 10:36:25 --> Form Validation Class Initialized
INFO - 2023-09-24 10:36:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:36:25 --> Final output sent to browser
DEBUG - 2023-09-24 10:36:26 --> Total execution time: 1.6088
INFO - 2023-09-24 10:36:44 --> Config Class Initialized
INFO - 2023-09-24 10:36:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:36:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:36:44 --> Utf8 Class Initialized
INFO - 2023-09-24 10:36:44 --> URI Class Initialized
INFO - 2023-09-24 10:36:44 --> Router Class Initialized
INFO - 2023-09-24 10:36:44 --> Output Class Initialized
INFO - 2023-09-24 10:36:44 --> Security Class Initialized
DEBUG - 2023-09-24 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:36:45 --> Input Class Initialized
INFO - 2023-09-24 10:36:45 --> Language Class Initialized
INFO - 2023-09-24 10:36:45 --> Loader Class Initialized
INFO - 2023-09-24 10:36:45 --> Helper loaded: url_helper
INFO - 2023-09-24 10:36:45 --> Helper loaded: file_helper
INFO - 2023-09-24 10:36:45 --> Database Driver Class Initialized
INFO - 2023-09-24 10:36:45 --> Email Class Initialized
DEBUG - 2023-09-24 10:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:36:45 --> Controller Class Initialized
INFO - 2023-09-24 10:36:45 --> Model "Services_model" initialized
INFO - 2023-09-24 10:36:45 --> Helper loaded: form_helper
INFO - 2023-09-24 10:36:45 --> Form Validation Class Initialized
INFO - 2023-09-24 10:36:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:36:46 --> Config Class Initialized
INFO - 2023-09-24 10:36:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:36:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:36:46 --> Utf8 Class Initialized
INFO - 2023-09-24 10:36:46 --> URI Class Initialized
INFO - 2023-09-24 10:36:46 --> Router Class Initialized
INFO - 2023-09-24 10:36:46 --> Output Class Initialized
INFO - 2023-09-24 10:36:46 --> Security Class Initialized
DEBUG - 2023-09-24 10:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:36:46 --> Input Class Initialized
INFO - 2023-09-24 10:36:47 --> Language Class Initialized
INFO - 2023-09-24 10:36:47 --> Loader Class Initialized
INFO - 2023-09-24 10:36:47 --> Helper loaded: url_helper
INFO - 2023-09-24 10:36:47 --> Helper loaded: file_helper
INFO - 2023-09-24 10:36:47 --> Database Driver Class Initialized
INFO - 2023-09-24 10:36:47 --> Email Class Initialized
DEBUG - 2023-09-24 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:36:47 --> Controller Class Initialized
INFO - 2023-09-24 10:36:47 --> Model "Services_model" initialized
INFO - 2023-09-24 10:36:47 --> Helper loaded: form_helper
INFO - 2023-09-24 10:36:47 --> Form Validation Class Initialized
INFO - 2023-09-24 10:36:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:36:47 --> Final output sent to browser
DEBUG - 2023-09-24 10:36:47 --> Total execution time: 1.7088
INFO - 2023-09-24 10:36:54 --> Config Class Initialized
INFO - 2023-09-24 10:36:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:36:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:36:54 --> Utf8 Class Initialized
INFO - 2023-09-24 10:36:54 --> URI Class Initialized
INFO - 2023-09-24 10:36:54 --> Router Class Initialized
INFO - 2023-09-24 10:36:54 --> Output Class Initialized
INFO - 2023-09-24 10:36:55 --> Security Class Initialized
DEBUG - 2023-09-24 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:36:55 --> Input Class Initialized
INFO - 2023-09-24 10:36:55 --> Language Class Initialized
INFO - 2023-09-24 10:36:55 --> Loader Class Initialized
INFO - 2023-09-24 10:36:55 --> Helper loaded: url_helper
INFO - 2023-09-24 10:36:55 --> Helper loaded: file_helper
INFO - 2023-09-24 10:36:55 --> Database Driver Class Initialized
INFO - 2023-09-24 10:36:55 --> Email Class Initialized
DEBUG - 2023-09-24 10:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:36:55 --> Controller Class Initialized
INFO - 2023-09-24 10:36:56 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:36:56 --> Model "Home_model" initialized
INFO - 2023-09-24 10:36:56 --> Helper loaded: download_helper
INFO - 2023-09-24 10:36:56 --> Helper loaded: form_helper
INFO - 2023-09-24 10:36:56 --> Form Validation Class Initialized
INFO - 2023-09-24 10:36:56 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:36:56 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:36:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:36:56 --> Final output sent to browser
DEBUG - 2023-09-24 10:36:57 --> Total execution time: 2.6510
INFO - 2023-09-24 10:37:11 --> Config Class Initialized
INFO - 2023-09-24 10:37:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:37:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:37:11 --> Utf8 Class Initialized
INFO - 2023-09-24 10:37:11 --> URI Class Initialized
INFO - 2023-09-24 10:37:11 --> Router Class Initialized
INFO - 2023-09-24 10:37:11 --> Output Class Initialized
INFO - 2023-09-24 10:37:11 --> Security Class Initialized
DEBUG - 2023-09-24 10:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:37:12 --> Input Class Initialized
INFO - 2023-09-24 10:37:12 --> Language Class Initialized
INFO - 2023-09-24 10:37:12 --> Loader Class Initialized
INFO - 2023-09-24 10:37:12 --> Helper loaded: url_helper
INFO - 2023-09-24 10:37:12 --> Helper loaded: file_helper
INFO - 2023-09-24 10:37:12 --> Database Driver Class Initialized
INFO - 2023-09-24 10:37:12 --> Email Class Initialized
DEBUG - 2023-09-24 10:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:37:12 --> Controller Class Initialized
INFO - 2023-09-24 10:37:13 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:37:13 --> Model "Home_model" initialized
INFO - 2023-09-24 10:37:13 --> Helper loaded: download_helper
INFO - 2023-09-24 10:37:13 --> Helper loaded: form_helper
INFO - 2023-09-24 10:37:13 --> Form Validation Class Initialized
INFO - 2023-09-24 10:37:13 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:37:13 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:37:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:37:13 --> Final output sent to browser
DEBUG - 2023-09-24 10:37:13 --> Total execution time: 2.6786
INFO - 2023-09-24 10:37:45 --> Config Class Initialized
INFO - 2023-09-24 10:37:45 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:37:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:37:45 --> Utf8 Class Initialized
INFO - 2023-09-24 10:37:45 --> URI Class Initialized
INFO - 2023-09-24 10:37:45 --> Router Class Initialized
INFO - 2023-09-24 10:37:45 --> Output Class Initialized
INFO - 2023-09-24 10:37:45 --> Security Class Initialized
DEBUG - 2023-09-24 10:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:37:45 --> Input Class Initialized
INFO - 2023-09-24 10:37:46 --> Language Class Initialized
INFO - 2023-09-24 10:37:46 --> Loader Class Initialized
INFO - 2023-09-24 10:37:46 --> Helper loaded: url_helper
INFO - 2023-09-24 10:37:46 --> Helper loaded: file_helper
INFO - 2023-09-24 10:37:46 --> Database Driver Class Initialized
INFO - 2023-09-24 10:37:46 --> Email Class Initialized
DEBUG - 2023-09-24 10:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:37:46 --> Controller Class Initialized
INFO - 2023-09-24 10:37:46 --> Model "Services_model" initialized
INFO - 2023-09-24 10:37:46 --> Helper loaded: form_helper
INFO - 2023-09-24 10:37:46 --> Form Validation Class Initialized
INFO - 2023-09-24 10:37:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:37:47 --> Final output sent to browser
DEBUG - 2023-09-24 10:37:47 --> Total execution time: 1.7896
INFO - 2023-09-24 10:38:05 --> Config Class Initialized
INFO - 2023-09-24 10:38:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:38:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:38:05 --> Utf8 Class Initialized
INFO - 2023-09-24 10:38:05 --> URI Class Initialized
INFO - 2023-09-24 10:38:05 --> Router Class Initialized
INFO - 2023-09-24 10:38:05 --> Output Class Initialized
INFO - 2023-09-24 10:38:05 --> Security Class Initialized
DEBUG - 2023-09-24 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:38:05 --> Input Class Initialized
INFO - 2023-09-24 10:38:05 --> Language Class Initialized
INFO - 2023-09-24 10:38:05 --> Loader Class Initialized
INFO - 2023-09-24 10:38:05 --> Helper loaded: url_helper
INFO - 2023-09-24 10:38:05 --> Helper loaded: file_helper
INFO - 2023-09-24 10:38:06 --> Database Driver Class Initialized
INFO - 2023-09-24 10:38:06 --> Email Class Initialized
DEBUG - 2023-09-24 10:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:38:06 --> Controller Class Initialized
INFO - 2023-09-24 10:38:06 --> Model "Services_model" initialized
INFO - 2023-09-24 10:38:06 --> Helper loaded: form_helper
INFO - 2023-09-24 10:38:06 --> Form Validation Class Initialized
INFO - 2023-09-24 10:38:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:38:06 --> Config Class Initialized
INFO - 2023-09-24 10:38:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:38:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:38:07 --> Utf8 Class Initialized
INFO - 2023-09-24 10:38:07 --> URI Class Initialized
INFO - 2023-09-24 10:38:07 --> Router Class Initialized
INFO - 2023-09-24 10:38:07 --> Output Class Initialized
INFO - 2023-09-24 10:38:07 --> Security Class Initialized
DEBUG - 2023-09-24 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:38:07 --> Input Class Initialized
INFO - 2023-09-24 10:38:07 --> Language Class Initialized
INFO - 2023-09-24 10:38:07 --> Loader Class Initialized
INFO - 2023-09-24 10:38:07 --> Helper loaded: url_helper
INFO - 2023-09-24 10:38:07 --> Helper loaded: file_helper
INFO - 2023-09-24 10:38:07 --> Database Driver Class Initialized
INFO - 2023-09-24 10:38:07 --> Email Class Initialized
DEBUG - 2023-09-24 10:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:38:08 --> Controller Class Initialized
INFO - 2023-09-24 10:38:08 --> Model "Services_model" initialized
INFO - 2023-09-24 10:38:08 --> Helper loaded: form_helper
INFO - 2023-09-24 10:38:08 --> Form Validation Class Initialized
INFO - 2023-09-24 10:38:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:38:08 --> Final output sent to browser
DEBUG - 2023-09-24 10:38:08 --> Total execution time: 1.7644
INFO - 2023-09-24 10:38:15 --> Config Class Initialized
INFO - 2023-09-24 10:38:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:38:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:38:15 --> Utf8 Class Initialized
INFO - 2023-09-24 10:38:15 --> URI Class Initialized
INFO - 2023-09-24 10:38:15 --> Router Class Initialized
INFO - 2023-09-24 10:38:15 --> Output Class Initialized
INFO - 2023-09-24 10:38:15 --> Security Class Initialized
DEBUG - 2023-09-24 10:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:38:15 --> Input Class Initialized
INFO - 2023-09-24 10:38:15 --> Language Class Initialized
INFO - 2023-09-24 10:38:16 --> Loader Class Initialized
INFO - 2023-09-24 10:38:16 --> Helper loaded: url_helper
INFO - 2023-09-24 10:38:16 --> Helper loaded: file_helper
INFO - 2023-09-24 10:38:16 --> Database Driver Class Initialized
INFO - 2023-09-24 10:38:16 --> Email Class Initialized
DEBUG - 2023-09-24 10:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:38:16 --> Controller Class Initialized
INFO - 2023-09-24 10:38:16 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:38:16 --> Model "Home_model" initialized
INFO - 2023-09-24 10:38:16 --> Helper loaded: download_helper
INFO - 2023-09-24 10:38:16 --> Helper loaded: form_helper
INFO - 2023-09-24 10:38:16 --> Form Validation Class Initialized
INFO - 2023-09-24 10:38:16 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:38:17 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:38:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:38:17 --> Final output sent to browser
DEBUG - 2023-09-24 10:38:17 --> Total execution time: 2.2228
INFO - 2023-09-24 10:38:24 --> Config Class Initialized
INFO - 2023-09-24 10:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:38:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:38:24 --> Utf8 Class Initialized
INFO - 2023-09-24 10:38:24 --> URI Class Initialized
INFO - 2023-09-24 10:38:24 --> Router Class Initialized
INFO - 2023-09-24 10:38:24 --> Output Class Initialized
INFO - 2023-09-24 10:38:24 --> Security Class Initialized
DEBUG - 2023-09-24 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:38:24 --> Input Class Initialized
INFO - 2023-09-24 10:38:25 --> Language Class Initialized
INFO - 2023-09-24 10:38:25 --> Loader Class Initialized
INFO - 2023-09-24 10:38:25 --> Helper loaded: url_helper
INFO - 2023-09-24 10:38:25 --> Helper loaded: file_helper
INFO - 2023-09-24 10:38:25 --> Database Driver Class Initialized
INFO - 2023-09-24 10:38:25 --> Email Class Initialized
DEBUG - 2023-09-24 10:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:38:25 --> Controller Class Initialized
INFO - 2023-09-24 10:38:25 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:38:25 --> Model "Home_model" initialized
INFO - 2023-09-24 10:38:25 --> Helper loaded: download_helper
INFO - 2023-09-24 10:38:25 --> Helper loaded: form_helper
INFO - 2023-09-24 10:38:25 --> Form Validation Class Initialized
INFO - 2023-09-24 10:38:25 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:38:25 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:38:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:38:26 --> Final output sent to browser
DEBUG - 2023-09-24 10:38:26 --> Total execution time: 1.9197
INFO - 2023-09-24 10:39:35 --> Config Class Initialized
INFO - 2023-09-24 10:39:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:39:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:39:35 --> Utf8 Class Initialized
INFO - 2023-09-24 10:39:35 --> URI Class Initialized
INFO - 2023-09-24 10:39:35 --> Router Class Initialized
INFO - 2023-09-24 10:39:35 --> Output Class Initialized
INFO - 2023-09-24 10:39:35 --> Security Class Initialized
DEBUG - 2023-09-24 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:39:36 --> Input Class Initialized
INFO - 2023-09-24 10:39:36 --> Language Class Initialized
INFO - 2023-09-24 10:39:36 --> Loader Class Initialized
INFO - 2023-09-24 10:39:36 --> Helper loaded: url_helper
INFO - 2023-09-24 10:39:36 --> Helper loaded: file_helper
INFO - 2023-09-24 10:39:36 --> Database Driver Class Initialized
INFO - 2023-09-24 10:39:36 --> Email Class Initialized
DEBUG - 2023-09-24 10:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:39:36 --> Controller Class Initialized
INFO - 2023-09-24 10:39:36 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:39:36 --> Model "Home_model" initialized
INFO - 2023-09-24 10:39:36 --> Helper loaded: download_helper
INFO - 2023-09-24 10:39:37 --> Helper loaded: form_helper
INFO - 2023-09-24 10:39:37 --> Form Validation Class Initialized
INFO - 2023-09-24 10:39:37 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:39:37 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:39:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:39:37 --> Final output sent to browser
DEBUG - 2023-09-24 10:39:37 --> Total execution time: 2.7785
INFO - 2023-09-24 10:39:42 --> Config Class Initialized
INFO - 2023-09-24 10:39:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:39:42 --> Utf8 Class Initialized
INFO - 2023-09-24 10:39:42 --> URI Class Initialized
INFO - 2023-09-24 10:39:42 --> Router Class Initialized
INFO - 2023-09-24 10:39:43 --> Output Class Initialized
INFO - 2023-09-24 10:39:43 --> Security Class Initialized
DEBUG - 2023-09-24 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:39:43 --> Input Class Initialized
INFO - 2023-09-24 10:39:43 --> Language Class Initialized
INFO - 2023-09-24 10:39:43 --> Loader Class Initialized
INFO - 2023-09-24 10:39:43 --> Helper loaded: url_helper
INFO - 2023-09-24 10:39:43 --> Helper loaded: file_helper
INFO - 2023-09-24 10:39:43 --> Database Driver Class Initialized
INFO - 2023-09-24 10:39:43 --> Email Class Initialized
DEBUG - 2023-09-24 10:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:39:43 --> Controller Class Initialized
INFO - 2023-09-24 10:39:44 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:39:44 --> Model "Home_model" initialized
INFO - 2023-09-24 10:39:44 --> Helper loaded: download_helper
INFO - 2023-09-24 10:39:44 --> Helper loaded: form_helper
INFO - 2023-09-24 10:39:44 --> Form Validation Class Initialized
INFO - 2023-09-24 10:39:44 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:39:44 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:39:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:39:44 --> Final output sent to browser
DEBUG - 2023-09-24 10:39:44 --> Total execution time: 2.1381
INFO - 2023-09-24 10:39:51 --> Config Class Initialized
INFO - 2023-09-24 10:39:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:39:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:39:52 --> Utf8 Class Initialized
INFO - 2023-09-24 10:39:52 --> URI Class Initialized
INFO - 2023-09-24 10:39:52 --> Router Class Initialized
INFO - 2023-09-24 10:39:52 --> Output Class Initialized
INFO - 2023-09-24 10:39:52 --> Security Class Initialized
DEBUG - 2023-09-24 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:39:52 --> Input Class Initialized
INFO - 2023-09-24 10:39:52 --> Language Class Initialized
INFO - 2023-09-24 10:39:52 --> Loader Class Initialized
INFO - 2023-09-24 10:39:52 --> Helper loaded: url_helper
INFO - 2023-09-24 10:39:52 --> Helper loaded: file_helper
INFO - 2023-09-24 10:39:53 --> Database Driver Class Initialized
INFO - 2023-09-24 10:39:53 --> Email Class Initialized
DEBUG - 2023-09-24 10:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:39:53 --> Controller Class Initialized
INFO - 2023-09-24 10:39:53 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:39:53 --> Model "Home_model" initialized
INFO - 2023-09-24 10:39:53 --> Helper loaded: download_helper
INFO - 2023-09-24 10:39:53 --> Helper loaded: form_helper
INFO - 2023-09-24 10:39:53 --> Form Validation Class Initialized
INFO - 2023-09-24 10:39:54 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:39:54 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:39:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:39:54 --> Final output sent to browser
DEBUG - 2023-09-24 10:39:54 --> Total execution time: 2.7980
INFO - 2023-09-24 10:40:00 --> Config Class Initialized
INFO - 2023-09-24 10:40:00 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:40:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:40:01 --> Utf8 Class Initialized
INFO - 2023-09-24 10:40:01 --> URI Class Initialized
INFO - 2023-09-24 10:40:01 --> Router Class Initialized
INFO - 2023-09-24 10:40:01 --> Output Class Initialized
INFO - 2023-09-24 10:40:01 --> Security Class Initialized
DEBUG - 2023-09-24 10:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:40:01 --> Input Class Initialized
INFO - 2023-09-24 10:40:01 --> Language Class Initialized
INFO - 2023-09-24 10:40:01 --> Loader Class Initialized
INFO - 2023-09-24 10:40:01 --> Helper loaded: url_helper
INFO - 2023-09-24 10:40:01 --> Helper loaded: file_helper
INFO - 2023-09-24 10:40:01 --> Database Driver Class Initialized
INFO - 2023-09-24 10:40:01 --> Email Class Initialized
DEBUG - 2023-09-24 10:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:40:02 --> Controller Class Initialized
INFO - 2023-09-24 10:40:02 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:40:02 --> Model "Home_model" initialized
INFO - 2023-09-24 10:40:02 --> Helper loaded: download_helper
INFO - 2023-09-24 10:40:02 --> Helper loaded: form_helper
INFO - 2023-09-24 10:40:02 --> Form Validation Class Initialized
INFO - 2023-09-24 10:40:02 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:40:02 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:40:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:40:02 --> Final output sent to browser
DEBUG - 2023-09-24 10:40:02 --> Total execution time: 2.0500
INFO - 2023-09-24 10:40:16 --> Config Class Initialized
INFO - 2023-09-24 10:40:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:40:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:40:17 --> Utf8 Class Initialized
INFO - 2023-09-24 10:40:17 --> URI Class Initialized
INFO - 2023-09-24 10:40:17 --> Router Class Initialized
INFO - 2023-09-24 10:40:17 --> Output Class Initialized
INFO - 2023-09-24 10:40:17 --> Security Class Initialized
DEBUG - 2023-09-24 10:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:40:17 --> Input Class Initialized
INFO - 2023-09-24 10:40:17 --> Language Class Initialized
INFO - 2023-09-24 10:40:17 --> Loader Class Initialized
INFO - 2023-09-24 10:40:17 --> Helper loaded: url_helper
INFO - 2023-09-24 10:40:17 --> Helper loaded: file_helper
INFO - 2023-09-24 10:40:17 --> Database Driver Class Initialized
INFO - 2023-09-24 10:40:17 --> Email Class Initialized
DEBUG - 2023-09-24 10:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:40:18 --> Controller Class Initialized
INFO - 2023-09-24 10:40:18 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:40:18 --> Model "Home_model" initialized
INFO - 2023-09-24 10:40:18 --> Helper loaded: download_helper
INFO - 2023-09-24 10:40:18 --> Helper loaded: form_helper
INFO - 2023-09-24 10:40:18 --> Form Validation Class Initialized
INFO - 2023-09-24 10:40:18 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:40:18 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:40:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:40:18 --> Final output sent to browser
DEBUG - 2023-09-24 10:40:18 --> Total execution time: 1.9514
INFO - 2023-09-24 10:40:26 --> Config Class Initialized
INFO - 2023-09-24 10:40:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:40:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:40:26 --> Utf8 Class Initialized
INFO - 2023-09-24 10:40:26 --> URI Class Initialized
INFO - 2023-09-24 10:40:26 --> Router Class Initialized
INFO - 2023-09-24 10:40:26 --> Output Class Initialized
INFO - 2023-09-24 10:40:26 --> Security Class Initialized
DEBUG - 2023-09-24 10:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:40:26 --> Input Class Initialized
INFO - 2023-09-24 10:40:27 --> Language Class Initialized
INFO - 2023-09-24 10:40:27 --> Loader Class Initialized
INFO - 2023-09-24 10:40:27 --> Helper loaded: url_helper
INFO - 2023-09-24 10:40:27 --> Helper loaded: file_helper
INFO - 2023-09-24 10:40:27 --> Database Driver Class Initialized
INFO - 2023-09-24 10:40:27 --> Email Class Initialized
DEBUG - 2023-09-24 10:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:40:27 --> Controller Class Initialized
INFO - 2023-09-24 10:40:27 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:40:27 --> Model "Home_model" initialized
INFO - 2023-09-24 10:40:27 --> Helper loaded: download_helper
INFO - 2023-09-24 10:40:27 --> Helper loaded: form_helper
INFO - 2023-09-24 10:40:28 --> Form Validation Class Initialized
INFO - 2023-09-24 10:40:28 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:40:28 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:40:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:40:28 --> Final output sent to browser
DEBUG - 2023-09-24 10:40:28 --> Total execution time: 2.3046
INFO - 2023-09-24 10:40:34 --> Config Class Initialized
INFO - 2023-09-24 10:40:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:40:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:40:34 --> Utf8 Class Initialized
INFO - 2023-09-24 10:40:34 --> URI Class Initialized
INFO - 2023-09-24 10:40:34 --> Router Class Initialized
INFO - 2023-09-24 10:40:34 --> Output Class Initialized
INFO - 2023-09-24 10:40:34 --> Security Class Initialized
DEBUG - 2023-09-24 10:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:40:34 --> Input Class Initialized
INFO - 2023-09-24 10:40:34 --> Language Class Initialized
INFO - 2023-09-24 10:40:34 --> Loader Class Initialized
INFO - 2023-09-24 10:40:34 --> Helper loaded: url_helper
INFO - 2023-09-24 10:40:34 --> Helper loaded: file_helper
INFO - 2023-09-24 10:40:34 --> Database Driver Class Initialized
INFO - 2023-09-24 10:40:34 --> Email Class Initialized
DEBUG - 2023-09-24 10:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:40:34 --> Controller Class Initialized
INFO - 2023-09-24 10:40:34 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:40:34 --> Model "Home_model" initialized
INFO - 2023-09-24 10:40:34 --> Helper loaded: download_helper
INFO - 2023-09-24 10:40:34 --> Helper loaded: form_helper
INFO - 2023-09-24 10:40:34 --> Form Validation Class Initialized
INFO - 2023-09-24 10:40:34 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:40:34 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:40:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:40:34 --> Final output sent to browser
DEBUG - 2023-09-24 10:40:34 --> Total execution time: 0.0640
INFO - 2023-09-24 10:40:40 --> Config Class Initialized
INFO - 2023-09-24 10:40:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:40:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:40:40 --> Utf8 Class Initialized
INFO - 2023-09-24 10:40:40 --> URI Class Initialized
INFO - 2023-09-24 10:40:40 --> Router Class Initialized
INFO - 2023-09-24 10:40:40 --> Output Class Initialized
INFO - 2023-09-24 10:40:40 --> Security Class Initialized
DEBUG - 2023-09-24 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:40:40 --> Input Class Initialized
INFO - 2023-09-24 10:40:40 --> Language Class Initialized
INFO - 2023-09-24 10:40:40 --> Loader Class Initialized
INFO - 2023-09-24 10:40:40 --> Helper loaded: url_helper
INFO - 2023-09-24 10:40:40 --> Helper loaded: file_helper
INFO - 2023-09-24 10:40:40 --> Database Driver Class Initialized
INFO - 2023-09-24 10:40:40 --> Email Class Initialized
DEBUG - 2023-09-24 10:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:40:40 --> Controller Class Initialized
INFO - 2023-09-24 10:40:40 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:40:40 --> Model "Home_model" initialized
INFO - 2023-09-24 10:40:40 --> Helper loaded: download_helper
INFO - 2023-09-24 10:40:40 --> Helper loaded: form_helper
INFO - 2023-09-24 10:40:40 --> Form Validation Class Initialized
INFO - 2023-09-24 10:40:40 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:40:40 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:40:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:40:40 --> Final output sent to browser
DEBUG - 2023-09-24 10:40:40 --> Total execution time: 0.0664
INFO - 2023-09-24 10:48:23 --> Config Class Initialized
INFO - 2023-09-24 10:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:48:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:48:24 --> Utf8 Class Initialized
INFO - 2023-09-24 10:48:24 --> URI Class Initialized
INFO - 2023-09-24 10:48:24 --> Router Class Initialized
INFO - 2023-09-24 10:48:24 --> Output Class Initialized
INFO - 2023-09-24 10:48:24 --> Security Class Initialized
DEBUG - 2023-09-24 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:48:24 --> Input Class Initialized
INFO - 2023-09-24 10:48:24 --> Language Class Initialized
INFO - 2023-09-24 10:48:24 --> Loader Class Initialized
INFO - 2023-09-24 10:48:24 --> Helper loaded: url_helper
INFO - 2023-09-24 10:48:25 --> Helper loaded: file_helper
INFO - 2023-09-24 10:48:25 --> Database Driver Class Initialized
INFO - 2023-09-24 10:48:25 --> Email Class Initialized
DEBUG - 2023-09-24 10:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:48:25 --> Controller Class Initialized
INFO - 2023-09-24 10:48:25 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:48:25 --> Model "Home_model" initialized
INFO - 2023-09-24 10:48:25 --> Helper loaded: download_helper
INFO - 2023-09-24 10:48:25 --> Helper loaded: form_helper
INFO - 2023-09-24 10:48:25 --> Form Validation Class Initialized
INFO - 2023-09-24 10:48:25 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:48:25 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:48:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:48:25 --> Final output sent to browser
DEBUG - 2023-09-24 10:48:25 --> Total execution time: 2.3008
INFO - 2023-09-24 10:48:43 --> Config Class Initialized
INFO - 2023-09-24 10:48:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:48:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:48:44 --> Utf8 Class Initialized
INFO - 2023-09-24 10:48:44 --> URI Class Initialized
INFO - 2023-09-24 10:48:44 --> Router Class Initialized
INFO - 2023-09-24 10:48:44 --> Output Class Initialized
INFO - 2023-09-24 10:48:44 --> Security Class Initialized
DEBUG - 2023-09-24 10:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:48:44 --> Input Class Initialized
INFO - 2023-09-24 10:48:44 --> Language Class Initialized
INFO - 2023-09-24 10:48:44 --> Loader Class Initialized
INFO - 2023-09-24 10:48:44 --> Helper loaded: url_helper
INFO - 2023-09-24 10:48:44 --> Helper loaded: file_helper
INFO - 2023-09-24 10:48:44 --> Database Driver Class Initialized
INFO - 2023-09-24 10:48:44 --> Email Class Initialized
DEBUG - 2023-09-24 10:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:48:45 --> Controller Class Initialized
INFO - 2023-09-24 10:48:45 --> Model "Services_model" initialized
INFO - 2023-09-24 10:48:45 --> Helper loaded: form_helper
INFO - 2023-09-24 10:48:45 --> Form Validation Class Initialized
INFO - 2023-09-24 10:48:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:48:45 --> Final output sent to browser
DEBUG - 2023-09-24 10:48:45 --> Total execution time: 1.8624
INFO - 2023-09-24 10:49:02 --> Config Class Initialized
INFO - 2023-09-24 10:49:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:02 --> URI Class Initialized
INFO - 2023-09-24 10:49:02 --> Router Class Initialized
INFO - 2023-09-24 10:49:02 --> Output Class Initialized
INFO - 2023-09-24 10:49:02 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:02 --> Input Class Initialized
INFO - 2023-09-24 10:49:02 --> Language Class Initialized
INFO - 2023-09-24 10:49:02 --> Loader Class Initialized
INFO - 2023-09-24 10:49:02 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:02 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:02 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:02 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:02 --> Controller Class Initialized
INFO - 2023-09-24 10:49:02 --> Model "Services_model" initialized
INFO - 2023-09-24 10:49:02 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:02 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:49:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:49:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:49:03 --> Final output sent to browser
DEBUG - 2023-09-24 10:49:03 --> Total execution time: 0.7414
INFO - 2023-09-24 10:49:10 --> Config Class Initialized
INFO - 2023-09-24 10:49:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:10 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:10 --> URI Class Initialized
INFO - 2023-09-24 10:49:10 --> Router Class Initialized
INFO - 2023-09-24 10:49:10 --> Output Class Initialized
INFO - 2023-09-24 10:49:10 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:10 --> Input Class Initialized
INFO - 2023-09-24 10:49:10 --> Language Class Initialized
INFO - 2023-09-24 10:49:10 --> Loader Class Initialized
INFO - 2023-09-24 10:49:10 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:10 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:10 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:10 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:10 --> Controller Class Initialized
INFO - 2023-09-24 10:49:10 --> Model "Services_model" initialized
INFO - 2023-09-24 10:49:10 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:10 --> Form Validation Class Initialized
INFO - 2023-09-24 10:49:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:49:10 --> Config Class Initialized
INFO - 2023-09-24 10:49:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:10 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:10 --> URI Class Initialized
INFO - 2023-09-24 10:49:10 --> Router Class Initialized
INFO - 2023-09-24 10:49:10 --> Output Class Initialized
INFO - 2023-09-24 10:49:10 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:10 --> Input Class Initialized
INFO - 2023-09-24 10:49:10 --> Language Class Initialized
INFO - 2023-09-24 10:49:10 --> Loader Class Initialized
INFO - 2023-09-24 10:49:10 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:10 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:10 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:10 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:10 --> Controller Class Initialized
INFO - 2023-09-24 10:49:10 --> Model "Services_model" initialized
INFO - 2023-09-24 10:49:10 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:10 --> Form Validation Class Initialized
INFO - 2023-09-24 10:49:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:49:10 --> Final output sent to browser
DEBUG - 2023-09-24 10:49:10 --> Total execution time: 0.0611
INFO - 2023-09-24 10:49:14 --> Config Class Initialized
INFO - 2023-09-24 10:49:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:14 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:14 --> URI Class Initialized
INFO - 2023-09-24 10:49:14 --> Router Class Initialized
INFO - 2023-09-24 10:49:14 --> Output Class Initialized
INFO - 2023-09-24 10:49:14 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:14 --> Input Class Initialized
INFO - 2023-09-24 10:49:14 --> Language Class Initialized
INFO - 2023-09-24 10:49:14 --> Loader Class Initialized
INFO - 2023-09-24 10:49:14 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:14 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:14 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:14 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:14 --> Controller Class Initialized
INFO - 2023-09-24 10:49:14 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:49:14 --> Model "Home_model" initialized
INFO - 2023-09-24 10:49:14 --> Helper loaded: download_helper
INFO - 2023-09-24 10:49:14 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:14 --> Form Validation Class Initialized
INFO - 2023-09-24 10:49:14 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:49:14 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:49:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:49:14 --> Final output sent to browser
DEBUG - 2023-09-24 10:49:14 --> Total execution time: 0.2859
INFO - 2023-09-24 10:49:29 --> Config Class Initialized
INFO - 2023-09-24 10:49:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:29 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:29 --> URI Class Initialized
INFO - 2023-09-24 10:49:29 --> Router Class Initialized
INFO - 2023-09-24 10:49:29 --> Output Class Initialized
INFO - 2023-09-24 10:49:29 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:30 --> Input Class Initialized
INFO - 2023-09-24 10:49:30 --> Language Class Initialized
INFO - 2023-09-24 10:49:31 --> Loader Class Initialized
INFO - 2023-09-24 10:49:31 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:31 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:31 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:31 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:31 --> Controller Class Initialized
INFO - 2023-09-24 10:49:31 --> Model "Services_model" initialized
INFO - 2023-09-24 10:49:31 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:31 --> Form Validation Class Initialized
INFO - 2023-09-24 10:49:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:49:31 --> Final output sent to browser
DEBUG - 2023-09-24 10:49:31 --> Total execution time: 2.9427
INFO - 2023-09-24 10:49:53 --> Config Class Initialized
INFO - 2023-09-24 10:49:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:49:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:49:54 --> Utf8 Class Initialized
INFO - 2023-09-24 10:49:54 --> URI Class Initialized
INFO - 2023-09-24 10:49:54 --> Router Class Initialized
INFO - 2023-09-24 10:49:54 --> Output Class Initialized
INFO - 2023-09-24 10:49:54 --> Security Class Initialized
DEBUG - 2023-09-24 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:49:54 --> Input Class Initialized
INFO - 2023-09-24 10:49:54 --> Language Class Initialized
INFO - 2023-09-24 10:49:54 --> Loader Class Initialized
INFO - 2023-09-24 10:49:54 --> Helper loaded: url_helper
INFO - 2023-09-24 10:49:54 --> Helper loaded: file_helper
INFO - 2023-09-24 10:49:55 --> Database Driver Class Initialized
INFO - 2023-09-24 10:49:55 --> Email Class Initialized
DEBUG - 2023-09-24 10:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:49:55 --> Controller Class Initialized
INFO - 2023-09-24 10:49:55 --> Model "Services_model" initialized
INFO - 2023-09-24 10:49:55 --> Helper loaded: form_helper
INFO - 2023-09-24 10:49:55 --> Form Validation Class Initialized
ERROR - 2023-09-24 10:49:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 10:49:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 10:49:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 10:49:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 10:49:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 10:49:58 --> Final output sent to browser
DEBUG - 2023-09-24 10:49:58 --> Total execution time: 4.4352
INFO - 2023-09-24 10:50:03 --> Config Class Initialized
INFO - 2023-09-24 10:50:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:50:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:50:03 --> Utf8 Class Initialized
INFO - 2023-09-24 10:50:03 --> URI Class Initialized
INFO - 2023-09-24 10:50:03 --> Router Class Initialized
INFO - 2023-09-24 10:50:03 --> Output Class Initialized
INFO - 2023-09-24 10:50:03 --> Security Class Initialized
DEBUG - 2023-09-24 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:50:04 --> Input Class Initialized
INFO - 2023-09-24 10:50:04 --> Language Class Initialized
INFO - 2023-09-24 10:50:04 --> Loader Class Initialized
INFO - 2023-09-24 10:50:04 --> Helper loaded: url_helper
INFO - 2023-09-24 10:50:04 --> Helper loaded: file_helper
INFO - 2023-09-24 10:50:04 --> Database Driver Class Initialized
INFO - 2023-09-24 10:50:04 --> Email Class Initialized
DEBUG - 2023-09-24 10:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:50:04 --> Controller Class Initialized
INFO - 2023-09-24 10:50:04 --> Model "Services_model" initialized
INFO - 2023-09-24 10:50:04 --> Helper loaded: form_helper
INFO - 2023-09-24 10:50:04 --> Form Validation Class Initialized
INFO - 2023-09-24 10:50:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 10:50:04 --> Config Class Initialized
INFO - 2023-09-24 10:50:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:50:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:50:04 --> Utf8 Class Initialized
INFO - 2023-09-24 10:50:04 --> URI Class Initialized
INFO - 2023-09-24 10:50:04 --> Router Class Initialized
INFO - 2023-09-24 10:50:04 --> Output Class Initialized
INFO - 2023-09-24 10:50:04 --> Security Class Initialized
DEBUG - 2023-09-24 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:50:05 --> Input Class Initialized
INFO - 2023-09-24 10:50:05 --> Language Class Initialized
INFO - 2023-09-24 10:50:05 --> Loader Class Initialized
INFO - 2023-09-24 10:50:05 --> Helper loaded: url_helper
INFO - 2023-09-24 10:50:05 --> Helper loaded: file_helper
INFO - 2023-09-24 10:50:05 --> Database Driver Class Initialized
INFO - 2023-09-24 10:50:05 --> Email Class Initialized
DEBUG - 2023-09-24 10:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:50:05 --> Controller Class Initialized
INFO - 2023-09-24 10:50:05 --> Model "Services_model" initialized
INFO - 2023-09-24 10:50:05 --> Helper loaded: form_helper
INFO - 2023-09-24 10:50:05 --> Form Validation Class Initialized
INFO - 2023-09-24 10:50:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 10:50:05 --> Final output sent to browser
DEBUG - 2023-09-24 10:50:06 --> Total execution time: 1.5883
INFO - 2023-09-24 10:50:10 --> Config Class Initialized
INFO - 2023-09-24 10:50:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:50:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:50:11 --> Utf8 Class Initialized
INFO - 2023-09-24 10:50:11 --> URI Class Initialized
INFO - 2023-09-24 10:50:11 --> Router Class Initialized
INFO - 2023-09-24 10:50:11 --> Output Class Initialized
INFO - 2023-09-24 10:50:11 --> Security Class Initialized
DEBUG - 2023-09-24 10:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:50:11 --> Input Class Initialized
INFO - 2023-09-24 10:50:11 --> Language Class Initialized
INFO - 2023-09-24 10:50:11 --> Loader Class Initialized
INFO - 2023-09-24 10:50:11 --> Helper loaded: url_helper
INFO - 2023-09-24 10:50:11 --> Helper loaded: file_helper
INFO - 2023-09-24 10:50:12 --> Database Driver Class Initialized
INFO - 2023-09-24 10:50:12 --> Email Class Initialized
DEBUG - 2023-09-24 10:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:50:12 --> Controller Class Initialized
INFO - 2023-09-24 10:50:12 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:50:12 --> Model "Home_model" initialized
INFO - 2023-09-24 10:50:12 --> Helper loaded: download_helper
INFO - 2023-09-24 10:50:12 --> Helper loaded: form_helper
INFO - 2023-09-24 10:50:12 --> Form Validation Class Initialized
INFO - 2023-09-24 10:50:12 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:50:12 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:50:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:50:12 --> Final output sent to browser
DEBUG - 2023-09-24 10:50:13 --> Total execution time: 2.2101
INFO - 2023-09-24 10:58:30 --> Config Class Initialized
INFO - 2023-09-24 10:58:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:58:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:58:30 --> Utf8 Class Initialized
INFO - 2023-09-24 10:58:30 --> URI Class Initialized
INFO - 2023-09-24 10:58:30 --> Router Class Initialized
INFO - 2023-09-24 10:58:30 --> Output Class Initialized
INFO - 2023-09-24 10:58:30 --> Security Class Initialized
DEBUG - 2023-09-24 10:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:58:30 --> Input Class Initialized
INFO - 2023-09-24 10:58:30 --> Language Class Initialized
INFO - 2023-09-24 10:58:30 --> Loader Class Initialized
INFO - 2023-09-24 10:58:30 --> Helper loaded: url_helper
INFO - 2023-09-24 10:58:30 --> Helper loaded: file_helper
INFO - 2023-09-24 10:58:31 --> Database Driver Class Initialized
INFO - 2023-09-24 10:58:31 --> Email Class Initialized
DEBUG - 2023-09-24 10:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:58:31 --> Controller Class Initialized
INFO - 2023-09-24 10:58:31 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:58:31 --> Model "Home_model" initialized
INFO - 2023-09-24 10:58:31 --> Helper loaded: download_helper
INFO - 2023-09-24 10:58:31 --> Helper loaded: form_helper
INFO - 2023-09-24 10:58:31 --> Form Validation Class Initialized
INFO - 2023-09-24 10:58:31 --> Helper loaded: custom_helper
INFO - 2023-09-24 10:58:32 --> Model "Social_media_model" initialized
INFO - 2023-09-24 10:58:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 10:58:32 --> Final output sent to browser
DEBUG - 2023-09-24 10:58:33 --> Total execution time: 2.9665
INFO - 2023-09-24 10:59:02 --> Config Class Initialized
INFO - 2023-09-24 10:59:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 10:59:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 10:59:02 --> Utf8 Class Initialized
INFO - 2023-09-24 10:59:02 --> URI Class Initialized
INFO - 2023-09-24 10:59:02 --> Router Class Initialized
INFO - 2023-09-24 10:59:02 --> Output Class Initialized
INFO - 2023-09-24 10:59:02 --> Security Class Initialized
DEBUG - 2023-09-24 10:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 10:59:02 --> Input Class Initialized
INFO - 2023-09-24 10:59:02 --> Language Class Initialized
INFO - 2023-09-24 10:59:02 --> Loader Class Initialized
INFO - 2023-09-24 10:59:02 --> Helper loaded: url_helper
INFO - 2023-09-24 10:59:02 --> Helper loaded: file_helper
INFO - 2023-09-24 10:59:02 --> Database Driver Class Initialized
INFO - 2023-09-24 10:59:02 --> Email Class Initialized
DEBUG - 2023-09-24 10:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 10:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 10:59:03 --> Controller Class Initialized
INFO - 2023-09-24 10:59:03 --> Model "Contact_model" initialized
INFO - 2023-09-24 10:59:03 --> Model "Home_model" initialized
INFO - 2023-09-24 10:59:03 --> Helper loaded: download_helper
INFO - 2023-09-24 10:59:03 --> Helper loaded: form_helper
INFO - 2023-09-24 10:59:03 --> Form Validation Class Initialized
INFO - 2023-09-24 11:23:05 --> Config Class Initialized
INFO - 2023-09-24 11:23:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:23:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:23:05 --> Utf8 Class Initialized
INFO - 2023-09-24 11:23:05 --> URI Class Initialized
INFO - 2023-09-24 11:23:05 --> Router Class Initialized
INFO - 2023-09-24 11:23:06 --> Output Class Initialized
INFO - 2023-09-24 11:23:06 --> Security Class Initialized
DEBUG - 2023-09-24 11:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:23:06 --> Input Class Initialized
INFO - 2023-09-24 11:23:06 --> Language Class Initialized
INFO - 2023-09-24 11:23:06 --> Loader Class Initialized
INFO - 2023-09-24 11:23:06 --> Helper loaded: url_helper
INFO - 2023-09-24 11:23:06 --> Helper loaded: file_helper
INFO - 2023-09-24 11:23:06 --> Database Driver Class Initialized
INFO - 2023-09-24 11:23:06 --> Email Class Initialized
DEBUG - 2023-09-24 11:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:23:07 --> Controller Class Initialized
INFO - 2023-09-24 11:23:07 --> Model "Services_model" initialized
INFO - 2023-09-24 11:23:07 --> Helper loaded: form_helper
INFO - 2023-09-24 11:23:07 --> Form Validation Class Initialized
INFO - 2023-09-24 11:23:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 11:23:07 --> Final output sent to browser
DEBUG - 2023-09-24 11:23:07 --> Total execution time: 2.1764
INFO - 2023-09-24 11:23:09 --> Config Class Initialized
INFO - 2023-09-24 11:23:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:23:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:23:09 --> Utf8 Class Initialized
INFO - 2023-09-24 11:23:09 --> URI Class Initialized
INFO - 2023-09-24 11:23:09 --> Router Class Initialized
INFO - 2023-09-24 11:23:09 --> Output Class Initialized
INFO - 2023-09-24 11:23:10 --> Security Class Initialized
DEBUG - 2023-09-24 11:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:23:10 --> Input Class Initialized
INFO - 2023-09-24 11:23:10 --> Language Class Initialized
ERROR - 2023-09-24 11:23:10 --> 404 Page Not Found: Assets/images
INFO - 2023-09-24 11:23:15 --> Config Class Initialized
INFO - 2023-09-24 11:23:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:23:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:23:15 --> Utf8 Class Initialized
INFO - 2023-09-24 11:23:15 --> URI Class Initialized
INFO - 2023-09-24 11:23:15 --> Router Class Initialized
INFO - 2023-09-24 11:23:15 --> Output Class Initialized
INFO - 2023-09-24 11:23:15 --> Security Class Initialized
DEBUG - 2023-09-24 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:23:15 --> Input Class Initialized
INFO - 2023-09-24 11:23:15 --> Language Class Initialized
INFO - 2023-09-24 11:23:15 --> Loader Class Initialized
INFO - 2023-09-24 11:23:15 --> Helper loaded: url_helper
INFO - 2023-09-24 11:23:15 --> Helper loaded: file_helper
INFO - 2023-09-24 11:23:15 --> Database Driver Class Initialized
INFO - 2023-09-24 11:23:15 --> Email Class Initialized
DEBUG - 2023-09-24 11:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 11:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:23:16 --> Controller Class Initialized
INFO - 2023-09-24 11:23:16 --> Model "Services_model" initialized
INFO - 2023-09-24 11:23:16 --> Helper loaded: form_helper
INFO - 2023-09-24 11:23:16 --> Form Validation Class Initialized
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-24 11:23:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-24 11:23:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-24 11:23:16 --> Final output sent to browser
DEBUG - 2023-09-24 11:23:16 --> Total execution time: 0.1685
INFO - 2023-09-24 11:23:27 --> Config Class Initialized
INFO - 2023-09-24 11:23:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:23:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:23:27 --> Utf8 Class Initialized
INFO - 2023-09-24 11:23:27 --> URI Class Initialized
INFO - 2023-09-24 11:23:28 --> Router Class Initialized
INFO - 2023-09-24 11:23:28 --> Output Class Initialized
INFO - 2023-09-24 11:23:28 --> Security Class Initialized
DEBUG - 2023-09-24 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:23:28 --> Input Class Initialized
INFO - 2023-09-24 11:23:28 --> Language Class Initialized
INFO - 2023-09-24 11:23:28 --> Loader Class Initialized
INFO - 2023-09-24 11:23:28 --> Helper loaded: url_helper
INFO - 2023-09-24 11:23:28 --> Helper loaded: file_helper
INFO - 2023-09-24 11:23:28 --> Database Driver Class Initialized
INFO - 2023-09-24 11:23:28 --> Email Class Initialized
DEBUG - 2023-09-24 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:23:28 --> Controller Class Initialized
INFO - 2023-09-24 11:23:28 --> Model "Services_model" initialized
INFO - 2023-09-24 11:23:28 --> Helper loaded: form_helper
INFO - 2023-09-24 11:23:28 --> Form Validation Class Initialized
INFO - 2023-09-24 11:23:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-24 11:23:28 --> Config Class Initialized
INFO - 2023-09-24 11:23:28 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:23:28 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:23:28 --> Utf8 Class Initialized
INFO - 2023-09-24 11:23:28 --> URI Class Initialized
INFO - 2023-09-24 11:23:28 --> Router Class Initialized
INFO - 2023-09-24 11:23:28 --> Output Class Initialized
INFO - 2023-09-24 11:23:28 --> Security Class Initialized
DEBUG - 2023-09-24 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:23:28 --> Input Class Initialized
INFO - 2023-09-24 11:23:28 --> Language Class Initialized
INFO - 2023-09-24 11:23:28 --> Loader Class Initialized
INFO - 2023-09-24 11:23:28 --> Helper loaded: url_helper
INFO - 2023-09-24 11:23:28 --> Helper loaded: file_helper
INFO - 2023-09-24 11:23:28 --> Database Driver Class Initialized
INFO - 2023-09-24 11:23:28 --> Email Class Initialized
DEBUG - 2023-09-24 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:23:28 --> Controller Class Initialized
INFO - 2023-09-24 11:23:28 --> Model "Services_model" initialized
INFO - 2023-09-24 11:23:28 --> Helper loaded: form_helper
INFO - 2023-09-24 11:23:28 --> Form Validation Class Initialized
INFO - 2023-09-24 11:23:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-24 11:23:29 --> Final output sent to browser
DEBUG - 2023-09-24 11:23:29 --> Total execution time: 0.8286
INFO - 2023-09-24 12:59:44 --> Config Class Initialized
INFO - 2023-09-24 12:59:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:59:45 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:59:45 --> Utf8 Class Initialized
INFO - 2023-09-24 12:59:45 --> URI Class Initialized
INFO - 2023-09-24 12:59:45 --> Router Class Initialized
INFO - 2023-09-24 12:59:46 --> Output Class Initialized
INFO - 2023-09-24 12:59:46 --> Security Class Initialized
DEBUG - 2023-09-24 12:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:59:46 --> Input Class Initialized
INFO - 2023-09-24 12:59:47 --> Language Class Initialized
INFO - 2023-09-24 12:59:48 --> Loader Class Initialized
INFO - 2023-09-24 12:59:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:59:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:59:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:59:50 --> Email Class Initialized
DEBUG - 2023-09-24 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:59:51 --> Controller Class Initialized
INFO - 2023-09-24 12:59:51 --> Model "Contact_model" initialized
INFO - 2023-09-24 12:59:52 --> Model "Home_model" initialized
INFO - 2023-09-24 12:59:52 --> Helper loaded: download_helper
INFO - 2023-09-24 12:59:52 --> Helper loaded: form_helper
INFO - 2023-09-24 12:59:52 --> Form Validation Class Initialized
INFO - 2023-09-24 12:59:53 --> Helper loaded: custom_helper
INFO - 2023-09-24 12:59:53 --> Model "Social_media_model" initialized
INFO - 2023-09-24 12:59:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 12:59:54 --> Final output sent to browser
DEBUG - 2023-09-24 12:59:54 --> Total execution time: 10.0485
INFO - 2023-09-24 13:44:55 --> Config Class Initialized
INFO - 2023-09-24 13:44:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:44:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:44:55 --> Utf8 Class Initialized
INFO - 2023-09-24 13:44:55 --> URI Class Initialized
INFO - 2023-09-24 13:44:55 --> Router Class Initialized
INFO - 2023-09-24 13:44:55 --> Output Class Initialized
INFO - 2023-09-24 13:44:55 --> Security Class Initialized
DEBUG - 2023-09-24 13:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:44:55 --> Input Class Initialized
INFO - 2023-09-24 13:44:55 --> Language Class Initialized
INFO - 2023-09-24 13:44:55 --> Loader Class Initialized
INFO - 2023-09-24 13:44:55 --> Helper loaded: url_helper
INFO - 2023-09-24 13:44:55 --> Helper loaded: file_helper
INFO - 2023-09-24 13:44:55 --> Database Driver Class Initialized
INFO - 2023-09-24 13:44:55 --> Email Class Initialized
DEBUG - 2023-09-24 13:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:44:55 --> Controller Class Initialized
INFO - 2023-09-24 13:44:55 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:44:55 --> Model "Home_model" initialized
INFO - 2023-09-24 13:44:55 --> Helper loaded: download_helper
INFO - 2023-09-24 13:44:55 --> Helper loaded: form_helper
INFO - 2023-09-24 13:44:55 --> Form Validation Class Initialized
INFO - 2023-09-24 13:44:56 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:44:56 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:44:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:44:56 --> Final output sent to browser
DEBUG - 2023-09-24 13:44:56 --> Total execution time: 1.6179
INFO - 2023-09-24 13:45:10 --> Config Class Initialized
INFO - 2023-09-24 13:45:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:45:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:45:10 --> Utf8 Class Initialized
INFO - 2023-09-24 13:45:10 --> URI Class Initialized
INFO - 2023-09-24 13:45:10 --> Router Class Initialized
INFO - 2023-09-24 13:45:10 --> Output Class Initialized
INFO - 2023-09-24 13:45:10 --> Security Class Initialized
DEBUG - 2023-09-24 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:45:10 --> Input Class Initialized
INFO - 2023-09-24 13:45:10 --> Language Class Initialized
INFO - 2023-09-24 13:45:10 --> Loader Class Initialized
INFO - 2023-09-24 13:45:10 --> Helper loaded: url_helper
INFO - 2023-09-24 13:45:10 --> Helper loaded: file_helper
INFO - 2023-09-24 13:45:10 --> Database Driver Class Initialized
INFO - 2023-09-24 13:45:10 --> Email Class Initialized
DEBUG - 2023-09-24 13:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:45:10 --> Controller Class Initialized
INFO - 2023-09-24 13:45:10 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:45:10 --> Model "Home_model" initialized
INFO - 2023-09-24 13:45:10 --> Helper loaded: download_helper
INFO - 2023-09-24 13:45:10 --> Helper loaded: form_helper
INFO - 2023-09-24 13:45:10 --> Form Validation Class Initialized
INFO - 2023-09-24 13:45:10 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:45:10 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:45:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:45:10 --> Final output sent to browser
DEBUG - 2023-09-24 13:45:11 --> Total execution time: 0.3345
INFO - 2023-09-24 13:45:19 --> Config Class Initialized
INFO - 2023-09-24 13:45:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:45:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:45:19 --> Utf8 Class Initialized
INFO - 2023-09-24 13:45:19 --> URI Class Initialized
INFO - 2023-09-24 13:45:19 --> Router Class Initialized
INFO - 2023-09-24 13:45:19 --> Output Class Initialized
INFO - 2023-09-24 13:45:19 --> Security Class Initialized
DEBUG - 2023-09-24 13:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:45:19 --> Input Class Initialized
INFO - 2023-09-24 13:45:19 --> Language Class Initialized
INFO - 2023-09-24 13:45:19 --> Loader Class Initialized
INFO - 2023-09-24 13:45:19 --> Helper loaded: url_helper
INFO - 2023-09-24 13:45:19 --> Helper loaded: file_helper
INFO - 2023-09-24 13:45:19 --> Database Driver Class Initialized
INFO - 2023-09-24 13:45:19 --> Email Class Initialized
DEBUG - 2023-09-24 13:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:45:19 --> Controller Class Initialized
INFO - 2023-09-24 13:45:19 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:45:19 --> Model "Home_model" initialized
INFO - 2023-09-24 13:45:19 --> Helper loaded: download_helper
INFO - 2023-09-24 13:45:19 --> Helper loaded: form_helper
INFO - 2023-09-24 13:45:19 --> Form Validation Class Initialized
INFO - 2023-09-24 13:45:19 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:45:19 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:45:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:45:20 --> Final output sent to browser
DEBUG - 2023-09-24 13:45:20 --> Total execution time: 0.3560
INFO - 2023-09-24 13:45:51 --> Config Class Initialized
INFO - 2023-09-24 13:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:45:51 --> Utf8 Class Initialized
INFO - 2023-09-24 13:45:51 --> URI Class Initialized
INFO - 2023-09-24 13:45:51 --> Router Class Initialized
INFO - 2023-09-24 13:45:51 --> Output Class Initialized
INFO - 2023-09-24 13:45:51 --> Security Class Initialized
DEBUG - 2023-09-24 13:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:45:51 --> Input Class Initialized
INFO - 2023-09-24 13:45:51 --> Language Class Initialized
INFO - 2023-09-24 13:45:51 --> Loader Class Initialized
INFO - 2023-09-24 13:45:51 --> Helper loaded: url_helper
INFO - 2023-09-24 13:45:51 --> Helper loaded: file_helper
INFO - 2023-09-24 13:45:51 --> Database Driver Class Initialized
INFO - 2023-09-24 13:45:51 --> Email Class Initialized
DEBUG - 2023-09-24 13:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:45:51 --> Controller Class Initialized
INFO - 2023-09-24 13:45:51 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:45:51 --> Model "Home_model" initialized
INFO - 2023-09-24 13:45:51 --> Helper loaded: download_helper
INFO - 2023-09-24 13:45:51 --> Helper loaded: form_helper
INFO - 2023-09-24 13:45:51 --> Form Validation Class Initialized
INFO - 2023-09-24 13:45:51 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:45:51 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:45:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:45:51 --> Final output sent to browser
DEBUG - 2023-09-24 13:45:51 --> Total execution time: 0.2650
INFO - 2023-09-24 13:46:05 --> Config Class Initialized
INFO - 2023-09-24 13:46:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:46:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:46:05 --> Utf8 Class Initialized
INFO - 2023-09-24 13:46:05 --> URI Class Initialized
INFO - 2023-09-24 13:46:05 --> Router Class Initialized
INFO - 2023-09-24 13:46:05 --> Output Class Initialized
INFO - 2023-09-24 13:46:05 --> Security Class Initialized
DEBUG - 2023-09-24 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:46:05 --> Input Class Initialized
INFO - 2023-09-24 13:46:05 --> Language Class Initialized
INFO - 2023-09-24 13:46:05 --> Loader Class Initialized
INFO - 2023-09-24 13:46:05 --> Helper loaded: url_helper
INFO - 2023-09-24 13:46:05 --> Helper loaded: file_helper
INFO - 2023-09-24 13:46:05 --> Database Driver Class Initialized
INFO - 2023-09-24 13:46:05 --> Email Class Initialized
DEBUG - 2023-09-24 13:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:46:05 --> Controller Class Initialized
INFO - 2023-09-24 13:46:05 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:46:05 --> Model "Home_model" initialized
INFO - 2023-09-24 13:46:05 --> Helper loaded: download_helper
INFO - 2023-09-24 13:46:05 --> Helper loaded: form_helper
INFO - 2023-09-24 13:46:05 --> Form Validation Class Initialized
INFO - 2023-09-24 13:46:05 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:46:05 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:46:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:46:05 --> Final output sent to browser
DEBUG - 2023-09-24 13:46:05 --> Total execution time: 0.5101
INFO - 2023-09-24 13:56:47 --> Config Class Initialized
INFO - 2023-09-24 13:56:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:56:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:56:47 --> Utf8 Class Initialized
INFO - 2023-09-24 13:56:47 --> URI Class Initialized
INFO - 2023-09-24 13:56:47 --> Router Class Initialized
INFO - 2023-09-24 13:56:47 --> Output Class Initialized
INFO - 2023-09-24 13:56:47 --> Security Class Initialized
DEBUG - 2023-09-24 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:56:47 --> Input Class Initialized
INFO - 2023-09-24 13:56:47 --> Language Class Initialized
INFO - 2023-09-24 13:56:47 --> Loader Class Initialized
INFO - 2023-09-24 13:56:47 --> Helper loaded: url_helper
INFO - 2023-09-24 13:56:47 --> Helper loaded: file_helper
INFO - 2023-09-24 13:56:47 --> Database Driver Class Initialized
INFO - 2023-09-24 13:56:47 --> Email Class Initialized
DEBUG - 2023-09-24 13:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:56:47 --> Controller Class Initialized
INFO - 2023-09-24 13:56:47 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:56:47 --> Model "Home_model" initialized
INFO - 2023-09-24 13:56:47 --> Helper loaded: download_helper
INFO - 2023-09-24 13:56:47 --> Helper loaded: form_helper
INFO - 2023-09-24 13:56:47 --> Form Validation Class Initialized
INFO - 2023-09-24 13:56:47 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:56:47 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:56:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:56:47 --> Final output sent to browser
DEBUG - 2023-09-24 13:56:47 --> Total execution time: 0.5547
INFO - 2023-09-24 13:56:54 --> Config Class Initialized
INFO - 2023-09-24 13:56:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:56:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:56:54 --> Utf8 Class Initialized
INFO - 2023-09-24 13:56:54 --> URI Class Initialized
INFO - 2023-09-24 13:56:54 --> Router Class Initialized
INFO - 2023-09-24 13:56:54 --> Output Class Initialized
INFO - 2023-09-24 13:56:54 --> Security Class Initialized
DEBUG - 2023-09-24 13:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:56:54 --> Input Class Initialized
INFO - 2023-09-24 13:56:54 --> Language Class Initialized
INFO - 2023-09-24 13:56:54 --> Loader Class Initialized
INFO - 2023-09-24 13:56:54 --> Helper loaded: url_helper
INFO - 2023-09-24 13:56:54 --> Helper loaded: file_helper
INFO - 2023-09-24 13:56:54 --> Database Driver Class Initialized
INFO - 2023-09-24 13:56:54 --> Email Class Initialized
DEBUG - 2023-09-24 13:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:56:54 --> Controller Class Initialized
INFO - 2023-09-24 13:56:54 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:56:54 --> Model "Home_model" initialized
INFO - 2023-09-24 13:56:54 --> Helper loaded: download_helper
INFO - 2023-09-24 13:56:54 --> Helper loaded: form_helper
INFO - 2023-09-24 13:56:54 --> Form Validation Class Initialized
INFO - 2023-09-24 13:56:54 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:56:54 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:56:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:56:54 --> Final output sent to browser
DEBUG - 2023-09-24 13:56:54 --> Total execution time: 0.1471
INFO - 2023-09-24 13:57:03 --> Config Class Initialized
INFO - 2023-09-24 13:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 13:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 13:57:03 --> Utf8 Class Initialized
INFO - 2023-09-24 13:57:03 --> URI Class Initialized
INFO - 2023-09-24 13:57:03 --> Router Class Initialized
INFO - 2023-09-24 13:57:03 --> Output Class Initialized
INFO - 2023-09-24 13:57:03 --> Security Class Initialized
DEBUG - 2023-09-24 13:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 13:57:03 --> Input Class Initialized
INFO - 2023-09-24 13:57:03 --> Language Class Initialized
INFO - 2023-09-24 13:57:03 --> Loader Class Initialized
INFO - 2023-09-24 13:57:03 --> Helper loaded: url_helper
INFO - 2023-09-24 13:57:03 --> Helper loaded: file_helper
INFO - 2023-09-24 13:57:03 --> Database Driver Class Initialized
INFO - 2023-09-24 13:57:03 --> Email Class Initialized
DEBUG - 2023-09-24 13:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 13:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 13:57:03 --> Controller Class Initialized
INFO - 2023-09-24 13:57:03 --> Model "Contact_model" initialized
INFO - 2023-09-24 13:57:03 --> Model "Home_model" initialized
INFO - 2023-09-24 13:57:03 --> Helper loaded: download_helper
INFO - 2023-09-24 13:57:03 --> Helper loaded: form_helper
INFO - 2023-09-24 13:57:03 --> Form Validation Class Initialized
INFO - 2023-09-24 13:57:03 --> Helper loaded: custom_helper
INFO - 2023-09-24 13:57:03 --> Model "Social_media_model" initialized
INFO - 2023-09-24 13:57:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 13:57:03 --> Final output sent to browser
DEBUG - 2023-09-24 13:57:03 --> Total execution time: 0.2371
INFO - 2023-09-24 14:00:22 --> Config Class Initialized
INFO - 2023-09-24 14:00:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:00:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:00:22 --> Utf8 Class Initialized
INFO - 2023-09-24 14:00:22 --> URI Class Initialized
INFO - 2023-09-24 14:00:22 --> Router Class Initialized
INFO - 2023-09-24 14:00:22 --> Output Class Initialized
INFO - 2023-09-24 14:00:22 --> Security Class Initialized
DEBUG - 2023-09-24 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:00:22 --> Input Class Initialized
INFO - 2023-09-24 14:00:22 --> Language Class Initialized
INFO - 2023-09-24 14:00:22 --> Loader Class Initialized
INFO - 2023-09-24 14:00:22 --> Helper loaded: url_helper
INFO - 2023-09-24 14:00:22 --> Helper loaded: file_helper
INFO - 2023-09-24 14:00:22 --> Database Driver Class Initialized
INFO - 2023-09-24 14:00:22 --> Email Class Initialized
DEBUG - 2023-09-24 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:00:22 --> Controller Class Initialized
INFO - 2023-09-24 14:00:22 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:00:22 --> Model "Home_model" initialized
INFO - 2023-09-24 14:00:22 --> Helper loaded: download_helper
INFO - 2023-09-24 14:00:22 --> Helper loaded: form_helper
INFO - 2023-09-24 14:00:22 --> Form Validation Class Initialized
INFO - 2023-09-24 14:00:22 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:00:22 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:00:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:00:22 --> Final output sent to browser
DEBUG - 2023-09-24 14:00:22 --> Total execution time: 0.3532
INFO - 2023-09-24 14:00:33 --> Config Class Initialized
INFO - 2023-09-24 14:00:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:00:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:00:33 --> Utf8 Class Initialized
INFO - 2023-09-24 14:00:33 --> URI Class Initialized
INFO - 2023-09-24 14:00:33 --> Router Class Initialized
INFO - 2023-09-24 14:00:33 --> Output Class Initialized
INFO - 2023-09-24 14:00:33 --> Security Class Initialized
DEBUG - 2023-09-24 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:00:33 --> Input Class Initialized
INFO - 2023-09-24 14:00:33 --> Language Class Initialized
INFO - 2023-09-24 14:00:33 --> Loader Class Initialized
INFO - 2023-09-24 14:00:33 --> Helper loaded: url_helper
INFO - 2023-09-24 14:00:33 --> Helper loaded: file_helper
INFO - 2023-09-24 14:00:33 --> Database Driver Class Initialized
INFO - 2023-09-24 14:00:33 --> Email Class Initialized
DEBUG - 2023-09-24 14:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:00:33 --> Controller Class Initialized
INFO - 2023-09-24 14:00:33 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:00:33 --> Model "Home_model" initialized
INFO - 2023-09-24 14:00:33 --> Helper loaded: download_helper
INFO - 2023-09-24 14:00:33 --> Helper loaded: form_helper
INFO - 2023-09-24 14:00:33 --> Form Validation Class Initialized
INFO - 2023-09-24 14:00:33 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:00:33 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:00:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:00:33 --> Final output sent to browser
DEBUG - 2023-09-24 14:00:33 --> Total execution time: 0.3500
INFO - 2023-09-24 14:00:39 --> Config Class Initialized
INFO - 2023-09-24 14:00:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:00:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:00:39 --> Utf8 Class Initialized
INFO - 2023-09-24 14:00:39 --> URI Class Initialized
INFO - 2023-09-24 14:00:39 --> Router Class Initialized
INFO - 2023-09-24 14:00:39 --> Output Class Initialized
INFO - 2023-09-24 14:00:39 --> Security Class Initialized
DEBUG - 2023-09-24 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:00:39 --> Input Class Initialized
INFO - 2023-09-24 14:00:39 --> Language Class Initialized
INFO - 2023-09-24 14:00:39 --> Loader Class Initialized
INFO - 2023-09-24 14:00:39 --> Helper loaded: url_helper
INFO - 2023-09-24 14:00:39 --> Helper loaded: file_helper
INFO - 2023-09-24 14:00:39 --> Database Driver Class Initialized
INFO - 2023-09-24 14:00:39 --> Email Class Initialized
DEBUG - 2023-09-24 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:00:39 --> Controller Class Initialized
INFO - 2023-09-24 14:00:39 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:00:39 --> Model "Home_model" initialized
INFO - 2023-09-24 14:00:39 --> Helper loaded: download_helper
INFO - 2023-09-24 14:00:39 --> Helper loaded: form_helper
INFO - 2023-09-24 14:00:39 --> Form Validation Class Initialized
INFO - 2023-09-24 14:00:39 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:00:39 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:00:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:00:39 --> Final output sent to browser
DEBUG - 2023-09-24 14:00:39 --> Total execution time: 0.0712
INFO - 2023-09-24 14:00:50 --> Config Class Initialized
INFO - 2023-09-24 14:00:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:00:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:00:50 --> Utf8 Class Initialized
INFO - 2023-09-24 14:00:50 --> URI Class Initialized
INFO - 2023-09-24 14:00:50 --> Router Class Initialized
INFO - 2023-09-24 14:00:50 --> Output Class Initialized
INFO - 2023-09-24 14:00:50 --> Security Class Initialized
DEBUG - 2023-09-24 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:00:50 --> Input Class Initialized
INFO - 2023-09-24 14:00:50 --> Language Class Initialized
INFO - 2023-09-24 14:00:50 --> Loader Class Initialized
INFO - 2023-09-24 14:00:50 --> Helper loaded: url_helper
INFO - 2023-09-24 14:00:50 --> Helper loaded: file_helper
INFO - 2023-09-24 14:00:50 --> Database Driver Class Initialized
INFO - 2023-09-24 14:00:50 --> Email Class Initialized
DEBUG - 2023-09-24 14:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:00:50 --> Controller Class Initialized
INFO - 2023-09-24 14:00:50 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:00:50 --> Model "Home_model" initialized
INFO - 2023-09-24 14:00:50 --> Helper loaded: download_helper
INFO - 2023-09-24 14:00:50 --> Helper loaded: form_helper
INFO - 2023-09-24 14:00:50 --> Form Validation Class Initialized
INFO - 2023-09-24 14:00:50 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:00:50 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:00:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:00:50 --> Final output sent to browser
DEBUG - 2023-09-24 14:00:50 --> Total execution time: 0.3922
INFO - 2023-09-24 14:00:58 --> Config Class Initialized
INFO - 2023-09-24 14:00:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:00:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:00:58 --> Utf8 Class Initialized
INFO - 2023-09-24 14:00:58 --> URI Class Initialized
INFO - 2023-09-24 14:00:58 --> Router Class Initialized
INFO - 2023-09-24 14:00:58 --> Output Class Initialized
INFO - 2023-09-24 14:00:58 --> Security Class Initialized
DEBUG - 2023-09-24 14:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:00:58 --> Input Class Initialized
INFO - 2023-09-24 14:00:58 --> Language Class Initialized
INFO - 2023-09-24 14:00:58 --> Loader Class Initialized
INFO - 2023-09-24 14:00:58 --> Helper loaded: url_helper
INFO - 2023-09-24 14:00:58 --> Helper loaded: file_helper
INFO - 2023-09-24 14:00:58 --> Database Driver Class Initialized
INFO - 2023-09-24 14:00:58 --> Email Class Initialized
DEBUG - 2023-09-24 14:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:00:58 --> Controller Class Initialized
INFO - 2023-09-24 14:00:58 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:00:58 --> Model "Home_model" initialized
INFO - 2023-09-24 14:00:58 --> Helper loaded: download_helper
INFO - 2023-09-24 14:00:58 --> Helper loaded: form_helper
INFO - 2023-09-24 14:00:58 --> Form Validation Class Initialized
INFO - 2023-09-24 14:00:58 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:00:58 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:00:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:00:58 --> Final output sent to browser
DEBUG - 2023-09-24 14:00:58 --> Total execution time: 0.3815
INFO - 2023-09-24 14:01:06 --> Config Class Initialized
INFO - 2023-09-24 14:01:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:01:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:01:06 --> Utf8 Class Initialized
INFO - 2023-09-24 14:01:06 --> URI Class Initialized
INFO - 2023-09-24 14:01:06 --> Router Class Initialized
INFO - 2023-09-24 14:01:06 --> Output Class Initialized
INFO - 2023-09-24 14:01:06 --> Security Class Initialized
DEBUG - 2023-09-24 14:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:01:06 --> Input Class Initialized
INFO - 2023-09-24 14:01:06 --> Language Class Initialized
INFO - 2023-09-24 14:01:06 --> Loader Class Initialized
INFO - 2023-09-24 14:01:06 --> Helper loaded: url_helper
INFO - 2023-09-24 14:01:06 --> Helper loaded: file_helper
INFO - 2023-09-24 14:01:06 --> Database Driver Class Initialized
INFO - 2023-09-24 14:01:06 --> Email Class Initialized
DEBUG - 2023-09-24 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:01:06 --> Controller Class Initialized
INFO - 2023-09-24 14:01:06 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:01:06 --> Model "Home_model" initialized
INFO - 2023-09-24 14:01:06 --> Helper loaded: download_helper
INFO - 2023-09-24 14:01:06 --> Helper loaded: form_helper
INFO - 2023-09-24 14:01:06 --> Form Validation Class Initialized
INFO - 2023-09-24 14:01:06 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:01:06 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:01:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-24 14:01:06 --> Final output sent to browser
DEBUG - 2023-09-24 14:01:06 --> Total execution time: 0.3005
INFO - 2023-09-24 14:04:02 --> Config Class Initialized
INFO - 2023-09-24 14:04:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:02 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:02 --> URI Class Initialized
INFO - 2023-09-24 14:04:02 --> Router Class Initialized
INFO - 2023-09-24 14:04:02 --> Output Class Initialized
INFO - 2023-09-24 14:04:02 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:02 --> Input Class Initialized
INFO - 2023-09-24 14:04:02 --> Language Class Initialized
INFO - 2023-09-24 14:04:03 --> Config Class Initialized
INFO - 2023-09-24 14:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:03 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:03 --> URI Class Initialized
INFO - 2023-09-24 14:04:03 --> Router Class Initialized
INFO - 2023-09-24 14:04:03 --> Output Class Initialized
INFO - 2023-09-24 14:04:03 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:03 --> Input Class Initialized
INFO - 2023-09-24 14:04:03 --> Language Class Initialized
ERROR - 2023-09-24 14:04:03 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-24 14:04:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:04:03 --> Config Class Initialized
INFO - 2023-09-24 14:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:03 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:03 --> URI Class Initialized
INFO - 2023-09-24 14:04:03 --> Router Class Initialized
INFO - 2023-09-24 14:04:03 --> Output Class Initialized
INFO - 2023-09-24 14:04:03 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:03 --> Input Class Initialized
INFO - 2023-09-24 14:04:03 --> Language Class Initialized
ERROR - 2023-09-24 14:04:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:04:03 --> Config Class Initialized
INFO - 2023-09-24 14:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:04 --> Config Class Initialized
INFO - 2023-09-24 14:04:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:04 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:04 --> URI Class Initialized
INFO - 2023-09-24 14:04:04 --> Router Class Initialized
INFO - 2023-09-24 14:04:04 --> Output Class Initialized
INFO - 2023-09-24 14:04:04 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:04 --> Input Class Initialized
INFO - 2023-09-24 14:04:04 --> Language Class Initialized
ERROR - 2023-09-24 14:04:04 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:04:04 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:04 --> URI Class Initialized
INFO - 2023-09-24 14:04:04 --> Router Class Initialized
INFO - 2023-09-24 14:04:05 --> Output Class Initialized
INFO - 2023-09-24 14:04:05 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:05 --> Input Class Initialized
INFO - 2023-09-24 14:04:05 --> Language Class Initialized
ERROR - 2023-09-24 14:04:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:04:06 --> Config Class Initialized
INFO - 2023-09-24 14:04:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:06 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:06 --> URI Class Initialized
INFO - 2023-09-24 14:04:06 --> Router Class Initialized
INFO - 2023-09-24 14:04:06 --> Output Class Initialized
INFO - 2023-09-24 14:04:06 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:06 --> Input Class Initialized
INFO - 2023-09-24 14:04:06 --> Language Class Initialized
ERROR - 2023-09-24 14:04:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:04:06 --> Config Class Initialized
INFO - 2023-09-24 14:04:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:04:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:04:06 --> Utf8 Class Initialized
INFO - 2023-09-24 14:04:06 --> URI Class Initialized
INFO - 2023-09-24 14:04:06 --> Router Class Initialized
INFO - 2023-09-24 14:04:06 --> Output Class Initialized
INFO - 2023-09-24 14:04:06 --> Security Class Initialized
DEBUG - 2023-09-24 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:04:06 --> Input Class Initialized
INFO - 2023-09-24 14:04:06 --> Language Class Initialized
ERROR - 2023-09-24 14:04:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-24 14:09:11 --> Config Class Initialized
INFO - 2023-09-24 14:09:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 14:09:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 14:09:11 --> Utf8 Class Initialized
INFO - 2023-09-24 14:09:11 --> URI Class Initialized
DEBUG - 2023-09-24 14:09:11 --> No URI present. Default controller set.
INFO - 2023-09-24 14:09:11 --> Router Class Initialized
INFO - 2023-09-24 14:09:11 --> Output Class Initialized
INFO - 2023-09-24 14:09:11 --> Security Class Initialized
DEBUG - 2023-09-24 14:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 14:09:11 --> Input Class Initialized
INFO - 2023-09-24 14:09:11 --> Language Class Initialized
INFO - 2023-09-24 14:09:11 --> Loader Class Initialized
INFO - 2023-09-24 14:09:11 --> Helper loaded: url_helper
INFO - 2023-09-24 14:09:11 --> Helper loaded: file_helper
INFO - 2023-09-24 14:09:11 --> Database Driver Class Initialized
INFO - 2023-09-24 14:09:11 --> Email Class Initialized
DEBUG - 2023-09-24 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-24 14:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 14:09:11 --> Controller Class Initialized
INFO - 2023-09-24 14:09:11 --> Model "Contact_model" initialized
INFO - 2023-09-24 14:09:11 --> Model "Home_model" initialized
INFO - 2023-09-24 14:09:11 --> Helper loaded: download_helper
INFO - 2023-09-24 14:09:11 --> Helper loaded: form_helper
INFO - 2023-09-24 14:09:11 --> Form Validation Class Initialized
INFO - 2023-09-24 14:09:12 --> Helper loaded: custom_helper
INFO - 2023-09-24 14:09:12 --> Model "Social_media_model" initialized
INFO - 2023-09-24 14:09:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-24 14:09:12 --> Final output sent to browser
DEBUG - 2023-09-24 14:09:12 --> Total execution time: 0.5507
