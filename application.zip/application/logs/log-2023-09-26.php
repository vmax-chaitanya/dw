<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-26 16:52:52 --> Config Class Initialized
INFO - 2023-09-26 16:52:52 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:52:52 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:52:52 --> Utf8 Class Initialized
INFO - 2023-09-26 16:52:52 --> URI Class Initialized
DEBUG - 2023-09-26 16:52:52 --> No URI present. Default controller set.
INFO - 2023-09-26 16:52:52 --> Router Class Initialized
INFO - 2023-09-26 16:52:52 --> Output Class Initialized
INFO - 2023-09-26 16:52:52 --> Security Class Initialized
DEBUG - 2023-09-26 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:52:52 --> Input Class Initialized
INFO - 2023-09-26 16:52:52 --> Language Class Initialized
INFO - 2023-09-26 16:52:52 --> Loader Class Initialized
INFO - 2023-09-26 16:52:52 --> Helper loaded: url_helper
INFO - 2023-09-26 16:52:52 --> Helper loaded: file_helper
INFO - 2023-09-26 16:52:52 --> Database Driver Class Initialized
INFO - 2023-09-26 16:52:52 --> Email Class Initialized
DEBUG - 2023-09-26 16:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:52:52 --> Controller Class Initialized
INFO - 2023-09-26 16:52:52 --> Model "Contact_model" initialized
ERROR - 2023-09-26 16:52:53 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\dw\application\models\Home_model.php 150
INFO - 2023-09-26 16:53:02 --> Config Class Initialized
INFO - 2023-09-26 16:53:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:53:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:53:02 --> Utf8 Class Initialized
INFO - 2023-09-26 16:53:02 --> URI Class Initialized
DEBUG - 2023-09-26 16:53:02 --> No URI present. Default controller set.
INFO - 2023-09-26 16:53:02 --> Router Class Initialized
INFO - 2023-09-26 16:53:02 --> Output Class Initialized
INFO - 2023-09-26 16:53:02 --> Security Class Initialized
DEBUG - 2023-09-26 16:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:53:02 --> Input Class Initialized
INFO - 2023-09-26 16:53:02 --> Language Class Initialized
INFO - 2023-09-26 16:53:02 --> Loader Class Initialized
INFO - 2023-09-26 16:53:02 --> Helper loaded: url_helper
INFO - 2023-09-26 16:53:02 --> Helper loaded: file_helper
INFO - 2023-09-26 16:53:02 --> Database Driver Class Initialized
INFO - 2023-09-26 16:53:02 --> Email Class Initialized
DEBUG - 2023-09-26 16:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:53:02 --> Controller Class Initialized
INFO - 2023-09-26 16:53:02 --> Model "Contact_model" initialized
ERROR - 2023-09-26 16:53:02 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\dw\application\models\Home_model.php 150
INFO - 2023-09-26 16:54:52 --> Config Class Initialized
INFO - 2023-09-26 16:54:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:54:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:54:53 --> Utf8 Class Initialized
INFO - 2023-09-26 16:54:53 --> URI Class Initialized
DEBUG - 2023-09-26 16:54:53 --> No URI present. Default controller set.
INFO - 2023-09-26 16:54:53 --> Router Class Initialized
INFO - 2023-09-26 16:54:53 --> Output Class Initialized
INFO - 2023-09-26 16:54:53 --> Security Class Initialized
DEBUG - 2023-09-26 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:54:53 --> Input Class Initialized
INFO - 2023-09-26 16:54:53 --> Language Class Initialized
INFO - 2023-09-26 16:54:53 --> Loader Class Initialized
INFO - 2023-09-26 16:54:53 --> Helper loaded: url_helper
INFO - 2023-09-26 16:54:53 --> Helper loaded: file_helper
INFO - 2023-09-26 16:54:53 --> Database Driver Class Initialized
INFO - 2023-09-26 16:54:53 --> Email Class Initialized
DEBUG - 2023-09-26 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:54:53 --> Controller Class Initialized
INFO - 2023-09-26 16:54:53 --> Model "Contact_model" initialized
INFO - 2023-09-26 16:54:53 --> Model "Home_model" initialized
INFO - 2023-09-26 16:54:53 --> Helper loaded: download_helper
INFO - 2023-09-26 16:54:53 --> Helper loaded: form_helper
INFO - 2023-09-26 16:54:53 --> Form Validation Class Initialized
INFO - 2023-09-26 16:54:53 --> Helper loaded: custom_helper
INFO - 2023-09-26 16:54:53 --> Model "Social_media_model" initialized
INFO - 2023-09-26 16:54:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-26 16:54:53 --> Final output sent to browser
DEBUG - 2023-09-26 16:54:53 --> Total execution time: 0.4943
INFO - 2023-09-26 16:55:01 --> Config Class Initialized
INFO - 2023-09-26 16:55:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:01 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:01 --> URI Class Initialized
INFO - 2023-09-26 16:55:01 --> Router Class Initialized
INFO - 2023-09-26 16:55:01 --> Output Class Initialized
INFO - 2023-09-26 16:55:01 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:01 --> Input Class Initialized
INFO - 2023-09-26 16:55:01 --> Language Class Initialized
INFO - 2023-09-26 16:55:01 --> Loader Class Initialized
INFO - 2023-09-26 16:55:01 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:01 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:01 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:01 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:01 --> Controller Class Initialized
INFO - 2023-09-26 16:55:01 --> Config Class Initialized
INFO - 2023-09-26 16:55:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:01 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:01 --> URI Class Initialized
INFO - 2023-09-26 16:55:01 --> Router Class Initialized
INFO - 2023-09-26 16:55:01 --> Output Class Initialized
INFO - 2023-09-26 16:55:01 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:01 --> Input Class Initialized
INFO - 2023-09-26 16:55:01 --> Language Class Initialized
INFO - 2023-09-26 16:55:01 --> Loader Class Initialized
INFO - 2023-09-26 16:55:02 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:02 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:02 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:02 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:02 --> Controller Class Initialized
INFO - 2023-09-26 16:55:02 --> Model "User_model" initialized
INFO - 2023-09-26 16:55:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-26 16:55:02 --> Final output sent to browser
DEBUG - 2023-09-26 16:55:02 --> Total execution time: 0.1263
INFO - 2023-09-26 16:55:03 --> Config Class Initialized
INFO - 2023-09-26 16:55:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:03 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:03 --> URI Class Initialized
INFO - 2023-09-26 16:55:03 --> Router Class Initialized
INFO - 2023-09-26 16:55:03 --> Output Class Initialized
INFO - 2023-09-26 16:55:03 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:03 --> Input Class Initialized
INFO - 2023-09-26 16:55:03 --> Language Class Initialized
ERROR - 2023-09-26 16:55:03 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-26 16:55:10 --> Config Class Initialized
INFO - 2023-09-26 16:55:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:10 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:10 --> URI Class Initialized
INFO - 2023-09-26 16:55:10 --> Router Class Initialized
INFO - 2023-09-26 16:55:10 --> Output Class Initialized
INFO - 2023-09-26 16:55:10 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:10 --> Input Class Initialized
INFO - 2023-09-26 16:55:10 --> Language Class Initialized
INFO - 2023-09-26 16:55:10 --> Loader Class Initialized
INFO - 2023-09-26 16:55:10 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:10 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:11 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:11 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:11 --> Controller Class Initialized
INFO - 2023-09-26 16:55:11 --> Model "User_model" initialized
INFO - 2023-09-26 16:55:11 --> Config Class Initialized
INFO - 2023-09-26 16:55:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:11 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:11 --> URI Class Initialized
INFO - 2023-09-26 16:55:11 --> Router Class Initialized
INFO - 2023-09-26 16:55:11 --> Output Class Initialized
INFO - 2023-09-26 16:55:11 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:11 --> Input Class Initialized
INFO - 2023-09-26 16:55:11 --> Language Class Initialized
INFO - 2023-09-26 16:55:11 --> Loader Class Initialized
INFO - 2023-09-26 16:55:11 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:11 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:11 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:11 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:11 --> Controller Class Initialized
INFO - 2023-09-26 16:55:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-26 16:55:11 --> Final output sent to browser
DEBUG - 2023-09-26 16:55:11 --> Total execution time: 0.1582
INFO - 2023-09-26 16:55:24 --> Config Class Initialized
INFO - 2023-09-26 16:55:24 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:24 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:24 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:24 --> URI Class Initialized
INFO - 2023-09-26 16:55:24 --> Router Class Initialized
INFO - 2023-09-26 16:55:24 --> Output Class Initialized
INFO - 2023-09-26 16:55:24 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:24 --> Input Class Initialized
INFO - 2023-09-26 16:55:24 --> Language Class Initialized
INFO - 2023-09-26 16:55:24 --> Loader Class Initialized
INFO - 2023-09-26 16:55:24 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:24 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:24 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:24 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:24 --> Controller Class Initialized
INFO - 2023-09-26 16:55:24 --> Model "Services_model" initialized
INFO - 2023-09-26 16:55:24 --> Helper loaded: form_helper
INFO - 2023-09-26 16:55:24 --> Form Validation Class Initialized
INFO - 2023-09-26 16:55:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-26 16:55:25 --> Final output sent to browser
DEBUG - 2023-09-26 16:55:25 --> Total execution time: 0.2089
INFO - 2023-09-26 16:55:29 --> Config Class Initialized
INFO - 2023-09-26 16:55:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:29 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:29 --> URI Class Initialized
INFO - 2023-09-26 16:55:29 --> Router Class Initialized
INFO - 2023-09-26 16:55:29 --> Output Class Initialized
INFO - 2023-09-26 16:55:29 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:29 --> Input Class Initialized
INFO - 2023-09-26 16:55:29 --> Language Class Initialized
INFO - 2023-09-26 16:55:29 --> Loader Class Initialized
INFO - 2023-09-26 16:55:29 --> Helper loaded: url_helper
INFO - 2023-09-26 16:55:29 --> Helper loaded: file_helper
INFO - 2023-09-26 16:55:29 --> Database Driver Class Initialized
INFO - 2023-09-26 16:55:29 --> Email Class Initialized
DEBUG - 2023-09-26 16:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:55:29 --> Controller Class Initialized
INFO - 2023-09-26 16:55:29 --> Model "Services_model" initialized
INFO - 2023-09-26 16:55:29 --> Helper loaded: form_helper
INFO - 2023-09-26 16:55:29 --> Form Validation Class Initialized
INFO - 2023-09-26 16:55:29 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-09-26 16:55:29 --> Final output sent to browser
DEBUG - 2023-09-26 16:55:29 --> Total execution time: 0.2546
INFO - 2023-09-26 16:55:29 --> Config Class Initialized
INFO - 2023-09-26 16:55:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:55:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:55:29 --> Utf8 Class Initialized
INFO - 2023-09-26 16:55:29 --> URI Class Initialized
INFO - 2023-09-26 16:55:29 --> Router Class Initialized
INFO - 2023-09-26 16:55:29 --> Output Class Initialized
INFO - 2023-09-26 16:55:29 --> Security Class Initialized
DEBUG - 2023-09-26 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:55:29 --> Input Class Initialized
INFO - 2023-09-26 16:55:29 --> Language Class Initialized
ERROR - 2023-09-26 16:55:29 --> 404 Page Not Found: admin/Services/images
INFO - 2023-09-26 16:56:23 --> Config Class Initialized
INFO - 2023-09-26 16:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:56:23 --> Utf8 Class Initialized
INFO - 2023-09-26 16:56:23 --> URI Class Initialized
INFO - 2023-09-26 16:56:23 --> Router Class Initialized
INFO - 2023-09-26 16:56:23 --> Output Class Initialized
INFO - 2023-09-26 16:56:23 --> Security Class Initialized
DEBUG - 2023-09-26 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:56:23 --> Input Class Initialized
INFO - 2023-09-26 16:56:23 --> Language Class Initialized
INFO - 2023-09-26 16:56:23 --> Loader Class Initialized
INFO - 2023-09-26 16:56:23 --> Helper loaded: url_helper
INFO - 2023-09-26 16:56:23 --> Helper loaded: file_helper
INFO - 2023-09-26 16:56:23 --> Database Driver Class Initialized
INFO - 2023-09-26 16:56:23 --> Email Class Initialized
DEBUG - 2023-09-26 16:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:56:23 --> Controller Class Initialized
INFO - 2023-09-26 16:56:23 --> Model "Services_model" initialized
INFO - 2023-09-26 16:56:23 --> Helper loaded: form_helper
INFO - 2023-09-26 16:56:23 --> Form Validation Class Initialized
INFO - 2023-09-26 16:56:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-26 16:56:23 --> Config Class Initialized
INFO - 2023-09-26 16:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:56:23 --> Utf8 Class Initialized
INFO - 2023-09-26 16:56:23 --> URI Class Initialized
INFO - 2023-09-26 16:56:23 --> Router Class Initialized
INFO - 2023-09-26 16:56:23 --> Output Class Initialized
INFO - 2023-09-26 16:56:23 --> Security Class Initialized
DEBUG - 2023-09-26 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:56:23 --> Input Class Initialized
INFO - 2023-09-26 16:56:23 --> Language Class Initialized
INFO - 2023-09-26 16:56:23 --> Loader Class Initialized
INFO - 2023-09-26 16:56:23 --> Helper loaded: url_helper
INFO - 2023-09-26 16:56:23 --> Helper loaded: file_helper
INFO - 2023-09-26 16:56:23 --> Database Driver Class Initialized
INFO - 2023-09-26 16:56:23 --> Email Class Initialized
DEBUG - 2023-09-26 16:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 16:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:56:23 --> Controller Class Initialized
INFO - 2023-09-26 16:56:23 --> Model "Services_model" initialized
INFO - 2023-09-26 16:56:23 --> Helper loaded: form_helper
INFO - 2023-09-26 16:56:23 --> Form Validation Class Initialized
INFO - 2023-09-26 16:56:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-26 16:56:23 --> Final output sent to browser
DEBUG - 2023-09-26 16:56:23 --> Total execution time: 0.0879
INFO - 2023-09-26 17:28:14 --> Config Class Initialized
INFO - 2023-09-26 17:28:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:28:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:28:14 --> Utf8 Class Initialized
INFO - 2023-09-26 17:28:14 --> URI Class Initialized
INFO - 2023-09-26 17:28:14 --> Router Class Initialized
INFO - 2023-09-26 17:28:14 --> Output Class Initialized
INFO - 2023-09-26 17:28:14 --> Security Class Initialized
DEBUG - 2023-09-26 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:28:14 --> Input Class Initialized
INFO - 2023-09-26 17:28:14 --> Language Class Initialized
INFO - 2023-09-26 17:28:14 --> Loader Class Initialized
INFO - 2023-09-26 17:28:14 --> Helper loaded: url_helper
INFO - 2023-09-26 17:28:14 --> Helper loaded: file_helper
INFO - 2023-09-26 17:28:14 --> Database Driver Class Initialized
INFO - 2023-09-26 17:28:14 --> Email Class Initialized
DEBUG - 2023-09-26 17:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:28:14 --> Controller Class Initialized
INFO - 2023-09-26 17:28:14 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:28:14 --> Model "Home_model" initialized
INFO - 2023-09-26 17:28:14 --> Helper loaded: download_helper
INFO - 2023-09-26 17:28:14 --> Helper loaded: form_helper
INFO - 2023-09-26 17:28:14 --> Form Validation Class Initialized
INFO - 2023-09-26 17:28:14 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:28:14 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:28:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-26 17:28:14 --> Final output sent to browser
DEBUG - 2023-09-26 17:28:14 --> Total execution time: 0.1632
INFO - 2023-09-26 17:28:21 --> Config Class Initialized
INFO - 2023-09-26 17:28:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:28:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:28:21 --> Utf8 Class Initialized
INFO - 2023-09-26 17:28:21 --> URI Class Initialized
INFO - 2023-09-26 17:28:21 --> Router Class Initialized
INFO - 2023-09-26 17:28:21 --> Output Class Initialized
INFO - 2023-09-26 17:28:21 --> Security Class Initialized
DEBUG - 2023-09-26 17:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:28:21 --> Input Class Initialized
INFO - 2023-09-26 17:28:21 --> Language Class Initialized
INFO - 2023-09-26 17:28:21 --> Loader Class Initialized
INFO - 2023-09-26 17:28:21 --> Helper loaded: url_helper
INFO - 2023-09-26 17:28:21 --> Helper loaded: file_helper
INFO - 2023-09-26 17:28:21 --> Database Driver Class Initialized
INFO - 2023-09-26 17:28:21 --> Email Class Initialized
DEBUG - 2023-09-26 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:28:21 --> Controller Class Initialized
INFO - 2023-09-26 17:28:21 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:28:21 --> Model "Home_model" initialized
INFO - 2023-09-26 17:28:21 --> Helper loaded: download_helper
INFO - 2023-09-26 17:28:21 --> Helper loaded: form_helper
INFO - 2023-09-26 17:28:21 --> Form Validation Class Initialized
INFO - 2023-09-26 17:28:21 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:28:21 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:28:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:28:21 --> Final output sent to browser
DEBUG - 2023-09-26 17:28:21 --> Total execution time: 0.1967
INFO - 2023-09-26 17:29:24 --> Config Class Initialized
INFO - 2023-09-26 17:29:24 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:29:24 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:29:24 --> Utf8 Class Initialized
INFO - 2023-09-26 17:29:24 --> URI Class Initialized
INFO - 2023-09-26 17:29:24 --> Router Class Initialized
INFO - 2023-09-26 17:29:24 --> Output Class Initialized
INFO - 2023-09-26 17:29:24 --> Security Class Initialized
DEBUG - 2023-09-26 17:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:29:24 --> Input Class Initialized
INFO - 2023-09-26 17:29:24 --> Language Class Initialized
INFO - 2023-09-26 17:29:24 --> Loader Class Initialized
INFO - 2023-09-26 17:29:24 --> Helper loaded: url_helper
INFO - 2023-09-26 17:29:24 --> Helper loaded: file_helper
INFO - 2023-09-26 17:29:24 --> Database Driver Class Initialized
INFO - 2023-09-26 17:29:24 --> Email Class Initialized
DEBUG - 2023-09-26 17:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:29:24 --> Controller Class Initialized
INFO - 2023-09-26 17:29:24 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:29:24 --> Model "Home_model" initialized
INFO - 2023-09-26 17:29:24 --> Helper loaded: download_helper
INFO - 2023-09-26 17:29:24 --> Helper loaded: form_helper
INFO - 2023-09-26 17:29:24 --> Form Validation Class Initialized
INFO - 2023-09-26 17:29:24 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:29:24 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:29:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:29:24 --> Final output sent to browser
DEBUG - 2023-09-26 17:29:24 --> Total execution time: 0.1981
INFO - 2023-09-26 17:29:31 --> Config Class Initialized
INFO - 2023-09-26 17:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:29:31 --> Utf8 Class Initialized
INFO - 2023-09-26 17:29:35 --> Config Class Initialized
INFO - 2023-09-26 17:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:29:35 --> Utf8 Class Initialized
INFO - 2023-09-26 17:29:35 --> URI Class Initialized
INFO - 2023-09-26 17:29:35 --> Router Class Initialized
INFO - 2023-09-26 17:29:35 --> Output Class Initialized
INFO - 2023-09-26 17:29:35 --> Security Class Initialized
DEBUG - 2023-09-26 17:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:29:35 --> Input Class Initialized
INFO - 2023-09-26 17:29:35 --> Language Class Initialized
INFO - 2023-09-26 17:29:35 --> Loader Class Initialized
INFO - 2023-09-26 17:29:35 --> Helper loaded: url_helper
INFO - 2023-09-26 17:29:35 --> Helper loaded: file_helper
INFO - 2023-09-26 17:29:35 --> Database Driver Class Initialized
INFO - 2023-09-26 17:29:35 --> Email Class Initialized
DEBUG - 2023-09-26 17:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:29:35 --> Controller Class Initialized
INFO - 2023-09-26 17:29:35 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:29:35 --> Model "Home_model" initialized
INFO - 2023-09-26 17:29:35 --> Helper loaded: download_helper
INFO - 2023-09-26 17:29:35 --> Helper loaded: form_helper
INFO - 2023-09-26 17:29:35 --> Form Validation Class Initialized
INFO - 2023-09-26 17:29:36 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:29:36 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:29:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:29:36 --> Final output sent to browser
DEBUG - 2023-09-26 17:29:36 --> Total execution time: 0.1014
INFO - 2023-09-26 17:29:42 --> Config Class Initialized
INFO - 2023-09-26 17:29:42 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:29:42 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:29:42 --> Utf8 Class Initialized
INFO - 2023-09-26 17:29:42 --> URI Class Initialized
INFO - 2023-09-26 17:29:42 --> Router Class Initialized
INFO - 2023-09-26 17:29:42 --> Output Class Initialized
INFO - 2023-09-26 17:29:42 --> Security Class Initialized
DEBUG - 2023-09-26 17:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:29:42 --> Input Class Initialized
INFO - 2023-09-26 17:29:42 --> Language Class Initialized
INFO - 2023-09-26 17:29:42 --> Loader Class Initialized
INFO - 2023-09-26 17:29:42 --> Helper loaded: url_helper
INFO - 2023-09-26 17:29:42 --> Helper loaded: file_helper
INFO - 2023-09-26 17:29:42 --> Database Driver Class Initialized
INFO - 2023-09-26 17:29:42 --> Email Class Initialized
DEBUG - 2023-09-26 17:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:29:42 --> Controller Class Initialized
INFO - 2023-09-26 17:29:42 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:29:42 --> Model "Home_model" initialized
INFO - 2023-09-26 17:29:42 --> Helper loaded: download_helper
INFO - 2023-09-26 17:29:42 --> Helper loaded: form_helper
INFO - 2023-09-26 17:29:42 --> Form Validation Class Initialized
INFO - 2023-09-26 17:29:42 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:29:42 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:29:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:29:43 --> Final output sent to browser
DEBUG - 2023-09-26 17:29:43 --> Total execution time: 0.1136
INFO - 2023-09-26 17:29:50 --> Config Class Initialized
INFO - 2023-09-26 17:29:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:29:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:29:50 --> Utf8 Class Initialized
INFO - 2023-09-26 17:29:50 --> URI Class Initialized
INFO - 2023-09-26 17:29:50 --> Router Class Initialized
INFO - 2023-09-26 17:29:50 --> Output Class Initialized
INFO - 2023-09-26 17:29:50 --> Security Class Initialized
DEBUG - 2023-09-26 17:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:29:50 --> Input Class Initialized
INFO - 2023-09-26 17:29:50 --> Language Class Initialized
INFO - 2023-09-26 17:29:50 --> Loader Class Initialized
INFO - 2023-09-26 17:29:50 --> Helper loaded: url_helper
INFO - 2023-09-26 17:29:50 --> Helper loaded: file_helper
INFO - 2023-09-26 17:29:50 --> Database Driver Class Initialized
INFO - 2023-09-26 17:29:50 --> Email Class Initialized
DEBUG - 2023-09-26 17:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:29:50 --> Controller Class Initialized
INFO - 2023-09-26 17:29:50 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:29:50 --> Model "Home_model" initialized
INFO - 2023-09-26 17:29:50 --> Helper loaded: download_helper
INFO - 2023-09-26 17:29:50 --> Helper loaded: form_helper
INFO - 2023-09-26 17:29:50 --> Form Validation Class Initialized
INFO - 2023-09-26 17:29:50 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:29:50 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:29:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:29:50 --> Final output sent to browser
DEBUG - 2023-09-26 17:29:51 --> Total execution time: 0.1137
INFO - 2023-09-26 17:30:06 --> Config Class Initialized
INFO - 2023-09-26 17:30:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:30:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:30:06 --> Utf8 Class Initialized
INFO - 2023-09-26 17:30:06 --> URI Class Initialized
INFO - 2023-09-26 17:30:06 --> Router Class Initialized
INFO - 2023-09-26 17:30:06 --> Output Class Initialized
INFO - 2023-09-26 17:30:06 --> Security Class Initialized
DEBUG - 2023-09-26 17:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:30:06 --> Input Class Initialized
INFO - 2023-09-26 17:30:06 --> Language Class Initialized
INFO - 2023-09-26 17:30:06 --> Loader Class Initialized
INFO - 2023-09-26 17:30:06 --> Helper loaded: url_helper
INFO - 2023-09-26 17:30:06 --> Helper loaded: file_helper
INFO - 2023-09-26 17:30:06 --> Database Driver Class Initialized
INFO - 2023-09-26 17:30:06 --> Email Class Initialized
DEBUG - 2023-09-26 17:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:30:06 --> Controller Class Initialized
INFO - 2023-09-26 17:30:06 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:30:06 --> Model "Home_model" initialized
INFO - 2023-09-26 17:30:06 --> Helper loaded: download_helper
INFO - 2023-09-26 17:30:06 --> Helper loaded: form_helper
INFO - 2023-09-26 17:30:06 --> Form Validation Class Initialized
INFO - 2023-09-26 17:30:06 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:30:06 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:30:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:30:06 --> Final output sent to browser
DEBUG - 2023-09-26 17:30:06 --> Total execution time: 0.1152
INFO - 2023-09-26 17:32:11 --> Config Class Initialized
INFO - 2023-09-26 17:32:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:32:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:32:11 --> Utf8 Class Initialized
INFO - 2023-09-26 17:32:11 --> URI Class Initialized
INFO - 2023-09-26 17:32:11 --> Router Class Initialized
INFO - 2023-09-26 17:32:11 --> Output Class Initialized
INFO - 2023-09-26 17:32:11 --> Security Class Initialized
DEBUG - 2023-09-26 17:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:32:11 --> Input Class Initialized
INFO - 2023-09-26 17:32:11 --> Language Class Initialized
INFO - 2023-09-26 17:32:11 --> Loader Class Initialized
INFO - 2023-09-26 17:32:11 --> Helper loaded: url_helper
INFO - 2023-09-26 17:32:11 --> Helper loaded: file_helper
INFO - 2023-09-26 17:32:11 --> Database Driver Class Initialized
INFO - 2023-09-26 17:32:11 --> Email Class Initialized
DEBUG - 2023-09-26 17:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:32:11 --> Controller Class Initialized
INFO - 2023-09-26 17:32:11 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:32:11 --> Model "Home_model" initialized
INFO - 2023-09-26 17:32:11 --> Helper loaded: download_helper
INFO - 2023-09-26 17:32:11 --> Helper loaded: form_helper
INFO - 2023-09-26 17:32:11 --> Form Validation Class Initialized
INFO - 2023-09-26 17:32:11 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:32:11 --> Model "Social_media_model" initialized
ERROR - 2023-09-26 17:32:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 52
ERROR - 2023-09-26 17:32:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 72
ERROR - 2023-09-26 17:32:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 158
ERROR - 2023-09-26 17:32:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 162
ERROR - 2023-09-26 17:32:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 166
INFO - 2023-09-26 17:32:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:32:11 --> Final output sent to browser
DEBUG - 2023-09-26 17:32:11 --> Total execution time: 0.1374
INFO - 2023-09-26 17:32:12 --> Config Class Initialized
INFO - 2023-09-26 17:32:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:32:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:32:12 --> Utf8 Class Initialized
INFO - 2023-09-26 17:34:45 --> Config Class Initialized
INFO - 2023-09-26 17:34:45 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:34:45 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:34:45 --> Utf8 Class Initialized
INFO - 2023-09-26 17:34:45 --> URI Class Initialized
INFO - 2023-09-26 17:34:45 --> Router Class Initialized
INFO - 2023-09-26 17:34:45 --> Output Class Initialized
INFO - 2023-09-26 17:34:45 --> Security Class Initialized
DEBUG - 2023-09-26 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:34:45 --> Input Class Initialized
INFO - 2023-09-26 17:34:45 --> Language Class Initialized
INFO - 2023-09-26 17:34:45 --> Loader Class Initialized
INFO - 2023-09-26 17:34:45 --> Helper loaded: url_helper
INFO - 2023-09-26 17:34:45 --> Helper loaded: file_helper
INFO - 2023-09-26 17:34:45 --> Database Driver Class Initialized
INFO - 2023-09-26 17:34:45 --> Email Class Initialized
DEBUG - 2023-09-26 17:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:34:45 --> Controller Class Initialized
INFO - 2023-09-26 17:34:45 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:34:45 --> Model "Home_model" initialized
INFO - 2023-09-26 17:34:45 --> Helper loaded: download_helper
INFO - 2023-09-26 17:34:45 --> Helper loaded: form_helper
INFO - 2023-09-26 17:34:45 --> Form Validation Class Initialized
INFO - 2023-09-26 17:34:45 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:34:45 --> Model "Social_media_model" initialized
ERROR - 2023-09-26 17:34:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 52
ERROR - 2023-09-26 17:34:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 72
ERROR - 2023-09-26 17:34:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 158
ERROR - 2023-09-26 17:34:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 162
ERROR - 2023-09-26 17:34:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\home\service_detail.php 166
INFO - 2023-09-26 17:34:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:34:45 --> Final output sent to browser
DEBUG - 2023-09-26 17:34:45 --> Total execution time: 0.2138
INFO - 2023-09-26 17:34:46 --> Config Class Initialized
INFO - 2023-09-26 17:34:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:34:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:34:46 --> Utf8 Class Initialized
INFO - 2023-09-26 17:34:55 --> Config Class Initialized
INFO - 2023-09-26 17:34:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:34:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:34:55 --> Utf8 Class Initialized
INFO - 2023-09-26 17:34:55 --> URI Class Initialized
INFO - 2023-09-26 17:34:55 --> Router Class Initialized
INFO - 2023-09-26 17:34:55 --> Output Class Initialized
INFO - 2023-09-26 17:34:55 --> Security Class Initialized
DEBUG - 2023-09-26 17:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:34:55 --> Input Class Initialized
INFO - 2023-09-26 17:34:55 --> Language Class Initialized
INFO - 2023-09-26 17:34:55 --> Loader Class Initialized
INFO - 2023-09-26 17:34:55 --> Helper loaded: url_helper
INFO - 2023-09-26 17:34:55 --> Helper loaded: file_helper
INFO - 2023-09-26 17:34:55 --> Database Driver Class Initialized
INFO - 2023-09-26 17:34:55 --> Email Class Initialized
DEBUG - 2023-09-26 17:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:34:55 --> Controller Class Initialized
INFO - 2023-09-26 17:34:55 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:34:55 --> Model "Home_model" initialized
INFO - 2023-09-26 17:34:55 --> Helper loaded: download_helper
INFO - 2023-09-26 17:34:55 --> Helper loaded: form_helper
INFO - 2023-09-26 17:34:55 --> Form Validation Class Initialized
INFO - 2023-09-26 17:34:55 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:34:55 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:34:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:34:55 --> Final output sent to browser
DEBUG - 2023-09-26 17:34:55 --> Total execution time: 0.1404
INFO - 2023-09-26 17:35:04 --> Config Class Initialized
INFO - 2023-09-26 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:35:04 --> Utf8 Class Initialized
INFO - 2023-09-26 17:35:04 --> URI Class Initialized
INFO - 2023-09-26 17:35:04 --> Router Class Initialized
INFO - 2023-09-26 17:35:04 --> Output Class Initialized
INFO - 2023-09-26 17:35:04 --> Security Class Initialized
DEBUG - 2023-09-26 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:35:04 --> Input Class Initialized
INFO - 2023-09-26 17:35:04 --> Language Class Initialized
INFO - 2023-09-26 17:35:04 --> Loader Class Initialized
INFO - 2023-09-26 17:35:04 --> Helper loaded: url_helper
INFO - 2023-09-26 17:35:04 --> Helper loaded: file_helper
INFO - 2023-09-26 17:35:04 --> Database Driver Class Initialized
INFO - 2023-09-26 17:35:04 --> Email Class Initialized
DEBUG - 2023-09-26 17:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:35:04 --> Controller Class Initialized
INFO - 2023-09-26 17:35:04 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:35:04 --> Model "Home_model" initialized
INFO - 2023-09-26 17:35:04 --> Helper loaded: download_helper
INFO - 2023-09-26 17:35:04 --> Helper loaded: form_helper
INFO - 2023-09-26 17:35:04 --> Form Validation Class Initialized
INFO - 2023-09-26 17:35:04 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:35:04 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:35:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:35:04 --> Final output sent to browser
DEBUG - 2023-09-26 17:35:04 --> Total execution time: 0.1190
INFO - 2023-09-26 17:35:15 --> Config Class Initialized
INFO - 2023-09-26 17:35:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:35:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:35:15 --> Utf8 Class Initialized
INFO - 2023-09-26 17:35:15 --> URI Class Initialized
INFO - 2023-09-26 17:35:15 --> Router Class Initialized
INFO - 2023-09-26 17:35:15 --> Output Class Initialized
INFO - 2023-09-26 17:35:15 --> Security Class Initialized
DEBUG - 2023-09-26 17:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:35:15 --> Input Class Initialized
INFO - 2023-09-26 17:35:15 --> Language Class Initialized
INFO - 2023-09-26 17:35:15 --> Loader Class Initialized
INFO - 2023-09-26 17:35:15 --> Helper loaded: url_helper
INFO - 2023-09-26 17:35:15 --> Helper loaded: file_helper
INFO - 2023-09-26 17:35:15 --> Database Driver Class Initialized
INFO - 2023-09-26 17:35:15 --> Email Class Initialized
DEBUG - 2023-09-26 17:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:35:15 --> Controller Class Initialized
INFO - 2023-09-26 17:35:15 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:35:15 --> Model "Home_model" initialized
INFO - 2023-09-26 17:35:15 --> Helper loaded: download_helper
INFO - 2023-09-26 17:35:15 --> Helper loaded: form_helper
INFO - 2023-09-26 17:35:15 --> Form Validation Class Initialized
INFO - 2023-09-26 17:35:15 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:35:15 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:35:15 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:35:15 --> Final output sent to browser
DEBUG - 2023-09-26 17:35:15 --> Total execution time: 0.1051
INFO - 2023-09-26 17:35:42 --> Config Class Initialized
INFO - 2023-09-26 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-26 17:36:09 --> Config Class Initialized
INFO - 2023-09-26 17:36:09 --> Hooks Class Initialized
DEBUG - 2023-09-26 17:36:09 --> UTF-8 Support Enabled
INFO - 2023-09-26 17:36:09 --> Utf8 Class Initialized
INFO - 2023-09-26 17:36:09 --> URI Class Initialized
INFO - 2023-09-26 17:36:09 --> Router Class Initialized
INFO - 2023-09-26 17:36:09 --> Output Class Initialized
INFO - 2023-09-26 17:36:09 --> Security Class Initialized
DEBUG - 2023-09-26 17:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 17:36:09 --> Input Class Initialized
INFO - 2023-09-26 17:36:09 --> Language Class Initialized
INFO - 2023-09-26 17:36:09 --> Loader Class Initialized
INFO - 2023-09-26 17:36:09 --> Helper loaded: url_helper
INFO - 2023-09-26 17:36:09 --> Helper loaded: file_helper
INFO - 2023-09-26 17:36:09 --> Database Driver Class Initialized
INFO - 2023-09-26 17:36:09 --> Email Class Initialized
DEBUG - 2023-09-26 17:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-26 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 17:36:09 --> Controller Class Initialized
INFO - 2023-09-26 17:36:09 --> Model "Contact_model" initialized
INFO - 2023-09-26 17:36:09 --> Model "Home_model" initialized
INFO - 2023-09-26 17:36:09 --> Helper loaded: download_helper
INFO - 2023-09-26 17:36:09 --> Helper loaded: form_helper
INFO - 2023-09-26 17:36:09 --> Form Validation Class Initialized
INFO - 2023-09-26 17:36:09 --> Helper loaded: custom_helper
INFO - 2023-09-26 17:36:09 --> Model "Social_media_model" initialized
INFO - 2023-09-26 17:36:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-26 17:36:09 --> Final output sent to browser
DEBUG - 2023-09-26 17:36:09 --> Total execution time: 0.1018
