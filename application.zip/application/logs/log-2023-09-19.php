<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-19 10:57:40 --> Config Class Initialized
INFO - 2023-09-19 10:57:40 --> Hooks Class Initialized
DEBUG - 2023-09-19 10:57:40 --> UTF-8 Support Enabled
INFO - 2023-09-19 10:57:40 --> Utf8 Class Initialized
INFO - 2023-09-19 10:57:40 --> URI Class Initialized
DEBUG - 2023-09-19 10:57:40 --> No URI present. Default controller set.
INFO - 2023-09-19 10:57:40 --> Router Class Initialized
INFO - 2023-09-19 10:57:40 --> Output Class Initialized
INFO - 2023-09-19 10:57:40 --> Security Class Initialized
DEBUG - 2023-09-19 10:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 10:57:40 --> Input Class Initialized
INFO - 2023-09-19 10:57:40 --> Language Class Initialized
INFO - 2023-09-19 10:57:41 --> Loader Class Initialized
INFO - 2023-09-19 10:57:41 --> Helper loaded: url_helper
INFO - 2023-09-19 10:57:41 --> Helper loaded: file_helper
INFO - 2023-09-19 10:57:41 --> Database Driver Class Initialized
INFO - 2023-09-19 10:57:41 --> Email Class Initialized
DEBUG - 2023-09-19 10:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-19 10:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 10:57:41 --> Controller Class Initialized
INFO - 2023-09-19 10:57:41 --> Model "Contact_model" initialized
INFO - 2023-09-19 10:57:41 --> Model "Home_model" initialized
INFO - 2023-09-19 10:57:41 --> Helper loaded: download_helper
INFO - 2023-09-19 10:57:41 --> Helper loaded: form_helper
INFO - 2023-09-19 10:57:41 --> Form Validation Class Initialized
INFO - 2023-09-19 10:57:41 --> Helper loaded: custom_helper
INFO - 2023-09-19 10:57:41 --> Model "Social_media_model" initialized
INFO - 2023-09-19 10:57:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-19 10:57:41 --> Final output sent to browser
DEBUG - 2023-09-19 10:57:41 --> Total execution time: 0.9546
INFO - 2023-09-19 10:59:04 --> Config Class Initialized
INFO - 2023-09-19 10:59:04 --> Hooks Class Initialized
DEBUG - 2023-09-19 10:59:04 --> UTF-8 Support Enabled
INFO - 2023-09-19 10:59:04 --> Utf8 Class Initialized
INFO - 2023-09-19 10:59:04 --> URI Class Initialized
DEBUG - 2023-09-19 10:59:04 --> No URI present. Default controller set.
INFO - 2023-09-19 10:59:04 --> Router Class Initialized
INFO - 2023-09-19 10:59:04 --> Output Class Initialized
INFO - 2023-09-19 10:59:04 --> Security Class Initialized
DEBUG - 2023-09-19 10:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 10:59:04 --> Input Class Initialized
INFO - 2023-09-19 10:59:04 --> Language Class Initialized
INFO - 2023-09-19 10:59:04 --> Loader Class Initialized
INFO - 2023-09-19 10:59:04 --> Helper loaded: url_helper
INFO - 2023-09-19 10:59:04 --> Helper loaded: file_helper
INFO - 2023-09-19 10:59:04 --> Database Driver Class Initialized
INFO - 2023-09-19 10:59:04 --> Email Class Initialized
DEBUG - 2023-09-19 10:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-19 10:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 10:59:04 --> Controller Class Initialized
INFO - 2023-09-19 10:59:04 --> Model "Contact_model" initialized
INFO - 2023-09-19 10:59:04 --> Model "Home_model" initialized
INFO - 2023-09-19 10:59:04 --> Helper loaded: download_helper
INFO - 2023-09-19 10:59:04 --> Helper loaded: form_helper
INFO - 2023-09-19 10:59:04 --> Form Validation Class Initialized
INFO - 2023-09-19 10:59:04 --> Helper loaded: custom_helper
INFO - 2023-09-19 10:59:04 --> Model "Social_media_model" initialized
INFO - 2023-09-19 10:59:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-19 10:59:04 --> Final output sent to browser
DEBUG - 2023-09-19 10:59:04 --> Total execution time: 0.0546
INFO - 2023-09-19 10:59:14 --> Config Class Initialized
INFO - 2023-09-19 10:59:14 --> Hooks Class Initialized
DEBUG - 2023-09-19 10:59:14 --> UTF-8 Support Enabled
INFO - 2023-09-19 10:59:14 --> Utf8 Class Initialized
INFO - 2023-09-19 10:59:14 --> URI Class Initialized
DEBUG - 2023-09-19 10:59:14 --> No URI present. Default controller set.
INFO - 2023-09-19 10:59:14 --> Router Class Initialized
INFO - 2023-09-19 10:59:14 --> Output Class Initialized
INFO - 2023-09-19 10:59:14 --> Security Class Initialized
DEBUG - 2023-09-19 10:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 10:59:14 --> Input Class Initialized
INFO - 2023-09-19 10:59:14 --> Language Class Initialized
INFO - 2023-09-19 10:59:14 --> Loader Class Initialized
INFO - 2023-09-19 10:59:14 --> Helper loaded: url_helper
INFO - 2023-09-19 10:59:14 --> Helper loaded: file_helper
INFO - 2023-09-19 10:59:14 --> Database Driver Class Initialized
INFO - 2023-09-19 10:59:14 --> Email Class Initialized
DEBUG - 2023-09-19 10:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-19 10:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 10:59:14 --> Controller Class Initialized
INFO - 2023-09-19 10:59:14 --> Model "Contact_model" initialized
INFO - 2023-09-19 10:59:14 --> Model "Home_model" initialized
INFO - 2023-09-19 10:59:14 --> Helper loaded: download_helper
INFO - 2023-09-19 10:59:14 --> Helper loaded: form_helper
INFO - 2023-09-19 10:59:14 --> Form Validation Class Initialized
INFO - 2023-09-19 10:59:14 --> Helper loaded: custom_helper
INFO - 2023-09-19 10:59:14 --> Model "Social_media_model" initialized
INFO - 2023-09-19 10:59:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-19 10:59:14 --> Final output sent to browser
DEBUG - 2023-09-19 10:59:14 --> Total execution time: 0.0750
INFO - 2023-09-19 11:01:06 --> Config Class Initialized
INFO - 2023-09-19 11:01:06 --> Hooks Class Initialized
DEBUG - 2023-09-19 11:01:06 --> UTF-8 Support Enabled
INFO - 2023-09-19 11:01:06 --> Utf8 Class Initialized
INFO - 2023-09-19 11:01:06 --> URI Class Initialized
DEBUG - 2023-09-19 11:01:06 --> No URI present. Default controller set.
INFO - 2023-09-19 11:01:06 --> Router Class Initialized
INFO - 2023-09-19 11:01:06 --> Output Class Initialized
INFO - 2023-09-19 11:01:06 --> Security Class Initialized
DEBUG - 2023-09-19 11:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-19 11:01:06 --> Input Class Initialized
INFO - 2023-09-19 11:01:06 --> Language Class Initialized
INFO - 2023-09-19 11:01:06 --> Loader Class Initialized
INFO - 2023-09-19 11:01:06 --> Helper loaded: url_helper
INFO - 2023-09-19 11:01:06 --> Helper loaded: file_helper
INFO - 2023-09-19 11:01:06 --> Database Driver Class Initialized
INFO - 2023-09-19 11:01:06 --> Email Class Initialized
DEBUG - 2023-09-19 11:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-19 11:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-19 11:01:06 --> Controller Class Initialized
INFO - 2023-09-19 11:01:06 --> Model "Contact_model" initialized
INFO - 2023-09-19 11:01:06 --> Model "Home_model" initialized
INFO - 2023-09-19 11:01:06 --> Helper loaded: download_helper
INFO - 2023-09-19 11:01:06 --> Helper loaded: form_helper
INFO - 2023-09-19 11:01:06 --> Form Validation Class Initialized
INFO - 2023-09-19 11:01:06 --> Helper loaded: custom_helper
INFO - 2023-09-19 11:01:06 --> Model "Social_media_model" initialized
INFO - 2023-09-19 11:01:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-19 11:01:06 --> Final output sent to browser
DEBUG - 2023-09-19 11:01:06 --> Total execution time: 0.0761
