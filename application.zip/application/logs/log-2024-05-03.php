<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-05-03 06:08:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:08:02 --> No URI present. Default controller set.
DEBUG - 2024-05-03 06:08:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-03 06:08:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\dw\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-03 06:08:07 --> Unable to connect to the database
DEBUG - 2024-05-03 06:08:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:08:13 --> No URI present. Default controller set.
DEBUG - 2024-05-03 06:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-03 06:08:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\dw\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-03 06:08:17 --> Unable to connect to the database
DEBUG - 2024-05-03 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:09:36 --> No URI present. Default controller set.
DEBUG - 2024-05-03 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 09:39:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 09:39:37 --> Total execution time: 1.1755
DEBUG - 2024-05-03 06:09:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:09:48 --> Total execution time: 0.3360
DEBUG - 2024-05-03 06:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 09:39:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 09:39:49 --> Total execution time: 0.0951
DEBUG - 2024-05-03 06:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:10:03 --> Total execution time: 0.2351
DEBUG - 2024-05-03 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:15:01 --> Severity: error --> Exception: Unable to locate the model you have specified: MetaTagsDataModel C:\xampp\htdocs\dw\system\core\Loader.php 349
DEBUG - 2024-05-03 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:15:18 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 67
ERROR - 2024-05-03 06:15:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 67
DEBUG - 2024-05-03 06:15:18 --> Total execution time: 0.1152
DEBUG - 2024-05-03 06:15:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 09:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 09:45:19 --> Total execution time: 0.0771
DEBUG - 2024-05-03 06:17:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:17:20 --> Total execution time: 0.0798
DEBUG - 2024-05-03 06:17:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:17:52 --> Total execution time: 0.1079
DEBUG - 2024-05-03 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 09:47:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 09:47:53 --> Total execution time: 0.0897
DEBUG - 2024-05-03 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:19:57 --> Total execution time: 0.0969
DEBUG - 2024-05-03 06:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 09:49:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 09:49:58 --> Total execution time: 0.0946
DEBUG - 2024-05-03 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:20:31 --> Total execution time: 0.1074
DEBUG - 2024-05-03 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:32:00 --> Total execution time: 0.1314
DEBUG - 2024-05-03 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:33:11 --> Total execution time: 0.1278
DEBUG - 2024-05-03 06:38:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:38:03 --> Total execution time: 0.1270
DEBUG - 2024-05-03 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:08:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:08:08 --> Total execution time: 0.1321
DEBUG - 2024-05-03 06:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:38:30 --> Total execution time: 0.1381
DEBUG - 2024-05-03 06:38:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:38:32 --> Total execution time: 0.0615
DEBUG - 2024-05-03 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:08:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:08:33 --> Total execution time: 0.0871
DEBUG - 2024-05-03 06:38:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:39:23 --> Total execution time: 0.0961
DEBUG - 2024-05-03 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:39:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:39:35 --> Total execution time: 0.0884
DEBUG - 2024-05-03 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:41:38 --> Total execution time: 0.1177
DEBUG - 2024-05-03 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:11:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:11:39 --> Total execution time: 0.0989
DEBUG - 2024-05-03 06:41:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:41:53 --> Total execution time: 0.0907
DEBUG - 2024-05-03 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:42:29 --> Total execution time: 0.1223
DEBUG - 2024-05-03 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:12:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:12:30 --> Total execution time: 0.0923
DEBUG - 2024-05-03 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:42:38 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 70
ERROR - 2024-05-03 06:42:38 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:42:38 --> Total execution time: 0.0923
DEBUG - 2024-05-03 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:12:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:12:38 --> Total execution time: 0.0894
DEBUG - 2024-05-03 06:42:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:42:57 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:42:57 --> Total execution time: 0.0977
DEBUG - 2024-05-03 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:43:05 --> Total execution time: 0.0944
DEBUG - 2024-05-03 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:13:06 --> Total execution time: 0.0729
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-05-03 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:13:06 --> Total execution time: 0.1058
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:13:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:13:06 --> Total execution time: 0.1240
DEBUG - 2024-05-03 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:43:10 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:43:10 --> Total execution time: 0.1062
DEBUG - 2024-05-03 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:43:12 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:43:12 --> Total execution time: 0.1193
DEBUG - 2024-05-03 06:45:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:45:20 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:45:20 --> Total execution time: 0.1198
DEBUG - 2024-05-03 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:15:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:15:21 --> Total execution time: 0.1034
DEBUG - 2024-05-03 06:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:15:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:15:33 --> Total execution time: 0.1011
DEBUG - 2024-05-03 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:45:36 --> Total execution time: 0.1236
DEBUG - 2024-05-03 06:45:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:45:38 --> Total execution time: 0.0993
DEBUG - 2024-05-03 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:46:10 --> Total execution time: 0.0691
DEBUG - 2024-05-03 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:16:11 --> Total execution time: 0.0662
DEBUG - 2024-05-03 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:46:16 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:46:16 --> Total execution time: 0.0903
DEBUG - 2024-05-03 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:46:19 --> Total execution time: 0.0709
DEBUG - 2024-05-03 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:46:23 --> Total execution time: 0.1236
DEBUG - 2024-05-03 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:47:19 --> Total execution time: 0.1405
DEBUG - 2024-05-03 06:47:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:17:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:17:20 --> Total execution time: 0.0984
DEBUG - 2024-05-03 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:47:21 --> Total execution time: 0.1319
DEBUG - 2024-05-03 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:17:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:17:21 --> Total execution time: 0.1037
DEBUG - 2024-05-03 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:47:25 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:47:25 --> Total execution time: 0.0954
DEBUG - 2024-05-03 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:48:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 39
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 39
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $categories C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 49
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 49
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 65
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 65
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 75
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 75
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 91
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 91
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 104
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 104
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 105
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 105
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 106
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 106
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 124
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 124
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 136
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 136
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 148
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 148
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 160
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 160
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 173
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 173
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 183
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 183
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 196
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 196
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 206
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 206
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 219
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 219
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 229
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 229
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 241
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 241
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 252
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 252
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 263
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 263
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 272
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 272
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 274
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 274
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Undefined variable $service C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 276
ERROR - 2024-05-03 06:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 276
DEBUG - 2024-05-03 06:48:02 --> Total execution time: 0.1588
DEBUG - 2024-05-03 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:18:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:18:03 --> Total execution time: 0.0690
DEBUG - 2024-05-03 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:50:43 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:50:43 --> Severity: error --> Exception: Call to undefined function meta_tag() C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 71
DEBUG - 2024-05-03 06:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:50:59 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 71
DEBUG - 2024-05-03 06:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:51:11 --> Severity: Warning --> Attempt to read property "meta_name" on array C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 71
DEBUG - 2024-05-03 06:51:11 --> Total execution time: 0.1272
DEBUG - 2024-05-03 06:51:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:51:37 --> Severity: Warning --> Attempt to read property "meta_name" on array C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 50
ERROR - 2024-05-03 06:51:37 --> Severity: Warning --> Attempt to read property "meta_name" on array C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 71
DEBUG - 2024-05-03 06:51:37 --> Total execution time: 0.1353
DEBUG - 2024-05-03 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:52:08 --> Severity: Warning --> Attempt to read property "meta_name" on array C:\xampp\htdocs\dw\application\views\admin\meta_tags_edit.php 71
DEBUG - 2024-05-03 06:52:08 --> Total execution time: 0.0896
DEBUG - 2024-05-03 06:52:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:52:38 --> Total execution time: 0.1456
DEBUG - 2024-05-03 06:53:51 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:53:51 --> Total execution time: 0.1202
DEBUG - 2024-05-03 06:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:56:29 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 06:56:29 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:56:29 --> Total execution time: 0.0906
DEBUG - 2024-05-03 06:56:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:56:38 --> Total execution time: 0.0730
DEBUG - 2024-05-03 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:56:47 --> Total execution time: 0.1292
DEBUG - 2024-05-03 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:54 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:56:55 --> Total execution time: 0.1332
DEBUG - 2024-05-03 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:56:56 --> Total execution time: 0.0744
DEBUG - 2024-05-03 06:56:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:26:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:26:57 --> Total execution time: 0.0984
DEBUG - 2024-05-03 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:57:42 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:57:42 --> Total execution time: 0.1277
DEBUG - 2024-05-03 06:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:57:44 --> Total execution time: 0.1383
DEBUG - 2024-05-03 06:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:57:52 --> Total execution time: 0.0741
DEBUG - 2024-05-03 06:58:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:58:53 --> Total execution time: 0.1504
DEBUG - 2024-05-03 06:58:54 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:28:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:28:54 --> Total execution time: 0.0744
DEBUG - 2024-05-03 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:58:58 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 06:58:58 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:58:58 --> Total execution time: 0.0929
DEBUG - 2024-05-03 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:28:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:28:58 --> Total execution time: 0.0887
DEBUG - 2024-05-03 06:59:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:59:01 --> Total execution time: 0.1073
DEBUG - 2024-05-03 06:59:07 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 06:59:07 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:59:07 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 06:59:07 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:59:07 --> Total execution time: 0.0822
DEBUG - 2024-05-03 06:59:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 06:59:25 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 06:59:25 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 06:59:25 --> Total execution time: 0.1446
DEBUG - 2024-05-03 06:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 06:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 06:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:29:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:29:27 --> Total execution time: 0.0835
DEBUG - 2024-05-03 07:15:17 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:15:17 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:45:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:45:17 --> Total execution time: 0.1511
DEBUG - 2024-05-03 07:15:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:15:19 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:45:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:45:19 --> Total execution time: 0.0781
DEBUG - 2024-05-03 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:20:04 --> Total execution time: 0.0922
DEBUG - 2024-05-03 07:20:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:50:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:50:05 --> Total execution time: 0.1029
DEBUG - 2024-05-03 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 07:20:23 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:20:23 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:20:23 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 07:20:23 --> Total execution time: 0.1008
DEBUG - 2024-05-03 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:20:59 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:21:15 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:51:15 --> Severity: Warning --> Attempt to read property "name" on array C:\xampp\htdocs\dw\application\controllers\HomeController.php 25
DEBUG - 2024-05-03 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:21:31 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:51:32 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\dw\application\controllers\HomeController.php 25
DEBUG - 2024-05-03 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:21:33 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:51:33 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\dw\application\controllers\HomeController.php 25
DEBUG - 2024-05-03 07:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:21:39 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:22:24 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:52:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:52:24 --> Total execution time: 0.1303
DEBUG - 2024-05-03 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:24:11 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:54:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:54:11 --> Total execution time: 0.1891
DEBUG - 2024-05-03 07:24:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:24:39 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 10:54:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 10:54:39 --> Total execution time: 0.1637
DEBUG - 2024-05-03 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:10 --> Total execution time: 0.2643
DEBUG - 2024-05-03 07:38:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:14 --> Total execution time: 0.2091
DEBUG - 2024-05-03 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:08:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:08:14 --> Total execution time: 0.0688
DEBUG - 2024-05-03 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 48
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 59
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 74
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 87
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 104
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 117
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 132
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 151
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 163
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 176
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 187
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 198
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 209
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 211
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 214
ERROR - 2024-05-03 07:38:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 216
DEBUG - 2024-05-03 07:38:14 --> Total execution time: 0.0996
DEBUG - 2024-05-03 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:38 --> Total execution time: 0.0893
DEBUG - 2024-05-03 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:40 --> Total execution time: 0.1350
DEBUG - 2024-05-03 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:08:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:08:40 --> Total execution time: 0.0836
DEBUG - 2024-05-03 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 48
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 59
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 74
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 87
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 104
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 117
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 132
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 151
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 163
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 176
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 187
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 198
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 209
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 211
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 214
ERROR - 2024-05-03 07:38:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 216
DEBUG - 2024-05-03 07:38:41 --> Total execution time: 0.0931
DEBUG - 2024-05-03 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:38:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:38:58 --> No URI present. Default controller set.
DEBUG - 2024-05-03 07:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:08:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:08:58 --> Total execution time: 0.1737
DEBUG - 2024-05-03 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:39:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:09:13 --> Total execution time: 0.1670
DEBUG - 2024-05-03 07:39:51 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:09:51 --> Total execution time: 0.1508
DEBUG - 2024-05-03 07:39:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:09:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:09:56 --> Total execution time: 0.1038
DEBUG - 2024-05-03 07:40:09 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:10 --> Total execution time: 0.1664
DEBUG - 2024-05-03 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 147
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 148
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 149
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:11 --> Total execution time: 0.1358
DEBUG - 2024-05-03 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-03 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-05-03 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:11 --> Total execution time: 0.0727
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:11 --> Total execution time: 0.1155
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:11 --> Total execution time: 0.1522
DEBUG - 2024-05-03 07:40:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:16 --> Total execution time: 0.1882
DEBUG - 2024-05-03 07:40:18 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 101
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 102
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 103
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:10:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:10:18 --> Total execution time: 0.1442
DEBUG - 2024-05-03 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 07:40:55 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:40:55 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:40:55 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 07:40:55 --> Total execution time: 0.1248
DEBUG - 2024-05-03 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:40:56 --> Total execution time: 0.0812
DEBUG - 2024-05-03 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 07:41:05 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:41:05 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:41:05 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 07:41:05 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 07:41:05 --> Total execution time: 0.0583
DEBUG - 2024-05-03 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:11:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:11:09 --> Total execution time: 0.0799
DEBUG - 2024-05-03 07:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 41
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 42
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 43
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:19:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:19:24 --> Total execution time: 0.1363
DEBUG - 2024-05-03 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 41
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 42
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 43
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:21:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:21:22 --> Total execution time: 0.1464
DEBUG - 2024-05-03 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 41
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 42
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 43
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:22:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:22:02 --> Total execution time: 0.1223
DEBUG - 2024-05-03 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 42
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\controllers\HomeController.php 43
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:22:35 --> Total execution time: 0.0962
DEBUG - 2024-05-03 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:23:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:23:13 --> Total execution time: 0.1335
DEBUG - 2024-05-03 07:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:27:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:27:01 --> Total execution time: 0.0884
DEBUG - 2024-05-03 07:57:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:27:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:27:03 --> Total execution time: 0.1183
DEBUG - 2024-05-03 07:57:07 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 07:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 07:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:27:07 --> Total execution time: 0.0935
DEBUG - 2024-05-03 08:01:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 08:01:38 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:38 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:38 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:38 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 08:01:38 --> Total execution time: 0.0813
DEBUG - 2024-05-03 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 08:01:40 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:40 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:40 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:01:40 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 08:01:40 --> Total execution time: 0.0626
DEBUG - 2024-05-03 08:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 08:20:22 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:20:22 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:20:22 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
ERROR - 2024-05-03 08:20:22 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\dw\application\views\admin\meta_tags_list.php 71
DEBUG - 2024-05-03 08:20:22 --> Total execution time: 0.0495
DEBUG - 2024-05-03 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:22:01 --> Total execution time: 0.0537
DEBUG - 2024-05-03 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:52:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:52:02 --> Total execution time: 0.0679
DEBUG - 2024-05-03 08:22:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:22:05 --> Total execution time: 0.0365
DEBUG - 2024-05-03 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:26:42 --> Total execution time: 0.0476
DEBUG - 2024-05-03 08:26:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:26:48 --> Total execution time: 0.0520
DEBUG - 2024-05-03 08:26:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:26:50 --> Total execution time: 0.0412
DEBUG - 2024-05-03 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:27:04 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:27:04 --> Total execution time: 0.0337
DEBUG - 2024-05-03 08:27:07 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:27:07 --> Total execution time: 0.0444
DEBUG - 2024-05-03 08:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:30 --> Total execution time: 0.0623
DEBUG - 2024-05-03 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:32 --> Total execution time: 0.0617
DEBUG - 2024-05-03 08:28:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:35 --> Total execution time: 0.0697
DEBUG - 2024-05-03 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:49 --> Total execution time: 0.0626
DEBUG - 2024-05-03 08:28:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:58 --> Total execution time: 0.0646
DEBUG - 2024-05-03 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:59 --> Total execution time: 0.0904
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-05-03 08:28:59 --> UTF-8 Support Enabled
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-05-03 08:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:59 --> Total execution time: 0.1302
DEBUG - 2024-05-03 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:58:59 --> Total execution time: 0.1426
DEBUG - 2024-05-03 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:59:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:59:05 --> Total execution time: 0.0666
DEBUG - 2024-05-03 08:29:44 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 11:59:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 11:59:44 --> Total execution time: 0.0687
DEBUG - 2024-05-03 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:00:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:00:12 --> Total execution time: 0.0630
DEBUG - 2024-05-03 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:31:52 --> Total execution time: 0.1242
DEBUG - 2024-05-03 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:26 --> Total execution time: 0.0773
DEBUG - 2024-05-03 08:32:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:28 --> Total execution time: 0.0420
DEBUG - 2024-05-03 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:31 --> Total execution time: 0.0451
DEBUG - 2024-05-03 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:02:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:02:32 --> Total execution time: 0.0689
DEBUG - 2024-05-03 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:51 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:51 --> Total execution time: 0.0460
DEBUG - 2024-05-03 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:32:53 --> Total execution time: 0.0501
DEBUG - 2024-05-03 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:33:02 --> Total execution time: 0.1101
DEBUG - 2024-05-03 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:33:12 --> Total execution time: 0.0841
DEBUG - 2024-05-03 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:38:52 --> Total execution time: 0.0515
DEBUG - 2024-05-03 08:40:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:40:10 --> Total execution time: 0.1105
DEBUG - 2024-05-03 08:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:46:23 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:16:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:16:23 --> Total execution time: 0.0579
DEBUG - 2024-05-03 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:16:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:16:36 --> Total execution time: 0.0773
DEBUG - 2024-05-03 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:20 --> Total execution time: 0.0830
DEBUG - 2024-05-03 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:20 --> Total execution time: 0.1029
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:20 --> Total execution time: 0.1866
DEBUG - 2024-05-03 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:24 --> Total execution time: 0.0971
DEBUG - 2024-05-03 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:24 --> Total execution time: 0.1703
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:24 --> Total execution time: 0.1597
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:24 --> Total execution time: 0.2768
DEBUG - 2024-05-03 08:48:46 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:46 --> No URI present. Default controller set.
DEBUG - 2024-05-03 08:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:18:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:18:46 --> Total execution time: 0.0989
DEBUG - 2024-05-03 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:48:55 --> Total execution time: 0.1264
DEBUG - 2024-05-03 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-03 08:49:13 --> Total execution time: 0.0503
DEBUG - 2024-05-03 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:49:18 --> No URI present. Default controller set.
DEBUG - 2024-05-03 08:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:19:18 --> Total execution time: 0.1368
DEBUG - 2024-05-03 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:49:19 --> No URI present. Default controller set.
DEBUG - 2024-05-03 08:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:19:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:19:19 --> Total execution time: 0.0876
DEBUG - 2024-05-03 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-03 08:49:28 --> No URI present. Default controller set.
DEBUG - 2024-05-03 08:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-03 08:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-03 12:19:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-03 12:19:28 --> Total execution time: 0.0996
