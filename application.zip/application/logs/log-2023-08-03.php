<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-03 16:47:52 --> Config Class Initialized
INFO - 2023-08-03 16:47:52 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:47:52 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:47:52 --> Utf8 Class Initialized
INFO - 2023-08-03 16:47:52 --> URI Class Initialized
DEBUG - 2023-08-03 16:47:52 --> No URI present. Default controller set.
INFO - 2023-08-03 16:47:52 --> Router Class Initialized
INFO - 2023-08-03 16:47:52 --> Output Class Initialized
INFO - 2023-08-03 16:47:52 --> Security Class Initialized
DEBUG - 2023-08-03 16:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:47:52 --> Input Class Initialized
INFO - 2023-08-03 16:47:52 --> Language Class Initialized
INFO - 2023-08-03 16:47:52 --> Loader Class Initialized
INFO - 2023-08-03 16:47:52 --> Helper loaded: url_helper
INFO - 2023-08-03 16:47:52 --> Helper loaded: file_helper
INFO - 2023-08-03 16:47:52 --> Database Driver Class Initialized
INFO - 2023-08-03 16:47:52 --> Email Class Initialized
DEBUG - 2023-08-03 16:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-03 16:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-03 16:47:52 --> Controller Class Initialized
INFO - 2023-08-03 16:47:52 --> File loaded: C:\xampp\htdocs\DW\application\views\welcome_message.php
INFO - 2023-08-03 16:47:52 --> Final output sent to browser
DEBUG - 2023-08-03 16:47:52 --> Total execution time: 0.0828
INFO - 2023-08-03 16:47:56 --> Config Class Initialized
INFO - 2023-08-03 16:47:56 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:47:56 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:47:56 --> Utf8 Class Initialized
INFO - 2023-08-03 16:47:56 --> URI Class Initialized
INFO - 2023-08-03 16:47:56 --> Router Class Initialized
INFO - 2023-08-03 16:47:56 --> Output Class Initialized
INFO - 2023-08-03 16:47:56 --> Security Class Initialized
DEBUG - 2023-08-03 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:47:56 --> Input Class Initialized
INFO - 2023-08-03 16:47:56 --> Language Class Initialized
INFO - 2023-08-03 16:47:56 --> Loader Class Initialized
INFO - 2023-08-03 16:47:56 --> Helper loaded: url_helper
INFO - 2023-08-03 16:47:56 --> Helper loaded: file_helper
INFO - 2023-08-03 16:47:56 --> Database Driver Class Initialized
INFO - 2023-08-03 16:47:56 --> Email Class Initialized
DEBUG - 2023-08-03 16:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-03 16:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-03 16:47:56 --> Controller Class Initialized
INFO - 2023-08-03 16:47:56 --> Model "Gallery_model" initialized
INFO - 2023-08-03 16:47:56 --> Helper loaded: form_helper
INFO - 2023-08-03 16:47:56 --> Form Validation Class Initialized
INFO - 2023-08-03 16:47:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-03 16:47:56 --> Final output sent to browser
DEBUG - 2023-08-03 16:47:56 --> Total execution time: 0.0598
INFO - 2023-08-03 16:47:57 --> Config Class Initialized
INFO - 2023-08-03 16:47:57 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:47:57 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:47:57 --> Utf8 Class Initialized
INFO - 2023-08-03 16:47:57 --> URI Class Initialized
INFO - 2023-08-03 16:47:57 --> Router Class Initialized
INFO - 2023-08-03 16:47:57 --> Output Class Initialized
INFO - 2023-08-03 16:47:57 --> Security Class Initialized
DEBUG - 2023-08-03 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:47:57 --> Input Class Initialized
INFO - 2023-08-03 16:47:57 --> Language Class Initialized
ERROR - 2023-08-03 16:47:57 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-03 16:47:58 --> Config Class Initialized
INFO - 2023-08-03 16:47:58 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:47:58 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:47:58 --> Utf8 Class Initialized
INFO - 2023-08-03 16:47:58 --> URI Class Initialized
INFO - 2023-08-03 16:47:58 --> Router Class Initialized
INFO - 2023-08-03 16:47:58 --> Output Class Initialized
INFO - 2023-08-03 16:47:58 --> Security Class Initialized
DEBUG - 2023-08-03 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:47:58 --> Input Class Initialized
INFO - 2023-08-03 16:47:58 --> Language Class Initialized
ERROR - 2023-08-03 16:47:58 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-03 16:53:42 --> Config Class Initialized
INFO - 2023-08-03 16:53:42 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:53:42 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:53:42 --> Utf8 Class Initialized
INFO - 2023-08-03 16:53:42 --> URI Class Initialized
INFO - 2023-08-03 16:53:42 --> Router Class Initialized
INFO - 2023-08-03 16:53:42 --> Output Class Initialized
INFO - 2023-08-03 16:53:42 --> Security Class Initialized
DEBUG - 2023-08-03 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:53:42 --> Input Class Initialized
INFO - 2023-08-03 16:53:42 --> Language Class Initialized
INFO - 2023-08-03 16:53:42 --> Loader Class Initialized
INFO - 2023-08-03 16:53:42 --> Helper loaded: url_helper
INFO - 2023-08-03 16:53:42 --> Helper loaded: file_helper
INFO - 2023-08-03 16:53:42 --> Database Driver Class Initialized
INFO - 2023-08-03 16:53:42 --> Email Class Initialized
DEBUG - 2023-08-03 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-03 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-03 16:53:42 --> Controller Class Initialized
INFO - 2023-08-03 16:53:42 --> Model "Services_model" initialized
INFO - 2023-08-03 16:53:42 --> Helper loaded: form_helper
INFO - 2023-08-03 16:53:42 --> Form Validation Class Initialized
INFO - 2023-08-03 16:53:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-03 16:53:42 --> Final output sent to browser
DEBUG - 2023-08-03 16:53:42 --> Total execution time: 0.0769
INFO - 2023-08-03 16:53:42 --> Config Class Initialized
INFO - 2023-08-03 16:53:42 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:53:42 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:53:42 --> Utf8 Class Initialized
INFO - 2023-08-03 16:53:42 --> URI Class Initialized
INFO - 2023-08-03 16:53:42 --> Router Class Initialized
INFO - 2023-08-03 16:53:42 --> Output Class Initialized
INFO - 2023-08-03 16:53:42 --> Security Class Initialized
DEBUG - 2023-08-03 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:53:42 --> Input Class Initialized
INFO - 2023-08-03 16:53:42 --> Language Class Initialized
ERROR - 2023-08-03 16:53:42 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-03 16:53:42 --> Config Class Initialized
INFO - 2023-08-03 16:53:42 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:53:42 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:53:42 --> Utf8 Class Initialized
INFO - 2023-08-03 16:53:42 --> URI Class Initialized
INFO - 2023-08-03 16:53:42 --> Router Class Initialized
INFO - 2023-08-03 16:53:42 --> Output Class Initialized
INFO - 2023-08-03 16:53:42 --> Security Class Initialized
DEBUG - 2023-08-03 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:53:42 --> Input Class Initialized
INFO - 2023-08-03 16:53:42 --> Language Class Initialized
ERROR - 2023-08-03 16:53:42 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-03 16:57:32 --> Config Class Initialized
INFO - 2023-08-03 16:57:32 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:57:32 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:57:32 --> Utf8 Class Initialized
INFO - 2023-08-03 16:57:32 --> URI Class Initialized
INFO - 2023-08-03 16:57:32 --> Router Class Initialized
INFO - 2023-08-03 16:57:32 --> Output Class Initialized
INFO - 2023-08-03 16:57:32 --> Security Class Initialized
DEBUG - 2023-08-03 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:57:32 --> Input Class Initialized
INFO - 2023-08-03 16:57:32 --> Language Class Initialized
INFO - 2023-08-03 16:57:32 --> Loader Class Initialized
INFO - 2023-08-03 16:57:32 --> Helper loaded: url_helper
INFO - 2023-08-03 16:57:32 --> Helper loaded: file_helper
INFO - 2023-08-03 16:57:32 --> Database Driver Class Initialized
INFO - 2023-08-03 16:57:32 --> Email Class Initialized
DEBUG - 2023-08-03 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-03 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-03 16:57:32 --> Controller Class Initialized
INFO - 2023-08-03 16:57:32 --> Model "Services_model" initialized
INFO - 2023-08-03 16:57:32 --> Helper loaded: form_helper
INFO - 2023-08-03 16:57:32 --> Form Validation Class Initialized
INFO - 2023-08-03 16:57:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-03 16:57:35 --> Upload Class Initialized
INFO - 2023-08-03 16:57:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-08-03 16:57:35 --> The upload path does not appear to be valid.
INFO - 2023-08-03 16:57:35 --> Config Class Initialized
INFO - 2023-08-03 16:57:35 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:57:35 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:57:35 --> Utf8 Class Initialized
INFO - 2023-08-03 16:57:35 --> URI Class Initialized
INFO - 2023-08-03 16:57:35 --> Router Class Initialized
INFO - 2023-08-03 16:57:35 --> Output Class Initialized
INFO - 2023-08-03 16:57:35 --> Security Class Initialized
DEBUG - 2023-08-03 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:57:35 --> Input Class Initialized
INFO - 2023-08-03 16:57:35 --> Language Class Initialized
INFO - 2023-08-03 16:57:35 --> Loader Class Initialized
INFO - 2023-08-03 16:57:35 --> Helper loaded: url_helper
INFO - 2023-08-03 16:57:35 --> Helper loaded: file_helper
INFO - 2023-08-03 16:57:35 --> Database Driver Class Initialized
INFO - 2023-08-03 16:57:35 --> Email Class Initialized
DEBUG - 2023-08-03 16:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-03 16:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-03 16:57:35 --> Controller Class Initialized
INFO - 2023-08-03 16:57:35 --> Model "Services_model" initialized
INFO - 2023-08-03 16:57:35 --> Helper loaded: form_helper
INFO - 2023-08-03 16:57:35 --> Form Validation Class Initialized
INFO - 2023-08-03 16:57:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-03 16:57:35 --> Final output sent to browser
DEBUG - 2023-08-03 16:57:35 --> Total execution time: 0.0507
INFO - 2023-08-03 16:57:35 --> Config Class Initialized
INFO - 2023-08-03 16:57:35 --> Hooks Class Initialized
DEBUG - 2023-08-03 16:57:35 --> UTF-8 Support Enabled
INFO - 2023-08-03 16:57:35 --> Utf8 Class Initialized
INFO - 2023-08-03 16:57:35 --> URI Class Initialized
INFO - 2023-08-03 16:57:35 --> Router Class Initialized
INFO - 2023-08-03 16:57:35 --> Output Class Initialized
INFO - 2023-08-03 16:57:35 --> Security Class Initialized
DEBUG - 2023-08-03 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-03 16:57:35 --> Input Class Initialized
INFO - 2023-08-03 16:57:35 --> Language Class Initialized
ERROR - 2023-08-03 16:57:35 --> 404 Page Not Found: admin/Services/images
