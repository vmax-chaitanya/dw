<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-23 16:45:19 --> Config Class Initialized
INFO - 2023-08-23 16:45:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:19 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:19 --> URI Class Initialized
INFO - 2023-08-23 16:45:19 --> Router Class Initialized
INFO - 2023-08-23 16:45:19 --> Output Class Initialized
INFO - 2023-08-23 16:45:19 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:19 --> Input Class Initialized
INFO - 2023-08-23 16:45:19 --> Language Class Initialized
INFO - 2023-08-23 16:45:19 --> Loader Class Initialized
INFO - 2023-08-23 16:45:19 --> Helper loaded: url_helper
INFO - 2023-08-23 16:45:19 --> Helper loaded: file_helper
INFO - 2023-08-23 16:45:20 --> Database Driver Class Initialized
INFO - 2023-08-23 16:45:20 --> Email Class Initialized
DEBUG - 2023-08-23 16:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:45:20 --> Controller Class Initialized
INFO - 2023-08-23 16:45:20 --> Model "Home_model" initialized
INFO - 2023-08-23 16:45:21 --> Helper loaded: form_helper
INFO - 2023-08-23 16:45:21 --> Form Validation Class Initialized
INFO - 2023-08-23 16:45:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training.php
INFO - 2023-08-23 16:45:21 --> Final output sent to browser
DEBUG - 2023-08-23 16:45:21 --> Total execution time: 2.3671
INFO - 2023-08-23 16:45:23 --> Config Class Initialized
INFO - 2023-08-23 16:45:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:23 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:23 --> URI Class Initialized
INFO - 2023-08-23 16:45:23 --> Router Class Initialized
INFO - 2023-08-23 16:45:23 --> Output Class Initialized
INFO - 2023-08-23 16:45:23 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:23 --> Input Class Initialized
INFO - 2023-08-23 16:45:23 --> Language Class Initialized
ERROR - 2023-08-23 16:45:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:23 --> Config Class Initialized
INFO - 2023-08-23 16:45:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:23 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:23 --> URI Class Initialized
INFO - 2023-08-23 16:45:23 --> Router Class Initialized
INFO - 2023-08-23 16:45:23 --> Output Class Initialized
INFO - 2023-08-23 16:45:23 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:23 --> Input Class Initialized
INFO - 2023-08-23 16:45:23 --> Language Class Initialized
ERROR - 2023-08-23 16:45:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:23 --> Config Class Initialized
INFO - 2023-08-23 16:45:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:23 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:23 --> URI Class Initialized
INFO - 2023-08-23 16:45:23 --> Router Class Initialized
INFO - 2023-08-23 16:45:23 --> Output Class Initialized
INFO - 2023-08-23 16:45:23 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:23 --> Input Class Initialized
INFO - 2023-08-23 16:45:23 --> Language Class Initialized
ERROR - 2023-08-23 16:45:23 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:36 --> Config Class Initialized
INFO - 2023-08-23 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:36 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:36 --> URI Class Initialized
INFO - 2023-08-23 16:45:36 --> Router Class Initialized
INFO - 2023-08-23 16:45:36 --> Output Class Initialized
INFO - 2023-08-23 16:45:36 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:36 --> Input Class Initialized
INFO - 2023-08-23 16:45:36 --> Language Class Initialized
ERROR - 2023-08-23 16:45:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:36 --> Config Class Initialized
INFO - 2023-08-23 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:36 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:36 --> URI Class Initialized
INFO - 2023-08-23 16:45:36 --> Router Class Initialized
INFO - 2023-08-23 16:45:36 --> Output Class Initialized
INFO - 2023-08-23 16:45:36 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:36 --> Input Class Initialized
INFO - 2023-08-23 16:45:36 --> Language Class Initialized
ERROR - 2023-08-23 16:45:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:36 --> Config Class Initialized
INFO - 2023-08-23 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:36 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:36 --> URI Class Initialized
INFO - 2023-08-23 16:45:36 --> Router Class Initialized
INFO - 2023-08-23 16:45:36 --> Output Class Initialized
INFO - 2023-08-23 16:45:36 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:36 --> Input Class Initialized
INFO - 2023-08-23 16:45:36 --> Language Class Initialized
ERROR - 2023-08-23 16:45:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:36 --> Config Class Initialized
INFO - 2023-08-23 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:36 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:36 --> URI Class Initialized
INFO - 2023-08-23 16:45:36 --> Router Class Initialized
INFO - 2023-08-23 16:45:36 --> Output Class Initialized
INFO - 2023-08-23 16:45:36 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:36 --> Input Class Initialized
INFO - 2023-08-23 16:45:36 --> Language Class Initialized
ERROR - 2023-08-23 16:45:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:37 --> Config Class Initialized
INFO - 2023-08-23 16:45:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:37 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:37 --> URI Class Initialized
INFO - 2023-08-23 16:45:37 --> Router Class Initialized
INFO - 2023-08-23 16:45:37 --> Output Class Initialized
INFO - 2023-08-23 16:45:37 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:37 --> Input Class Initialized
INFO - 2023-08-23 16:45:37 --> Language Class Initialized
ERROR - 2023-08-23 16:45:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:45:37 --> Config Class Initialized
INFO - 2023-08-23 16:45:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:45:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:45:37 --> Utf8 Class Initialized
INFO - 2023-08-23 16:45:37 --> URI Class Initialized
INFO - 2023-08-23 16:45:37 --> Router Class Initialized
INFO - 2023-08-23 16:45:37 --> Output Class Initialized
INFO - 2023-08-23 16:45:37 --> Security Class Initialized
DEBUG - 2023-08-23 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:45:37 --> Input Class Initialized
INFO - 2023-08-23 16:45:37 --> Language Class Initialized
ERROR - 2023-08-23 16:45:37 --> 404 Page Not Found: Assets/images
INFO - 2023-08-23 16:46:59 --> Config Class Initialized
INFO - 2023-08-23 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:46:59 --> Utf8 Class Initialized
INFO - 2023-08-23 16:46:59 --> URI Class Initialized
INFO - 2023-08-23 16:46:59 --> Router Class Initialized
INFO - 2023-08-23 16:46:59 --> Output Class Initialized
INFO - 2023-08-23 16:46:59 --> Security Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:46:59 --> Input Class Initialized
INFO - 2023-08-23 16:46:59 --> Language Class Initialized
INFO - 2023-08-23 16:46:59 --> Loader Class Initialized
INFO - 2023-08-23 16:46:59 --> Helper loaded: url_helper
INFO - 2023-08-23 16:46:59 --> Helper loaded: file_helper
INFO - 2023-08-23 16:46:59 --> Database Driver Class Initialized
INFO - 2023-08-23 16:46:59 --> Email Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:46:59 --> Controller Class Initialized
INFO - 2023-08-23 16:46:59 --> Model "Home_model" initialized
INFO - 2023-08-23 16:46:59 --> Helper loaded: form_helper
INFO - 2023-08-23 16:46:59 --> Form Validation Class Initialized
INFO - 2023-08-23 16:46:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 16:46:59 --> Final output sent to browser
DEBUG - 2023-08-23 16:46:59 --> Total execution time: 0.3188
INFO - 2023-08-23 16:46:59 --> Config Class Initialized
INFO - 2023-08-23 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:46:59 --> Utf8 Class Initialized
INFO - 2023-08-23 16:46:59 --> URI Class Initialized
INFO - 2023-08-23 16:46:59 --> Router Class Initialized
INFO - 2023-08-23 16:46:59 --> Output Class Initialized
INFO - 2023-08-23 16:46:59 --> Security Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:46:59 --> Input Class Initialized
INFO - 2023-08-23 16:46:59 --> Language Class Initialized
ERROR - 2023-08-23 16:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:46:59 --> Config Class Initialized
INFO - 2023-08-23 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:46:59 --> Utf8 Class Initialized
INFO - 2023-08-23 16:46:59 --> URI Class Initialized
INFO - 2023-08-23 16:46:59 --> Router Class Initialized
INFO - 2023-08-23 16:46:59 --> Output Class Initialized
INFO - 2023-08-23 16:46:59 --> Security Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:46:59 --> Input Class Initialized
INFO - 2023-08-23 16:46:59 --> Language Class Initialized
ERROR - 2023-08-23 16:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:46:59 --> Config Class Initialized
INFO - 2023-08-23 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:46:59 --> Utf8 Class Initialized
INFO - 2023-08-23 16:46:59 --> URI Class Initialized
INFO - 2023-08-23 16:46:59 --> Router Class Initialized
INFO - 2023-08-23 16:46:59 --> Output Class Initialized
INFO - 2023-08-23 16:46:59 --> Security Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:46:59 --> Input Class Initialized
INFO - 2023-08-23 16:46:59 --> Language Class Initialized
ERROR - 2023-08-23 16:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:46:59 --> Config Class Initialized
INFO - 2023-08-23 16:46:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:46:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:46:59 --> Utf8 Class Initialized
INFO - 2023-08-23 16:46:59 --> URI Class Initialized
INFO - 2023-08-23 16:46:59 --> Router Class Initialized
INFO - 2023-08-23 16:46:59 --> Output Class Initialized
INFO - 2023-08-23 16:46:59 --> Security Class Initialized
DEBUG - 2023-08-23 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:46:59 --> Input Class Initialized
INFO - 2023-08-23 16:46:59 --> Language Class Initialized
ERROR - 2023-08-23 16:46:59 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:00 --> Config Class Initialized
INFO - 2023-08-23 16:47:00 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:00 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:00 --> URI Class Initialized
INFO - 2023-08-23 16:47:00 --> Router Class Initialized
INFO - 2023-08-23 16:47:00 --> Output Class Initialized
INFO - 2023-08-23 16:47:00 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:00 --> Input Class Initialized
INFO - 2023-08-23 16:47:00 --> Language Class Initialized
ERROR - 2023-08-23 16:47:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:00 --> Config Class Initialized
INFO - 2023-08-23 16:47:00 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:00 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:00 --> URI Class Initialized
INFO - 2023-08-23 16:47:00 --> Router Class Initialized
INFO - 2023-08-23 16:47:00 --> Output Class Initialized
INFO - 2023-08-23 16:47:00 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:00 --> Input Class Initialized
INFO - 2023-08-23 16:47:00 --> Language Class Initialized
ERROR - 2023-08-23 16:47:00 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:01 --> Config Class Initialized
INFO - 2023-08-23 16:47:01 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:01 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:01 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:01 --> URI Class Initialized
INFO - 2023-08-23 16:47:01 --> Router Class Initialized
INFO - 2023-08-23 16:47:01 --> Output Class Initialized
INFO - 2023-08-23 16:47:01 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:01 --> Input Class Initialized
INFO - 2023-08-23 16:47:01 --> Language Class Initialized
ERROR - 2023-08-23 16:47:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:01 --> Config Class Initialized
INFO - 2023-08-23 16:47:01 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:01 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:01 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:01 --> URI Class Initialized
INFO - 2023-08-23 16:47:01 --> Router Class Initialized
INFO - 2023-08-23 16:47:01 --> Output Class Initialized
INFO - 2023-08-23 16:47:01 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:01 --> Input Class Initialized
INFO - 2023-08-23 16:47:01 --> Language Class Initialized
ERROR - 2023-08-23 16:47:01 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:03 --> Config Class Initialized
INFO - 2023-08-23 16:47:03 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:03 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:03 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:03 --> URI Class Initialized
INFO - 2023-08-23 16:47:03 --> Router Class Initialized
INFO - 2023-08-23 16:47:03 --> Output Class Initialized
INFO - 2023-08-23 16:47:03 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:03 --> Input Class Initialized
INFO - 2023-08-23 16:47:03 --> Language Class Initialized
INFO - 2023-08-23 16:47:03 --> Loader Class Initialized
INFO - 2023-08-23 16:47:03 --> Helper loaded: url_helper
INFO - 2023-08-23 16:47:03 --> Helper loaded: file_helper
INFO - 2023-08-23 16:47:03 --> Database Driver Class Initialized
INFO - 2023-08-23 16:47:03 --> Email Class Initialized
DEBUG - 2023-08-23 16:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:47:03 --> Controller Class Initialized
INFO - 2023-08-23 16:47:03 --> Model "Home_model" initialized
INFO - 2023-08-23 16:47:03 --> Helper loaded: form_helper
INFO - 2023-08-23 16:47:03 --> Form Validation Class Initialized
INFO - 2023-08-23 16:47:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 16:47:03 --> Final output sent to browser
DEBUG - 2023-08-23 16:47:03 --> Total execution time: 0.0494
INFO - 2023-08-23 16:47:04 --> Config Class Initialized
INFO - 2023-08-23 16:47:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:04 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:04 --> URI Class Initialized
INFO - 2023-08-23 16:47:04 --> Router Class Initialized
INFO - 2023-08-23 16:47:04 --> Output Class Initialized
INFO - 2023-08-23 16:47:04 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:04 --> Input Class Initialized
INFO - 2023-08-23 16:47:04 --> Language Class Initialized
ERROR - 2023-08-23 16:47:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:04 --> Config Class Initialized
INFO - 2023-08-23 16:47:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:04 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:04 --> URI Class Initialized
INFO - 2023-08-23 16:47:04 --> Router Class Initialized
INFO - 2023-08-23 16:47:04 --> Output Class Initialized
INFO - 2023-08-23 16:47:04 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:04 --> Input Class Initialized
INFO - 2023-08-23 16:47:04 --> Language Class Initialized
ERROR - 2023-08-23 16:47:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:04 --> Config Class Initialized
INFO - 2023-08-23 16:47:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:04 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:04 --> URI Class Initialized
INFO - 2023-08-23 16:47:04 --> Router Class Initialized
INFO - 2023-08-23 16:47:04 --> Output Class Initialized
INFO - 2023-08-23 16:47:04 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:04 --> Input Class Initialized
INFO - 2023-08-23 16:47:04 --> Language Class Initialized
ERROR - 2023-08-23 16:47:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:04 --> Config Class Initialized
INFO - 2023-08-23 16:47:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:04 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:04 --> URI Class Initialized
INFO - 2023-08-23 16:47:04 --> Router Class Initialized
INFO - 2023-08-23 16:47:04 --> Output Class Initialized
INFO - 2023-08-23 16:47:04 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:04 --> Input Class Initialized
INFO - 2023-08-23 16:47:04 --> Language Class Initialized
ERROR - 2023-08-23 16:47:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:47:04 --> Config Class Initialized
INFO - 2023-08-23 16:47:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:47:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:47:04 --> Utf8 Class Initialized
INFO - 2023-08-23 16:47:04 --> URI Class Initialized
INFO - 2023-08-23 16:47:04 --> Router Class Initialized
INFO - 2023-08-23 16:47:04 --> Output Class Initialized
INFO - 2023-08-23 16:47:04 --> Security Class Initialized
DEBUG - 2023-08-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:47:04 --> Input Class Initialized
INFO - 2023-08-23 16:47:04 --> Language Class Initialized
ERROR - 2023-08-23 16:47:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:54:21 --> Config Class Initialized
INFO - 2023-08-23 16:54:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:54:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:54:21 --> Utf8 Class Initialized
INFO - 2023-08-23 16:54:21 --> URI Class Initialized
INFO - 2023-08-23 16:54:22 --> Router Class Initialized
INFO - 2023-08-23 16:54:22 --> Output Class Initialized
INFO - 2023-08-23 16:54:22 --> Security Class Initialized
DEBUG - 2023-08-23 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:54:22 --> Input Class Initialized
INFO - 2023-08-23 16:54:22 --> Language Class Initialized
INFO - 2023-08-23 16:54:22 --> Loader Class Initialized
INFO - 2023-08-23 16:54:22 --> Helper loaded: url_helper
INFO - 2023-08-23 16:54:22 --> Helper loaded: file_helper
INFO - 2023-08-23 16:54:22 --> Database Driver Class Initialized
INFO - 2023-08-23 16:54:22 --> Email Class Initialized
DEBUG - 2023-08-23 16:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:54:23 --> Controller Class Initialized
INFO - 2023-08-23 16:54:23 --> Model "Home_model" initialized
INFO - 2023-08-23 16:54:23 --> Helper loaded: form_helper
INFO - 2023-08-23 16:54:23 --> Form Validation Class Initialized
INFO - 2023-08-23 16:54:48 --> Config Class Initialized
INFO - 2023-08-23 16:54:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:54:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:54:48 --> Utf8 Class Initialized
INFO - 2023-08-23 16:54:48 --> URI Class Initialized
INFO - 2023-08-23 16:54:48 --> Router Class Initialized
INFO - 2023-08-23 16:54:48 --> Output Class Initialized
INFO - 2023-08-23 16:54:48 --> Security Class Initialized
DEBUG - 2023-08-23 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:54:48 --> Input Class Initialized
INFO - 2023-08-23 16:54:48 --> Language Class Initialized
INFO - 2023-08-23 16:54:48 --> Loader Class Initialized
INFO - 2023-08-23 16:54:48 --> Helper loaded: url_helper
INFO - 2023-08-23 16:54:48 --> Helper loaded: file_helper
INFO - 2023-08-23 16:54:48 --> Database Driver Class Initialized
INFO - 2023-08-23 16:54:48 --> Email Class Initialized
DEBUG - 2023-08-23 16:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:54:48 --> Controller Class Initialized
INFO - 2023-08-23 16:54:48 --> Model "Home_model" initialized
INFO - 2023-08-23 16:54:48 --> Helper loaded: form_helper
INFO - 2023-08-23 16:54:48 --> Form Validation Class Initialized
INFO - 2023-08-23 16:55:30 --> Config Class Initialized
INFO - 2023-08-23 16:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:30 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:31 --> URI Class Initialized
INFO - 2023-08-23 16:55:31 --> Router Class Initialized
INFO - 2023-08-23 16:55:31 --> Output Class Initialized
INFO - 2023-08-23 16:55:31 --> Security Class Initialized
DEBUG - 2023-08-23 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:31 --> Input Class Initialized
INFO - 2023-08-23 16:55:31 --> Language Class Initialized
INFO - 2023-08-23 16:55:31 --> Loader Class Initialized
INFO - 2023-08-23 16:55:31 --> Helper loaded: url_helper
INFO - 2023-08-23 16:55:31 --> Helper loaded: file_helper
INFO - 2023-08-23 16:55:31 --> Database Driver Class Initialized
INFO - 2023-08-23 16:55:31 --> Email Class Initialized
DEBUG - 2023-08-23 16:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:55:31 --> Controller Class Initialized
INFO - 2023-08-23 16:55:31 --> Model "Home_model" initialized
INFO - 2023-08-23 16:55:31 --> Helper loaded: form_helper
INFO - 2023-08-23 16:55:31 --> Form Validation Class Initialized
INFO - 2023-08-23 16:55:38 --> Config Class Initialized
INFO - 2023-08-23 16:55:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:38 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:38 --> URI Class Initialized
INFO - 2023-08-23 16:55:38 --> Router Class Initialized
INFO - 2023-08-23 16:55:38 --> Output Class Initialized
INFO - 2023-08-23 16:55:38 --> Security Class Initialized
DEBUG - 2023-08-23 16:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:38 --> Input Class Initialized
INFO - 2023-08-23 16:55:38 --> Language Class Initialized
INFO - 2023-08-23 16:55:38 --> Loader Class Initialized
INFO - 2023-08-23 16:55:38 --> Helper loaded: url_helper
INFO - 2023-08-23 16:55:38 --> Helper loaded: file_helper
INFO - 2023-08-23 16:55:38 --> Database Driver Class Initialized
INFO - 2023-08-23 16:55:38 --> Email Class Initialized
DEBUG - 2023-08-23 16:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:55:38 --> Controller Class Initialized
INFO - 2023-08-23 16:55:38 --> Model "Home_model" initialized
INFO - 2023-08-23 16:55:38 --> Helper loaded: form_helper
INFO - 2023-08-23 16:55:38 --> Form Validation Class Initialized
INFO - 2023-08-23 16:55:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 16:55:38 --> Final output sent to browser
DEBUG - 2023-08-23 16:55:39 --> Total execution time: 0.7132
INFO - 2023-08-23 16:55:39 --> Config Class Initialized
INFO - 2023-08-23 16:55:39 --> Config Class Initialized
INFO - 2023-08-23 16:55:39 --> Hooks Class Initialized
INFO - 2023-08-23 16:55:39 --> Config Class Initialized
DEBUG - 2023-08-23 16:55:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:39 --> Hooks Class Initialized
INFO - 2023-08-23 16:55:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:39 --> Utf8 Class Initialized
DEBUG - 2023-08-23 16:55:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:39 --> URI Class Initialized
INFO - 2023-08-23 16:55:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:39 --> URI Class Initialized
INFO - 2023-08-23 16:55:39 --> URI Class Initialized
INFO - 2023-08-23 16:55:39 --> Router Class Initialized
INFO - 2023-08-23 16:55:39 --> Router Class Initialized
INFO - 2023-08-23 16:55:40 --> Output Class Initialized
INFO - 2023-08-23 16:55:40 --> Output Class Initialized
INFO - 2023-08-23 16:55:40 --> Security Class Initialized
INFO - 2023-08-23 16:55:40 --> Router Class Initialized
DEBUG - 2023-08-23 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:40 --> Security Class Initialized
DEBUG - 2023-08-23 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:40 --> Input Class Initialized
INFO - 2023-08-23 16:55:40 --> Input Class Initialized
INFO - 2023-08-23 16:55:40 --> Output Class Initialized
INFO - 2023-08-23 16:55:40 --> Security Class Initialized
DEBUG - 2023-08-23 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:40 --> Language Class Initialized
INFO - 2023-08-23 16:55:40 --> Language Class Initialized
INFO - 2023-08-23 16:55:40 --> Input Class Initialized
ERROR - 2023-08-23 16:55:40 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 16:55:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:55:40 --> Language Class Initialized
ERROR - 2023-08-23 16:55:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:55:40 --> Config Class Initialized
INFO - 2023-08-23 16:55:40 --> Config Class Initialized
INFO - 2023-08-23 16:55:40 --> Config Class Initialized
INFO - 2023-08-23 16:55:40 --> Hooks Class Initialized
INFO - 2023-08-23 16:55:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 16:55:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:41 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:41 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:41 --> URI Class Initialized
INFO - 2023-08-23 16:55:41 --> Router Class Initialized
INFO - 2023-08-23 16:55:41 --> URI Class Initialized
INFO - 2023-08-23 16:55:41 --> Router Class Initialized
INFO - 2023-08-23 16:55:41 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:41 --> Output Class Initialized
INFO - 2023-08-23 16:55:41 --> Security Class Initialized
INFO - 2023-08-23 16:55:41 --> Output Class Initialized
DEBUG - 2023-08-23 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:41 --> Input Class Initialized
INFO - 2023-08-23 16:55:41 --> URI Class Initialized
INFO - 2023-08-23 16:55:41 --> Security Class Initialized
INFO - 2023-08-23 16:55:41 --> Router Class Initialized
INFO - 2023-08-23 16:55:41 --> Language Class Initialized
INFO - 2023-08-23 16:55:41 --> Output Class Initialized
DEBUG - 2023-08-23 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:41 --> Security Class Initialized
INFO - 2023-08-23 16:55:41 --> Input Class Initialized
INFO - 2023-08-23 16:55:41 --> Language Class Initialized
DEBUG - 2023-08-23 16:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 16:55:41 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 16:55:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:55:41 --> Input Class Initialized
INFO - 2023-08-23 16:55:41 --> Language Class Initialized
ERROR - 2023-08-23 16:55:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:55:41 --> Config Class Initialized
INFO - 2023-08-23 16:55:41 --> Config Class Initialized
INFO - 2023-08-23 16:55:41 --> Hooks Class Initialized
INFO - 2023-08-23 16:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:41 --> Utf8 Class Initialized
DEBUG - 2023-08-23 16:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:55:41 --> URI Class Initialized
INFO - 2023-08-23 16:55:41 --> Utf8 Class Initialized
INFO - 2023-08-23 16:55:41 --> Router Class Initialized
INFO - 2023-08-23 16:55:41 --> Output Class Initialized
INFO - 2023-08-23 16:55:41 --> URI Class Initialized
INFO - 2023-08-23 16:55:41 --> Security Class Initialized
INFO - 2023-08-23 16:55:41 --> Router Class Initialized
DEBUG - 2023-08-23 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:41 --> Input Class Initialized
INFO - 2023-08-23 16:55:41 --> Output Class Initialized
INFO - 2023-08-23 16:55:41 --> Language Class Initialized
INFO - 2023-08-23 16:55:41 --> Security Class Initialized
ERROR - 2023-08-23 16:55:41 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:55:41 --> Input Class Initialized
INFO - 2023-08-23 16:55:41 --> Language Class Initialized
ERROR - 2023-08-23 16:55:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:57:36 --> Config Class Initialized
INFO - 2023-08-23 16:57:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:57:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:57:36 --> Utf8 Class Initialized
INFO - 2023-08-23 16:57:37 --> URI Class Initialized
INFO - 2023-08-23 16:57:37 --> Router Class Initialized
INFO - 2023-08-23 16:57:37 --> Output Class Initialized
INFO - 2023-08-23 16:57:37 --> Security Class Initialized
DEBUG - 2023-08-23 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:57:37 --> Input Class Initialized
INFO - 2023-08-23 16:57:37 --> Language Class Initialized
INFO - 2023-08-23 16:57:37 --> Loader Class Initialized
INFO - 2023-08-23 16:57:37 --> Helper loaded: url_helper
INFO - 2023-08-23 16:57:37 --> Helper loaded: file_helper
INFO - 2023-08-23 16:57:37 --> Database Driver Class Initialized
INFO - 2023-08-23 16:57:37 --> Email Class Initialized
DEBUG - 2023-08-23 16:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 16:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 16:57:37 --> Controller Class Initialized
INFO - 2023-08-23 16:57:37 --> Model "Home_model" initialized
INFO - 2023-08-23 16:57:37 --> Helper loaded: form_helper
INFO - 2023-08-23 16:57:37 --> Form Validation Class Initialized
INFO - 2023-08-23 16:57:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 16:57:37 --> Final output sent to browser
DEBUG - 2023-08-23 16:57:38 --> Total execution time: 0.7373
INFO - 2023-08-23 16:57:38 --> Config Class Initialized
INFO - 2023-08-23 16:57:38 --> Config Class Initialized
INFO - 2023-08-23 16:57:38 --> Config Class Initialized
INFO - 2023-08-23 16:57:38 --> Hooks Class Initialized
INFO - 2023-08-23 16:57:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:57:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:57:38 --> Hooks Class Initialized
INFO - 2023-08-23 16:57:39 --> Utf8 Class Initialized
DEBUG - 2023-08-23 16:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 16:57:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:57:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:57:39 --> URI Class Initialized
INFO - 2023-08-23 16:57:39 --> URI Class Initialized
INFO - 2023-08-23 16:57:39 --> Router Class Initialized
INFO - 2023-08-23 16:57:39 --> Output Class Initialized
INFO - 2023-08-23 16:57:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:57:39 --> Router Class Initialized
INFO - 2023-08-23 16:57:39 --> Output Class Initialized
INFO - 2023-08-23 16:57:39 --> Security Class Initialized
DEBUG - 2023-08-23 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:57:39 --> Security Class Initialized
DEBUG - 2023-08-23 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:57:39 --> Input Class Initialized
INFO - 2023-08-23 16:57:39 --> URI Class Initialized
INFO - 2023-08-23 16:57:39 --> Language Class Initialized
INFO - 2023-08-23 16:57:39 --> Input Class Initialized
INFO - 2023-08-23 16:57:39 --> Language Class Initialized
INFO - 2023-08-23 16:57:39 --> Router Class Initialized
ERROR - 2023-08-23 16:57:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:57:39 --> Output Class Initialized
ERROR - 2023-08-23 16:57:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:57:39 --> Security Class Initialized
DEBUG - 2023-08-23 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:57:39 --> Input Class Initialized
INFO - 2023-08-23 16:57:39 --> Language Class Initialized
ERROR - 2023-08-23 16:57:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:57:39 --> Config Class Initialized
INFO - 2023-08-23 16:57:39 --> Config Class Initialized
INFO - 2023-08-23 16:57:39 --> Hooks Class Initialized
INFO - 2023-08-23 16:57:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 16:57:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:57:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:57:39 --> Utf8 Class Initialized
INFO - 2023-08-23 16:57:39 --> URI Class Initialized
INFO - 2023-08-23 16:57:39 --> URI Class Initialized
INFO - 2023-08-23 16:57:39 --> Router Class Initialized
INFO - 2023-08-23 16:57:39 --> Router Class Initialized
INFO - 2023-08-23 16:57:39 --> Output Class Initialized
INFO - 2023-08-23 16:57:39 --> Security Class Initialized
INFO - 2023-08-23 16:57:39 --> Output Class Initialized
DEBUG - 2023-08-23 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:57:39 --> Security Class Initialized
INFO - 2023-08-23 16:57:39 --> Input Class Initialized
INFO - 2023-08-23 16:57:39 --> Language Class Initialized
DEBUG - 2023-08-23 16:57:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 16:57:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:57:39 --> Input Class Initialized
INFO - 2023-08-23 16:57:39 --> Language Class Initialized
ERROR - 2023-08-23 16:57:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 16:59:51 --> Config Class Initialized
INFO - 2023-08-23 16:59:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:59:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:51 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:51 --> URI Class Initialized
INFO - 2023-08-23 16:59:51 --> Router Class Initialized
INFO - 2023-08-23 16:59:51 --> Output Class Initialized
INFO - 2023-08-23 16:59:51 --> Security Class Initialized
DEBUG - 2023-08-23 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:51 --> Input Class Initialized
INFO - 2023-08-23 16:59:51 --> Language Class Initialized
ERROR - 2023-08-23 16:59:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 16:59:51 --> Config Class Initialized
INFO - 2023-08-23 16:59:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:59:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:51 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:51 --> URI Class Initialized
INFO - 2023-08-23 16:59:51 --> Router Class Initialized
INFO - 2023-08-23 16:59:51 --> Output Class Initialized
INFO - 2023-08-23 16:59:51 --> Security Class Initialized
DEBUG - 2023-08-23 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:51 --> Input Class Initialized
INFO - 2023-08-23 16:59:51 --> Language Class Initialized
ERROR - 2023-08-23 16:59:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 16:59:52 --> Config Class Initialized
INFO - 2023-08-23 16:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:52 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:52 --> URI Class Initialized
INFO - 2023-08-23 16:59:52 --> Router Class Initialized
INFO - 2023-08-23 16:59:52 --> Output Class Initialized
INFO - 2023-08-23 16:59:52 --> Security Class Initialized
DEBUG - 2023-08-23 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:52 --> Input Class Initialized
INFO - 2023-08-23 16:59:52 --> Language Class Initialized
ERROR - 2023-08-23 16:59:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 16:59:52 --> Config Class Initialized
INFO - 2023-08-23 16:59:52 --> Hooks Class Initialized
INFO - 2023-08-23 16:59:52 --> Config Class Initialized
INFO - 2023-08-23 16:59:52 --> Config Class Initialized
DEBUG - 2023-08-23 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:52 --> Hooks Class Initialized
INFO - 2023-08-23 16:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:52 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:52 --> Utf8 Class Initialized
DEBUG - 2023-08-23 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:52 --> URI Class Initialized
INFO - 2023-08-23 16:59:52 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:52 --> URI Class Initialized
INFO - 2023-08-23 16:59:52 --> Router Class Initialized
INFO - 2023-08-23 16:59:52 --> Router Class Initialized
INFO - 2023-08-23 16:59:52 --> Output Class Initialized
INFO - 2023-08-23 16:59:52 --> Output Class Initialized
INFO - 2023-08-23 16:59:52 --> Security Class Initialized
INFO - 2023-08-23 16:59:52 --> URI Class Initialized
DEBUG - 2023-08-23 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:52 --> Router Class Initialized
INFO - 2023-08-23 16:59:52 --> Security Class Initialized
INFO - 2023-08-23 16:59:52 --> Input Class Initialized
DEBUG - 2023-08-23 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:52 --> Input Class Initialized
INFO - 2023-08-23 16:59:52 --> Output Class Initialized
INFO - 2023-08-23 16:59:52 --> Language Class Initialized
INFO - 2023-08-23 16:59:52 --> Language Class Initialized
INFO - 2023-08-23 16:59:52 --> Security Class Initialized
ERROR - 2023-08-23 16:59:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:52 --> Input Class Initialized
INFO - 2023-08-23 16:59:53 --> Language Class Initialized
ERROR - 2023-08-23 16:59:53 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 16:59:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 16:59:53 --> Config Class Initialized
INFO - 2023-08-23 16:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 16:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 16:59:53 --> Utf8 Class Initialized
INFO - 2023-08-23 16:59:53 --> URI Class Initialized
INFO - 2023-08-23 16:59:53 --> Router Class Initialized
INFO - 2023-08-23 16:59:53 --> Output Class Initialized
INFO - 2023-08-23 16:59:53 --> Security Class Initialized
DEBUG - 2023-08-23 16:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 16:59:54 --> Input Class Initialized
INFO - 2023-08-23 16:59:54 --> Language Class Initialized
ERROR - 2023-08-23 16:59:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:16 --> Config Class Initialized
INFO - 2023-08-23 17:01:16 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:16 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:16 --> URI Class Initialized
INFO - 2023-08-23 17:01:16 --> Router Class Initialized
INFO - 2023-08-23 17:01:16 --> Output Class Initialized
INFO - 2023-08-23 17:01:16 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:16 --> Input Class Initialized
INFO - 2023-08-23 17:01:16 --> Language Class Initialized
INFO - 2023-08-23 17:01:16 --> Loader Class Initialized
INFO - 2023-08-23 17:01:16 --> Helper loaded: url_helper
INFO - 2023-08-23 17:01:17 --> Helper loaded: file_helper
INFO - 2023-08-23 17:01:17 --> Database Driver Class Initialized
INFO - 2023-08-23 17:01:17 --> Email Class Initialized
DEBUG - 2023-08-23 17:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:01:17 --> Controller Class Initialized
INFO - 2023-08-23 17:01:17 --> Model "Home_model" initialized
INFO - 2023-08-23 17:01:17 --> Helper loaded: form_helper
INFO - 2023-08-23 17:01:17 --> Form Validation Class Initialized
INFO - 2023-08-23 17:01:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:01:17 --> Final output sent to browser
DEBUG - 2023-08-23 17:01:17 --> Total execution time: 0.6211
INFO - 2023-08-23 17:01:18 --> Config Class Initialized
INFO - 2023-08-23 17:01:18 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:19 --> Config Class Initialized
DEBUG - 2023-08-23 17:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:20 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:20 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:20 --> URI Class Initialized
INFO - 2023-08-23 17:01:20 --> Router Class Initialized
INFO - 2023-08-23 17:01:20 --> URI Class Initialized
INFO - 2023-08-23 17:01:20 --> Output Class Initialized
INFO - 2023-08-23 17:01:20 --> Security Class Initialized
INFO - 2023-08-23 17:01:20 --> Router Class Initialized
DEBUG - 2023-08-23 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:20 --> Output Class Initialized
INFO - 2023-08-23 17:01:20 --> Input Class Initialized
INFO - 2023-08-23 17:01:20 --> Security Class Initialized
INFO - 2023-08-23 17:01:20 --> Language Class Initialized
DEBUG - 2023-08-23 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:20 --> Input Class Initialized
ERROR - 2023-08-23 17:01:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:01:20 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
INFO - 2023-08-23 17:01:21 --> Config Class Initialized
INFO - 2023-08-23 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 17:01:21 --> URI Class Initialized
INFO - 2023-08-23 17:01:21 --> Router Class Initialized
INFO - 2023-08-23 17:01:21 --> Output Class Initialized
INFO - 2023-08-23 17:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:01:21 --> Input Class Initialized
INFO - 2023-08-23 17:01:21 --> Language Class Initialized
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 17:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:09 --> URI Class Initialized
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:09 --> Router Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
DEBUG - 2023-08-23 17:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:09 --> URI Class Initialized
INFO - 2023-08-23 17:20:09 --> Router Class Initialized
INFO - 2023-08-23 17:20:09 --> Output Class Initialized
INFO - 2023-08-23 17:20:09 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:09 --> Input Class Initialized
INFO - 2023-08-23 17:20:09 --> Language Class Initialized
ERROR - 2023-08-23 17:20:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:09 --> Config Class Initialized
INFO - 2023-08-23 17:20:09 --> Output Class Initialized
INFO - 2023-08-23 17:20:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:09 --> Security Class Initialized
INFO - 2023-08-23 17:20:09 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:09 --> URI Class Initialized
INFO - 2023-08-23 17:20:09 --> URI Class Initialized
INFO - 2023-08-23 17:20:10 --> Router Class Initialized
INFO - 2023-08-23 17:20:10 --> Output Class Initialized
INFO - 2023-08-23 17:20:10 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 17:20:10 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:10 --> URI Class Initialized
DEBUG - 2023-08-23 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Router Class Initialized
INFO - 2023-08-23 17:20:10 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:10 --> Router Class Initialized
INFO - 2023-08-23 17:20:10 --> URI Class Initialized
INFO - 2023-08-23 17:20:10 --> Output Class Initialized
INFO - 2023-08-23 17:20:10 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:10 --> Output Class Initialized
INFO - 2023-08-23 17:20:10 --> Router Class Initialized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
INFO - 2023-08-23 17:20:10 --> Security Class Initialized
INFO - 2023-08-23 17:20:10 --> URI Class Initialized
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
INFO - 2023-08-23 17:20:10 --> Router Class Initialized
INFO - 2023-08-23 17:20:10 --> Output Class Initialized
INFO - 2023-08-23 17:20:10 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Output Class Initialized
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:10 --> Security Class Initialized
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:10 --> Input Class Initialized
INFO - 2023-08-23 17:20:10 --> Language Class Initialized
ERROR - 2023-08-23 17:20:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:14 --> Config Class Initialized
INFO - 2023-08-23 17:20:14 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:14 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:14 --> URI Class Initialized
INFO - 2023-08-23 17:20:14 --> Router Class Initialized
INFO - 2023-08-23 17:20:14 --> Output Class Initialized
INFO - 2023-08-23 17:20:14 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:14 --> Input Class Initialized
INFO - 2023-08-23 17:20:14 --> Language Class Initialized
INFO - 2023-08-23 17:20:14 --> Loader Class Initialized
INFO - 2023-08-23 17:20:14 --> Helper loaded: url_helper
INFO - 2023-08-23 17:20:14 --> Helper loaded: file_helper
INFO - 2023-08-23 17:20:14 --> Database Driver Class Initialized
INFO - 2023-08-23 17:20:14 --> Email Class Initialized
DEBUG - 2023-08-23 17:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:20:14 --> Controller Class Initialized
INFO - 2023-08-23 17:20:14 --> Model "Home_model" initialized
INFO - 2023-08-23 17:20:14 --> Helper loaded: form_helper
INFO - 2023-08-23 17:20:14 --> Form Validation Class Initialized
INFO - 2023-08-23 17:20:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:20:14 --> Final output sent to browser
DEBUG - 2023-08-23 17:20:15 --> Total execution time: 0.5111
INFO - 2023-08-23 17:20:15 --> Config Class Initialized
INFO - 2023-08-23 17:20:15 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:15 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:15 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:15 --> URI Class Initialized
INFO - 2023-08-23 17:20:15 --> Router Class Initialized
INFO - 2023-08-23 17:20:15 --> Output Class Initialized
INFO - 2023-08-23 17:20:15 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:15 --> Input Class Initialized
INFO - 2023-08-23 17:20:15 --> Language Class Initialized
ERROR - 2023-08-23 17:20:15 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:20:15 --> Config Class Initialized
INFO - 2023-08-23 17:20:15 --> Config Class Initialized
INFO - 2023-08-23 17:20:15 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:15 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:15 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:15 --> URI Class Initialized
INFO - 2023-08-23 17:20:15 --> Router Class Initialized
INFO - 2023-08-23 17:20:15 --> Output Class Initialized
INFO - 2023-08-23 17:20:15 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:15 --> Input Class Initialized
INFO - 2023-08-23 17:20:15 --> Language Class Initialized
ERROR - 2023-08-23 17:20:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:16 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:16 --> Config Class Initialized
DEBUG - 2023-08-23 17:20:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:16 --> Config Class Initialized
INFO - 2023-08-23 17:20:16 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:16 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:16 --> URI Class Initialized
INFO - 2023-08-23 17:20:16 --> Router Class Initialized
INFO - 2023-08-23 17:20:16 --> Output Class Initialized
INFO - 2023-08-23 17:20:16 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:16 --> Input Class Initialized
INFO - 2023-08-23 17:20:16 --> Language Class Initialized
ERROR - 2023-08-23 17:20:16 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:20:16 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:16 --> Config Class Initialized
INFO - 2023-08-23 17:20:16 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:16 --> Config Class Initialized
DEBUG - 2023-08-23 17:20:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:16 --> URI Class Initialized
INFO - 2023-08-23 17:20:16 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:16 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:16 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:16 --> Config Class Initialized
INFO - 2023-08-23 17:20:17 --> Config Class Initialized
INFO - 2023-08-23 17:20:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:20:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:17 --> Config Class Initialized
INFO - 2023-08-23 17:20:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Config Class Initialized
INFO - 2023-08-23 17:20:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Config Class Initialized
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
DEBUG - 2023-08-23 17:20:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
INFO - 2023-08-23 17:20:17 --> Utf8 Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> URI Class Initialized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
INFO - 2023-08-23 17:20:17 --> Router Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
INFO - 2023-08-23 17:20:17 --> Output Class Initialized
INFO - 2023-08-23 17:20:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
DEBUG - 2023-08-23 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Input Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
INFO - 2023-08-23 17:20:17 --> Language Class Initialized
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 17:20:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:22:13 --> Config Class Initialized
INFO - 2023-08-23 17:22:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:13 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:13 --> URI Class Initialized
INFO - 2023-08-23 17:22:13 --> Router Class Initialized
INFO - 2023-08-23 17:22:13 --> Output Class Initialized
INFO - 2023-08-23 17:22:13 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:13 --> Input Class Initialized
INFO - 2023-08-23 17:22:13 --> Language Class Initialized
INFO - 2023-08-23 17:22:13 --> Loader Class Initialized
INFO - 2023-08-23 17:22:14 --> Helper loaded: url_helper
INFO - 2023-08-23 17:22:14 --> Helper loaded: file_helper
INFO - 2023-08-23 17:22:14 --> Database Driver Class Initialized
INFO - 2023-08-23 17:22:14 --> Email Class Initialized
DEBUG - 2023-08-23 17:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:22:14 --> Controller Class Initialized
INFO - 2023-08-23 17:22:14 --> Model "Home_model" initialized
INFO - 2023-08-23 17:22:14 --> Helper loaded: form_helper
INFO - 2023-08-23 17:22:14 --> Form Validation Class Initialized
INFO - 2023-08-23 17:22:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:22:14 --> Final output sent to browser
DEBUG - 2023-08-23 17:22:14 --> Total execution time: 0.5499
INFO - 2023-08-23 17:22:16 --> Config Class Initialized
INFO - 2023-08-23 17:22:16 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:16 --> Config Class Initialized
INFO - 2023-08-23 17:22:16 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:16 --> URI Class Initialized
INFO - 2023-08-23 17:22:16 --> Router Class Initialized
INFO - 2023-08-23 17:22:16 --> Hooks Class Initialized
INFO - 2023-08-23 17:22:16 --> Config Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:22:17 --> Config Class Initialized
INFO - 2023-08-23 17:22:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:17 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:17 --> URI Class Initialized
INFO - 2023-08-23 17:22:17 --> Router Class Initialized
INFO - 2023-08-23 17:22:17 --> Output Class Initialized
INFO - 2023-08-23 17:22:17 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:17 --> Input Class Initialized
INFO - 2023-08-23 17:22:17 --> Language Class Initialized
ERROR - 2023-08-23 17:22:17 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:22:18 --> Config Class Initialized
INFO - 2023-08-23 17:22:18 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:18 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:18 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:18 --> URI Class Initialized
INFO - 2023-08-23 17:22:18 --> Router Class Initialized
INFO - 2023-08-23 17:22:18 --> Output Class Initialized
INFO - 2023-08-23 17:22:18 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:18 --> Input Class Initialized
INFO - 2023-08-23 17:22:18 --> Language Class Initialized
ERROR - 2023-08-23 17:22:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:22:34 --> Config Class Initialized
INFO - 2023-08-23 17:22:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:22:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:22:34 --> Utf8 Class Initialized
INFO - 2023-08-23 17:22:34 --> URI Class Initialized
INFO - 2023-08-23 17:22:34 --> Router Class Initialized
INFO - 2023-08-23 17:22:34 --> Output Class Initialized
INFO - 2023-08-23 17:22:34 --> Security Class Initialized
DEBUG - 2023-08-23 17:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:22:34 --> Input Class Initialized
INFO - 2023-08-23 17:22:34 --> Language Class Initialized
INFO - 2023-08-23 17:22:34 --> Loader Class Initialized
INFO - 2023-08-23 17:22:34 --> Helper loaded: url_helper
INFO - 2023-08-23 17:22:34 --> Helper loaded: file_helper
INFO - 2023-08-23 17:22:34 --> Database Driver Class Initialized
INFO - 2023-08-23 17:22:34 --> Email Class Initialized
DEBUG - 2023-08-23 17:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:22:34 --> Controller Class Initialized
INFO - 2023-08-23 17:22:34 --> Model "Home_model" initialized
INFO - 2023-08-23 17:22:34 --> Helper loaded: form_helper
INFO - 2023-08-23 17:22:34 --> Form Validation Class Initialized
INFO - 2023-08-23 17:22:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:22:34 --> Final output sent to browser
DEBUG - 2023-08-23 17:22:35 --> Total execution time: 0.3406
INFO - 2023-08-23 17:31:09 --> Config Class Initialized
INFO - 2023-08-23 17:31:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:31:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:31:09 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:09 --> URI Class Initialized
INFO - 2023-08-23 17:31:09 --> Router Class Initialized
INFO - 2023-08-23 17:31:09 --> Output Class Initialized
INFO - 2023-08-23 17:31:09 --> Security Class Initialized
DEBUG - 2023-08-23 17:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:31:09 --> Input Class Initialized
INFO - 2023-08-23 17:31:09 --> Language Class Initialized
INFO - 2023-08-23 17:31:09 --> Loader Class Initialized
INFO - 2023-08-23 17:31:09 --> Helper loaded: url_helper
INFO - 2023-08-23 17:31:09 --> Helper loaded: file_helper
INFO - 2023-08-23 17:31:09 --> Database Driver Class Initialized
INFO - 2023-08-23 17:31:09 --> Email Class Initialized
DEBUG - 2023-08-23 17:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:31:09 --> Controller Class Initialized
INFO - 2023-08-23 17:31:09 --> Model "Home_model" initialized
INFO - 2023-08-23 17:31:10 --> Helper loaded: form_helper
INFO - 2023-08-23 17:31:10 --> Form Validation Class Initialized
INFO - 2023-08-23 17:31:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:31:10 --> Final output sent to browser
DEBUG - 2023-08-23 17:31:10 --> Total execution time: 0.6812
INFO - 2023-08-23 17:31:11 --> Config Class Initialized
INFO - 2023-08-23 17:31:11 --> Config Class Initialized
INFO - 2023-08-23 17:31:11 --> Config Class Initialized
INFO - 2023-08-23 17:31:11 --> Hooks Class Initialized
INFO - 2023-08-23 17:31:11 --> Hooks Class Initialized
INFO - 2023-08-23 17:31:11 --> Hooks Class Initialized
INFO - 2023-08-23 17:31:11 --> Config Class Initialized
DEBUG - 2023-08-23 17:31:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:31:11 --> Hooks Class Initialized
INFO - 2023-08-23 17:31:11 --> Config Class Initialized
DEBUG - 2023-08-23 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 17:31:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:31:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:11 --> URI Class Initialized
INFO - 2023-08-23 17:31:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:11 --> URI Class Initialized
INFO - 2023-08-23 17:31:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:31:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:31:11 --> URI Class Initialized
INFO - 2023-08-23 17:31:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:11 --> Router Class Initialized
INFO - 2023-08-23 17:31:11 --> Router Class Initialized
DEBUG - 2023-08-23 17:31:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:31:11 --> URI Class Initialized
INFO - 2023-08-23 17:31:11 --> Output Class Initialized
INFO - 2023-08-23 17:31:11 --> Output Class Initialized
INFO - 2023-08-23 17:31:11 --> Router Class Initialized
INFO - 2023-08-23 17:31:11 --> Router Class Initialized
INFO - 2023-08-23 17:31:11 --> Output Class Initialized
INFO - 2023-08-23 17:31:11 --> Security Class Initialized
INFO - 2023-08-23 17:31:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:31:11 --> URI Class Initialized
INFO - 2023-08-23 17:31:11 --> Output Class Initialized
INFO - 2023-08-23 17:31:11 --> Security Class Initialized
INFO - 2023-08-23 17:31:11 --> Security Class Initialized
DEBUG - 2023-08-23 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:31:11 --> Security Class Initialized
DEBUG - 2023-08-23 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:31:11 --> Input Class Initialized
DEBUG - 2023-08-23 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:31:11 --> Router Class Initialized
DEBUG - 2023-08-23 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:31:11 --> Output Class Initialized
INFO - 2023-08-23 17:31:11 --> Input Class Initialized
INFO - 2023-08-23 17:31:11 --> Input Class Initialized
INFO - 2023-08-23 17:31:11 --> Language Class Initialized
INFO - 2023-08-23 17:31:12 --> Input Class Initialized
INFO - 2023-08-23 17:31:12 --> Language Class Initialized
ERROR - 2023-08-23 17:31:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:31:12 --> Language Class Initialized
INFO - 2023-08-23 17:31:12 --> Security Class Initialized
INFO - 2023-08-23 17:31:12 --> Language Class Initialized
ERROR - 2023-08-23 17:31:12 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 17:31:12 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 17:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 17:31:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:31:12 --> Input Class Initialized
INFO - 2023-08-23 17:31:12 --> Language Class Initialized
ERROR - 2023-08-23 17:31:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:33:36 --> Config Class Initialized
INFO - 2023-08-23 17:33:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:33:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:36 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:36 --> URI Class Initialized
INFO - 2023-08-23 17:33:36 --> Router Class Initialized
INFO - 2023-08-23 17:33:36 --> Output Class Initialized
INFO - 2023-08-23 17:33:36 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:36 --> Input Class Initialized
INFO - 2023-08-23 17:33:36 --> Language Class Initialized
INFO - 2023-08-23 17:33:36 --> Loader Class Initialized
INFO - 2023-08-23 17:33:36 --> Helper loaded: url_helper
INFO - 2023-08-23 17:33:37 --> Helper loaded: file_helper
INFO - 2023-08-23 17:33:37 --> Database Driver Class Initialized
INFO - 2023-08-23 17:33:37 --> Email Class Initialized
DEBUG - 2023-08-23 17:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:33:37 --> Controller Class Initialized
INFO - 2023-08-23 17:33:37 --> Model "Home_model" initialized
INFO - 2023-08-23 17:33:37 --> Helper loaded: form_helper
INFO - 2023-08-23 17:33:37 --> Form Validation Class Initialized
INFO - 2023-08-23 17:33:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:33:37 --> Final output sent to browser
DEBUG - 2023-08-23 17:33:37 --> Total execution time: 0.4074
INFO - 2023-08-23 17:33:37 --> Config Class Initialized
INFO - 2023-08-23 17:33:37 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:37 --> Config Class Initialized
DEBUG - 2023-08-23 17:33:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:37 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:38 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:38 --> URI Class Initialized
INFO - 2023-08-23 17:33:38 --> Router Class Initialized
DEBUG - 2023-08-23 17:33:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:38 --> Output Class Initialized
INFO - 2023-08-23 17:33:38 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:38 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:38 --> Input Class Initialized
INFO - 2023-08-23 17:33:38 --> URI Class Initialized
INFO - 2023-08-23 17:33:38 --> Language Class Initialized
INFO - 2023-08-23 17:33:38 --> Router Class Initialized
INFO - 2023-08-23 17:33:38 --> Output Class Initialized
ERROR - 2023-08-23 17:33:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:33:38 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:38 --> Input Class Initialized
INFO - 2023-08-23 17:33:38 --> Language Class Initialized
ERROR - 2023-08-23 17:33:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:33:38 --> Config Class Initialized
INFO - 2023-08-23 17:33:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:33:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:38 --> Config Class Initialized
INFO - 2023-08-23 17:33:38 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:38 --> Config Class Initialized
INFO - 2023-08-23 17:33:38 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:38 --> URI Class Initialized
DEBUG - 2023-08-23 17:33:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:38 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:38 --> Router Class Initialized
DEBUG - 2023-08-23 17:33:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:38 --> Output Class Initialized
INFO - 2023-08-23 17:33:38 --> Security Class Initialized
INFO - 2023-08-23 17:33:38 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:38 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:38 --> URI Class Initialized
INFO - 2023-08-23 17:33:38 --> URI Class Initialized
INFO - 2023-08-23 17:33:38 --> Router Class Initialized
DEBUG - 2023-08-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:38 --> Router Class Initialized
INFO - 2023-08-23 17:33:38 --> Output Class Initialized
INFO - 2023-08-23 17:33:38 --> Input Class Initialized
INFO - 2023-08-23 17:33:38 --> Output Class Initialized
INFO - 2023-08-23 17:33:38 --> Language Class Initialized
INFO - 2023-08-23 17:33:38 --> Security Class Initialized
INFO - 2023-08-23 17:33:38 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:38 --> Input Class Initialized
INFO - 2023-08-23 17:33:38 --> Input Class Initialized
ERROR - 2023-08-23 17:33:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:33:38 --> Language Class Initialized
INFO - 2023-08-23 17:33:38 --> Language Class Initialized
ERROR - 2023-08-23 17:33:38 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 17:33:38 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:33:49 --> Config Class Initialized
INFO - 2023-08-23 17:33:49 --> Config Class Initialized
INFO - 2023-08-23 17:33:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:50 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:50 --> Config Class Initialized
INFO - 2023-08-23 17:33:50 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:50 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:50 --> URI Class Initialized
INFO - 2023-08-23 17:33:50 --> Config Class Initialized
INFO - 2023-08-23 17:33:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:50 --> Config Class Initialized
DEBUG - 2023-08-23 17:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:50 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:50 --> Router Class Initialized
INFO - 2023-08-23 17:33:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:50 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:50 --> URI Class Initialized
INFO - 2023-08-23 17:33:50 --> Router Class Initialized
INFO - 2023-08-23 17:33:50 --> Output Class Initialized
INFO - 2023-08-23 17:33:50 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:50 --> Input Class Initialized
INFO - 2023-08-23 17:33:50 --> Language Class Initialized
ERROR - 2023-08-23 17:33:50 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 17:33:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:50 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:50 --> Output Class Initialized
INFO - 2023-08-23 17:33:50 --> Security Class Initialized
INFO - 2023-08-23 17:33:50 --> URI Class Initialized
INFO - 2023-08-23 17:33:50 --> Utf8 Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:51 --> URI Class Initialized
INFO - 2023-08-23 17:33:51 --> Config Class Initialized
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
INFO - 2023-08-23 17:33:51 --> Router Class Initialized
INFO - 2023-08-23 17:33:51 --> Config Class Initialized
INFO - 2023-08-23 17:33:51 --> URI Class Initialized
INFO - 2023-08-23 17:33:51 --> Router Class Initialized
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
INFO - 2023-08-23 17:33:51 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:51 --> Hooks Class Initialized
INFO - 2023-08-23 17:33:51 --> Output Class Initialized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:33:51 --> Output Class Initialized
INFO - 2023-08-23 17:33:51 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:51 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:51 --> Router Class Initialized
INFO - 2023-08-23 17:33:51 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 17:33:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
INFO - 2023-08-23 17:33:51 --> URI Class Initialized
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
INFO - 2023-08-23 17:33:51 --> Utf8 Class Initialized
INFO - 2023-08-23 17:33:51 --> Output Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:51 --> Security Class Initialized
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:33:51 --> URI Class Initialized
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
INFO - 2023-08-23 17:33:51 --> Router Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:51 --> Output Class Initialized
INFO - 2023-08-23 17:33:51 --> Router Class Initialized
INFO - 2023-08-23 17:33:51 --> Security Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:33:51 --> Output Class Initialized
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
INFO - 2023-08-23 17:33:51 --> Security Class Initialized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
DEBUG - 2023-08-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:33:51 --> Input Class Initialized
INFO - 2023-08-23 17:33:51 --> Language Class Initialized
ERROR - 2023-08-23 17:33:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 17:35:25 --> Config Class Initialized
INFO - 2023-08-23 17:35:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:25 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:25 --> URI Class Initialized
INFO - 2023-08-23 17:35:25 --> Router Class Initialized
INFO - 2023-08-23 17:35:25 --> Output Class Initialized
INFO - 2023-08-23 17:35:25 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:25 --> Input Class Initialized
INFO - 2023-08-23 17:35:25 --> Language Class Initialized
INFO - 2023-08-23 17:35:25 --> Loader Class Initialized
INFO - 2023-08-23 17:35:25 --> Helper loaded: url_helper
INFO - 2023-08-23 17:35:25 --> Helper loaded: file_helper
INFO - 2023-08-23 17:35:25 --> Database Driver Class Initialized
INFO - 2023-08-23 17:35:25 --> Email Class Initialized
DEBUG - 2023-08-23 17:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:35:25 --> Controller Class Initialized
INFO - 2023-08-23 17:35:25 --> Model "Home_model" initialized
INFO - 2023-08-23 17:35:25 --> Helper loaded: form_helper
INFO - 2023-08-23 17:35:25 --> Form Validation Class Initialized
INFO - 2023-08-23 17:35:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:35:25 --> Final output sent to browser
DEBUG - 2023-08-23 17:35:25 --> Total execution time: 0.3849
INFO - 2023-08-23 17:35:25 --> Config Class Initialized
INFO - 2023-08-23 17:35:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:25 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:25 --> URI Class Initialized
INFO - 2023-08-23 17:35:25 --> Router Class Initialized
INFO - 2023-08-23 17:35:25 --> Output Class Initialized
INFO - 2023-08-23 17:35:25 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:25 --> Input Class Initialized
INFO - 2023-08-23 17:35:25 --> Language Class Initialized
ERROR - 2023-08-23 17:35:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:35:26 --> Config Class Initialized
INFO - 2023-08-23 17:35:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:26 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:26 --> URI Class Initialized
INFO - 2023-08-23 17:35:26 --> Router Class Initialized
INFO - 2023-08-23 17:35:26 --> Output Class Initialized
INFO - 2023-08-23 17:35:26 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:26 --> Input Class Initialized
INFO - 2023-08-23 17:35:26 --> Language Class Initialized
ERROR - 2023-08-23 17:35:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:35:26 --> Config Class Initialized
INFO - 2023-08-23 17:35:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:26 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:26 --> URI Class Initialized
INFO - 2023-08-23 17:35:26 --> Router Class Initialized
INFO - 2023-08-23 17:35:26 --> Output Class Initialized
INFO - 2023-08-23 17:35:26 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:26 --> Input Class Initialized
INFO - 2023-08-23 17:35:26 --> Language Class Initialized
ERROR - 2023-08-23 17:35:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:35:26 --> Config Class Initialized
INFO - 2023-08-23 17:35:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:26 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:26 --> URI Class Initialized
INFO - 2023-08-23 17:35:26 --> Router Class Initialized
INFO - 2023-08-23 17:35:26 --> Output Class Initialized
INFO - 2023-08-23 17:35:26 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:26 --> Input Class Initialized
INFO - 2023-08-23 17:35:26 --> Language Class Initialized
ERROR - 2023-08-23 17:35:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:35:26 --> Config Class Initialized
INFO - 2023-08-23 17:35:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:35:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:35:26 --> Utf8 Class Initialized
INFO - 2023-08-23 17:35:26 --> URI Class Initialized
INFO - 2023-08-23 17:35:26 --> Router Class Initialized
INFO - 2023-08-23 17:35:26 --> Output Class Initialized
INFO - 2023-08-23 17:35:26 --> Security Class Initialized
DEBUG - 2023-08-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:35:26 --> Input Class Initialized
INFO - 2023-08-23 17:35:26 --> Language Class Initialized
ERROR - 2023-08-23 17:35:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:36:10 --> Config Class Initialized
INFO - 2023-08-23 17:36:10 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:10 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:10 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:10 --> URI Class Initialized
INFO - 2023-08-23 17:36:10 --> Router Class Initialized
INFO - 2023-08-23 17:36:10 --> Output Class Initialized
INFO - 2023-08-23 17:36:10 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:10 --> Input Class Initialized
INFO - 2023-08-23 17:36:10 --> Language Class Initialized
INFO - 2023-08-23 17:36:10 --> Loader Class Initialized
INFO - 2023-08-23 17:36:10 --> Helper loaded: url_helper
INFO - 2023-08-23 17:36:10 --> Helper loaded: file_helper
INFO - 2023-08-23 17:36:10 --> Database Driver Class Initialized
INFO - 2023-08-23 17:36:10 --> Email Class Initialized
DEBUG - 2023-08-23 17:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 17:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 17:36:10 --> Controller Class Initialized
INFO - 2023-08-23 17:36:10 --> Model "Home_model" initialized
INFO - 2023-08-23 17:36:10 --> Helper loaded: form_helper
INFO - 2023-08-23 17:36:10 --> Form Validation Class Initialized
INFO - 2023-08-23 17:36:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 17:36:11 --> Final output sent to browser
DEBUG - 2023-08-23 17:36:11 --> Total execution time: 0.3939
INFO - 2023-08-23 17:36:11 --> Config Class Initialized
INFO - 2023-08-23 17:36:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:11 --> URI Class Initialized
INFO - 2023-08-23 17:36:11 --> Router Class Initialized
INFO - 2023-08-23 17:36:11 --> Output Class Initialized
INFO - 2023-08-23 17:36:11 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:11 --> Input Class Initialized
INFO - 2023-08-23 17:36:11 --> Language Class Initialized
ERROR - 2023-08-23 17:36:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:36:11 --> Config Class Initialized
INFO - 2023-08-23 17:36:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:11 --> URI Class Initialized
INFO - 2023-08-23 17:36:11 --> Router Class Initialized
INFO - 2023-08-23 17:36:11 --> Output Class Initialized
INFO - 2023-08-23 17:36:11 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:11 --> Input Class Initialized
INFO - 2023-08-23 17:36:11 --> Language Class Initialized
ERROR - 2023-08-23 17:36:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:36:11 --> Config Class Initialized
INFO - 2023-08-23 17:36:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:11 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:11 --> URI Class Initialized
INFO - 2023-08-23 17:36:11 --> Router Class Initialized
INFO - 2023-08-23 17:36:11 --> Output Class Initialized
INFO - 2023-08-23 17:36:11 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:11 --> Input Class Initialized
INFO - 2023-08-23 17:36:11 --> Language Class Initialized
ERROR - 2023-08-23 17:36:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:36:12 --> Config Class Initialized
INFO - 2023-08-23 17:36:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:12 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:12 --> URI Class Initialized
INFO - 2023-08-23 17:36:12 --> Router Class Initialized
INFO - 2023-08-23 17:36:12 --> Output Class Initialized
INFO - 2023-08-23 17:36:12 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:12 --> Input Class Initialized
INFO - 2023-08-23 17:36:12 --> Language Class Initialized
ERROR - 2023-08-23 17:36:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 17:36:12 --> Config Class Initialized
INFO - 2023-08-23 17:36:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 17:36:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 17:36:12 --> Utf8 Class Initialized
INFO - 2023-08-23 17:36:12 --> URI Class Initialized
INFO - 2023-08-23 17:36:12 --> Router Class Initialized
INFO - 2023-08-23 17:36:12 --> Output Class Initialized
INFO - 2023-08-23 17:36:12 --> Security Class Initialized
DEBUG - 2023-08-23 17:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 17:36:12 --> Input Class Initialized
INFO - 2023-08-23 17:36:12 --> Language Class Initialized
ERROR - 2023-08-23 17:36:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:13:49 --> Config Class Initialized
INFO - 2023-08-23 19:13:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:13:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:13:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:13:49 --> URI Class Initialized
INFO - 2023-08-23 19:13:49 --> Router Class Initialized
INFO - 2023-08-23 19:13:49 --> Output Class Initialized
INFO - 2023-08-23 19:13:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:13:49 --> Input Class Initialized
INFO - 2023-08-23 19:13:49 --> Language Class Initialized
INFO - 2023-08-23 19:13:49 --> Loader Class Initialized
INFO - 2023-08-23 19:13:49 --> Helper loaded: url_helper
INFO - 2023-08-23 19:13:49 --> Helper loaded: file_helper
INFO - 2023-08-23 19:13:49 --> Database Driver Class Initialized
INFO - 2023-08-23 19:13:49 --> Email Class Initialized
DEBUG - 2023-08-23 19:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:13:49 --> Controller Class Initialized
INFO - 2023-08-23 19:13:49 --> Model "Home_model" initialized
INFO - 2023-08-23 19:13:49 --> Helper loaded: form_helper
INFO - 2023-08-23 19:13:49 --> Form Validation Class Initialized
INFO - 2023-08-23 19:13:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:13:49 --> Final output sent to browser
DEBUG - 2023-08-23 19:13:49 --> Total execution time: 0.2848
INFO - 2023-08-23 19:17:10 --> Config Class Initialized
INFO - 2023-08-23 19:17:10 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:10 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:10 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:10 --> URI Class Initialized
INFO - 2023-08-23 19:17:10 --> Router Class Initialized
INFO - 2023-08-23 19:17:10 --> Output Class Initialized
INFO - 2023-08-23 19:17:10 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:10 --> Input Class Initialized
INFO - 2023-08-23 19:17:10 --> Language Class Initialized
INFO - 2023-08-23 19:17:10 --> Loader Class Initialized
INFO - 2023-08-23 19:17:10 --> Helper loaded: url_helper
INFO - 2023-08-23 19:17:10 --> Helper loaded: file_helper
INFO - 2023-08-23 19:17:10 --> Database Driver Class Initialized
INFO - 2023-08-23 19:17:10 --> Email Class Initialized
DEBUG - 2023-08-23 19:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:17:10 --> Controller Class Initialized
INFO - 2023-08-23 19:17:10 --> Model "Home_model" initialized
INFO - 2023-08-23 19:17:10 --> Helper loaded: form_helper
INFO - 2023-08-23 19:17:10 --> Form Validation Class Initialized
INFO - 2023-08-23 19:17:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:17:10 --> Final output sent to browser
DEBUG - 2023-08-23 19:17:10 --> Total execution time: 0.3606
INFO - 2023-08-23 19:17:11 --> Config Class Initialized
INFO - 2023-08-23 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:11 --> URI Class Initialized
INFO - 2023-08-23 19:17:11 --> Router Class Initialized
INFO - 2023-08-23 19:17:11 --> Output Class Initialized
INFO - 2023-08-23 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:11 --> Input Class Initialized
INFO - 2023-08-23 19:17:11 --> Language Class Initialized
ERROR - 2023-08-23 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:11 --> Config Class Initialized
INFO - 2023-08-23 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:11 --> URI Class Initialized
INFO - 2023-08-23 19:17:11 --> Router Class Initialized
INFO - 2023-08-23 19:17:11 --> Output Class Initialized
INFO - 2023-08-23 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:11 --> Input Class Initialized
INFO - 2023-08-23 19:17:11 --> Language Class Initialized
ERROR - 2023-08-23 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:11 --> Config Class Initialized
INFO - 2023-08-23 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:11 --> Config Class Initialized
INFO - 2023-08-23 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:11 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:11 --> URI Class Initialized
INFO - 2023-08-23 19:17:11 --> Router Class Initialized
INFO - 2023-08-23 19:17:11 --> Output Class Initialized
INFO - 2023-08-23 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:11 --> Input Class Initialized
INFO - 2023-08-23 19:17:11 --> Language Class Initialized
ERROR - 2023-08-23 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:11 --> URI Class Initialized
INFO - 2023-08-23 19:17:11 --> Router Class Initialized
INFO - 2023-08-23 19:17:11 --> Output Class Initialized
INFO - 2023-08-23 19:17:11 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:11 --> Input Class Initialized
INFO - 2023-08-23 19:17:11 --> Language Class Initialized
ERROR - 2023-08-23 19:17:11 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:12 --> Config Class Initialized
INFO - 2023-08-23 19:17:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:12 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:12 --> URI Class Initialized
INFO - 2023-08-23 19:17:12 --> Router Class Initialized
INFO - 2023-08-23 19:17:12 --> Output Class Initialized
INFO - 2023-08-23 19:17:12 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:12 --> Input Class Initialized
INFO - 2023-08-23 19:17:12 --> Language Class Initialized
ERROR - 2023-08-23 19:17:12 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:16 --> Config Class Initialized
INFO - 2023-08-23 19:17:16 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:16 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:16 --> URI Class Initialized
INFO - 2023-08-23 19:17:16 --> Router Class Initialized
INFO - 2023-08-23 19:17:16 --> Output Class Initialized
INFO - 2023-08-23 19:17:16 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:16 --> Input Class Initialized
INFO - 2023-08-23 19:17:16 --> Language Class Initialized
INFO - 2023-08-23 19:17:16 --> Loader Class Initialized
INFO - 2023-08-23 19:17:16 --> Helper loaded: url_helper
INFO - 2023-08-23 19:17:16 --> Helper loaded: file_helper
INFO - 2023-08-23 19:17:16 --> Database Driver Class Initialized
INFO - 2023-08-23 19:17:16 --> Email Class Initialized
DEBUG - 2023-08-23 19:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:17:16 --> Controller Class Initialized
INFO - 2023-08-23 19:17:16 --> Model "Home_model" initialized
INFO - 2023-08-23 19:17:16 --> Helper loaded: form_helper
INFO - 2023-08-23 19:17:16 --> Form Validation Class Initialized
INFO - 2023-08-23 19:17:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:17:16 --> Final output sent to browser
DEBUG - 2023-08-23 19:17:16 --> Total execution time: 0.0627
INFO - 2023-08-23 19:17:48 --> Config Class Initialized
INFO - 2023-08-23 19:17:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:48 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:48 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
INFO - 2023-08-23 19:17:49 --> Loader Class Initialized
INFO - 2023-08-23 19:17:49 --> Helper loaded: url_helper
INFO - 2023-08-23 19:17:49 --> Helper loaded: file_helper
INFO - 2023-08-23 19:17:49 --> Database Driver Class Initialized
INFO - 2023-08-23 19:17:49 --> Email Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:17:49 --> Controller Class Initialized
INFO - 2023-08-23 19:17:49 --> Model "Home_model" initialized
INFO - 2023-08-23 19:17:49 --> Helper loaded: form_helper
INFO - 2023-08-23 19:17:49 --> Form Validation Class Initialized
INFO - 2023-08-23 19:17:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:17:49 --> Final output sent to browser
DEBUG - 2023-08-23 19:17:49 --> Total execution time: 0.3249
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:49 --> Config Class Initialized
INFO - 2023-08-23 19:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:49 --> URI Class Initialized
INFO - 2023-08-23 19:17:49 --> Router Class Initialized
INFO - 2023-08-23 19:17:49 --> Output Class Initialized
INFO - 2023-08-23 19:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:49 --> Input Class Initialized
INFO - 2023-08-23 19:17:49 --> Language Class Initialized
ERROR - 2023-08-23 19:17:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:51 --> Config Class Initialized
INFO - 2023-08-23 19:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:51 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:51 --> URI Class Initialized
INFO - 2023-08-23 19:17:51 --> Router Class Initialized
INFO - 2023-08-23 19:17:51 --> Output Class Initialized
INFO - 2023-08-23 19:17:51 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:51 --> Input Class Initialized
INFO - 2023-08-23 19:17:51 --> Language Class Initialized
INFO - 2023-08-23 19:17:51 --> Loader Class Initialized
INFO - 2023-08-23 19:17:51 --> Helper loaded: url_helper
INFO - 2023-08-23 19:17:51 --> Helper loaded: file_helper
INFO - 2023-08-23 19:17:51 --> Database Driver Class Initialized
INFO - 2023-08-23 19:17:51 --> Email Class Initialized
DEBUG - 2023-08-23 19:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:17:51 --> Controller Class Initialized
INFO - 2023-08-23 19:17:51 --> Model "Home_model" initialized
INFO - 2023-08-23 19:17:51 --> Helper loaded: form_helper
INFO - 2023-08-23 19:17:51 --> Form Validation Class Initialized
INFO - 2023-08-23 19:17:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:17:51 --> Final output sent to browser
DEBUG - 2023-08-23 19:17:51 --> Total execution time: 0.0617
INFO - 2023-08-23 19:17:54 --> Config Class Initialized
INFO - 2023-08-23 19:17:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:54 --> URI Class Initialized
INFO - 2023-08-23 19:17:54 --> Router Class Initialized
INFO - 2023-08-23 19:17:54 --> Output Class Initialized
INFO - 2023-08-23 19:17:54 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:54 --> Input Class Initialized
INFO - 2023-08-23 19:17:54 --> Language Class Initialized
INFO - 2023-08-23 19:17:54 --> Loader Class Initialized
INFO - 2023-08-23 19:17:54 --> Helper loaded: url_helper
INFO - 2023-08-23 19:17:54 --> Helper loaded: file_helper
INFO - 2023-08-23 19:17:54 --> Database Driver Class Initialized
INFO - 2023-08-23 19:17:54 --> Email Class Initialized
DEBUG - 2023-08-23 19:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:17:54 --> Controller Class Initialized
INFO - 2023-08-23 19:17:54 --> Model "Home_model" initialized
INFO - 2023-08-23 19:17:54 --> Helper loaded: form_helper
INFO - 2023-08-23 19:17:54 --> Form Validation Class Initialized
INFO - 2023-08-23 19:17:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:17:54 --> Final output sent to browser
DEBUG - 2023-08-23 19:17:54 --> Total execution time: 0.0576
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Config Class Initialized
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:55 --> Router Class Initialized
INFO - 2023-08-23 19:17:55 --> Output Class Initialized
INFO - 2023-08-23 19:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:55 --> Input Class Initialized
INFO - 2023-08-23 19:17:55 --> Language Class Initialized
ERROR - 2023-08-23 19:17:55 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 19:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:17:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:17:55 --> URI Class Initialized
INFO - 2023-08-23 19:17:56 --> Router Class Initialized
INFO - 2023-08-23 19:17:56 --> Output Class Initialized
INFO - 2023-08-23 19:17:56 --> Security Class Initialized
DEBUG - 2023-08-23 19:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:17:56 --> Input Class Initialized
INFO - 2023-08-23 19:17:56 --> Language Class Initialized
ERROR - 2023-08-23 19:17:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:53 --> Config Class Initialized
INFO - 2023-08-23 19:39:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:53 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:53 --> URI Class Initialized
INFO - 2023-08-23 19:39:53 --> Router Class Initialized
INFO - 2023-08-23 19:39:53 --> Output Class Initialized
INFO - 2023-08-23 19:39:53 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:53 --> Input Class Initialized
INFO - 2023-08-23 19:39:53 --> Language Class Initialized
INFO - 2023-08-23 19:39:53 --> Loader Class Initialized
INFO - 2023-08-23 19:39:53 --> Helper loaded: url_helper
INFO - 2023-08-23 19:39:53 --> Helper loaded: file_helper
INFO - 2023-08-23 19:39:53 --> Database Driver Class Initialized
INFO - 2023-08-23 19:39:53 --> Email Class Initialized
DEBUG - 2023-08-23 19:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:39:53 --> Controller Class Initialized
INFO - 2023-08-23 19:39:53 --> Model "Home_model" initialized
INFO - 2023-08-23 19:39:53 --> Helper loaded: download_helper
INFO - 2023-08-23 19:39:53 --> Helper loaded: form_helper
INFO - 2023-08-23 19:39:53 --> Form Validation Class Initialized
INFO - 2023-08-23 19:39:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:39:53 --> Final output sent to browser
DEBUG - 2023-08-23 19:39:53 --> Total execution time: 0.5933
INFO - 2023-08-23 19:39:54 --> Config Class Initialized
INFO - 2023-08-23 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:54 --> URI Class Initialized
INFO - 2023-08-23 19:39:54 --> Router Class Initialized
INFO - 2023-08-23 19:39:54 --> Output Class Initialized
INFO - 2023-08-23 19:39:54 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:54 --> Input Class Initialized
INFO - 2023-08-23 19:39:54 --> Language Class Initialized
ERROR - 2023-08-23 19:39:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:54 --> Config Class Initialized
INFO - 2023-08-23 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:54 --> URI Class Initialized
INFO - 2023-08-23 19:39:54 --> Router Class Initialized
INFO - 2023-08-23 19:39:54 --> Output Class Initialized
INFO - 2023-08-23 19:39:54 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:54 --> Input Class Initialized
INFO - 2023-08-23 19:39:54 --> Language Class Initialized
ERROR - 2023-08-23 19:39:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:54 --> Config Class Initialized
INFO - 2023-08-23 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:54 --> URI Class Initialized
INFO - 2023-08-23 19:39:54 --> Router Class Initialized
INFO - 2023-08-23 19:39:54 --> Output Class Initialized
INFO - 2023-08-23 19:39:54 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:54 --> Input Class Initialized
INFO - 2023-08-23 19:39:54 --> Language Class Initialized
ERROR - 2023-08-23 19:39:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:55 --> Config Class Initialized
INFO - 2023-08-23 19:39:55 --> Config Class Initialized
INFO - 2023-08-23 19:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:55 --> URI Class Initialized
INFO - 2023-08-23 19:39:55 --> Router Class Initialized
INFO - 2023-08-23 19:39:55 --> Output Class Initialized
INFO - 2023-08-23 19:39:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:55 --> Input Class Initialized
INFO - 2023-08-23 19:39:55 --> Language Class Initialized
ERROR - 2023-08-23 19:39:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:55 --> URI Class Initialized
INFO - 2023-08-23 19:39:55 --> Router Class Initialized
INFO - 2023-08-23 19:39:55 --> Output Class Initialized
INFO - 2023-08-23 19:39:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:55 --> Input Class Initialized
INFO - 2023-08-23 19:39:55 --> Language Class Initialized
ERROR - 2023-08-23 19:39:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:39:55 --> Config Class Initialized
INFO - 2023-08-23 19:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:39:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:39:55 --> URI Class Initialized
INFO - 2023-08-23 19:39:55 --> Router Class Initialized
INFO - 2023-08-23 19:39:55 --> Output Class Initialized
INFO - 2023-08-23 19:39:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:39:55 --> Input Class Initialized
INFO - 2023-08-23 19:39:55 --> Language Class Initialized
ERROR - 2023-08-23 19:39:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:40:04 --> Config Class Initialized
INFO - 2023-08-23 19:40:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:04 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:04 --> URI Class Initialized
INFO - 2023-08-23 19:40:04 --> Router Class Initialized
INFO - 2023-08-23 19:40:04 --> Output Class Initialized
INFO - 2023-08-23 19:40:04 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:04 --> Input Class Initialized
INFO - 2023-08-23 19:40:04 --> Language Class Initialized
ERROR - 2023-08-23 19:40:04 --> 404 Page Not Found: Contact/create
INFO - 2023-08-23 19:40:37 --> Config Class Initialized
INFO - 2023-08-23 19:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:37 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:38 --> URI Class Initialized
INFO - 2023-08-23 19:40:38 --> Router Class Initialized
INFO - 2023-08-23 19:40:38 --> Output Class Initialized
INFO - 2023-08-23 19:40:38 --> Security Class Initialized
INFO - 2023-08-23 19:40:38 --> Config Class Initialized
INFO - 2023-08-23 19:40:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:38 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:38 --> URI Class Initialized
INFO - 2023-08-23 19:40:38 --> Router Class Initialized
INFO - 2023-08-23 19:40:38 --> Output Class Initialized
INFO - 2023-08-23 19:40:38 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:38 --> Input Class Initialized
INFO - 2023-08-23 19:40:38 --> Language Class Initialized
ERROR - 2023-08-23 19:40:38 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:38 --> Config Class Initialized
INFO - 2023-08-23 19:40:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:38 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:38 --> URI Class Initialized
INFO - 2023-08-23 19:40:38 --> Router Class Initialized
INFO - 2023-08-23 19:40:38 --> Output Class Initialized
INFO - 2023-08-23 19:40:38 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:38 --> Input Class Initialized
INFO - 2023-08-23 19:40:38 --> Language Class Initialized
ERROR - 2023-08-23 19:40:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:38 --> Input Class Initialized
INFO - 2023-08-23 19:40:38 --> Language Class Initialized
ERROR - 2023-08-23 19:40:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:38 --> Config Class Initialized
INFO - 2023-08-23 19:40:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:38 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:38 --> URI Class Initialized
INFO - 2023-08-23 19:40:38 --> Router Class Initialized
INFO - 2023-08-23 19:40:38 --> Output Class Initialized
INFO - 2023-08-23 19:40:38 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:38 --> Input Class Initialized
INFO - 2023-08-23 19:40:38 --> Language Class Initialized
ERROR - 2023-08-23 19:40:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:39 --> Config Class Initialized
INFO - 2023-08-23 19:40:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:39 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:39 --> URI Class Initialized
INFO - 2023-08-23 19:40:39 --> Router Class Initialized
INFO - 2023-08-23 19:40:39 --> Output Class Initialized
INFO - 2023-08-23 19:40:39 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:40 --> Input Class Initialized
INFO - 2023-08-23 19:40:40 --> Language Class Initialized
ERROR - 2023-08-23 19:40:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:40 --> Config Class Initialized
INFO - 2023-08-23 19:40:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:40 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:40 --> URI Class Initialized
INFO - 2023-08-23 19:40:40 --> Router Class Initialized
INFO - 2023-08-23 19:40:40 --> Output Class Initialized
INFO - 2023-08-23 19:40:40 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:40 --> Input Class Initialized
INFO - 2023-08-23 19:40:40 --> Language Class Initialized
ERROR - 2023-08-23 19:40:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:40 --> Config Class Initialized
INFO - 2023-08-23 19:40:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:40 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:40 --> URI Class Initialized
INFO - 2023-08-23 19:40:40 --> Router Class Initialized
INFO - 2023-08-23 19:40:40 --> Output Class Initialized
INFO - 2023-08-23 19:40:40 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:40 --> Input Class Initialized
INFO - 2023-08-23 19:40:40 --> Language Class Initialized
ERROR - 2023-08-23 19:40:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:44 --> Config Class Initialized
INFO - 2023-08-23 19:40:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:44 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:44 --> URI Class Initialized
INFO - 2023-08-23 19:40:44 --> Router Class Initialized
INFO - 2023-08-23 19:40:44 --> Output Class Initialized
INFO - 2023-08-23 19:40:44 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:44 --> Input Class Initialized
INFO - 2023-08-23 19:40:44 --> Language Class Initialized
ERROR - 2023-08-23 19:40:44 --> 404 Page Not Found: Contact/create
INFO - 2023-08-23 19:40:44 --> Config Class Initialized
INFO - 2023-08-23 19:40:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:44 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:44 --> URI Class Initialized
INFO - 2023-08-23 19:40:44 --> Router Class Initialized
INFO - 2023-08-23 19:40:44 --> Output Class Initialized
INFO - 2023-08-23 19:40:44 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:44 --> Input Class Initialized
INFO - 2023-08-23 19:40:44 --> Language Class Initialized
INFO - 2023-08-23 19:40:44 --> Loader Class Initialized
INFO - 2023-08-23 19:40:44 --> Helper loaded: url_helper
INFO - 2023-08-23 19:40:44 --> Helper loaded: file_helper
INFO - 2023-08-23 19:40:44 --> Database Driver Class Initialized
INFO - 2023-08-23 19:40:44 --> Email Class Initialized
DEBUG - 2023-08-23 19:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:40:44 --> Controller Class Initialized
INFO - 2023-08-23 19:40:44 --> Config Class Initialized
INFO - 2023-08-23 19:40:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:44 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:44 --> URI Class Initialized
INFO - 2023-08-23 19:40:44 --> Router Class Initialized
INFO - 2023-08-23 19:40:44 --> Output Class Initialized
INFO - 2023-08-23 19:40:44 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:44 --> Input Class Initialized
INFO - 2023-08-23 19:40:44 --> Language Class Initialized
INFO - 2023-08-23 19:40:44 --> Loader Class Initialized
INFO - 2023-08-23 19:40:44 --> Helper loaded: url_helper
INFO - 2023-08-23 19:40:44 --> Helper loaded: file_helper
INFO - 2023-08-23 19:40:44 --> Database Driver Class Initialized
INFO - 2023-08-23 19:40:44 --> Email Class Initialized
DEBUG - 2023-08-23 19:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:40:44 --> Controller Class Initialized
INFO - 2023-08-23 19:40:44 --> Model "User_model" initialized
INFO - 2023-08-23 19:40:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-23 19:40:45 --> Final output sent to browser
DEBUG - 2023-08-23 19:40:45 --> Total execution time: 0.5271
INFO - 2023-08-23 19:40:45 --> Config Class Initialized
INFO - 2023-08-23 19:40:45 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:45 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:45 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:45 --> URI Class Initialized
INFO - 2023-08-23 19:40:45 --> Router Class Initialized
INFO - 2023-08-23 19:40:45 --> Output Class Initialized
INFO - 2023-08-23 19:40:45 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:45 --> Input Class Initialized
INFO - 2023-08-23 19:40:45 --> Language Class Initialized
ERROR - 2023-08-23 19:40:45 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-23 19:40:46 --> Config Class Initialized
INFO - 2023-08-23 19:40:46 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:46 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:46 --> URI Class Initialized
INFO - 2023-08-23 19:40:46 --> Router Class Initialized
INFO - 2023-08-23 19:40:46 --> Output Class Initialized
INFO - 2023-08-23 19:40:46 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:46 --> Input Class Initialized
INFO - 2023-08-23 19:40:46 --> Language Class Initialized
ERROR - 2023-08-23 19:40:46 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-23 19:40:46 --> Config Class Initialized
INFO - 2023-08-23 19:40:46 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:46 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:46 --> URI Class Initialized
INFO - 2023-08-23 19:40:46 --> Router Class Initialized
INFO - 2023-08-23 19:40:46 --> Output Class Initialized
INFO - 2023-08-23 19:40:46 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:46 --> Input Class Initialized
INFO - 2023-08-23 19:40:46 --> Language Class Initialized
ERROR - 2023-08-23 19:40:46 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-23 19:40:47 --> Config Class Initialized
INFO - 2023-08-23 19:40:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:47 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:47 --> URI Class Initialized
INFO - 2023-08-23 19:40:47 --> Router Class Initialized
INFO - 2023-08-23 19:40:47 --> Output Class Initialized
INFO - 2023-08-23 19:40:47 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:47 --> Input Class Initialized
INFO - 2023-08-23 19:40:47 --> Language Class Initialized
ERROR - 2023-08-23 19:40:47 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-23 19:40:55 --> Config Class Initialized
INFO - 2023-08-23 19:40:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:55 --> URI Class Initialized
INFO - 2023-08-23 19:40:55 --> Router Class Initialized
INFO - 2023-08-23 19:40:55 --> Output Class Initialized
INFO - 2023-08-23 19:40:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:55 --> Input Class Initialized
INFO - 2023-08-23 19:40:55 --> Language Class Initialized
INFO - 2023-08-23 19:40:55 --> Loader Class Initialized
INFO - 2023-08-23 19:40:55 --> Helper loaded: url_helper
INFO - 2023-08-23 19:40:56 --> Helper loaded: file_helper
INFO - 2023-08-23 19:40:56 --> Database Driver Class Initialized
INFO - 2023-08-23 19:40:56 --> Email Class Initialized
DEBUG - 2023-08-23 19:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:40:56 --> Controller Class Initialized
INFO - 2023-08-23 19:40:56 --> Model "Home_model" initialized
INFO - 2023-08-23 19:40:56 --> Helper loaded: download_helper
INFO - 2023-08-23 19:40:56 --> Helper loaded: form_helper
INFO - 2023-08-23 19:40:56 --> Form Validation Class Initialized
INFO - 2023-08-23 19:40:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:40:56 --> Final output sent to browser
DEBUG - 2023-08-23 19:40:56 --> Total execution time: 0.6032
INFO - 2023-08-23 19:40:58 --> Config Class Initialized
INFO - 2023-08-23 19:40:58 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:58 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:59 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:59 --> URI Class Initialized
INFO - 2023-08-23 19:40:59 --> Router Class Initialized
INFO - 2023-08-23 19:40:59 --> Output Class Initialized
INFO - 2023-08-23 19:40:59 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:59 --> Input Class Initialized
INFO - 2023-08-23 19:40:59 --> Language Class Initialized
ERROR - 2023-08-23 19:40:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
INFO - 2023-08-23 19:40:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:59 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:59 --> URI Class Initialized
INFO - 2023-08-23 19:40:59 --> Router Class Initialized
INFO - 2023-08-23 19:40:59 --> Output Class Initialized
INFO - 2023-08-23 19:40:59 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:59 --> Input Class Initialized
INFO - 2023-08-23 19:40:59 --> Language Class Initialized
ERROR - 2023-08-23 19:40:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
INFO - 2023-08-23 19:40:59 --> Hooks Class Initialized
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
DEBUG - 2023-08-23 19:40:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:59 --> Utf8 Class Initialized
INFO - 2023-08-23 19:40:59 --> URI Class Initialized
INFO - 2023-08-23 19:40:59 --> Router Class Initialized
INFO - 2023-08-23 19:40:59 --> Output Class Initialized
INFO - 2023-08-23 19:40:59 --> Security Class Initialized
DEBUG - 2023-08-23 19:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:40:59 --> Input Class Initialized
INFO - 2023-08-23 19:40:59 --> Language Class Initialized
ERROR - 2023-08-23 19:40:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:40:59 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:40:59 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:40:59 --> Config Class Initialized
INFO - 2023-08-23 19:41:00 --> Utf8 Class Initialized
INFO - 2023-08-23 19:41:00 --> Hooks Class Initialized
INFO - 2023-08-23 19:41:00 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:41:00 --> Utf8 Class Initialized
INFO - 2023-08-23 19:41:00 --> URI Class Initialized
INFO - 2023-08-23 19:41:00 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:41:00 --> Router Class Initialized
DEBUG - 2023-08-23 19:41:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:41:00 --> Output Class Initialized
INFO - 2023-08-23 19:41:00 --> Utf8 Class Initialized
INFO - 2023-08-23 19:41:00 --> Security Class Initialized
INFO - 2023-08-23 19:41:00 --> URI Class Initialized
INFO - 2023-08-23 19:41:00 --> URI Class Initialized
DEBUG - 2023-08-23 19:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:41:00 --> Utf8 Class Initialized
INFO - 2023-08-23 19:41:00 --> URI Class Initialized
INFO - 2023-08-23 19:41:00 --> Router Class Initialized
INFO - 2023-08-23 19:41:00 --> Router Class Initialized
INFO - 2023-08-23 19:41:00 --> Input Class Initialized
INFO - 2023-08-23 19:41:00 --> Output Class Initialized
INFO - 2023-08-23 19:41:00 --> Router Class Initialized
INFO - 2023-08-23 19:41:00 --> Language Class Initialized
INFO - 2023-08-23 19:41:00 --> Output Class Initialized
INFO - 2023-08-23 19:41:00 --> Security Class Initialized
INFO - 2023-08-23 19:41:00 --> Output Class Initialized
INFO - 2023-08-23 19:41:00 --> Security Class Initialized
INFO - 2023-08-23 19:41:00 --> Security Class Initialized
ERROR - 2023-08-23 19:41:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:41:00 --> Input Class Initialized
INFO - 2023-08-23 19:41:00 --> Input Class Initialized
INFO - 2023-08-23 19:41:00 --> Language Class Initialized
DEBUG - 2023-08-23 19:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 19:41:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:41:00 --> Input Class Initialized
INFO - 2023-08-23 19:41:00 --> Language Class Initialized
INFO - 2023-08-23 19:41:00 --> Language Class Initialized
ERROR - 2023-08-23 19:41:00 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 19:41:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:04 --> Config Class Initialized
INFO - 2023-08-23 19:48:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:04 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:04 --> URI Class Initialized
INFO - 2023-08-23 19:48:04 --> Router Class Initialized
INFO - 2023-08-23 19:48:04 --> Output Class Initialized
INFO - 2023-08-23 19:48:04 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:04 --> Input Class Initialized
INFO - 2023-08-23 19:48:04 --> Language Class Initialized
INFO - 2023-08-23 19:48:04 --> Loader Class Initialized
INFO - 2023-08-23 19:48:04 --> Helper loaded: url_helper
INFO - 2023-08-23 19:48:04 --> Helper loaded: file_helper
INFO - 2023-08-23 19:48:04 --> Database Driver Class Initialized
INFO - 2023-08-23 19:48:04 --> Email Class Initialized
DEBUG - 2023-08-23 19:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:48:05 --> Controller Class Initialized
INFO - 2023-08-23 19:48:05 --> Model "Home_model" initialized
INFO - 2023-08-23 19:48:05 --> Helper loaded: download_helper
INFO - 2023-08-23 19:48:05 --> Helper loaded: form_helper
INFO - 2023-08-23 19:48:05 --> Form Validation Class Initialized
INFO - 2023-08-23 19:48:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:48:05 --> Final output sent to browser
DEBUG - 2023-08-23 19:48:05 --> Total execution time: 0.9410
INFO - 2023-08-23 19:48:05 --> Config Class Initialized
INFO - 2023-08-23 19:48:05 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:05 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:05 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:05 --> URI Class Initialized
INFO - 2023-08-23 19:48:05 --> Router Class Initialized
INFO - 2023-08-23 19:48:05 --> Output Class Initialized
INFO - 2023-08-23 19:48:05 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:05 --> Input Class Initialized
INFO - 2023-08-23 19:48:05 --> Language Class Initialized
ERROR - 2023-08-23 19:48:05 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:06 --> Config Class Initialized
INFO - 2023-08-23 19:48:06 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:06 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:06 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:06 --> URI Class Initialized
INFO - 2023-08-23 19:48:06 --> Router Class Initialized
INFO - 2023-08-23 19:48:06 --> Output Class Initialized
INFO - 2023-08-23 19:48:06 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:06 --> Input Class Initialized
INFO - 2023-08-23 19:48:06 --> Language Class Initialized
ERROR - 2023-08-23 19:48:06 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:06 --> Config Class Initialized
INFO - 2023-08-23 19:48:06 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:06 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:06 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:06 --> URI Class Initialized
INFO - 2023-08-23 19:48:06 --> Router Class Initialized
INFO - 2023-08-23 19:48:06 --> Output Class Initialized
INFO - 2023-08-23 19:48:06 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:06 --> Input Class Initialized
INFO - 2023-08-23 19:48:06 --> Language Class Initialized
ERROR - 2023-08-23 19:48:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:07 --> Config Class Initialized
INFO - 2023-08-23 19:48:07 --> Config Class Initialized
INFO - 2023-08-23 19:48:07 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:07 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:07 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:07 --> URI Class Initialized
INFO - 2023-08-23 19:48:07 --> Router Class Initialized
INFO - 2023-08-23 19:48:07 --> Output Class Initialized
INFO - 2023-08-23 19:48:07 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:07 --> Input Class Initialized
INFO - 2023-08-23 19:48:07 --> Language Class Initialized
ERROR - 2023-08-23 19:48:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:07 --> Config Class Initialized
INFO - 2023-08-23 19:48:07 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:07 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:07 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:07 --> URI Class Initialized
INFO - 2023-08-23 19:48:07 --> Router Class Initialized
INFO - 2023-08-23 19:48:07 --> Output Class Initialized
INFO - 2023-08-23 19:48:07 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:07 --> Input Class Initialized
INFO - 2023-08-23 19:48:07 --> Language Class Initialized
ERROR - 2023-08-23 19:48:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
DEBUG - 2023-08-23 19:48:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:08 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:08 --> URI Class Initialized
INFO - 2023-08-23 19:48:08 --> Router Class Initialized
INFO - 2023-08-23 19:48:08 --> Output Class Initialized
INFO - 2023-08-23 19:48:08 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:08 --> Input Class Initialized
INFO - 2023-08-23 19:48:08 --> Language Class Initialized
ERROR - 2023-08-23 19:48:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:08 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:08 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:08 --> URI Class Initialized
INFO - 2023-08-23 19:48:08 --> Router Class Initialized
INFO - 2023-08-23 19:48:08 --> Config Class Initialized
INFO - 2023-08-23 19:48:08 --> Output Class Initialized
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:08 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:08 --> URI Class Initialized
INFO - 2023-08-23 19:48:08 --> Router Class Initialized
INFO - 2023-08-23 19:48:08 --> Output Class Initialized
INFO - 2023-08-23 19:48:08 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:08 --> Input Class Initialized
INFO - 2023-08-23 19:48:08 --> Language Class Initialized
ERROR - 2023-08-23 19:48:08 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:48:09 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:48:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:09 --> URI Class Initialized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
INFO - 2023-08-23 19:48:09 --> Config Class Initialized
INFO - 2023-08-23 19:48:09 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:09 --> Router Class Initialized
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:09 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:09 --> Output Class Initialized
DEBUG - 2023-08-23 19:48:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:09 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:09 --> URI Class Initialized
INFO - 2023-08-23 19:48:09 --> Router Class Initialized
INFO - 2023-08-23 19:48:09 --> Output Class Initialized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
INFO - 2023-08-23 19:48:09 --> URI Class Initialized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
INFO - 2023-08-23 19:48:09 --> Utf8 Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:09 --> URI Class Initialized
INFO - 2023-08-23 19:48:09 --> Router Class Initialized
INFO - 2023-08-23 19:48:09 --> URI Class Initialized
INFO - 2023-08-23 19:48:09 --> Router Class Initialized
INFO - 2023-08-23 19:48:09 --> Router Class Initialized
INFO - 2023-08-23 19:48:09 --> Output Class Initialized
INFO - 2023-08-23 19:48:09 --> Output Class Initialized
INFO - 2023-08-23 19:48:09 --> Output Class Initialized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Security Class Initialized
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:09 --> Input Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:09 --> Language Class Initialized
ERROR - 2023-08-23 19:48:09 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:51 --> Config Class Initialized
INFO - 2023-08-23 19:48:51 --> Config Class Initialized
INFO - 2023-08-23 19:48:51 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:48:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:51 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:51 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:51 --> URI Class Initialized
INFO - 2023-08-23 19:48:51 --> URI Class Initialized
INFO - 2023-08-23 19:48:51 --> Router Class Initialized
INFO - 2023-08-23 19:48:51 --> Router Class Initialized
INFO - 2023-08-23 19:48:51 --> Output Class Initialized
INFO - 2023-08-23 19:48:51 --> Output Class Initialized
INFO - 2023-08-23 19:48:51 --> Security Class Initialized
INFO - 2023-08-23 19:48:51 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:51 --> Input Class Initialized
INFO - 2023-08-23 19:48:51 --> Language Class Initialized
INFO - 2023-08-23 19:48:51 --> Input Class Initialized
INFO - 2023-08-23 19:48:52 --> Loader Class Initialized
INFO - 2023-08-23 19:48:52 --> Language Class Initialized
INFO - 2023-08-23 19:48:52 --> Helper loaded: url_helper
INFO - 2023-08-23 19:48:52 --> Loader Class Initialized
INFO - 2023-08-23 19:48:52 --> Helper loaded: url_helper
INFO - 2023-08-23 19:48:52 --> Helper loaded: file_helper
INFO - 2023-08-23 19:48:52 --> Helper loaded: file_helper
INFO - 2023-08-23 19:48:52 --> Database Driver Class Initialized
INFO - 2023-08-23 19:48:52 --> Database Driver Class Initialized
INFO - 2023-08-23 19:48:52 --> Email Class Initialized
DEBUG - 2023-08-23 19:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:48:52 --> Email Class Initialized
INFO - 2023-08-23 19:48:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-08-23 19:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:48:52 --> Controller Class Initialized
INFO - 2023-08-23 19:48:52 --> Model "Home_model" initialized
INFO - 2023-08-23 19:48:52 --> Helper loaded: download_helper
INFO - 2023-08-23 19:48:52 --> Helper loaded: form_helper
INFO - 2023-08-23 19:48:52 --> Form Validation Class Initialized
ERROR - 2023-08-23 19:48:52 --> Severity: Warning --> Undefined property: HomeController::$contact_model C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 112
ERROR - 2023-08-23 19:48:52 --> Severity: error --> Exception: Call to a member function create_contact() on null C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 112
INFO - 2023-08-23 19:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:48:52 --> Controller Class Initialized
INFO - 2023-08-23 19:48:52 --> Model "Home_model" initialized
INFO - 2023-08-23 19:48:52 --> Helper loaded: download_helper
INFO - 2023-08-23 19:48:52 --> Helper loaded: form_helper
INFO - 2023-08-23 19:48:52 --> Form Validation Class Initialized
INFO - 2023-08-23 19:48:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:48:52 --> Final output sent to browser
DEBUG - 2023-08-23 19:48:53 --> Total execution time: 1.1625
INFO - 2023-08-23 19:48:54 --> Config Class Initialized
INFO - 2023-08-23 19:48:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:55 --> Config Class Initialized
INFO - 2023-08-23 19:48:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:55 --> URI Class Initialized
INFO - 2023-08-23 19:48:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:55 --> URI Class Initialized
INFO - 2023-08-23 19:48:55 --> Router Class Initialized
INFO - 2023-08-23 19:48:55 --> Output Class Initialized
INFO - 2023-08-23 19:48:55 --> Router Class Initialized
INFO - 2023-08-23 19:48:55 --> Security Class Initialized
INFO - 2023-08-23 19:48:55 --> Output Class Initialized
DEBUG - 2023-08-23 19:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:55 --> Security Class Initialized
INFO - 2023-08-23 19:48:55 --> Input Class Initialized
DEBUG - 2023-08-23 19:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:55 --> Language Class Initialized
INFO - 2023-08-23 19:48:55 --> Input Class Initialized
ERROR - 2023-08-23 19:48:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:55 --> Language Class Initialized
ERROR - 2023-08-23 19:48:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> Security Class Initialized
INFO - 2023-08-23 19:48:56 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:56 --> Input Class Initialized
DEBUG - 2023-08-23 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:56 --> Language Class Initialized
INFO - 2023-08-23 19:48:56 --> Input Class Initialized
ERROR - 2023-08-23 19:48:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:56 --> Language Class Initialized
ERROR - 2023-08-23 19:48:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:56 --> Input Class Initialized
INFO - 2023-08-23 19:48:56 --> Language Class Initialized
ERROR - 2023-08-23 19:48:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:56 --> Input Class Initialized
INFO - 2023-08-23 19:48:56 --> Language Class Initialized
ERROR - 2023-08-23 19:48:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
INFO - 2023-08-23 19:48:56 --> Config Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> URI Class Initialized
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:56 --> Input Class Initialized
INFO - 2023-08-23 19:48:56 --> Language Class Initialized
ERROR - 2023-08-23 19:48:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
DEBUG - 2023-08-23 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:56 --> Hooks Class Initialized
INFO - 2023-08-23 19:48:56 --> Output Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:56 --> Router Class Initialized
INFO - 2023-08-23 19:48:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:48:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:48:57 --> Security Class Initialized
INFO - 2023-08-23 19:48:57 --> Output Class Initialized
INFO - 2023-08-23 19:48:57 --> URI Class Initialized
DEBUG - 2023-08-23 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:57 --> Security Class Initialized
INFO - 2023-08-23 19:48:57 --> URI Class Initialized
INFO - 2023-08-23 19:48:57 --> Utf8 Class Initialized
INFO - 2023-08-23 19:48:57 --> Router Class Initialized
INFO - 2023-08-23 19:48:57 --> Input Class Initialized
DEBUG - 2023-08-23 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:57 --> Router Class Initialized
INFO - 2023-08-23 19:48:57 --> Language Class Initialized
INFO - 2023-08-23 19:48:57 --> URI Class Initialized
INFO - 2023-08-23 19:48:57 --> Output Class Initialized
INFO - 2023-08-23 19:48:57 --> Input Class Initialized
INFO - 2023-08-23 19:48:57 --> Router Class Initialized
INFO - 2023-08-23 19:48:57 --> Output Class Initialized
INFO - 2023-08-23 19:48:57 --> Language Class Initialized
INFO - 2023-08-23 19:48:57 --> Security Class Initialized
ERROR - 2023-08-23 19:48:57 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 19:48:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:48:57 --> Security Class Initialized
INFO - 2023-08-23 19:48:57 --> Output Class Initialized
INFO - 2023-08-23 19:48:57 --> Security Class Initialized
DEBUG - 2023-08-23 19:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:57 --> Input Class Initialized
DEBUG - 2023-08-23 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:48:57 --> Language Class Initialized
INFO - 2023-08-23 19:48:57 --> Input Class Initialized
INFO - 2023-08-23 19:48:57 --> Input Class Initialized
INFO - 2023-08-23 19:48:57 --> Language Class Initialized
INFO - 2023-08-23 19:48:57 --> Language Class Initialized
ERROR - 2023-08-23 19:48:57 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 19:48:57 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 19:48:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:27 --> Config Class Initialized
INFO - 2023-08-23 19:49:27 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:27 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:27 --> URI Class Initialized
INFO - 2023-08-23 19:49:27 --> Router Class Initialized
INFO - 2023-08-23 19:49:27 --> Output Class Initialized
INFO - 2023-08-23 19:49:27 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:27 --> Input Class Initialized
INFO - 2023-08-23 19:49:27 --> Language Class Initialized
INFO - 2023-08-23 19:49:27 --> Loader Class Initialized
INFO - 2023-08-23 19:49:27 --> Helper loaded: url_helper
INFO - 2023-08-23 19:49:27 --> Helper loaded: file_helper
INFO - 2023-08-23 19:49:27 --> Database Driver Class Initialized
INFO - 2023-08-23 19:49:27 --> Email Class Initialized
DEBUG - 2023-08-23 19:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:49:27 --> Controller Class Initialized
INFO - 2023-08-23 19:49:27 --> Model "Home_model" initialized
INFO - 2023-08-23 19:49:27 --> Helper loaded: download_helper
INFO - 2023-08-23 19:49:27 --> Helper loaded: form_helper
INFO - 2023-08-23 19:49:27 --> Form Validation Class Initialized
INFO - 2023-08-23 19:49:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:49:27 --> Final output sent to browser
DEBUG - 2023-08-23 19:49:28 --> Total execution time: 0.3983
INFO - 2023-08-23 19:49:29 --> Config Class Initialized
INFO - 2023-08-23 19:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:29 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:29 --> URI Class Initialized
INFO - 2023-08-23 19:49:29 --> Router Class Initialized
INFO - 2023-08-23 19:49:29 --> Output Class Initialized
INFO - 2023-08-23 19:49:29 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:29 --> Input Class Initialized
INFO - 2023-08-23 19:49:29 --> Language Class Initialized
ERROR - 2023-08-23 19:49:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:29 --> Config Class Initialized
INFO - 2023-08-23 19:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:29 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:29 --> URI Class Initialized
INFO - 2023-08-23 19:49:29 --> Router Class Initialized
INFO - 2023-08-23 19:49:29 --> Output Class Initialized
INFO - 2023-08-23 19:49:29 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:29 --> Input Class Initialized
INFO - 2023-08-23 19:49:29 --> Language Class Initialized
ERROR - 2023-08-23 19:49:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:29 --> Config Class Initialized
INFO - 2023-08-23 19:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:29 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:29 --> URI Class Initialized
INFO - 2023-08-23 19:49:29 --> Router Class Initialized
INFO - 2023-08-23 19:49:29 --> Output Class Initialized
INFO - 2023-08-23 19:49:29 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:29 --> Input Class Initialized
INFO - 2023-08-23 19:49:29 --> Language Class Initialized
ERROR - 2023-08-23 19:49:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:29 --> Config Class Initialized
INFO - 2023-08-23 19:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:29 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:29 --> URI Class Initialized
INFO - 2023-08-23 19:49:29 --> Router Class Initialized
INFO - 2023-08-23 19:49:29 --> Output Class Initialized
INFO - 2023-08-23 19:49:29 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:29 --> Input Class Initialized
INFO - 2023-08-23 19:49:29 --> Language Class Initialized
ERROR - 2023-08-23 19:49:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:29 --> Config Class Initialized
INFO - 2023-08-23 19:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:29 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:29 --> URI Class Initialized
INFO - 2023-08-23 19:49:29 --> Router Class Initialized
INFO - 2023-08-23 19:49:29 --> Output Class Initialized
INFO - 2023-08-23 19:49:29 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:29 --> Input Class Initialized
INFO - 2023-08-23 19:49:29 --> Language Class Initialized
ERROR - 2023-08-23 19:49:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:30 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:30 --> URI Class Initialized
INFO - 2023-08-23 19:49:30 --> Router Class Initialized
INFO - 2023-08-23 19:49:30 --> Output Class Initialized
INFO - 2023-08-23 19:49:30 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:30 --> Input Class Initialized
INFO - 2023-08-23 19:49:30 --> Language Class Initialized
ERROR - 2023-08-23 19:49:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:30 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:30 --> URI Class Initialized
INFO - 2023-08-23 19:49:30 --> Router Class Initialized
INFO - 2023-08-23 19:49:30 --> Output Class Initialized
INFO - 2023-08-23 19:49:30 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:30 --> Input Class Initialized
INFO - 2023-08-23 19:49:30 --> Language Class Initialized
ERROR - 2023-08-23 19:49:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:30 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:30 --> URI Class Initialized
INFO - 2023-08-23 19:49:30 --> Router Class Initialized
INFO - 2023-08-23 19:49:30 --> Output Class Initialized
INFO - 2023-08-23 19:49:30 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:30 --> Input Class Initialized
INFO - 2023-08-23 19:49:30 --> Language Class Initialized
ERROR - 2023-08-23 19:49:30 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:30 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:30 --> URI Class Initialized
INFO - 2023-08-23 19:49:30 --> Router Class Initialized
INFO - 2023-08-23 19:49:30 --> Output Class Initialized
INFO - 2023-08-23 19:49:30 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:30 --> Input Class Initialized
INFO - 2023-08-23 19:49:30 --> Language Class Initialized
ERROR - 2023-08-23 19:49:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:30 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:30 --> URI Class Initialized
INFO - 2023-08-23 19:49:30 --> Router Class Initialized
INFO - 2023-08-23 19:49:30 --> Output Class Initialized
INFO - 2023-08-23 19:49:30 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:30 --> Input Class Initialized
INFO - 2023-08-23 19:49:30 --> Language Class Initialized
ERROR - 2023-08-23 19:49:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:30 --> Config Class Initialized
INFO - 2023-08-23 19:49:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:31 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:31 --> URI Class Initialized
INFO - 2023-08-23 19:49:31 --> Router Class Initialized
INFO - 2023-08-23 19:49:31 --> Output Class Initialized
INFO - 2023-08-23 19:49:31 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:32 --> Input Class Initialized
INFO - 2023-08-23 19:49:32 --> Language Class Initialized
ERROR - 2023-08-23 19:49:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:32 --> Config Class Initialized
INFO - 2023-08-23 19:49:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:32 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:32 --> URI Class Initialized
INFO - 2023-08-23 19:49:32 --> Router Class Initialized
INFO - 2023-08-23 19:49:32 --> Output Class Initialized
INFO - 2023-08-23 19:49:32 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:32 --> Input Class Initialized
INFO - 2023-08-23 19:49:32 --> Language Class Initialized
ERROR - 2023-08-23 19:49:32 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:32 --> Config Class Initialized
INFO - 2023-08-23 19:49:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:32 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:32 --> URI Class Initialized
INFO - 2023-08-23 19:49:32 --> Router Class Initialized
INFO - 2023-08-23 19:49:32 --> Output Class Initialized
INFO - 2023-08-23 19:49:32 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:32 --> Input Class Initialized
INFO - 2023-08-23 19:49:32 --> Language Class Initialized
ERROR - 2023-08-23 19:49:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:51 --> Config Class Initialized
INFO - 2023-08-23 19:49:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:51 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:51 --> URI Class Initialized
INFO - 2023-08-23 19:49:51 --> Router Class Initialized
INFO - 2023-08-23 19:49:51 --> Output Class Initialized
INFO - 2023-08-23 19:49:51 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:51 --> Input Class Initialized
INFO - 2023-08-23 19:49:51 --> Language Class Initialized
INFO - 2023-08-23 19:49:51 --> Loader Class Initialized
INFO - 2023-08-23 19:49:51 --> Helper loaded: url_helper
INFO - 2023-08-23 19:49:51 --> Helper loaded: file_helper
INFO - 2023-08-23 19:49:51 --> Database Driver Class Initialized
INFO - 2023-08-23 19:49:51 --> Email Class Initialized
DEBUG - 2023-08-23 19:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:49:51 --> Controller Class Initialized
INFO - 2023-08-23 19:49:51 --> Model "Home_model" initialized
INFO - 2023-08-23 19:49:51 --> Helper loaded: download_helper
INFO - 2023-08-23 19:49:51 --> Helper loaded: form_helper
INFO - 2023-08-23 19:49:51 --> Form Validation Class Initialized
INFO - 2023-08-23 19:49:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:49:52 --> Final output sent to browser
DEBUG - 2023-08-23 19:49:52 --> Total execution time: 1.0251
INFO - 2023-08-23 19:49:52 --> Config Class Initialized
INFO - 2023-08-23 19:49:52 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:52 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:52 --> URI Class Initialized
INFO - 2023-08-23 19:49:52 --> Router Class Initialized
INFO - 2023-08-23 19:49:52 --> Output Class Initialized
INFO - 2023-08-23 19:49:52 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:52 --> Input Class Initialized
INFO - 2023-08-23 19:49:52 --> Language Class Initialized
ERROR - 2023-08-23 19:49:52 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:53 --> Config Class Initialized
INFO - 2023-08-23 19:49:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:53 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:53 --> URI Class Initialized
INFO - 2023-08-23 19:49:53 --> Router Class Initialized
INFO - 2023-08-23 19:49:53 --> Output Class Initialized
INFO - 2023-08-23 19:49:53 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:53 --> Input Class Initialized
INFO - 2023-08-23 19:49:53 --> Language Class Initialized
ERROR - 2023-08-23 19:49:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:53 --> Config Class Initialized
INFO - 2023-08-23 19:49:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:53 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:53 --> URI Class Initialized
INFO - 2023-08-23 19:49:53 --> Router Class Initialized
INFO - 2023-08-23 19:49:53 --> Output Class Initialized
INFO - 2023-08-23 19:49:53 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:53 --> Input Class Initialized
INFO - 2023-08-23 19:49:53 --> Language Class Initialized
ERROR - 2023-08-23 19:49:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:53 --> Config Class Initialized
INFO - 2023-08-23 19:49:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:53 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:53 --> URI Class Initialized
INFO - 2023-08-23 19:49:53 --> Router Class Initialized
INFO - 2023-08-23 19:49:53 --> Output Class Initialized
INFO - 2023-08-23 19:49:53 --> Security Class Initialized
INFO - 2023-08-23 19:49:53 --> Config Class Initialized
INFO - 2023-08-23 19:49:53 --> Config Class Initialized
INFO - 2023-08-23 19:49:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:53 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:53 --> URI Class Initialized
INFO - 2023-08-23 19:49:53 --> Router Class Initialized
INFO - 2023-08-23 19:49:53 --> Output Class Initialized
INFO - 2023-08-23 19:49:54 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:54 --> Input Class Initialized
INFO - 2023-08-23 19:49:54 --> Language Class Initialized
ERROR - 2023-08-23 19:49:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:54 --> Config Class Initialized
DEBUG - 2023-08-23 19:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:54 --> Input Class Initialized
INFO - 2023-08-23 19:49:54 --> Language Class Initialized
ERROR - 2023-08-23 19:49:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:54 --> Config Class Initialized
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:54 --> Config Class Initialized
INFO - 2023-08-23 19:49:54 --> URI Class Initialized
INFO - 2023-08-23 19:49:54 --> Config Class Initialized
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
INFO - 2023-08-23 19:49:54 --> Router Class Initialized
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Config Class Initialized
INFO - 2023-08-23 19:49:54 --> Output Class Initialized
INFO - 2023-08-23 19:49:54 --> Security Class Initialized
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
INFO - 2023-08-23 19:49:54 --> Hooks Class Initialized
INFO - 2023-08-23 19:49:54 --> URI Class Initialized
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:54 --> Router Class Initialized
INFO - 2023-08-23 19:49:54 --> URI Class Initialized
DEBUG - 2023-08-23 19:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:49:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Input Class Initialized
INFO - 2023-08-23 19:49:54 --> Router Class Initialized
INFO - 2023-08-23 19:49:54 --> Output Class Initialized
INFO - 2023-08-23 19:49:54 --> Output Class Initialized
INFO - 2023-08-23 19:49:54 --> Language Class Initialized
INFO - 2023-08-23 19:49:54 --> URI Class Initialized
INFO - 2023-08-23 19:49:54 --> URI Class Initialized
INFO - 2023-08-23 19:49:54 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:54 --> Router Class Initialized
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
INFO - 2023-08-23 19:49:55 --> Output Class Initialized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:55 --> URI Class Initialized
INFO - 2023-08-23 19:49:55 --> Router Class Initialized
INFO - 2023-08-23 19:49:55 --> Router Class Initialized
INFO - 2023-08-23 19:49:55 --> Output Class Initialized
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Output Class Initialized
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
INFO - 2023-08-23 19:49:55 --> Config Class Initialized
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:49:55 --> Config Class Initialized
INFO - 2023-08-23 19:49:55 --> Hooks Class Initialized
INFO - 2023-08-23 19:49:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:49:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:49:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:49:55 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Utf8 Class Initialized
INFO - 2023-08-23 19:49:55 --> URI Class Initialized
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Router Class Initialized
INFO - 2023-08-23 19:49:55 --> URI Class Initialized
INFO - 2023-08-23 19:49:55 --> Router Class Initialized
INFO - 2023-08-23 19:49:55 --> Output Class Initialized
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
INFO - 2023-08-23 19:49:55 --> Output Class Initialized
ERROR - 2023-08-23 19:49:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:49:55 --> Security Class Initialized
DEBUG - 2023-08-23 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:49:55 --> Input Class Initialized
INFO - 2023-08-23 19:49:55 --> Language Class Initialized
ERROR - 2023-08-23 19:49:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:53:21 --> Config Class Initialized
INFO - 2023-08-23 19:53:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:21 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:21 --> URI Class Initialized
INFO - 2023-08-23 19:53:21 --> Router Class Initialized
INFO - 2023-08-23 19:53:21 --> Output Class Initialized
INFO - 2023-08-23 19:53:21 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:21 --> Input Class Initialized
INFO - 2023-08-23 19:53:21 --> Language Class Initialized
INFO - 2023-08-23 19:53:21 --> Loader Class Initialized
INFO - 2023-08-23 19:53:21 --> Helper loaded: url_helper
INFO - 2023-08-23 19:53:21 --> Helper loaded: file_helper
INFO - 2023-08-23 19:53:21 --> Database Driver Class Initialized
INFO - 2023-08-23 19:53:21 --> Email Class Initialized
DEBUG - 2023-08-23 19:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:53:22 --> Controller Class Initialized
INFO - 2023-08-23 19:53:22 --> Model "Home_model" initialized
INFO - 2023-08-23 19:53:22 --> Helper loaded: download_helper
INFO - 2023-08-23 19:53:22 --> Helper loaded: form_helper
INFO - 2023-08-23 19:53:22 --> Form Validation Class Initialized
INFO - 2023-08-23 19:53:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:53:22 --> Final output sent to browser
DEBUG - 2023-08-23 19:53:22 --> Total execution time: 0.4045
INFO - 2023-08-23 19:53:23 --> Config Class Initialized
INFO - 2023-08-23 19:53:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:23 --> Config Class Initialized
INFO - 2023-08-23 19:53:23 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:23 --> Config Class Initialized
INFO - 2023-08-23 19:53:23 --> Hooks Class Initialized
INFO - 2023-08-23 19:53:23 --> Config Class Initialized
INFO - 2023-08-23 19:53:23 --> Config Class Initialized
INFO - 2023-08-23 19:53:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:23 --> Hooks Class Initialized
INFO - 2023-08-23 19:53:23 --> URI Class Initialized
INFO - 2023-08-23 19:53:23 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:53:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:23 --> URI Class Initialized
INFO - 2023-08-23 19:53:23 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:23 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:23 --> Router Class Initialized
INFO - 2023-08-23 19:53:23 --> Hooks Class Initialized
INFO - 2023-08-23 19:53:23 --> Output Class Initialized
INFO - 2023-08-23 19:53:24 --> URI Class Initialized
INFO - 2023-08-23 19:53:24 --> Router Class Initialized
INFO - 2023-08-23 19:53:24 --> Output Class Initialized
INFO - 2023-08-23 19:53:24 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:24 --> Input Class Initialized
INFO - 2023-08-23 19:53:24 --> Language Class Initialized
ERROR - 2023-08-23 19:53:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:24 --> Router Class Initialized
INFO - 2023-08-23 19:53:24 --> URI Class Initialized
INFO - 2023-08-23 19:53:24 --> Router Class Initialized
INFO - 2023-08-23 19:53:24 --> Output Class Initialized
DEBUG - 2023-08-23 19:53:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:24 --> Security Class Initialized
INFO - 2023-08-23 19:53:24 --> Output Class Initialized
INFO - 2023-08-23 19:53:24 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:24 --> Input Class Initialized
INFO - 2023-08-23 19:53:24 --> Language Class Initialized
ERROR - 2023-08-23 19:53:24 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:24 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:24 --> URI Class Initialized
INFO - 2023-08-23 19:53:24 --> Router Class Initialized
INFO - 2023-08-23 19:53:24 --> Input Class Initialized
INFO - 2023-08-23 19:53:24 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:24 --> Language Class Initialized
INFO - 2023-08-23 19:53:24 --> Output Class Initialized
INFO - 2023-08-23 19:53:24 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:24 --> Input Class Initialized
INFO - 2023-08-23 19:53:24 --> Language Class Initialized
ERROR - 2023-08-23 19:53:24 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 19:53:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:24 --> Input Class Initialized
INFO - 2023-08-23 19:53:25 --> Language Class Initialized
ERROR - 2023-08-23 19:53:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:47 --> Config Class Initialized
INFO - 2023-08-23 19:53:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:47 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:47 --> URI Class Initialized
INFO - 2023-08-23 19:53:47 --> Router Class Initialized
INFO - 2023-08-23 19:53:47 --> Output Class Initialized
INFO - 2023-08-23 19:53:47 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:47 --> Input Class Initialized
INFO - 2023-08-23 19:53:47 --> Language Class Initialized
INFO - 2023-08-23 19:53:47 --> Loader Class Initialized
INFO - 2023-08-23 19:53:47 --> Helper loaded: url_helper
INFO - 2023-08-23 19:53:47 --> Helper loaded: file_helper
INFO - 2023-08-23 19:53:47 --> Database Driver Class Initialized
INFO - 2023-08-23 19:53:47 --> Email Class Initialized
DEBUG - 2023-08-23 19:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:53:47 --> Controller Class Initialized
INFO - 2023-08-23 19:53:47 --> Model "Home_model" initialized
INFO - 2023-08-23 19:53:47 --> Helper loaded: download_helper
INFO - 2023-08-23 19:53:47 --> Helper loaded: form_helper
INFO - 2023-08-23 19:53:47 --> Form Validation Class Initialized
INFO - 2023-08-23 19:53:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:53:48 --> Final output sent to browser
DEBUG - 2023-08-23 19:53:48 --> Total execution time: 0.7010
INFO - 2023-08-23 19:53:49 --> Config Class Initialized
INFO - 2023-08-23 19:53:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:49 --> Config Class Initialized
INFO - 2023-08-23 19:53:49 --> Hooks Class Initialized
INFO - 2023-08-23 19:53:49 --> Config Class Initialized
INFO - 2023-08-23 19:53:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:49 --> URI Class Initialized
INFO - 2023-08-23 19:53:49 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:53:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:49 --> URI Class Initialized
INFO - 2023-08-23 19:53:49 --> Router Class Initialized
INFO - 2023-08-23 19:53:49 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:49 --> Router Class Initialized
INFO - 2023-08-23 19:53:49 --> Output Class Initialized
INFO - 2023-08-23 19:53:49 --> Output Class Initialized
INFO - 2023-08-23 19:53:49 --> URI Class Initialized
INFO - 2023-08-23 19:53:49 --> Security Class Initialized
INFO - 2023-08-23 19:53:49 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:49 --> Input Class Initialized
INFO - 2023-08-23 19:53:49 --> Router Class Initialized
INFO - 2023-08-23 19:53:49 --> Input Class Initialized
INFO - 2023-08-23 19:53:49 --> Language Class Initialized
INFO - 2023-08-23 19:53:49 --> Language Class Initialized
INFO - 2023-08-23 19:53:49 --> Output Class Initialized
INFO - 2023-08-23 19:53:49 --> Security Class Initialized
ERROR - 2023-08-23 19:53:49 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 19:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 19:53:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:49 --> Input Class Initialized
INFO - 2023-08-23 19:53:49 --> Language Class Initialized
INFO - 2023-08-23 19:53:49 --> Config Class Initialized
INFO - 2023-08-23 19:53:50 --> Hooks Class Initialized
INFO - 2023-08-23 19:53:50 --> Config Class Initialized
ERROR - 2023-08-23 19:53:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:53:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:53:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:53:50 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:50 --> Utf8 Class Initialized
INFO - 2023-08-23 19:53:50 --> URI Class Initialized
INFO - 2023-08-23 19:53:50 --> URI Class Initialized
INFO - 2023-08-23 19:53:50 --> Router Class Initialized
INFO - 2023-08-23 19:53:50 --> Router Class Initialized
INFO - 2023-08-23 19:53:50 --> Output Class Initialized
INFO - 2023-08-23 19:53:50 --> Output Class Initialized
INFO - 2023-08-23 19:53:50 --> Security Class Initialized
DEBUG - 2023-08-23 19:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:53:50 --> Security Class Initialized
INFO - 2023-08-23 19:53:50 --> Input Class Initialized
INFO - 2023-08-23 19:53:50 --> Language Class Initialized
DEBUG - 2023-08-23 19:53:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 19:53:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:53:50 --> Input Class Initialized
INFO - 2023-08-23 19:53:50 --> Language Class Initialized
ERROR - 2023-08-23 19:53:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:54:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
DEBUG - 2023-08-23 19:54:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
INFO - 2023-08-23 19:54:14 --> Config Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:14 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:14 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:14 --> URI Class Initialized
INFO - 2023-08-23 19:54:14 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:54:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:14 --> URI Class Initialized
INFO - 2023-08-23 19:54:14 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
DEBUG - 2023-08-23 19:54:15 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:15 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:54:15 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:54:15 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:15 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:15 --> URI Class Initialized
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
INFO - 2023-08-23 19:54:15 --> URI Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> URI Class Initialized
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:15 --> Config Class Initialized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:15 --> URI Class Initialized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:15 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
INFO - 2023-08-23 19:54:15 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:15 --> URI Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:15 --> Router Class Initialized
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Output Class Initialized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
INFO - 2023-08-23 19:54:15 --> Security Class Initialized
ERROR - 2023-08-23 19:54:15 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:15 --> Input Class Initialized
INFO - 2023-08-23 19:54:15 --> Language Class Initialized
ERROR - 2023-08-23 19:54:16 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:22 --> Config Class Initialized
INFO - 2023-08-23 19:54:22 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:22 --> Config Class Initialized
DEBUG - 2023-08-23 19:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:22 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:22 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:22 --> URI Class Initialized
DEBUG - 2023-08-23 19:54:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:22 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:22 --> Router Class Initialized
INFO - 2023-08-23 19:54:22 --> URI Class Initialized
INFO - 2023-08-23 19:54:22 --> Output Class Initialized
INFO - 2023-08-23 19:54:22 --> Router Class Initialized
INFO - 2023-08-23 19:54:22 --> Security Class Initialized
INFO - 2023-08-23 19:54:22 --> Output Class Initialized
INFO - 2023-08-23 19:54:22 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:22 --> Input Class Initialized
INFO - 2023-08-23 19:54:22 --> Input Class Initialized
INFO - 2023-08-23 19:54:23 --> Language Class Initialized
INFO - 2023-08-23 19:54:23 --> Language Class Initialized
INFO - 2023-08-23 19:54:23 --> Loader Class Initialized
INFO - 2023-08-23 19:54:23 --> Loader Class Initialized
INFO - 2023-08-23 19:54:23 --> Helper loaded: url_helper
INFO - 2023-08-23 19:54:23 --> Helper loaded: url_helper
INFO - 2023-08-23 19:54:23 --> Helper loaded: file_helper
INFO - 2023-08-23 19:54:23 --> Helper loaded: file_helper
INFO - 2023-08-23 19:54:23 --> Database Driver Class Initialized
INFO - 2023-08-23 19:54:23 --> Database Driver Class Initialized
INFO - 2023-08-23 19:54:23 --> Email Class Initialized
INFO - 2023-08-23 19:54:23 --> Email Class Initialized
DEBUG - 2023-08-23 19:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:54:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-08-23 19:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:54:23 --> Controller Class Initialized
INFO - 2023-08-23 19:54:23 --> Model "Home_model" initialized
INFO - 2023-08-23 19:54:23 --> Helper loaded: download_helper
INFO - 2023-08-23 19:54:23 --> Helper loaded: form_helper
INFO - 2023-08-23 19:54:23 --> Form Validation Class Initialized
INFO - 2023-08-23 19:54:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:54:23 --> Final output sent to browser
DEBUG - 2023-08-23 19:54:23 --> Total execution time: 0.6799
INFO - 2023-08-23 19:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:54:24 --> Config Class Initialized
INFO - 2023-08-23 19:54:24 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:24 --> Controller Class Initialized
DEBUG - 2023-08-23 19:54:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:24 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:24 --> Model "Home_model" initialized
INFO - 2023-08-23 19:54:24 --> URI Class Initialized
INFO - 2023-08-23 19:54:24 --> Helper loaded: download_helper
INFO - 2023-08-23 19:54:24 --> Router Class Initialized
INFO - 2023-08-23 19:54:24 --> Helper loaded: form_helper
INFO - 2023-08-23 19:54:24 --> Output Class Initialized
INFO - 2023-08-23 19:54:24 --> Form Validation Class Initialized
INFO - 2023-08-23 19:54:24 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 19:54:24 --> Severity: Warning --> Undefined property: HomeController::$contact_model C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 112
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
ERROR - 2023-08-23 19:54:25 --> Severity: error --> Exception: Call to a member function create_contact() on null C:\xampp\htdocs\dw\application\controllers\Home\HomeController.php 112
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
ERROR - 2023-08-23 19:54:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
ERROR - 2023-08-23 19:54:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
ERROR - 2023-08-23 19:54:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> Router Class Initialized
INFO - 2023-08-23 19:54:25 --> Output Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
ERROR - 2023-08-23 19:54:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:25 --> Input Class Initialized
INFO - 2023-08-23 19:54:25 --> Config Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:25 --> Security Class Initialized
ERROR - 2023-08-23 19:54:25 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:25 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:25 --> Language Class Initialized
INFO - 2023-08-23 19:54:25 --> URI Class Initialized
INFO - 2023-08-23 19:54:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:54:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:26 --> Router Class Initialized
INFO - 2023-08-23 19:54:26 --> Config Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:26 --> Output Class Initialized
INFO - 2023-08-23 19:54:26 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:26 --> Config Class Initialized
INFO - 2023-08-23 19:54:26 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
INFO - 2023-08-23 19:54:26 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:26 --> UTF-8 Support Enabled
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:26 --> Hooks Class Initialized
INFO - 2023-08-23 19:54:26 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:26 --> URI Class Initialized
DEBUG - 2023-08-23 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:26 --> Router Class Initialized
DEBUG - 2023-08-23 19:54:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:54:26 --> URI Class Initialized
INFO - 2023-08-23 19:54:26 --> Utf8 Class Initialized
INFO - 2023-08-23 19:54:26 --> Output Class Initialized
INFO - 2023-08-23 19:54:26 --> Router Class Initialized
INFO - 2023-08-23 19:54:26 --> Security Class Initialized
INFO - 2023-08-23 19:54:26 --> URI Class Initialized
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:26 --> Router Class Initialized
INFO - 2023-08-23 19:54:26 --> Output Class Initialized
INFO - 2023-08-23 19:54:26 --> Security Class Initialized
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
DEBUG - 2023-08-23 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:54:26 --> Output Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
INFO - 2023-08-23 19:54:26 --> Security Class Initialized
DEBUG - 2023-08-23 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:54:26 --> Input Class Initialized
INFO - 2023-08-23 19:54:26 --> Language Class Initialized
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 19:54:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:57:26 --> Config Class Initialized
INFO - 2023-08-23 19:57:27 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:57:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:57:27 --> Utf8 Class Initialized
INFO - 2023-08-23 19:57:27 --> URI Class Initialized
INFO - 2023-08-23 19:57:27 --> Router Class Initialized
INFO - 2023-08-23 19:57:27 --> Output Class Initialized
INFO - 2023-08-23 19:57:27 --> Security Class Initialized
DEBUG - 2023-08-23 19:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:57:27 --> Input Class Initialized
INFO - 2023-08-23 19:57:27 --> Language Class Initialized
INFO - 2023-08-23 19:57:27 --> Loader Class Initialized
INFO - 2023-08-23 19:57:27 --> Helper loaded: url_helper
INFO - 2023-08-23 19:57:27 --> Helper loaded: file_helper
INFO - 2023-08-23 19:57:27 --> Database Driver Class Initialized
INFO - 2023-08-23 19:57:27 --> Email Class Initialized
DEBUG - 2023-08-23 19:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:57:27 --> Controller Class Initialized
ERROR - 2023-08-23 19:57:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Contact_model C:\xampp\htdocs\dw\system\core\Loader.php 349
INFO - 2023-08-23 19:57:41 --> Config Class Initialized
INFO - 2023-08-23 19:57:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:57:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:57:41 --> Config Class Initialized
INFO - 2023-08-23 19:57:41 --> Utf8 Class Initialized
INFO - 2023-08-23 19:57:41 --> Hooks Class Initialized
INFO - 2023-08-23 19:57:41 --> URI Class Initialized
DEBUG - 2023-08-23 19:57:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:57:41 --> Router Class Initialized
INFO - 2023-08-23 19:57:41 --> Output Class Initialized
INFO - 2023-08-23 19:57:41 --> Utf8 Class Initialized
INFO - 2023-08-23 19:57:41 --> Security Class Initialized
DEBUG - 2023-08-23 19:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:57:41 --> URI Class Initialized
INFO - 2023-08-23 19:57:41 --> Input Class Initialized
INFO - 2023-08-23 19:57:41 --> Router Class Initialized
INFO - 2023-08-23 19:57:41 --> Language Class Initialized
INFO - 2023-08-23 19:57:41 --> Output Class Initialized
INFO - 2023-08-23 19:57:41 --> Loader Class Initialized
INFO - 2023-08-23 19:57:41 --> Security Class Initialized
INFO - 2023-08-23 19:57:41 --> Helper loaded: url_helper
DEBUG - 2023-08-23 19:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:57:41 --> Helper loaded: file_helper
INFO - 2023-08-23 19:57:41 --> Input Class Initialized
INFO - 2023-08-23 19:57:41 --> Database Driver Class Initialized
INFO - 2023-08-23 19:57:41 --> Language Class Initialized
INFO - 2023-08-23 19:57:41 --> Email Class Initialized
INFO - 2023-08-23 19:57:41 --> Loader Class Initialized
DEBUG - 2023-08-23 19:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:57:41 --> Helper loaded: url_helper
INFO - 2023-08-23 19:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:57:41 --> Helper loaded: file_helper
INFO - 2023-08-23 19:57:41 --> Database Driver Class Initialized
INFO - 2023-08-23 19:57:41 --> Controller Class Initialized
INFO - 2023-08-23 19:57:41 --> Email Class Initialized
ERROR - 2023-08-23 19:57:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Contact_model C:\xampp\htdocs\dw\system\core\Loader.php 349
DEBUG - 2023-08-23 19:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:57:41 --> Controller Class Initialized
ERROR - 2023-08-23 19:57:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Contact_model C:\xampp\htdocs\dw\system\core\Loader.php 349
INFO - 2023-08-23 19:58:32 --> Config Class Initialized
INFO - 2023-08-23 19:58:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:58:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:33 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:33 --> URI Class Initialized
INFO - 2023-08-23 19:58:33 --> Router Class Initialized
INFO - 2023-08-23 19:58:33 --> Output Class Initialized
INFO - 2023-08-23 19:58:33 --> Security Class Initialized
DEBUG - 2023-08-23 19:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:33 --> Input Class Initialized
INFO - 2023-08-23 19:58:33 --> Language Class Initialized
INFO - 2023-08-23 19:58:33 --> Loader Class Initialized
INFO - 2023-08-23 19:58:33 --> Helper loaded: url_helper
INFO - 2023-08-23 19:58:33 --> Helper loaded: file_helper
INFO - 2023-08-23 19:58:33 --> Database Driver Class Initialized
INFO - 2023-08-23 19:58:33 --> Email Class Initialized
DEBUG - 2023-08-23 19:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 19:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 19:58:33 --> Controller Class Initialized
INFO - 2023-08-23 19:58:33 --> Model "Contact_model" initialized
INFO - 2023-08-23 19:58:33 --> Model "Home_model" initialized
INFO - 2023-08-23 19:58:33 --> Helper loaded: download_helper
INFO - 2023-08-23 19:58:33 --> Helper loaded: form_helper
INFO - 2023-08-23 19:58:33 --> Form Validation Class Initialized
INFO - 2023-08-23 19:58:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 19:58:33 --> Final output sent to browser
DEBUG - 2023-08-23 19:58:33 --> Total execution time: 0.4688
INFO - 2023-08-23 19:58:33 --> Config Class Initialized
INFO - 2023-08-23 19:58:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:58:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:33 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:33 --> URI Class Initialized
INFO - 2023-08-23 19:58:33 --> Router Class Initialized
INFO - 2023-08-23 19:58:33 --> Output Class Initialized
INFO - 2023-08-23 19:58:33 --> Security Class Initialized
DEBUG - 2023-08-23 19:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:33 --> Input Class Initialized
INFO - 2023-08-23 19:58:33 --> Language Class Initialized
ERROR - 2023-08-23 19:58:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:58:33 --> Config Class Initialized
INFO - 2023-08-23 19:58:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:58:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:33 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:33 --> URI Class Initialized
INFO - 2023-08-23 19:58:33 --> Router Class Initialized
INFO - 2023-08-23 19:58:33 --> Output Class Initialized
INFO - 2023-08-23 19:58:33 --> Security Class Initialized
DEBUG - 2023-08-23 19:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:33 --> Input Class Initialized
INFO - 2023-08-23 19:58:33 --> Language Class Initialized
ERROR - 2023-08-23 19:58:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:58:34 --> Config Class Initialized
INFO - 2023-08-23 19:58:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:58:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:34 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:35 --> URI Class Initialized
INFO - 2023-08-23 19:58:35 --> Router Class Initialized
INFO - 2023-08-23 19:58:35 --> Output Class Initialized
INFO - 2023-08-23 19:58:35 --> Security Class Initialized
DEBUG - 2023-08-23 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:35 --> Input Class Initialized
INFO - 2023-08-23 19:58:35 --> Language Class Initialized
ERROR - 2023-08-23 19:58:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:58:35 --> Config Class Initialized
INFO - 2023-08-23 19:58:35 --> Config Class Initialized
INFO - 2023-08-23 19:58:35 --> Hooks Class Initialized
INFO - 2023-08-23 19:58:35 --> Config Class Initialized
INFO - 2023-08-23 19:58:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:58:35 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:58:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:35 --> Hooks Class Initialized
INFO - 2023-08-23 19:58:35 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:58:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:58:35 --> URI Class Initialized
INFO - 2023-08-23 19:58:35 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:35 --> Utf8 Class Initialized
INFO - 2023-08-23 19:58:35 --> Router Class Initialized
INFO - 2023-08-23 19:58:35 --> URI Class Initialized
INFO - 2023-08-23 19:58:35 --> Router Class Initialized
INFO - 2023-08-23 19:58:35 --> Output Class Initialized
INFO - 2023-08-23 19:58:35 --> Output Class Initialized
INFO - 2023-08-23 19:58:35 --> Security Class Initialized
INFO - 2023-08-23 19:58:35 --> Security Class Initialized
INFO - 2023-08-23 19:58:35 --> URI Class Initialized
DEBUG - 2023-08-23 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:35 --> Router Class Initialized
INFO - 2023-08-23 19:58:35 --> Input Class Initialized
DEBUG - 2023-08-23 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:35 --> Output Class Initialized
INFO - 2023-08-23 19:58:35 --> Input Class Initialized
INFO - 2023-08-23 19:58:35 --> Security Class Initialized
INFO - 2023-08-23 19:58:35 --> Language Class Initialized
ERROR - 2023-08-23 19:58:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:58:35 --> Language Class Initialized
ERROR - 2023-08-23 19:58:35 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:58:35 --> Input Class Initialized
INFO - 2023-08-23 19:58:35 --> Language Class Initialized
ERROR - 2023-08-23 19:58:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 19:59:19 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
INFO - 2023-08-23 19:59:20 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:59:20 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:20 --> Utf8 Class Initialized
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:59:20 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:20 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:20 --> URI Class Initialized
INFO - 2023-08-23 19:59:20 --> Router Class Initialized
INFO - 2023-08-23 19:59:20 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:20 --> URI Class Initialized
INFO - 2023-08-23 19:59:20 --> URI Class Initialized
INFO - 2023-08-23 19:59:20 --> Router Class Initialized
INFO - 2023-08-23 19:59:20 --> Output Class Initialized
INFO - 2023-08-23 19:59:20 --> Output Class Initialized
INFO - 2023-08-23 19:59:20 --> Config Class Initialized
INFO - 2023-08-23 19:59:20 --> URI Class Initialized
INFO - 2023-08-23 19:59:20 --> URI Class Initialized
INFO - 2023-08-23 19:59:20 --> Router Class Initialized
INFO - 2023-08-23 19:59:20 --> Security Class Initialized
INFO - 2023-08-23 19:59:20 --> Security Class Initialized
DEBUG - 2023-08-23 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:20 --> Router Class Initialized
INFO - 2023-08-23 19:59:20 --> Output Class Initialized
INFO - 2023-08-23 19:59:20 --> Hooks Class Initialized
INFO - 2023-08-23 19:59:20 --> Input Class Initialized
DEBUG - 2023-08-23 19:59:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 19:59:20 --> Router Class Initialized
DEBUG - 2023-08-23 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:20 --> Output Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
INFO - 2023-08-23 19:59:21 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:21 --> Security Class Initialized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:59:21 --> Config Class Initialized
INFO - 2023-08-23 19:59:21 --> Output Class Initialized
INFO - 2023-08-23 19:59:21 --> Hooks Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
DEBUG - 2023-08-23 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:21 --> Security Class Initialized
DEBUG - 2023-08-23 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:59:21 --> URI Class Initialized
DEBUG - 2023-08-23 19:59:21 --> UTF-8 Support Enabled
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:59:21 --> Router Class Initialized
INFO - 2023-08-23 19:59:21 --> Output Class Initialized
INFO - 2023-08-23 19:59:21 --> Security Class Initialized
INFO - 2023-08-23 19:59:21 --> Utf8 Class Initialized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
DEBUG - 2023-08-23 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:21 --> Security Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
INFO - 2023-08-23 19:59:21 --> URI Class Initialized
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
INFO - 2023-08-23 19:59:21 --> Router Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
INFO - 2023-08-23 19:59:21 --> Output Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 19:59:21 --> Security Class Initialized
DEBUG - 2023-08-23 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 19:59:21 --> Input Class Initialized
INFO - 2023-08-23 19:59:21 --> Language Class Initialized
ERROR - 2023-08-23 19:59:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:25 --> Config Class Initialized
INFO - 2023-08-23 20:00:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:25 --> URI Class Initialized
INFO - 2023-08-23 20:00:25 --> Router Class Initialized
INFO - 2023-08-23 20:00:25 --> Output Class Initialized
INFO - 2023-08-23 20:00:25 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:25 --> Input Class Initialized
INFO - 2023-08-23 20:00:25 --> Language Class Initialized
INFO - 2023-08-23 20:00:25 --> Loader Class Initialized
INFO - 2023-08-23 20:00:25 --> Helper loaded: url_helper
INFO - 2023-08-23 20:00:25 --> Helper loaded: file_helper
INFO - 2023-08-23 20:00:25 --> Database Driver Class Initialized
INFO - 2023-08-23 20:00:25 --> Email Class Initialized
DEBUG - 2023-08-23 20:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:00:25 --> Controller Class Initialized
INFO - 2023-08-23 20:00:25 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:00:25 --> Model "Home_model" initialized
INFO - 2023-08-23 20:00:25 --> Helper loaded: download_helper
INFO - 2023-08-23 20:00:25 --> Helper loaded: form_helper
INFO - 2023-08-23 20:00:26 --> Form Validation Class Initialized
INFO - 2023-08-23 20:00:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:00:26 --> Final output sent to browser
DEBUG - 2023-08-23 20:00:26 --> Total execution time: 0.8540
INFO - 2023-08-23 20:00:29 --> Config Class Initialized
INFO - 2023-08-23 20:00:29 --> Config Class Initialized
INFO - 2023-08-23 20:00:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:29 --> Config Class Initialized
DEBUG - 2023-08-23 20:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:29 --> Config Class Initialized
INFO - 2023-08-23 20:00:29 --> URI Class Initialized
INFO - 2023-08-23 20:00:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:29 --> URI Class Initialized
INFO - 2023-08-23 20:00:29 --> Router Class Initialized
INFO - 2023-08-23 20:00:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:29 --> Router Class Initialized
DEBUG - 2023-08-23 20:00:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:29 --> Output Class Initialized
INFO - 2023-08-23 20:00:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:29 --> Output Class Initialized
INFO - 2023-08-23 20:00:29 --> Security Class Initialized
INFO - 2023-08-23 20:00:29 --> URI Class Initialized
INFO - 2023-08-23 20:00:29 --> Router Class Initialized
INFO - 2023-08-23 20:00:29 --> Output Class Initialized
INFO - 2023-08-23 20:00:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:29 --> Input Class Initialized
INFO - 2023-08-23 20:00:29 --> Language Class Initialized
ERROR - 2023-08-23 20:00:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
INFO - 2023-08-23 20:00:30 --> URI Class Initialized
DEBUG - 2023-08-23 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:30 --> Input Class Initialized
INFO - 2023-08-23 20:00:30 --> Input Class Initialized
INFO - 2023-08-23 20:00:30 --> Language Class Initialized
ERROR - 2023-08-23 20:00:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:30 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:30 --> Language Class Initialized
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
ERROR - 2023-08-23 20:00:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
DEBUG - 2023-08-23 20:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:30 --> Router Class Initialized
INFO - 2023-08-23 20:00:30 --> Output Class Initialized
INFO - 2023-08-23 20:00:30 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:30 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
DEBUG - 2023-08-23 20:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:30 --> Security Class Initialized
INFO - 2023-08-23 20:00:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
INFO - 2023-08-23 20:00:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:30 --> URI Class Initialized
DEBUG - 2023-08-23 20:00:30 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:30 --> Router Class Initialized
INFO - 2023-08-23 20:00:30 --> URI Class Initialized
INFO - 2023-08-23 20:00:30 --> URI Class Initialized
INFO - 2023-08-23 20:00:30 --> Router Class Initialized
INFO - 2023-08-23 20:00:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:30 --> Router Class Initialized
INFO - 2023-08-23 20:00:30 --> Output Class Initialized
INFO - 2023-08-23 20:00:30 --> Output Class Initialized
INFO - 2023-08-23 20:00:30 --> Input Class Initialized
INFO - 2023-08-23 20:00:30 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:30 --> Output Class Initialized
INFO - 2023-08-23 20:00:30 --> Language Class Initialized
INFO - 2023-08-23 20:00:30 --> URI Class Initialized
INFO - 2023-08-23 20:00:30 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:30 --> Input Class Initialized
INFO - 2023-08-23 20:00:30 --> Language Class Initialized
ERROR - 2023-08-23 20:00:30 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:00:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:30 --> Router Class Initialized
INFO - 2023-08-23 20:00:30 --> Security Class Initialized
INFO - 2023-08-23 20:00:30 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:30 --> Output Class Initialized
INFO - 2023-08-23 20:00:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:30 --> Config Class Initialized
INFO - 2023-08-23 20:00:31 --> Config Class Initialized
INFO - 2023-08-23 20:00:31 --> URI Class Initialized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:31 --> Router Class Initialized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:31 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:31 --> Output Class Initialized
INFO - 2023-08-23 20:00:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:00:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
DEBUG - 2023-08-23 20:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Config Class Initialized
INFO - 2023-08-23 20:00:31 --> Hooks Class Initialized
INFO - 2023-08-23 20:00:31 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:00:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> URI Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
INFO - 2023-08-23 20:00:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:31 --> URI Class Initialized
INFO - 2023-08-23 20:00:31 --> Router Class Initialized
INFO - 2023-08-23 20:00:31 --> Output Class Initialized
INFO - 2023-08-23 20:00:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:31 --> URI Class Initialized
INFO - 2023-08-23 20:00:31 --> Router Class Initialized
INFO - 2023-08-23 20:00:31 --> Router Class Initialized
INFO - 2023-08-23 20:00:31 --> Output Class Initialized
INFO - 2023-08-23 20:00:31 --> Output Class Initialized
INFO - 2023-08-23 20:00:31 --> Security Class Initialized
INFO - 2023-08-23 20:00:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Input Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
INFO - 2023-08-23 20:00:31 --> Language Class Initialized
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:00:31 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:37 --> Config Class Initialized
INFO - 2023-08-23 20:00:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:37 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:37 --> URI Class Initialized
INFO - 2023-08-23 20:00:37 --> Router Class Initialized
INFO - 2023-08-23 20:00:37 --> Output Class Initialized
INFO - 2023-08-23 20:00:37 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:37 --> Input Class Initialized
INFO - 2023-08-23 20:00:37 --> Language Class Initialized
INFO - 2023-08-23 20:00:37 --> Loader Class Initialized
INFO - 2023-08-23 20:00:37 --> Helper loaded: url_helper
INFO - 2023-08-23 20:00:37 --> Helper loaded: file_helper
INFO - 2023-08-23 20:00:37 --> Database Driver Class Initialized
INFO - 2023-08-23 20:00:37 --> Email Class Initialized
DEBUG - 2023-08-23 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:00:37 --> Controller Class Initialized
INFO - 2023-08-23 20:00:37 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:00:37 --> Model "Home_model" initialized
INFO - 2023-08-23 20:00:37 --> Helper loaded: download_helper
INFO - 2023-08-23 20:00:37 --> Helper loaded: form_helper
INFO - 2023-08-23 20:00:37 --> Form Validation Class Initialized
INFO - 2023-08-23 20:00:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:00:37 --> Final output sent to browser
DEBUG - 2023-08-23 20:00:37 --> Total execution time: 0.7045
INFO - 2023-08-23 20:00:39 --> Config Class Initialized
INFO - 2023-08-23 20:00:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:39 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:39 --> URI Class Initialized
INFO - 2023-08-23 20:00:39 --> Router Class Initialized
INFO - 2023-08-23 20:00:39 --> Output Class Initialized
INFO - 2023-08-23 20:00:39 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:39 --> Input Class Initialized
INFO - 2023-08-23 20:00:39 --> Language Class Initialized
ERROR - 2023-08-23 20:00:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:40 --> Config Class Initialized
INFO - 2023-08-23 20:00:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:40 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:40 --> URI Class Initialized
INFO - 2023-08-23 20:00:40 --> Router Class Initialized
INFO - 2023-08-23 20:00:40 --> Output Class Initialized
INFO - 2023-08-23 20:00:40 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:40 --> Input Class Initialized
INFO - 2023-08-23 20:00:40 --> Language Class Initialized
ERROR - 2023-08-23 20:00:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:40 --> Config Class Initialized
INFO - 2023-08-23 20:00:40 --> Config Class Initialized
INFO - 2023-08-23 20:00:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:40 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:40 --> URI Class Initialized
INFO - 2023-08-23 20:00:40 --> Router Class Initialized
INFO - 2023-08-23 20:00:40 --> Output Class Initialized
INFO - 2023-08-23 20:00:40 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:40 --> Input Class Initialized
INFO - 2023-08-23 20:00:40 --> Language Class Initialized
ERROR - 2023-08-23 20:00:40 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:41 --> Config Class Initialized
INFO - 2023-08-23 20:00:41 --> Config Class Initialized
INFO - 2023-08-23 20:00:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:41 --> URI Class Initialized
INFO - 2023-08-23 20:00:41 --> Router Class Initialized
INFO - 2023-08-23 20:00:41 --> Output Class Initialized
INFO - 2023-08-23 20:00:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:41 --> Input Class Initialized
INFO - 2023-08-23 20:00:41 --> Language Class Initialized
ERROR - 2023-08-23 20:00:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:41 --> URI Class Initialized
INFO - 2023-08-23 20:00:41 --> Router Class Initialized
INFO - 2023-08-23 20:00:41 --> Output Class Initialized
INFO - 2023-08-23 20:00:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:41 --> Input Class Initialized
INFO - 2023-08-23 20:00:41 --> Language Class Initialized
ERROR - 2023-08-23 20:00:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:41 --> Config Class Initialized
INFO - 2023-08-23 20:00:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:41 --> URI Class Initialized
INFO - 2023-08-23 20:00:41 --> Router Class Initialized
INFO - 2023-08-23 20:00:41 --> Output Class Initialized
INFO - 2023-08-23 20:00:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:41 --> Input Class Initialized
INFO - 2023-08-23 20:00:41 --> Language Class Initialized
ERROR - 2023-08-23 20:00:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:41 --> URI Class Initialized
INFO - 2023-08-23 20:00:41 --> Config Class Initialized
INFO - 2023-08-23 20:00:42 --> Router Class Initialized
INFO - 2023-08-23 20:00:42 --> Output Class Initialized
INFO - 2023-08-23 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:42 --> Input Class Initialized
INFO - 2023-08-23 20:00:42 --> Language Class Initialized
ERROR - 2023-08-23 20:00:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:42 --> URI Class Initialized
INFO - 2023-08-23 20:00:42 --> Router Class Initialized
INFO - 2023-08-23 20:00:42 --> Output Class Initialized
INFO - 2023-08-23 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:42 --> Input Class Initialized
INFO - 2023-08-23 20:00:42 --> Language Class Initialized
ERROR - 2023-08-23 20:00:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:42 --> Config Class Initialized
INFO - 2023-08-23 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:42 --> URI Class Initialized
INFO - 2023-08-23 20:00:42 --> Router Class Initialized
INFO - 2023-08-23 20:00:42 --> Output Class Initialized
INFO - 2023-08-23 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:42 --> Input Class Initialized
INFO - 2023-08-23 20:00:42 --> Language Class Initialized
ERROR - 2023-08-23 20:00:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:42 --> Config Class Initialized
INFO - 2023-08-23 20:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:42 --> URI Class Initialized
INFO - 2023-08-23 20:00:42 --> Router Class Initialized
INFO - 2023-08-23 20:00:42 --> Output Class Initialized
INFO - 2023-08-23 20:00:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:42 --> Input Class Initialized
INFO - 2023-08-23 20:00:42 --> Language Class Initialized
ERROR - 2023-08-23 20:00:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:43 --> Config Class Initialized
INFO - 2023-08-23 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:43 --> URI Class Initialized
INFO - 2023-08-23 20:00:43 --> Router Class Initialized
INFO - 2023-08-23 20:00:43 --> Output Class Initialized
INFO - 2023-08-23 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:43 --> Input Class Initialized
INFO - 2023-08-23 20:00:43 --> Language Class Initialized
ERROR - 2023-08-23 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:43 --> Config Class Initialized
INFO - 2023-08-23 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:43 --> URI Class Initialized
INFO - 2023-08-23 20:00:43 --> Router Class Initialized
INFO - 2023-08-23 20:00:43 --> Output Class Initialized
INFO - 2023-08-23 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:43 --> Input Class Initialized
INFO - 2023-08-23 20:00:43 --> Language Class Initialized
ERROR - 2023-08-23 20:00:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:00:43 --> Config Class Initialized
INFO - 2023-08-23 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:43 --> URI Class Initialized
INFO - 2023-08-23 20:00:43 --> Router Class Initialized
INFO - 2023-08-23 20:00:43 --> Output Class Initialized
INFO - 2023-08-23 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:43 --> Input Class Initialized
INFO - 2023-08-23 20:00:43 --> Language Class Initialized
ERROR - 2023-08-23 20:00:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:43 --> Config Class Initialized
INFO - 2023-08-23 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:43 --> URI Class Initialized
INFO - 2023-08-23 20:00:43 --> Router Class Initialized
INFO - 2023-08-23 20:00:43 --> Output Class Initialized
INFO - 2023-08-23 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:43 --> Input Class Initialized
INFO - 2023-08-23 20:00:43 --> Config Class Initialized
INFO - 2023-08-23 20:00:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:43 --> URI Class Initialized
INFO - 2023-08-23 20:00:43 --> Router Class Initialized
INFO - 2023-08-23 20:00:43 --> Output Class Initialized
INFO - 2023-08-23 20:00:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:43 --> Input Class Initialized
INFO - 2023-08-23 20:00:43 --> Language Class Initialized
ERROR - 2023-08-23 20:00:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:43 --> Language Class Initialized
ERROR - 2023-08-23 20:00:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:00:50 --> Config Class Initialized
INFO - 2023-08-23 20:00:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:00:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:00:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:00:50 --> URI Class Initialized
INFO - 2023-08-23 20:00:50 --> Router Class Initialized
INFO - 2023-08-23 20:00:50 --> Output Class Initialized
INFO - 2023-08-23 20:00:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:00:50 --> Input Class Initialized
INFO - 2023-08-23 20:00:50 --> Language Class Initialized
INFO - 2023-08-23 20:00:50 --> Loader Class Initialized
INFO - 2023-08-23 20:00:50 --> Helper loaded: url_helper
INFO - 2023-08-23 20:00:50 --> Helper loaded: file_helper
INFO - 2023-08-23 20:00:50 --> Database Driver Class Initialized
INFO - 2023-08-23 20:00:50 --> Email Class Initialized
DEBUG - 2023-08-23 20:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:00:50 --> Controller Class Initialized
INFO - 2023-08-23 20:00:50 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:00:50 --> Model "Home_model" initialized
INFO - 2023-08-23 20:00:50 --> Helper loaded: download_helper
INFO - 2023-08-23 20:00:50 --> Helper loaded: form_helper
INFO - 2023-08-23 20:00:50 --> Form Validation Class Initialized
ERROR - 2023-08-23 20:00:50 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `message`, `services_ids`, `status`, `created_at`) VALUES ('', '', '', '', NULL, NULL, '2023-08-23 20:00:50')
INFO - 2023-08-23 20:00:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-23 20:01:17 --> Config Class Initialized
INFO - 2023-08-23 20:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:17 --> URI Class Initialized
INFO - 2023-08-23 20:01:17 --> Router Class Initialized
INFO - 2023-08-23 20:01:17 --> Output Class Initialized
INFO - 2023-08-23 20:01:17 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:17 --> Input Class Initialized
INFO - 2023-08-23 20:01:17 --> Language Class Initialized
INFO - 2023-08-23 20:01:17 --> Loader Class Initialized
INFO - 2023-08-23 20:01:17 --> Helper loaded: url_helper
INFO - 2023-08-23 20:01:17 --> Helper loaded: file_helper
INFO - 2023-08-23 20:01:17 --> Database Driver Class Initialized
INFO - 2023-08-23 20:01:17 --> Email Class Initialized
DEBUG - 2023-08-23 20:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:01:17 --> Controller Class Initialized
INFO - 2023-08-23 20:01:17 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:01:17 --> Model "Home_model" initialized
INFO - 2023-08-23 20:01:17 --> Helper loaded: download_helper
INFO - 2023-08-23 20:01:17 --> Helper loaded: form_helper
INFO - 2023-08-23 20:01:17 --> Form Validation Class Initialized
ERROR - 2023-08-23 20:01:17 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `message`, `services_ids`, `status`, `created_at`) VALUES ('hh', 'ghggh@gmail.com', '8888888888', 'jjhgfjgfjghfjhgf', NULL, NULL, '2023-08-23 20:01:17')
INFO - 2023-08-23 20:01:17 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-23 20:01:17 --> Config Class Initialized
INFO - 2023-08-23 20:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:17 --> URI Class Initialized
INFO - 2023-08-23 20:01:17 --> Router Class Initialized
INFO - 2023-08-23 20:01:17 --> Output Class Initialized
INFO - 2023-08-23 20:01:17 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:17 --> Input Class Initialized
INFO - 2023-08-23 20:01:17 --> Language Class Initialized
INFO - 2023-08-23 20:01:18 --> Loader Class Initialized
INFO - 2023-08-23 20:01:18 --> Helper loaded: url_helper
INFO - 2023-08-23 20:01:18 --> Helper loaded: file_helper
INFO - 2023-08-23 20:01:18 --> Database Driver Class Initialized
INFO - 2023-08-23 20:01:18 --> Email Class Initialized
DEBUG - 2023-08-23 20:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:01:18 --> Controller Class Initialized
INFO - 2023-08-23 20:01:18 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:01:18 --> Model "Home_model" initialized
INFO - 2023-08-23 20:01:18 --> Helper loaded: download_helper
INFO - 2023-08-23 20:01:18 --> Helper loaded: form_helper
INFO - 2023-08-23 20:01:18 --> Form Validation Class Initialized
INFO - 2023-08-23 20:01:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:01:18 --> Final output sent to browser
DEBUG - 2023-08-23 20:01:18 --> Total execution time: 1.3833
INFO - 2023-08-23 20:01:19 --> Config Class Initialized
INFO - 2023-08-23 20:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:19 --> URI Class Initialized
INFO - 2023-08-23 20:01:19 --> Router Class Initialized
INFO - 2023-08-23 20:01:19 --> Output Class Initialized
INFO - 2023-08-23 20:01:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:19 --> Input Class Initialized
INFO - 2023-08-23 20:01:19 --> Language Class Initialized
ERROR - 2023-08-23 20:01:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:20 --> Config Class Initialized
INFO - 2023-08-23 20:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:20 --> URI Class Initialized
INFO - 2023-08-23 20:01:20 --> Router Class Initialized
INFO - 2023-08-23 20:01:20 --> Output Class Initialized
INFO - 2023-08-23 20:01:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:20 --> Input Class Initialized
INFO - 2023-08-23 20:01:20 --> Language Class Initialized
ERROR - 2023-08-23 20:01:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:20 --> Config Class Initialized
INFO - 2023-08-23 20:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:20 --> URI Class Initialized
INFO - 2023-08-23 20:01:20 --> Router Class Initialized
INFO - 2023-08-23 20:01:20 --> Output Class Initialized
INFO - 2023-08-23 20:01:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:20 --> Input Class Initialized
INFO - 2023-08-23 20:01:20 --> Language Class Initialized
ERROR - 2023-08-23 20:01:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:21 --> URI Class Initialized
INFO - 2023-08-23 20:01:21 --> Router Class Initialized
INFO - 2023-08-23 20:01:21 --> Output Class Initialized
INFO - 2023-08-23 20:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:21 --> Input Class Initialized
INFO - 2023-08-23 20:01:21 --> Language Class Initialized
ERROR - 2023-08-23 20:01:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> URI Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Router Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:21 --> URI Class Initialized
INFO - 2023-08-23 20:01:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:21 --> URI Class Initialized
INFO - 2023-08-23 20:01:21 --> Router Class Initialized
INFO - 2023-08-23 20:01:21 --> Output Class Initialized
INFO - 2023-08-23 20:01:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:21 --> Input Class Initialized
INFO - 2023-08-23 20:01:21 --> Language Class Initialized
ERROR - 2023-08-23 20:01:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:01:21 --> Output Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:21 --> Router Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:21 --> Security Class Initialized
INFO - 2023-08-23 20:01:21 --> Config Class Initialized
INFO - 2023-08-23 20:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:21 --> Output Class Initialized
INFO - 2023-08-23 20:01:21 --> Security Class Initialized
INFO - 2023-08-23 20:01:21 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:22 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:01:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:22 --> URI Class Initialized
INFO - 2023-08-23 20:01:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
INFO - 2023-08-23 20:01:22 --> URI Class Initialized
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
INFO - 2023-08-23 20:01:22 --> URI Class Initialized
INFO - 2023-08-23 20:01:22 --> Router Class Initialized
INFO - 2023-08-23 20:01:22 --> Output Class Initialized
INFO - 2023-08-23 20:01:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:01:22 --> Router Class Initialized
INFO - 2023-08-23 20:01:22 --> Router Class Initialized
INFO - 2023-08-23 20:01:22 --> Output Class Initialized
INFO - 2023-08-23 20:01:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:22 --> Output Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
INFO - 2023-08-23 20:01:22 --> Config Class Initialized
INFO - 2023-08-23 20:01:22 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:01:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:22 --> URI Class Initialized
INFO - 2023-08-23 20:01:22 --> Security Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:22 --> Router Class Initialized
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
INFO - 2023-08-23 20:01:22 --> URI Class Initialized
INFO - 2023-08-23 20:01:22 --> Config Class Initialized
INFO - 2023-08-23 20:01:22 --> Output Class Initialized
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
INFO - 2023-08-23 20:01:22 --> Router Class Initialized
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:22 --> Security Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:01:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:22 --> Output Class Initialized
DEBUG - 2023-08-23 20:01:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:01:22 --> Input Class Initialized
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
INFO - 2023-08-23 20:01:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:01:22 --> Security Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:01:22 --> Language Class Initialized
ERROR - 2023-08-23 20:01:22 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:01:23 --> URI Class Initialized
INFO - 2023-08-23 20:01:23 --> Input Class Initialized
INFO - 2023-08-23 20:01:23 --> Router Class Initialized
INFO - 2023-08-23 20:01:23 --> Output Class Initialized
INFO - 2023-08-23 20:01:23 --> Language Class Initialized
INFO - 2023-08-23 20:01:23 --> Security Class Initialized
DEBUG - 2023-08-23 20:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:01:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:01:23 --> Input Class Initialized
INFO - 2023-08-23 20:01:23 --> Language Class Initialized
ERROR - 2023-08-23 20:01:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:19 --> Config Class Initialized
INFO - 2023-08-23 20:03:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:19 --> URI Class Initialized
INFO - 2023-08-23 20:03:19 --> Router Class Initialized
INFO - 2023-08-23 20:03:19 --> Output Class Initialized
INFO - 2023-08-23 20:03:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:19 --> Input Class Initialized
INFO - 2023-08-23 20:03:19 --> Language Class Initialized
INFO - 2023-08-23 20:03:19 --> Loader Class Initialized
INFO - 2023-08-23 20:03:19 --> Helper loaded: url_helper
INFO - 2023-08-23 20:03:19 --> Helper loaded: file_helper
INFO - 2023-08-23 20:03:19 --> Database Driver Class Initialized
INFO - 2023-08-23 20:03:20 --> Email Class Initialized
DEBUG - 2023-08-23 20:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:03:20 --> Controller Class Initialized
INFO - 2023-08-23 20:03:20 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:03:20 --> Model "Home_model" initialized
INFO - 2023-08-23 20:03:20 --> Helper loaded: download_helper
INFO - 2023-08-23 20:03:20 --> Helper loaded: form_helper
INFO - 2023-08-23 20:03:20 --> Form Validation Class Initialized
INFO - 2023-08-23 20:03:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:03:20 --> Final output sent to browser
DEBUG - 2023-08-23 20:03:20 --> Total execution time: 1.1779
INFO - 2023-08-23 20:03:20 --> Config Class Initialized
INFO - 2023-08-23 20:03:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:20 --> URI Class Initialized
INFO - 2023-08-23 20:03:20 --> Router Class Initialized
INFO - 2023-08-23 20:03:20 --> Output Class Initialized
INFO - 2023-08-23 20:03:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:20 --> Input Class Initialized
INFO - 2023-08-23 20:03:20 --> Language Class Initialized
ERROR - 2023-08-23 20:03:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:20 --> Config Class Initialized
INFO - 2023-08-23 20:03:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:20 --> URI Class Initialized
INFO - 2023-08-23 20:03:20 --> Router Class Initialized
INFO - 2023-08-23 20:03:20 --> Output Class Initialized
INFO - 2023-08-23 20:03:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:20 --> Input Class Initialized
INFO - 2023-08-23 20:03:20 --> Language Class Initialized
ERROR - 2023-08-23 20:03:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:21 --> Config Class Initialized
INFO - 2023-08-23 20:03:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:21 --> URI Class Initialized
INFO - 2023-08-23 20:03:21 --> Router Class Initialized
INFO - 2023-08-23 20:03:21 --> Output Class Initialized
INFO - 2023-08-23 20:03:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:21 --> Input Class Initialized
INFO - 2023-08-23 20:03:21 --> Language Class Initialized
ERROR - 2023-08-23 20:03:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:21 --> Config Class Initialized
INFO - 2023-08-23 20:03:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:21 --> URI Class Initialized
INFO - 2023-08-23 20:03:21 --> Router Class Initialized
INFO - 2023-08-23 20:03:21 --> Output Class Initialized
INFO - 2023-08-23 20:03:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:22 --> Input Class Initialized
INFO - 2023-08-23 20:03:22 --> Config Class Initialized
INFO - 2023-08-23 20:03:22 --> Config Class Initialized
INFO - 2023-08-23 20:03:22 --> Language Class Initialized
INFO - 2023-08-23 20:03:22 --> Hooks Class Initialized
ERROR - 2023-08-23 20:03:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:22 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:03:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:22 --> Config Class Initialized
INFO - 2023-08-23 20:03:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:22 --> URI Class Initialized
INFO - 2023-08-23 20:03:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:22 --> URI Class Initialized
DEBUG - 2023-08-23 20:03:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:22 --> Router Class Initialized
INFO - 2023-08-23 20:03:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:23 --> Router Class Initialized
INFO - 2023-08-23 20:03:23 --> Config Class Initialized
INFO - 2023-08-23 20:03:23 --> Output Class Initialized
INFO - 2023-08-23 20:03:23 --> Output Class Initialized
INFO - 2023-08-23 20:03:23 --> URI Class Initialized
INFO - 2023-08-23 20:03:23 --> Router Class Initialized
INFO - 2023-08-23 20:03:23 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:23 --> Config Class Initialized
INFO - 2023-08-23 20:03:23 --> Security Class Initialized
INFO - 2023-08-23 20:03:23 --> Security Class Initialized
INFO - 2023-08-23 20:03:23 --> Output Class Initialized
INFO - 2023-08-23 20:03:23 --> Security Class Initialized
INFO - 2023-08-23 20:03:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:23 --> Config Class Initialized
DEBUG - 2023-08-23 20:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:23 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:23 --> URI Class Initialized
INFO - 2023-08-23 20:03:23 --> Router Class Initialized
INFO - 2023-08-23 20:03:23 --> Output Class Initialized
INFO - 2023-08-23 20:03:23 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:23 --> Input Class Initialized
INFO - 2023-08-23 20:03:23 --> Language Class Initialized
ERROR - 2023-08-23 20:03:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:23 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:23 --> Input Class Initialized
INFO - 2023-08-23 20:03:23 --> Language Class Initialized
ERROR - 2023-08-23 20:03:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:23 --> URI Class Initialized
INFO - 2023-08-23 20:03:23 --> Input Class Initialized
INFO - 2023-08-23 20:03:23 --> Config Class Initialized
INFO - 2023-08-23 20:03:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:23 --> URI Class Initialized
INFO - 2023-08-23 20:03:23 --> Router Class Initialized
INFO - 2023-08-23 20:03:23 --> Output Class Initialized
INFO - 2023-08-23 20:03:23 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:23 --> Input Class Initialized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:24 --> Config Class Initialized
DEBUG - 2023-08-23 20:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:24 --> Config Class Initialized
INFO - 2023-08-23 20:03:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:24 --> URI Class Initialized
INFO - 2023-08-23 20:03:24 --> Router Class Initialized
INFO - 2023-08-23 20:03:24 --> Output Class Initialized
INFO - 2023-08-23 20:03:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:24 --> Input Class Initialized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
INFO - 2023-08-23 20:03:24 --> Router Class Initialized
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:03:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:24 --> Output Class Initialized
INFO - 2023-08-23 20:03:24 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:24 --> URI Class Initialized
INFO - 2023-08-23 20:03:24 --> Security Class Initialized
INFO - 2023-08-23 20:03:24 --> URI Class Initialized
DEBUG - 2023-08-23 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:24 --> Router Class Initialized
INFO - 2023-08-23 20:03:24 --> Router Class Initialized
INFO - 2023-08-23 20:03:24 --> Input Class Initialized
INFO - 2023-08-23 20:03:24 --> Output Class Initialized
INFO - 2023-08-23 20:03:24 --> Output Class Initialized
INFO - 2023-08-23 20:03:24 --> Security Class Initialized
INFO - 2023-08-23 20:03:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
INFO - 2023-08-23 20:03:24 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
INFO - 2023-08-23 20:03:24 --> Input Class Initialized
INFO - 2023-08-23 20:03:24 --> Language Class Initialized
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:03:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:52 --> Config Class Initialized
INFO - 2023-08-23 20:03:52 --> Config Class Initialized
INFO - 2023-08-23 20:03:52 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:52 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:52 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:03:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:52 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:52 --> URI Class Initialized
INFO - 2023-08-23 20:03:52 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:52 --> Router Class Initialized
INFO - 2023-08-23 20:03:52 --> URI Class Initialized
INFO - 2023-08-23 20:03:52 --> Output Class Initialized
INFO - 2023-08-23 20:03:52 --> Router Class Initialized
INFO - 2023-08-23 20:03:53 --> Security Class Initialized
INFO - 2023-08-23 20:03:53 --> Output Class Initialized
DEBUG - 2023-08-23 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:53 --> Security Class Initialized
INFO - 2023-08-23 20:03:53 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:53 --> Language Class Initialized
INFO - 2023-08-23 20:03:53 --> Input Class Initialized
INFO - 2023-08-23 20:03:53 --> Loader Class Initialized
INFO - 2023-08-23 20:03:53 --> Language Class Initialized
INFO - 2023-08-23 20:03:53 --> Loader Class Initialized
INFO - 2023-08-23 20:03:53 --> Helper loaded: url_helper
INFO - 2023-08-23 20:03:53 --> Helper loaded: url_helper
INFO - 2023-08-23 20:03:53 --> Helper loaded: file_helper
INFO - 2023-08-23 20:03:53 --> Helper loaded: file_helper
INFO - 2023-08-23 20:03:53 --> Database Driver Class Initialized
INFO - 2023-08-23 20:03:53 --> Database Driver Class Initialized
INFO - 2023-08-23 20:03:53 --> Email Class Initialized
INFO - 2023-08-23 20:03:53 --> Email Class Initialized
DEBUG - 2023-08-23 20:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-23 20:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:03:53 --> Controller Class Initialized
INFO - 2023-08-23 20:03:53 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:03:53 --> Model "Home_model" initialized
INFO - 2023-08-23 20:03:53 --> Controller Class Initialized
INFO - 2023-08-23 20:03:53 --> Helper loaded: download_helper
INFO - 2023-08-23 20:03:53 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:03:53 --> Model "Home_model" initialized
INFO - 2023-08-23 20:03:53 --> Helper loaded: form_helper
INFO - 2023-08-23 20:03:53 --> Helper loaded: download_helper
INFO - 2023-08-23 20:03:53 --> Form Validation Class Initialized
INFO - 2023-08-23 20:03:53 --> Helper loaded: form_helper
INFO - 2023-08-23 20:03:53 --> Form Validation Class Initialized
INFO - 2023-08-23 20:03:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:03:53 --> Final output sent to browser
ERROR - 2023-08-23 20:03:53 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `message`, `services_ids`, `status`, `created_at`) VALUES ('sfdfs', 'dddd@gmail.com', '7777777777', 'kgh', NULL, NULL, '2023-08-23 20:03:53')
DEBUG - 2023-08-23 20:03:54 --> Total execution time: 0.5855
INFO - 2023-08-23 20:03:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-23 20:03:55 --> Config Class Initialized
INFO - 2023-08-23 20:03:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:55 --> URI Class Initialized
INFO - 2023-08-23 20:03:55 --> Router Class Initialized
INFO - 2023-08-23 20:03:55 --> Output Class Initialized
INFO - 2023-08-23 20:03:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:55 --> Input Class Initialized
INFO - 2023-08-23 20:03:55 --> Language Class Initialized
ERROR - 2023-08-23 20:03:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:55 --> Config Class Initialized
INFO - 2023-08-23 20:03:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:55 --> URI Class Initialized
INFO - 2023-08-23 20:03:55 --> Router Class Initialized
INFO - 2023-08-23 20:03:55 --> Output Class Initialized
INFO - 2023-08-23 20:03:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:55 --> Input Class Initialized
INFO - 2023-08-23 20:03:55 --> Language Class Initialized
ERROR - 2023-08-23 20:03:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:55 --> Config Class Initialized
INFO - 2023-08-23 20:03:55 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:55 --> Config Class Initialized
INFO - 2023-08-23 20:03:55 --> Config Class Initialized
DEBUG - 2023-08-23 20:03:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:55 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
INFO - 2023-08-23 20:03:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
INFO - 2023-08-23 20:03:56 --> Security Class Initialized
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
DEBUG - 2023-08-23 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
INFO - 2023-08-23 20:03:56 --> Input Class Initialized
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
INFO - 2023-08-23 20:03:56 --> Language Class Initialized
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:56 --> Security Class Initialized
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:56 --> Security Class Initialized
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
ERROR - 2023-08-23 20:03:56 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
DEBUG - 2023-08-23 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:56 --> URI Class Initialized
INFO - 2023-08-23 20:03:56 --> Security Class Initialized
INFO - 2023-08-23 20:03:56 --> Input Class Initialized
INFO - 2023-08-23 20:03:56 --> Router Class Initialized
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
INFO - 2023-08-23 20:03:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:56 --> Input Class Initialized
INFO - 2023-08-23 20:03:56 --> Language Class Initialized
ERROR - 2023-08-23 20:03:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
INFO - 2023-08-23 20:03:56 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:56 --> Output Class Initialized
INFO - 2023-08-23 20:03:56 --> Language Class Initialized
INFO - 2023-08-23 20:03:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:56 --> Language Class Initialized
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
INFO - 2023-08-23 20:03:56 --> Input Class Initialized
ERROR - 2023-08-23 20:03:56 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:03:56 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:03:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:56 --> Language Class Initialized
INFO - 2023-08-23 20:03:56 --> Config Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:03:57 --> Security Class Initialized
INFO - 2023-08-23 20:03:57 --> URI Class Initialized
INFO - 2023-08-23 20:03:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:03:57 --> Config Class Initialized
INFO - 2023-08-23 20:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:57 --> URI Class Initialized
INFO - 2023-08-23 20:03:57 --> Router Class Initialized
INFO - 2023-08-23 20:03:57 --> Output Class Initialized
INFO - 2023-08-23 20:03:57 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:57 --> Input Class Initialized
INFO - 2023-08-23 20:03:57 --> Language Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:03:57 --> URI Class Initialized
INFO - 2023-08-23 20:03:57 --> Router Class Initialized
INFO - 2023-08-23 20:03:57 --> Output Class Initialized
INFO - 2023-08-23 20:03:57 --> Security Class Initialized
DEBUG - 2023-08-23 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:57 --> Input Class Initialized
INFO - 2023-08-23 20:03:57 --> Language Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:57 --> Router Class Initialized
INFO - 2023-08-23 20:03:57 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:03:57 --> Language Class Initialized
INFO - 2023-08-23 20:03:57 --> Output Class Initialized
INFO - 2023-08-23 20:03:57 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:57 --> URI Class Initialized
INFO - 2023-08-23 20:03:57 --> Security Class Initialized
INFO - 2023-08-23 20:03:57 --> Router Class Initialized
INFO - 2023-08-23 20:03:57 --> Output Class Initialized
DEBUG - 2023-08-23 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:57 --> Security Class Initialized
INFO - 2023-08-23 20:03:57 --> Input Class Initialized
DEBUG - 2023-08-23 20:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:03:57 --> Language Class Initialized
INFO - 2023-08-23 20:03:57 --> Input Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:03:57 --> Language Class Initialized
ERROR - 2023-08-23 20:03:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:26 --> Config Class Initialized
INFO - 2023-08-23 20:06:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:26 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:26 --> URI Class Initialized
INFO - 2023-08-23 20:06:26 --> Router Class Initialized
INFO - 2023-08-23 20:06:26 --> Output Class Initialized
INFO - 2023-08-23 20:06:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:26 --> Input Class Initialized
INFO - 2023-08-23 20:06:26 --> Language Class Initialized
INFO - 2023-08-23 20:06:26 --> Loader Class Initialized
INFO - 2023-08-23 20:06:26 --> Helper loaded: url_helper
INFO - 2023-08-23 20:06:26 --> Helper loaded: file_helper
INFO - 2023-08-23 20:06:26 --> Database Driver Class Initialized
INFO - 2023-08-23 20:06:26 --> Email Class Initialized
DEBUG - 2023-08-23 20:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:06:26 --> Controller Class Initialized
INFO - 2023-08-23 20:06:26 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:06:26 --> Model "Home_model" initialized
INFO - 2023-08-23 20:06:26 --> Helper loaded: download_helper
INFO - 2023-08-23 20:06:26 --> Helper loaded: form_helper
INFO - 2023-08-23 20:06:26 --> Form Validation Class Initialized
INFO - 2023-08-23 20:06:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:06:27 --> Final output sent to browser
DEBUG - 2023-08-23 20:06:27 --> Total execution time: 0.7094
INFO - 2023-08-23 20:06:28 --> Config Class Initialized
INFO - 2023-08-23 20:06:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:28 --> Config Class Initialized
INFO - 2023-08-23 20:06:28 --> URI Class Initialized
INFO - 2023-08-23 20:06:28 --> Router Class Initialized
INFO - 2023-08-23 20:06:28 --> Hooks Class Initialized
INFO - 2023-08-23 20:06:28 --> Output Class Initialized
INFO - 2023-08-23 20:06:29 --> Config Class Initialized
INFO - 2023-08-23 20:06:29 --> Config Class Initialized
INFO - 2023-08-23 20:06:29 --> Security Class Initialized
INFO - 2023-08-23 20:06:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:06:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:30 --> URI Class Initialized
INFO - 2023-08-23 20:06:30 --> Input Class Initialized
INFO - 2023-08-23 20:06:30 --> Language Class Initialized
INFO - 2023-08-23 20:06:30 --> URI Class Initialized
DEBUG - 2023-08-23 20:06:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:30 --> Router Class Initialized
INFO - 2023-08-23 20:06:30 --> URI Class Initialized
ERROR - 2023-08-23 20:06:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:30 --> Router Class Initialized
INFO - 2023-08-23 20:06:30 --> Output Class Initialized
INFO - 2023-08-23 20:06:30 --> Router Class Initialized
INFO - 2023-08-23 20:06:30 --> Output Class Initialized
INFO - 2023-08-23 20:06:30 --> Security Class Initialized
INFO - 2023-08-23 20:06:30 --> Security Class Initialized
INFO - 2023-08-23 20:06:30 --> Output Class Initialized
DEBUG - 2023-08-23 20:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:30 --> Input Class Initialized
INFO - 2023-08-23 20:06:30 --> Input Class Initialized
INFO - 2023-08-23 20:06:30 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:30 --> Language Class Initialized
INFO - 2023-08-23 20:06:30 --> Input Class Initialized
INFO - 2023-08-23 20:06:30 --> Language Class Initialized
INFO - 2023-08-23 20:06:30 --> Language Class Initialized
ERROR - 2023-08-23 20:06:30 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:06:30 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:06:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:31 --> Config Class Initialized
INFO - 2023-08-23 20:06:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:31 --> URI Class Initialized
INFO - 2023-08-23 20:06:31 --> Router Class Initialized
INFO - 2023-08-23 20:06:31 --> Output Class Initialized
INFO - 2023-08-23 20:06:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:31 --> Input Class Initialized
INFO - 2023-08-23 20:06:31 --> Language Class Initialized
ERROR - 2023-08-23 20:06:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:31 --> Config Class Initialized
INFO - 2023-08-23 20:06:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:31 --> URI Class Initialized
INFO - 2023-08-23 20:06:31 --> Router Class Initialized
INFO - 2023-08-23 20:06:31 --> Output Class Initialized
INFO - 2023-08-23 20:06:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:32 --> Input Class Initialized
INFO - 2023-08-23 20:06:32 --> Language Class Initialized
ERROR - 2023-08-23 20:06:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:32 --> Config Class Initialized
INFO - 2023-08-23 20:06:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:32 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:32 --> URI Class Initialized
INFO - 2023-08-23 20:06:32 --> Router Class Initialized
INFO - 2023-08-23 20:06:32 --> Output Class Initialized
INFO - 2023-08-23 20:06:32 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:32 --> Input Class Initialized
INFO - 2023-08-23 20:06:32 --> Language Class Initialized
ERROR - 2023-08-23 20:06:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:32 --> Config Class Initialized
INFO - 2023-08-23 20:06:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:32 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:32 --> URI Class Initialized
INFO - 2023-08-23 20:06:32 --> Router Class Initialized
INFO - 2023-08-23 20:06:32 --> Output Class Initialized
INFO - 2023-08-23 20:06:32 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:32 --> Input Class Initialized
INFO - 2023-08-23 20:06:32 --> Language Class Initialized
ERROR - 2023-08-23 20:06:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:32 --> Config Class Initialized
INFO - 2023-08-23 20:06:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:32 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:32 --> URI Class Initialized
INFO - 2023-08-23 20:06:32 --> Router Class Initialized
INFO - 2023-08-23 20:06:32 --> Output Class Initialized
INFO - 2023-08-23 20:06:32 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:32 --> Input Class Initialized
INFO - 2023-08-23 20:06:32 --> Language Class Initialized
ERROR - 2023-08-23 20:06:32 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:33 --> Config Class Initialized
INFO - 2023-08-23 20:06:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:33 --> URI Class Initialized
INFO - 2023-08-23 20:06:33 --> Router Class Initialized
INFO - 2023-08-23 20:06:33 --> Output Class Initialized
INFO - 2023-08-23 20:06:33 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:33 --> Input Class Initialized
INFO - 2023-08-23 20:06:33 --> Language Class Initialized
ERROR - 2023-08-23 20:06:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:33 --> Config Class Initialized
INFO - 2023-08-23 20:06:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:33 --> URI Class Initialized
INFO - 2023-08-23 20:06:33 --> Router Class Initialized
INFO - 2023-08-23 20:06:33 --> Output Class Initialized
INFO - 2023-08-23 20:06:33 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:33 --> Input Class Initialized
INFO - 2023-08-23 20:06:33 --> Language Class Initialized
ERROR - 2023-08-23 20:06:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:34 --> Config Class Initialized
INFO - 2023-08-23 20:06:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:34 --> URI Class Initialized
INFO - 2023-08-23 20:06:34 --> Router Class Initialized
INFO - 2023-08-23 20:06:34 --> Output Class Initialized
INFO - 2023-08-23 20:06:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:34 --> Input Class Initialized
INFO - 2023-08-23 20:06:34 --> Language Class Initialized
ERROR - 2023-08-23 20:06:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:06:34 --> Config Class Initialized
INFO - 2023-08-23 20:06:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:34 --> URI Class Initialized
INFO - 2023-08-23 20:06:34 --> Router Class Initialized
INFO - 2023-08-23 20:06:34 --> Output Class Initialized
INFO - 2023-08-23 20:06:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:34 --> Input Class Initialized
INFO - 2023-08-23 20:06:34 --> Language Class Initialized
ERROR - 2023-08-23 20:06:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:34 --> Config Class Initialized
INFO - 2023-08-23 20:06:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:34 --> URI Class Initialized
INFO - 2023-08-23 20:06:35 --> Router Class Initialized
INFO - 2023-08-23 20:06:35 --> Output Class Initialized
INFO - 2023-08-23 20:06:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:35 --> Input Class Initialized
INFO - 2023-08-23 20:06:35 --> Language Class Initialized
ERROR - 2023-08-23 20:06:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:35 --> Config Class Initialized
INFO - 2023-08-23 20:06:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:35 --> URI Class Initialized
INFO - 2023-08-23 20:06:35 --> Router Class Initialized
INFO - 2023-08-23 20:06:35 --> Output Class Initialized
INFO - 2023-08-23 20:06:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:35 --> Input Class Initialized
INFO - 2023-08-23 20:06:35 --> Language Class Initialized
ERROR - 2023-08-23 20:06:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:06:56 --> Config Class Initialized
INFO - 2023-08-23 20:06:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:06:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:06:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:06:56 --> URI Class Initialized
INFO - 2023-08-23 20:06:56 --> Router Class Initialized
INFO - 2023-08-23 20:06:56 --> Output Class Initialized
INFO - 2023-08-23 20:06:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:06:56 --> Input Class Initialized
INFO - 2023-08-23 20:06:56 --> Language Class Initialized
INFO - 2023-08-23 20:06:56 --> Loader Class Initialized
INFO - 2023-08-23 20:06:56 --> Helper loaded: url_helper
INFO - 2023-08-23 20:06:56 --> Helper loaded: file_helper
INFO - 2023-08-23 20:06:56 --> Database Driver Class Initialized
INFO - 2023-08-23 20:06:56 --> Email Class Initialized
DEBUG - 2023-08-23 20:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:06:56 --> Controller Class Initialized
INFO - 2023-08-23 20:06:56 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:06:56 --> Model "Home_model" initialized
INFO - 2023-08-23 20:06:56 --> Helper loaded: download_helper
INFO - 2023-08-23 20:06:56 --> Helper loaded: form_helper
INFO - 2023-08-23 20:06:56 --> Form Validation Class Initialized
INFO - 2023-08-23 20:06:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:06:56 --> Final output sent to browser
DEBUG - 2023-08-23 20:06:56 --> Total execution time: 0.4306
INFO - 2023-08-23 20:07:17 --> Config Class Initialized
INFO - 2023-08-23 20:07:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:18 --> URI Class Initialized
INFO - 2023-08-23 20:07:18 --> Router Class Initialized
INFO - 2023-08-23 20:07:18 --> Output Class Initialized
INFO - 2023-08-23 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:18 --> Input Class Initialized
INFO - 2023-08-23 20:07:18 --> Language Class Initialized
INFO - 2023-08-23 20:07:18 --> Loader Class Initialized
INFO - 2023-08-23 20:07:18 --> Helper loaded: url_helper
INFO - 2023-08-23 20:07:18 --> Helper loaded: file_helper
INFO - 2023-08-23 20:07:18 --> Database Driver Class Initialized
INFO - 2023-08-23 20:07:18 --> Email Class Initialized
DEBUG - 2023-08-23 20:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:07:18 --> Controller Class Initialized
INFO - 2023-08-23 20:07:18 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:07:18 --> Model "Home_model" initialized
INFO - 2023-08-23 20:07:18 --> Helper loaded: download_helper
INFO - 2023-08-23 20:07:18 --> Helper loaded: form_helper
INFO - 2023-08-23 20:07:18 --> Form Validation Class Initialized
INFO - 2023-08-23 20:07:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:07:18 --> Final output sent to browser
DEBUG - 2023-08-23 20:07:18 --> Total execution time: 0.5966
INFO - 2023-08-23 20:07:18 --> Config Class Initialized
INFO - 2023-08-23 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:18 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:18 --> URI Class Initialized
INFO - 2023-08-23 20:07:18 --> Router Class Initialized
INFO - 2023-08-23 20:07:18 --> Output Class Initialized
INFO - 2023-08-23 20:07:18 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:18 --> Input Class Initialized
INFO - 2023-08-23 20:07:18 --> Language Class Initialized
ERROR - 2023-08-23 20:07:18 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:19 --> Config Class Initialized
INFO - 2023-08-23 20:07:19 --> Config Class Initialized
INFO - 2023-08-23 20:07:19 --> Config Class Initialized
INFO - 2023-08-23 20:07:19 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:19 --> Config Class Initialized
INFO - 2023-08-23 20:07:19 --> Config Class Initialized
DEBUG - 2023-08-23 20:07:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:19 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:19 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:19 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:07:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:19 --> URI Class Initialized
INFO - 2023-08-23 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:20 --> URI Class Initialized
DEBUG - 2023-08-23 20:07:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:20 --> Router Class Initialized
INFO - 2023-08-23 20:07:20 --> Router Class Initialized
INFO - 2023-08-23 20:07:20 --> URI Class Initialized
INFO - 2023-08-23 20:07:20 --> Output Class Initialized
INFO - 2023-08-23 20:07:20 --> Router Class Initialized
INFO - 2023-08-23 20:07:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:20 --> Output Class Initialized
INFO - 2023-08-23 20:07:20 --> URI Class Initialized
INFO - 2023-08-23 20:07:20 --> Output Class Initialized
INFO - 2023-08-23 20:07:20 --> Security Class Initialized
INFO - 2023-08-23 20:07:20 --> URI Class Initialized
INFO - 2023-08-23 20:07:20 --> Security Class Initialized
INFO - 2023-08-23 20:07:20 --> Router Class Initialized
INFO - 2023-08-23 20:07:20 --> Router Class Initialized
DEBUG - 2023-08-23 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:20 --> Output Class Initialized
INFO - 2023-08-23 20:07:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:20 --> Output Class Initialized
INFO - 2023-08-23 20:07:20 --> Security Class Initialized
INFO - 2023-08-23 20:07:20 --> Input Class Initialized
INFO - 2023-08-23 20:07:20 --> Input Class Initialized
DEBUG - 2023-08-23 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:20 --> Security Class Initialized
INFO - 2023-08-23 20:07:20 --> Input Class Initialized
INFO - 2023-08-23 20:07:20 --> Language Class Initialized
INFO - 2023-08-23 20:07:20 --> Input Class Initialized
INFO - 2023-08-23 20:07:20 --> Language Class Initialized
DEBUG - 2023-08-23 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:20 --> Language Class Initialized
ERROR - 2023-08-23 20:07:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:20 --> Language Class Initialized
ERROR - 2023-08-23 20:07:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:20 --> Input Class Initialized
ERROR - 2023-08-23 20:07:20 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:07:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:20 --> Language Class Initialized
ERROR - 2023-08-23 20:07:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:23 --> Config Class Initialized
INFO - 2023-08-23 20:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:23 --> URI Class Initialized
INFO - 2023-08-23 20:07:23 --> Config Class Initialized
INFO - 2023-08-23 20:07:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:23 --> URI Class Initialized
INFO - 2023-08-23 20:07:23 --> Router Class Initialized
INFO - 2023-08-23 20:07:23 --> Output Class Initialized
INFO - 2023-08-23 20:07:23 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:23 --> Input Class Initialized
INFO - 2023-08-23 20:07:23 --> Language Class Initialized
ERROR - 2023-08-23 20:07:23 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:23 --> Config Class Initialized
INFO - 2023-08-23 20:07:24 --> Config Class Initialized
INFO - 2023-08-23 20:07:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:24 --> URI Class Initialized
INFO - 2023-08-23 20:07:24 --> Router Class Initialized
INFO - 2023-08-23 20:07:24 --> Output Class Initialized
INFO - 2023-08-23 20:07:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:24 --> Input Class Initialized
INFO - 2023-08-23 20:07:24 --> Language Class Initialized
ERROR - 2023-08-23 20:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:24 --> Config Class Initialized
INFO - 2023-08-23 20:07:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:24 --> Config Class Initialized
DEBUG - 2023-08-23 20:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:24 --> Config Class Initialized
INFO - 2023-08-23 20:07:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:24 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:07:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:24 --> URI Class Initialized
INFO - 2023-08-23 20:07:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:24 --> Router Class Initialized
INFO - 2023-08-23 20:07:24 --> URI Class Initialized
INFO - 2023-08-23 20:07:24 --> Router Class Initialized
INFO - 2023-08-23 20:07:24 --> URI Class Initialized
INFO - 2023-08-23 20:07:24 --> Router Class Initialized
INFO - 2023-08-23 20:07:24 --> URI Class Initialized
INFO - 2023-08-23 20:07:24 --> Output Class Initialized
INFO - 2023-08-23 20:07:24 --> Output Class Initialized
INFO - 2023-08-23 20:07:24 --> Router Class Initialized
INFO - 2023-08-23 20:07:24 --> Output Class Initialized
INFO - 2023-08-23 20:07:24 --> Output Class Initialized
INFO - 2023-08-23 20:07:24 --> Security Class Initialized
INFO - 2023-08-23 20:07:24 --> Security Class Initialized
INFO - 2023-08-23 20:07:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:24 --> Input Class Initialized
INFO - 2023-08-23 20:07:24 --> Input Class Initialized
INFO - 2023-08-23 20:07:24 --> Language Class Initialized
DEBUG - 2023-08-23 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:24 --> Language Class Initialized
ERROR - 2023-08-23 20:07:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:24 --> Input Class Initialized
ERROR - 2023-08-23 20:07:25 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:25 --> Language Class Initialized
INFO - 2023-08-23 20:07:25 --> Input Class Initialized
INFO - 2023-08-23 20:07:25 --> Language Class Initialized
ERROR - 2023-08-23 20:07:25 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:07:25 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:07:50 --> Config Class Initialized
INFO - 2023-08-23 20:07:50 --> Config Class Initialized
INFO - 2023-08-23 20:07:50 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:50 --> Config Class Initialized
INFO - 2023-08-23 20:07:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:50 --> URI Class Initialized
INFO - 2023-08-23 20:07:50 --> Router Class Initialized
INFO - 2023-08-23 20:07:50 --> Output Class Initialized
INFO - 2023-08-23 20:07:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:50 --> Input Class Initialized
INFO - 2023-08-23 20:07:50 --> Language Class Initialized
ERROR - 2023-08-23 20:07:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:07:50 --> Config Class Initialized
INFO - 2023-08-23 20:07:50 --> Config Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:51 --> Config Class Initialized
INFO - 2023-08-23 20:07:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:51 --> Input Class Initialized
INFO - 2023-08-23 20:07:51 --> Language Class Initialized
ERROR - 2023-08-23 20:07:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:07:51 --> Config Class Initialized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
INFO - 2023-08-23 20:07:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
DEBUG - 2023-08-23 20:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
INFO - 2023-08-23 20:07:51 --> Input Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
DEBUG - 2023-08-23 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:51 --> URI Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
INFO - 2023-08-23 20:07:51 --> Language Class Initialized
INFO - 2023-08-23 20:07:51 --> Router Class Initialized
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
INFO - 2023-08-23 20:07:51 --> Input Class Initialized
DEBUG - 2023-08-23 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
INFO - 2023-08-23 20:07:51 --> Output Class Initialized
ERROR - 2023-08-23 20:07:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
INFO - 2023-08-23 20:07:51 --> Input Class Initialized
INFO - 2023-08-23 20:07:51 --> Language Class Initialized
INFO - 2023-08-23 20:07:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:51 --> Language Class Initialized
ERROR - 2023-08-23 20:07:52 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:07:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:52 --> Input Class Initialized
INFO - 2023-08-23 20:07:52 --> Input Class Initialized
INFO - 2023-08-23 20:07:52 --> Language Class Initialized
INFO - 2023-08-23 20:07:52 --> Language Class Initialized
ERROR - 2023-08-23 20:07:52 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:07:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:07:55 --> Config Class Initialized
INFO - 2023-08-23 20:07:55 --> Config Class Initialized
INFO - 2023-08-23 20:07:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:07:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:55 --> Hooks Class Initialized
INFO - 2023-08-23 20:07:55 --> URI Class Initialized
INFO - 2023-08-23 20:07:55 --> Router Class Initialized
DEBUG - 2023-08-23 20:07:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:07:55 --> Output Class Initialized
INFO - 2023-08-23 20:07:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:07:55 --> Security Class Initialized
INFO - 2023-08-23 20:07:55 --> URI Class Initialized
DEBUG - 2023-08-23 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:55 --> Input Class Initialized
INFO - 2023-08-23 20:07:55 --> Router Class Initialized
INFO - 2023-08-23 20:07:55 --> Language Class Initialized
INFO - 2023-08-23 20:07:55 --> Output Class Initialized
INFO - 2023-08-23 20:07:55 --> Loader Class Initialized
INFO - 2023-08-23 20:07:55 --> Security Class Initialized
INFO - 2023-08-23 20:07:55 --> Helper loaded: url_helper
INFO - 2023-08-23 20:07:55 --> Helper loaded: file_helper
DEBUG - 2023-08-23 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:07:55 --> Database Driver Class Initialized
INFO - 2023-08-23 20:07:55 --> Email Class Initialized
INFO - 2023-08-23 20:07:55 --> Input Class Initialized
DEBUG - 2023-08-23 20:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:07:55 --> Language Class Initialized
INFO - 2023-08-23 20:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:07:55 --> Loader Class Initialized
INFO - 2023-08-23 20:07:55 --> Controller Class Initialized
INFO - 2023-08-23 20:07:55 --> Helper loaded: url_helper
INFO - 2023-08-23 20:07:55 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:07:55 --> Helper loaded: file_helper
INFO - 2023-08-23 20:07:55 --> Database Driver Class Initialized
INFO - 2023-08-23 20:07:55 --> Model "Home_model" initialized
INFO - 2023-08-23 20:07:55 --> Email Class Initialized
INFO - 2023-08-23 20:07:55 --> Helper loaded: download_helper
DEBUG - 2023-08-23 20:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:07:56 --> Helper loaded: form_helper
INFO - 2023-08-23 20:07:56 --> Form Validation Class Initialized
INFO - 2023-08-23 20:07:56 --> Final output sent to browser
DEBUG - 2023-08-23 20:07:56 --> Total execution time: 0.7902
INFO - 2023-08-23 20:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:07:56 --> Controller Class Initialized
INFO - 2023-08-23 20:07:56 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:07:56 --> Model "Home_model" initialized
INFO - 2023-08-23 20:07:56 --> Helper loaded: download_helper
INFO - 2023-08-23 20:07:56 --> Helper loaded: form_helper
INFO - 2023-08-23 20:07:56 --> Form Validation Class Initialized
INFO - 2023-08-23 20:07:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:07:56 --> Final output sent to browser
DEBUG - 2023-08-23 20:07:56 --> Total execution time: 1.1690
INFO - 2023-08-23 20:08:35 --> Config Class Initialized
INFO - 2023-08-23 20:08:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:35 --> URI Class Initialized
INFO - 2023-08-23 20:08:35 --> Router Class Initialized
INFO - 2023-08-23 20:08:35 --> Output Class Initialized
INFO - 2023-08-23 20:08:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:35 --> Input Class Initialized
INFO - 2023-08-23 20:08:35 --> Language Class Initialized
ERROR - 2023-08-23 20:08:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:35 --> Config Class Initialized
INFO - 2023-08-23 20:08:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:35 --> URI Class Initialized
INFO - 2023-08-23 20:08:35 --> Router Class Initialized
INFO - 2023-08-23 20:08:35 --> Output Class Initialized
INFO - 2023-08-23 20:08:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:35 --> Input Class Initialized
INFO - 2023-08-23 20:08:35 --> Language Class Initialized
ERROR - 2023-08-23 20:08:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:35 --> Config Class Initialized
INFO - 2023-08-23 20:08:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:35 --> URI Class Initialized
INFO - 2023-08-23 20:08:35 --> Router Class Initialized
INFO - 2023-08-23 20:08:35 --> Output Class Initialized
INFO - 2023-08-23 20:08:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:35 --> Input Class Initialized
INFO - 2023-08-23 20:08:35 --> Language Class Initialized
ERROR - 2023-08-23 20:08:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:36 --> URI Class Initialized
INFO - 2023-08-23 20:08:36 --> Router Class Initialized
INFO - 2023-08-23 20:08:36 --> Output Class Initialized
INFO - 2023-08-23 20:08:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:36 --> Input Class Initialized
INFO - 2023-08-23 20:08:36 --> Language Class Initialized
ERROR - 2023-08-23 20:08:36 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:36 --> URI Class Initialized
INFO - 2023-08-23 20:08:36 --> Router Class Initialized
INFO - 2023-08-23 20:08:36 --> Output Class Initialized
INFO - 2023-08-23 20:08:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:36 --> Input Class Initialized
INFO - 2023-08-23 20:08:36 --> Language Class Initialized
ERROR - 2023-08-23 20:08:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:36 --> Hooks Class Initialized
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:08:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:36 --> URI Class Initialized
INFO - 2023-08-23 20:08:36 --> URI Class Initialized
INFO - 2023-08-23 20:08:36 --> Router Class Initialized
INFO - 2023-08-23 20:08:36 --> Router Class Initialized
INFO - 2023-08-23 20:08:36 --> Output Class Initialized
INFO - 2023-08-23 20:08:36 --> Output Class Initialized
INFO - 2023-08-23 20:08:36 --> Security Class Initialized
INFO - 2023-08-23 20:08:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:36 --> Input Class Initialized
INFO - 2023-08-23 20:08:36 --> Input Class Initialized
INFO - 2023-08-23 20:08:36 --> Language Class Initialized
INFO - 2023-08-23 20:08:36 --> Language Class Initialized
ERROR - 2023-08-23 20:08:36 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:08:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:36 --> Config Class Initialized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
INFO - 2023-08-23 20:08:37 --> Config Class Initialized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Config Class Initialized
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:37 --> Output Class Initialized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
INFO - 2023-08-23 20:08:37 --> Config Class Initialized
INFO - 2023-08-23 20:08:37 --> Security Class Initialized
INFO - 2023-08-23 20:08:37 --> Output Class Initialized
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:37 --> Output Class Initialized
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Input Class Initialized
INFO - 2023-08-23 20:08:37 --> Security Class Initialized
INFO - 2023-08-23 20:08:37 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:37 --> Language Class Initialized
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:08:37 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Input Class Initialized
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:37 --> Input Class Initialized
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:37 --> Language Class Initialized
ERROR - 2023-08-23 20:08:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:37 --> Language Class Initialized
ERROR - 2023-08-23 20:08:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:37 --> Output Class Initialized
INFO - 2023-08-23 20:08:37 --> Output Class Initialized
INFO - 2023-08-23 20:08:37 --> Security Class Initialized
INFO - 2023-08-23 20:08:37 --> Config Class Initialized
INFO - 2023-08-23 20:08:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:08:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:37 --> Security Class Initialized
INFO - 2023-08-23 20:08:37 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:37 --> Input Class Initialized
INFO - 2023-08-23 20:08:37 --> Input Class Initialized
INFO - 2023-08-23 20:08:37 --> URI Class Initialized
INFO - 2023-08-23 20:08:37 --> Language Class Initialized
INFO - 2023-08-23 20:08:37 --> Language Class Initialized
ERROR - 2023-08-23 20:08:37 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:08:37 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:37 --> Router Class Initialized
INFO - 2023-08-23 20:08:38 --> Output Class Initialized
INFO - 2023-08-23 20:08:38 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:38 --> Input Class Initialized
INFO - 2023-08-23 20:08:38 --> Language Class Initialized
ERROR - 2023-08-23 20:08:38 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:41 --> Config Class Initialized
INFO - 2023-08-23 20:08:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:41 --> URI Class Initialized
INFO - 2023-08-23 20:08:41 --> Router Class Initialized
INFO - 2023-08-23 20:08:41 --> Output Class Initialized
INFO - 2023-08-23 20:08:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:42 --> Input Class Initialized
INFO - 2023-08-23 20:08:42 --> Language Class Initialized
INFO - 2023-08-23 20:08:42 --> Loader Class Initialized
INFO - 2023-08-23 20:08:42 --> Helper loaded: url_helper
INFO - 2023-08-23 20:08:42 --> Helper loaded: file_helper
INFO - 2023-08-23 20:08:42 --> Database Driver Class Initialized
INFO - 2023-08-23 20:08:42 --> Email Class Initialized
DEBUG - 2023-08-23 20:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:08:42 --> Controller Class Initialized
INFO - 2023-08-23 20:08:42 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:08:42 --> Model "Home_model" initialized
INFO - 2023-08-23 20:08:42 --> Helper loaded: download_helper
INFO - 2023-08-23 20:08:42 --> Helper loaded: form_helper
INFO - 2023-08-23 20:08:42 --> Form Validation Class Initialized
INFO - 2023-08-23 20:08:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:08:42 --> Final output sent to browser
DEBUG - 2023-08-23 20:08:42 --> Total execution time: 0.5896
INFO - 2023-08-23 20:08:42 --> Config Class Initialized
INFO - 2023-08-23 20:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:42 --> URI Class Initialized
INFO - 2023-08-23 20:08:42 --> Router Class Initialized
INFO - 2023-08-23 20:08:42 --> Output Class Initialized
INFO - 2023-08-23 20:08:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:42 --> Input Class Initialized
INFO - 2023-08-23 20:08:42 --> Language Class Initialized
ERROR - 2023-08-23 20:08:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:42 --> Config Class Initialized
INFO - 2023-08-23 20:08:42 --> Config Class Initialized
INFO - 2023-08-23 20:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:42 --> URI Class Initialized
INFO - 2023-08-23 20:08:42 --> Router Class Initialized
INFO - 2023-08-23 20:08:42 --> Output Class Initialized
INFO - 2023-08-23 20:08:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:42 --> Input Class Initialized
INFO - 2023-08-23 20:08:42 --> Language Class Initialized
ERROR - 2023-08-23 20:08:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:43 --> URI Class Initialized
INFO - 2023-08-23 20:08:43 --> Router Class Initialized
INFO - 2023-08-23 20:08:43 --> Output Class Initialized
INFO - 2023-08-23 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:43 --> Input Class Initialized
INFO - 2023-08-23 20:08:43 --> Language Class Initialized
ERROR - 2023-08-23 20:08:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:43 --> Config Class Initialized
INFO - 2023-08-23 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:43 --> URI Class Initialized
INFO - 2023-08-23 20:08:43 --> Router Class Initialized
INFO - 2023-08-23 20:08:43 --> Output Class Initialized
INFO - 2023-08-23 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:43 --> Input Class Initialized
INFO - 2023-08-23 20:08:43 --> Language Class Initialized
ERROR - 2023-08-23 20:08:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:43 --> Config Class Initialized
INFO - 2023-08-23 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:43 --> URI Class Initialized
INFO - 2023-08-23 20:08:43 --> Router Class Initialized
INFO - 2023-08-23 20:08:43 --> Output Class Initialized
INFO - 2023-08-23 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:43 --> Input Class Initialized
INFO - 2023-08-23 20:08:43 --> Language Class Initialized
ERROR - 2023-08-23 20:08:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:08:43 --> Config Class Initialized
INFO - 2023-08-23 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:43 --> URI Class Initialized
INFO - 2023-08-23 20:08:43 --> Router Class Initialized
INFO - 2023-08-23 20:08:43 --> Output Class Initialized
INFO - 2023-08-23 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:43 --> Input Class Initialized
INFO - 2023-08-23 20:08:43 --> Language Class Initialized
ERROR - 2023-08-23 20:08:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:43 --> Config Class Initialized
INFO - 2023-08-23 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:43 --> URI Class Initialized
INFO - 2023-08-23 20:08:43 --> Router Class Initialized
INFO - 2023-08-23 20:08:43 --> Output Class Initialized
INFO - 2023-08-23 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:43 --> Input Class Initialized
INFO - 2023-08-23 20:08:43 --> Language Class Initialized
ERROR - 2023-08-23 20:08:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:08:44 --> Config Class Initialized
INFO - 2023-08-23 20:08:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:08:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:08:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:08:44 --> URI Class Initialized
INFO - 2023-08-23 20:08:44 --> Router Class Initialized
INFO - 2023-08-23 20:08:44 --> Output Class Initialized
INFO - 2023-08-23 20:08:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:08:44 --> Input Class Initialized
INFO - 2023-08-23 20:08:44 --> Language Class Initialized
ERROR - 2023-08-23 20:08:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:08 --> Config Class Initialized
INFO - 2023-08-23 20:09:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:08 --> URI Class Initialized
INFO - 2023-08-23 20:09:08 --> Router Class Initialized
INFO - 2023-08-23 20:09:08 --> Output Class Initialized
INFO - 2023-08-23 20:09:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:08 --> Input Class Initialized
INFO - 2023-08-23 20:09:08 --> Language Class Initialized
INFO - 2023-08-23 20:09:08 --> Loader Class Initialized
INFO - 2023-08-23 20:09:08 --> Helper loaded: url_helper
INFO - 2023-08-23 20:09:08 --> Helper loaded: file_helper
INFO - 2023-08-23 20:09:08 --> Database Driver Class Initialized
INFO - 2023-08-23 20:09:08 --> Email Class Initialized
DEBUG - 2023-08-23 20:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:09:08 --> Controller Class Initialized
INFO - 2023-08-23 20:09:08 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:09:08 --> Model "Home_model" initialized
INFO - 2023-08-23 20:09:08 --> Helper loaded: download_helper
INFO - 2023-08-23 20:09:08 --> Helper loaded: form_helper
INFO - 2023-08-23 20:09:08 --> Form Validation Class Initialized
INFO - 2023-08-23 20:09:08 --> Config Class Initialized
INFO - 2023-08-23 20:09:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:08 --> URI Class Initialized
INFO - 2023-08-23 20:09:08 --> Router Class Initialized
INFO - 2023-08-23 20:09:08 --> Output Class Initialized
INFO - 2023-08-23 20:09:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:08 --> Input Class Initialized
INFO - 2023-08-23 20:09:08 --> Language Class Initialized
INFO - 2023-08-23 20:09:08 --> Loader Class Initialized
INFO - 2023-08-23 20:09:08 --> Helper loaded: url_helper
INFO - 2023-08-23 20:09:08 --> Helper loaded: file_helper
INFO - 2023-08-23 20:09:08 --> Database Driver Class Initialized
INFO - 2023-08-23 20:09:08 --> Email Class Initialized
DEBUG - 2023-08-23 20:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:09:08 --> Controller Class Initialized
INFO - 2023-08-23 20:09:08 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:09:08 --> Model "Home_model" initialized
INFO - 2023-08-23 20:09:08 --> Helper loaded: download_helper
INFO - 2023-08-23 20:09:08 --> Helper loaded: form_helper
INFO - 2023-08-23 20:09:08 --> Form Validation Class Initialized
INFO - 2023-08-23 20:09:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:09:08 --> Final output sent to browser
DEBUG - 2023-08-23 20:09:08 --> Total execution time: 0.0602
INFO - 2023-08-23 20:09:27 --> Config Class Initialized
INFO - 2023-08-23 20:09:27 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:27 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:27 --> URI Class Initialized
INFO - 2023-08-23 20:09:27 --> Router Class Initialized
INFO - 2023-08-23 20:09:27 --> Output Class Initialized
INFO - 2023-08-23 20:09:27 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:27 --> Input Class Initialized
INFO - 2023-08-23 20:09:27 --> Language Class Initialized
INFO - 2023-08-23 20:09:27 --> Loader Class Initialized
INFO - 2023-08-23 20:09:27 --> Helper loaded: url_helper
INFO - 2023-08-23 20:09:27 --> Helper loaded: file_helper
INFO - 2023-08-23 20:09:27 --> Database Driver Class Initialized
INFO - 2023-08-23 20:09:27 --> Email Class Initialized
DEBUG - 2023-08-23 20:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:09:27 --> Controller Class Initialized
INFO - 2023-08-23 20:09:27 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:09:27 --> Model "Home_model" initialized
INFO - 2023-08-23 20:09:27 --> Helper loaded: download_helper
INFO - 2023-08-23 20:09:27 --> Helper loaded: form_helper
INFO - 2023-08-23 20:09:27 --> Form Validation Class Initialized
INFO - 2023-08-23 20:09:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:09:28 --> Final output sent to browser
DEBUG - 2023-08-23 20:09:28 --> Total execution time: 0.5178
INFO - 2023-08-23 20:09:28 --> Config Class Initialized
INFO - 2023-08-23 20:09:29 --> Config Class Initialized
INFO - 2023-08-23 20:09:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:29 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:29 --> URI Class Initialized
INFO - 2023-08-23 20:09:29 --> Router Class Initialized
INFO - 2023-08-23 20:09:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:29 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:29 --> Output Class Initialized
INFO - 2023-08-23 20:09:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:29 --> URI Class Initialized
INFO - 2023-08-23 20:09:29 --> Config Class Initialized
INFO - 2023-08-23 20:09:29 --> Config Class Initialized
INFO - 2023-08-23 20:09:29 --> Router Class Initialized
INFO - 2023-08-23 20:09:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:29 --> Security Class Initialized
INFO - 2023-08-23 20:09:29 --> URI Class Initialized
INFO - 2023-08-23 20:09:29 --> Output Class Initialized
INFO - 2023-08-23 20:09:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:29 --> Router Class Initialized
DEBUG - 2023-08-23 20:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:29 --> Security Class Initialized
INFO - 2023-08-23 20:09:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:29 --> Output Class Initialized
INFO - 2023-08-23 20:09:29 --> URI Class Initialized
INFO - 2023-08-23 20:09:29 --> Input Class Initialized
INFO - 2023-08-23 20:09:29 --> Language Class Initialized
DEBUG - 2023-08-23 20:09:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:29 --> Security Class Initialized
INFO - 2023-08-23 20:09:29 --> Router Class Initialized
INFO - 2023-08-23 20:09:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:30 --> Output Class Initialized
INFO - 2023-08-23 20:09:30 --> URI Class Initialized
DEBUG - 2023-08-23 20:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:09:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:30 --> Router Class Initialized
INFO - 2023-08-23 20:09:30 --> Input Class Initialized
INFO - 2023-08-23 20:09:30 --> Language Class Initialized
ERROR - 2023-08-23 20:09:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:30 --> Security Class Initialized
INFO - 2023-08-23 20:09:30 --> Input Class Initialized
DEBUG - 2023-08-23 20:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:30 --> Language Class Initialized
INFO - 2023-08-23 20:09:30 --> Output Class Initialized
ERROR - 2023-08-23 20:09:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:30 --> Input Class Initialized
INFO - 2023-08-23 20:09:30 --> Security Class Initialized
INFO - 2023-08-23 20:09:30 --> Language Class Initialized
DEBUG - 2023-08-23 20:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:09:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:30 --> Input Class Initialized
INFO - 2023-08-23 20:09:30 --> Language Class Initialized
ERROR - 2023-08-23 20:09:30 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:34 --> URI Class Initialized
INFO - 2023-08-23 20:09:34 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:34 --> Router Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:34 --> Output Class Initialized
INFO - 2023-08-23 20:09:34 --> URI Class Initialized
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:34 --> Router Class Initialized
INFO - 2023-08-23 20:09:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:34 --> URI Class Initialized
INFO - 2023-08-23 20:09:34 --> Router Class Initialized
INFO - 2023-08-23 20:09:34 --> URI Class Initialized
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:34 --> Security Class Initialized
INFO - 2023-08-23 20:09:34 --> Router Class Initialized
INFO - 2023-08-23 20:09:34 --> Output Class Initialized
INFO - 2023-08-23 20:09:34 --> Output Class Initialized
DEBUG - 2023-08-23 20:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:34 --> URI Class Initialized
INFO - 2023-08-23 20:09:34 --> Output Class Initialized
INFO - 2023-08-23 20:09:34 --> Security Class Initialized
INFO - 2023-08-23 20:09:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:34 --> Router Class Initialized
INFO - 2023-08-23 20:09:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:34 --> Input Class Initialized
INFO - 2023-08-23 20:09:34 --> Language Class Initialized
ERROR - 2023-08-23 20:09:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:34 --> Input Class Initialized
INFO - 2023-08-23 20:09:34 --> Input Class Initialized
INFO - 2023-08-23 20:09:34 --> Language Class Initialized
DEBUG - 2023-08-23 20:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:09:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:35 --> Output Class Initialized
INFO - 2023-08-23 20:09:35 --> Security Class Initialized
INFO - 2023-08-23 20:09:35 --> Input Class Initialized
INFO - 2023-08-23 20:09:35 --> URI Class Initialized
INFO - 2023-08-23 20:09:35 --> Language Class Initialized
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:35 --> Language Class Initialized
ERROR - 2023-08-23 20:09:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
INFO - 2023-08-23 20:09:35 --> Router Class Initialized
INFO - 2023-08-23 20:09:35 --> Input Class Initialized
INFO - 2023-08-23 20:09:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:35 --> Language Class Initialized
ERROR - 2023-08-23 20:09:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:35 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:35 --> Output Class Initialized
INFO - 2023-08-23 20:09:35 --> URI Class Initialized
DEBUG - 2023-08-23 20:09:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:35 --> Router Class Initialized
INFO - 2023-08-23 20:09:35 --> Output Class Initialized
INFO - 2023-08-23 20:09:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:35 --> Input Class Initialized
INFO - 2023-08-23 20:09:35 --> Language Class Initialized
ERROR - 2023-08-23 20:09:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:35 --> Security Class Initialized
ERROR - 2023-08-23 20:09:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:35 --> URI Class Initialized
INFO - 2023-08-23 20:09:35 --> Router Class Initialized
INFO - 2023-08-23 20:09:35 --> Input Class Initialized
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
INFO - 2023-08-23 20:09:35 --> Language Class Initialized
INFO - 2023-08-23 20:09:35 --> Config Class Initialized
INFO - 2023-08-23 20:09:35 --> Output Class Initialized
ERROR - 2023-08-23 20:09:35 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:36 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:36 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:36 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:36 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:36 --> URI Class Initialized
INFO - 2023-08-23 20:09:36 --> Router Class Initialized
INFO - 2023-08-23 20:09:36 --> Output Class Initialized
INFO - 2023-08-23 20:09:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:36 --> Input Class Initialized
INFO - 2023-08-23 20:09:36 --> Language Class Initialized
ERROR - 2023-08-23 20:09:36 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:09:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:09:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:36 --> Input Class Initialized
INFO - 2023-08-23 20:09:36 --> Language Class Initialized
INFO - 2023-08-23 20:09:36 --> URI Class Initialized
ERROR - 2023-08-23 20:09:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:36 --> Router Class Initialized
INFO - 2023-08-23 20:09:36 --> Output Class Initialized
INFO - 2023-08-23 20:09:36 --> URI Class Initialized
INFO - 2023-08-23 20:09:36 --> URI Class Initialized
INFO - 2023-08-23 20:09:36 --> Router Class Initialized
INFO - 2023-08-23 20:09:36 --> Security Class Initialized
INFO - 2023-08-23 20:09:36 --> Router Class Initialized
DEBUG - 2023-08-23 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:36 --> Output Class Initialized
INFO - 2023-08-23 20:09:36 --> Output Class Initialized
INFO - 2023-08-23 20:09:36 --> Input Class Initialized
INFO - 2023-08-23 20:09:36 --> Security Class Initialized
INFO - 2023-08-23 20:09:36 --> Language Class Initialized
ERROR - 2023-08-23 20:09:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:36 --> Input Class Initialized
INFO - 2023-08-23 20:09:36 --> Input Class Initialized
INFO - 2023-08-23 20:09:36 --> Language Class Initialized
INFO - 2023-08-23 20:09:36 --> Language Class Initialized
ERROR - 2023-08-23 20:09:37 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:09:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:41 --> Config Class Initialized
INFO - 2023-08-23 20:09:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:41 --> URI Class Initialized
INFO - 2023-08-23 20:09:41 --> Router Class Initialized
INFO - 2023-08-23 20:09:41 --> Output Class Initialized
INFO - 2023-08-23 20:09:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:41 --> Input Class Initialized
INFO - 2023-08-23 20:09:41 --> Language Class Initialized
INFO - 2023-08-23 20:09:41 --> Loader Class Initialized
INFO - 2023-08-23 20:09:41 --> Helper loaded: url_helper
INFO - 2023-08-23 20:09:41 --> Helper loaded: file_helper
INFO - 2023-08-23 20:09:41 --> Database Driver Class Initialized
INFO - 2023-08-23 20:09:41 --> Email Class Initialized
DEBUG - 2023-08-23 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:09:41 --> Controller Class Initialized
INFO - 2023-08-23 20:09:41 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:09:41 --> Model "Home_model" initialized
INFO - 2023-08-23 20:09:41 --> Helper loaded: download_helper
INFO - 2023-08-23 20:09:41 --> Helper loaded: form_helper
INFO - 2023-08-23 20:09:41 --> Form Validation Class Initialized
INFO - 2023-08-23 20:09:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:09:41 --> Final output sent to browser
DEBUG - 2023-08-23 20:09:41 --> Total execution time: 0.5757
INFO - 2023-08-23 20:09:43 --> Config Class Initialized
INFO - 2023-08-23 20:09:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:43 --> URI Class Initialized
INFO - 2023-08-23 20:09:43 --> Router Class Initialized
INFO - 2023-08-23 20:09:43 --> Output Class Initialized
INFO - 2023-08-23 20:09:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:43 --> Input Class Initialized
INFO - 2023-08-23 20:09:43 --> Language Class Initialized
ERROR - 2023-08-23 20:09:43 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:43 --> Config Class Initialized
INFO - 2023-08-23 20:09:43 --> Config Class Initialized
INFO - 2023-08-23 20:09:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:43 --> Config Class Initialized
INFO - 2023-08-23 20:09:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:43 --> URI Class Initialized
INFO - 2023-08-23 20:09:43 --> Router Class Initialized
INFO - 2023-08-23 20:09:43 --> Output Class Initialized
INFO - 2023-08-23 20:09:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:43 --> Input Class Initialized
INFO - 2023-08-23 20:09:43 --> Language Class Initialized
ERROR - 2023-08-23 20:09:43 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:43 --> URI Class Initialized
INFO - 2023-08-23 20:09:43 --> Router Class Initialized
INFO - 2023-08-23 20:09:43 --> Output Class Initialized
INFO - 2023-08-23 20:09:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:43 --> Input Class Initialized
INFO - 2023-08-23 20:09:43 --> Language Class Initialized
ERROR - 2023-08-23 20:09:43 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:44 --> Config Class Initialized
INFO - 2023-08-23 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:44 --> URI Class Initialized
INFO - 2023-08-23 20:09:44 --> Router Class Initialized
INFO - 2023-08-23 20:09:44 --> Output Class Initialized
INFO - 2023-08-23 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:44 --> Input Class Initialized
INFO - 2023-08-23 20:09:44 --> Language Class Initialized
ERROR - 2023-08-23 20:09:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:44 --> URI Class Initialized
INFO - 2023-08-23 20:09:44 --> Router Class Initialized
INFO - 2023-08-23 20:09:44 --> Output Class Initialized
INFO - 2023-08-23 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:44 --> Input Class Initialized
INFO - 2023-08-23 20:09:44 --> Language Class Initialized
ERROR - 2023-08-23 20:09:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:44 --> Config Class Initialized
INFO - 2023-08-23 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:44 --> URI Class Initialized
INFO - 2023-08-23 20:09:44 --> Router Class Initialized
INFO - 2023-08-23 20:09:44 --> Output Class Initialized
INFO - 2023-08-23 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:44 --> Input Class Initialized
INFO - 2023-08-23 20:09:44 --> Language Class Initialized
ERROR - 2023-08-23 20:09:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:44 --> Config Class Initialized
INFO - 2023-08-23 20:09:44 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:44 --> Config Class Initialized
INFO - 2023-08-23 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:44 --> URI Class Initialized
INFO - 2023-08-23 20:09:44 --> Router Class Initialized
INFO - 2023-08-23 20:09:44 --> Output Class Initialized
INFO - 2023-08-23 20:09:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:44 --> Input Class Initialized
INFO - 2023-08-23 20:09:44 --> Language Class Initialized
ERROR - 2023-08-23 20:09:44 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:09:44 --> Config Class Initialized
INFO - 2023-08-23 20:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:45 --> Config Class Initialized
DEBUG - 2023-08-23 20:09:45 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:45 --> Config Class Initialized
INFO - 2023-08-23 20:09:45 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:45 --> Config Class Initialized
INFO - 2023-08-23 20:09:45 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:45 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:09:45 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:45 --> URI Class Initialized
INFO - 2023-08-23 20:09:45 --> URI Class Initialized
INFO - 2023-08-23 20:09:45 --> Router Class Initialized
INFO - 2023-08-23 20:09:45 --> Output Class Initialized
INFO - 2023-08-23 20:09:45 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:45 --> Input Class Initialized
INFO - 2023-08-23 20:09:45 --> Language Class Initialized
ERROR - 2023-08-23 20:09:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:45 --> Router Class Initialized
INFO - 2023-08-23 20:09:45 --> Hooks Class Initialized
INFO - 2023-08-23 20:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:46 --> URI Class Initialized
INFO - 2023-08-23 20:09:46 --> Output Class Initialized
INFO - 2023-08-23 20:09:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:09:46 --> Router Class Initialized
DEBUG - 2023-08-23 20:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:09:46 --> URI Class Initialized
INFO - 2023-08-23 20:09:46 --> Output Class Initialized
INFO - 2023-08-23 20:09:46 --> Security Class Initialized
INFO - 2023-08-23 20:09:46 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:46 --> URI Class Initialized
INFO - 2023-08-23 20:09:46 --> Router Class Initialized
INFO - 2023-08-23 20:09:46 --> Security Class Initialized
INFO - 2023-08-23 20:09:46 --> Input Class Initialized
INFO - 2023-08-23 20:09:46 --> Output Class Initialized
INFO - 2023-08-23 20:09:46 --> Router Class Initialized
DEBUG - 2023-08-23 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:46 --> Language Class Initialized
ERROR - 2023-08-23 20:09:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:46 --> Output Class Initialized
INFO - 2023-08-23 20:09:46 --> Security Class Initialized
INFO - 2023-08-23 20:09:46 --> Security Class Initialized
DEBUG - 2023-08-23 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:46 --> Input Class Initialized
DEBUG - 2023-08-23 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:09:46 --> Input Class Initialized
INFO - 2023-08-23 20:09:46 --> Language Class Initialized
INFO - 2023-08-23 20:09:46 --> Language Class Initialized
INFO - 2023-08-23 20:09:46 --> Input Class Initialized
ERROR - 2023-08-23 20:09:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:09:46 --> Language Class Initialized
ERROR - 2023-08-23 20:09:46 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:09:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:20 --> Config Class Initialized
INFO - 2023-08-23 20:11:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:21 --> URI Class Initialized
INFO - 2023-08-23 20:11:21 --> Router Class Initialized
INFO - 2023-08-23 20:11:21 --> Output Class Initialized
INFO - 2023-08-23 20:11:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:21 --> Input Class Initialized
INFO - 2023-08-23 20:11:21 --> Language Class Initialized
INFO - 2023-08-23 20:11:21 --> Loader Class Initialized
INFO - 2023-08-23 20:11:21 --> Helper loaded: url_helper
INFO - 2023-08-23 20:11:21 --> Helper loaded: file_helper
INFO - 2023-08-23 20:11:21 --> Database Driver Class Initialized
INFO - 2023-08-23 20:11:21 --> Email Class Initialized
DEBUG - 2023-08-23 20:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:11:21 --> Controller Class Initialized
INFO - 2023-08-23 20:11:21 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:11:21 --> Model "Home_model" initialized
INFO - 2023-08-23 20:11:21 --> Helper loaded: download_helper
INFO - 2023-08-23 20:11:21 --> Helper loaded: form_helper
INFO - 2023-08-23 20:11:21 --> Form Validation Class Initialized
INFO - 2023-08-23 20:11:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:11:21 --> Final output sent to browser
DEBUG - 2023-08-23 20:11:22 --> Total execution time: 0.9619
INFO - 2023-08-23 20:11:22 --> Config Class Initialized
INFO - 2023-08-23 20:11:23 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:23 --> Config Class Initialized
INFO - 2023-08-23 20:11:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:11:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:23 --> URI Class Initialized
INFO - 2023-08-23 20:11:23 --> Config Class Initialized
INFO - 2023-08-23 20:11:23 --> Config Class Initialized
INFO - 2023-08-23 20:11:23 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:23 --> Config Class Initialized
INFO - 2023-08-23 20:11:23 --> Router Class Initialized
INFO - 2023-08-23 20:11:23 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:23 --> Config Class Initialized
DEBUG - 2023-08-23 20:11:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:23 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:11:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
DEBUG - 2023-08-23 20:11:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
INFO - 2023-08-23 20:11:24 --> Config Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:24 --> Config Class Initialized
INFO - 2023-08-23 20:11:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:24 --> Input Class Initialized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:24 --> Config Class Initialized
INFO - 2023-08-23 20:11:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:24 --> URI Class Initialized
INFO - 2023-08-23 20:11:24 --> Router Class Initialized
INFO - 2023-08-23 20:11:24 --> Output Class Initialized
INFO - 2023-08-23 20:11:24 --> Security Class Initialized
INFO - 2023-08-23 20:11:24 --> Language Class Initialized
ERROR - 2023-08-23 20:11:24 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:11:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:25 --> Config Class Initialized
DEBUG - 2023-08-23 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:25 --> URI Class Initialized
INFO - 2023-08-23 20:11:25 --> Router Class Initialized
INFO - 2023-08-23 20:11:25 --> Output Class Initialized
INFO - 2023-08-23 20:11:25 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:25 --> Input Class Initialized
INFO - 2023-08-23 20:11:25 --> Language Class Initialized
ERROR - 2023-08-23 20:11:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:25 --> Config Class Initialized
INFO - 2023-08-23 20:11:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:25 --> Input Class Initialized
INFO - 2023-08-23 20:11:25 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:25 --> Language Class Initialized
INFO - 2023-08-23 20:11:25 --> Config Class Initialized
INFO - 2023-08-23 20:11:25 --> URI Class Initialized
DEBUG - 2023-08-23 20:11:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:25 --> Router Class Initialized
ERROR - 2023-08-23 20:11:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:25 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:25 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:11:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:25 --> Output Class Initialized
INFO - 2023-08-23 20:11:25 --> URI Class Initialized
INFO - 2023-08-23 20:11:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:25 --> URI Class Initialized
INFO - 2023-08-23 20:11:25 --> Security Class Initialized
INFO - 2023-08-23 20:11:25 --> Router Class Initialized
DEBUG - 2023-08-23 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:25 --> Router Class Initialized
INFO - 2023-08-23 20:11:25 --> Input Class Initialized
INFO - 2023-08-23 20:11:25 --> Output Class Initialized
INFO - 2023-08-23 20:11:25 --> Output Class Initialized
INFO - 2023-08-23 20:11:25 --> Security Class Initialized
INFO - 2023-08-23 20:11:25 --> Language Class Initialized
DEBUG - 2023-08-23 20:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:11:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:25 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:25 --> Input Class Initialized
INFO - 2023-08-23 20:11:25 --> Input Class Initialized
INFO - 2023-08-23 20:11:25 --> Language Class Initialized
INFO - 2023-08-23 20:11:25 --> Language Class Initialized
ERROR - 2023-08-23 20:11:25 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:11:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:53 --> Config Class Initialized
INFO - 2023-08-23 20:11:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:53 --> URI Class Initialized
INFO - 2023-08-23 20:11:53 --> Router Class Initialized
INFO - 2023-08-23 20:11:53 --> Output Class Initialized
INFO - 2023-08-23 20:11:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:53 --> Input Class Initialized
INFO - 2023-08-23 20:11:53 --> Language Class Initialized
INFO - 2023-08-23 20:11:53 --> Loader Class Initialized
INFO - 2023-08-23 20:11:53 --> Helper loaded: url_helper
INFO - 2023-08-23 20:11:53 --> Helper loaded: file_helper
INFO - 2023-08-23 20:11:53 --> Database Driver Class Initialized
INFO - 2023-08-23 20:11:53 --> Email Class Initialized
DEBUG - 2023-08-23 20:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:11:53 --> Controller Class Initialized
INFO - 2023-08-23 20:11:53 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:11:53 --> Model "Home_model" initialized
INFO - 2023-08-23 20:11:53 --> Helper loaded: download_helper
INFO - 2023-08-23 20:11:53 --> Helper loaded: form_helper
INFO - 2023-08-23 20:11:53 --> Form Validation Class Initialized
INFO - 2023-08-23 20:11:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:11:53 --> Final output sent to browser
DEBUG - 2023-08-23 20:11:53 --> Total execution time: 0.4886
INFO - 2023-08-23 20:11:55 --> Config Class Initialized
INFO - 2023-08-23 20:11:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:55 --> URI Class Initialized
INFO - 2023-08-23 20:11:55 --> Router Class Initialized
INFO - 2023-08-23 20:11:55 --> Output Class Initialized
INFO - 2023-08-23 20:11:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:55 --> Input Class Initialized
INFO - 2023-08-23 20:11:55 --> Language Class Initialized
ERROR - 2023-08-23 20:11:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:55 --> Config Class Initialized
INFO - 2023-08-23 20:11:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:55 --> URI Class Initialized
INFO - 2023-08-23 20:11:55 --> Router Class Initialized
INFO - 2023-08-23 20:11:55 --> Output Class Initialized
INFO - 2023-08-23 20:11:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:55 --> Input Class Initialized
INFO - 2023-08-23 20:11:55 --> Config Class Initialized
INFO - 2023-08-23 20:11:55 --> Config Class Initialized
INFO - 2023-08-23 20:11:56 --> Language Class Initialized
ERROR - 2023-08-23 20:11:56 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:56 --> Config Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> Config Class Initialized
INFO - 2023-08-23 20:11:56 --> Config Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
INFO - 2023-08-23 20:11:56 --> Config Class Initialized
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:56 --> Input Class Initialized
INFO - 2023-08-23 20:11:56 --> Language Class Initialized
ERROR - 2023-08-23 20:11:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
DEBUG - 2023-08-23 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
INFO - 2023-08-23 20:11:56 --> URI Class Initialized
DEBUG - 2023-08-23 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:56 --> Input Class Initialized
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Config Class Initialized
DEBUG - 2023-08-23 20:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:56 --> Router Class Initialized
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
INFO - 2023-08-23 20:11:56 --> Input Class Initialized
INFO - 2023-08-23 20:11:56 --> Input Class Initialized
INFO - 2023-08-23 20:11:56 --> Language Class Initialized
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
INFO - 2023-08-23 20:11:56 --> Language Class Initialized
ERROR - 2023-08-23 20:11:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:56 --> Output Class Initialized
DEBUG - 2023-08-23 20:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:11:56 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:11:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:56 --> Security Class Initialized
INFO - 2023-08-23 20:11:56 --> Input Class Initialized
INFO - 2023-08-23 20:11:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:56 --> Language Class Initialized
INFO - 2023-08-23 20:11:57 --> Language Class Initialized
DEBUG - 2023-08-23 20:11:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:11:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:57 --> URI Class Initialized
INFO - 2023-08-23 20:11:57 --> Input Class Initialized
INFO - 2023-08-23 20:11:57 --> Config Class Initialized
INFO - 2023-08-23 20:11:57 --> Config Class Initialized
INFO - 2023-08-23 20:11:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:57 --> Router Class Initialized
ERROR - 2023-08-23 20:11:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:57 --> Language Class Initialized
DEBUG - 2023-08-23 20:11:57 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:11:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:11:57 --> Output Class Initialized
INFO - 2023-08-23 20:11:57 --> Security Class Initialized
INFO - 2023-08-23 20:11:57 --> Config Class Initialized
INFO - 2023-08-23 20:11:57 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:11:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:57 --> URI Class Initialized
DEBUG - 2023-08-23 20:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:11:57 --> Input Class Initialized
INFO - 2023-08-23 20:11:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:11:58 --> Language Class Initialized
INFO - 2023-08-23 20:11:58 --> URI Class Initialized
INFO - 2023-08-23 20:11:58 --> Router Class Initialized
DEBUG - 2023-08-23 20:11:58 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:11:58 --> Output Class Initialized
INFO - 2023-08-23 20:11:58 --> Router Class Initialized
INFO - 2023-08-23 20:11:58 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:58 --> URI Class Initialized
INFO - 2023-08-23 20:11:58 --> Output Class Initialized
INFO - 2023-08-23 20:11:58 --> Security Class Initialized
INFO - 2023-08-23 20:11:58 --> Security Class Initialized
DEBUG - 2023-08-23 20:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:11:58 --> Router Class Initialized
INFO - 2023-08-23 20:11:58 --> Input Class Initialized
INFO - 2023-08-23 20:11:58 --> Input Class Initialized
INFO - 2023-08-23 20:11:58 --> Output Class Initialized
INFO - 2023-08-23 20:11:58 --> Language Class Initialized
INFO - 2023-08-23 20:11:58 --> Security Class Initialized
ERROR - 2023-08-23 20:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:58 --> Language Class Initialized
DEBUG - 2023-08-23 20:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:11:58 --> Input Class Initialized
INFO - 2023-08-23 20:11:58 --> Language Class Initialized
ERROR - 2023-08-23 20:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:17 --> Config Class Initialized
INFO - 2023-08-23 20:12:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:17 --> URI Class Initialized
INFO - 2023-08-23 20:12:17 --> Router Class Initialized
INFO - 2023-08-23 20:12:17 --> Output Class Initialized
INFO - 2023-08-23 20:12:17 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:17 --> Input Class Initialized
INFO - 2023-08-23 20:12:17 --> Language Class Initialized
INFO - 2023-08-23 20:12:17 --> Loader Class Initialized
INFO - 2023-08-23 20:12:17 --> Helper loaded: url_helper
INFO - 2023-08-23 20:12:18 --> Helper loaded: file_helper
INFO - 2023-08-23 20:12:18 --> Database Driver Class Initialized
INFO - 2023-08-23 20:12:18 --> Email Class Initialized
DEBUG - 2023-08-23 20:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:12:18 --> Controller Class Initialized
INFO - 2023-08-23 20:12:18 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:12:18 --> Model "Home_model" initialized
INFO - 2023-08-23 20:12:18 --> Helper loaded: download_helper
INFO - 2023-08-23 20:12:18 --> Helper loaded: form_helper
INFO - 2023-08-23 20:12:18 --> Form Validation Class Initialized
INFO - 2023-08-23 20:12:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:12:18 --> Final output sent to browser
DEBUG - 2023-08-23 20:12:18 --> Total execution time: 0.7232
INFO - 2023-08-23 20:12:19 --> Config Class Initialized
INFO - 2023-08-23 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:19 --> URI Class Initialized
INFO - 2023-08-23 20:12:19 --> Router Class Initialized
INFO - 2023-08-23 20:12:19 --> Output Class Initialized
INFO - 2023-08-23 20:12:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:19 --> Input Class Initialized
INFO - 2023-08-23 20:12:19 --> Language Class Initialized
ERROR - 2023-08-23 20:12:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:19 --> Config Class Initialized
INFO - 2023-08-23 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:19 --> URI Class Initialized
INFO - 2023-08-23 20:12:19 --> Router Class Initialized
INFO - 2023-08-23 20:12:19 --> Output Class Initialized
INFO - 2023-08-23 20:12:19 --> Config Class Initialized
INFO - 2023-08-23 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:19 --> URI Class Initialized
INFO - 2023-08-23 20:12:19 --> Router Class Initialized
INFO - 2023-08-23 20:12:19 --> Output Class Initialized
INFO - 2023-08-23 20:12:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:19 --> Input Class Initialized
INFO - 2023-08-23 20:12:19 --> Language Class Initialized
ERROR - 2023-08-23 20:12:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:19 --> Input Class Initialized
INFO - 2023-08-23 20:12:19 --> Language Class Initialized
ERROR - 2023-08-23 20:12:19 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:19 --> Config Class Initialized
INFO - 2023-08-23 20:12:19 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:19 --> URI Class Initialized
INFO - 2023-08-23 20:12:19 --> Router Class Initialized
INFO - 2023-08-23 20:12:19 --> Output Class Initialized
INFO - 2023-08-23 20:12:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:19 --> Input Class Initialized
INFO - 2023-08-23 20:12:19 --> Language Class Initialized
ERROR - 2023-08-23 20:12:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:20 --> Config Class Initialized
INFO - 2023-08-23 20:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:20 --> URI Class Initialized
INFO - 2023-08-23 20:12:20 --> Router Class Initialized
INFO - 2023-08-23 20:12:20 --> Output Class Initialized
INFO - 2023-08-23 20:12:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:20 --> Input Class Initialized
INFO - 2023-08-23 20:12:20 --> Language Class Initialized
ERROR - 2023-08-23 20:12:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:21 --> Config Class Initialized
INFO - 2023-08-23 20:12:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:21 --> URI Class Initialized
INFO - 2023-08-23 20:12:21 --> Router Class Initialized
INFO - 2023-08-23 20:12:21 --> Output Class Initialized
INFO - 2023-08-23 20:12:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:21 --> Input Class Initialized
INFO - 2023-08-23 20:12:21 --> Language Class Initialized
ERROR - 2023-08-23 20:12:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:21 --> Config Class Initialized
INFO - 2023-08-23 20:12:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:21 --> URI Class Initialized
INFO - 2023-08-23 20:12:21 --> Router Class Initialized
INFO - 2023-08-23 20:12:21 --> Output Class Initialized
INFO - 2023-08-23 20:12:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:21 --> Input Class Initialized
INFO - 2023-08-23 20:12:21 --> Language Class Initialized
ERROR - 2023-08-23 20:12:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:21 --> Config Class Initialized
INFO - 2023-08-23 20:12:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:22 --> URI Class Initialized
INFO - 2023-08-23 20:12:22 --> Router Class Initialized
INFO - 2023-08-23 20:12:22 --> Output Class Initialized
INFO - 2023-08-23 20:12:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:22 --> Input Class Initialized
INFO - 2023-08-23 20:12:22 --> Language Class Initialized
ERROR - 2023-08-23 20:12:22 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:12:31 --> Config Class Initialized
INFO - 2023-08-23 20:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:31 --> URI Class Initialized
INFO - 2023-08-23 20:12:31 --> Router Class Initialized
INFO - 2023-08-23 20:12:31 --> Output Class Initialized
INFO - 2023-08-23 20:12:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:31 --> Input Class Initialized
INFO - 2023-08-23 20:12:31 --> Language Class Initialized
ERROR - 2023-08-23 20:12:31 --> 404 Page Not Found: Training-detail/content-writing.html
INFO - 2023-08-23 20:12:34 --> Config Class Initialized
INFO - 2023-08-23 20:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:34 --> URI Class Initialized
INFO - 2023-08-23 20:12:34 --> Router Class Initialized
INFO - 2023-08-23 20:12:34 --> Output Class Initialized
INFO - 2023-08-23 20:12:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:34 --> Input Class Initialized
INFO - 2023-08-23 20:12:34 --> Language Class Initialized
INFO - 2023-08-23 20:12:34 --> Loader Class Initialized
INFO - 2023-08-23 20:12:34 --> Helper loaded: url_helper
INFO - 2023-08-23 20:12:34 --> Helper loaded: file_helper
INFO - 2023-08-23 20:12:34 --> Database Driver Class Initialized
INFO - 2023-08-23 20:12:34 --> Email Class Initialized
DEBUG - 2023-08-23 20:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:12:34 --> Controller Class Initialized
INFO - 2023-08-23 20:12:34 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:12:34 --> Model "Home_model" initialized
INFO - 2023-08-23 20:12:34 --> Helper loaded: download_helper
INFO - 2023-08-23 20:12:34 --> Helper loaded: form_helper
INFO - 2023-08-23 20:12:34 --> Form Validation Class Initialized
INFO - 2023-08-23 20:12:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:12:34 --> Final output sent to browser
DEBUG - 2023-08-23 20:12:34 --> Total execution time: 0.0472
INFO - 2023-08-23 20:12:35 --> Config Class Initialized
INFO - 2023-08-23 20:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:35 --> URI Class Initialized
INFO - 2023-08-23 20:12:35 --> Router Class Initialized
INFO - 2023-08-23 20:12:35 --> Output Class Initialized
INFO - 2023-08-23 20:12:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:35 --> Input Class Initialized
INFO - 2023-08-23 20:12:35 --> Language Class Initialized
ERROR - 2023-08-23 20:12:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:35 --> Config Class Initialized
INFO - 2023-08-23 20:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:35 --> URI Class Initialized
INFO - 2023-08-23 20:12:35 --> Router Class Initialized
INFO - 2023-08-23 20:12:35 --> Output Class Initialized
INFO - 2023-08-23 20:12:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:35 --> Input Class Initialized
INFO - 2023-08-23 20:12:35 --> Language Class Initialized
ERROR - 2023-08-23 20:12:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:35 --> Config Class Initialized
INFO - 2023-08-23 20:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:35 --> URI Class Initialized
INFO - 2023-08-23 20:12:35 --> Router Class Initialized
INFO - 2023-08-23 20:12:35 --> Output Class Initialized
INFO - 2023-08-23 20:12:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:35 --> Input Class Initialized
INFO - 2023-08-23 20:12:35 --> Language Class Initialized
ERROR - 2023-08-23 20:12:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:36 --> Config Class Initialized
INFO - 2023-08-23 20:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:36 --> URI Class Initialized
INFO - 2023-08-23 20:12:36 --> Router Class Initialized
INFO - 2023-08-23 20:12:36 --> Config Class Initialized
INFO - 2023-08-23 20:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:36 --> URI Class Initialized
INFO - 2023-08-23 20:12:36 --> Router Class Initialized
INFO - 2023-08-23 20:12:36 --> Output Class Initialized
INFO - 2023-08-23 20:12:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:36 --> Input Class Initialized
INFO - 2023-08-23 20:12:36 --> Language Class Initialized
ERROR - 2023-08-23 20:12:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:36 --> Output Class Initialized
INFO - 2023-08-23 20:12:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:36 --> Input Class Initialized
INFO - 2023-08-23 20:12:36 --> Language Class Initialized
ERROR - 2023-08-23 20:12:36 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:36 --> Config Class Initialized
INFO - 2023-08-23 20:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:36 --> URI Class Initialized
INFO - 2023-08-23 20:12:36 --> Router Class Initialized
INFO - 2023-08-23 20:12:37 --> Output Class Initialized
INFO - 2023-08-23 20:12:37 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:37 --> Input Class Initialized
INFO - 2023-08-23 20:12:37 --> Language Class Initialized
ERROR - 2023-08-23 20:12:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:12:37 --> Config Class Initialized
INFO - 2023-08-23 20:12:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:12:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:12:37 --> Utf8 Class Initialized
INFO - 2023-08-23 20:12:37 --> URI Class Initialized
INFO - 2023-08-23 20:12:37 --> Router Class Initialized
INFO - 2023-08-23 20:12:37 --> Output Class Initialized
INFO - 2023-08-23 20:12:37 --> Security Class Initialized
DEBUG - 2023-08-23 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:12:37 --> Input Class Initialized
INFO - 2023-08-23 20:12:37 --> Language Class Initialized
ERROR - 2023-08-23 20:12:37 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:00 --> Config Class Initialized
INFO - 2023-08-23 20:13:00 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:00 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:00 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:00 --> URI Class Initialized
INFO - 2023-08-23 20:13:00 --> Router Class Initialized
INFO - 2023-08-23 20:13:00 --> Output Class Initialized
INFO - 2023-08-23 20:13:00 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:00 --> Input Class Initialized
INFO - 2023-08-23 20:13:00 --> Language Class Initialized
INFO - 2023-08-23 20:13:00 --> Loader Class Initialized
INFO - 2023-08-23 20:13:00 --> Helper loaded: url_helper
INFO - 2023-08-23 20:13:00 --> Helper loaded: file_helper
INFO - 2023-08-23 20:13:00 --> Database Driver Class Initialized
INFO - 2023-08-23 20:13:00 --> Email Class Initialized
DEBUG - 2023-08-23 20:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:13:00 --> Controller Class Initialized
INFO - 2023-08-23 20:13:00 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:13:00 --> Model "Home_model" initialized
INFO - 2023-08-23 20:13:00 --> Helper loaded: download_helper
INFO - 2023-08-23 20:13:00 --> Helper loaded: form_helper
INFO - 2023-08-23 20:13:00 --> Form Validation Class Initialized
INFO - 2023-08-23 20:13:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:13:00 --> Final output sent to browser
DEBUG - 2023-08-23 20:13:01 --> Total execution time: 0.2477
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:02 --> Config Class Initialized
INFO - 2023-08-23 20:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:02 --> URI Class Initialized
INFO - 2023-08-23 20:13:02 --> Router Class Initialized
INFO - 2023-08-23 20:13:02 --> Output Class Initialized
INFO - 2023-08-23 20:13:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:02 --> Input Class Initialized
INFO - 2023-08-23 20:13:02 --> Language Class Initialized
ERROR - 2023-08-23 20:13:02 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:03 --> Config Class Initialized
INFO - 2023-08-23 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:03 --> URI Class Initialized
INFO - 2023-08-23 20:13:03 --> Router Class Initialized
INFO - 2023-08-23 20:13:03 --> Output Class Initialized
INFO - 2023-08-23 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:03 --> Input Class Initialized
INFO - 2023-08-23 20:13:03 --> Language Class Initialized
ERROR - 2023-08-23 20:13:03 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:03 --> Config Class Initialized
INFO - 2023-08-23 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:03 --> URI Class Initialized
INFO - 2023-08-23 20:13:03 --> Router Class Initialized
INFO - 2023-08-23 20:13:03 --> Output Class Initialized
INFO - 2023-08-23 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:03 --> Input Class Initialized
INFO - 2023-08-23 20:13:03 --> Language Class Initialized
ERROR - 2023-08-23 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:03 --> Config Class Initialized
INFO - 2023-08-23 20:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:03 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:03 --> URI Class Initialized
INFO - 2023-08-23 20:13:03 --> Router Class Initialized
INFO - 2023-08-23 20:13:03 --> Output Class Initialized
INFO - 2023-08-23 20:13:03 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:03 --> Input Class Initialized
INFO - 2023-08-23 20:13:03 --> Language Class Initialized
ERROR - 2023-08-23 20:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:04 --> Config Class Initialized
INFO - 2023-08-23 20:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:04 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:04 --> URI Class Initialized
INFO - 2023-08-23 20:13:04 --> Router Class Initialized
INFO - 2023-08-23 20:13:04 --> Output Class Initialized
INFO - 2023-08-23 20:13:04 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:04 --> Input Class Initialized
INFO - 2023-08-23 20:13:04 --> Language Class Initialized
ERROR - 2023-08-23 20:13:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:04 --> Config Class Initialized
INFO - 2023-08-23 20:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:04 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:04 --> URI Class Initialized
INFO - 2023-08-23 20:13:04 --> Router Class Initialized
INFO - 2023-08-23 20:13:04 --> Output Class Initialized
INFO - 2023-08-23 20:13:04 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:04 --> Input Class Initialized
INFO - 2023-08-23 20:13:04 --> Language Class Initialized
ERROR - 2023-08-23 20:13:04 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:43 --> Config Class Initialized
INFO - 2023-08-23 20:13:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:43 --> URI Class Initialized
INFO - 2023-08-23 20:13:43 --> Router Class Initialized
INFO - 2023-08-23 20:13:43 --> Output Class Initialized
INFO - 2023-08-23 20:13:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:43 --> Input Class Initialized
INFO - 2023-08-23 20:13:43 --> Language Class Initialized
INFO - 2023-08-23 20:13:43 --> Loader Class Initialized
INFO - 2023-08-23 20:13:43 --> Helper loaded: url_helper
INFO - 2023-08-23 20:13:43 --> Helper loaded: file_helper
INFO - 2023-08-23 20:13:43 --> Database Driver Class Initialized
INFO - 2023-08-23 20:13:44 --> Email Class Initialized
DEBUG - 2023-08-23 20:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:13:44 --> Controller Class Initialized
INFO - 2023-08-23 20:13:44 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:13:44 --> Model "Home_model" initialized
INFO - 2023-08-23 20:13:44 --> Helper loaded: download_helper
INFO - 2023-08-23 20:13:44 --> Helper loaded: form_helper
INFO - 2023-08-23 20:13:44 --> Form Validation Class Initialized
INFO - 2023-08-23 20:13:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:13:44 --> Final output sent to browser
DEBUG - 2023-08-23 20:13:45 --> Total execution time: 1.2140
INFO - 2023-08-23 20:13:45 --> Config Class Initialized
INFO - 2023-08-23 20:13:45 --> Config Class Initialized
INFO - 2023-08-23 20:13:45 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:45 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:45 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:46 --> Input Class Initialized
INFO - 2023-08-23 20:13:46 --> Language Class Initialized
ERROR - 2023-08-23 20:13:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Security Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:46 --> Input Class Initialized
INFO - 2023-08-23 20:13:46 --> Language Class Initialized
ERROR - 2023-08-23 20:13:46 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:46 --> Input Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Language Class Initialized
ERROR - 2023-08-23 20:13:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:46 --> Config Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:46 --> Security Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Security Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:13:46 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
DEBUG - 2023-08-23 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
DEBUG - 2023-08-23 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Input Class Initialized
INFO - 2023-08-23 20:13:46 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:46 --> Router Class Initialized
INFO - 2023-08-23 20:13:46 --> Input Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Output Class Initialized
INFO - 2023-08-23 20:13:46 --> Language Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:46 --> URI Class Initialized
INFO - 2023-08-23 20:13:47 --> Security Class Initialized
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:47 --> Security Class Initialized
INFO - 2023-08-23 20:13:47 --> Language Class Initialized
INFO - 2023-08-23 20:13:47 --> Router Class Initialized
DEBUG - 2023-08-23 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:47 --> Input Class Initialized
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:47 --> Router Class Initialized
DEBUG - 2023-08-23 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:47 --> Output Class Initialized
INFO - 2023-08-23 20:13:47 --> Config Class Initialized
INFO - 2023-08-23 20:13:47 --> Language Class Initialized
INFO - 2023-08-23 20:13:47 --> Security Class Initialized
INFO - 2023-08-23 20:13:47 --> Config Class Initialized
INFO - 2023-08-23 20:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:47 --> Input Class Initialized
INFO - 2023-08-23 20:13:47 --> Input Class Initialized
INFO - 2023-08-23 20:13:47 --> Output Class Initialized
INFO - 2023-08-23 20:13:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:13:47 --> Language Class Initialized
DEBUG - 2023-08-23 20:13:47 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:47 --> Language Class Initialized
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:13:47 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:47 --> Config Class Initialized
INFO - 2023-08-23 20:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:47 --> URI Class Initialized
INFO - 2023-08-23 20:13:47 --> Router Class Initialized
INFO - 2023-08-23 20:13:47 --> Output Class Initialized
INFO - 2023-08-23 20:13:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:47 --> Input Class Initialized
INFO - 2023-08-23 20:13:47 --> Language Class Initialized
ERROR - 2023-08-23 20:13:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:13:47 --> URI Class Initialized
INFO - 2023-08-23 20:13:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:13:47 --> Security Class Initialized
INFO - 2023-08-23 20:13:48 --> URI Class Initialized
INFO - 2023-08-23 20:13:48 --> Router Class Initialized
INFO - 2023-08-23 20:13:48 --> Router Class Initialized
INFO - 2023-08-23 20:13:48 --> Output Class Initialized
INFO - 2023-08-23 20:13:48 --> Output Class Initialized
INFO - 2023-08-23 20:13:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:48 --> Security Class Initialized
INFO - 2023-08-23 20:13:48 --> Input Class Initialized
DEBUG - 2023-08-23 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:13:48 --> Language Class Initialized
DEBUG - 2023-08-23 20:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:13:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:13:48 --> Input Class Initialized
INFO - 2023-08-23 20:13:48 --> Input Class Initialized
INFO - 2023-08-23 20:13:48 --> Language Class Initialized
INFO - 2023-08-23 20:13:48 --> Language Class Initialized
ERROR - 2023-08-23 20:13:48 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:13:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:14:17 --> Config Class Initialized
INFO - 2023-08-23 20:14:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:14:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:18 --> URI Class Initialized
INFO - 2023-08-23 20:14:18 --> Router Class Initialized
INFO - 2023-08-23 20:14:18 --> Output Class Initialized
INFO - 2023-08-23 20:14:18 --> Security Class Initialized
DEBUG - 2023-08-23 20:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:18 --> Input Class Initialized
INFO - 2023-08-23 20:14:18 --> Language Class Initialized
INFO - 2023-08-23 20:14:18 --> Loader Class Initialized
INFO - 2023-08-23 20:14:18 --> Helper loaded: url_helper
INFO - 2023-08-23 20:14:18 --> Helper loaded: file_helper
INFO - 2023-08-23 20:14:18 --> Database Driver Class Initialized
INFO - 2023-08-23 20:14:18 --> Email Class Initialized
DEBUG - 2023-08-23 20:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:14:18 --> Controller Class Initialized
INFO - 2023-08-23 20:14:18 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:14:18 --> Model "Home_model" initialized
INFO - 2023-08-23 20:14:18 --> Helper loaded: download_helper
INFO - 2023-08-23 20:14:18 --> Helper loaded: form_helper
INFO - 2023-08-23 20:14:18 --> Form Validation Class Initialized
INFO - 2023-08-23 20:14:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:14:18 --> Final output sent to browser
DEBUG - 2023-08-23 20:14:19 --> Total execution time: 0.9577
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:20 --> URI Class Initialized
INFO - 2023-08-23 20:14:20 --> Router Class Initialized
INFO - 2023-08-23 20:14:20 --> Output Class Initialized
INFO - 2023-08-23 20:14:20 --> Security Class Initialized
DEBUG - 2023-08-23 20:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:20 --> Input Class Initialized
INFO - 2023-08-23 20:14:20 --> Language Class Initialized
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:14:20 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:20 --> URI Class Initialized
INFO - 2023-08-23 20:14:20 --> Router Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:20 --> Output Class Initialized
INFO - 2023-08-23 20:14:20 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:20 --> URI Class Initialized
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:14:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:20 --> Config Class Initialized
INFO - 2023-08-23 20:14:20 --> URI Class Initialized
INFO - 2023-08-23 20:14:20 --> Router Class Initialized
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:20 --> Security Class Initialized
INFO - 2023-08-23 20:14:20 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:21 --> URI Class Initialized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
INFO - 2023-08-23 20:14:21 --> Router Class Initialized
INFO - 2023-08-23 20:14:21 --> Router Class Initialized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> URI Class Initialized
INFO - 2023-08-23 20:14:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> Input Class Initialized
INFO - 2023-08-23 20:14:21 --> Language Class Initialized
ERROR - 2023-08-23 20:14:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
INFO - 2023-08-23 20:14:21 --> Router Class Initialized
DEBUG - 2023-08-23 20:14:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:21 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> Input Class Initialized
INFO - 2023-08-23 20:14:21 --> Language Class Initialized
INFO - 2023-08-23 20:14:21 --> Config Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> Input Class Initialized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
INFO - 2023-08-23 20:14:21 --> URI Class Initialized
INFO - 2023-08-23 20:14:21 --> Hooks Class Initialized
ERROR - 2023-08-23 20:14:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:14:21 --> Input Class Initialized
INFO - 2023-08-23 20:14:21 --> Language Class Initialized
ERROR - 2023-08-23 20:14:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:14:21 --> Language Class Initialized
DEBUG - 2023-08-23 20:14:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
INFO - 2023-08-23 20:14:21 --> Router Class Initialized
ERROR - 2023-08-23 20:14:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:14:21 --> Config Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
INFO - 2023-08-23 20:14:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:21 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:21 --> URI Class Initialized
INFO - 2023-08-23 20:14:21 --> Router Class Initialized
INFO - 2023-08-23 20:14:21 --> Output Class Initialized
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:21 --> Input Class Initialized
INFO - 2023-08-23 20:14:21 --> Language Class Initialized
ERROR - 2023-08-23 20:14:21 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:14:21 --> Config Class Initialized
INFO - 2023-08-23 20:14:21 --> Security Class Initialized
INFO - 2023-08-23 20:14:22 --> Input Class Initialized
INFO - 2023-08-23 20:14:22 --> Config Class Initialized
DEBUG - 2023-08-23 20:14:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:22 --> Language Class Initialized
INFO - 2023-08-23 20:14:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:22 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:14:22 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:14:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:22 --> Config Class Initialized
INFO - 2023-08-23 20:14:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:22 --> URI Class Initialized
DEBUG - 2023-08-23 20:14:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:22 --> URI Class Initialized
INFO - 2023-08-23 20:14:22 --> Router Class Initialized
INFO - 2023-08-23 20:14:22 --> Output Class Initialized
INFO - 2023-08-23 20:14:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:22 --> Input Class Initialized
INFO - 2023-08-23 20:14:22 --> Language Class Initialized
ERROR - 2023-08-23 20:14:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:14:22 --> Router Class Initialized
INFO - 2023-08-23 20:14:22 --> Input Class Initialized
INFO - 2023-08-23 20:14:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:14:22 --> Language Class Initialized
INFO - 2023-08-23 20:14:22 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:14:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:14:22 --> Output Class Initialized
INFO - 2023-08-23 20:14:22 --> URI Class Initialized
ERROR - 2023-08-23 20:14:22 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:14:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:14:22 --> Security Class Initialized
INFO - 2023-08-23 20:14:22 --> URI Class Initialized
INFO - 2023-08-23 20:14:22 --> Router Class Initialized
INFO - 2023-08-23 20:14:22 --> Output Class Initialized
DEBUG - 2023-08-23 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:22 --> Router Class Initialized
INFO - 2023-08-23 20:14:22 --> Input Class Initialized
INFO - 2023-08-23 20:14:22 --> Security Class Initialized
INFO - 2023-08-23 20:14:22 --> Output Class Initialized
DEBUG - 2023-08-23 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:22 --> Security Class Initialized
INFO - 2023-08-23 20:14:23 --> Input Class Initialized
INFO - 2023-08-23 20:14:23 --> Language Class Initialized
ERROR - 2023-08-23 20:14:23 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:14:23 --> Input Class Initialized
INFO - 2023-08-23 20:14:23 --> Language Class Initialized
INFO - 2023-08-23 20:14:23 --> Language Class Initialized
ERROR - 2023-08-23 20:14:23 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:14:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:47 --> Config Class Initialized
INFO - 2023-08-23 20:15:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:47 --> URI Class Initialized
INFO - 2023-08-23 20:15:47 --> Router Class Initialized
INFO - 2023-08-23 20:15:47 --> Output Class Initialized
INFO - 2023-08-23 20:15:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:47 --> Input Class Initialized
INFO - 2023-08-23 20:15:47 --> Language Class Initialized
INFO - 2023-08-23 20:15:47 --> Loader Class Initialized
INFO - 2023-08-23 20:15:47 --> Helper loaded: url_helper
INFO - 2023-08-23 20:15:47 --> Helper loaded: file_helper
INFO - 2023-08-23 20:15:47 --> Database Driver Class Initialized
INFO - 2023-08-23 20:15:47 --> Email Class Initialized
DEBUG - 2023-08-23 20:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:15:48 --> Controller Class Initialized
INFO - 2023-08-23 20:15:48 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:15:48 --> Model "Home_model" initialized
INFO - 2023-08-23 20:15:48 --> Helper loaded: download_helper
INFO - 2023-08-23 20:15:48 --> Helper loaded: form_helper
INFO - 2023-08-23 20:15:48 --> Form Validation Class Initialized
INFO - 2023-08-23 20:15:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:15:48 --> Final output sent to browser
DEBUG - 2023-08-23 20:15:48 --> Total execution time: 1.0274
INFO - 2023-08-23 20:15:49 --> Config Class Initialized
INFO - 2023-08-23 20:15:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:49 --> URI Class Initialized
INFO - 2023-08-23 20:15:49 --> Router Class Initialized
INFO - 2023-08-23 20:15:49 --> Output Class Initialized
INFO - 2023-08-23 20:15:49 --> Security Class Initialized
DEBUG - 2023-08-23 20:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:49 --> Input Class Initialized
INFO - 2023-08-23 20:15:49 --> Language Class Initialized
ERROR - 2023-08-23 20:15:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:15:49 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:50 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:50 --> URI Class Initialized
INFO - 2023-08-23 20:15:50 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
INFO - 2023-08-23 20:15:50 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Router Class Initialized
INFO - 2023-08-23 20:15:50 --> Output Class Initialized
INFO - 2023-08-23 20:15:50 --> Security Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
INFO - 2023-08-23 20:15:50 --> URI Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:50 --> Router Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:50 --> Config Class Initialized
INFO - 2023-08-23 20:15:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:50 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:50 --> Output Class Initialized
INFO - 2023-08-23 20:15:50 --> URI Class Initialized
INFO - 2023-08-23 20:15:50 --> Input Class Initialized
INFO - 2023-08-23 20:15:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:50 --> Security Class Initialized
INFO - 2023-08-23 20:15:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
INFO - 2023-08-23 20:15:51 --> URI Class Initialized
INFO - 2023-08-23 20:15:51 --> URI Class Initialized
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
INFO - 2023-08-23 20:15:51 --> URI Class Initialized
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
INFO - 2023-08-23 20:15:51 --> Config Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
INFO - 2023-08-23 20:15:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
DEBUG - 2023-08-23 20:15:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> URI Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:15:51 --> Config Class Initialized
INFO - 2023-08-23 20:15:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:15:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:51 --> URI Class Initialized
INFO - 2023-08-23 20:15:51 --> Router Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:51 --> Input Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:51 --> Config Class Initialized
INFO - 2023-08-23 20:15:51 --> Output Class Initialized
INFO - 2023-08-23 20:15:51 --> Language Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:15:51 --> Security Class Initialized
INFO - 2023-08-23 20:15:51 --> Hooks Class Initialized
ERROR - 2023-08-23 20:15:51 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:52 --> Config Class Initialized
DEBUG - 2023-08-23 20:15:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:52 --> Input Class Initialized
INFO - 2023-08-23 20:15:52 --> Hooks Class Initialized
INFO - 2023-08-23 20:15:52 --> Language Class Initialized
INFO - 2023-08-23 20:15:52 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:52 --> Config Class Initialized
INFO - 2023-08-23 20:15:52 --> URI Class Initialized
ERROR - 2023-08-23 20:15:52 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:15:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:53 --> Hooks Class Initialized
INFO - 2023-08-23 20:15:53 --> Router Class Initialized
INFO - 2023-08-23 20:15:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:15:53 --> Output Class Initialized
INFO - 2023-08-23 20:15:53 --> URI Class Initialized
DEBUG - 2023-08-23 20:15:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:15:54 --> Security Class Initialized
INFO - 2023-08-23 20:15:54 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:54 --> Input Class Initialized
INFO - 2023-08-23 20:15:54 --> Router Class Initialized
INFO - 2023-08-23 20:15:54 --> Language Class Initialized
INFO - 2023-08-23 20:15:54 --> Output Class Initialized
INFO - 2023-08-23 20:15:54 --> URI Class Initialized
INFO - 2023-08-23 20:15:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:54 --> Input Class Initialized
ERROR - 2023-08-23 20:15:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:54 --> Router Class Initialized
INFO - 2023-08-23 20:15:54 --> Language Class Initialized
INFO - 2023-08-23 20:15:54 --> Output Class Initialized
ERROR - 2023-08-23 20:15:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:15:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:15:54 --> Input Class Initialized
INFO - 2023-08-23 20:15:54 --> Language Class Initialized
ERROR - 2023-08-23 20:15:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Input Class Initialized
INFO - 2023-08-23 20:16:47 --> Language Class Initialized
INFO - 2023-08-23 20:16:47 --> Loader Class Initialized
INFO - 2023-08-23 20:16:47 --> Helper loaded: url_helper
INFO - 2023-08-23 20:16:47 --> Helper loaded: file_helper
INFO - 2023-08-23 20:16:47 --> Database Driver Class Initialized
INFO - 2023-08-23 20:16:47 --> Email Class Initialized
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> Controller Class Initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Input Class Initialized
INFO - 2023-08-23 20:16:47 --> Model "Home_model" initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Helper loaded: download_helper
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Language Class Initialized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
INFO - 2023-08-23 20:16:47 --> Helper loaded: form_helper
INFO - 2023-08-23 20:16:47 --> Form Validation Class Initialized
ERROR - 2023-08-23 20:16:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Input Class Initialized
INFO - 2023-08-23 20:16:47 --> Language Class Initialized
ERROR - 2023-08-23 20:16:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
ERROR - 2023-08-23 20:16:47 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `message`, `services_ids`, `status`, `created_at`) VALUES ('we', 'adeee@gmil.com', '8712186367', 'rwer', NULL, NULL, '2023-08-23 20:16:47')
INFO - 2023-08-23 20:16:47 --> Config Class Initialized
INFO - 2023-08-23 20:16:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:47 --> URI Class Initialized
INFO - 2023-08-23 20:16:47 --> Router Class Initialized
INFO - 2023-08-23 20:16:47 --> Output Class Initialized
INFO - 2023-08-23 20:16:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Input Class Initialized
INFO - 2023-08-23 20:16:47 --> Language Class Initialized
ERROR - 2023-08-23 20:16:47 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:47 --> Input Class Initialized
INFO - 2023-08-23 20:16:47 --> Language Class Initialized
ERROR - 2023-08-23 20:16:47 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
INFO - 2023-08-23 20:16:48 --> Config Class Initialized
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
INFO - 2023-08-23 20:16:48 --> Loader Class Initialized
INFO - 2023-08-23 20:16:48 --> Helper loaded: url_helper
INFO - 2023-08-23 20:16:48 --> Helper loaded: file_helper
INFO - 2023-08-23 20:16:48 --> Database Driver Class Initialized
INFO - 2023-08-23 20:16:48 --> Email Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
INFO - 2023-08-23 20:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:16:48 --> Controller Class Initialized
INFO - 2023-08-23 20:16:48 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:16:48 --> Model "Home_model" initialized
INFO - 2023-08-23 20:16:48 --> Helper loaded: download_helper
INFO - 2023-08-23 20:16:48 --> Helper loaded: form_helper
INFO - 2023-08-23 20:16:48 --> Form Validation Class Initialized
INFO - 2023-08-23 20:16:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:16:48 --> Final output sent to browser
DEBUG - 2023-08-23 20:16:48 --> Total execution time: 1.1194
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:48 --> Config Class Initialized
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:48 --> Config Class Initialized
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:48 --> Config Class Initialized
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:48 --> Config Class Initialized
INFO - 2023-08-23 20:16:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:48 --> URI Class Initialized
INFO - 2023-08-23 20:16:48 --> Router Class Initialized
INFO - 2023-08-23 20:16:48 --> Output Class Initialized
INFO - 2023-08-23 20:16:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:48 --> Input Class Initialized
INFO - 2023-08-23 20:16:48 --> Language Class Initialized
ERROR - 2023-08-23 20:16:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:49 --> Config Class Initialized
INFO - 2023-08-23 20:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:49 --> URI Class Initialized
INFO - 2023-08-23 20:16:49 --> Router Class Initialized
INFO - 2023-08-23 20:16:49 --> Output Class Initialized
INFO - 2023-08-23 20:16:49 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:49 --> Input Class Initialized
INFO - 2023-08-23 20:16:49 --> Language Class Initialized
ERROR - 2023-08-23 20:16:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:49 --> Config Class Initialized
INFO - 2023-08-23 20:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:49 --> URI Class Initialized
INFO - 2023-08-23 20:16:49 --> Router Class Initialized
INFO - 2023-08-23 20:16:49 --> Output Class Initialized
INFO - 2023-08-23 20:16:49 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:49 --> Input Class Initialized
INFO - 2023-08-23 20:16:49 --> Language Class Initialized
ERROR - 2023-08-23 20:16:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:49 --> Config Class Initialized
INFO - 2023-08-23 20:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:49 --> URI Class Initialized
INFO - 2023-08-23 20:16:49 --> Router Class Initialized
INFO - 2023-08-23 20:16:49 --> Output Class Initialized
INFO - 2023-08-23 20:16:49 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:49 --> Input Class Initialized
INFO - 2023-08-23 20:16:49 --> Language Class Initialized
ERROR - 2023-08-23 20:16:49 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:49 --> Config Class Initialized
INFO - 2023-08-23 20:16:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:49 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:16:50 --> Config Class Initialized
INFO - 2023-08-23 20:16:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:16:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:16:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:16:50 --> URI Class Initialized
INFO - 2023-08-23 20:16:50 --> Router Class Initialized
INFO - 2023-08-23 20:16:50 --> Output Class Initialized
INFO - 2023-08-23 20:16:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:16:50 --> Input Class Initialized
INFO - 2023-08-23 20:16:50 --> Language Class Initialized
ERROR - 2023-08-23 20:16:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:30 --> Config Class Initialized
INFO - 2023-08-23 20:17:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:30 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:30 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:30 --> URI Class Initialized
INFO - 2023-08-23 20:17:30 --> Router Class Initialized
INFO - 2023-08-23 20:17:30 --> Output Class Initialized
INFO - 2023-08-23 20:17:30 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:30 --> Input Class Initialized
INFO - 2023-08-23 20:17:30 --> Language Class Initialized
INFO - 2023-08-23 20:17:30 --> Loader Class Initialized
INFO - 2023-08-23 20:17:30 --> Helper loaded: url_helper
INFO - 2023-08-23 20:17:30 --> Helper loaded: file_helper
INFO - 2023-08-23 20:17:30 --> Database Driver Class Initialized
INFO - 2023-08-23 20:17:30 --> Email Class Initialized
DEBUG - 2023-08-23 20:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:17:30 --> Controller Class Initialized
INFO - 2023-08-23 20:17:30 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:17:30 --> Model "Home_model" initialized
INFO - 2023-08-23 20:17:30 --> Helper loaded: download_helper
INFO - 2023-08-23 20:17:30 --> Helper loaded: form_helper
INFO - 2023-08-23 20:17:30 --> Form Validation Class Initialized
INFO - 2023-08-23 20:17:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:17:31 --> Final output sent to browser
DEBUG - 2023-08-23 20:17:31 --> Total execution time: 0.8044
INFO - 2023-08-23 20:17:31 --> Config Class Initialized
INFO - 2023-08-23 20:17:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:31 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:31 --> URI Class Initialized
INFO - 2023-08-23 20:17:31 --> Router Class Initialized
INFO - 2023-08-23 20:17:31 --> Output Class Initialized
INFO - 2023-08-23 20:17:31 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:31 --> Input Class Initialized
INFO - 2023-08-23 20:17:31 --> Language Class Initialized
ERROR - 2023-08-23 20:17:31 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:32 --> Config Class Initialized
INFO - 2023-08-23 20:17:32 --> Config Class Initialized
INFO - 2023-08-23 20:17:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> Router Class Initialized
INFO - 2023-08-23 20:17:33 --> Router Class Initialized
INFO - 2023-08-23 20:17:33 --> Output Class Initialized
INFO - 2023-08-23 20:17:33 --> Output Class Initialized
INFO - 2023-08-23 20:17:33 --> Security Class Initialized
INFO - 2023-08-23 20:17:33 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:33 --> Input Class Initialized
INFO - 2023-08-23 20:17:33 --> Input Class Initialized
INFO - 2023-08-23 20:17:33 --> Language Class Initialized
INFO - 2023-08-23 20:17:33 --> Language Class Initialized
ERROR - 2023-08-23 20:17:33 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:33 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:33 --> Router Class Initialized
INFO - 2023-08-23 20:17:33 --> Output Class Initialized
INFO - 2023-08-23 20:17:33 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:33 --> Input Class Initialized
INFO - 2023-08-23 20:17:33 --> Language Class Initialized
ERROR - 2023-08-23 20:17:33 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> Router Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:33 --> URI Class Initialized
INFO - 2023-08-23 20:17:33 --> Config Class Initialized
INFO - 2023-08-23 20:17:34 --> URI Class Initialized
INFO - 2023-08-23 20:17:34 --> URI Class Initialized
INFO - 2023-08-23 20:17:34 --> Router Class Initialized
INFO - 2023-08-23 20:17:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:34 --> Router Class Initialized
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
DEBUG - 2023-08-23 20:17:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:34 --> Router Class Initialized
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
INFO - 2023-08-23 20:17:34 --> Router Class Initialized
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
INFO - 2023-08-23 20:17:34 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> URI Class Initialized
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
INFO - 2023-08-23 20:17:34 --> Router Class Initialized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:34 --> Output Class Initialized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
INFO - 2023-08-23 20:17:34 --> Security Class Initialized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:34 --> Config Class Initialized
INFO - 2023-08-23 20:17:34 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:34 --> Input Class Initialized
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:34 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:34 --> Language Class Initialized
DEBUG - 2023-08-23 20:17:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:34 --> Hooks Class Initialized
ERROR - 2023-08-23 20:17:34 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:34 --> Config Class Initialized
INFO - 2023-08-23 20:17:35 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:17:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:35 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:35 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:35 --> URI Class Initialized
INFO - 2023-08-23 20:17:35 --> Router Class Initialized
INFO - 2023-08-23 20:17:35 --> Output Class Initialized
INFO - 2023-08-23 20:17:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:35 --> Input Class Initialized
INFO - 2023-08-23 20:17:35 --> Language Class Initialized
ERROR - 2023-08-23 20:17:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:35 --> URI Class Initialized
INFO - 2023-08-23 20:17:35 --> Router Class Initialized
INFO - 2023-08-23 20:17:35 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:35 --> Output Class Initialized
INFO - 2023-08-23 20:17:35 --> URI Class Initialized
INFO - 2023-08-23 20:17:35 --> Security Class Initialized
INFO - 2023-08-23 20:17:35 --> Router Class Initialized
DEBUG - 2023-08-23 20:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:35 --> Output Class Initialized
INFO - 2023-08-23 20:17:35 --> Input Class Initialized
INFO - 2023-08-23 20:17:35 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:35 --> Input Class Initialized
INFO - 2023-08-23 20:17:35 --> Language Class Initialized
INFO - 2023-08-23 20:17:35 --> Language Class Initialized
ERROR - 2023-08-23 20:17:35 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:17:35 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:39 --> Config Class Initialized
INFO - 2023-08-23 20:17:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:39 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:39 --> URI Class Initialized
INFO - 2023-08-23 20:17:39 --> Router Class Initialized
INFO - 2023-08-23 20:17:39 --> Output Class Initialized
INFO - 2023-08-23 20:17:39 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:39 --> Input Class Initialized
INFO - 2023-08-23 20:17:39 --> Language Class Initialized
INFO - 2023-08-23 20:17:39 --> Loader Class Initialized
INFO - 2023-08-23 20:17:39 --> Helper loaded: url_helper
INFO - 2023-08-23 20:17:39 --> Helper loaded: file_helper
INFO - 2023-08-23 20:17:39 --> Database Driver Class Initialized
INFO - 2023-08-23 20:17:39 --> Email Class Initialized
DEBUG - 2023-08-23 20:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:17:39 --> Controller Class Initialized
INFO - 2023-08-23 20:17:40 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:17:40 --> Model "Home_model" initialized
INFO - 2023-08-23 20:17:40 --> Helper loaded: download_helper
INFO - 2023-08-23 20:17:40 --> Helper loaded: form_helper
INFO - 2023-08-23 20:17:40 --> Form Validation Class Initialized
INFO - 2023-08-23 20:17:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:17:40 --> Final output sent to browser
DEBUG - 2023-08-23 20:17:40 --> Total execution time: 0.8524
INFO - 2023-08-23 20:17:41 --> Config Class Initialized
INFO - 2023-08-23 20:17:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:41 --> URI Class Initialized
INFO - 2023-08-23 20:17:41 --> Router Class Initialized
INFO - 2023-08-23 20:17:41 --> Output Class Initialized
INFO - 2023-08-23 20:17:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:41 --> Input Class Initialized
INFO - 2023-08-23 20:17:41 --> Language Class Initialized
ERROR - 2023-08-23 20:17:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:42 --> Config Class Initialized
INFO - 2023-08-23 20:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:42 --> URI Class Initialized
INFO - 2023-08-23 20:17:42 --> Router Class Initialized
INFO - 2023-08-23 20:17:42 --> Output Class Initialized
INFO - 2023-08-23 20:17:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:42 --> Input Class Initialized
INFO - 2023-08-23 20:17:42 --> Language Class Initialized
ERROR - 2023-08-23 20:17:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:42 --> Config Class Initialized
INFO - 2023-08-23 20:17:42 --> Config Class Initialized
INFO - 2023-08-23 20:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:42 --> URI Class Initialized
INFO - 2023-08-23 20:17:42 --> Router Class Initialized
INFO - 2023-08-23 20:17:42 --> Output Class Initialized
INFO - 2023-08-23 20:17:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:42 --> Input Class Initialized
INFO - 2023-08-23 20:17:42 --> Language Class Initialized
ERROR - 2023-08-23 20:17:42 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:42 --> Config Class Initialized
INFO - 2023-08-23 20:17:42 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:42 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:42 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:42 --> URI Class Initialized
INFO - 2023-08-23 20:17:42 --> Router Class Initialized
INFO - 2023-08-23 20:17:42 --> Output Class Initialized
INFO - 2023-08-23 20:17:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:42 --> Input Class Initialized
INFO - 2023-08-23 20:17:42 --> Language Class Initialized
ERROR - 2023-08-23 20:17:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:42 --> Config Class Initialized
INFO - 2023-08-23 20:17:43 --> Config Class Initialized
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:43 --> Config Class Initialized
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:43 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:43 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:43 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:43 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:43 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> URI Class Initialized
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
DEBUG - 2023-08-23 20:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
INFO - 2023-08-23 20:17:43 --> Input Class Initialized
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
INFO - 2023-08-23 20:17:43 --> Router Class Initialized
DEBUG - 2023-08-23 20:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
INFO - 2023-08-23 20:17:43 --> Language Class Initialized
INFO - 2023-08-23 20:17:43 --> Output Class Initialized
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
ERROR - 2023-08-23 20:17:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:43 --> Input Class Initialized
INFO - 2023-08-23 20:17:43 --> Language Class Initialized
ERROR - 2023-08-23 20:17:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
INFO - 2023-08-23 20:17:43 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:43 --> Input Class Initialized
DEBUG - 2023-08-23 20:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:43 --> Input Class Initialized
INFO - 2023-08-23 20:17:43 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
INFO - 2023-08-23 20:17:44 --> Config Class Initialized
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
INFO - 2023-08-23 20:17:44 --> Input Class Initialized
INFO - 2023-08-23 20:17:44 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:44 --> URI Class Initialized
INFO - 2023-08-23 20:17:44 --> Router Class Initialized
INFO - 2023-08-23 20:17:44 --> Output Class Initialized
INFO - 2023-08-23 20:17:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:44 --> Input Class Initialized
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:44 --> Input Class Initialized
INFO - 2023-08-23 20:17:44 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:17:44 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:44 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:44 --> URI Class Initialized
INFO - 2023-08-23 20:17:44 --> Router Class Initialized
INFO - 2023-08-23 20:17:44 --> Output Class Initialized
INFO - 2023-08-23 20:17:44 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:44 --> Input Class Initialized
INFO - 2023-08-23 20:17:44 --> Language Class Initialized
ERROR - 2023-08-23 20:17:44 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:47 --> Config Class Initialized
INFO - 2023-08-23 20:17:47 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:47 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:47 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:47 --> URI Class Initialized
INFO - 2023-08-23 20:17:47 --> Router Class Initialized
INFO - 2023-08-23 20:17:47 --> Output Class Initialized
INFO - 2023-08-23 20:17:47 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:47 --> Input Class Initialized
INFO - 2023-08-23 20:17:47 --> Language Class Initialized
INFO - 2023-08-23 20:17:47 --> Loader Class Initialized
INFO - 2023-08-23 20:17:47 --> Helper loaded: url_helper
INFO - 2023-08-23 20:17:47 --> Helper loaded: file_helper
INFO - 2023-08-23 20:17:47 --> Database Driver Class Initialized
INFO - 2023-08-23 20:17:47 --> Email Class Initialized
DEBUG - 2023-08-23 20:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:17:47 --> Controller Class Initialized
INFO - 2023-08-23 20:17:47 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:17:47 --> Model "Home_model" initialized
INFO - 2023-08-23 20:17:47 --> Helper loaded: download_helper
INFO - 2023-08-23 20:17:47 --> Helper loaded: form_helper
INFO - 2023-08-23 20:17:47 --> Form Validation Class Initialized
INFO - 2023-08-23 20:17:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:17:47 --> Final output sent to browser
DEBUG - 2023-08-23 20:17:48 --> Total execution time: 0.9121
INFO - 2023-08-23 20:17:48 --> Config Class Initialized
INFO - 2023-08-23 20:17:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:48 --> URI Class Initialized
INFO - 2023-08-23 20:17:48 --> Router Class Initialized
INFO - 2023-08-23 20:17:48 --> Output Class Initialized
INFO - 2023-08-23 20:17:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:48 --> Input Class Initialized
INFO - 2023-08-23 20:17:48 --> Language Class Initialized
ERROR - 2023-08-23 20:17:48 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:48 --> Config Class Initialized
INFO - 2023-08-23 20:17:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:48 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:48 --> URI Class Initialized
INFO - 2023-08-23 20:17:48 --> Router Class Initialized
INFO - 2023-08-23 20:17:48 --> Output Class Initialized
INFO - 2023-08-23 20:17:48 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:49 --> Config Class Initialized
INFO - 2023-08-23 20:17:49 --> Config Class Initialized
INFO - 2023-08-23 20:17:49 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:49 --> Config Class Initialized
DEBUG - 2023-08-23 20:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:49 --> Config Class Initialized
INFO - 2023-08-23 20:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:49 --> Config Class Initialized
INFO - 2023-08-23 20:17:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:49 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:49 --> URI Class Initialized
INFO - 2023-08-23 20:17:49 --> Router Class Initialized
INFO - 2023-08-23 20:17:49 --> Output Class Initialized
INFO - 2023-08-23 20:17:49 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:49 --> Input Class Initialized
INFO - 2023-08-23 20:17:49 --> Language Class Initialized
ERROR - 2023-08-23 20:17:49 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:50 --> Input Class Initialized
INFO - 2023-08-23 20:17:50 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:50 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:50 --> Language Class Initialized
DEBUG - 2023-08-23 20:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:50 --> Config Class Initialized
INFO - 2023-08-23 20:17:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:50 --> URI Class Initialized
INFO - 2023-08-23 20:17:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:50 --> URI Class Initialized
INFO - 2023-08-23 20:17:50 --> Router Class Initialized
INFO - 2023-08-23 20:17:50 --> Output Class Initialized
INFO - 2023-08-23 20:17:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:50 --> Input Class Initialized
INFO - 2023-08-23 20:17:50 --> Language Class Initialized
ERROR - 2023-08-23 20:17:50 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:50 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:17:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:50 --> Router Class Initialized
INFO - 2023-08-23 20:17:50 --> URI Class Initialized
INFO - 2023-08-23 20:17:50 --> URI Class Initialized
INFO - 2023-08-23 20:17:50 --> Router Class Initialized
INFO - 2023-08-23 20:17:50 --> Router Class Initialized
INFO - 2023-08-23 20:17:50 --> Output Class Initialized
INFO - 2023-08-23 20:17:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:50 --> Input Class Initialized
INFO - 2023-08-23 20:17:50 --> Language Class Initialized
ERROR - 2023-08-23 20:17:50 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:50 --> Output Class Initialized
INFO - 2023-08-23 20:17:50 --> URI Class Initialized
INFO - 2023-08-23 20:17:50 --> Config Class Initialized
INFO - 2023-08-23 20:17:50 --> Output Class Initialized
INFO - 2023-08-23 20:17:50 --> Config Class Initialized
INFO - 2023-08-23 20:17:50 --> Config Class Initialized
INFO - 2023-08-23 20:17:51 --> Router Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
INFO - 2023-08-23 20:17:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
INFO - 2023-08-23 20:17:51 --> Output Class Initialized
DEBUG - 2023-08-23 20:17:51 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:51 --> URI Class Initialized
INFO - 2023-08-23 20:17:51 --> Router Class Initialized
INFO - 2023-08-23 20:17:51 --> Output Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:51 --> Input Class Initialized
INFO - 2023-08-23 20:17:51 --> Language Class Initialized
ERROR - 2023-08-23 20:17:51 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
INFO - 2023-08-23 20:17:51 --> Config Class Initialized
INFO - 2023-08-23 20:17:51 --> URI Class Initialized
DEBUG - 2023-08-23 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:51 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:51 --> Input Class Initialized
INFO - 2023-08-23 20:17:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:51 --> Input Class Initialized
INFO - 2023-08-23 20:17:51 --> Language Class Initialized
ERROR - 2023-08-23 20:17:51 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:51 --> Router Class Initialized
INFO - 2023-08-23 20:17:51 --> Input Class Initialized
INFO - 2023-08-23 20:17:51 --> Language Class Initialized
INFO - 2023-08-23 20:17:51 --> URI Class Initialized
DEBUG - 2023-08-23 20:17:51 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:51 --> Language Class Initialized
INFO - 2023-08-23 20:17:51 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:17:51 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:51 --> Router Class Initialized
INFO - 2023-08-23 20:17:51 --> Config Class Initialized
INFO - 2023-08-23 20:17:51 --> Output Class Initialized
INFO - 2023-08-23 20:17:51 --> Output Class Initialized
INFO - 2023-08-23 20:17:51 --> URI Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
INFO - 2023-08-23 20:17:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:51 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:52 --> Input Class Initialized
INFO - 2023-08-23 20:17:52 --> Router Class Initialized
DEBUG - 2023-08-23 20:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:17:52 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:52 --> Input Class Initialized
INFO - 2023-08-23 20:17:52 --> Output Class Initialized
INFO - 2023-08-23 20:17:52 --> Language Class Initialized
INFO - 2023-08-23 20:17:52 --> Security Class Initialized
INFO - 2023-08-23 20:17:52 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:17:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:52 --> Language Class Initialized
INFO - 2023-08-23 20:17:52 --> URI Class Initialized
INFO - 2023-08-23 20:17:52 --> Router Class Initialized
DEBUG - 2023-08-23 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:52 --> Input Class Initialized
ERROR - 2023-08-23 20:17:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:52 --> Language Class Initialized
INFO - 2023-08-23 20:17:52 --> Output Class Initialized
ERROR - 2023-08-23 20:17:52 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:52 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:53 --> Input Class Initialized
INFO - 2023-08-23 20:17:53 --> Language Class Initialized
ERROR - 2023-08-23 20:17:53 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:17:54 --> Config Class Initialized
INFO - 2023-08-23 20:17:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:54 --> URI Class Initialized
INFO - 2023-08-23 20:17:54 --> Router Class Initialized
INFO - 2023-08-23 20:17:54 --> Output Class Initialized
INFO - 2023-08-23 20:17:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:55 --> Input Class Initialized
INFO - 2023-08-23 20:17:55 --> Language Class Initialized
INFO - 2023-08-23 20:17:55 --> Loader Class Initialized
INFO - 2023-08-23 20:17:55 --> Helper loaded: url_helper
INFO - 2023-08-23 20:17:55 --> Helper loaded: file_helper
INFO - 2023-08-23 20:17:55 --> Database Driver Class Initialized
INFO - 2023-08-23 20:17:55 --> Email Class Initialized
DEBUG - 2023-08-23 20:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:17:55 --> Controller Class Initialized
INFO - 2023-08-23 20:17:55 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:17:55 --> Model "Home_model" initialized
INFO - 2023-08-23 20:17:55 --> Helper loaded: download_helper
INFO - 2023-08-23 20:17:55 --> Helper loaded: form_helper
INFO - 2023-08-23 20:17:55 --> Form Validation Class Initialized
INFO - 2023-08-23 20:17:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:17:55 --> Final output sent to browser
DEBUG - 2023-08-23 20:17:55 --> Total execution time: 0.5018
INFO - 2023-08-23 20:17:55 --> Config Class Initialized
INFO - 2023-08-23 20:17:55 --> Config Class Initialized
INFO - 2023-08-23 20:17:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:56 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:17:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:56 --> URI Class Initialized
INFO - 2023-08-23 20:17:56 --> URI Class Initialized
INFO - 2023-08-23 20:17:56 --> Router Class Initialized
INFO - 2023-08-23 20:17:56 --> Router Class Initialized
INFO - 2023-08-23 20:17:56 --> Output Class Initialized
INFO - 2023-08-23 20:17:56 --> Output Class Initialized
INFO - 2023-08-23 20:17:56 --> Security Class Initialized
INFO - 2023-08-23 20:17:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:56 --> Input Class Initialized
INFO - 2023-08-23 20:17:56 --> Input Class Initialized
INFO - 2023-08-23 20:17:56 --> Language Class Initialized
INFO - 2023-08-23 20:17:56 --> Language Class Initialized
ERROR - 2023-08-23 20:17:56 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:56 --> Config Class Initialized
INFO - 2023-08-23 20:17:56 --> Config Class Initialized
INFO - 2023-08-23 20:17:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:56 --> Config Class Initialized
INFO - 2023-08-23 20:17:56 --> Config Class Initialized
INFO - 2023-08-23 20:17:57 --> Config Class Initialized
INFO - 2023-08-23 20:17:57 --> URI Class Initialized
INFO - 2023-08-23 20:17:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:57 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:57 --> Router Class Initialized
INFO - 2023-08-23 20:17:57 --> Output Class Initialized
INFO - 2023-08-23 20:17:57 --> Security Class Initialized
DEBUG - 2023-08-23 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:57 --> Input Class Initialized
INFO - 2023-08-23 20:17:57 --> Language Class Initialized
ERROR - 2023-08-23 20:17:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:57 --> Hooks Class Initialized
INFO - 2023-08-23 20:17:57 --> URI Class Initialized
DEBUG - 2023-08-23 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:17:57 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:17:57 --> Router Class Initialized
INFO - 2023-08-23 20:17:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:57 --> Output Class Initialized
INFO - 2023-08-23 20:17:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:57 --> Utf8 Class Initialized
INFO - 2023-08-23 20:17:57 --> URI Class Initialized
INFO - 2023-08-23 20:17:57 --> URI Class Initialized
INFO - 2023-08-23 20:17:57 --> Security Class Initialized
INFO - 2023-08-23 20:17:57 --> URI Class Initialized
INFO - 2023-08-23 20:17:57 --> Router Class Initialized
INFO - 2023-08-23 20:17:57 --> Router Class Initialized
INFO - 2023-08-23 20:17:57 --> Router Class Initialized
INFO - 2023-08-23 20:17:57 --> Output Class Initialized
DEBUG - 2023-08-23 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:57 --> Output Class Initialized
INFO - 2023-08-23 20:17:57 --> Output Class Initialized
INFO - 2023-08-23 20:17:57 --> Security Class Initialized
INFO - 2023-08-23 20:17:57 --> Security Class Initialized
INFO - 2023-08-23 20:17:57 --> Security Class Initialized
INFO - 2023-08-23 20:17:57 --> Input Class Initialized
DEBUG - 2023-08-23 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:57 --> Input Class Initialized
INFO - 2023-08-23 20:17:57 --> Language Class Initialized
DEBUG - 2023-08-23 20:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:17:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:57 --> Language Class Initialized
INFO - 2023-08-23 20:17:57 --> Input Class Initialized
DEBUG - 2023-08-23 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:17:57 --> Input Class Initialized
INFO - 2023-08-23 20:17:57 --> Language Class Initialized
ERROR - 2023-08-23 20:17:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:17:57 --> Language Class Initialized
ERROR - 2023-08-23 20:17:57 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:17:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:22 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:18:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:22 --> Config Class Initialized
DEBUG - 2023-08-23 20:18:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:22 --> URI Class Initialized
INFO - 2023-08-23 20:18:22 --> Router Class Initialized
INFO - 2023-08-23 20:18:22 --> Output Class Initialized
INFO - 2023-08-23 20:18:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:22 --> URI Class Initialized
INFO - 2023-08-23 20:18:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:22 --> Input Class Initialized
DEBUG - 2023-08-23 20:18:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:22 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:22 --> Router Class Initialized
INFO - 2023-08-23 20:18:23 --> URI Class Initialized
INFO - 2023-08-23 20:18:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:23 --> Output Class Initialized
INFO - 2023-08-23 20:18:23 --> Router Class Initialized
INFO - 2023-08-23 20:18:23 --> Security Class Initialized
INFO - 2023-08-23 20:18:23 --> Language Class Initialized
DEBUG - 2023-08-23 20:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:18:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:23 --> Output Class Initialized
DEBUG - 2023-08-23 20:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:23 --> URI Class Initialized
ERROR - 2023-08-23 20:18:23 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:23 --> Security Class Initialized
INFO - 2023-08-23 20:18:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:23 --> Router Class Initialized
INFO - 2023-08-23 20:18:23 --> URI Class Initialized
DEBUG - 2023-08-23 20:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:23 --> Output Class Initialized
INFO - 2023-08-23 20:18:23 --> URI Class Initialized
INFO - 2023-08-23 20:18:23 --> Router Class Initialized
INFO - 2023-08-23 20:18:23 --> Input Class Initialized
INFO - 2023-08-23 20:18:23 --> Input Class Initialized
INFO - 2023-08-23 20:18:24 --> Config Class Initialized
INFO - 2023-08-23 20:18:24 --> Router Class Initialized
INFO - 2023-08-23 20:18:24 --> Output Class Initialized
INFO - 2023-08-23 20:18:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:24 --> Input Class Initialized
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
INFO - 2023-08-23 20:18:24 --> Output Class Initialized
INFO - 2023-08-23 20:18:24 --> Security Class Initialized
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
INFO - 2023-08-23 20:18:24 --> Security Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:24 --> Input Class Initialized
INFO - 2023-08-23 20:18:24 --> Hooks Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
DEBUG - 2023-08-23 20:18:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:24 --> Input Class Initialized
INFO - 2023-08-23 20:18:24 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:24 --> URI Class Initialized
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
INFO - 2023-08-23 20:18:24 --> Router Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:24 --> Output Class Initialized
INFO - 2023-08-23 20:18:24 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:24 --> Input Class Initialized
INFO - 2023-08-23 20:18:24 --> Language Class Initialized
ERROR - 2023-08-23 20:18:24 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:26 --> Config Class Initialized
INFO - 2023-08-23 20:18:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:26 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:26 --> URI Class Initialized
INFO - 2023-08-23 20:18:26 --> Router Class Initialized
INFO - 2023-08-23 20:18:26 --> Helper loaded: form_helper
INFO - 2023-08-23 20:18:26 --> Form Validation Class Initialized
INFO - 2023-08-23 20:18:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:18:26 --> Final output sent to browser
DEBUG - 2023-08-23 20:18:26 --> Total execution time: 0.2450
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:28 --> URI Class Initialized
INFO - 2023-08-23 20:18:28 --> Router Class Initialized
INFO - 2023-08-23 20:18:28 --> Output Class Initialized
INFO - 2023-08-23 20:18:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:28 --> Input Class Initialized
INFO - 2023-08-23 20:18:28 --> Language Class Initialized
ERROR - 2023-08-23 20:18:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:28 --> URI Class Initialized
INFO - 2023-08-23 20:18:28 --> Router Class Initialized
INFO - 2023-08-23 20:18:28 --> Output Class Initialized
INFO - 2023-08-23 20:18:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:28 --> Input Class Initialized
INFO - 2023-08-23 20:18:28 --> Language Class Initialized
ERROR - 2023-08-23 20:18:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:28 --> URI Class Initialized
INFO - 2023-08-23 20:18:28 --> Router Class Initialized
INFO - 2023-08-23 20:18:28 --> Output Class Initialized
INFO - 2023-08-23 20:18:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:28 --> Input Class Initialized
INFO - 2023-08-23 20:18:28 --> Language Class Initialized
ERROR - 2023-08-23 20:18:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:28 --> URI Class Initialized
INFO - 2023-08-23 20:18:28 --> Router Class Initialized
INFO - 2023-08-23 20:18:28 --> Output Class Initialized
INFO - 2023-08-23 20:18:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:28 --> Input Class Initialized
INFO - 2023-08-23 20:18:28 --> Language Class Initialized
ERROR - 2023-08-23 20:18:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:18:28 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:18:29 --> Config Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:18:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:18:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:18:29 --> URI Class Initialized
INFO - 2023-08-23 20:18:29 --> Router Class Initialized
INFO - 2023-08-23 20:18:29 --> Output Class Initialized
INFO - 2023-08-23 20:18:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:18:29 --> Input Class Initialized
INFO - 2023-08-23 20:18:29 --> Language Class Initialized
ERROR - 2023-08-23 20:18:29 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:37 --> Config Class Initialized
INFO - 2023-08-23 20:22:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:22:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:37 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:37 --> URI Class Initialized
INFO - 2023-08-23 20:22:37 --> Router Class Initialized
INFO - 2023-08-23 20:22:37 --> Output Class Initialized
INFO - 2023-08-23 20:22:37 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:37 --> Input Class Initialized
INFO - 2023-08-23 20:22:37 --> Language Class Initialized
INFO - 2023-08-23 20:22:37 --> Loader Class Initialized
INFO - 2023-08-23 20:22:37 --> Helper loaded: url_helper
INFO - 2023-08-23 20:22:37 --> Helper loaded: file_helper
INFO - 2023-08-23 20:22:37 --> Database Driver Class Initialized
INFO - 2023-08-23 20:22:37 --> Email Class Initialized
DEBUG - 2023-08-23 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:22:37 --> Controller Class Initialized
INFO - 2023-08-23 20:22:37 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:22:37 --> Model "Home_model" initialized
INFO - 2023-08-23 20:22:37 --> Helper loaded: download_helper
INFO - 2023-08-23 20:22:37 --> Helper loaded: form_helper
INFO - 2023-08-23 20:22:37 --> Form Validation Class Initialized
INFO - 2023-08-23 20:22:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:22:37 --> Final output sent to browser
DEBUG - 2023-08-23 20:22:38 --> Total execution time: 0.9663
INFO - 2023-08-23 20:22:39 --> Config Class Initialized
INFO - 2023-08-23 20:22:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:22:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:39 --> Config Class Initialized
INFO - 2023-08-23 20:22:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:22:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:39 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:39 --> URI Class Initialized
INFO - 2023-08-23 20:22:39 --> Router Class Initialized
INFO - 2023-08-23 20:22:39 --> Output Class Initialized
INFO - 2023-08-23 20:22:39 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:39 --> Input Class Initialized
INFO - 2023-08-23 20:22:39 --> Language Class Initialized
ERROR - 2023-08-23 20:22:39 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:22:39 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:40 --> URI Class Initialized
INFO - 2023-08-23 20:22:40 --> Router Class Initialized
INFO - 2023-08-23 20:22:40 --> Config Class Initialized
INFO - 2023-08-23 20:22:40 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:40 --> Output Class Initialized
INFO - 2023-08-23 20:22:40 --> Config Class Initialized
DEBUG - 2023-08-23 20:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:40 --> Config Class Initialized
INFO - 2023-08-23 20:22:40 --> Config Class Initialized
INFO - 2023-08-23 20:22:40 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:40 --> Security Class Initialized
INFO - 2023-08-23 20:22:40 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:40 --> Input Class Initialized
DEBUG - 2023-08-23 20:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:40 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:40 --> URI Class Initialized
INFO - 2023-08-23 20:22:40 --> Router Class Initialized
INFO - 2023-08-23 20:22:40 --> Output Class Initialized
INFO - 2023-08-23 20:22:40 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:40 --> Input Class Initialized
INFO - 2023-08-23 20:22:40 --> Language Class Initialized
ERROR - 2023-08-23 20:22:40 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:22:40 --> URI Class Initialized
DEBUG - 2023-08-23 20:22:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:40 --> Router Class Initialized
INFO - 2023-08-23 20:22:40 --> Output Class Initialized
INFO - 2023-08-23 20:22:40 --> Config Class Initialized
INFO - 2023-08-23 20:22:40 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:40 --> Language Class Initialized
INFO - 2023-08-23 20:22:40 --> Security Class Initialized
INFO - 2023-08-23 20:22:40 --> Hooks Class Initialized
ERROR - 2023-08-23 20:22:41 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:41 --> Input Class Initialized
INFO - 2023-08-23 20:22:41 --> Language Class Initialized
ERROR - 2023-08-23 20:22:41 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:22:41 --> Config Class Initialized
INFO - 2023-08-23 20:22:41 --> Config Class Initialized
INFO - 2023-08-23 20:22:41 --> Input Class Initialized
INFO - 2023-08-23 20:22:41 --> Language Class Initialized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Config Class Initialized
INFO - 2023-08-23 20:22:41 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:41 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
ERROR - 2023-08-23 20:22:41 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:41 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:41 --> Config Class Initialized
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:41 --> Input Class Initialized
INFO - 2023-08-23 20:22:41 --> Language Class Initialized
ERROR - 2023-08-23 20:22:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Config Class Initialized
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> URI Class Initialized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Output Class Initialized
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:41 --> Input Class Initialized
INFO - 2023-08-23 20:22:41 --> Language Class Initialized
ERROR - 2023-08-23 20:22:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:41 --> Hooks Class Initialized
INFO - 2023-08-23 20:22:41 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:41 --> Router Class Initialized
INFO - 2023-08-23 20:22:41 --> Utf8 Class Initialized
INFO - 2023-08-23 20:22:41 --> Input Class Initialized
INFO - 2023-08-23 20:22:42 --> URI Class Initialized
DEBUG - 2023-08-23 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:42 --> Output Class Initialized
INFO - 2023-08-23 20:22:42 --> Router Class Initialized
INFO - 2023-08-23 20:22:42 --> Input Class Initialized
INFO - 2023-08-23 20:22:42 --> Language Class Initialized
INFO - 2023-08-23 20:22:42 --> Language Class Initialized
INFO - 2023-08-23 20:22:42 --> Input Class Initialized
INFO - 2023-08-23 20:22:42 --> Language Class Initialized
ERROR - 2023-08-23 20:22:42 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:42 --> Output Class Initialized
ERROR - 2023-08-23 20:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:42 --> Security Class Initialized
INFO - 2023-08-23 20:22:42 --> Security Class Initialized
DEBUG - 2023-08-23 20:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:22:42 --> Input Class Initialized
INFO - 2023-08-23 20:22:42 --> Language Class Initialized
INFO - 2023-08-23 20:22:42 --> Input Class Initialized
ERROR - 2023-08-23 20:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:22:42 --> Language Class Initialized
ERROR - 2023-08-23 20:22:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:23:12 --> Config Class Initialized
INFO - 2023-08-23 20:23:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:23:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:23:12 --> Utf8 Class Initialized
INFO - 2023-08-23 20:23:12 --> URI Class Initialized
INFO - 2023-08-23 20:23:12 --> Router Class Initialized
INFO - 2023-08-23 20:23:12 --> Output Class Initialized
INFO - 2023-08-23 20:23:12 --> Security Class Initialized
DEBUG - 2023-08-23 20:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:23:12 --> Input Class Initialized
INFO - 2023-08-23 20:23:12 --> Language Class Initialized
INFO - 2023-08-23 20:23:12 --> Loader Class Initialized
INFO - 2023-08-23 20:23:12 --> Helper loaded: url_helper
INFO - 2023-08-23 20:23:12 --> Helper loaded: file_helper
INFO - 2023-08-23 20:23:12 --> Database Driver Class Initialized
INFO - 2023-08-23 20:23:12 --> Email Class Initialized
DEBUG - 2023-08-23 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:23:12 --> Controller Class Initialized
INFO - 2023-08-23 20:23:12 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:23:12 --> Model "Home_model" initialized
INFO - 2023-08-23 20:23:12 --> Helper loaded: download_helper
INFO - 2023-08-23 20:23:12 --> Helper loaded: form_helper
INFO - 2023-08-23 20:23:12 --> Form Validation Class Initialized
ERROR - 2023-08-23 20:23:12 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `message`, `services_ids`, `status`, `created_at`) VALUES ('ddddd', 'ssss@gmail.com', '9999999999', 'dfsdf', NULL, NULL, '2023-08-23 20:23:12')
INFO - 2023-08-23 20:23:12 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-23 20:26:11 --> Config Class Initialized
INFO - 2023-08-23 20:26:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:11 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:11 --> URI Class Initialized
INFO - 2023-08-23 20:26:11 --> Router Class Initialized
INFO - 2023-08-23 20:26:11 --> Output Class Initialized
INFO - 2023-08-23 20:26:11 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:11 --> Input Class Initialized
INFO - 2023-08-23 20:26:11 --> Language Class Initialized
INFO - 2023-08-23 20:26:11 --> Loader Class Initialized
INFO - 2023-08-23 20:26:11 --> Helper loaded: url_helper
INFO - 2023-08-23 20:26:11 --> Helper loaded: file_helper
INFO - 2023-08-23 20:26:11 --> Database Driver Class Initialized
INFO - 2023-08-23 20:26:11 --> Email Class Initialized
DEBUG - 2023-08-23 20:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:26:11 --> Controller Class Initialized
INFO - 2023-08-23 20:26:11 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:26:11 --> Model "Home_model" initialized
INFO - 2023-08-23 20:26:11 --> Helper loaded: download_helper
INFO - 2023-08-23 20:26:11 --> Helper loaded: form_helper
INFO - 2023-08-23 20:26:12 --> Form Validation Class Initialized
INFO - 2023-08-23 20:26:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:26:12 --> Final output sent to browser
DEBUG - 2023-08-23 20:26:12 --> Total execution time: 0.8843
INFO - 2023-08-23 20:26:13 --> Config Class Initialized
INFO - 2023-08-23 20:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:13 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:13 --> URI Class Initialized
INFO - 2023-08-23 20:26:13 --> Router Class Initialized
INFO - 2023-08-23 20:26:13 --> Output Class Initialized
INFO - 2023-08-23 20:26:13 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:13 --> Input Class Initialized
INFO - 2023-08-23 20:26:13 --> Language Class Initialized
ERROR - 2023-08-23 20:26:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:13 --> Config Class Initialized
INFO - 2023-08-23 20:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:13 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:13 --> URI Class Initialized
INFO - 2023-08-23 20:26:13 --> Router Class Initialized
INFO - 2023-08-23 20:26:13 --> Output Class Initialized
INFO - 2023-08-23 20:26:13 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:13 --> Input Class Initialized
INFO - 2023-08-23 20:26:13 --> Language Class Initialized
ERROR - 2023-08-23 20:26:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:13 --> Config Class Initialized
INFO - 2023-08-23 20:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:13 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:13 --> URI Class Initialized
INFO - 2023-08-23 20:26:13 --> Router Class Initialized
INFO - 2023-08-23 20:26:13 --> Output Class Initialized
INFO - 2023-08-23 20:26:13 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:13 --> Input Class Initialized
INFO - 2023-08-23 20:26:13 --> Language Class Initialized
ERROR - 2023-08-23 20:26:13 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:13 --> Config Class Initialized
INFO - 2023-08-23 20:26:13 --> Hooks Class Initialized
INFO - 2023-08-23 20:26:13 --> Config Class Initialized
DEBUG - 2023-08-23 20:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:14 --> Hooks Class Initialized
INFO - 2023-08-23 20:26:14 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:26:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:14 --> URI Class Initialized
INFO - 2023-08-23 20:26:14 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:14 --> Router Class Initialized
INFO - 2023-08-23 20:26:14 --> URI Class Initialized
INFO - 2023-08-23 20:26:14 --> Output Class Initialized
INFO - 2023-08-23 20:26:14 --> Router Class Initialized
INFO - 2023-08-23 20:26:14 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:14 --> Output Class Initialized
INFO - 2023-08-23 20:26:14 --> Input Class Initialized
INFO - 2023-08-23 20:26:14 --> Language Class Initialized
INFO - 2023-08-23 20:26:14 --> Security Class Initialized
ERROR - 2023-08-23 20:26:14 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:14 --> Input Class Initialized
INFO - 2023-08-23 20:26:14 --> Language Class Initialized
ERROR - 2023-08-23 20:26:14 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:27 --> Config Class Initialized
INFO - 2023-08-23 20:26:27 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:27 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:27 --> URI Class Initialized
INFO - 2023-08-23 20:26:27 --> Router Class Initialized
INFO - 2023-08-23 20:26:27 --> Output Class Initialized
INFO - 2023-08-23 20:26:27 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:27 --> Input Class Initialized
INFO - 2023-08-23 20:26:27 --> Language Class Initialized
INFO - 2023-08-23 20:26:27 --> Loader Class Initialized
INFO - 2023-08-23 20:26:27 --> Helper loaded: url_helper
INFO - 2023-08-23 20:26:27 --> Helper loaded: file_helper
INFO - 2023-08-23 20:26:27 --> Database Driver Class Initialized
INFO - 2023-08-23 20:26:27 --> Email Class Initialized
DEBUG - 2023-08-23 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:26:27 --> Controller Class Initialized
INFO - 2023-08-23 20:26:27 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:26:27 --> Model "Home_model" initialized
INFO - 2023-08-23 20:26:27 --> Helper loaded: download_helper
INFO - 2023-08-23 20:26:27 --> Helper loaded: form_helper
INFO - 2023-08-23 20:26:27 --> Form Validation Class Initialized
INFO - 2023-08-23 20:26:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:26:27 --> Final output sent to browser
DEBUG - 2023-08-23 20:26:27 --> Total execution time: 0.3446
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:28 --> URI Class Initialized
INFO - 2023-08-23 20:26:28 --> Router Class Initialized
INFO - 2023-08-23 20:26:28 --> Output Class Initialized
INFO - 2023-08-23 20:26:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:28 --> Input Class Initialized
INFO - 2023-08-23 20:26:28 --> Language Class Initialized
ERROR - 2023-08-23 20:26:28 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:28 --> URI Class Initialized
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:28 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:28 --> Router Class Initialized
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:28 --> URI Class Initialized
INFO - 2023-08-23 20:26:28 --> Router Class Initialized
INFO - 2023-08-23 20:26:28 --> Hooks Class Initialized
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:28 --> Config Class Initialized
INFO - 2023-08-23 20:26:29 --> Output Class Initialized
DEBUG - 2023-08-23 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:29 --> Output Class Initialized
INFO - 2023-08-23 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:29 --> URI Class Initialized
INFO - 2023-08-23 20:26:29 --> Router Class Initialized
INFO - 2023-08-23 20:26:29 --> Output Class Initialized
INFO - 2023-08-23 20:26:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:29 --> Input Class Initialized
INFO - 2023-08-23 20:26:29 --> Language Class Initialized
ERROR - 2023-08-23 20:26:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:29 --> Security Class Initialized
INFO - 2023-08-23 20:26:29 --> Security Class Initialized
INFO - 2023-08-23 20:26:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:29 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-23 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:29 --> Input Class Initialized
INFO - 2023-08-23 20:26:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:29 --> URI Class Initialized
INFO - 2023-08-23 20:26:29 --> Input Class Initialized
INFO - 2023-08-23 20:26:29 --> Router Class Initialized
INFO - 2023-08-23 20:26:29 --> URI Class Initialized
INFO - 2023-08-23 20:26:29 --> Output Class Initialized
INFO - 2023-08-23 20:26:29 --> Language Class Initialized
ERROR - 2023-08-23 20:26:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:29 --> Language Class Initialized
INFO - 2023-08-23 20:26:29 --> Security Class Initialized
INFO - 2023-08-23 20:26:29 --> Router Class Initialized
ERROR - 2023-08-23 20:26:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:29 --> Output Class Initialized
DEBUG - 2023-08-23 20:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:29 --> Security Class Initialized
INFO - 2023-08-23 20:26:29 --> Input Class Initialized
INFO - 2023-08-23 20:26:29 --> Language Class Initialized
DEBUG - 2023-08-23 20:26:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:26:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:29 --> Input Class Initialized
INFO - 2023-08-23 20:26:29 --> Language Class Initialized
ERROR - 2023-08-23 20:26:29 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:26:53 --> Config Class Initialized
INFO - 2023-08-23 20:26:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
INFO - 2023-08-23 20:26:54 --> Config Class Initialized
INFO - 2023-08-23 20:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:26:54 --> Utf8 Class Initialized
INFO - 2023-08-23 20:26:54 --> URI Class Initialized
INFO - 2023-08-23 20:26:54 --> Router Class Initialized
INFO - 2023-08-23 20:26:54 --> Output Class Initialized
INFO - 2023-08-23 20:26:54 --> Security Class Initialized
DEBUG - 2023-08-23 20:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:26:54 --> Input Class Initialized
INFO - 2023-08-23 20:26:54 --> Language Class Initialized
ERROR - 2023-08-23 20:26:54 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:27:02 --> Config Class Initialized
INFO - 2023-08-23 20:27:02 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:27:02 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:27:02 --> Utf8 Class Initialized
INFO - 2023-08-23 20:27:02 --> URI Class Initialized
INFO - 2023-08-23 20:27:02 --> Router Class Initialized
INFO - 2023-08-23 20:27:02 --> Output Class Initialized
INFO - 2023-08-23 20:27:02 --> Security Class Initialized
DEBUG - 2023-08-23 20:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:27:02 --> Input Class Initialized
INFO - 2023-08-23 20:27:02 --> Language Class Initialized
INFO - 2023-08-23 20:27:02 --> Loader Class Initialized
INFO - 2023-08-23 20:27:02 --> Helper loaded: url_helper
INFO - 2023-08-23 20:27:02 --> Helper loaded: file_helper
INFO - 2023-08-23 20:27:02 --> Database Driver Class Initialized
INFO - 2023-08-23 20:27:02 --> Email Class Initialized
DEBUG - 2023-08-23 20:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:27:02 --> Controller Class Initialized
INFO - 2023-08-23 20:27:02 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:27:02 --> Model "Home_model" initialized
INFO - 2023-08-23 20:27:02 --> Helper loaded: download_helper
INFO - 2023-08-23 20:27:02 --> Helper loaded: form_helper
INFO - 2023-08-23 20:27:02 --> Form Validation Class Initialized
INFO - 2023-08-23 20:31:06 --> Config Class Initialized
INFO - 2023-08-23 20:31:06 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:06 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:06 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:06 --> URI Class Initialized
INFO - 2023-08-23 20:31:06 --> Router Class Initialized
INFO - 2023-08-23 20:31:06 --> Output Class Initialized
INFO - 2023-08-23 20:31:06 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:06 --> Input Class Initialized
INFO - 2023-08-23 20:31:06 --> Language Class Initialized
INFO - 2023-08-23 20:31:06 --> Loader Class Initialized
INFO - 2023-08-23 20:31:06 --> Helper loaded: url_helper
INFO - 2023-08-23 20:31:07 --> Helper loaded: file_helper
INFO - 2023-08-23 20:31:07 --> Database Driver Class Initialized
INFO - 2023-08-23 20:31:07 --> Email Class Initialized
DEBUG - 2023-08-23 20:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:31:07 --> Controller Class Initialized
INFO - 2023-08-23 20:31:07 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:31:07 --> Model "Home_model" initialized
INFO - 2023-08-23 20:31:07 --> Helper loaded: download_helper
INFO - 2023-08-23 20:31:07 --> Helper loaded: form_helper
INFO - 2023-08-23 20:31:07 --> Form Validation Class Initialized
INFO - 2023-08-23 20:31:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:31:07 --> Final output sent to browser
DEBUG - 2023-08-23 20:31:07 --> Total execution time: 0.5774
INFO - 2023-08-23 20:31:07 --> Config Class Initialized
INFO - 2023-08-23 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:07 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:07 --> URI Class Initialized
INFO - 2023-08-23 20:31:07 --> Router Class Initialized
INFO - 2023-08-23 20:31:07 --> Output Class Initialized
INFO - 2023-08-23 20:31:07 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:07 --> Input Class Initialized
INFO - 2023-08-23 20:31:07 --> Language Class Initialized
ERROR - 2023-08-23 20:31:07 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:07 --> Config Class Initialized
INFO - 2023-08-23 20:31:07 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:07 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:07 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:07 --> URI Class Initialized
INFO - 2023-08-23 20:31:07 --> Router Class Initialized
INFO - 2023-08-23 20:31:07 --> Output Class Initialized
INFO - 2023-08-23 20:31:07 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:07 --> Input Class Initialized
INFO - 2023-08-23 20:31:07 --> Language Class Initialized
ERROR - 2023-08-23 20:31:07 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:08 --> Config Class Initialized
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:08 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:08 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:08 --> URI Class Initialized
INFO - 2023-08-23 20:31:08 --> Router Class Initialized
INFO - 2023-08-23 20:31:08 --> Output Class Initialized
INFO - 2023-08-23 20:31:08 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:08 --> Input Class Initialized
INFO - 2023-08-23 20:31:08 --> Language Class Initialized
ERROR - 2023-08-23 20:31:08 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:08 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:09 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:09 --> URI Class Initialized
INFO - 2023-08-23 20:31:09 --> Router Class Initialized
INFO - 2023-08-23 20:31:09 --> Output Class Initialized
INFO - 2023-08-23 20:31:09 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:09 --> Input Class Initialized
INFO - 2023-08-23 20:31:09 --> Language Class Initialized
ERROR - 2023-08-23 20:31:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:09 --> Config Class Initialized
INFO - 2023-08-23 20:31:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:09 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:09 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:09 --> URI Class Initialized
INFO - 2023-08-23 20:31:09 --> Router Class Initialized
INFO - 2023-08-23 20:31:09 --> Output Class Initialized
INFO - 2023-08-23 20:31:09 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:09 --> Input Class Initialized
INFO - 2023-08-23 20:31:09 --> Language Class Initialized
ERROR - 2023-08-23 20:31:09 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:09 --> Config Class Initialized
INFO - 2023-08-23 20:31:09 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:10 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:10 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:10 --> URI Class Initialized
INFO - 2023-08-23 20:31:10 --> Router Class Initialized
INFO - 2023-08-23 20:31:10 --> Output Class Initialized
INFO - 2023-08-23 20:31:10 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:10 --> Input Class Initialized
INFO - 2023-08-23 20:31:10 --> Language Class Initialized
ERROR - 2023-08-23 20:31:10 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:31:36 --> Config Class Initialized
INFO - 2023-08-23 20:31:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:36 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:36 --> URI Class Initialized
INFO - 2023-08-23 20:31:36 --> Router Class Initialized
INFO - 2023-08-23 20:31:36 --> Output Class Initialized
INFO - 2023-08-23 20:31:36 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:36 --> Input Class Initialized
INFO - 2023-08-23 20:31:36 --> Language Class Initialized
INFO - 2023-08-23 20:31:36 --> Loader Class Initialized
INFO - 2023-08-23 20:31:36 --> Helper loaded: url_helper
INFO - 2023-08-23 20:31:36 --> Helper loaded: file_helper
INFO - 2023-08-23 20:31:36 --> Database Driver Class Initialized
INFO - 2023-08-23 20:31:36 --> Email Class Initialized
DEBUG - 2023-08-23 20:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:31:36 --> Controller Class Initialized
INFO - 2023-08-23 20:31:36 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:31:36 --> Model "Home_model" initialized
INFO - 2023-08-23 20:31:36 --> Helper loaded: download_helper
INFO - 2023-08-23 20:31:36 --> Helper loaded: form_helper
INFO - 2023-08-23 20:31:36 --> Form Validation Class Initialized
INFO - 2023-08-23 20:31:50 --> Config Class Initialized
INFO - 2023-08-23 20:31:50 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:31:50 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:31:50 --> Utf8 Class Initialized
INFO - 2023-08-23 20:31:50 --> URI Class Initialized
INFO - 2023-08-23 20:31:50 --> Router Class Initialized
INFO - 2023-08-23 20:31:50 --> Output Class Initialized
INFO - 2023-08-23 20:31:50 --> Security Class Initialized
DEBUG - 2023-08-23 20:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:31:50 --> Input Class Initialized
INFO - 2023-08-23 20:31:50 --> Language Class Initialized
INFO - 2023-08-23 20:31:50 --> Loader Class Initialized
INFO - 2023-08-23 20:31:50 --> Helper loaded: url_helper
INFO - 2023-08-23 20:31:50 --> Helper loaded: file_helper
INFO - 2023-08-23 20:31:50 --> Database Driver Class Initialized
INFO - 2023-08-23 20:31:51 --> Email Class Initialized
DEBUG - 2023-08-23 20:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:31:51 --> Controller Class Initialized
INFO - 2023-08-23 20:31:51 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:31:51 --> Model "Home_model" initialized
INFO - 2023-08-23 20:31:51 --> Helper loaded: download_helper
INFO - 2023-08-23 20:31:51 --> Helper loaded: form_helper
INFO - 2023-08-23 20:31:51 --> Form Validation Class Initialized
INFO - 2023-08-23 20:33:21 --> Config Class Initialized
INFO - 2023-08-23 20:33:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:33:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:33:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:33:21 --> URI Class Initialized
INFO - 2023-08-23 20:33:21 --> Router Class Initialized
INFO - 2023-08-23 20:33:21 --> Output Class Initialized
INFO - 2023-08-23 20:33:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:33:21 --> Input Class Initialized
INFO - 2023-08-23 20:33:21 --> Language Class Initialized
INFO - 2023-08-23 20:33:21 --> Loader Class Initialized
INFO - 2023-08-23 20:33:21 --> Helper loaded: url_helper
INFO - 2023-08-23 20:33:21 --> Helper loaded: file_helper
INFO - 2023-08-23 20:33:21 --> Database Driver Class Initialized
INFO - 2023-08-23 20:33:21 --> Email Class Initialized
DEBUG - 2023-08-23 20:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:33:21 --> Controller Class Initialized
INFO - 2023-08-23 20:33:21 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:33:21 --> Model "Home_model" initialized
INFO - 2023-08-23 20:33:21 --> Helper loaded: download_helper
INFO - 2023-08-23 20:33:21 --> Helper loaded: form_helper
INFO - 2023-08-23 20:33:22 --> Form Validation Class Initialized
INFO - 2023-08-23 20:34:22 --> Config Class Initialized
INFO - 2023-08-23 20:34:22 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:22 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:22 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:22 --> URI Class Initialized
INFO - 2023-08-23 20:34:22 --> Router Class Initialized
INFO - 2023-08-23 20:34:22 --> Output Class Initialized
INFO - 2023-08-23 20:34:22 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:22 --> Input Class Initialized
INFO - 2023-08-23 20:34:22 --> Language Class Initialized
INFO - 2023-08-23 20:34:22 --> Loader Class Initialized
INFO - 2023-08-23 20:34:22 --> Helper loaded: url_helper
INFO - 2023-08-23 20:34:22 --> Helper loaded: file_helper
INFO - 2023-08-23 20:34:22 --> Database Driver Class Initialized
INFO - 2023-08-23 20:34:22 --> Email Class Initialized
DEBUG - 2023-08-23 20:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:34:22 --> Controller Class Initialized
INFO - 2023-08-23 20:34:22 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:34:22 --> Model "Home_model" initialized
INFO - 2023-08-23 20:34:22 --> Helper loaded: download_helper
INFO - 2023-08-23 20:34:22 --> Helper loaded: form_helper
INFO - 2023-08-23 20:34:22 --> Form Validation Class Initialized
INFO - 2023-08-23 20:34:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:34:22 --> Final output sent to browser
DEBUG - 2023-08-23 20:34:22 --> Total execution time: 0.7280
INFO - 2023-08-23 20:34:24 --> Config Class Initialized
INFO - 2023-08-23 20:34:24 --> Config Class Initialized
INFO - 2023-08-23 20:34:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:34:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:34:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:24 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:24 --> URI Class Initialized
INFO - 2023-08-23 20:34:24 --> URI Class Initialized
INFO - 2023-08-23 20:34:24 --> Router Class Initialized
INFO - 2023-08-23 20:34:24 --> Output Class Initialized
INFO - 2023-08-23 20:34:24 --> Router Class Initialized
INFO - 2023-08-23 20:34:24 --> Security Class Initialized
INFO - 2023-08-23 20:34:24 --> Output Class Initialized
DEBUG - 2023-08-23 20:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:24 --> Security Class Initialized
INFO - 2023-08-23 20:34:24 --> Input Class Initialized
DEBUG - 2023-08-23 20:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:24 --> Language Class Initialized
ERROR - 2023-08-23 20:34:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:34:24 --> Input Class Initialized
INFO - 2023-08-23 20:34:24 --> Language Class Initialized
ERROR - 2023-08-23 20:34:24 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:34:24 --> Config Class Initialized
INFO - 2023-08-23 20:34:24 --> Hooks Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
INFO - 2023-08-23 20:34:25 --> Output Class Initialized
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> Security Class Initialized
INFO - 2023-08-23 20:34:25 --> Output Class Initialized
DEBUG - 2023-08-23 20:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:25 --> Security Class Initialized
INFO - 2023-08-23 20:34:25 --> Input Class Initialized
DEBUG - 2023-08-23 20:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:25 --> Language Class Initialized
INFO - 2023-08-23 20:34:25 --> Input Class Initialized
ERROR - 2023-08-23 20:34:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:25 --> Language Class Initialized
ERROR - 2023-08-23 20:34:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> Output Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> Security Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
DEBUG - 2023-08-23 20:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:25 --> Input Class Initialized
INFO - 2023-08-23 20:34:25 --> Language Class Initialized
ERROR - 2023-08-23 20:34:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> Output Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> Input Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> Language Class Initialized
INFO - 2023-08-23 20:34:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:34:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
DEBUG - 2023-08-23 20:34:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> Router Class Initialized
INFO - 2023-08-23 20:34:25 --> Config Class Initialized
INFO - 2023-08-23 20:34:25 --> URI Class Initialized
INFO - 2023-08-23 20:34:25 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:26 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:26 --> URI Class Initialized
INFO - 2023-08-23 20:34:26 --> Router Class Initialized
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:26 --> Router Class Initialized
INFO - 2023-08-23 20:34:26 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> URI Class Initialized
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> Router Class Initialized
INFO - 2023-08-23 20:34:26 --> URI Class Initialized
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
INFO - 2023-08-23 20:34:26 --> Router Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Output Class Initialized
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
INFO - 2023-08-23 20:34:26 --> Security Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
DEBUG - 2023-08-23 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:26 --> Input Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
INFO - 2023-08-23 20:34:26 --> Language Class Initialized
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:34:26 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:34:53 --> Config Class Initialized
INFO - 2023-08-23 20:34:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:34:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:34:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:34:53 --> URI Class Initialized
INFO - 2023-08-23 20:34:53 --> Router Class Initialized
INFO - 2023-08-23 20:34:53 --> Output Class Initialized
INFO - 2023-08-23 20:34:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:34:53 --> Input Class Initialized
INFO - 2023-08-23 20:34:53 --> Language Class Initialized
INFO - 2023-08-23 20:34:53 --> Loader Class Initialized
INFO - 2023-08-23 20:34:53 --> Helper loaded: url_helper
INFO - 2023-08-23 20:34:53 --> Helper loaded: file_helper
INFO - 2023-08-23 20:34:53 --> Database Driver Class Initialized
INFO - 2023-08-23 20:34:53 --> Email Class Initialized
DEBUG - 2023-08-23 20:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:34:53 --> Controller Class Initialized
INFO - 2023-08-23 20:34:53 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:34:53 --> Model "Home_model" initialized
INFO - 2023-08-23 20:34:53 --> Helper loaded: download_helper
INFO - 2023-08-23 20:34:53 --> Helper loaded: form_helper
INFO - 2023-08-23 20:34:53 --> Form Validation Class Initialized
INFO - 2023-08-23 20:35:51 --> Config Class Initialized
INFO - 2023-08-23 20:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:51 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:51 --> URI Class Initialized
INFO - 2023-08-23 20:35:51 --> Router Class Initialized
INFO - 2023-08-23 20:35:51 --> Output Class Initialized
INFO - 2023-08-23 20:35:51 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:51 --> Input Class Initialized
INFO - 2023-08-23 20:35:51 --> Language Class Initialized
INFO - 2023-08-23 20:35:51 --> Loader Class Initialized
INFO - 2023-08-23 20:35:51 --> Helper loaded: url_helper
INFO - 2023-08-23 20:35:51 --> Helper loaded: file_helper
INFO - 2023-08-23 20:35:51 --> Database Driver Class Initialized
INFO - 2023-08-23 20:35:51 --> Email Class Initialized
DEBUG - 2023-08-23 20:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:35:51 --> Controller Class Initialized
INFO - 2023-08-23 20:35:51 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:35:51 --> Model "Home_model" initialized
INFO - 2023-08-23 20:35:51 --> Helper loaded: download_helper
INFO - 2023-08-23 20:35:51 --> Helper loaded: form_helper
INFO - 2023-08-23 20:35:51 --> Form Validation Class Initialized
INFO - 2023-08-23 20:35:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:35:52 --> Final output sent to browser
DEBUG - 2023-08-23 20:35:52 --> Total execution time: 0.5756
INFO - 2023-08-23 20:35:52 --> Config Class Initialized
INFO - 2023-08-23 20:35:52 --> Config Class Initialized
INFO - 2023-08-23 20:35:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:53 --> URI Class Initialized
INFO - 2023-08-23 20:35:53 --> Router Class Initialized
INFO - 2023-08-23 20:35:53 --> Output Class Initialized
INFO - 2023-08-23 20:35:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:53 --> Input Class Initialized
INFO - 2023-08-23 20:35:53 --> Language Class Initialized
ERROR - 2023-08-23 20:35:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:53 --> Hooks Class Initialized
INFO - 2023-08-23 20:35:53 --> Config Class Initialized
INFO - 2023-08-23 20:35:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:53 --> URI Class Initialized
INFO - 2023-08-23 20:35:53 --> Router Class Initialized
INFO - 2023-08-23 20:35:53 --> Output Class Initialized
INFO - 2023-08-23 20:35:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:53 --> Input Class Initialized
INFO - 2023-08-23 20:35:53 --> Language Class Initialized
ERROR - 2023-08-23 20:35:53 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:53 --> Config Class Initialized
INFO - 2023-08-23 20:35:53 --> Config Class Initialized
DEBUG - 2023-08-23 20:35:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:53 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:53 --> Hooks Class Initialized
INFO - 2023-08-23 20:35:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:53 --> URI Class Initialized
INFO - 2023-08-23 20:35:53 --> URI Class Initialized
INFO - 2023-08-23 20:35:53 --> Router Class Initialized
DEBUG - 2023-08-23 20:35:53 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:53 --> Router Class Initialized
INFO - 2023-08-23 20:35:53 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:53 --> URI Class Initialized
INFO - 2023-08-23 20:35:53 --> Output Class Initialized
INFO - 2023-08-23 20:35:53 --> Output Class Initialized
INFO - 2023-08-23 20:35:53 --> Router Class Initialized
INFO - 2023-08-23 20:35:53 --> Security Class Initialized
INFO - 2023-08-23 20:35:53 --> Output Class Initialized
INFO - 2023-08-23 20:35:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:53 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:54 --> Input Class Initialized
INFO - 2023-08-23 20:35:54 --> Language Class Initialized
ERROR - 2023-08-23 20:35:54 --> 404 Page Not Found: Training-detail/assets
DEBUG - 2023-08-23 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:54 --> Input Class Initialized
INFO - 2023-08-23 20:35:54 --> Input Class Initialized
INFO - 2023-08-23 20:35:54 --> Language Class Initialized
INFO - 2023-08-23 20:35:54 --> Language Class Initialized
ERROR - 2023-08-23 20:35:54 --> 404 Page Not Found: Training-detail/assets
ERROR - 2023-08-23 20:35:54 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:55 --> Config Class Initialized
INFO - 2023-08-23 20:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:55 --> URI Class Initialized
INFO - 2023-08-23 20:35:55 --> Router Class Initialized
INFO - 2023-08-23 20:35:55 --> Output Class Initialized
INFO - 2023-08-23 20:35:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:55 --> Input Class Initialized
INFO - 2023-08-23 20:35:55 --> Language Class Initialized
INFO - 2023-08-23 20:35:55 --> Loader Class Initialized
INFO - 2023-08-23 20:35:55 --> Helper loaded: url_helper
INFO - 2023-08-23 20:35:55 --> Helper loaded: file_helper
INFO - 2023-08-23 20:35:55 --> Database Driver Class Initialized
INFO - 2023-08-23 20:35:55 --> Email Class Initialized
DEBUG - 2023-08-23 20:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:35:55 --> Controller Class Initialized
INFO - 2023-08-23 20:35:55 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:35:55 --> Model "Home_model" initialized
INFO - 2023-08-23 20:35:55 --> Helper loaded: download_helper
INFO - 2023-08-23 20:35:55 --> Helper loaded: form_helper
INFO - 2023-08-23 20:35:55 --> Form Validation Class Initialized
INFO - 2023-08-23 20:35:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:35:55 --> Config Class Initialized
INFO - 2023-08-23 20:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:55 --> URI Class Initialized
INFO - 2023-08-23 20:35:55 --> Router Class Initialized
INFO - 2023-08-23 20:35:55 --> Output Class Initialized
INFO - 2023-08-23 20:35:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:55 --> Input Class Initialized
INFO - 2023-08-23 20:35:55 --> Language Class Initialized
ERROR - 2023-08-23 20:35:55 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:55 --> Final output sent to browser
DEBUG - 2023-08-23 20:35:55 --> Total execution time: 0.4530
INFO - 2023-08-23 20:35:55 --> Config Class Initialized
INFO - 2023-08-23 20:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:55 --> URI Class Initialized
INFO - 2023-08-23 20:35:55 --> Router Class Initialized
INFO - 2023-08-23 20:35:55 --> Output Class Initialized
INFO - 2023-08-23 20:35:55 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:55 --> Config Class Initialized
INFO - 2023-08-23 20:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:55 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:55 --> URI Class Initialized
INFO - 2023-08-23 20:35:55 --> Router Class Initialized
INFO - 2023-08-23 20:35:56 --> Output Class Initialized
INFO - 2023-08-23 20:35:56 --> Config Class Initialized
INFO - 2023-08-23 20:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:56 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:35:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:56 --> URI Class Initialized
INFO - 2023-08-23 20:35:56 --> Router Class Initialized
INFO - 2023-08-23 20:35:56 --> Output Class Initialized
INFO - 2023-08-23 20:35:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:56 --> Input Class Initialized
INFO - 2023-08-23 20:35:56 --> Language Class Initialized
ERROR - 2023-08-23 20:35:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:56 --> Config Class Initialized
INFO - 2023-08-23 20:35:56 --> Config Class Initialized
INFO - 2023-08-23 20:35:56 --> Input Class Initialized
INFO - 2023-08-23 20:35:56 --> Language Class Initialized
INFO - 2023-08-23 20:35:56 --> Security Class Initialized
ERROR - 2023-08-23 20:35:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:56 --> Hooks Class Initialized
INFO - 2023-08-23 20:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-08-23 20:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:56 --> Input Class Initialized
INFO - 2023-08-23 20:35:56 --> Language Class Initialized
INFO - 2023-08-23 20:35:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:56 --> URI Class Initialized
DEBUG - 2023-08-23 20:35:56 --> UTF-8 Support Enabled
ERROR - 2023-08-23 20:35:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:56 --> Router Class Initialized
INFO - 2023-08-23 20:35:56 --> Output Class Initialized
INFO - 2023-08-23 20:35:56 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:56 --> Input Class Initialized
INFO - 2023-08-23 20:35:56 --> Language Class Initialized
ERROR - 2023-08-23 20:35:56 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:35:56 --> Utf8 Class Initialized
INFO - 2023-08-23 20:35:56 --> URI Class Initialized
INFO - 2023-08-23 20:35:57 --> Router Class Initialized
INFO - 2023-08-23 20:35:57 --> Output Class Initialized
INFO - 2023-08-23 20:35:57 --> Security Class Initialized
DEBUG - 2023-08-23 20:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:35:57 --> Input Class Initialized
INFO - 2023-08-23 20:35:57 --> Language Class Initialized
ERROR - 2023-08-23 20:35:57 --> 404 Page Not Found: Training-detail/assets
INFO - 2023-08-23 20:36:21 --> Config Class Initialized
INFO - 2023-08-23 20:36:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:36:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:21 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:21 --> URI Class Initialized
INFO - 2023-08-23 20:36:21 --> Router Class Initialized
INFO - 2023-08-23 20:36:21 --> Output Class Initialized
INFO - 2023-08-23 20:36:21 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:21 --> Input Class Initialized
INFO - 2023-08-23 20:36:21 --> Language Class Initialized
INFO - 2023-08-23 20:36:21 --> Loader Class Initialized
INFO - 2023-08-23 20:36:21 --> Helper loaded: url_helper
INFO - 2023-08-23 20:36:21 --> Helper loaded: file_helper
INFO - 2023-08-23 20:36:21 --> Database Driver Class Initialized
INFO - 2023-08-23 20:36:21 --> Email Class Initialized
DEBUG - 2023-08-23 20:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:36:21 --> Controller Class Initialized
INFO - 2023-08-23 20:36:21 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:36:21 --> Model "Home_model" initialized
INFO - 2023-08-23 20:36:21 --> Helper loaded: download_helper
INFO - 2023-08-23 20:36:21 --> Helper loaded: form_helper
INFO - 2023-08-23 20:36:21 --> Form Validation Class Initialized
INFO - 2023-08-23 20:36:26 --> Config Class Initialized
INFO - 2023-08-23 20:36:26 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:36:26 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:26 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:26 --> URI Class Initialized
INFO - 2023-08-23 20:36:26 --> Router Class Initialized
INFO - 2023-08-23 20:36:26 --> Output Class Initialized
INFO - 2023-08-23 20:36:26 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:26 --> Input Class Initialized
INFO - 2023-08-23 20:36:26 --> Language Class Initialized
ERROR - 2023-08-23 20:36:26 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:36:26 --> Config Class Initialized
INFO - 2023-08-23 20:36:26 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Config Class Initialized
DEBUG - 2023-08-23 20:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:27 --> Config Class Initialized
INFO - 2023-08-23 20:36:27 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Config Class Initialized
INFO - 2023-08-23 20:36:27 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:27 --> URI Class Initialized
DEBUG - 2023-08-23 20:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:27 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Router Class Initialized
INFO - 2023-08-23 20:36:27 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:27 --> Output Class Initialized
INFO - 2023-08-23 20:36:27 --> Security Class Initialized
INFO - 2023-08-23 20:36:27 --> Config Class Initialized
INFO - 2023-08-23 20:36:27 --> URI Class Initialized
INFO - 2023-08-23 20:36:27 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:27 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:27 --> Config Class Initialized
INFO - 2023-08-23 20:36:27 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Router Class Initialized
INFO - 2023-08-23 20:36:27 --> Input Class Initialized
INFO - 2023-08-23 20:36:27 --> URI Class Initialized
DEBUG - 2023-08-23 20:36:27 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:27 --> URI Class Initialized
INFO - 2023-08-23 20:36:27 --> Hooks Class Initialized
INFO - 2023-08-23 20:36:27 --> Output Class Initialized
INFO - 2023-08-23 20:36:27 --> Router Class Initialized
INFO - 2023-08-23 20:36:27 --> Language Class Initialized
INFO - 2023-08-23 20:36:27 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:27 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:27 --> Input Class Initialized
INFO - 2023-08-23 20:36:27 --> Language Class Initialized
ERROR - 2023-08-23 20:36:27 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:36:27 --> Output Class Initialized
DEBUG - 2023-08-23 20:36:28 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:28 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:28 --> URI Class Initialized
INFO - 2023-08-23 20:36:28 --> Router Class Initialized
INFO - 2023-08-23 20:36:28 --> Output Class Initialized
INFO - 2023-08-23 20:36:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:28 --> Input Class Initialized
INFO - 2023-08-23 20:36:28 --> Language Class Initialized
ERROR - 2023-08-23 20:36:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:36:28 --> Router Class Initialized
INFO - 2023-08-23 20:36:28 --> Security Class Initialized
INFO - 2023-08-23 20:36:28 --> URI Class Initialized
ERROR - 2023-08-23 20:36:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:28 --> Input Class Initialized
INFO - 2023-08-23 20:36:28 --> Output Class Initialized
INFO - 2023-08-23 20:36:28 --> Language Class Initialized
INFO - 2023-08-23 20:36:28 --> Router Class Initialized
ERROR - 2023-08-23 20:36:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:36:28 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:28 --> Output Class Initialized
INFO - 2023-08-23 20:36:28 --> Input Class Initialized
INFO - 2023-08-23 20:36:28 --> Language Class Initialized
INFO - 2023-08-23 20:36:28 --> Security Class Initialized
ERROR - 2023-08-23 20:36:28 --> 404 Page Not Found: Assets/home
DEBUG - 2023-08-23 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:28 --> Input Class Initialized
INFO - 2023-08-23 20:36:28 --> Language Class Initialized
ERROR - 2023-08-23 20:36:28 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:36:29 --> Config Class Initialized
INFO - 2023-08-23 20:36:29 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:36:29 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:36:29 --> Utf8 Class Initialized
INFO - 2023-08-23 20:36:29 --> URI Class Initialized
INFO - 2023-08-23 20:36:29 --> Router Class Initialized
INFO - 2023-08-23 20:36:29 --> Output Class Initialized
INFO - 2023-08-23 20:36:29 --> Security Class Initialized
DEBUG - 2023-08-23 20:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:36:29 --> Input Class Initialized
INFO - 2023-08-23 20:36:29 --> Language Class Initialized
INFO - 2023-08-23 20:36:29 --> Loader Class Initialized
INFO - 2023-08-23 20:36:29 --> Helper loaded: url_helper
INFO - 2023-08-23 20:36:29 --> Helper loaded: file_helper
INFO - 2023-08-23 20:36:29 --> Database Driver Class Initialized
INFO - 2023-08-23 20:36:29 --> Email Class Initialized
DEBUG - 2023-08-23 20:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:36:29 --> Controller Class Initialized
INFO - 2023-08-23 20:36:29 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:36:29 --> Model "Home_model" initialized
INFO - 2023-08-23 20:36:29 --> Helper loaded: download_helper
INFO - 2023-08-23 20:36:29 --> Helper loaded: form_helper
INFO - 2023-08-23 20:36:29 --> Form Validation Class Initialized
INFO - 2023-08-23 20:40:14 --> Config Class Initialized
INFO - 2023-08-23 20:40:14 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:40:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:40:14 --> Utf8 Class Initialized
INFO - 2023-08-23 20:40:14 --> URI Class Initialized
INFO - 2023-08-23 20:40:14 --> Router Class Initialized
INFO - 2023-08-23 20:40:14 --> Output Class Initialized
INFO - 2023-08-23 20:40:14 --> Security Class Initialized
DEBUG - 2023-08-23 20:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:40:14 --> Input Class Initialized
INFO - 2023-08-23 20:40:14 --> Language Class Initialized
INFO - 2023-08-23 20:40:14 --> Loader Class Initialized
INFO - 2023-08-23 20:40:14 --> Helper loaded: url_helper
INFO - 2023-08-23 20:40:14 --> Helper loaded: file_helper
INFO - 2023-08-23 20:40:14 --> Database Driver Class Initialized
INFO - 2023-08-23 20:40:14 --> Email Class Initialized
DEBUG - 2023-08-23 20:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:40:14 --> Controller Class Initialized
INFO - 2023-08-23 20:40:14 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:40:14 --> Model "Home_model" initialized
INFO - 2023-08-23 20:40:14 --> Helper loaded: download_helper
INFO - 2023-08-23 20:40:14 --> Helper loaded: form_helper
INFO - 2023-08-23 20:40:14 --> Form Validation Class Initialized
INFO - 2023-08-23 20:41:16 --> Config Class Initialized
INFO - 2023-08-23 20:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:16 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:16 --> URI Class Initialized
INFO - 2023-08-23 20:41:16 --> Router Class Initialized
INFO - 2023-08-23 20:41:16 --> Output Class Initialized
INFO - 2023-08-23 20:41:16 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:16 --> Input Class Initialized
INFO - 2023-08-23 20:41:16 --> Language Class Initialized
INFO - 2023-08-23 20:41:16 --> Loader Class Initialized
INFO - 2023-08-23 20:41:16 --> Helper loaded: url_helper
INFO - 2023-08-23 20:41:16 --> Helper loaded: file_helper
INFO - 2023-08-23 20:41:16 --> Database Driver Class Initialized
INFO - 2023-08-23 20:41:16 --> Email Class Initialized
DEBUG - 2023-08-23 20:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:41:16 --> Controller Class Initialized
INFO - 2023-08-23 20:41:16 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:41:16 --> Model "Home_model" initialized
INFO - 2023-08-23 20:41:16 --> Helper loaded: download_helper
INFO - 2023-08-23 20:41:16 --> Helper loaded: form_helper
INFO - 2023-08-23 20:41:16 --> Form Validation Class Initialized
INFO - 2023-08-23 20:41:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/training_detail.php
INFO - 2023-08-23 20:41:16 --> Final output sent to browser
DEBUG - 2023-08-23 20:41:16 --> Total execution time: 0.5223
INFO - 2023-08-23 20:41:17 --> Config Class Initialized
INFO - 2023-08-23 20:41:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:17 --> URI Class Initialized
INFO - 2023-08-23 20:41:17 --> Router Class Initialized
INFO - 2023-08-23 20:41:17 --> Output Class Initialized
INFO - 2023-08-23 20:41:17 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:17 --> Input Class Initialized
INFO - 2023-08-23 20:41:17 --> Language Class Initialized
ERROR - 2023-08-23 20:41:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:17 --> Config Class Initialized
INFO - 2023-08-23 20:41:17 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:17 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:17 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:17 --> URI Class Initialized
INFO - 2023-08-23 20:41:17 --> Router Class Initialized
INFO - 2023-08-23 20:41:17 --> Output Class Initialized
INFO - 2023-08-23 20:41:17 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:17 --> Input Class Initialized
INFO - 2023-08-23 20:41:17 --> Language Class Initialized
ERROR - 2023-08-23 20:41:17 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:18 --> Config Class Initialized
INFO - 2023-08-23 20:41:18 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:18 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:18 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:18 --> URI Class Initialized
INFO - 2023-08-23 20:41:18 --> Router Class Initialized
INFO - 2023-08-23 20:41:18 --> Output Class Initialized
INFO - 2023-08-23 20:41:18 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:18 --> Input Class Initialized
INFO - 2023-08-23 20:41:18 --> Language Class Initialized
ERROR - 2023-08-23 20:41:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:18 --> Config Class Initialized
INFO - 2023-08-23 20:41:18 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:18 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:18 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:18 --> URI Class Initialized
INFO - 2023-08-23 20:41:18 --> Router Class Initialized
INFO - 2023-08-23 20:41:18 --> Output Class Initialized
INFO - 2023-08-23 20:41:18 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:18 --> Input Class Initialized
INFO - 2023-08-23 20:41:18 --> Language Class Initialized
ERROR - 2023-08-23 20:41:18 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:18 --> Config Class Initialized
INFO - 2023-08-23 20:41:18 --> Hooks Class Initialized
INFO - 2023-08-23 20:41:19 --> Config Class Initialized
DEBUG - 2023-08-23 20:41:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:19 --> Config Class Initialized
INFO - 2023-08-23 20:41:19 --> Hooks Class Initialized
INFO - 2023-08-23 20:41:19 --> Utf8 Class Initialized
DEBUG - 2023-08-23 20:41:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:19 --> Hooks Class Initialized
INFO - 2023-08-23 20:41:19 --> URI Class Initialized
DEBUG - 2023-08-23 20:41:19 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:19 --> URI Class Initialized
INFO - 2023-08-23 20:41:19 --> Router Class Initialized
INFO - 2023-08-23 20:41:19 --> Router Class Initialized
INFO - 2023-08-23 20:41:19 --> Output Class Initialized
INFO - 2023-08-23 20:41:19 --> Output Class Initialized
INFO - 2023-08-23 20:41:19 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:19 --> Security Class Initialized
INFO - 2023-08-23 20:41:19 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:19 --> URI Class Initialized
INFO - 2023-08-23 20:41:19 --> Router Class Initialized
INFO - 2023-08-23 20:41:19 --> Input Class Initialized
INFO - 2023-08-23 20:41:19 --> Output Class Initialized
DEBUG - 2023-08-23 20:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:19 --> Security Class Initialized
INFO - 2023-08-23 20:41:19 --> Input Class Initialized
INFO - 2023-08-23 20:41:19 --> Language Class Initialized
DEBUG - 2023-08-23 20:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-23 20:41:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:19 --> Input Class Initialized
INFO - 2023-08-23 20:41:19 --> Language Class Initialized
INFO - 2023-08-23 20:41:19 --> Language Class Initialized
ERROR - 2023-08-23 20:41:19 --> 404 Page Not Found: Assets/home
ERROR - 2023-08-23 20:41:19 --> 404 Page Not Found: Assets/home
INFO - 2023-08-23 20:41:23 --> Config Class Initialized
INFO - 2023-08-23 20:41:23 --> Hooks Class Initialized
DEBUG - 2023-08-23 20:41:23 --> UTF-8 Support Enabled
INFO - 2023-08-23 20:41:23 --> Utf8 Class Initialized
INFO - 2023-08-23 20:41:23 --> URI Class Initialized
INFO - 2023-08-23 20:41:23 --> Router Class Initialized
INFO - 2023-08-23 20:41:23 --> Output Class Initialized
INFO - 2023-08-23 20:41:23 --> Security Class Initialized
DEBUG - 2023-08-23 20:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 20:41:23 --> Input Class Initialized
INFO - 2023-08-23 20:41:23 --> Language Class Initialized
INFO - 2023-08-23 20:41:23 --> Loader Class Initialized
INFO - 2023-08-23 20:41:23 --> Helper loaded: url_helper
INFO - 2023-08-23 20:41:23 --> Helper loaded: file_helper
INFO - 2023-08-23 20:41:23 --> Database Driver Class Initialized
INFO - 2023-08-23 20:41:23 --> Email Class Initialized
DEBUG - 2023-08-23 20:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-23 20:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 20:41:23 --> Controller Class Initialized
INFO - 2023-08-23 20:41:23 --> Model "Contact_model" initialized
INFO - 2023-08-23 20:41:23 --> Model "Home_model" initialized
INFO - 2023-08-23 20:41:23 --> Helper loaded: download_helper
INFO - 2023-08-23 20:41:23 --> Helper loaded: form_helper
INFO - 2023-08-23 20:41:23 --> Form Validation Class Initialized
