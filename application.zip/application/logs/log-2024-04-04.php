<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-04 17:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:42:30 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:12:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:12:31 --> Total execution time: 1.2230
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.1930
DEBUG - 2024-04-04 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2706
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2674
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2288
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2763
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2879
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:13:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:13:03 --> Total execution time: 0.2450
DEBUG - 2024-04-04 17:44:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:31 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:31 --> Total execution time: 0.1037
DEBUG - 2024-04-04 17:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:32 --> Total execution time: 0.0861
DEBUG - 2024-04-04 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:33 --> Total execution time: 0.0625
DEBUG - 2024-04-04 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:33 --> Total execution time: 0.1197
DEBUG - 2024-04-04 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:33 --> Total execution time: 0.0771
DEBUG - 2024-04-04 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:33 --> Total execution time: 0.1085
DEBUG - 2024-04-04 17:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:34 --> Total execution time: 0.0771
DEBUG - 2024-04-04 17:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:14:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:14:34 --> Total execution time: 0.0715
DEBUG - 2024-04-04 17:45:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:45 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:45 --> Total execution time: 0.0827
DEBUG - 2024-04-04 17:45:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:45:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:46 --> Total execution time: 0.2582
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:46 --> Total execution time: 0.2919
DEBUG - 2024-04-04 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:47 --> Total execution time: 0.1582
DEBUG - 2024-04-04 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:47 --> Total execution time: 0.1986
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:47 --> Total execution time: 0.1890
DEBUG - 2024-04-04 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:47 --> Total execution time: 0.1298
DEBUG - 2024-04-04 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:15:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:15:47 --> Total execution time: 0.1489
DEBUG - 2024-04-04 17:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:04 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:04 --> Total execution time: 0.1182
DEBUG - 2024-04-04 17:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:05 --> Total execution time: 0.2477
DEBUG - 2024-04-04 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:05 --> Total execution time: 0.4415
DEBUG - 2024-04-04 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:05 --> Total execution time: 1.1436
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:06 --> Total execution time: 0.2858
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:06 --> Total execution time: 0.5375
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:06 --> Total execution time: 1.2873
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:06 --> Total execution time: 0.2375
DEBUG - 2024-04-04 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:12 --> Total execution time: 0.1956
DEBUG - 2024-04-04 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.1456
DEBUG - 2024-04-04 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.1876
DEBUG - 2024-04-04 17:46:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.2007
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.1132
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.2902
DEBUG - 2024-04-04 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.2270
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:13 --> Total execution time: 0.4167
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.1623
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.1077
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.1582
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.2391
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.2188
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.2393
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:27 --> Total execution time: 0.2790
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:28 --> Total execution time: 0.2395
DEBUG - 2024-04-04 17:46:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.0727
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.1152
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.0630
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.0913
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.3753
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.1305
DEBUG - 2024-04-04 17:46:33 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.4257
DEBUG - 2024-04-04 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:16:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:16:33 --> Total execution time: 0.3928
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:34 --> Total execution time: 0.1192
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.4636
DEBUG - 2024-04-04 17:47:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.7159
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.6278
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.7868
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.7922
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.8596
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:35 --> Total execution time: 0.3372
DEBUG - 2024-04-04 17:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:51 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:51 --> Total execution time: 0.1215
DEBUG - 2024-04-04 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:47:51 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:51 --> Total execution time: 0.1060
DEBUG - 2024-04-04 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:51 --> Total execution time: 0.0853
DEBUG - 2024-04-04 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:51 --> Total execution time: 0.1202
DEBUG - 2024-04-04 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:51 --> Total execution time: 0.3172
DEBUG - 2024-04-04 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:52 --> Total execution time: 0.0918
DEBUG - 2024-04-04 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:52 --> Total execution time: 0.0693
DEBUG - 2024-04-04 17:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:17:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:17:52 --> Total execution time: 0.1099
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:20 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:20 --> Total execution time: 0.1172
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:20 --> Total execution time: 0.0657
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:20 --> Total execution time: 0.0913
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:21 --> Total execution time: 0.1542
DEBUG - 2024-04-04 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:21 --> Total execution time: 0.4123
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:21 --> Total execution time: 0.4194
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:21 --> Total execution time: 0.3880
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:21 --> Total execution time: 0.5226
DEBUG - 2024-04-04 17:48:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:27 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:27 --> Total execution time: 0.0885
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:28 --> Total execution time: 0.2159
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:28 --> Total execution time: 0.1924
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:29 --> Total execution time: 0.3738
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:29 --> Total execution time: 0.2279
DEBUG - 2024-04-04 17:48:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:29 --> Total execution time: 0.2211
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:29 --> Total execution time: 0.2819
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:29 --> Total execution time: 0.1949
DEBUG - 2024-04-04 17:48:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:35 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:35 --> Total execution time: 0.1302
DEBUG - 2024-04-04 17:48:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.1178
DEBUG - 2024-04-04 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.2458
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.0788
DEBUG - 2024-04-04 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.1238
DEBUG - 2024-04-04 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.0675
DEBUG - 2024-04-04 17:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:36 --> Total execution time: 0.2438
DEBUG - 2024-04-04 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:37 --> Total execution time: 0.3963
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:43 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.0807
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.1499
DEBUG - 2024-04-04 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.0686
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.0700
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.2439
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:43 --> Total execution time: 0.2526
DEBUG - 2024-04-04 17:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:44 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:44 --> Total execution time: 0.3274
DEBUG - 2024-04-04 17:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:44 --> Total execution time: 0.2051
DEBUG - 2024-04-04 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:47 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:47 --> Total execution time: 0.1499
DEBUG - 2024-04-04 17:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:48 --> Total execution time: 0.0729
DEBUG - 2024-04-04 17:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:48 --> Total execution time: 0.0791
DEBUG - 2024-04-04 17:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:48 --> Total execution time: 0.0654
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:48 --> Total execution time: 0.1090
DEBUG - 2024-04-04 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:49 --> Total execution time: 0.3216
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:49 --> Total execution time: 0.3613
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:49 --> Total execution time: 0.2697
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:51 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.0876
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.1526
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.1228
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.1541
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.1484
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.3990
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.4427
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:18:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:18:51 --> Total execution time: 0.2449
DEBUG - 2024-04-04 17:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:16 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:16 --> Total execution time: 0.0938
DEBUG - 2024-04-04 17:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.2341
DEBUG - 2024-04-04 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.3572
DEBUG - 2024-04-04 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.9251
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.3284
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.9869
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.4600
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:17 --> Total execution time: 0.2640
DEBUG - 2024-04-04 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:22 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:22 --> Total execution time: 0.0960
DEBUG - 2024-04-04 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:22 --> Total execution time: 0.0916
DEBUG - 2024-04-04 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:50:22 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:22 --> Total execution time: 0.1285
DEBUG - 2024-04-04 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:22 --> Total execution time: 0.1176
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:23 --> Total execution time: 0.2490
DEBUG - 2024-04-04 17:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:23 --> Total execution time: 0.0798
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:23 --> Total execution time: 0.1086
DEBUG - 2024-04-04 17:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:23 --> Total execution time: 0.0722
DEBUG - 2024-04-04 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:25 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:25 --> Total execution time: 0.0758
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:26 --> Total execution time: 0.0743
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:26 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.3765
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.4327
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.4224
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.5626
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.3398
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:27 --> Total execution time: 0.5928
DEBUG - 2024-04-04 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:36 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:36 --> Total execution time: 0.0675
DEBUG - 2024-04-04 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:36 --> Total execution time: 0.0908
DEBUG - 2024-04-04 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:36 --> Total execution time: 0.0703
DEBUG - 2024-04-04 17:50:37 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:37 --> Total execution time: 0.1718
DEBUG - 2024-04-04 17:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:37 --> Total execution time: 0.1154
DEBUG - 2024-04-04 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:37 --> Total execution time: 0.1471
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:37 --> Total execution time: 0.1143
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:37 --> Total execution time: 0.2226
DEBUG - 2024-04-04 17:50:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:40 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:40 --> Total execution time: 0.1652
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.0779
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.2009
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.1806
DEBUG - 2024-04-04 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.2408
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.2101
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.3934
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:41 --> Total execution time: 0.3876
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:59 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:59 --> Total execution time: 0.0972
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:59 --> Total execution time: 0.1553
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:59 --> Total execution time: 0.1238
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:20:59 --> Total execution time: 0.1466
DEBUG - 2024-04-04 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:50:59 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:20:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:00 --> Total execution time: 0.2452
DEBUG - 2024-04-04 17:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:00 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:00 --> Total execution time: 0.3140
DEBUG - 2024-04-04 17:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:00 --> Total execution time: 0.2763
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:00 --> Total execution time: 0.3637
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:02 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:02 --> Total execution time: 0.0699
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:02 --> Total execution time: 0.1921
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:02 --> Total execution time: 0.2320
DEBUG - 2024-04-04 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:02 --> Total execution time: 0.1847
DEBUG - 2024-04-04 17:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:02 --> Total execution time: 0.2069
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:03 --> Total execution time: 0.3656
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:03 --> Total execution time: 0.4712
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:03 --> Total execution time: 0.3291
DEBUG - 2024-04-04 17:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:04 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:04 --> Total execution time: 0.0803
DEBUG - 2024-04-04 17:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.4229
DEBUG - 2024-04-04 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.5188
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.0951
DEBUG - 2024-04-04 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.0701
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.2088
DEBUG - 2024-04-04 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.0762
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:05 --> Total execution time: 0.0900
DEBUG - 2024-04-04 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:18 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:18 --> Total execution time: 0.1018
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.1131
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.2567
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.3294
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.3261
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.1690
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.0613
DEBUG - 2024-04-04 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:19 --> Total execution time: 0.0974
DEBUG - 2024-04-04 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:41 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:41 --> Total execution time: 0.0702
DEBUG - 2024-04-04 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:42 --> Total execution time: 0.2384
DEBUG - 2024-04-04 17:51:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 0.3026
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 1.1162
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 1.2658
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 1.3033
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 1.5842
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:43 --> Total execution time: 0.3384
DEBUG - 2024-04-04 17:51:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:45 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:45 --> Total execution time: 0.0721
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:46 --> Total execution time: 0.1300
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:46 --> Total execution time: 0.2664
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 21:21:46 --> Total execution time: 0.4450
DEBUG - 2024-04-04 17:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:51:47 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:47 --> Total execution time: 0.4854
DEBUG - 2024-04-04 17:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:47 --> Total execution time: 0.9305
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:47 --> Total execution time: 0.1091
DEBUG - 2024-04-04 17:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:21:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:21:47 --> Total execution time: 0.1356
DEBUG - 2024-04-04 17:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:52:10 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:22:10 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:22:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:22:10 --> Total execution time: 0.0784
DEBUG - 2024-04-04 17:52:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:52:27 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:22:27 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:22:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:22:27 --> Total execution time: 0.1528
DEBUG - 2024-04-04 17:52:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:52:35 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:22:35 --> Severity: 8192 --> Implicit conversion from float 112.5 to int loses precision C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 299
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:22:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:22:35 --> Total execution time: 0.1088
DEBUG - 2024-04-04 17:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:52:42 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:22:42 --> Total execution time: 0.1716
DEBUG - 2024-04-04 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:22:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:22:56 --> Total execution time: 0.2874
DEBUG - 2024-04-04 17:53:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:00 --> Total execution time: 0.0944
DEBUG - 2024-04-04 17:53:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:23 --> Total execution time: 0.1418
DEBUG - 2024-04-04 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:30 --> Total execution time: 0.1028
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.0822
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.1033
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.1880
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.1940
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.2807
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.2701
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:23:44 --> Total execution time: 0.1615
DEBUG - 2024-04-04 17:54:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:17 --> Total execution time: 0.1355
DEBUG - 2024-04-04 17:54:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.1206
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.1492
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.9675
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 1.0018
DEBUG - 2024-04-04 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.0790
DEBUG - 2024-04-04 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.0675
DEBUG - 2024-04-04 17:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:18 --> Total execution time: 0.2976
DEBUG - 2024-04-04 17:54:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.1159
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.2305
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.0910
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.2881
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.0963
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:29 --> Total execution time: 0.0854
DEBUG - 2024-04-04 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:30 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:30 --> Total execution time: 0.2050
DEBUG - 2024-04-04 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:30 --> Total execution time: 0.1244
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:30 --> Total execution time: 0.1649
DEBUG - 2024-04-04 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:30 --> Total execution time: 0.0722
DEBUG - 2024-04-04 17:54:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.0727
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.1361
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.3241
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.4134
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.3561
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.2491
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.2309
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:34 --> Total execution time: 0.2995
DEBUG - 2024-04-04 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:35 --> Total execution time: 0.5572
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:35 --> Total execution time: 0.1304
DEBUG - 2024-04-04 17:54:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:24:35 --> Total execution time: 0.1647
DEBUG - 2024-04-04 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:12 --> Total execution time: 0.1452
DEBUG - 2024-04-04 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:12 --> Total execution time: 0.1378
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:12 --> Total execution time: 0.2701
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:12 --> Total execution time: 0.2543
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.1373
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.0628
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.0932
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.1584
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:56:13 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.0855
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-04 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.0843
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:26:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:26:13 --> Total execution time: 0.1277
DEBUG - 2024-04-04 17:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:05 --> Total execution time: 0.1310
DEBUG - 2024-04-04 17:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:05 --> Total execution time: 0.1739
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:05 --> Total execution time: 0.2186
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:05 --> Total execution time: 0.1342
DEBUG - 2024-04-04 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:07 --> Total execution time: 0.1288
DEBUG - 2024-04-04 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:07 --> Total execution time: 0.1797
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:08 --> Total execution time: 0.2080
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:08 --> Total execution time: 0.1511
DEBUG - 2024-04-04 17:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:10 --> Total execution time: 0.0684
DEBUG - 2024-04-04 17:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 17:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-04 17:57:10 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:10 --> Total execution time: 0.0727
DEBUG - 2024-04-04 17:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:10 --> Total execution time: 0.1134
DEBUG - 2024-04-04 17:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:27:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:27:10 --> Total execution time: 0.0942
DEBUG - 2024-04-04 17:59:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 17:59:54 --> No URI present. Default controller set.
DEBUG - 2024-04-04 17:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 17:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:29:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:29:54 --> Total execution time: 0.0955
DEBUG - 2024-04-04 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:13:41 --> No URI present. Default controller set.
DEBUG - 2024-04-04 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:43:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:43:41 --> Total execution time: 0.1097
DEBUG - 2024-04-04 18:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:43:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:43:43 --> Total execution time: 0.0743
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.0859
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 18:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.1375
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.2441
DEBUG - 2024-04-04 18:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.1960
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.1289
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:29 --> Total execution time: 0.1635
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:44:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:44:30 --> Total execution time: 0.2245
DEBUG - 2024-04-04 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:28 --> Total execution time: 0.0732
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.1014
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.1506
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.2119
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 18:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.4251
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.5014
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:29 --> Total execution time: 0.2786
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:45:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:45:30 --> Total execution time: 0.3940
DEBUG - 2024-04-04 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:46:28 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:22:07 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:07 --> Total execution time: 0.0915
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.2644
DEBUG - 2024-04-04 18:22:09 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.2332
DEBUG - 2024-04-04 18:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.5195
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.3687
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.6303
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.6876
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:52:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:52:09 --> Total execution time: 0.3972
DEBUG - 2024-04-04 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:02 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:53:02 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:23:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:51 --> Total execution time: 0.0890
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:52 --> Total execution time: 0.1301
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.7086
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.6079
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.6388
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.4359
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.7437
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:53:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:53:53 --> Total execution time: 0.8795
DEBUG - 2024-04-04 18:24:13 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:54:13 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:25:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:09 --> Total execution time: 0.1018
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.0950
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.1338
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.1732
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.1550
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.0917
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.1929
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:55:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:55:10 --> Total execution time: 0.1086
DEBUG - 2024-04-04 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:55:33 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:31 --> Total execution time: 0.1020
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.2224
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.1003
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.3850
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.1314
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.1441
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.2380
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:56:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:56:32 --> Total execution time: 0.2699
DEBUG - 2024-04-04 18:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:27:09 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:57:09 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:27:27 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 21:57:27 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:28:59 --> No URI present. Default controller set.
DEBUG - 2024-04-04 18:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 21:58:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 21:58:59 --> Total execution time: 0.0953
DEBUG - 2024-04-04 18:33:00 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:33:12 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 22:03:12 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:33:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 22:03:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 22:03:46 --> Total execution time: 0.0674
DEBUG - 2024-04-04 18:33:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 22:03:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 22:03:50 --> Total execution time: 0.0771
DEBUG - 2024-04-04 18:33:58 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 22:04:16 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 18:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-04 22:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-04 22:04:25 --> Total execution time: 0.0728
DEBUG - 2024-04-04 18:34:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:34:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:34:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-04 18:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-04 18:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-04 18:34:40 --> UTF-8 Support Enabled
