<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-20 11:22:56 --> Config Class Initialized
INFO - 2023-08-20 11:22:56 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:56 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:56 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:56 --> URI Class Initialized
INFO - 2023-08-20 11:22:56 --> Router Class Initialized
INFO - 2023-08-20 11:22:56 --> Output Class Initialized
INFO - 2023-08-20 11:22:56 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:56 --> Input Class Initialized
INFO - 2023-08-20 11:22:56 --> Language Class Initialized
INFO - 2023-08-20 11:22:56 --> Loader Class Initialized
INFO - 2023-08-20 11:22:56 --> Helper loaded: url_helper
INFO - 2023-08-20 11:22:56 --> Helper loaded: file_helper
INFO - 2023-08-20 11:22:56 --> Database Driver Class Initialized
INFO - 2023-08-20 11:22:56 --> Email Class Initialized
DEBUG - 2023-08-20 11:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:22:56 --> Controller Class Initialized
INFO - 2023-08-20 11:22:56 --> Model "Home_model" initialized
INFO - 2023-08-20 11:22:56 --> Helper loaded: form_helper
INFO - 2023-08-20 11:22:56 --> Form Validation Class Initialized
INFO - 2023-08-20 11:22:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-08-20 11:22:56 --> Final output sent to browser
DEBUG - 2023-08-20 11:22:56 --> Total execution time: 0.2440
INFO - 2023-08-20 11:22:56 --> Config Class Initialized
INFO - 2023-08-20 11:22:56 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:56 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:56 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:57 --> URI Class Initialized
INFO - 2023-08-20 11:22:57 --> Router Class Initialized
INFO - 2023-08-20 11:22:57 --> Output Class Initialized
INFO - 2023-08-20 11:22:57 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:57 --> Input Class Initialized
INFO - 2023-08-20 11:22:57 --> Language Class Initialized
ERROR - 2023-08-20 11:22:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:22:57 --> Config Class Initialized
INFO - 2023-08-20 11:22:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:57 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:57 --> URI Class Initialized
INFO - 2023-08-20 11:22:57 --> Router Class Initialized
INFO - 2023-08-20 11:22:57 --> Output Class Initialized
INFO - 2023-08-20 11:22:57 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:57 --> Input Class Initialized
INFO - 2023-08-20 11:22:57 --> Language Class Initialized
ERROR - 2023-08-20 11:22:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:22:57 --> Config Class Initialized
INFO - 2023-08-20 11:22:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:57 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:57 --> URI Class Initialized
INFO - 2023-08-20 11:22:57 --> Router Class Initialized
INFO - 2023-08-20 11:22:57 --> Output Class Initialized
INFO - 2023-08-20 11:22:57 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:57 --> Input Class Initialized
INFO - 2023-08-20 11:22:57 --> Language Class Initialized
ERROR - 2023-08-20 11:22:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:22:57 --> Config Class Initialized
INFO - 2023-08-20 11:22:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:57 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:57 --> URI Class Initialized
INFO - 2023-08-20 11:22:57 --> Router Class Initialized
INFO - 2023-08-20 11:22:57 --> Output Class Initialized
INFO - 2023-08-20 11:22:57 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:57 --> Input Class Initialized
INFO - 2023-08-20 11:22:57 --> Language Class Initialized
ERROR - 2023-08-20 11:22:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:22:57 --> Config Class Initialized
INFO - 2023-08-20 11:22:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:58 --> Config Class Initialized
INFO - 2023-08-20 11:22:58 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:22:58 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:22:58 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:58 --> URI Class Initialized
INFO - 2023-08-20 11:22:58 --> Router Class Initialized
INFO - 2023-08-20 11:22:58 --> Output Class Initialized
INFO - 2023-08-20 11:22:58 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:58 --> Input Class Initialized
INFO - 2023-08-20 11:22:58 --> Language Class Initialized
ERROR - 2023-08-20 11:22:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:22:58 --> Utf8 Class Initialized
INFO - 2023-08-20 11:22:58 --> URI Class Initialized
INFO - 2023-08-20 11:22:58 --> Router Class Initialized
INFO - 2023-08-20 11:22:58 --> Output Class Initialized
INFO - 2023-08-20 11:22:58 --> Security Class Initialized
DEBUG - 2023-08-20 11:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:22:58 --> Input Class Initialized
INFO - 2023-08-20 11:22:58 --> Language Class Initialized
ERROR - 2023-08-20 11:22:58 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:23:20 --> Config Class Initialized
INFO - 2023-08-20 11:23:20 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:23:20 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:23:20 --> Utf8 Class Initialized
INFO - 2023-08-20 11:23:20 --> URI Class Initialized
INFO - 2023-08-20 11:23:20 --> Router Class Initialized
INFO - 2023-08-20 11:23:20 --> Output Class Initialized
INFO - 2023-08-20 11:23:20 --> Security Class Initialized
DEBUG - 2023-08-20 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:23:20 --> Input Class Initialized
INFO - 2023-08-20 11:23:20 --> Language Class Initialized
INFO - 2023-08-20 11:23:20 --> Loader Class Initialized
INFO - 2023-08-20 11:23:20 --> Helper loaded: url_helper
INFO - 2023-08-20 11:23:20 --> Helper loaded: file_helper
INFO - 2023-08-20 11:23:20 --> Database Driver Class Initialized
INFO - 2023-08-20 11:23:20 --> Email Class Initialized
DEBUG - 2023-08-20 11:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:23:21 --> Controller Class Initialized
INFO - 2023-08-20 11:23:21 --> Config Class Initialized
INFO - 2023-08-20 11:23:21 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:23:21 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:23:21 --> Utf8 Class Initialized
INFO - 2023-08-20 11:23:21 --> URI Class Initialized
INFO - 2023-08-20 11:23:21 --> Router Class Initialized
INFO - 2023-08-20 11:23:21 --> Output Class Initialized
INFO - 2023-08-20 11:23:21 --> Security Class Initialized
DEBUG - 2023-08-20 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:23:21 --> Input Class Initialized
INFO - 2023-08-20 11:23:21 --> Language Class Initialized
INFO - 2023-08-20 11:23:21 --> Loader Class Initialized
INFO - 2023-08-20 11:23:21 --> Helper loaded: url_helper
INFO - 2023-08-20 11:23:21 --> Helper loaded: file_helper
INFO - 2023-08-20 11:23:21 --> Database Driver Class Initialized
INFO - 2023-08-20 11:23:21 --> Email Class Initialized
DEBUG - 2023-08-20 11:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:23:21 --> Controller Class Initialized
INFO - 2023-08-20 11:23:21 --> Model "User_model" initialized
INFO - 2023-08-20 11:23:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-20 11:23:21 --> Final output sent to browser
DEBUG - 2023-08-20 11:23:21 --> Total execution time: 0.0588
INFO - 2023-08-20 11:23:31 --> Config Class Initialized
INFO - 2023-08-20 11:23:31 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:23:31 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:23:31 --> Utf8 Class Initialized
INFO - 2023-08-20 11:23:31 --> URI Class Initialized
INFO - 2023-08-20 11:23:31 --> Router Class Initialized
INFO - 2023-08-20 11:23:31 --> Output Class Initialized
INFO - 2023-08-20 11:23:31 --> Security Class Initialized
DEBUG - 2023-08-20 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:23:31 --> Input Class Initialized
INFO - 2023-08-20 11:23:32 --> Language Class Initialized
INFO - 2023-08-20 11:23:32 --> Loader Class Initialized
INFO - 2023-08-20 11:23:32 --> Helper loaded: url_helper
INFO - 2023-08-20 11:23:32 --> Helper loaded: file_helper
INFO - 2023-08-20 11:23:32 --> Database Driver Class Initialized
INFO - 2023-08-20 11:23:32 --> Email Class Initialized
DEBUG - 2023-08-20 11:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:23:32 --> Controller Class Initialized
INFO - 2023-08-20 11:23:32 --> Model "User_model" initialized
INFO - 2023-08-20 11:23:32 --> Config Class Initialized
INFO - 2023-08-20 11:23:32 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:23:32 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:23:32 --> Utf8 Class Initialized
INFO - 2023-08-20 11:23:32 --> URI Class Initialized
INFO - 2023-08-20 11:23:32 --> Router Class Initialized
INFO - 2023-08-20 11:23:32 --> Output Class Initialized
INFO - 2023-08-20 11:23:32 --> Security Class Initialized
DEBUG - 2023-08-20 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:23:32 --> Input Class Initialized
INFO - 2023-08-20 11:23:32 --> Language Class Initialized
INFO - 2023-08-20 11:23:32 --> Loader Class Initialized
INFO - 2023-08-20 11:23:32 --> Helper loaded: url_helper
INFO - 2023-08-20 11:23:32 --> Helper loaded: file_helper
INFO - 2023-08-20 11:23:32 --> Database Driver Class Initialized
INFO - 2023-08-20 11:23:32 --> Email Class Initialized
DEBUG - 2023-08-20 11:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:23:32 --> Controller Class Initialized
INFO - 2023-08-20 11:23:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-20 11:23:32 --> Final output sent to browser
DEBUG - 2023-08-20 11:23:32 --> Total execution time: 0.0605
INFO - 2023-08-20 11:24:01 --> Config Class Initialized
INFO - 2023-08-20 11:24:01 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:01 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:01 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:01 --> URI Class Initialized
INFO - 2023-08-20 11:24:01 --> Router Class Initialized
INFO - 2023-08-20 11:24:01 --> Output Class Initialized
INFO - 2023-08-20 11:24:01 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:01 --> Input Class Initialized
INFO - 2023-08-20 11:24:01 --> Language Class Initialized
INFO - 2023-08-20 11:24:02 --> Loader Class Initialized
INFO - 2023-08-20 11:24:02 --> Helper loaded: url_helper
INFO - 2023-08-20 11:24:02 --> Helper loaded: file_helper
INFO - 2023-08-20 11:24:02 --> Database Driver Class Initialized
INFO - 2023-08-20 11:24:02 --> Email Class Initialized
DEBUG - 2023-08-20 11:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:24:02 --> Controller Class Initialized
INFO - 2023-08-20 11:24:02 --> Model "Services_model" initialized
INFO - 2023-08-20 11:24:02 --> Helper loaded: form_helper
INFO - 2023-08-20 11:24:02 --> Form Validation Class Initialized
INFO - 2023-08-20 11:24:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 11:24:02 --> Final output sent to browser
DEBUG - 2023-08-20 11:24:02 --> Total execution time: 0.4144
INFO - 2023-08-20 11:24:02 --> Config Class Initialized
INFO - 2023-08-20 11:24:02 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:02 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:02 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:02 --> URI Class Initialized
INFO - 2023-08-20 11:24:02 --> Router Class Initialized
INFO - 2023-08-20 11:24:02 --> Output Class Initialized
INFO - 2023-08-20 11:24:02 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:02 --> Input Class Initialized
INFO - 2023-08-20 11:24:02 --> Language Class Initialized
ERROR - 2023-08-20 11:24:02 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 11:24:04 --> Config Class Initialized
INFO - 2023-08-20 11:24:04 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:04 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:04 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:04 --> URI Class Initialized
INFO - 2023-08-20 11:24:04 --> Router Class Initialized
INFO - 2023-08-20 11:24:04 --> Output Class Initialized
INFO - 2023-08-20 11:24:04 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:04 --> Input Class Initialized
INFO - 2023-08-20 11:24:04 --> Language Class Initialized
INFO - 2023-08-20 11:24:04 --> Loader Class Initialized
INFO - 2023-08-20 11:24:04 --> Helper loaded: url_helper
INFO - 2023-08-20 11:24:04 --> Helper loaded: file_helper
INFO - 2023-08-20 11:24:04 --> Database Driver Class Initialized
INFO - 2023-08-20 11:24:04 --> Email Class Initialized
DEBUG - 2023-08-20 11:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:24:04 --> Controller Class Initialized
INFO - 2023-08-20 11:24:04 --> Model "Services_model" initialized
INFO - 2023-08-20 11:24:04 --> Helper loaded: form_helper
INFO - 2023-08-20 11:24:04 --> Form Validation Class Initialized
INFO - 2023-08-20 11:24:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-20 11:24:04 --> Final output sent to browser
DEBUG - 2023-08-20 11:24:04 --> Total execution time: 0.0787
INFO - 2023-08-20 11:24:08 --> Config Class Initialized
INFO - 2023-08-20 11:24:08 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:08 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:08 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:08 --> URI Class Initialized
INFO - 2023-08-20 11:24:08 --> Router Class Initialized
INFO - 2023-08-20 11:24:08 --> Output Class Initialized
INFO - 2023-08-20 11:24:08 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:08 --> Input Class Initialized
INFO - 2023-08-20 11:24:08 --> Language Class Initialized
INFO - 2023-08-20 11:24:08 --> Loader Class Initialized
INFO - 2023-08-20 11:24:08 --> Helper loaded: url_helper
INFO - 2023-08-20 11:24:08 --> Helper loaded: file_helper
INFO - 2023-08-20 11:24:08 --> Database Driver Class Initialized
INFO - 2023-08-20 11:24:08 --> Email Class Initialized
DEBUG - 2023-08-20 11:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:24:08 --> Controller Class Initialized
INFO - 2023-08-20 11:24:08 --> Model "Training_model" initialized
INFO - 2023-08-20 11:24:08 --> Helper loaded: form_helper
INFO - 2023-08-20 11:24:08 --> Form Validation Class Initialized
INFO - 2023-08-20 11:24:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-20 11:24:08 --> Final output sent to browser
DEBUG - 2023-08-20 11:24:08 --> Total execution time: 0.0779
INFO - 2023-08-20 11:24:10 --> Config Class Initialized
INFO - 2023-08-20 11:24:10 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:10 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:10 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:10 --> URI Class Initialized
INFO - 2023-08-20 11:24:10 --> Router Class Initialized
INFO - 2023-08-20 11:24:10 --> Output Class Initialized
INFO - 2023-08-20 11:24:10 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:10 --> Input Class Initialized
INFO - 2023-08-20 11:24:10 --> Language Class Initialized
INFO - 2023-08-20 11:24:10 --> Loader Class Initialized
INFO - 2023-08-20 11:24:10 --> Helper loaded: url_helper
INFO - 2023-08-20 11:24:10 --> Helper loaded: file_helper
INFO - 2023-08-20 11:24:10 --> Database Driver Class Initialized
INFO - 2023-08-20 11:24:10 --> Email Class Initialized
DEBUG - 2023-08-20 11:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:24:10 --> Controller Class Initialized
INFO - 2023-08-20 11:24:10 --> Model "Training_model" initialized
INFO - 2023-08-20 11:24:10 --> Helper loaded: form_helper
INFO - 2023-08-20 11:24:10 --> Form Validation Class Initialized
INFO - 2023-08-20 11:24:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:24:10 --> Final output sent to browser
DEBUG - 2023-08-20 11:24:10 --> Total execution time: 0.0814
INFO - 2023-08-20 11:24:11 --> Config Class Initialized
INFO - 2023-08-20 11:24:11 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:24:11 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:24:11 --> Utf8 Class Initialized
INFO - 2023-08-20 11:24:11 --> URI Class Initialized
INFO - 2023-08-20 11:24:11 --> Router Class Initialized
INFO - 2023-08-20 11:24:11 --> Output Class Initialized
INFO - 2023-08-20 11:24:11 --> Security Class Initialized
DEBUG - 2023-08-20 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:24:11 --> Input Class Initialized
INFO - 2023-08-20 11:24:11 --> Language Class Initialized
INFO - 2023-08-20 11:24:11 --> Loader Class Initialized
INFO - 2023-08-20 11:24:11 --> Helper loaded: url_helper
INFO - 2023-08-20 11:24:11 --> Helper loaded: file_helper
INFO - 2023-08-20 11:24:11 --> Database Driver Class Initialized
INFO - 2023-08-20 11:24:11 --> Email Class Initialized
DEBUG - 2023-08-20 11:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:24:11 --> Controller Class Initialized
INFO - 2023-08-20 11:24:11 --> Model "Training_model" initialized
INFO - 2023-08-20 11:24:11 --> Helper loaded: form_helper
INFO - 2023-08-20 11:24:11 --> Form Validation Class Initialized
INFO - 2023-08-20 11:24:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:24:11 --> Final output sent to browser
DEBUG - 2023-08-20 11:24:11 --> Total execution time: 0.0590
INFO - 2023-08-20 11:25:10 --> Config Class Initialized
INFO - 2023-08-20 11:25:10 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:25:10 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:25:10 --> Utf8 Class Initialized
INFO - 2023-08-20 11:25:10 --> URI Class Initialized
INFO - 2023-08-20 11:25:10 --> Router Class Initialized
INFO - 2023-08-20 11:25:10 --> Output Class Initialized
INFO - 2023-08-20 11:25:10 --> Security Class Initialized
DEBUG - 2023-08-20 11:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:25:10 --> Input Class Initialized
INFO - 2023-08-20 11:25:10 --> Language Class Initialized
INFO - 2023-08-20 11:25:10 --> Loader Class Initialized
INFO - 2023-08-20 11:25:10 --> Helper loaded: url_helper
INFO - 2023-08-20 11:25:10 --> Helper loaded: file_helper
INFO - 2023-08-20 11:25:10 --> Database Driver Class Initialized
INFO - 2023-08-20 11:25:11 --> Email Class Initialized
DEBUG - 2023-08-20 11:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:25:11 --> Controller Class Initialized
INFO - 2023-08-20 11:25:11 --> Model "Training_model" initialized
INFO - 2023-08-20 11:25:11 --> Helper loaded: form_helper
INFO - 2023-08-20 11:25:11 --> Form Validation Class Initialized
INFO - 2023-08-20 11:25:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:25:11 --> Final output sent to browser
DEBUG - 2023-08-20 11:25:11 --> Total execution time: 1.7389
INFO - 2023-08-20 11:25:12 --> Config Class Initialized
INFO - 2023-08-20 11:25:12 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:25:12 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:25:12 --> Utf8 Class Initialized
INFO - 2023-08-20 11:25:12 --> URI Class Initialized
INFO - 2023-08-20 11:25:12 --> Router Class Initialized
INFO - 2023-08-20 11:25:12 --> Output Class Initialized
INFO - 2023-08-20 11:25:12 --> Security Class Initialized
DEBUG - 2023-08-20 11:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:25:12 --> Input Class Initialized
INFO - 2023-08-20 11:25:12 --> Language Class Initialized
INFO - 2023-08-20 11:25:12 --> Loader Class Initialized
INFO - 2023-08-20 11:25:12 --> Helper loaded: url_helper
INFO - 2023-08-20 11:25:12 --> Helper loaded: file_helper
INFO - 2023-08-20 11:25:12 --> Database Driver Class Initialized
INFO - 2023-08-20 11:25:12 --> Email Class Initialized
DEBUG - 2023-08-20 11:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:25:12 --> Controller Class Initialized
INFO - 2023-08-20 11:25:12 --> Model "Training_model" initialized
INFO - 2023-08-20 11:25:12 --> Helper loaded: form_helper
INFO - 2023-08-20 11:25:12 --> Form Validation Class Initialized
INFO - 2023-08-20 11:25:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:25:12 --> Final output sent to browser
DEBUG - 2023-08-20 11:25:12 --> Total execution time: 0.0513
INFO - 2023-08-20 11:28:25 --> Config Class Initialized
INFO - 2023-08-20 11:28:25 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:28:25 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:28:25 --> Utf8 Class Initialized
INFO - 2023-08-20 11:28:25 --> URI Class Initialized
INFO - 2023-08-20 11:28:25 --> Router Class Initialized
INFO - 2023-08-20 11:28:25 --> Output Class Initialized
INFO - 2023-08-20 11:28:25 --> Security Class Initialized
DEBUG - 2023-08-20 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:28:25 --> Input Class Initialized
INFO - 2023-08-20 11:28:25 --> Language Class Initialized
INFO - 2023-08-20 11:28:25 --> Loader Class Initialized
INFO - 2023-08-20 11:28:25 --> Helper loaded: url_helper
INFO - 2023-08-20 11:28:25 --> Helper loaded: file_helper
INFO - 2023-08-20 11:28:25 --> Database Driver Class Initialized
INFO - 2023-08-20 11:28:25 --> Email Class Initialized
DEBUG - 2023-08-20 11:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:28:25 --> Controller Class Initialized
INFO - 2023-08-20 11:28:25 --> Model "Training_model" initialized
INFO - 2023-08-20 11:28:25 --> Helper loaded: form_helper
INFO - 2023-08-20 11:28:25 --> Form Validation Class Initialized
INFO - 2023-08-20 11:28:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:28:25 --> Final output sent to browser
DEBUG - 2023-08-20 11:28:25 --> Total execution time: 0.6926
INFO - 2023-08-20 11:28:40 --> Config Class Initialized
INFO - 2023-08-20 11:28:40 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:28:40 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:28:40 --> Utf8 Class Initialized
INFO - 2023-08-20 11:28:40 --> URI Class Initialized
INFO - 2023-08-20 11:28:40 --> Router Class Initialized
INFO - 2023-08-20 11:28:40 --> Output Class Initialized
INFO - 2023-08-20 11:28:40 --> Security Class Initialized
DEBUG - 2023-08-20 11:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:28:40 --> Input Class Initialized
INFO - 2023-08-20 11:28:40 --> Language Class Initialized
INFO - 2023-08-20 11:28:40 --> Loader Class Initialized
INFO - 2023-08-20 11:28:40 --> Helper loaded: url_helper
INFO - 2023-08-20 11:28:40 --> Helper loaded: file_helper
INFO - 2023-08-20 11:28:40 --> Database Driver Class Initialized
INFO - 2023-08-20 11:28:41 --> Email Class Initialized
DEBUG - 2023-08-20 11:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:28:41 --> Controller Class Initialized
INFO - 2023-08-20 11:28:41 --> Model "Training_model" initialized
INFO - 2023-08-20 11:28:41 --> Helper loaded: form_helper
INFO - 2023-08-20 11:28:41 --> Form Validation Class Initialized
INFO - 2023-08-20 11:28:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:28:41 --> Final output sent to browser
DEBUG - 2023-08-20 11:28:41 --> Total execution time: 1.2970
INFO - 2023-08-20 11:30:15 --> Config Class Initialized
INFO - 2023-08-20 11:30:15 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:30:15 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:30:15 --> Utf8 Class Initialized
INFO - 2023-08-20 11:30:15 --> URI Class Initialized
INFO - 2023-08-20 11:30:15 --> Router Class Initialized
INFO - 2023-08-20 11:30:15 --> Output Class Initialized
INFO - 2023-08-20 11:30:15 --> Security Class Initialized
DEBUG - 2023-08-20 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:30:15 --> Input Class Initialized
INFO - 2023-08-20 11:30:15 --> Language Class Initialized
INFO - 2023-08-20 11:30:16 --> Loader Class Initialized
INFO - 2023-08-20 11:30:16 --> Helper loaded: url_helper
INFO - 2023-08-20 11:30:16 --> Helper loaded: file_helper
INFO - 2023-08-20 11:30:16 --> Database Driver Class Initialized
INFO - 2023-08-20 11:30:16 --> Email Class Initialized
DEBUG - 2023-08-20 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:30:16 --> Controller Class Initialized
INFO - 2023-08-20 11:30:16 --> Model "Training_model" initialized
INFO - 2023-08-20 11:30:16 --> Helper loaded: form_helper
INFO - 2023-08-20 11:30:16 --> Form Validation Class Initialized
INFO - 2023-08-20 11:30:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:30:16 --> Final output sent to browser
DEBUG - 2023-08-20 11:30:16 --> Total execution time: 0.9913
INFO - 2023-08-20 11:30:19 --> Config Class Initialized
INFO - 2023-08-20 11:30:19 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:30:19 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:30:19 --> Utf8 Class Initialized
INFO - 2023-08-20 11:30:19 --> URI Class Initialized
INFO - 2023-08-20 11:30:19 --> Router Class Initialized
INFO - 2023-08-20 11:30:19 --> Output Class Initialized
INFO - 2023-08-20 11:30:19 --> Security Class Initialized
INFO - 2023-08-20 11:30:19 --> Helper loaded: form_helper
INFO - 2023-08-20 11:30:19 --> Form Validation Class Initialized
INFO - 2023-08-20 11:30:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:30:19 --> Final output sent to browser
DEBUG - 2023-08-20 11:30:19 --> Total execution time: 0.3835
INFO - 2023-08-20 11:32:07 --> Config Class Initialized
INFO - 2023-08-20 11:32:07 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:32:07 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:32:07 --> Utf8 Class Initialized
INFO - 2023-08-20 11:32:07 --> URI Class Initialized
INFO - 2023-08-20 11:32:07 --> Router Class Initialized
INFO - 2023-08-20 11:32:07 --> Output Class Initialized
INFO - 2023-08-20 11:32:07 --> Security Class Initialized
DEBUG - 2023-08-20 11:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:32:07 --> Input Class Initialized
INFO - 2023-08-20 11:32:07 --> Language Class Initialized
INFO - 2023-08-20 11:32:07 --> Loader Class Initialized
INFO - 2023-08-20 11:32:07 --> Helper loaded: url_helper
INFO - 2023-08-20 11:32:07 --> Helper loaded: file_helper
INFO - 2023-08-20 11:32:07 --> Database Driver Class Initialized
INFO - 2023-08-20 11:32:07 --> Email Class Initialized
DEBUG - 2023-08-20 11:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:32:07 --> Controller Class Initialized
INFO - 2023-08-20 11:32:07 --> Model "Training_model" initialized
INFO - 2023-08-20 11:32:07 --> Helper loaded: form_helper
INFO - 2023-08-20 11:32:07 --> Form Validation Class Initialized
INFO - 2023-08-20 11:32:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:32:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:32:07 --> Final output sent to browser
DEBUG - 2023-08-20 11:32:08 --> Total execution time: 0.4684
INFO - 2023-08-20 11:32:27 --> Config Class Initialized
INFO - 2023-08-20 11:32:27 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:32:27 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:32:27 --> Utf8 Class Initialized
INFO - 2023-08-20 11:32:28 --> URI Class Initialized
INFO - 2023-08-20 11:32:28 --> Router Class Initialized
INFO - 2023-08-20 11:32:28 --> Output Class Initialized
INFO - 2023-08-20 11:32:28 --> Security Class Initialized
DEBUG - 2023-08-20 11:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:32:29 --> Input Class Initialized
INFO - 2023-08-20 11:32:29 --> Language Class Initialized
ERROR - 2023-08-20 11:32:29 --> 404 Page Not Found: admin/Training/images
INFO - 2023-08-20 11:32:40 --> Config Class Initialized
INFO - 2023-08-20 11:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:32:40 --> Utf8 Class Initialized
INFO - 2023-08-20 11:32:40 --> URI Class Initialized
INFO - 2023-08-20 11:32:40 --> Router Class Initialized
INFO - 2023-08-20 11:32:40 --> Output Class Initialized
INFO - 2023-08-20 11:32:40 --> Security Class Initialized
DEBUG - 2023-08-20 11:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:32:40 --> Input Class Initialized
INFO - 2023-08-20 11:32:40 --> Language Class Initialized
INFO - 2023-08-20 11:32:40 --> Loader Class Initialized
INFO - 2023-08-20 11:32:40 --> Helper loaded: url_helper
INFO - 2023-08-20 11:32:40 --> Helper loaded: file_helper
INFO - 2023-08-20 11:32:40 --> Database Driver Class Initialized
INFO - 2023-08-20 11:32:40 --> Email Class Initialized
DEBUG - 2023-08-20 11:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:32:40 --> Controller Class Initialized
INFO - 2023-08-20 11:32:40 --> Model "Training_model" initialized
INFO - 2023-08-20 11:32:40 --> Helper loaded: form_helper
INFO - 2023-08-20 11:32:40 --> Form Validation Class Initialized
INFO - 2023-08-20 11:32:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:32:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:32:41 --> Final output sent to browser
DEBUG - 2023-08-20 11:32:41 --> Total execution time: 0.9414
INFO - 2023-08-20 11:33:39 --> Config Class Initialized
INFO - 2023-08-20 11:33:39 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:33:39 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:33:39 --> Utf8 Class Initialized
INFO - 2023-08-20 11:33:39 --> URI Class Initialized
INFO - 2023-08-20 11:33:39 --> Router Class Initialized
INFO - 2023-08-20 11:33:39 --> Output Class Initialized
INFO - 2023-08-20 11:33:40 --> Security Class Initialized
DEBUG - 2023-08-20 11:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:33:40 --> Input Class Initialized
INFO - 2023-08-20 11:33:40 --> Language Class Initialized
INFO - 2023-08-20 11:33:40 --> Loader Class Initialized
INFO - 2023-08-20 11:33:40 --> Helper loaded: url_helper
INFO - 2023-08-20 11:33:40 --> Helper loaded: file_helper
INFO - 2023-08-20 11:33:40 --> Database Driver Class Initialized
INFO - 2023-08-20 11:33:40 --> Email Class Initialized
DEBUG - 2023-08-20 11:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:33:40 --> Controller Class Initialized
INFO - 2023-08-20 11:33:40 --> Model "Training_model" initialized
INFO - 2023-08-20 11:33:40 --> Helper loaded: form_helper
INFO - 2023-08-20 11:33:40 --> Form Validation Class Initialized
INFO - 2023-08-20 11:33:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:33:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:33:40 --> Final output sent to browser
DEBUG - 2023-08-20 11:33:40 --> Total execution time: 0.8851
INFO - 2023-08-20 11:38:13 --> Config Class Initialized
INFO - 2023-08-20 11:38:13 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:38:13 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:38:13 --> Utf8 Class Initialized
INFO - 2023-08-20 11:38:13 --> URI Class Initialized
INFO - 2023-08-20 11:38:13 --> Router Class Initialized
INFO - 2023-08-20 11:38:13 --> Output Class Initialized
INFO - 2023-08-20 11:38:13 --> Security Class Initialized
DEBUG - 2023-08-20 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:38:13 --> Input Class Initialized
INFO - 2023-08-20 11:38:13 --> Language Class Initialized
INFO - 2023-08-20 11:38:13 --> Loader Class Initialized
INFO - 2023-08-20 11:38:13 --> Helper loaded: url_helper
INFO - 2023-08-20 11:38:13 --> Helper loaded: file_helper
INFO - 2023-08-20 11:38:13 --> Database Driver Class Initialized
INFO - 2023-08-20 11:38:13 --> Email Class Initialized
DEBUG - 2023-08-20 11:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:38:13 --> Controller Class Initialized
INFO - 2023-08-20 11:38:13 --> Model "Training_model" initialized
INFO - 2023-08-20 11:38:13 --> Helper loaded: form_helper
INFO - 2023-08-20 11:38:13 --> Form Validation Class Initialized
INFO - 2023-08-20 11:38:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:38:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:38:13 --> Final output sent to browser
DEBUG - 2023-08-20 11:38:13 --> Total execution time: 0.3077
INFO - 2023-08-20 11:38:18 --> Config Class Initialized
INFO - 2023-08-20 11:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:38:18 --> Utf8 Class Initialized
INFO - 2023-08-20 11:38:18 --> URI Class Initialized
INFO - 2023-08-20 11:38:18 --> Router Class Initialized
INFO - 2023-08-20 11:38:18 --> Output Class Initialized
INFO - 2023-08-20 11:38:18 --> Security Class Initialized
DEBUG - 2023-08-20 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:38:18 --> Input Class Initialized
INFO - 2023-08-20 11:38:18 --> Language Class Initialized
INFO - 2023-08-20 11:38:18 --> Loader Class Initialized
INFO - 2023-08-20 11:38:18 --> Helper loaded: url_helper
INFO - 2023-08-20 11:38:18 --> Helper loaded: file_helper
INFO - 2023-08-20 11:38:18 --> Database Driver Class Initialized
INFO - 2023-08-20 11:38:18 --> Email Class Initialized
DEBUG - 2023-08-20 11:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:38:18 --> Controller Class Initialized
INFO - 2023-08-20 11:38:18 --> Model "Training_model" initialized
INFO - 2023-08-20 11:38:18 --> Helper loaded: form_helper
INFO - 2023-08-20 11:38:18 --> Form Validation Class Initialized
INFO - 2023-08-20 11:38:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:38:18 --> Final output sent to browser
DEBUG - 2023-08-20 11:38:18 --> Total execution time: 0.0511
INFO - 2023-08-20 11:38:53 --> Config Class Initialized
INFO - 2023-08-20 11:38:53 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:38:53 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:38:53 --> Utf8 Class Initialized
INFO - 2023-08-20 11:38:53 --> URI Class Initialized
INFO - 2023-08-20 11:38:53 --> Router Class Initialized
INFO - 2023-08-20 11:38:53 --> Output Class Initialized
INFO - 2023-08-20 11:38:53 --> Security Class Initialized
DEBUG - 2023-08-20 11:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:38:53 --> Input Class Initialized
INFO - 2023-08-20 11:38:53 --> Language Class Initialized
INFO - 2023-08-20 11:38:53 --> Loader Class Initialized
INFO - 2023-08-20 11:38:53 --> Helper loaded: url_helper
INFO - 2023-08-20 11:38:53 --> Helper loaded: file_helper
INFO - 2023-08-20 11:38:53 --> Database Driver Class Initialized
INFO - 2023-08-20 11:38:54 --> Email Class Initialized
DEBUG - 2023-08-20 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:38:54 --> Controller Class Initialized
INFO - 2023-08-20 11:38:54 --> Model "Training_model" initialized
INFO - 2023-08-20 11:38:54 --> Helper loaded: form_helper
INFO - 2023-08-20 11:38:54 --> Form Validation Class Initialized
INFO - 2023-08-20 11:38:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:38:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:38:54 --> Final output sent to browser
DEBUG - 2023-08-20 11:38:54 --> Total execution time: 0.8358
INFO - 2023-08-20 11:39:57 --> Config Class Initialized
INFO - 2023-08-20 11:39:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:39:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:39:57 --> Utf8 Class Initialized
INFO - 2023-08-20 11:39:57 --> URI Class Initialized
INFO - 2023-08-20 11:39:57 --> Router Class Initialized
INFO - 2023-08-20 11:39:57 --> Output Class Initialized
INFO - 2023-08-20 11:39:57 --> Security Class Initialized
DEBUG - 2023-08-20 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:39:57 --> Input Class Initialized
INFO - 2023-08-20 11:39:57 --> Language Class Initialized
INFO - 2023-08-20 11:39:57 --> Loader Class Initialized
INFO - 2023-08-20 11:39:57 --> Helper loaded: url_helper
INFO - 2023-08-20 11:39:57 --> Helper loaded: file_helper
INFO - 2023-08-20 11:39:57 --> Database Driver Class Initialized
INFO - 2023-08-20 11:39:57 --> Email Class Initialized
DEBUG - 2023-08-20 11:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:39:58 --> Controller Class Initialized
INFO - 2023-08-20 11:39:58 --> Model "Training_model" initialized
INFO - 2023-08-20 11:39:58 --> Helper loaded: form_helper
INFO - 2023-08-20 11:39:58 --> Form Validation Class Initialized
INFO - 2023-08-20 11:39:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:39:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:39:58 --> Final output sent to browser
DEBUG - 2023-08-20 11:39:58 --> Total execution time: 0.8610
INFO - 2023-08-20 11:40:54 --> Config Class Initialized
INFO - 2023-08-20 11:40:54 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:40:54 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:40:54 --> Utf8 Class Initialized
INFO - 2023-08-20 11:40:54 --> URI Class Initialized
INFO - 2023-08-20 11:40:54 --> Router Class Initialized
INFO - 2023-08-20 11:40:54 --> Output Class Initialized
INFO - 2023-08-20 11:40:54 --> Security Class Initialized
DEBUG - 2023-08-20 11:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:40:54 --> Input Class Initialized
INFO - 2023-08-20 11:40:55 --> Language Class Initialized
INFO - 2023-08-20 11:40:55 --> Loader Class Initialized
INFO - 2023-08-20 11:40:55 --> Helper loaded: url_helper
INFO - 2023-08-20 11:40:55 --> Helper loaded: file_helper
INFO - 2023-08-20 11:40:55 --> Database Driver Class Initialized
INFO - 2023-08-20 11:40:55 --> Email Class Initialized
DEBUG - 2023-08-20 11:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:40:55 --> Controller Class Initialized
INFO - 2023-08-20 11:40:55 --> Model "Training_model" initialized
INFO - 2023-08-20 11:40:55 --> Helper loaded: form_helper
INFO - 2023-08-20 11:40:55 --> Form Validation Class Initialized
INFO - 2023-08-20 11:40:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:40:55 --> Config Class Initialized
INFO - 2023-08-20 11:40:55 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:40:55 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:40:55 --> Utf8 Class Initialized
INFO - 2023-08-20 11:40:55 --> URI Class Initialized
INFO - 2023-08-20 11:40:55 --> Router Class Initialized
INFO - 2023-08-20 11:40:55 --> Output Class Initialized
INFO - 2023-08-20 11:40:56 --> Security Class Initialized
DEBUG - 2023-08-20 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:40:56 --> Input Class Initialized
INFO - 2023-08-20 11:40:56 --> Language Class Initialized
INFO - 2023-08-20 11:40:56 --> Loader Class Initialized
INFO - 2023-08-20 11:40:56 --> Helper loaded: url_helper
INFO - 2023-08-20 11:40:56 --> Helper loaded: file_helper
INFO - 2023-08-20 11:40:56 --> Database Driver Class Initialized
INFO - 2023-08-20 11:40:56 --> Email Class Initialized
DEBUG - 2023-08-20 11:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:40:56 --> Controller Class Initialized
INFO - 2023-08-20 11:40:56 --> Model "Training_model" initialized
INFO - 2023-08-20 11:40:56 --> Helper loaded: form_helper
INFO - 2023-08-20 11:40:56 --> Form Validation Class Initialized
INFO - 2023-08-20 11:40:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-20 11:40:56 --> Final output sent to browser
DEBUG - 2023-08-20 11:40:57 --> Total execution time: 1.2590
INFO - 2023-08-20 11:40:57 --> Config Class Initialized
INFO - 2023-08-20 11:40:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:40:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:40:57 --> Utf8 Class Initialized
INFO - 2023-08-20 11:40:57 --> URI Class Initialized
INFO - 2023-08-20 11:40:58 --> Router Class Initialized
INFO - 2023-08-20 11:40:58 --> Output Class Initialized
INFO - 2023-08-20 11:40:58 --> Security Class Initialized
DEBUG - 2023-08-20 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:40:58 --> Input Class Initialized
INFO - 2023-08-20 11:40:58 --> Language Class Initialized
ERROR - 2023-08-20 11:40:58 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-20 11:42:13 --> Config Class Initialized
INFO - 2023-08-20 11:42:13 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:42:13 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:42:13 --> Utf8 Class Initialized
INFO - 2023-08-20 11:42:13 --> URI Class Initialized
INFO - 2023-08-20 11:42:13 --> Router Class Initialized
INFO - 2023-08-20 11:42:13 --> Output Class Initialized
INFO - 2023-08-20 11:42:13 --> Security Class Initialized
DEBUG - 2023-08-20 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:42:13 --> Input Class Initialized
INFO - 2023-08-20 11:42:13 --> Language Class Initialized
INFO - 2023-08-20 11:42:13 --> Loader Class Initialized
INFO - 2023-08-20 11:42:13 --> Helper loaded: url_helper
INFO - 2023-08-20 11:42:13 --> Helper loaded: file_helper
INFO - 2023-08-20 11:42:13 --> Database Driver Class Initialized
INFO - 2023-08-20 11:42:13 --> Email Class Initialized
DEBUG - 2023-08-20 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:42:13 --> Controller Class Initialized
INFO - 2023-08-20 11:42:13 --> Model "Training_model" initialized
INFO - 2023-08-20 11:42:13 --> Helper loaded: form_helper
INFO - 2023-08-20 11:42:13 --> Form Validation Class Initialized
INFO - 2023-08-20 11:42:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:42:13 --> Final output sent to browser
DEBUG - 2023-08-20 11:42:14 --> Total execution time: 0.4849
INFO - 2023-08-20 11:42:14 --> Config Class Initialized
INFO - 2023-08-20 11:42:14 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:42:14 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:42:14 --> Utf8 Class Initialized
INFO - 2023-08-20 11:42:14 --> URI Class Initialized
INFO - 2023-08-20 11:42:14 --> Router Class Initialized
INFO - 2023-08-20 11:42:14 --> Output Class Initialized
INFO - 2023-08-20 11:42:14 --> Security Class Initialized
DEBUG - 2023-08-20 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:42:14 --> Input Class Initialized
INFO - 2023-08-20 11:42:15 --> Language Class Initialized
INFO - 2023-08-20 11:42:15 --> Loader Class Initialized
INFO - 2023-08-20 11:42:15 --> Helper loaded: url_helper
INFO - 2023-08-20 11:42:15 --> Helper loaded: file_helper
INFO - 2023-08-20 11:42:15 --> Database Driver Class Initialized
INFO - 2023-08-20 11:42:15 --> Email Class Initialized
DEBUG - 2023-08-20 11:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:42:15 --> Controller Class Initialized
INFO - 2023-08-20 11:42:15 --> Model "Training_model" initialized
INFO - 2023-08-20 11:42:15 --> Helper loaded: form_helper
INFO - 2023-08-20 11:42:15 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 46
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 55
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 69
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 81
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 98
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 99
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 100
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 116
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 126
ERROR - 2023-08-20 11:42:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 127
INFO - 2023-08-20 11:42:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:42:15 --> Final output sent to browser
DEBUG - 2023-08-20 11:42:15 --> Total execution time: 0.8731
INFO - 2023-08-20 11:43:34 --> Config Class Initialized
INFO - 2023-08-20 11:43:34 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:43:34 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:43:34 --> Utf8 Class Initialized
INFO - 2023-08-20 11:43:34 --> URI Class Initialized
INFO - 2023-08-20 11:43:34 --> Router Class Initialized
INFO - 2023-08-20 11:43:34 --> Output Class Initialized
INFO - 2023-08-20 11:43:34 --> Security Class Initialized
DEBUG - 2023-08-20 11:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:43:35 --> Input Class Initialized
INFO - 2023-08-20 11:43:35 --> Language Class Initialized
INFO - 2023-08-20 11:43:35 --> Loader Class Initialized
INFO - 2023-08-20 11:43:35 --> Helper loaded: url_helper
INFO - 2023-08-20 11:43:35 --> Helper loaded: file_helper
INFO - 2023-08-20 11:43:35 --> Database Driver Class Initialized
INFO - 2023-08-20 11:43:35 --> Email Class Initialized
DEBUG - 2023-08-20 11:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:43:35 --> Controller Class Initialized
INFO - 2023-08-20 11:43:35 --> Model "Training_model" initialized
INFO - 2023-08-20 11:43:35 --> Helper loaded: form_helper
INFO - 2023-08-20 11:43:36 --> Form Validation Class Initialized
INFO - 2023-08-20 11:43:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:43:36 --> Final output sent to browser
DEBUG - 2023-08-20 11:43:36 --> Total execution time: 2.5048
INFO - 2023-08-20 11:43:37 --> Config Class Initialized
INFO - 2023-08-20 11:43:37 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:43:37 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:43:37 --> Utf8 Class Initialized
INFO - 2023-08-20 11:43:37 --> URI Class Initialized
INFO - 2023-08-20 11:43:37 --> Router Class Initialized
INFO - 2023-08-20 11:43:37 --> Output Class Initialized
INFO - 2023-08-20 11:43:37 --> Security Class Initialized
DEBUG - 2023-08-20 11:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:43:37 --> Input Class Initialized
INFO - 2023-08-20 11:43:37 --> Language Class Initialized
INFO - 2023-08-20 11:43:38 --> Loader Class Initialized
INFO - 2023-08-20 11:43:38 --> Helper loaded: url_helper
INFO - 2023-08-20 11:43:38 --> Helper loaded: file_helper
INFO - 2023-08-20 11:43:38 --> Database Driver Class Initialized
INFO - 2023-08-20 11:43:38 --> Email Class Initialized
DEBUG - 2023-08-20 11:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:43:38 --> Controller Class Initialized
INFO - 2023-08-20 11:43:38 --> Model "Training_model" initialized
INFO - 2023-08-20 11:43:38 --> Helper loaded: form_helper
INFO - 2023-08-20 11:43:38 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 39
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 46
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 55
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 69
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 81
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 98
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 99
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 100
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 116
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 127
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 137
ERROR - 2023-08-20 11:43:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 138
INFO - 2023-08-20 11:43:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:43:38 --> Final output sent to browser
DEBUG - 2023-08-20 11:43:38 --> Total execution time: 1.1810
INFO - 2023-08-20 11:45:48 --> Config Class Initialized
INFO - 2023-08-20 11:45:48 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:45:48 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:45:48 --> Utf8 Class Initialized
INFO - 2023-08-20 11:45:48 --> URI Class Initialized
INFO - 2023-08-20 11:45:48 --> Router Class Initialized
INFO - 2023-08-20 11:45:49 --> Output Class Initialized
INFO - 2023-08-20 11:45:49 --> Security Class Initialized
DEBUG - 2023-08-20 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:45:49 --> Input Class Initialized
INFO - 2023-08-20 11:45:49 --> Language Class Initialized
INFO - 2023-08-20 11:45:49 --> Loader Class Initialized
INFO - 2023-08-20 11:45:49 --> Helper loaded: url_helper
INFO - 2023-08-20 11:45:49 --> Helper loaded: file_helper
INFO - 2023-08-20 11:45:49 --> Database Driver Class Initialized
INFO - 2023-08-20 11:45:49 --> Email Class Initialized
DEBUG - 2023-08-20 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:45:49 --> Controller Class Initialized
INFO - 2023-08-20 11:45:49 --> Model "Training_model" initialized
INFO - 2023-08-20 11:45:49 --> Helper loaded: form_helper
INFO - 2023-08-20 11:45:49 --> Form Validation Class Initialized
INFO - 2023-08-20 11:45:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:45:49 --> Final output sent to browser
DEBUG - 2023-08-20 11:45:49 --> Total execution time: 0.8431
INFO - 2023-08-20 11:45:50 --> Config Class Initialized
INFO - 2023-08-20 11:45:50 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:45:50 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:45:50 --> Utf8 Class Initialized
INFO - 2023-08-20 11:45:50 --> URI Class Initialized
INFO - 2023-08-20 11:45:50 --> Router Class Initialized
INFO - 2023-08-20 11:45:50 --> Output Class Initialized
INFO - 2023-08-20 11:45:50 --> Security Class Initialized
DEBUG - 2023-08-20 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:45:50 --> Input Class Initialized
INFO - 2023-08-20 11:45:50 --> Language Class Initialized
INFO - 2023-08-20 11:45:50 --> Loader Class Initialized
INFO - 2023-08-20 11:45:50 --> Helper loaded: url_helper
INFO - 2023-08-20 11:45:50 --> Helper loaded: file_helper
INFO - 2023-08-20 11:45:50 --> Database Driver Class Initialized
INFO - 2023-08-20 11:45:50 --> Email Class Initialized
DEBUG - 2023-08-20 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:45:51 --> Controller Class Initialized
INFO - 2023-08-20 11:45:51 --> Model "Training_model" initialized
INFO - 2023-08-20 11:45:51 --> Helper loaded: form_helper
INFO - 2023-08-20 11:45:51 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:45:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
INFO - 2023-08-20 11:45:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:45:51 --> Final output sent to browser
DEBUG - 2023-08-20 11:45:51 --> Total execution time: 1.1703
INFO - 2023-08-20 11:52:41 --> Config Class Initialized
INFO - 2023-08-20 11:52:41 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:52:41 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:52:41 --> Utf8 Class Initialized
INFO - 2023-08-20 11:52:41 --> URI Class Initialized
INFO - 2023-08-20 11:52:41 --> Router Class Initialized
INFO - 2023-08-20 11:52:41 --> Output Class Initialized
INFO - 2023-08-20 11:52:41 --> Security Class Initialized
DEBUG - 2023-08-20 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:52:41 --> Input Class Initialized
INFO - 2023-08-20 11:52:41 --> Language Class Initialized
INFO - 2023-08-20 11:52:41 --> Loader Class Initialized
INFO - 2023-08-20 11:52:41 --> Helper loaded: url_helper
INFO - 2023-08-20 11:52:41 --> Helper loaded: file_helper
INFO - 2023-08-20 11:52:41 --> Database Driver Class Initialized
INFO - 2023-08-20 11:52:41 --> Email Class Initialized
DEBUG - 2023-08-20 11:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:52:41 --> Controller Class Initialized
INFO - 2023-08-20 11:52:41 --> Model "Training_model" initialized
INFO - 2023-08-20 11:52:41 --> Helper loaded: form_helper
INFO - 2023-08-20 11:52:41 --> Form Validation Class Initialized
INFO - 2023-08-20 11:52:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:52:42 --> Final output sent to browser
DEBUG - 2023-08-20 11:52:42 --> Total execution time: 0.9331
INFO - 2023-08-20 11:52:43 --> Config Class Initialized
INFO - 2023-08-20 11:52:43 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:52:43 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:52:43 --> Utf8 Class Initialized
INFO - 2023-08-20 11:52:43 --> URI Class Initialized
INFO - 2023-08-20 11:52:43 --> Router Class Initialized
INFO - 2023-08-20 11:52:43 --> Output Class Initialized
INFO - 2023-08-20 11:52:43 --> Security Class Initialized
DEBUG - 2023-08-20 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:52:43 --> Input Class Initialized
INFO - 2023-08-20 11:52:43 --> Language Class Initialized
INFO - 2023-08-20 11:52:43 --> Loader Class Initialized
INFO - 2023-08-20 11:52:43 --> Helper loaded: url_helper
INFO - 2023-08-20 11:52:43 --> Helper loaded: file_helper
INFO - 2023-08-20 11:52:43 --> Database Driver Class Initialized
INFO - 2023-08-20 11:52:43 --> Email Class Initialized
DEBUG - 2023-08-20 11:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:52:43 --> Controller Class Initialized
INFO - 2023-08-20 11:52:43 --> Model "Training_model" initialized
INFO - 2023-08-20 11:52:43 --> Helper loaded: form_helper
INFO - 2023-08-20 11:52:43 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:52:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-20 11:52:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-20 11:52:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:52:44 --> Final output sent to browser
DEBUG - 2023-08-20 11:52:44 --> Total execution time: 1.1190
INFO - 2023-08-20 11:53:25 --> Config Class Initialized
INFO - 2023-08-20 11:53:25 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:25 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:25 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:25 --> URI Class Initialized
INFO - 2023-08-20 11:53:25 --> Router Class Initialized
INFO - 2023-08-20 11:53:25 --> Output Class Initialized
INFO - 2023-08-20 11:53:25 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:25 --> Input Class Initialized
INFO - 2023-08-20 11:53:25 --> Language Class Initialized
INFO - 2023-08-20 11:53:25 --> Loader Class Initialized
INFO - 2023-08-20 11:53:25 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:26 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:26 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:26 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:26 --> Controller Class Initialized
INFO - 2023-08-20 11:53:26 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:26 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:26 --> Form Validation Class Initialized
INFO - 2023-08-20 11:53:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:53:26 --> Final output sent to browser
DEBUG - 2023-08-20 11:53:26 --> Total execution time: 0.8806
INFO - 2023-08-20 11:53:27 --> Config Class Initialized
INFO - 2023-08-20 11:53:27 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:27 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:28 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:28 --> URI Class Initialized
INFO - 2023-08-20 11:53:28 --> Router Class Initialized
INFO - 2023-08-20 11:53:28 --> Output Class Initialized
INFO - 2023-08-20 11:53:28 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:28 --> Input Class Initialized
INFO - 2023-08-20 11:53:28 --> Language Class Initialized
INFO - 2023-08-20 11:53:28 --> Loader Class Initialized
INFO - 2023-08-20 11:53:28 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:28 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:28 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:28 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:28 --> Controller Class Initialized
INFO - 2023-08-20 11:53:28 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:28 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:28 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-20 11:53:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-20 11:53:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:53:28 --> Final output sent to browser
DEBUG - 2023-08-20 11:53:29 --> Total execution time: 1.1838
INFO - 2023-08-20 11:53:37 --> Config Class Initialized
INFO - 2023-08-20 11:53:37 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:37 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:37 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:37 --> URI Class Initialized
INFO - 2023-08-20 11:53:37 --> Router Class Initialized
INFO - 2023-08-20 11:53:37 --> Output Class Initialized
INFO - 2023-08-20 11:53:37 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:37 --> Input Class Initialized
INFO - 2023-08-20 11:53:37 --> Language Class Initialized
INFO - 2023-08-20 11:53:37 --> Loader Class Initialized
INFO - 2023-08-20 11:53:37 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:37 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:37 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:37 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:37 --> Controller Class Initialized
INFO - 2023-08-20 11:53:37 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:38 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:38 --> Form Validation Class Initialized
INFO - 2023-08-20 11:53:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:53:38 --> Config Class Initialized
INFO - 2023-08-20 11:53:38 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:38 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:38 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:38 --> URI Class Initialized
INFO - 2023-08-20 11:53:38 --> Router Class Initialized
INFO - 2023-08-20 11:53:38 --> Output Class Initialized
INFO - 2023-08-20 11:53:38 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:38 --> Input Class Initialized
INFO - 2023-08-20 11:53:38 --> Language Class Initialized
INFO - 2023-08-20 11:53:38 --> Loader Class Initialized
INFO - 2023-08-20 11:53:38 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:38 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:38 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:38 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:38 --> Controller Class Initialized
INFO - 2023-08-20 11:53:38 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:38 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:38 --> Form Validation Class Initialized
INFO - 2023-08-20 11:53:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-20 11:53:38 --> Final output sent to browser
DEBUG - 2023-08-20 11:53:39 --> Total execution time: 0.6299
INFO - 2023-08-20 11:53:43 --> Config Class Initialized
INFO - 2023-08-20 11:53:43 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:43 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:43 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:43 --> URI Class Initialized
INFO - 2023-08-20 11:53:43 --> Router Class Initialized
INFO - 2023-08-20 11:53:43 --> Output Class Initialized
INFO - 2023-08-20 11:53:43 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:43 --> Input Class Initialized
INFO - 2023-08-20 11:53:43 --> Language Class Initialized
INFO - 2023-08-20 11:53:43 --> Loader Class Initialized
INFO - 2023-08-20 11:53:43 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:43 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:43 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:43 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:43 --> Controller Class Initialized
INFO - 2023-08-20 11:53:43 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:43 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:43 --> Form Validation Class Initialized
INFO - 2023-08-20 11:53:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:53:43 --> Final output sent to browser
DEBUG - 2023-08-20 11:53:44 --> Total execution time: 0.7329
INFO - 2023-08-20 11:53:44 --> Config Class Initialized
INFO - 2023-08-20 11:53:45 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:53:45 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:53:45 --> Utf8 Class Initialized
INFO - 2023-08-20 11:53:45 --> URI Class Initialized
INFO - 2023-08-20 11:53:45 --> Router Class Initialized
INFO - 2023-08-20 11:53:45 --> Output Class Initialized
INFO - 2023-08-20 11:53:45 --> Security Class Initialized
DEBUG - 2023-08-20 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:53:45 --> Input Class Initialized
INFO - 2023-08-20 11:53:45 --> Language Class Initialized
INFO - 2023-08-20 11:53:45 --> Loader Class Initialized
INFO - 2023-08-20 11:53:45 --> Helper loaded: url_helper
INFO - 2023-08-20 11:53:45 --> Helper loaded: file_helper
INFO - 2023-08-20 11:53:45 --> Database Driver Class Initialized
INFO - 2023-08-20 11:53:45 --> Email Class Initialized
DEBUG - 2023-08-20 11:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:53:45 --> Controller Class Initialized
INFO - 2023-08-20 11:53:45 --> Model "Training_model" initialized
INFO - 2023-08-20 11:53:45 --> Helper loaded: form_helper
INFO - 2023-08-20 11:53:45 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:53:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:53:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:53:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:53:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-20 11:53:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-20 11:53:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-20 11:53:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:53:46 --> Final output sent to browser
DEBUG - 2023-08-20 11:53:46 --> Total execution time: 1.1796
INFO - 2023-08-20 11:54:28 --> Config Class Initialized
INFO - 2023-08-20 11:54:28 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:54:28 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:54:28 --> Utf8 Class Initialized
INFO - 2023-08-20 11:54:28 --> URI Class Initialized
INFO - 2023-08-20 11:54:28 --> Router Class Initialized
INFO - 2023-08-20 11:54:28 --> Output Class Initialized
INFO - 2023-08-20 11:54:28 --> Security Class Initialized
DEBUG - 2023-08-20 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:54:28 --> Input Class Initialized
INFO - 2023-08-20 11:54:28 --> Language Class Initialized
INFO - 2023-08-20 11:54:28 --> Loader Class Initialized
INFO - 2023-08-20 11:54:28 --> Helper loaded: url_helper
INFO - 2023-08-20 11:54:28 --> Helper loaded: file_helper
INFO - 2023-08-20 11:54:28 --> Database Driver Class Initialized
INFO - 2023-08-20 11:54:28 --> Email Class Initialized
DEBUG - 2023-08-20 11:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:54:28 --> Controller Class Initialized
INFO - 2023-08-20 11:54:28 --> Model "Training_model" initialized
INFO - 2023-08-20 11:54:28 --> Helper loaded: form_helper
INFO - 2023-08-20 11:54:28 --> Form Validation Class Initialized
INFO - 2023-08-20 11:54:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 11:54:29 --> Config Class Initialized
INFO - 2023-08-20 11:54:29 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:54:29 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:54:29 --> Utf8 Class Initialized
INFO - 2023-08-20 11:54:29 --> URI Class Initialized
INFO - 2023-08-20 11:54:29 --> Router Class Initialized
INFO - 2023-08-20 11:54:29 --> Output Class Initialized
INFO - 2023-08-20 11:54:29 --> Security Class Initialized
DEBUG - 2023-08-20 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:54:29 --> Input Class Initialized
INFO - 2023-08-20 11:54:29 --> Language Class Initialized
INFO - 2023-08-20 11:54:29 --> Loader Class Initialized
INFO - 2023-08-20 11:54:29 --> Helper loaded: url_helper
INFO - 2023-08-20 11:54:30 --> Helper loaded: file_helper
INFO - 2023-08-20 11:54:30 --> Database Driver Class Initialized
INFO - 2023-08-20 11:54:30 --> Email Class Initialized
DEBUG - 2023-08-20 11:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:54:30 --> Controller Class Initialized
INFO - 2023-08-20 11:54:30 --> Model "Training_model" initialized
INFO - 2023-08-20 11:54:30 --> Helper loaded: form_helper
INFO - 2023-08-20 11:54:30 --> Form Validation Class Initialized
INFO - 2023-08-20 11:54:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-20 11:54:30 --> Final output sent to browser
DEBUG - 2023-08-20 11:54:30 --> Total execution time: 0.6286
INFO - 2023-08-20 11:54:36 --> Config Class Initialized
INFO - 2023-08-20 11:54:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:54:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:54:36 --> Utf8 Class Initialized
INFO - 2023-08-20 11:54:36 --> URI Class Initialized
INFO - 2023-08-20 11:54:36 --> Router Class Initialized
INFO - 2023-08-20 11:54:36 --> Output Class Initialized
INFO - 2023-08-20 11:54:36 --> Security Class Initialized
DEBUG - 2023-08-20 11:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:54:36 --> Input Class Initialized
INFO - 2023-08-20 11:54:37 --> Language Class Initialized
INFO - 2023-08-20 11:54:37 --> Loader Class Initialized
INFO - 2023-08-20 11:54:37 --> Helper loaded: url_helper
INFO - 2023-08-20 11:54:37 --> Helper loaded: file_helper
INFO - 2023-08-20 11:54:37 --> Database Driver Class Initialized
INFO - 2023-08-20 11:54:37 --> Email Class Initialized
DEBUG - 2023-08-20 11:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:54:37 --> Controller Class Initialized
INFO - 2023-08-20 11:54:37 --> Model "Training_model" initialized
INFO - 2023-08-20 11:54:37 --> Helper loaded: form_helper
INFO - 2023-08-20 11:54:37 --> Form Validation Class Initialized
INFO - 2023-08-20 11:54:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:54:37 --> Final output sent to browser
DEBUG - 2023-08-20 11:54:37 --> Total execution time: 0.7865
INFO - 2023-08-20 11:54:38 --> Config Class Initialized
INFO - 2023-08-20 11:54:38 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:54:38 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:54:38 --> Utf8 Class Initialized
INFO - 2023-08-20 11:54:38 --> URI Class Initialized
INFO - 2023-08-20 11:54:38 --> Router Class Initialized
INFO - 2023-08-20 11:54:38 --> Output Class Initialized
INFO - 2023-08-20 11:54:38 --> Security Class Initialized
DEBUG - 2023-08-20 11:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:54:38 --> Input Class Initialized
INFO - 2023-08-20 11:54:38 --> Language Class Initialized
INFO - 2023-08-20 11:54:38 --> Loader Class Initialized
INFO - 2023-08-20 11:54:38 --> Helper loaded: url_helper
INFO - 2023-08-20 11:54:38 --> Helper loaded: file_helper
INFO - 2023-08-20 11:54:38 --> Database Driver Class Initialized
INFO - 2023-08-20 11:54:38 --> Email Class Initialized
DEBUG - 2023-08-20 11:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:54:38 --> Controller Class Initialized
INFO - 2023-08-20 11:54:38 --> Model "Training_model" initialized
INFO - 2023-08-20 11:54:38 --> Helper loaded: form_helper
INFO - 2023-08-20 11:54:39 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-20 11:54:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-20 11:54:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:54:39 --> Final output sent to browser
DEBUG - 2023-08-20 11:54:39 --> Total execution time: 0.9578
INFO - 2023-08-20 11:58:16 --> Config Class Initialized
INFO - 2023-08-20 11:58:16 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:58:16 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:58:16 --> Utf8 Class Initialized
INFO - 2023-08-20 11:58:16 --> URI Class Initialized
INFO - 2023-08-20 11:58:16 --> Router Class Initialized
INFO - 2023-08-20 11:58:16 --> Output Class Initialized
INFO - 2023-08-20 11:58:16 --> Security Class Initialized
DEBUG - 2023-08-20 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:58:16 --> Input Class Initialized
INFO - 2023-08-20 11:58:16 --> Language Class Initialized
INFO - 2023-08-20 11:58:16 --> Loader Class Initialized
INFO - 2023-08-20 11:58:16 --> Helper loaded: url_helper
INFO - 2023-08-20 11:58:16 --> Helper loaded: file_helper
INFO - 2023-08-20 11:58:16 --> Database Driver Class Initialized
INFO - 2023-08-20 11:58:16 --> Email Class Initialized
DEBUG - 2023-08-20 11:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:58:16 --> Controller Class Initialized
INFO - 2023-08-20 11:58:16 --> Model "Training_model" initialized
INFO - 2023-08-20 11:58:16 --> Helper loaded: form_helper
INFO - 2023-08-20 11:58:17 --> Form Validation Class Initialized
INFO - 2023-08-20 11:58:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:58:17 --> Final output sent to browser
DEBUG - 2023-08-20 11:58:17 --> Total execution time: 0.8565
INFO - 2023-08-20 11:58:18 --> Config Class Initialized
INFO - 2023-08-20 11:58:18 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:58:18 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:58:18 --> Utf8 Class Initialized
INFO - 2023-08-20 11:58:18 --> URI Class Initialized
INFO - 2023-08-20 11:58:18 --> Router Class Initialized
INFO - 2023-08-20 11:58:18 --> Output Class Initialized
INFO - 2023-08-20 11:58:18 --> Security Class Initialized
DEBUG - 2023-08-20 11:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:58:18 --> Input Class Initialized
INFO - 2023-08-20 11:58:18 --> Language Class Initialized
INFO - 2023-08-20 11:58:18 --> Loader Class Initialized
INFO - 2023-08-20 11:58:18 --> Helper loaded: url_helper
INFO - 2023-08-20 11:58:18 --> Helper loaded: file_helper
INFO - 2023-08-20 11:58:18 --> Database Driver Class Initialized
INFO - 2023-08-20 11:58:18 --> Email Class Initialized
DEBUG - 2023-08-20 11:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:58:19 --> Controller Class Initialized
INFO - 2023-08-20 11:58:19 --> Model "Training_model" initialized
INFO - 2023-08-20 11:58:19 --> Helper loaded: form_helper
INFO - 2023-08-20 11:58:19 --> Form Validation Class Initialized
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 40
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 49
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 60
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 75
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 88
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 105
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 118
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 133
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 134
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 135
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 152
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 164
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 175
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 177
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 180
ERROR - 2023-08-20 11:58:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\training_edit.php 182
INFO - 2023-08-20 11:58:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_edit.php
INFO - 2023-08-20 11:58:19 --> Final output sent to browser
DEBUG - 2023-08-20 11:58:19 --> Total execution time: 1.1672
INFO - 2023-08-20 11:58:26 --> Config Class Initialized
INFO - 2023-08-20 11:58:26 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:58:26 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:58:26 --> Utf8 Class Initialized
INFO - 2023-08-20 11:58:26 --> URI Class Initialized
INFO - 2023-08-20 11:58:26 --> Router Class Initialized
INFO - 2023-08-20 11:58:26 --> Output Class Initialized
INFO - 2023-08-20 11:58:26 --> Security Class Initialized
DEBUG - 2023-08-20 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:58:26 --> Input Class Initialized
INFO - 2023-08-20 11:58:26 --> Language Class Initialized
INFO - 2023-08-20 11:58:26 --> Loader Class Initialized
INFO - 2023-08-20 11:58:26 --> Helper loaded: url_helper
INFO - 2023-08-20 11:58:26 --> Helper loaded: file_helper
INFO - 2023-08-20 11:58:26 --> Database Driver Class Initialized
INFO - 2023-08-20 11:58:26 --> Email Class Initialized
DEBUG - 2023-08-20 11:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:58:27 --> Controller Class Initialized
INFO - 2023-08-20 11:58:27 --> Model "Training_model" initialized
INFO - 2023-08-20 11:58:27 --> Helper loaded: form_helper
INFO - 2023-08-20 11:58:27 --> Form Validation Class Initialized
INFO - 2023-08-20 11:58:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_list.php
INFO - 2023-08-20 11:58:27 --> Final output sent to browser
DEBUG - 2023-08-20 11:58:27 --> Total execution time: 0.7400
INFO - 2023-08-20 11:58:29 --> Config Class Initialized
INFO - 2023-08-20 11:58:29 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:58:29 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:58:29 --> Utf8 Class Initialized
INFO - 2023-08-20 11:58:29 --> URI Class Initialized
INFO - 2023-08-20 11:58:29 --> Router Class Initialized
INFO - 2023-08-20 11:58:29 --> Output Class Initialized
INFO - 2023-08-20 11:58:29 --> Security Class Initialized
DEBUG - 2023-08-20 11:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:58:29 --> Input Class Initialized
INFO - 2023-08-20 11:58:29 --> Language Class Initialized
INFO - 2023-08-20 11:58:29 --> Loader Class Initialized
INFO - 2023-08-20 11:58:29 --> Helper loaded: url_helper
INFO - 2023-08-20 11:58:29 --> Helper loaded: file_helper
INFO - 2023-08-20 11:58:29 --> Database Driver Class Initialized
INFO - 2023-08-20 11:58:29 --> Email Class Initialized
DEBUG - 2023-08-20 11:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:58:30 --> Controller Class Initialized
INFO - 2023-08-20 11:58:30 --> Model "Training_model" initialized
INFO - 2023-08-20 11:58:30 --> Helper loaded: form_helper
INFO - 2023-08-20 11:58:30 --> Form Validation Class Initialized
INFO - 2023-08-20 11:58:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:58:30 --> Final output sent to browser
DEBUG - 2023-08-20 11:58:30 --> Total execution time: 0.9422
INFO - 2023-08-20 11:58:31 --> Config Class Initialized
INFO - 2023-08-20 11:58:31 --> Hooks Class Initialized
DEBUG - 2023-08-20 11:58:31 --> UTF-8 Support Enabled
INFO - 2023-08-20 11:58:31 --> Utf8 Class Initialized
INFO - 2023-08-20 11:58:31 --> URI Class Initialized
INFO - 2023-08-20 11:58:31 --> Router Class Initialized
INFO - 2023-08-20 11:58:31 --> Output Class Initialized
INFO - 2023-08-20 11:58:31 --> Security Class Initialized
DEBUG - 2023-08-20 11:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 11:58:31 --> Input Class Initialized
INFO - 2023-08-20 11:58:31 --> Language Class Initialized
INFO - 2023-08-20 11:58:31 --> Loader Class Initialized
INFO - 2023-08-20 11:58:31 --> Helper loaded: url_helper
INFO - 2023-08-20 11:58:31 --> Helper loaded: file_helper
INFO - 2023-08-20 11:58:31 --> Database Driver Class Initialized
INFO - 2023-08-20 11:58:31 --> Email Class Initialized
DEBUG - 2023-08-20 11:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 11:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 11:58:31 --> Controller Class Initialized
INFO - 2023-08-20 11:58:31 --> Model "Training_model" initialized
INFO - 2023-08-20 11:58:31 --> Helper loaded: form_helper
INFO - 2023-08-20 11:58:31 --> Form Validation Class Initialized
INFO - 2023-08-20 11:58:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 11:58:31 --> Final output sent to browser
DEBUG - 2023-08-20 11:58:31 --> Total execution time: 0.6078
INFO - 2023-08-20 12:09:44 --> Config Class Initialized
INFO - 2023-08-20 12:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:09:44 --> Utf8 Class Initialized
INFO - 2023-08-20 12:09:44 --> URI Class Initialized
INFO - 2023-08-20 12:09:44 --> Router Class Initialized
INFO - 2023-08-20 12:09:44 --> Output Class Initialized
INFO - 2023-08-20 12:09:44 --> Security Class Initialized
DEBUG - 2023-08-20 12:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:09:44 --> Input Class Initialized
INFO - 2023-08-20 12:09:44 --> Language Class Initialized
INFO - 2023-08-20 12:09:44 --> Loader Class Initialized
INFO - 2023-08-20 12:09:45 --> Helper loaded: url_helper
INFO - 2023-08-20 12:09:45 --> Helper loaded: file_helper
INFO - 2023-08-20 12:09:45 --> Database Driver Class Initialized
INFO - 2023-08-20 12:09:45 --> Email Class Initialized
DEBUG - 2023-08-20 12:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:09:45 --> Controller Class Initialized
INFO - 2023-08-20 12:09:45 --> Model "Training_model" initialized
INFO - 2023-08-20 12:09:45 --> Helper loaded: form_helper
INFO - 2023-08-20 12:09:45 --> Form Validation Class Initialized
INFO - 2023-08-20 12:09:45 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 12:09:45 --> Final output sent to browser
DEBUG - 2023-08-20 12:09:45 --> Total execution time: 0.8646
INFO - 2023-08-20 12:09:46 --> Config Class Initialized
INFO - 2023-08-20 12:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:09:46 --> Utf8 Class Initialized
INFO - 2023-08-20 12:09:46 --> URI Class Initialized
INFO - 2023-08-20 12:09:46 --> Router Class Initialized
INFO - 2023-08-20 12:09:46 --> Output Class Initialized
INFO - 2023-08-20 12:09:46 --> Security Class Initialized
DEBUG - 2023-08-20 12:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:09:46 --> Input Class Initialized
INFO - 2023-08-20 12:09:46 --> Language Class Initialized
INFO - 2023-08-20 12:09:46 --> Loader Class Initialized
INFO - 2023-08-20 12:09:46 --> Helper loaded: url_helper
INFO - 2023-08-20 12:09:46 --> Helper loaded: file_helper
INFO - 2023-08-20 12:09:46 --> Database Driver Class Initialized
INFO - 2023-08-20 12:09:46 --> Email Class Initialized
DEBUG - 2023-08-20 12:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:09:46 --> Controller Class Initialized
INFO - 2023-08-20 12:09:46 --> Model "Training_model" initialized
INFO - 2023-08-20 12:09:46 --> Helper loaded: form_helper
INFO - 2023-08-20 12:09:46 --> Form Validation Class Initialized
INFO - 2023-08-20 12:09:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 12:09:46 --> Final output sent to browser
DEBUG - 2023-08-20 12:09:46 --> Total execution time: 0.0989
INFO - 2023-08-20 12:11:42 --> Config Class Initialized
INFO - 2023-08-20 12:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:11:42 --> Utf8 Class Initialized
INFO - 2023-08-20 12:11:42 --> URI Class Initialized
INFO - 2023-08-20 12:11:42 --> Router Class Initialized
INFO - 2023-08-20 12:11:42 --> Output Class Initialized
INFO - 2023-08-20 12:11:42 --> Security Class Initialized
DEBUG - 2023-08-20 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:11:42 --> Input Class Initialized
INFO - 2023-08-20 12:11:42 --> Language Class Initialized
ERROR - 2023-08-20 12:11:42 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-20 12:11:42 --> Config Class Initialized
INFO - 2023-08-20 12:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:11:42 --> Utf8 Class Initialized
INFO - 2023-08-20 12:11:42 --> URI Class Initialized
INFO - 2023-08-20 12:11:42 --> Router Class Initialized
INFO - 2023-08-20 12:11:42 --> Output Class Initialized
INFO - 2023-08-20 12:11:42 --> Security Class Initialized
DEBUG - 2023-08-20 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:11:42 --> Input Class Initialized
INFO - 2023-08-20 12:11:42 --> Language Class Initialized
ERROR - 2023-08-20 12:11:42 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-20 12:18:06 --> Config Class Initialized
INFO - 2023-08-20 12:18:06 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:18:06 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:18:06 --> Utf8 Class Initialized
INFO - 2023-08-20 12:18:06 --> URI Class Initialized
INFO - 2023-08-20 12:18:06 --> Router Class Initialized
INFO - 2023-08-20 12:18:07 --> Output Class Initialized
INFO - 2023-08-20 12:18:07 --> Security Class Initialized
DEBUG - 2023-08-20 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:18:07 --> Input Class Initialized
INFO - 2023-08-20 12:18:07 --> Language Class Initialized
INFO - 2023-08-20 12:18:07 --> Loader Class Initialized
INFO - 2023-08-20 12:18:07 --> Helper loaded: url_helper
INFO - 2023-08-20 12:18:07 --> Helper loaded: file_helper
INFO - 2023-08-20 12:18:07 --> Database Driver Class Initialized
INFO - 2023-08-20 12:18:07 --> Email Class Initialized
DEBUG - 2023-08-20 12:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:18:07 --> Controller Class Initialized
INFO - 2023-08-20 12:18:07 --> Model "Training_model" initialized
INFO - 2023-08-20 12:18:07 --> Helper loaded: form_helper
INFO - 2023-08-20 12:18:07 --> Form Validation Class Initialized
INFO - 2023-08-20 12:18:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 12:18:08 --> Final output sent to browser
DEBUG - 2023-08-20 12:18:08 --> Total execution time: 1.5427
INFO - 2023-08-20 12:18:09 --> Config Class Initialized
INFO - 2023-08-20 12:18:09 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:18:09 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:18:09 --> Utf8 Class Initialized
INFO - 2023-08-20 12:18:09 --> URI Class Initialized
INFO - 2023-08-20 12:18:09 --> Router Class Initialized
INFO - 2023-08-20 12:18:09 --> Output Class Initialized
INFO - 2023-08-20 12:18:09 --> Security Class Initialized
DEBUG - 2023-08-20 12:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:18:09 --> Input Class Initialized
INFO - 2023-08-20 12:18:09 --> Language Class Initialized
INFO - 2023-08-20 12:18:10 --> Config Class Initialized
ERROR - 2023-08-20 12:18:10 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-20 12:18:10 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:18:10 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:18:10 --> Utf8 Class Initialized
INFO - 2023-08-20 12:18:11 --> URI Class Initialized
INFO - 2023-08-20 12:18:11 --> Config Class Initialized
INFO - 2023-08-20 12:18:11 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:18:11 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:18:11 --> Utf8 Class Initialized
INFO - 2023-08-20 12:18:11 --> URI Class Initialized
INFO - 2023-08-20 12:18:11 --> Router Class Initialized
INFO - 2023-08-20 12:18:11 --> Output Class Initialized
INFO - 2023-08-20 12:18:11 --> Security Class Initialized
DEBUG - 2023-08-20 12:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:18:11 --> Input Class Initialized
INFO - 2023-08-20 12:18:11 --> Language Class Initialized
INFO - 2023-08-20 12:18:11 --> Loader Class Initialized
INFO - 2023-08-20 12:18:11 --> Helper loaded: url_helper
INFO - 2023-08-20 12:18:11 --> Helper loaded: file_helper
INFO - 2023-08-20 12:18:11 --> Router Class Initialized
INFO - 2023-08-20 12:18:11 --> Output Class Initialized
INFO - 2023-08-20 12:18:11 --> Database Driver Class Initialized
INFO - 2023-08-20 12:18:11 --> Security Class Initialized
DEBUG - 2023-08-20 12:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:18:11 --> Email Class Initialized
INFO - 2023-08-20 12:18:11 --> Input Class Initialized
INFO - 2023-08-20 12:18:11 --> Language Class Initialized
DEBUG - 2023-08-20 12:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-08-20 12:18:11 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-20 12:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:18:11 --> Controller Class Initialized
INFO - 2023-08-20 12:18:11 --> Model "Training_model" initialized
INFO - 2023-08-20 12:18:11 --> Helper loaded: form_helper
INFO - 2023-08-20 12:18:11 --> Form Validation Class Initialized
INFO - 2023-08-20 12:18:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/training_create.php
INFO - 2023-08-20 12:18:11 --> Final output sent to browser
DEBUG - 2023-08-20 12:18:11 --> Total execution time: 0.4948
INFO - 2023-08-20 12:52:42 --> Config Class Initialized
INFO - 2023-08-20 12:52:42 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:52:42 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:52:42 --> Utf8 Class Initialized
INFO - 2023-08-20 12:52:42 --> URI Class Initialized
INFO - 2023-08-20 12:52:42 --> Router Class Initialized
INFO - 2023-08-20 12:52:42 --> Output Class Initialized
INFO - 2023-08-20 12:52:42 --> Security Class Initialized
DEBUG - 2023-08-20 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:52:42 --> Input Class Initialized
INFO - 2023-08-20 12:52:42 --> Language Class Initialized
INFO - 2023-08-20 12:52:42 --> Loader Class Initialized
INFO - 2023-08-20 12:52:42 --> Helper loaded: url_helper
INFO - 2023-08-20 12:52:42 --> Helper loaded: file_helper
INFO - 2023-08-20 12:52:42 --> Database Driver Class Initialized
INFO - 2023-08-20 12:52:42 --> Email Class Initialized
DEBUG - 2023-08-20 12:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:52:42 --> Controller Class Initialized
INFO - 2023-08-20 12:52:42 --> Model "Services_model" initialized
INFO - 2023-08-20 12:52:42 --> Helper loaded: form_helper
INFO - 2023-08-20 12:52:42 --> Form Validation Class Initialized
INFO - 2023-08-20 12:52:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 12:52:42 --> Final output sent to browser
DEBUG - 2023-08-20 12:52:42 --> Total execution time: 0.2725
INFO - 2023-08-20 12:52:43 --> Config Class Initialized
INFO - 2023-08-20 12:52:43 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:52:43 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:52:43 --> Utf8 Class Initialized
INFO - 2023-08-20 12:52:43 --> URI Class Initialized
INFO - 2023-08-20 12:52:43 --> Router Class Initialized
INFO - 2023-08-20 12:52:43 --> Output Class Initialized
INFO - 2023-08-20 12:52:43 --> Security Class Initialized
DEBUG - 2023-08-20 12:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:52:43 --> Input Class Initialized
INFO - 2023-08-20 12:52:43 --> Language Class Initialized
ERROR - 2023-08-20 12:52:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 12:52:57 --> Config Class Initialized
INFO - 2023-08-20 12:52:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:52:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:52:57 --> Utf8 Class Initialized
INFO - 2023-08-20 12:52:57 --> URI Class Initialized
INFO - 2023-08-20 12:52:57 --> Router Class Initialized
INFO - 2023-08-20 12:52:57 --> Output Class Initialized
INFO - 2023-08-20 12:52:57 --> Security Class Initialized
DEBUG - 2023-08-20 12:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:52:57 --> Input Class Initialized
INFO - 2023-08-20 12:52:57 --> Language Class Initialized
INFO - 2023-08-20 12:52:57 --> Loader Class Initialized
INFO - 2023-08-20 12:52:57 --> Helper loaded: url_helper
INFO - 2023-08-20 12:52:57 --> Helper loaded: file_helper
INFO - 2023-08-20 12:52:57 --> Database Driver Class Initialized
INFO - 2023-08-20 12:52:57 --> Email Class Initialized
DEBUG - 2023-08-20 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:52:57 --> Controller Class Initialized
INFO - 2023-08-20 12:52:57 --> Model "Services_model" initialized
INFO - 2023-08-20 12:52:57 --> Helper loaded: form_helper
INFO - 2023-08-20 12:52:57 --> Form Validation Class Initialized
INFO - 2023-08-20 12:52:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-20 12:52:57 --> Final output sent to browser
DEBUG - 2023-08-20 12:52:57 --> Total execution time: 0.0523
INFO - 2023-08-20 12:53:12 --> Config Class Initialized
INFO - 2023-08-20 12:53:12 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:53:12 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:53:12 --> Utf8 Class Initialized
INFO - 2023-08-20 12:53:12 --> URI Class Initialized
INFO - 2023-08-20 12:53:12 --> Router Class Initialized
INFO - 2023-08-20 12:53:12 --> Output Class Initialized
INFO - 2023-08-20 12:53:12 --> Security Class Initialized
DEBUG - 2023-08-20 12:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:53:12 --> Input Class Initialized
INFO - 2023-08-20 12:53:12 --> Language Class Initialized
ERROR - 2023-08-20 12:53:12 --> 404 Page Not Found: admin/Services/images
INFO - 2023-08-20 12:53:35 --> Config Class Initialized
INFO - 2023-08-20 12:53:35 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:53:35 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:53:35 --> Utf8 Class Initialized
INFO - 2023-08-20 12:53:35 --> URI Class Initialized
INFO - 2023-08-20 12:53:35 --> Router Class Initialized
INFO - 2023-08-20 12:53:35 --> Output Class Initialized
INFO - 2023-08-20 12:53:35 --> Security Class Initialized
DEBUG - 2023-08-20 12:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:53:35 --> Input Class Initialized
INFO - 2023-08-20 12:53:35 --> Language Class Initialized
INFO - 2023-08-20 12:53:35 --> Loader Class Initialized
INFO - 2023-08-20 12:53:35 --> Helper loaded: url_helper
INFO - 2023-08-20 12:53:35 --> Helper loaded: file_helper
INFO - 2023-08-20 12:53:35 --> Database Driver Class Initialized
INFO - 2023-08-20 12:53:35 --> Email Class Initialized
DEBUG - 2023-08-20 12:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:53:35 --> Controller Class Initialized
INFO - 2023-08-20 12:53:35 --> Model "Services_model" initialized
INFO - 2023-08-20 12:53:35 --> Helper loaded: form_helper
INFO - 2023-08-20 12:53:35 --> Form Validation Class Initialized
INFO - 2023-08-20 12:53:35 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_create.php
INFO - 2023-08-20 12:53:35 --> Final output sent to browser
DEBUG - 2023-08-20 12:53:36 --> Total execution time: 0.4223
INFO - 2023-08-20 12:54:10 --> Config Class Initialized
INFO - 2023-08-20 12:54:10 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:54:10 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:54:10 --> Utf8 Class Initialized
INFO - 2023-08-20 12:54:10 --> URI Class Initialized
INFO - 2023-08-20 12:54:10 --> Router Class Initialized
INFO - 2023-08-20 12:54:10 --> Output Class Initialized
INFO - 2023-08-20 12:54:10 --> Security Class Initialized
DEBUG - 2023-08-20 12:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:54:10 --> Input Class Initialized
INFO - 2023-08-20 12:54:10 --> Language Class Initialized
INFO - 2023-08-20 12:54:10 --> Loader Class Initialized
INFO - 2023-08-20 12:54:10 --> Helper loaded: url_helper
INFO - 2023-08-20 12:54:10 --> Helper loaded: file_helper
INFO - 2023-08-20 12:54:10 --> Database Driver Class Initialized
INFO - 2023-08-20 12:54:10 --> Email Class Initialized
DEBUG - 2023-08-20 12:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:54:10 --> Controller Class Initialized
INFO - 2023-08-20 12:54:10 --> Model "Services_model" initialized
INFO - 2023-08-20 12:54:10 --> Helper loaded: form_helper
INFO - 2023-08-20 12:54:10 --> Form Validation Class Initialized
INFO - 2023-08-20 12:54:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-20 12:54:10 --> Severity: Warning --> Undefined variable $banner_image C:\xampp\htdocs\dw\application\controllers\Admin\Services.php 60
ERROR - 2023-08-20 12:54:10 --> Severity: Warning --> Undefined variable $icon C:\xampp\htdocs\dw\application\controllers\Admin\Services.php 61
ERROR - 2023-08-20 12:54:10 --> Query error: Column 'banner_image' cannot be null - Invalid query: INSERT INTO `services` (`name`, `description`, `description_new`, `status`, `image`, `banner_image`, `icon`, `created_at`, `created_by`) VALUES ('chairuutut', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '1', '/assets/images/services/1692528850blog-page-img-5.jpg', NULL, NULL, '2023-08-20 12:54:10', '2')
INFO - 2023-08-20 12:54:10 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-20 12:55:35 --> Config Class Initialized
INFO - 2023-08-20 12:55:35 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:55:35 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:55:35 --> Utf8 Class Initialized
INFO - 2023-08-20 12:55:35 --> URI Class Initialized
INFO - 2023-08-20 12:55:35 --> Router Class Initialized
INFO - 2023-08-20 12:55:35 --> Output Class Initialized
INFO - 2023-08-20 12:55:35 --> Security Class Initialized
DEBUG - 2023-08-20 12:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:55:35 --> Input Class Initialized
INFO - 2023-08-20 12:55:35 --> Language Class Initialized
INFO - 2023-08-20 12:55:35 --> Loader Class Initialized
INFO - 2023-08-20 12:55:35 --> Helper loaded: url_helper
INFO - 2023-08-20 12:55:35 --> Helper loaded: file_helper
INFO - 2023-08-20 12:55:35 --> Database Driver Class Initialized
INFO - 2023-08-20 12:55:35 --> Email Class Initialized
DEBUG - 2023-08-20 12:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:55:35 --> Controller Class Initialized
INFO - 2023-08-20 12:55:35 --> Model "Services_model" initialized
INFO - 2023-08-20 12:55:35 --> Helper loaded: form_helper
INFO - 2023-08-20 12:55:35 --> Form Validation Class Initialized
INFO - 2023-08-20 12:55:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 12:55:36 --> Config Class Initialized
INFO - 2023-08-20 12:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:55:36 --> Utf8 Class Initialized
INFO - 2023-08-20 12:55:36 --> URI Class Initialized
INFO - 2023-08-20 12:55:36 --> Router Class Initialized
INFO - 2023-08-20 12:55:36 --> Output Class Initialized
INFO - 2023-08-20 12:55:36 --> Security Class Initialized
DEBUG - 2023-08-20 12:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:55:36 --> Input Class Initialized
INFO - 2023-08-20 12:55:36 --> Language Class Initialized
INFO - 2023-08-20 12:55:36 --> Loader Class Initialized
INFO - 2023-08-20 12:55:36 --> Helper loaded: url_helper
INFO - 2023-08-20 12:55:36 --> Helper loaded: file_helper
INFO - 2023-08-20 12:55:36 --> Database Driver Class Initialized
INFO - 2023-08-20 12:55:36 --> Email Class Initialized
DEBUG - 2023-08-20 12:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:55:36 --> Controller Class Initialized
INFO - 2023-08-20 12:55:36 --> Model "Services_model" initialized
INFO - 2023-08-20 12:55:36 --> Helper loaded: form_helper
INFO - 2023-08-20 12:55:36 --> Form Validation Class Initialized
INFO - 2023-08-20 12:55:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 12:55:36 --> Final output sent to browser
DEBUG - 2023-08-20 12:55:36 --> Total execution time: 0.0442
INFO - 2023-08-20 12:55:36 --> Config Class Initialized
INFO - 2023-08-20 12:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:55:36 --> Utf8 Class Initialized
INFO - 2023-08-20 12:55:36 --> URI Class Initialized
INFO - 2023-08-20 12:55:36 --> Router Class Initialized
INFO - 2023-08-20 12:55:36 --> Output Class Initialized
INFO - 2023-08-20 12:55:36 --> Security Class Initialized
DEBUG - 2023-08-20 12:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:55:36 --> Input Class Initialized
INFO - 2023-08-20 12:55:36 --> Language Class Initialized
ERROR - 2023-08-20 12:55:36 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 12:55:45 --> Config Class Initialized
INFO - 2023-08-20 12:55:45 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:55:45 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:55:45 --> Utf8 Class Initialized
INFO - 2023-08-20 12:55:45 --> URI Class Initialized
INFO - 2023-08-20 12:55:45 --> Router Class Initialized
INFO - 2023-08-20 12:55:45 --> Output Class Initialized
INFO - 2023-08-20 12:55:45 --> Security Class Initialized
DEBUG - 2023-08-20 12:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:55:46 --> Input Class Initialized
INFO - 2023-08-20 12:55:46 --> Language Class Initialized
INFO - 2023-08-20 12:55:46 --> Loader Class Initialized
INFO - 2023-08-20 12:55:46 --> Helper loaded: url_helper
INFO - 2023-08-20 12:55:46 --> Helper loaded: file_helper
INFO - 2023-08-20 12:55:46 --> Database Driver Class Initialized
INFO - 2023-08-20 12:55:46 --> Email Class Initialized
DEBUG - 2023-08-20 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:55:46 --> Controller Class Initialized
INFO - 2023-08-20 12:55:46 --> Model "Services_model" initialized
INFO - 2023-08-20 12:55:46 --> Helper loaded: form_helper
INFO - 2023-08-20 12:55:46 --> Form Validation Class Initialized
INFO - 2023-08-20 12:55:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:55:46 --> Final output sent to browser
DEBUG - 2023-08-20 12:55:46 --> Total execution time: 0.8990
INFO - 2023-08-20 12:55:47 --> Config Class Initialized
INFO - 2023-08-20 12:55:47 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:55:47 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:55:47 --> Utf8 Class Initialized
INFO - 2023-08-20 12:55:47 --> URI Class Initialized
INFO - 2023-08-20 12:55:47 --> Router Class Initialized
INFO - 2023-08-20 12:55:47 --> Output Class Initialized
INFO - 2023-08-20 12:55:47 --> Security Class Initialized
DEBUG - 2023-08-20 12:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:55:47 --> Input Class Initialized
INFO - 2023-08-20 12:55:47 --> Language Class Initialized
INFO - 2023-08-20 12:55:47 --> Loader Class Initialized
INFO - 2023-08-20 12:55:47 --> Helper loaded: url_helper
INFO - 2023-08-20 12:55:47 --> Helper loaded: file_helper
INFO - 2023-08-20 12:55:47 --> Database Driver Class Initialized
INFO - 2023-08-20 12:55:47 --> Email Class Initialized
DEBUG - 2023-08-20 12:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:55:47 --> Controller Class Initialized
INFO - 2023-08-20 12:55:47 --> Model "Services_model" initialized
INFO - 2023-08-20 12:55:47 --> Helper loaded: form_helper
INFO - 2023-08-20 12:55:47 --> Form Validation Class Initialized
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 75
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 76
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 77
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-08-20 12:55:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 100
INFO - 2023-08-20 12:55:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:55:47 --> Final output sent to browser
DEBUG - 2023-08-20 12:55:47 --> Total execution time: 0.0481
INFO - 2023-08-20 12:57:21 --> Config Class Initialized
INFO - 2023-08-20 12:57:21 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:57:21 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:57:21 --> Utf8 Class Initialized
INFO - 2023-08-20 12:57:21 --> URI Class Initialized
INFO - 2023-08-20 12:57:21 --> Router Class Initialized
INFO - 2023-08-20 12:57:21 --> Output Class Initialized
INFO - 2023-08-20 12:57:21 --> Security Class Initialized
DEBUG - 2023-08-20 12:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:57:21 --> Input Class Initialized
INFO - 2023-08-20 12:57:21 --> Language Class Initialized
INFO - 2023-08-20 12:57:21 --> Loader Class Initialized
INFO - 2023-08-20 12:57:21 --> Helper loaded: url_helper
INFO - 2023-08-20 12:57:21 --> Helper loaded: file_helper
INFO - 2023-08-20 12:57:21 --> Database Driver Class Initialized
INFO - 2023-08-20 12:57:21 --> Email Class Initialized
DEBUG - 2023-08-20 12:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:57:21 --> Controller Class Initialized
INFO - 2023-08-20 12:57:21 --> Model "Services_model" initialized
INFO - 2023-08-20 12:57:21 --> Helper loaded: form_helper
INFO - 2023-08-20 12:57:21 --> Form Validation Class Initialized
INFO - 2023-08-20 12:57:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:57:22 --> Final output sent to browser
DEBUG - 2023-08-20 12:57:22 --> Total execution time: 0.9113
INFO - 2023-08-20 12:57:23 --> Config Class Initialized
INFO - 2023-08-20 12:57:23 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:57:23 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:57:23 --> Utf8 Class Initialized
INFO - 2023-08-20 12:57:23 --> URI Class Initialized
INFO - 2023-08-20 12:57:23 --> Router Class Initialized
INFO - 2023-08-20 12:57:23 --> Output Class Initialized
INFO - 2023-08-20 12:57:23 --> Security Class Initialized
DEBUG - 2023-08-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:57:23 --> Input Class Initialized
INFO - 2023-08-20 12:57:23 --> Language Class Initialized
INFO - 2023-08-20 12:57:23 --> Loader Class Initialized
INFO - 2023-08-20 12:57:23 --> Helper loaded: url_helper
INFO - 2023-08-20 12:57:23 --> Helper loaded: file_helper
INFO - 2023-08-20 12:57:23 --> Database Driver Class Initialized
INFO - 2023-08-20 12:57:23 --> Email Class Initialized
DEBUG - 2023-08-20 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:57:23 --> Controller Class Initialized
INFO - 2023-08-20 12:57:23 --> Model "Services_model" initialized
INFO - 2023-08-20 12:57:23 --> Helper loaded: form_helper
INFO - 2023-08-20 12:57:23 --> Form Validation Class Initialized
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 12:57:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 128
INFO - 2023-08-20 12:57:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:57:23 --> Final output sent to browser
DEBUG - 2023-08-20 12:57:23 --> Total execution time: 0.0488
INFO - 2023-08-20 12:57:57 --> Config Class Initialized
INFO - 2023-08-20 12:57:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:57:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:57:57 --> Utf8 Class Initialized
INFO - 2023-08-20 12:57:57 --> URI Class Initialized
INFO - 2023-08-20 12:57:57 --> Router Class Initialized
INFO - 2023-08-20 12:57:57 --> Output Class Initialized
INFO - 2023-08-20 12:57:57 --> Security Class Initialized
DEBUG - 2023-08-20 12:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:57:57 --> Input Class Initialized
INFO - 2023-08-20 12:57:57 --> Language Class Initialized
INFO - 2023-08-20 12:57:57 --> Loader Class Initialized
INFO - 2023-08-20 12:57:57 --> Helper loaded: url_helper
INFO - 2023-08-20 12:57:57 --> Helper loaded: file_helper
INFO - 2023-08-20 12:57:57 --> Database Driver Class Initialized
INFO - 2023-08-20 12:57:57 --> Email Class Initialized
DEBUG - 2023-08-20 12:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:57:57 --> Controller Class Initialized
INFO - 2023-08-20 12:57:58 --> Model "Services_model" initialized
INFO - 2023-08-20 12:57:58 --> Helper loaded: form_helper
INFO - 2023-08-20 12:57:58 --> Form Validation Class Initialized
ERROR - 2023-08-20 12:57:58 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 12:57:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 12:57:58 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
ERROR - 2023-08-20 12:57:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
INFO - 2023-08-20 12:57:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:57:58 --> Final output sent to browser
DEBUG - 2023-08-20 12:57:58 --> Total execution time: 1.1467
INFO - 2023-08-20 12:57:59 --> Config Class Initialized
INFO - 2023-08-20 12:57:59 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:57:59 --> Utf8 Class Initialized
INFO - 2023-08-20 12:57:59 --> URI Class Initialized
INFO - 2023-08-20 12:57:59 --> Router Class Initialized
INFO - 2023-08-20 12:57:59 --> Output Class Initialized
INFO - 2023-08-20 12:57:59 --> Security Class Initialized
DEBUG - 2023-08-20 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:57:59 --> Input Class Initialized
INFO - 2023-08-20 12:57:59 --> Language Class Initialized
INFO - 2023-08-20 12:57:59 --> Loader Class Initialized
INFO - 2023-08-20 12:57:59 --> Helper loaded: url_helper
INFO - 2023-08-20 12:57:59 --> Helper loaded: file_helper
INFO - 2023-08-20 12:57:59 --> Database Driver Class Initialized
INFO - 2023-08-20 12:57:59 --> Email Class Initialized
DEBUG - 2023-08-20 12:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:57:59 --> Controller Class Initialized
INFO - 2023-08-20 12:57:59 --> Model "Services_model" initialized
INFO - 2023-08-20 12:57:59 --> Helper loaded: form_helper
INFO - 2023-08-20 12:57:59 --> Form Validation Class Initialized
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 128
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Undefined variable $training C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
ERROR - 2023-08-20 12:57:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
INFO - 2023-08-20 12:57:59 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:57:59 --> Final output sent to browser
DEBUG - 2023-08-20 12:57:59 --> Total execution time: 0.0570
INFO - 2023-08-20 12:58:09 --> Config Class Initialized
INFO - 2023-08-20 12:58:09 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:58:09 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:58:09 --> Utf8 Class Initialized
INFO - 2023-08-20 12:58:09 --> URI Class Initialized
INFO - 2023-08-20 12:58:09 --> Router Class Initialized
INFO - 2023-08-20 12:58:10 --> Output Class Initialized
INFO - 2023-08-20 12:58:10 --> Security Class Initialized
DEBUG - 2023-08-20 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:58:10 --> Input Class Initialized
INFO - 2023-08-20 12:58:10 --> Language Class Initialized
INFO - 2023-08-20 12:58:10 --> Loader Class Initialized
INFO - 2023-08-20 12:58:10 --> Helper loaded: url_helper
INFO - 2023-08-20 12:58:10 --> Helper loaded: file_helper
INFO - 2023-08-20 12:58:10 --> Database Driver Class Initialized
INFO - 2023-08-20 12:58:10 --> Email Class Initialized
DEBUG - 2023-08-20 12:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:58:10 --> Controller Class Initialized
INFO - 2023-08-20 12:58:10 --> Model "Services_model" initialized
INFO - 2023-08-20 12:58:10 --> Helper loaded: form_helper
INFO - 2023-08-20 12:58:10 --> Form Validation Class Initialized
INFO - 2023-08-20 12:58:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:58:10 --> Final output sent to browser
DEBUG - 2023-08-20 12:58:10 --> Total execution time: 0.8530
INFO - 2023-08-20 12:58:11 --> Config Class Initialized
INFO - 2023-08-20 12:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-20 12:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-20 12:58:11 --> Utf8 Class Initialized
INFO - 2023-08-20 12:58:11 --> URI Class Initialized
INFO - 2023-08-20 12:58:11 --> Router Class Initialized
INFO - 2023-08-20 12:58:11 --> Output Class Initialized
INFO - 2023-08-20 12:58:11 --> Security Class Initialized
DEBUG - 2023-08-20 12:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 12:58:11 --> Input Class Initialized
INFO - 2023-08-20 12:58:11 --> Language Class Initialized
INFO - 2023-08-20 12:58:11 --> Loader Class Initialized
INFO - 2023-08-20 12:58:11 --> Helper loaded: url_helper
INFO - 2023-08-20 12:58:11 --> Helper loaded: file_helper
INFO - 2023-08-20 12:58:11 --> Database Driver Class Initialized
INFO - 2023-08-20 12:58:11 --> Email Class Initialized
DEBUG - 2023-08-20 12:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 12:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 12:58:11 --> Controller Class Initialized
INFO - 2023-08-20 12:58:11 --> Model "Services_model" initialized
INFO - 2023-08-20 12:58:11 --> Helper loaded: form_helper
INFO - 2023-08-20 12:58:11 --> Form Validation Class Initialized
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 128
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 12:58:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
INFO - 2023-08-20 12:58:11 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 12:58:11 --> Final output sent to browser
DEBUG - 2023-08-20 12:58:11 --> Total execution time: 0.0785
INFO - 2023-08-20 13:00:03 --> Config Class Initialized
INFO - 2023-08-20 13:00:03 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:00:03 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:00:03 --> Utf8 Class Initialized
INFO - 2023-08-20 13:00:03 --> URI Class Initialized
INFO - 2023-08-20 13:00:03 --> Router Class Initialized
INFO - 2023-08-20 13:00:03 --> Output Class Initialized
INFO - 2023-08-20 13:00:03 --> Security Class Initialized
DEBUG - 2023-08-20 13:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:00:03 --> Input Class Initialized
INFO - 2023-08-20 13:00:03 --> Language Class Initialized
INFO - 2023-08-20 13:00:03 --> Loader Class Initialized
INFO - 2023-08-20 13:00:03 --> Helper loaded: url_helper
INFO - 2023-08-20 13:00:03 --> Helper loaded: file_helper
INFO - 2023-08-20 13:00:04 --> Database Driver Class Initialized
INFO - 2023-08-20 13:00:04 --> Email Class Initialized
DEBUG - 2023-08-20 13:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:00:04 --> Controller Class Initialized
INFO - 2023-08-20 13:00:04 --> Model "Services_model" initialized
INFO - 2023-08-20 13:00:04 --> Helper loaded: form_helper
INFO - 2023-08-20 13:00:04 --> Form Validation Class Initialized
INFO - 2023-08-20 13:00:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:00:04 --> Final output sent to browser
DEBUG - 2023-08-20 13:00:04 --> Total execution time: 0.7541
INFO - 2023-08-20 13:00:05 --> Config Class Initialized
INFO - 2023-08-20 13:00:05 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:00:05 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:00:05 --> Utf8 Class Initialized
INFO - 2023-08-20 13:00:05 --> URI Class Initialized
INFO - 2023-08-20 13:00:05 --> Router Class Initialized
INFO - 2023-08-20 13:00:05 --> Output Class Initialized
INFO - 2023-08-20 13:00:05 --> Security Class Initialized
DEBUG - 2023-08-20 13:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:00:05 --> Input Class Initialized
INFO - 2023-08-20 13:00:05 --> Language Class Initialized
INFO - 2023-08-20 13:00:05 --> Loader Class Initialized
INFO - 2023-08-20 13:00:05 --> Helper loaded: url_helper
INFO - 2023-08-20 13:00:05 --> Helper loaded: file_helper
INFO - 2023-08-20 13:00:05 --> Database Driver Class Initialized
INFO - 2023-08-20 13:00:05 --> Email Class Initialized
DEBUG - 2023-08-20 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:00:05 --> Controller Class Initialized
INFO - 2023-08-20 13:00:05 --> Model "Services_model" initialized
INFO - 2023-08-20 13:00:05 --> Helper loaded: form_helper
INFO - 2023-08-20 13:00:05 --> Form Validation Class Initialized
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 128
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 13:00:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 132
INFO - 2023-08-20 13:00:05 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:00:05 --> Final output sent to browser
DEBUG - 2023-08-20 13:00:05 --> Total execution time: 0.0531
INFO - 2023-08-20 13:00:42 --> Config Class Initialized
INFO - 2023-08-20 13:00:42 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:00:42 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:00:42 --> Utf8 Class Initialized
INFO - 2023-08-20 13:00:42 --> URI Class Initialized
INFO - 2023-08-20 13:00:42 --> Router Class Initialized
INFO - 2023-08-20 13:00:42 --> Output Class Initialized
INFO - 2023-08-20 13:00:42 --> Security Class Initialized
DEBUG - 2023-08-20 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:00:42 --> Input Class Initialized
INFO - 2023-08-20 13:00:42 --> Language Class Initialized
INFO - 2023-08-20 13:00:42 --> Loader Class Initialized
INFO - 2023-08-20 13:00:42 --> Helper loaded: url_helper
INFO - 2023-08-20 13:00:42 --> Helper loaded: file_helper
INFO - 2023-08-20 13:00:42 --> Database Driver Class Initialized
INFO - 2023-08-20 13:00:42 --> Email Class Initialized
DEBUG - 2023-08-20 13:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:00:42 --> Controller Class Initialized
INFO - 2023-08-20 13:00:42 --> Model "Services_model" initialized
INFO - 2023-08-20 13:00:42 --> Helper loaded: form_helper
INFO - 2023-08-20 13:00:42 --> Form Validation Class Initialized
INFO - 2023-08-20 13:00:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:00:43 --> Final output sent to browser
DEBUG - 2023-08-20 13:00:43 --> Total execution time: 0.5140
INFO - 2023-08-20 13:00:44 --> Config Class Initialized
INFO - 2023-08-20 13:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:00:44 --> Utf8 Class Initialized
INFO - 2023-08-20 13:00:44 --> URI Class Initialized
INFO - 2023-08-20 13:00:44 --> Router Class Initialized
INFO - 2023-08-20 13:00:44 --> Output Class Initialized
INFO - 2023-08-20 13:00:44 --> Security Class Initialized
DEBUG - 2023-08-20 13:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:00:44 --> Input Class Initialized
INFO - 2023-08-20 13:00:44 --> Language Class Initialized
INFO - 2023-08-20 13:00:44 --> Loader Class Initialized
INFO - 2023-08-20 13:00:44 --> Helper loaded: url_helper
INFO - 2023-08-20 13:00:44 --> Helper loaded: file_helper
INFO - 2023-08-20 13:00:44 --> Database Driver Class Initialized
INFO - 2023-08-20 13:00:44 --> Email Class Initialized
DEBUG - 2023-08-20 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:00:44 --> Controller Class Initialized
INFO - 2023-08-20 13:00:44 --> Model "Services_model" initialized
INFO - 2023-08-20 13:00:44 --> Helper loaded: form_helper
INFO - 2023-08-20 13:00:44 --> Form Validation Class Initialized
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-20 13:00:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-20 13:00:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:00:44 --> Final output sent to browser
DEBUG - 2023-08-20 13:00:44 --> Total execution time: 0.0535
INFO - 2023-08-20 13:01:30 --> Config Class Initialized
INFO - 2023-08-20 13:01:30 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:01:30 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:01:30 --> Utf8 Class Initialized
INFO - 2023-08-20 13:01:30 --> URI Class Initialized
INFO - 2023-08-20 13:01:30 --> Router Class Initialized
INFO - 2023-08-20 13:01:30 --> Output Class Initialized
INFO - 2023-08-20 13:01:30 --> Security Class Initialized
DEBUG - 2023-08-20 13:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:01:30 --> Input Class Initialized
INFO - 2023-08-20 13:01:30 --> Language Class Initialized
INFO - 2023-08-20 13:01:30 --> Loader Class Initialized
INFO - 2023-08-20 13:01:30 --> Helper loaded: url_helper
INFO - 2023-08-20 13:01:30 --> Helper loaded: file_helper
INFO - 2023-08-20 13:01:30 --> Database Driver Class Initialized
INFO - 2023-08-20 13:01:30 --> Email Class Initialized
DEBUG - 2023-08-20 13:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:01:30 --> Controller Class Initialized
INFO - 2023-08-20 13:01:30 --> Model "Services_model" initialized
INFO - 2023-08-20 13:01:30 --> Helper loaded: form_helper
INFO - 2023-08-20 13:01:30 --> Form Validation Class Initialized
INFO - 2023-08-20 13:01:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 13:01:30 --> Config Class Initialized
INFO - 2023-08-20 13:01:30 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:01:30 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:01:30 --> Utf8 Class Initialized
INFO - 2023-08-20 13:01:30 --> URI Class Initialized
INFO - 2023-08-20 13:01:31 --> Router Class Initialized
INFO - 2023-08-20 13:01:31 --> Output Class Initialized
INFO - 2023-08-20 13:01:31 --> Security Class Initialized
DEBUG - 2023-08-20 13:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:01:31 --> Input Class Initialized
INFO - 2023-08-20 13:01:31 --> Language Class Initialized
INFO - 2023-08-20 13:01:31 --> Loader Class Initialized
INFO - 2023-08-20 13:01:31 --> Helper loaded: url_helper
INFO - 2023-08-20 13:01:31 --> Helper loaded: file_helper
INFO - 2023-08-20 13:01:31 --> Database Driver Class Initialized
INFO - 2023-08-20 13:01:31 --> Email Class Initialized
DEBUG - 2023-08-20 13:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:01:31 --> Controller Class Initialized
INFO - 2023-08-20 13:01:31 --> Model "Services_model" initialized
INFO - 2023-08-20 13:01:31 --> Helper loaded: form_helper
INFO - 2023-08-20 13:01:31 --> Form Validation Class Initialized
INFO - 2023-08-20 13:01:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 13:01:31 --> Final output sent to browser
DEBUG - 2023-08-20 13:01:31 --> Total execution time: 0.5703
INFO - 2023-08-20 13:01:32 --> Config Class Initialized
INFO - 2023-08-20 13:01:32 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:01:32 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:01:32 --> Utf8 Class Initialized
INFO - 2023-08-20 13:01:32 --> URI Class Initialized
INFO - 2023-08-20 13:01:32 --> Router Class Initialized
INFO - 2023-08-20 13:01:32 --> Output Class Initialized
INFO - 2023-08-20 13:01:32 --> Security Class Initialized
DEBUG - 2023-08-20 13:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:01:32 --> Input Class Initialized
INFO - 2023-08-20 13:01:32 --> Language Class Initialized
ERROR - 2023-08-20 13:01:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 13:01:36 --> Config Class Initialized
INFO - 2023-08-20 13:01:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:01:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:01:36 --> Utf8 Class Initialized
INFO - 2023-08-20 13:01:36 --> URI Class Initialized
INFO - 2023-08-20 13:01:36 --> Router Class Initialized
INFO - 2023-08-20 13:01:36 --> Output Class Initialized
INFO - 2023-08-20 13:01:36 --> Security Class Initialized
DEBUG - 2023-08-20 13:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:01:36 --> Input Class Initialized
INFO - 2023-08-20 13:01:36 --> Language Class Initialized
INFO - 2023-08-20 13:01:36 --> Loader Class Initialized
INFO - 2023-08-20 13:01:36 --> Helper loaded: url_helper
INFO - 2023-08-20 13:01:36 --> Helper loaded: file_helper
INFO - 2023-08-20 13:01:36 --> Database Driver Class Initialized
INFO - 2023-08-20 13:01:36 --> Email Class Initialized
DEBUG - 2023-08-20 13:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:01:36 --> Controller Class Initialized
INFO - 2023-08-20 13:01:36 --> Model "Services_model" initialized
INFO - 2023-08-20 13:01:36 --> Helper loaded: form_helper
INFO - 2023-08-20 13:01:36 --> Form Validation Class Initialized
INFO - 2023-08-20 13:01:36 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:01:36 --> Final output sent to browser
DEBUG - 2023-08-20 13:01:36 --> Total execution time: 0.4463
INFO - 2023-08-20 13:01:37 --> Config Class Initialized
INFO - 2023-08-20 13:01:37 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:01:37 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:01:37 --> Utf8 Class Initialized
INFO - 2023-08-20 13:01:37 --> URI Class Initialized
INFO - 2023-08-20 13:01:37 --> Router Class Initialized
INFO - 2023-08-20 13:01:37 --> Output Class Initialized
INFO - 2023-08-20 13:01:37 --> Security Class Initialized
DEBUG - 2023-08-20 13:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:01:37 --> Input Class Initialized
INFO - 2023-08-20 13:01:37 --> Language Class Initialized
INFO - 2023-08-20 13:01:37 --> Loader Class Initialized
INFO - 2023-08-20 13:01:37 --> Helper loaded: url_helper
INFO - 2023-08-20 13:01:37 --> Helper loaded: file_helper
INFO - 2023-08-20 13:01:37 --> Database Driver Class Initialized
INFO - 2023-08-20 13:01:38 --> Email Class Initialized
DEBUG - 2023-08-20 13:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:01:38 --> Controller Class Initialized
INFO - 2023-08-20 13:01:38 --> Model "Services_model" initialized
INFO - 2023-08-20 13:01:38 --> Helper loaded: form_helper
INFO - 2023-08-20 13:01:38 --> Form Validation Class Initialized
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-20 13:01:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-20 13:01:38 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:01:38 --> Final output sent to browser
DEBUG - 2023-08-20 13:01:38 --> Total execution time: 0.5083
INFO - 2023-08-20 13:02:01 --> Config Class Initialized
INFO - 2023-08-20 13:02:01 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:01 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:01 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:01 --> URI Class Initialized
INFO - 2023-08-20 13:02:01 --> Router Class Initialized
INFO - 2023-08-20 13:02:01 --> Output Class Initialized
INFO - 2023-08-20 13:02:01 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:01 --> Input Class Initialized
INFO - 2023-08-20 13:02:01 --> Language Class Initialized
INFO - 2023-08-20 13:02:01 --> Loader Class Initialized
INFO - 2023-08-20 13:02:01 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:01 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:01 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:01 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:01 --> Controller Class Initialized
INFO - 2023-08-20 13:02:01 --> Model "Services_model" initialized
INFO - 2023-08-20 13:02:01 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:01 --> Form Validation Class Initialized
INFO - 2023-08-20 13:02:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-20 13:02:01 --> Config Class Initialized
INFO - 2023-08-20 13:02:01 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:01 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:01 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:01 --> URI Class Initialized
INFO - 2023-08-20 13:02:01 --> Router Class Initialized
INFO - 2023-08-20 13:02:02 --> Output Class Initialized
INFO - 2023-08-20 13:02:02 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:02 --> Input Class Initialized
INFO - 2023-08-20 13:02:02 --> Language Class Initialized
INFO - 2023-08-20 13:02:02 --> Loader Class Initialized
INFO - 2023-08-20 13:02:02 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:02 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:02 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:02 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:02 --> Controller Class Initialized
INFO - 2023-08-20 13:02:02 --> Model "Services_model" initialized
INFO - 2023-08-20 13:02:02 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:02 --> Form Validation Class Initialized
INFO - 2023-08-20 13:02:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 13:02:02 --> Final output sent to browser
DEBUG - 2023-08-20 13:02:02 --> Total execution time: 0.6441
INFO - 2023-08-20 13:02:03 --> Config Class Initialized
INFO - 2023-08-20 13:02:03 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:03 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:03 --> URI Class Initialized
INFO - 2023-08-20 13:02:03 --> Router Class Initialized
INFO - 2023-08-20 13:02:03 --> Output Class Initialized
INFO - 2023-08-20 13:02:03 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:03 --> Input Class Initialized
INFO - 2023-08-20 13:02:03 --> Language Class Initialized
ERROR - 2023-08-20 13:02:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 13:02:07 --> Config Class Initialized
INFO - 2023-08-20 13:02:07 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:07 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:07 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:07 --> URI Class Initialized
INFO - 2023-08-20 13:02:07 --> Router Class Initialized
INFO - 2023-08-20 13:02:07 --> Output Class Initialized
INFO - 2023-08-20 13:02:07 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:07 --> Input Class Initialized
INFO - 2023-08-20 13:02:07 --> Language Class Initialized
INFO - 2023-08-20 13:02:07 --> Loader Class Initialized
INFO - 2023-08-20 13:02:07 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:07 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:07 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:07 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:07 --> Controller Class Initialized
INFO - 2023-08-20 13:02:07 --> Model "Services_model" initialized
INFO - 2023-08-20 13:02:07 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:07 --> Form Validation Class Initialized
INFO - 2023-08-20 13:02:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:02:07 --> Final output sent to browser
DEBUG - 2023-08-20 13:02:08 --> Total execution time: 0.4302
INFO - 2023-08-20 13:02:08 --> Config Class Initialized
INFO - 2023-08-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:08 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:08 --> URI Class Initialized
INFO - 2023-08-20 13:02:09 --> Router Class Initialized
INFO - 2023-08-20 13:02:09 --> Output Class Initialized
INFO - 2023-08-20 13:02:09 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:09 --> Input Class Initialized
INFO - 2023-08-20 13:02:09 --> Language Class Initialized
INFO - 2023-08-20 13:02:09 --> Loader Class Initialized
INFO - 2023-08-20 13:02:09 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:09 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:09 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:09 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:09 --> Controller Class Initialized
INFO - 2023-08-20 13:02:09 --> Model "Services_model" initialized
INFO - 2023-08-20 13:02:09 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:09 --> Form Validation Class Initialized
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-20 13:02:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-20 13:02:09 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:02:09 --> Final output sent to browser
DEBUG - 2023-08-20 13:02:09 --> Total execution time: 0.6014
INFO - 2023-08-20 13:02:39 --> Config Class Initialized
INFO - 2023-08-20 13:02:39 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:39 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:39 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:39 --> URI Class Initialized
INFO - 2023-08-20 13:02:39 --> Router Class Initialized
INFO - 2023-08-20 13:02:39 --> Output Class Initialized
INFO - 2023-08-20 13:02:39 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:39 --> Input Class Initialized
INFO - 2023-08-20 13:02:39 --> Language Class Initialized
INFO - 2023-08-20 13:02:39 --> Loader Class Initialized
INFO - 2023-08-20 13:02:39 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:39 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:39 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:39 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:39 --> Controller Class Initialized
INFO - 2023-08-20 13:02:39 --> Model "Banner_model" initialized
INFO - 2023-08-20 13:02:39 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:39 --> Form Validation Class Initialized
INFO - 2023-08-20 13:02:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-20 13:02:39 --> Final output sent to browser
DEBUG - 2023-08-20 13:02:39 --> Total execution time: 0.4015
INFO - 2023-08-20 13:02:45 --> Config Class Initialized
INFO - 2023-08-20 13:02:45 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:45 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:45 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:45 --> URI Class Initialized
INFO - 2023-08-20 13:02:45 --> Router Class Initialized
INFO - 2023-08-20 13:02:45 --> Output Class Initialized
INFO - 2023-08-20 13:02:46 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:46 --> Input Class Initialized
INFO - 2023-08-20 13:02:46 --> Language Class Initialized
INFO - 2023-08-20 13:02:46 --> Loader Class Initialized
INFO - 2023-08-20 13:02:46 --> Helper loaded: url_helper
INFO - 2023-08-20 13:02:46 --> Helper loaded: file_helper
INFO - 2023-08-20 13:02:46 --> Database Driver Class Initialized
INFO - 2023-08-20 13:02:46 --> Email Class Initialized
DEBUG - 2023-08-20 13:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:02:46 --> Controller Class Initialized
INFO - 2023-08-20 13:02:46 --> Model "Services_model" initialized
INFO - 2023-08-20 13:02:46 --> Helper loaded: form_helper
INFO - 2023-08-20 13:02:46 --> Form Validation Class Initialized
INFO - 2023-08-20 13:02:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-08-20 13:02:46 --> Final output sent to browser
DEBUG - 2023-08-20 13:02:46 --> Total execution time: 0.4133
INFO - 2023-08-20 13:02:47 --> Config Class Initialized
INFO - 2023-08-20 13:02:47 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:02:47 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:02:47 --> Utf8 Class Initialized
INFO - 2023-08-20 13:02:47 --> URI Class Initialized
INFO - 2023-08-20 13:02:47 --> Router Class Initialized
INFO - 2023-08-20 13:02:47 --> Output Class Initialized
INFO - 2023-08-20 13:02:47 --> Security Class Initialized
DEBUG - 2023-08-20 13:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:02:47 --> Input Class Initialized
INFO - 2023-08-20 13:02:47 --> Language Class Initialized
ERROR - 2023-08-20 13:02:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-20 13:45:51 --> Config Class Initialized
INFO - 2023-08-20 13:45:51 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:45:51 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:45:51 --> Utf8 Class Initialized
INFO - 2023-08-20 13:45:51 --> URI Class Initialized
INFO - 2023-08-20 13:45:51 --> Router Class Initialized
INFO - 2023-08-20 13:45:51 --> Output Class Initialized
INFO - 2023-08-20 13:45:51 --> Security Class Initialized
DEBUG - 2023-08-20 13:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:45:51 --> Input Class Initialized
INFO - 2023-08-20 13:45:51 --> Language Class Initialized
INFO - 2023-08-20 13:45:51 --> Loader Class Initialized
INFO - 2023-08-20 13:45:51 --> Helper loaded: url_helper
INFO - 2023-08-20 13:45:51 --> Helper loaded: file_helper
INFO - 2023-08-20 13:45:51 --> Database Driver Class Initialized
INFO - 2023-08-20 13:45:51 --> Email Class Initialized
DEBUG - 2023-08-20 13:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:45:51 --> Controller Class Initialized
INFO - 2023-08-20 13:45:51 --> Model "Services_model" initialized
INFO - 2023-08-20 13:45:51 --> Helper loaded: form_helper
INFO - 2023-08-20 13:45:51 --> Form Validation Class Initialized
INFO - 2023-08-20 13:45:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:45:51 --> Final output sent to browser
DEBUG - 2023-08-20 13:45:51 --> Total execution time: 0.1164
INFO - 2023-08-20 13:45:52 --> Config Class Initialized
INFO - 2023-08-20 13:45:52 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:45:52 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:45:52 --> Utf8 Class Initialized
INFO - 2023-08-20 13:45:52 --> URI Class Initialized
INFO - 2023-08-20 13:45:52 --> Router Class Initialized
INFO - 2023-08-20 13:45:52 --> Output Class Initialized
INFO - 2023-08-20 13:45:52 --> Security Class Initialized
DEBUG - 2023-08-20 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:45:52 --> Input Class Initialized
INFO - 2023-08-20 13:45:52 --> Language Class Initialized
INFO - 2023-08-20 13:45:52 --> Loader Class Initialized
INFO - 2023-08-20 13:45:52 --> Helper loaded: url_helper
INFO - 2023-08-20 13:45:52 --> Helper loaded: file_helper
INFO - 2023-08-20 13:45:52 --> Database Driver Class Initialized
INFO - 2023-08-20 13:45:52 --> Email Class Initialized
DEBUG - 2023-08-20 13:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:45:52 --> Controller Class Initialized
INFO - 2023-08-20 13:45:52 --> Model "Services_model" initialized
INFO - 2023-08-20 13:45:52 --> Helper loaded: form_helper
INFO - 2023-08-20 13:45:52 --> Form Validation Class Initialized
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 46
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 56
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 72
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 85
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 118
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 130
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 140
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 142
ERROR - 2023-08-20 13:45:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 144
INFO - 2023-08-20 13:45:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-08-20 13:45:52 --> Final output sent to browser
DEBUG - 2023-08-20 13:45:52 --> Total execution time: 0.0606
INFO - 2023-08-20 13:49:25 --> Config Class Initialized
INFO - 2023-08-20 13:49:25 --> Hooks Class Initialized
DEBUG - 2023-08-20 13:49:25 --> UTF-8 Support Enabled
INFO - 2023-08-20 13:49:25 --> Utf8 Class Initialized
INFO - 2023-08-20 13:49:25 --> URI Class Initialized
INFO - 2023-08-20 13:49:25 --> Router Class Initialized
INFO - 2023-08-20 13:49:25 --> Output Class Initialized
INFO - 2023-08-20 13:49:25 --> Security Class Initialized
DEBUG - 2023-08-20 13:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 13:49:25 --> Input Class Initialized
INFO - 2023-08-20 13:49:25 --> Language Class Initialized
INFO - 2023-08-20 13:49:25 --> Loader Class Initialized
INFO - 2023-08-20 13:49:25 --> Helper loaded: url_helper
INFO - 2023-08-20 13:49:25 --> Helper loaded: file_helper
INFO - 2023-08-20 13:49:25 --> Database Driver Class Initialized
INFO - 2023-08-20 13:49:25 --> Email Class Initialized
DEBUG - 2023-08-20 13:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-20 13:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 13:49:25 --> Controller Class Initialized
INFO - 2023-08-20 13:49:25 --> Model "Banner_model" initialized
INFO - 2023-08-20 13:49:25 --> Helper loaded: form_helper
INFO - 2023-08-20 13:49:25 --> Form Validation Class Initialized
INFO - 2023-08-20 13:49:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-20 13:49:25 --> Final output sent to browser
DEBUG - 2023-08-20 13:49:25 --> Total execution time: 0.0652
