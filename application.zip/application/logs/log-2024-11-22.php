<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> No URI present. Default controller set.
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:34 --> Total execution time: 0.0897
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.0599
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.0829
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.0970
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.1158
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.1320
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:00:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:00:35 --> Total execution time: 0.1469
DEBUG - 2024-11-22 16:31:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:17 --> Total execution time: 0.0397
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0500
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0703
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0956
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0965
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.1467
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.1638
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0842
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.1075
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.1205
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:31:54 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.1270
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:54 --> Total execution time: 0.0793
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:55 --> Total execution time: 0.0791
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:55 --> Total execution time: 0.1177
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:55 --> Total execution time: 0.1400
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:01:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:01:55 --> Total execution time: 0.1137
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.0447
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.0961
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1406
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1698
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1974
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.2236
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.2485
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1625
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1474
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1015
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 16:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1232
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1247
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1143
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.0813
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:09:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:09:36 --> Total execution time: 0.1001
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.0537
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.0735
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1144
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1493
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1823
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.2072
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.2289
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1763
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1563
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1394
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.0930
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1163
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1259
DEBUG - 2024-11-22 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.1217
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:14:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:14:47 --> Total execution time: 0.0739
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.0670
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.0992
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1351
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1843
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.2155
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.2443
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.2863
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.2213
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.2040
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1150
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:45:59 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1508
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1889
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1946
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1229
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:15:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:15:59 --> Total execution time: 0.1609
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.0733
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.1326
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.1856
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.2286
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.2754
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.3145
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:51 --> Total execution time: 0.3688
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 16:57:52 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2937
DEBUG - 2024-11-22 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2830
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2739
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.1908
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:57:52 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2376
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2601
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.2439
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:27:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:27:52 --> Total execution time: 0.1564
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.0731
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.1375
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.1764
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2290
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2751
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.3045
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.3547
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2834
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2594
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.1724
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2254
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:23 --> Total execution time: 0.2681
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 16:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:24 --> Total execution time: 0.3001
DEBUG - 2024-11-22 16:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:24 --> Total execution time: 0.1373
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:24 --> Total execution time: 0.1664
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:24 --> Total execution time: 0.1995
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.1784
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 16:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.2292
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.2973
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.3608
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.4187
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.3713
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:29:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:29:39 --> Total execution time: 0.3743
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:29 --> Total execution time: 0.0830
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.1630
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.2191
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3003
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3627
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.4191
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.4676
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3743
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3668
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3279
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3485
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3359
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3255
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.2983
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.2995
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3046
DEBUG - 2024-11-22 17:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3241
DEBUG - 2024-11-22 17:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:30 --> Total execution time: 0.3302
ERROR - 2024-11-22 21:30:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:31 --> Total execution time: 0.2005
DEBUG - 2024-11-22 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:31 --> Total execution time: 0.1133
DEBUG - 2024-11-22 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:31 --> Total execution time: 0.0782
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:30:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:30:31 --> Total execution time: 0.1147
DEBUG - 2024-11-22 17:07:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.0765
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.1672
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.2513
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.3680
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.4518
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.5138
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.5682
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:43 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:43 --> Total execution time: 0.5326
DEBUG - 2024-11-22 17:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.5142
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.2976
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3699
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.4280
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3731
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3791
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.2819
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3436
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3505
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3560
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3589
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3644
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3540
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3492
DEBUG - 2024-11-22 17:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:44 --> Total execution time: 0.3579
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:44 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3490
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3362
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3287
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3304
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.2828
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3012
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.2897
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3049
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3023
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.3054
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.2206
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:07:45 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.0987
DEBUG - 2024-11-22 17:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:37:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:37:45 --> Total execution time: 0.1049
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:12 --> Total execution time: 0.1326
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:12 --> Total execution time: 0.1544
DEBUG - 2024-11-22 17:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:12 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2109
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2729
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.3399
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.4254
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.3744
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.3723
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.3592
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.3589
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2587
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2389
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.1970
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2461
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-22 17:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2712
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2560
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2618
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2421
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2223
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:13 --> Total execution time: 0.2565
DEBUG - 2024-11-22 17:16:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-22 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-22 17:16:14 --> UTF-8 Support Enabled
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-22 17:16:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:14 --> Total execution time: 0.1350
DEBUG - 2024-11-22 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-22 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:14 --> Total execution time: 0.1633
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-22 21:46:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-22 21:46:14 --> Total execution time: 0.2200
