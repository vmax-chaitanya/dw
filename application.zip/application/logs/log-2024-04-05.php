<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-05 08:09:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:21 --> No URI present. Default controller set.
DEBUG - 2024-04-05 08:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:22 --> Total execution time: 1.7178
DEBUG - 2024-04-05 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:29 --> Total execution time: 0.1308
DEBUG - 2024-04-05 08:09:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:29 --> Total execution time: 0.2084
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:29 --> Total execution time: 0.2433
DEBUG - 2024-04-05 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:32 --> Total execution time: 0.1723
DEBUG - 2024-04-05 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:32 --> Total execution time: 0.0826
DEBUG - 2024-04-05 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:32 --> Total execution time: 0.1211
DEBUG - 2024-04-05 08:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:39:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:39:32 --> Total execution time: 0.0889
DEBUG - 2024-04-05 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:09:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:39:54 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:10:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:10:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:10:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.1074
DEBUG - 2024-04-05 08:10:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:04 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.1812
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:10:04 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.2272
DEBUG - 2024-04-05 08:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.2145
DEBUG - 2024-04-05 08:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.1384
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.1795
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
ERROR - 2024-04-05 11:40:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 136
DEBUG - 2024-04-05 11:40:04 --> Total execution time: 0.1453
DEBUG - 2024-04-05 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:39 --> Total execution time: 0.1325
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:40 --> Total execution time: 0.1661
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:40 --> Total execution time: 0.1781
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:40 --> Total execution time: 0.4182
DEBUG - 2024-04-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:40 --> Total execution time: 0.3605
DEBUG - 2024-04-05 08:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.3952
DEBUG - 2024-04-05 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.4821
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.2379
DEBUG - 2024-04-05 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.0990
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.1561
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:49:41 --> Total execution time: 0.2512
DEBUG - 2024-04-05 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:48 --> Total execution time: 0.1510
DEBUG - 2024-04-05 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:49 --> Total execution time: 0.5122
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:49 --> Total execution time: 0.6019
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:49 --> Total execution time: 0.9191
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:49 --> Total execution time: 1.1974
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:49 --> Total execution time: 1.2661
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:50 --> Total execution time: 0.5500
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:50 --> Total execution time: 0.4678
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:50 --> Total execution time: 0.4329
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:50 --> Total execution time: 0.3873
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:50:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:50:50 --> Total execution time: 0.3358
DEBUG - 2024-04-05 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:50:54 --> Total execution time: 0.0766
DEBUG - 2024-04-05 08:20:58 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:50:58 --> Total execution time: 0.1489
DEBUG - 2024-04-05 08:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:51:10 --> Total execution time: 0.0958
DEBUG - 2024-04-05 08:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:51:15 --> Total execution time: 0.1516
DEBUG - 2024-04-05 08:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:51:50 --> Total execution time: 0.0895
DEBUG - 2024-04-05 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:33 --> Total execution time: 0.0936
DEBUG - 2024-04-05 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.2698
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.1154
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.5608
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.4472
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.5012
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:34 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.5323
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.4970
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.2240
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:34 --> Total execution time: 0.1886
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:35 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:35 --> Total execution time: 0.1655
DEBUG - 2024-04-05 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:52:43 --> Total execution time: 0.0913
DEBUG - 2024-04-05 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:48 --> Total execution time: 0.1110
DEBUG - 2024-04-05 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:48 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:52:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-04-05 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1875
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.2394
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.5080
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1314
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1658
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.2092
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1111
DEBUG - 2024-04-05 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.3242
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1587
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:52:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:52:49 --> Total execution time: 0.1909
DEBUG - 2024-04-05 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:29 --> Total execution time: 0.1431
DEBUG - 2024-04-05 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.6352
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.2564
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.4234
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.9430
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 1.0194
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.5590
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.2966
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.2551
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.2536
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:53:30 --> Total execution time: 0.3104
DEBUG - 2024-04-05 08:23:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:49 --> Total execution time: 0.1300
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.2122
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.0870
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.3184
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.0863
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.1124
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:50 --> Total execution time: 0.0770
DEBUG - 2024-04-05 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:51 --> Total execution time: 0.1752
DEBUG - 2024-04-05 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:24:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:54:51 --> Total execution time: 0.1639
DEBUG - 2024-04-05 08:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:51 --> Total execution time: 0.0717
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:54:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:54:51 --> Total execution time: 0.1155
DEBUG - 2024-04-05 08:25:47 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:30 --> Total execution time: 0.1131
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:30 --> Total execution time: 0.2398
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:30 --> Total execution time: 0.1234
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:30 --> Total execution time: 0.3820
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:30 --> Total execution time: 0.1165
DEBUG - 2024-04-05 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.4796
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.1885
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.2308
DEBUG - 2024-04-05 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.3565
DEBUG - 2024-04-05 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.1577
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:56:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:56:31 --> Total execution time: 0.1990
DEBUG - 2024-04-05 08:26:48 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:16 --> Total execution time: 0.0985
DEBUG - 2024-04-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.6159
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.6355
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.9094
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.4415
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.4283
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.4884
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:17 --> Total execution time: 0.2274
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:18 --> Total execution time: 0.4025
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:18 --> Total execution time: 0.1773
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:18 --> Total execution time: 0.2545
DEBUG - 2024-04-05 08:27:35 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:57:35 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:55 --> Total execution time: 0.1297
DEBUG - 2024-04-05 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:55 --> Total execution time: 0.1346
DEBUG - 2024-04-05 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:55 --> Total execution time: 0.2798
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:57:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:57:55 --> Total execution time: 0.1530
DEBUG - 2024-04-05 08:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:58:04 --> Total execution time: 0.0857
DEBUG - 2024-04-05 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 11:58:19 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:28:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:58:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:58:44 --> Total execution time: 0.2504
DEBUG - 2024-04-05 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:58:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:58:49 --> Total execution time: 0.1534
DEBUG - 2024-04-05 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 11:59:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 11:59:16 --> Total execution time: 0.1755
DEBUG - 2024-04-05 08:37:59 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:07:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:07:59 --> Total execution time: 0.1899
DEBUG - 2024-04-05 08:38:14 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 12:08:28 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:38:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:32 --> Total execution time: 0.1599
DEBUG - 2024-04-05 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:38:44 --> UTF-8 Support Enabled
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:44 --> Total execution time: 0.0884
DEBUG - 2024-04-05 08:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:44 --> Total execution time: 0.1199
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:45 --> Total execution time: 0.1345
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:45 --> Total execution time: 0.1921
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:45 --> Total execution time: 0.1992
DEBUG - 2024-04-05 08:38:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:45 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:45 --> Total execution time: 0.1162
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:08:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:08:45 --> Total execution time: 0.1675
DEBUG - 2024-04-05 08:39:24 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:24 --> Total execution time: 0.1094
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.0931
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.1167
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.0878
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.1632
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.2075
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.1796
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:28 --> Total execution time: 0.2166
DEBUG - 2024-04-05 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:39:49 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 12:09:50 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:39:54 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:09:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:09:54 --> Total execution time: 0.1294
DEBUG - 2024-04-05 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:10:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:10:07 --> Total execution time: 0.0805
DEBUG - 2024-04-05 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:10:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:10:22 --> Total execution time: 0.1336
DEBUG - 2024-04-05 08:43:23 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:13:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:13:23 --> Total execution time: 0.1581
DEBUG - 2024-04-05 08:43:26 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:13:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:13:27 --> Total execution time: 0.1259
DEBUG - 2024-04-05 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:17:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:17:42 --> Total execution time: 0.1295
DEBUG - 2024-04-05 08:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:17:58 --> Total execution time: 0.1506
DEBUG - 2024-04-05 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:15 --> Total execution time: 0.1360
DEBUG - 2024-04-05 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:32 --> Total execution time: 0.1849
DEBUG - 2024-04-05 08:48:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.0617
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.1033
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.2451
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.0842
DEBUG - 2024-04-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.2489
DEBUG - 2024-04-05 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.0945
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:18:53 --> Total execution time: 0.2199
DEBUG - 2024-04-05 08:49:50 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 12:19:50 --> Phpmailer class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:41 --> Total execution time: 0.0836
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.1585
DEBUG - 2024-04-05 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.1773
DEBUG - 2024-04-05 08:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.2323
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.3658
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.6618
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.6984
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:22:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:22:42 --> Total execution time: 0.1898
DEBUG - 2024-04-05 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:19 --> Total execution time: 0.1242
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.1256
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.1064
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:53:20 --> UTF-8 Support Enabled
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.0916
DEBUG - 2024-04-05 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
DEBUG - 2024-04-05 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.1432
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.0935
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.2069
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:20 --> Total execution time: 0.2395
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:29 --> Total execution time: 0.1180
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:29 --> Total execution time: 0.0678
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:29 --> Total execution time: 0.0721
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> UTF-8 Support Enabled
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:29 --> Total execution time: 0.2211
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:29 --> Total execution time: 0.0790
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:30 --> Total execution time: 0.3309
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:30 --> Total execution time: 0.4905
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:30 --> Total execution time: 0.5405
DEBUG - 2024-04-05 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:43 --> Total execution time: 0.1198
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:43 --> Total execution time: 0.5890
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:53:43 --> UTF-8 Support Enabled
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:43 --> Total execution time: 0.6590
DEBUG - 2024-04-05 08:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:43 --> Total execution time: 0.5376
DEBUG - 2024-04-05 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:43 --> Total execution time: 0.5697
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:44 --> Total execution time: 0.5106
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:44 --> Total execution time: 0.8052
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:23:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:23:44 --> Total execution time: 0.2095
DEBUG - 2024-04-05 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:22 --> Total execution time: 0.1170
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:22 --> Total execution time: 0.1409
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:22 --> Total execution time: 0.1589
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
DEBUG - 2024-04-05 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:22 --> Total execution time: 0.1916
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:23 --> Total execution time: 0.1568
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:23 --> Total execution time: 0.1626
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:23 --> Total execution time: 0.1962
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-05 12:24:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-05 12:24:23 --> Total execution time: 0.2737
DEBUG - 2024-04-05 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2024-04-05 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-05 08:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-05 12:24:43 --> Phpmailer class already loaded. Second attempt ignored.
