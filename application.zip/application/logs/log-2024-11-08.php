<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-08 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:09:24 --> No URI present. Default controller set.
DEBUG - 2024-11-08 06:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 06:09:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'dw' C:\xampp\htdocs\dw\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-11-08 06:09:24 --> Unable to connect to the database
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> No URI present. Default controller set.
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:47 --> Total execution time: 0.1715
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 06:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:47 --> Total execution time: 0.1832
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:47 --> Total execution time: 0.2515
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:47 --> Total execution time: 0.3306
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:48 --> Total execution time: 0.3761
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:48 --> Total execution time: 0.4102
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:41:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:41:48 --> Total execution time: 0.5302
DEBUG - 2024-11-08 06:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:28 --> Total execution time: 0.3222
DEBUG - 2024-11-08 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:29 --> Total execution time: 0.2419
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:29 --> Total execution time: 0.2780
DEBUG - 2024-11-08 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:39 --> Total execution time: 0.2263
DEBUG - 2024-11-08 06:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:47 --> Total execution time: 0.1953
DEBUG - 2024-11-08 06:12:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:42:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:42:55 --> Total execution time: 0.1722
DEBUG - 2024-11-08 06:13:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:43:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:43:14 --> Total execution time: 0.2079
DEBUG - 2024-11-08 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:50:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:50:32 --> Total execution time: 0.3078
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> No URI present. Default controller set.
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:40 --> Total execution time: 0.2032
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:40 --> Total execution time: 0.2824
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:41 --> Total execution time: 0.4601
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:41 --> Total execution time: 0.5578
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:41 --> Total execution time: 0.7357
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:41 --> Total execution time: 0.9345
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 10:54:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 10:54:41 --> Total execution time: 1.0033
DEBUG - 2024-11-08 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:05:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:05:45 --> Total execution time: 0.3171
DEBUG - 2024-11-08 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:06:29 --> Total execution time: 0.2254
DEBUG - 2024-11-08 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:14:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:14:27 --> Total execution time: 0.1349
DEBUG - 2024-11-08 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:05 --> Total execution time: 0.3060
DEBUG - 2024-11-08 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:05 --> Total execution time: 0.1989
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:05 --> Total execution time: 0.2624
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:05 --> Total execution time: 0.3264
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.1256
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.1631
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.1976
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2367
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3020
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3641
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.1845
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2557
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3111
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3310
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3138
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.3006
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2883
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2678
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2681
DEBUG - 2024-11-08 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:06 --> Total execution time: 0.2578
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:06 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2781
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2872
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2846
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2995
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2956
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2869
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2733
DEBUG - 2024-11-08 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2170
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2386
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.2153
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.1992
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:28:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:28:07 --> Total execution time: 0.1845
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.1380
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.1518
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.2232
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.2410
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.3141
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.3478
DEBUG - 2024-11-08 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.3797
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:30:56 --> Total execution time: 0.2120
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:00:56 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2478
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2696
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1677
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2008
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2423
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2510
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1499
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2169
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1919
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2166
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2358
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2559
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2382
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2157
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.2055
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1964
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1927
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1962
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:00:57 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1935
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1936
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1880
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1799
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1612
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:30:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:30:57 --> Total execution time: 0.1484
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:58 --> Total execution time: 0.0924
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:58 --> Total execution time: 0.1491
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:58 --> Total execution time: 0.1984
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:58 --> Total execution time: 0.2565
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:58 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:58 --> Total execution time: 0.1443
DEBUG - 2024-11-08 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1541
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1900
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2388
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2795
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2821
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1635
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2073
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2439
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2221
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1463
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1865
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2306
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2471
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2220
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2436
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2378
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2229
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.2060
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1888
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1923
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1915
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:03:59 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1892
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1873
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1850
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1737
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1569
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:33:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:33:59 --> Total execution time: 0.1510
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.0779
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.1289
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.1757
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.2266
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.2659
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.3145
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.3261
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.2322
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.2364
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.1241
DEBUG - 2024-11-08 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.1531
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:49 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:35:49 --> Total execution time: 0.1996
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2611
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2474
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.1748
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2170
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2507
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2110
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2299
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2412
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2303
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2242
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2483
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2623
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2474
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2281
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:05:50 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2297
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.2158
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.1823
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.1656
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.1551
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:35:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:35:50 --> Total execution time: 0.1454
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1011
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.0736
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1087
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.0747
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.0996
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1309
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1654
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1605
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1480
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1444
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1334
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:07 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:07 --> Total execution time: 0.1383
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1302
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.0903
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1153
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1313
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1311
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.0838
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1094
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1334
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1401
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1425
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1426
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1405
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1370
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1400
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1347
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1321
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1261
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1256
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1268
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:42:08 --> Total execution time: 0.1173
DEBUG - 2024-11-08 07:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:46:51 --> Total execution time: 0.0774
DEBUG - 2024-11-08 07:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:46:51 --> Total execution time: 0.0453
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:46:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:46:51 --> Total execution time: 0.0635
DEBUG - 2024-11-08 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:18 --> Total execution time: 0.0738
DEBUG - 2024-11-08 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:18 --> Total execution time: 0.0636
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:18 --> Total execution time: 0.0841
DEBUG - 2024-11-08 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:21 --> Total execution time: 0.0596
DEBUG - 2024-11-08 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:21 --> Total execution time: 0.0687
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:21 --> Total execution time: 0.1082
DEBUG - 2024-11-08 07:18:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:29 --> Total execution time: 0.0551
DEBUG - 2024-11-08 07:18:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:29 --> Total execution time: 0.0590
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:48:29 --> Total execution time: 0.0764
DEBUG - 2024-11-08 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:05 --> Total execution time: 0.0863
DEBUG - 2024-11-08 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:05 --> Total execution time: 0.0512
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:05 --> Total execution time: 0.0767
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0625
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0898
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1086
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0937
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0972
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1178
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1410
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1283
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1291
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1261
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1113
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1246
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1202
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1148
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0767
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0930
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1098
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1025
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.1018
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0677
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:28 --> Total execution time: 0.0674
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-08 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:28 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1078
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:29 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1318
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:29 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1116
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1092
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-08 07:19:29 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1118
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1071
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-08 07:19:29 --> UTF-8 Support Enabled
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 07:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.1030
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.0952
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.0895
DEBUG - 2024-11-08 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.0843
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-08 11:49:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-08 11:49:29 --> Total execution time: 0.0631
