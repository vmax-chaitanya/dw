<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-07 17:39:53 --> Config Class Initialized
INFO - 2023-09-07 17:39:53 --> Hooks Class Initialized
DEBUG - 2023-09-07 17:39:53 --> UTF-8 Support Enabled
INFO - 2023-09-07 17:39:53 --> Utf8 Class Initialized
INFO - 2023-09-07 17:39:53 --> URI Class Initialized
DEBUG - 2023-09-07 17:39:53 --> No URI present. Default controller set.
INFO - 2023-09-07 17:39:53 --> Router Class Initialized
INFO - 2023-09-07 17:39:53 --> Output Class Initialized
INFO - 2023-09-07 17:39:53 --> Security Class Initialized
DEBUG - 2023-09-07 17:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 17:39:53 --> Input Class Initialized
INFO - 2023-09-07 17:39:53 --> Language Class Initialized
INFO - 2023-09-07 17:39:53 --> Loader Class Initialized
INFO - 2023-09-07 17:39:53 --> Helper loaded: url_helper
INFO - 2023-09-07 17:39:53 --> Helper loaded: file_helper
INFO - 2023-09-07 17:39:53 --> Database Driver Class Initialized
INFO - 2023-09-07 17:39:54 --> Email Class Initialized
DEBUG - 2023-09-07 17:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 17:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 17:39:54 --> Controller Class Initialized
INFO - 2023-09-07 17:39:54 --> Model "Contact_model" initialized
INFO - 2023-09-07 17:39:54 --> Model "Home_model" initialized
INFO - 2023-09-07 17:39:54 --> Helper loaded: download_helper
INFO - 2023-09-07 17:39:54 --> Helper loaded: form_helper
INFO - 2023-09-07 17:39:54 --> Form Validation Class Initialized
INFO - 2023-09-07 17:39:54 --> Helper loaded: custom_helper
INFO - 2023-09-07 17:39:54 --> Model "Social_media_model" initialized
INFO - 2023-09-07 17:39:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 17:39:54 --> Final output sent to browser
DEBUG - 2023-09-07 17:39:54 --> Total execution time: 1.8585
INFO - 2023-09-07 17:39:56 --> Config Class Initialized
INFO - 2023-09-07 17:39:56 --> Hooks Class Initialized
DEBUG - 2023-09-07 17:39:56 --> UTF-8 Support Enabled
INFO - 2023-09-07 17:39:56 --> Utf8 Class Initialized
INFO - 2023-09-07 17:39:56 --> URI Class Initialized
INFO - 2023-09-07 17:39:56 --> Router Class Initialized
INFO - 2023-09-07 17:39:56 --> Output Class Initialized
INFO - 2023-09-07 17:39:56 --> Security Class Initialized
DEBUG - 2023-09-07 17:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 17:39:56 --> Input Class Initialized
INFO - 2023-09-07 17:39:56 --> Language Class Initialized
ERROR - 2023-09-07 17:39:56 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 17:58:32 --> Config Class Initialized
INFO - 2023-09-07 17:58:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 17:58:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 17:58:32 --> Utf8 Class Initialized
INFO - 2023-09-07 17:58:32 --> URI Class Initialized
INFO - 2023-09-07 17:58:32 --> Router Class Initialized
INFO - 2023-09-07 17:58:32 --> Output Class Initialized
INFO - 2023-09-07 17:58:32 --> Security Class Initialized
DEBUG - 2023-09-07 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 17:58:32 --> Input Class Initialized
INFO - 2023-09-07 17:58:32 --> Language Class Initialized
INFO - 2023-09-07 17:58:32 --> Loader Class Initialized
INFO - 2023-09-07 17:58:32 --> Helper loaded: url_helper
INFO - 2023-09-07 17:58:32 --> Helper loaded: file_helper
INFO - 2023-09-07 17:58:32 --> Database Driver Class Initialized
INFO - 2023-09-07 17:58:32 --> Email Class Initialized
DEBUG - 2023-09-07 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 17:58:32 --> Controller Class Initialized
INFO - 2023-09-07 17:58:32 --> Model "Contact_model" initialized
INFO - 2023-09-07 17:58:32 --> Model "Home_model" initialized
INFO - 2023-09-07 17:58:32 --> Helper loaded: download_helper
INFO - 2023-09-07 17:58:32 --> Helper loaded: form_helper
INFO - 2023-09-07 17:58:32 --> Form Validation Class Initialized
INFO - 2023-09-07 17:58:32 --> Helper loaded: custom_helper
INFO - 2023-09-07 17:58:32 --> Model "Social_media_model" initialized
INFO - 2023-09-07 17:58:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 17:58:32 --> Final output sent to browser
DEBUG - 2023-09-07 17:58:32 --> Total execution time: 0.1280
INFO - 2023-09-07 17:58:33 --> Config Class Initialized
INFO - 2023-09-07 17:58:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 17:58:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 17:58:33 --> Utf8 Class Initialized
INFO - 2023-09-07 17:58:33 --> URI Class Initialized
INFO - 2023-09-07 17:58:33 --> Router Class Initialized
INFO - 2023-09-07 17:58:33 --> Output Class Initialized
INFO - 2023-09-07 17:58:33 --> Security Class Initialized
DEBUG - 2023-09-07 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 17:58:33 --> Input Class Initialized
INFO - 2023-09-07 17:58:33 --> Language Class Initialized
ERROR - 2023-09-07 17:58:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:13:07 --> Config Class Initialized
INFO - 2023-09-07 18:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:13:07 --> Utf8 Class Initialized
INFO - 2023-09-07 18:13:07 --> URI Class Initialized
INFO - 2023-09-07 18:13:07 --> Router Class Initialized
INFO - 2023-09-07 18:13:07 --> Output Class Initialized
INFO - 2023-09-07 18:13:07 --> Security Class Initialized
DEBUG - 2023-09-07 18:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:13:07 --> Input Class Initialized
INFO - 2023-09-07 18:13:07 --> Language Class Initialized
INFO - 2023-09-07 18:13:07 --> Loader Class Initialized
INFO - 2023-09-07 18:13:07 --> Helper loaded: url_helper
INFO - 2023-09-07 18:13:07 --> Helper loaded: file_helper
INFO - 2023-09-07 18:13:07 --> Database Driver Class Initialized
INFO - 2023-09-07 18:13:07 --> Email Class Initialized
DEBUG - 2023-09-07 18:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:13:07 --> Controller Class Initialized
INFO - 2023-09-07 18:13:07 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:13:07 --> Model "Home_model" initialized
INFO - 2023-09-07 18:13:07 --> Helper loaded: download_helper
INFO - 2023-09-07 18:13:07 --> Helper loaded: form_helper
INFO - 2023-09-07 18:13:07 --> Form Validation Class Initialized
INFO - 2023-09-07 18:13:07 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:13:07 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:13:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:13:07 --> Final output sent to browser
DEBUG - 2023-09-07 18:13:07 --> Total execution time: 0.1306
INFO - 2023-09-07 18:13:08 --> Config Class Initialized
INFO - 2023-09-07 18:13:08 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:13:08 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:13:08 --> Utf8 Class Initialized
INFO - 2023-09-07 18:13:08 --> URI Class Initialized
INFO - 2023-09-07 18:13:08 --> Router Class Initialized
INFO - 2023-09-07 18:13:08 --> Output Class Initialized
INFO - 2023-09-07 18:13:08 --> Security Class Initialized
DEBUG - 2023-09-07 18:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:13:08 --> Input Class Initialized
INFO - 2023-09-07 18:13:08 --> Language Class Initialized
ERROR - 2023-09-07 18:13:08 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:14:36 --> Config Class Initialized
INFO - 2023-09-07 18:14:36 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:14:36 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:14:36 --> Utf8 Class Initialized
INFO - 2023-09-07 18:14:36 --> URI Class Initialized
INFO - 2023-09-07 18:14:36 --> Router Class Initialized
INFO - 2023-09-07 18:14:36 --> Output Class Initialized
INFO - 2023-09-07 18:14:36 --> Security Class Initialized
DEBUG - 2023-09-07 18:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:14:36 --> Input Class Initialized
INFO - 2023-09-07 18:14:36 --> Language Class Initialized
INFO - 2023-09-07 18:14:36 --> Loader Class Initialized
INFO - 2023-09-07 18:14:36 --> Helper loaded: url_helper
INFO - 2023-09-07 18:14:36 --> Helper loaded: file_helper
INFO - 2023-09-07 18:14:36 --> Database Driver Class Initialized
INFO - 2023-09-07 18:14:36 --> Email Class Initialized
DEBUG - 2023-09-07 18:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:14:36 --> Controller Class Initialized
INFO - 2023-09-07 18:14:36 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:14:36 --> Model "Home_model" initialized
INFO - 2023-09-07 18:14:36 --> Helper loaded: download_helper
INFO - 2023-09-07 18:14:36 --> Helper loaded: form_helper
INFO - 2023-09-07 18:14:36 --> Form Validation Class Initialized
INFO - 2023-09-07 18:14:36 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:14:36 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:14:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:14:36 --> Final output sent to browser
DEBUG - 2023-09-07 18:14:36 --> Total execution time: 0.1798
INFO - 2023-09-07 18:14:37 --> Config Class Initialized
INFO - 2023-09-07 18:14:37 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:14:37 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:14:37 --> Utf8 Class Initialized
INFO - 2023-09-07 18:14:37 --> URI Class Initialized
INFO - 2023-09-07 18:14:37 --> Router Class Initialized
INFO - 2023-09-07 18:14:37 --> Output Class Initialized
INFO - 2023-09-07 18:14:37 --> Security Class Initialized
DEBUG - 2023-09-07 18:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:14:37 --> Input Class Initialized
INFO - 2023-09-07 18:14:37 --> Language Class Initialized
ERROR - 2023-09-07 18:14:37 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:14:54 --> Config Class Initialized
INFO - 2023-09-07 18:14:54 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:14:54 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:14:54 --> Utf8 Class Initialized
INFO - 2023-09-07 18:14:54 --> URI Class Initialized
INFO - 2023-09-07 18:14:54 --> Router Class Initialized
INFO - 2023-09-07 18:14:54 --> Output Class Initialized
INFO - 2023-09-07 18:14:54 --> Security Class Initialized
DEBUG - 2023-09-07 18:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:14:54 --> Input Class Initialized
INFO - 2023-09-07 18:14:54 --> Language Class Initialized
INFO - 2023-09-07 18:14:54 --> Loader Class Initialized
INFO - 2023-09-07 18:14:54 --> Helper loaded: url_helper
INFO - 2023-09-07 18:14:54 --> Helper loaded: file_helper
INFO - 2023-09-07 18:14:54 --> Database Driver Class Initialized
INFO - 2023-09-07 18:14:54 --> Email Class Initialized
DEBUG - 2023-09-07 18:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:14:54 --> Controller Class Initialized
INFO - 2023-09-07 18:14:54 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:14:54 --> Model "Home_model" initialized
INFO - 2023-09-07 18:14:54 --> Helper loaded: download_helper
INFO - 2023-09-07 18:14:54 --> Helper loaded: form_helper
INFO - 2023-09-07 18:14:54 --> Form Validation Class Initialized
INFO - 2023-09-07 18:14:54 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:14:54 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:14:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:14:54 --> Final output sent to browser
DEBUG - 2023-09-07 18:14:54 --> Total execution time: 0.4182
INFO - 2023-09-07 18:14:55 --> Config Class Initialized
INFO - 2023-09-07 18:14:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:14:55 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:14:55 --> Utf8 Class Initialized
INFO - 2023-09-07 18:14:55 --> URI Class Initialized
INFO - 2023-09-07 18:14:55 --> Router Class Initialized
INFO - 2023-09-07 18:14:55 --> Output Class Initialized
INFO - 2023-09-07 18:14:55 --> Security Class Initialized
DEBUG - 2023-09-07 18:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:14:55 --> Input Class Initialized
INFO - 2023-09-07 18:14:55 --> Language Class Initialized
ERROR - 2023-09-07 18:14:55 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:15:42 --> Config Class Initialized
INFO - 2023-09-07 18:15:42 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:15:42 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:15:42 --> Utf8 Class Initialized
INFO - 2023-09-07 18:15:42 --> URI Class Initialized
INFO - 2023-09-07 18:15:42 --> Router Class Initialized
INFO - 2023-09-07 18:15:42 --> Output Class Initialized
INFO - 2023-09-07 18:15:42 --> Security Class Initialized
DEBUG - 2023-09-07 18:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:15:42 --> Input Class Initialized
INFO - 2023-09-07 18:15:42 --> Language Class Initialized
INFO - 2023-09-07 18:15:42 --> Loader Class Initialized
INFO - 2023-09-07 18:15:42 --> Helper loaded: url_helper
INFO - 2023-09-07 18:15:42 --> Helper loaded: file_helper
INFO - 2023-09-07 18:15:42 --> Database Driver Class Initialized
INFO - 2023-09-07 18:15:42 --> Email Class Initialized
DEBUG - 2023-09-07 18:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:15:42 --> Controller Class Initialized
INFO - 2023-09-07 18:15:42 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:15:42 --> Model "Home_model" initialized
INFO - 2023-09-07 18:15:42 --> Helper loaded: download_helper
INFO - 2023-09-07 18:15:42 --> Helper loaded: form_helper
INFO - 2023-09-07 18:15:42 --> Form Validation Class Initialized
INFO - 2023-09-07 18:15:42 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:15:42 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:15:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:15:42 --> Final output sent to browser
DEBUG - 2023-09-07 18:15:42 --> Total execution time: 0.2077
INFO - 2023-09-07 18:15:43 --> Config Class Initialized
INFO - 2023-09-07 18:15:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:15:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:15:43 --> Utf8 Class Initialized
INFO - 2023-09-07 18:15:43 --> URI Class Initialized
INFO - 2023-09-07 18:15:43 --> Router Class Initialized
INFO - 2023-09-07 18:15:43 --> Output Class Initialized
INFO - 2023-09-07 18:15:43 --> Security Class Initialized
DEBUG - 2023-09-07 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:15:43 --> Input Class Initialized
INFO - 2023-09-07 18:15:43 --> Language Class Initialized
ERROR - 2023-09-07 18:15:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:17:21 --> Config Class Initialized
INFO - 2023-09-07 18:17:21 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:17:21 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:17:21 --> Utf8 Class Initialized
INFO - 2023-09-07 18:17:21 --> URI Class Initialized
INFO - 2023-09-07 18:17:21 --> Router Class Initialized
INFO - 2023-09-07 18:17:21 --> Output Class Initialized
INFO - 2023-09-07 18:17:21 --> Security Class Initialized
DEBUG - 2023-09-07 18:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:17:21 --> Input Class Initialized
INFO - 2023-09-07 18:17:21 --> Language Class Initialized
INFO - 2023-09-07 18:17:21 --> Loader Class Initialized
INFO - 2023-09-07 18:17:21 --> Helper loaded: url_helper
INFO - 2023-09-07 18:17:21 --> Helper loaded: file_helper
INFO - 2023-09-07 18:17:21 --> Database Driver Class Initialized
INFO - 2023-09-07 18:17:21 --> Email Class Initialized
DEBUG - 2023-09-07 18:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:17:21 --> Controller Class Initialized
INFO - 2023-09-07 18:17:21 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:17:21 --> Model "Home_model" initialized
INFO - 2023-09-07 18:17:21 --> Helper loaded: download_helper
INFO - 2023-09-07 18:17:21 --> Helper loaded: form_helper
INFO - 2023-09-07 18:17:21 --> Form Validation Class Initialized
INFO - 2023-09-07 18:17:21 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:17:21 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:17:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:17:21 --> Final output sent to browser
DEBUG - 2023-09-07 18:17:21 --> Total execution time: 0.1144
INFO - 2023-09-07 18:17:23 --> Config Class Initialized
INFO - 2023-09-07 18:17:23 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:17:23 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:17:23 --> Utf8 Class Initialized
INFO - 2023-09-07 18:17:23 --> URI Class Initialized
INFO - 2023-09-07 18:17:23 --> Router Class Initialized
INFO - 2023-09-07 18:17:23 --> Output Class Initialized
INFO - 2023-09-07 18:17:23 --> Security Class Initialized
DEBUG - 2023-09-07 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:17:23 --> Input Class Initialized
INFO - 2023-09-07 18:17:23 --> Language Class Initialized
ERROR - 2023-09-07 18:17:23 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:18:01 --> Config Class Initialized
INFO - 2023-09-07 18:18:01 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:01 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:01 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:01 --> URI Class Initialized
INFO - 2023-09-07 18:18:01 --> Router Class Initialized
INFO - 2023-09-07 18:18:01 --> Output Class Initialized
INFO - 2023-09-07 18:18:01 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:01 --> Input Class Initialized
INFO - 2023-09-07 18:18:01 --> Language Class Initialized
INFO - 2023-09-07 18:18:01 --> Loader Class Initialized
INFO - 2023-09-07 18:18:01 --> Helper loaded: url_helper
INFO - 2023-09-07 18:18:01 --> Helper loaded: file_helper
INFO - 2023-09-07 18:18:01 --> Database Driver Class Initialized
INFO - 2023-09-07 18:18:01 --> Email Class Initialized
DEBUG - 2023-09-07 18:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:18:01 --> Controller Class Initialized
INFO - 2023-09-07 18:18:01 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:18:01 --> Model "Home_model" initialized
INFO - 2023-09-07 18:18:01 --> Helper loaded: download_helper
INFO - 2023-09-07 18:18:01 --> Helper loaded: form_helper
INFO - 2023-09-07 18:18:01 --> Form Validation Class Initialized
INFO - 2023-09-07 18:18:01 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:18:01 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:18:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:18:01 --> Final output sent to browser
DEBUG - 2023-09-07 18:18:01 --> Total execution time: 0.1600
INFO - 2023-09-07 18:18:01 --> Config Class Initialized
INFO - 2023-09-07 18:18:01 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:01 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:01 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:01 --> URI Class Initialized
INFO - 2023-09-07 18:18:01 --> Router Class Initialized
INFO - 2023-09-07 18:18:01 --> Output Class Initialized
INFO - 2023-09-07 18:18:01 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:01 --> Input Class Initialized
INFO - 2023-09-07 18:18:01 --> Language Class Initialized
ERROR - 2023-09-07 18:18:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:18:32 --> Config Class Initialized
INFO - 2023-09-07 18:18:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:32 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:32 --> URI Class Initialized
INFO - 2023-09-07 18:18:32 --> Router Class Initialized
INFO - 2023-09-07 18:18:32 --> Output Class Initialized
INFO - 2023-09-07 18:18:32 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:32 --> Input Class Initialized
INFO - 2023-09-07 18:18:32 --> Language Class Initialized
INFO - 2023-09-07 18:18:32 --> Loader Class Initialized
INFO - 2023-09-07 18:18:32 --> Helper loaded: url_helper
INFO - 2023-09-07 18:18:32 --> Helper loaded: file_helper
INFO - 2023-09-07 18:18:32 --> Database Driver Class Initialized
INFO - 2023-09-07 18:18:32 --> Email Class Initialized
DEBUG - 2023-09-07 18:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:18:32 --> Controller Class Initialized
INFO - 2023-09-07 18:18:32 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:18:32 --> Model "Home_model" initialized
INFO - 2023-09-07 18:18:32 --> Helper loaded: download_helper
INFO - 2023-09-07 18:18:32 --> Helper loaded: form_helper
INFO - 2023-09-07 18:18:32 --> Form Validation Class Initialized
INFO - 2023-09-07 18:18:32 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:18:32 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:18:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:18:32 --> Final output sent to browser
DEBUG - 2023-09-07 18:18:32 --> Total execution time: 0.0981
INFO - 2023-09-07 18:18:33 --> Config Class Initialized
INFO - 2023-09-07 18:18:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:33 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:33 --> URI Class Initialized
INFO - 2023-09-07 18:18:33 --> Router Class Initialized
INFO - 2023-09-07 18:18:33 --> Output Class Initialized
INFO - 2023-09-07 18:18:33 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:33 --> Input Class Initialized
INFO - 2023-09-07 18:18:33 --> Language Class Initialized
ERROR - 2023-09-07 18:18:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:18:51 --> Config Class Initialized
INFO - 2023-09-07 18:18:51 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:51 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:51 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:51 --> URI Class Initialized
INFO - 2023-09-07 18:18:51 --> Router Class Initialized
INFO - 2023-09-07 18:18:51 --> Output Class Initialized
INFO - 2023-09-07 18:18:51 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:51 --> Input Class Initialized
INFO - 2023-09-07 18:18:51 --> Language Class Initialized
INFO - 2023-09-07 18:18:51 --> Loader Class Initialized
INFO - 2023-09-07 18:18:51 --> Helper loaded: url_helper
INFO - 2023-09-07 18:18:51 --> Helper loaded: file_helper
INFO - 2023-09-07 18:18:51 --> Database Driver Class Initialized
INFO - 2023-09-07 18:18:51 --> Email Class Initialized
DEBUG - 2023-09-07 18:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:18:51 --> Controller Class Initialized
INFO - 2023-09-07 18:18:51 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:18:51 --> Model "Home_model" initialized
INFO - 2023-09-07 18:18:51 --> Helper loaded: download_helper
INFO - 2023-09-07 18:18:51 --> Helper loaded: form_helper
INFO - 2023-09-07 18:18:52 --> Form Validation Class Initialized
INFO - 2023-09-07 18:18:52 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:18:52 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:18:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:18:52 --> Final output sent to browser
DEBUG - 2023-09-07 18:18:52 --> Total execution time: 0.2587
INFO - 2023-09-07 18:18:52 --> Config Class Initialized
INFO - 2023-09-07 18:18:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:52 --> URI Class Initialized
INFO - 2023-09-07 18:18:52 --> Router Class Initialized
INFO - 2023-09-07 18:18:52 --> Output Class Initialized
INFO - 2023-09-07 18:18:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:52 --> Input Class Initialized
INFO - 2023-09-07 18:18:52 --> Language Class Initialized
ERROR - 2023-09-07 18:18:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:18:58 --> Config Class Initialized
INFO - 2023-09-07 18:18:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:58 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:58 --> URI Class Initialized
INFO - 2023-09-07 18:18:58 --> Router Class Initialized
INFO - 2023-09-07 18:18:58 --> Output Class Initialized
INFO - 2023-09-07 18:18:58 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:58 --> Input Class Initialized
INFO - 2023-09-07 18:18:58 --> Language Class Initialized
ERROR - 2023-09-07 18:18:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:18:59 --> Config Class Initialized
INFO - 2023-09-07 18:18:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:59 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:59 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:59 --> URI Class Initialized
INFO - 2023-09-07 18:18:59 --> Router Class Initialized
INFO - 2023-09-07 18:18:59 --> Output Class Initialized
INFO - 2023-09-07 18:18:59 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:59 --> Input Class Initialized
INFO - 2023-09-07 18:18:59 --> Language Class Initialized
ERROR - 2023-09-07 18:18:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:18:59 --> Config Class Initialized
INFO - 2023-09-07 18:18:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:59 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:59 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:59 --> URI Class Initialized
INFO - 2023-09-07 18:18:59 --> Router Class Initialized
INFO - 2023-09-07 18:18:59 --> Output Class Initialized
INFO - 2023-09-07 18:18:59 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:59 --> Input Class Initialized
INFO - 2023-09-07 18:18:59 --> Language Class Initialized
ERROR - 2023-09-07 18:18:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:18:59 --> Config Class Initialized
INFO - 2023-09-07 18:18:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:59 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:59 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:59 --> URI Class Initialized
INFO - 2023-09-07 18:18:59 --> Router Class Initialized
INFO - 2023-09-07 18:18:59 --> Output Class Initialized
INFO - 2023-09-07 18:18:59 --> Security Class Initialized
DEBUG - 2023-09-07 18:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:18:59 --> Input Class Initialized
INFO - 2023-09-07 18:18:59 --> Language Class Initialized
ERROR - 2023-09-07 18:18:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:18:59 --> Config Class Initialized
INFO - 2023-09-07 18:18:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:18:59 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:18:59 --> Utf8 Class Initialized
INFO - 2023-09-07 18:18:59 --> URI Class Initialized
INFO - 2023-09-07 18:18:59 --> Router Class Initialized
INFO - 2023-09-07 18:18:59 --> Output Class Initialized
INFO - 2023-09-07 18:18:59 --> Security Class Initialized
DEBUG - 2023-09-07 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:19:00 --> Input Class Initialized
INFO - 2023-09-07 18:19:00 --> Language Class Initialized
ERROR - 2023-09-07 18:19:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:19:00 --> Config Class Initialized
INFO - 2023-09-07 18:19:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:19:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:19:00 --> Utf8 Class Initialized
INFO - 2023-09-07 18:19:00 --> URI Class Initialized
INFO - 2023-09-07 18:19:00 --> Router Class Initialized
INFO - 2023-09-07 18:19:00 --> Output Class Initialized
INFO - 2023-09-07 18:19:00 --> Security Class Initialized
DEBUG - 2023-09-07 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:19:00 --> Input Class Initialized
INFO - 2023-09-07 18:19:00 --> Language Class Initialized
ERROR - 2023-09-07 18:19:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:19:00 --> Config Class Initialized
INFO - 2023-09-07 18:19:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:19:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:19:00 --> Utf8 Class Initialized
INFO - 2023-09-07 18:19:00 --> URI Class Initialized
INFO - 2023-09-07 18:19:00 --> Router Class Initialized
INFO - 2023-09-07 18:19:00 --> Output Class Initialized
INFO - 2023-09-07 18:19:00 --> Security Class Initialized
DEBUG - 2023-09-07 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:19:00 --> Input Class Initialized
INFO - 2023-09-07 18:19:00 --> Language Class Initialized
ERROR - 2023-09-07 18:19:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 18:23:58 --> Config Class Initialized
INFO - 2023-09-07 18:23:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:23:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:23:58 --> Utf8 Class Initialized
INFO - 2023-09-07 18:23:58 --> URI Class Initialized
DEBUG - 2023-09-07 18:23:58 --> No URI present. Default controller set.
INFO - 2023-09-07 18:23:58 --> Router Class Initialized
INFO - 2023-09-07 18:23:58 --> Output Class Initialized
INFO - 2023-09-07 18:23:58 --> Security Class Initialized
DEBUG - 2023-09-07 18:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:23:58 --> Input Class Initialized
INFO - 2023-09-07 18:23:58 --> Language Class Initialized
INFO - 2023-09-07 18:23:58 --> Loader Class Initialized
INFO - 2023-09-07 18:23:58 --> Helper loaded: url_helper
INFO - 2023-09-07 18:23:58 --> Helper loaded: file_helper
INFO - 2023-09-07 18:23:58 --> Database Driver Class Initialized
INFO - 2023-09-07 18:23:58 --> Email Class Initialized
DEBUG - 2023-09-07 18:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:23:58 --> Controller Class Initialized
INFO - 2023-09-07 18:23:58 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:23:58 --> Model "Home_model" initialized
INFO - 2023-09-07 18:23:58 --> Helper loaded: download_helper
INFO - 2023-09-07 18:23:58 --> Helper loaded: form_helper
INFO - 2023-09-07 18:23:58 --> Form Validation Class Initialized
INFO - 2023-09-07 18:23:58 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:23:58 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:23:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:23:58 --> Final output sent to browser
DEBUG - 2023-09-07 18:23:58 --> Total execution time: 0.0530
INFO - 2023-09-07 18:23:58 --> Config Class Initialized
INFO - 2023-09-07 18:23:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:23:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:23:58 --> Utf8 Class Initialized
INFO - 2023-09-07 18:23:58 --> URI Class Initialized
INFO - 2023-09-07 18:23:58 --> Router Class Initialized
INFO - 2023-09-07 18:23:58 --> Output Class Initialized
INFO - 2023-09-07 18:23:58 --> Security Class Initialized
DEBUG - 2023-09-07 18:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:23:58 --> Input Class Initialized
INFO - 2023-09-07 18:23:58 --> Language Class Initialized
ERROR - 2023-09-07 18:23:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:46 --> Config Class Initialized
INFO - 2023-09-07 18:35:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:46 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:46 --> URI Class Initialized
DEBUG - 2023-09-07 18:35:46 --> No URI present. Default controller set.
INFO - 2023-09-07 18:35:46 --> Router Class Initialized
INFO - 2023-09-07 18:35:46 --> Output Class Initialized
INFO - 2023-09-07 18:35:46 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:46 --> Input Class Initialized
INFO - 2023-09-07 18:35:46 --> Language Class Initialized
INFO - 2023-09-07 18:35:46 --> Loader Class Initialized
INFO - 2023-09-07 18:35:46 --> Helper loaded: url_helper
INFO - 2023-09-07 18:35:46 --> Helper loaded: file_helper
INFO - 2023-09-07 18:35:46 --> Database Driver Class Initialized
INFO - 2023-09-07 18:35:46 --> Email Class Initialized
DEBUG - 2023-09-07 18:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:35:46 --> Controller Class Initialized
INFO - 2023-09-07 18:35:46 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:35:46 --> Model "Home_model" initialized
INFO - 2023-09-07 18:35:46 --> Helper loaded: download_helper
INFO - 2023-09-07 18:35:46 --> Helper loaded: form_helper
INFO - 2023-09-07 18:35:46 --> Form Validation Class Initialized
INFO - 2023-09-07 18:35:46 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:35:46 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:35:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:35:46 --> Final output sent to browser
DEBUG - 2023-09-07 18:35:46 --> Total execution time: 0.0459
INFO - 2023-09-07 18:35:47 --> Config Class Initialized
INFO - 2023-09-07 18:35:47 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:47 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:47 --> URI Class Initialized
INFO - 2023-09-07 18:35:47 --> Router Class Initialized
INFO - 2023-09-07 18:35:47 --> Output Class Initialized
INFO - 2023-09-07 18:35:47 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:47 --> Input Class Initialized
INFO - 2023-09-07 18:35:47 --> Language Class Initialized
ERROR - 2023-09-07 18:35:47 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:51 --> Config Class Initialized
INFO - 2023-09-07 18:35:51 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:51 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:51 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:51 --> URI Class Initialized
INFO - 2023-09-07 18:35:51 --> Router Class Initialized
INFO - 2023-09-07 18:35:51 --> Output Class Initialized
INFO - 2023-09-07 18:35:51 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:51 --> Input Class Initialized
INFO - 2023-09-07 18:35:51 --> Language Class Initialized
INFO - 2023-09-07 18:35:51 --> Loader Class Initialized
INFO - 2023-09-07 18:35:51 --> Helper loaded: url_helper
INFO - 2023-09-07 18:35:51 --> Helper loaded: file_helper
INFO - 2023-09-07 18:35:51 --> Database Driver Class Initialized
INFO - 2023-09-07 18:35:51 --> Email Class Initialized
DEBUG - 2023-09-07 18:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:35:51 --> Controller Class Initialized
INFO - 2023-09-07 18:35:51 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:35:51 --> Model "Home_model" initialized
INFO - 2023-09-07 18:35:51 --> Helper loaded: download_helper
INFO - 2023-09-07 18:35:51 --> Helper loaded: form_helper
INFO - 2023-09-07 18:35:51 --> Form Validation Class Initialized
INFO - 2023-09-07 18:35:51 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:35:51 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:35:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-07 18:35:51 --> Final output sent to browser
DEBUG - 2023-09-07 18:35:51 --> Total execution time: 0.1634
INFO - 2023-09-07 18:35:52 --> Config Class Initialized
INFO - 2023-09-07 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:52 --> URI Class Initialized
INFO - 2023-09-07 18:35:52 --> Router Class Initialized
INFO - 2023-09-07 18:35:52 --> Output Class Initialized
INFO - 2023-09-07 18:35:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:52 --> Input Class Initialized
INFO - 2023-09-07 18:35:52 --> Language Class Initialized
ERROR - 2023-09-07 18:35:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:52 --> Config Class Initialized
INFO - 2023-09-07 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:52 --> URI Class Initialized
INFO - 2023-09-07 18:35:52 --> Router Class Initialized
INFO - 2023-09-07 18:35:52 --> Output Class Initialized
INFO - 2023-09-07 18:35:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:52 --> Input Class Initialized
INFO - 2023-09-07 18:35:52 --> Language Class Initialized
ERROR - 2023-09-07 18:35:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:52 --> Config Class Initialized
INFO - 2023-09-07 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:52 --> URI Class Initialized
INFO - 2023-09-07 18:35:52 --> Router Class Initialized
INFO - 2023-09-07 18:35:52 --> Output Class Initialized
INFO - 2023-09-07 18:35:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:52 --> Input Class Initialized
INFO - 2023-09-07 18:35:52 --> Language Class Initialized
ERROR - 2023-09-07 18:35:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:52 --> Config Class Initialized
INFO - 2023-09-07 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:52 --> URI Class Initialized
INFO - 2023-09-07 18:35:52 --> Router Class Initialized
INFO - 2023-09-07 18:35:52 --> Output Class Initialized
INFO - 2023-09-07 18:35:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:52 --> Input Class Initialized
INFO - 2023-09-07 18:35:52 --> Language Class Initialized
ERROR - 2023-09-07 18:35:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:35:52 --> Config Class Initialized
INFO - 2023-09-07 18:35:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:52 --> URI Class Initialized
INFO - 2023-09-07 18:35:52 --> Router Class Initialized
INFO - 2023-09-07 18:35:52 --> Output Class Initialized
INFO - 2023-09-07 18:35:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:52 --> Input Class Initialized
INFO - 2023-09-07 18:35:52 --> Language Class Initialized
ERROR - 2023-09-07 18:35:52 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-07 18:35:57 --> Config Class Initialized
INFO - 2023-09-07 18:35:57 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:57 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:57 --> URI Class Initialized
DEBUG - 2023-09-07 18:35:57 --> No URI present. Default controller set.
INFO - 2023-09-07 18:35:57 --> Router Class Initialized
INFO - 2023-09-07 18:35:57 --> Output Class Initialized
INFO - 2023-09-07 18:35:57 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:57 --> Input Class Initialized
INFO - 2023-09-07 18:35:57 --> Language Class Initialized
INFO - 2023-09-07 18:35:57 --> Loader Class Initialized
INFO - 2023-09-07 18:35:57 --> Helper loaded: url_helper
INFO - 2023-09-07 18:35:57 --> Helper loaded: file_helper
INFO - 2023-09-07 18:35:57 --> Database Driver Class Initialized
INFO - 2023-09-07 18:35:57 --> Email Class Initialized
DEBUG - 2023-09-07 18:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:35:57 --> Controller Class Initialized
INFO - 2023-09-07 18:35:57 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:35:57 --> Model "Home_model" initialized
INFO - 2023-09-07 18:35:57 --> Helper loaded: download_helper
INFO - 2023-09-07 18:35:57 --> Helper loaded: form_helper
INFO - 2023-09-07 18:35:57 --> Form Validation Class Initialized
INFO - 2023-09-07 18:35:57 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:35:57 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:35:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:35:57 --> Final output sent to browser
DEBUG - 2023-09-07 18:35:57 --> Total execution time: 0.0659
INFO - 2023-09-07 18:35:57 --> Config Class Initialized
INFO - 2023-09-07 18:35:57 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:35:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:35:57 --> Utf8 Class Initialized
INFO - 2023-09-07 18:35:57 --> URI Class Initialized
INFO - 2023-09-07 18:35:57 --> Router Class Initialized
INFO - 2023-09-07 18:35:57 --> Output Class Initialized
INFO - 2023-09-07 18:35:57 --> Security Class Initialized
DEBUG - 2023-09-07 18:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:35:57 --> Input Class Initialized
INFO - 2023-09-07 18:35:57 --> Language Class Initialized
ERROR - 2023-09-07 18:35:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:36:08 --> Config Class Initialized
INFO - 2023-09-07 18:36:08 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:08 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:08 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:08 --> URI Class Initialized
INFO - 2023-09-07 18:36:08 --> Router Class Initialized
INFO - 2023-09-07 18:36:08 --> Output Class Initialized
INFO - 2023-09-07 18:36:08 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:08 --> Input Class Initialized
INFO - 2023-09-07 18:36:08 --> Language Class Initialized
INFO - 2023-09-07 18:36:08 --> Loader Class Initialized
INFO - 2023-09-07 18:36:08 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:08 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:08 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:08 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:08 --> Controller Class Initialized
INFO - 2023-09-07 18:36:08 --> Config Class Initialized
INFO - 2023-09-07 18:36:08 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:08 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:08 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:08 --> URI Class Initialized
INFO - 2023-09-07 18:36:08 --> Router Class Initialized
INFO - 2023-09-07 18:36:08 --> Output Class Initialized
INFO - 2023-09-07 18:36:08 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:08 --> Input Class Initialized
INFO - 2023-09-07 18:36:08 --> Language Class Initialized
INFO - 2023-09-07 18:36:08 --> Loader Class Initialized
INFO - 2023-09-07 18:36:08 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:08 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:08 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:08 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:08 --> Controller Class Initialized
INFO - 2023-09-07 18:36:08 --> Model "User_model" initialized
INFO - 2023-09-07 18:36:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-07 18:36:08 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:08 --> Total execution time: 0.0310
INFO - 2023-09-07 18:36:09 --> Config Class Initialized
INFO - 2023-09-07 18:36:09 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:09 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:09 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:09 --> URI Class Initialized
INFO - 2023-09-07 18:36:09 --> Router Class Initialized
INFO - 2023-09-07 18:36:09 --> Output Class Initialized
INFO - 2023-09-07 18:36:09 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:09 --> Input Class Initialized
INFO - 2023-09-07 18:36:09 --> Language Class Initialized
ERROR - 2023-09-07 18:36:09 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-07 18:36:16 --> Config Class Initialized
INFO - 2023-09-07 18:36:16 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:16 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:16 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:16 --> URI Class Initialized
INFO - 2023-09-07 18:36:16 --> Router Class Initialized
INFO - 2023-09-07 18:36:16 --> Output Class Initialized
INFO - 2023-09-07 18:36:16 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:16 --> Input Class Initialized
INFO - 2023-09-07 18:36:16 --> Language Class Initialized
INFO - 2023-09-07 18:36:16 --> Loader Class Initialized
INFO - 2023-09-07 18:36:16 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:16 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:16 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:16 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:16 --> Controller Class Initialized
INFO - 2023-09-07 18:36:16 --> Model "User_model" initialized
INFO - 2023-09-07 18:36:16 --> Config Class Initialized
INFO - 2023-09-07 18:36:16 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:16 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:16 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:16 --> URI Class Initialized
INFO - 2023-09-07 18:36:16 --> Router Class Initialized
INFO - 2023-09-07 18:36:16 --> Output Class Initialized
INFO - 2023-09-07 18:36:16 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:16 --> Input Class Initialized
INFO - 2023-09-07 18:36:16 --> Language Class Initialized
INFO - 2023-09-07 18:36:16 --> Loader Class Initialized
INFO - 2023-09-07 18:36:16 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:16 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:16 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:16 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:16 --> Controller Class Initialized
INFO - 2023-09-07 18:36:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-07 18:36:16 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:16 --> Total execution time: 0.0375
INFO - 2023-09-07 18:36:20 --> Config Class Initialized
INFO - 2023-09-07 18:36:20 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:20 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:20 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:20 --> URI Class Initialized
INFO - 2023-09-07 18:36:20 --> Router Class Initialized
INFO - 2023-09-07 18:36:20 --> Output Class Initialized
INFO - 2023-09-07 18:36:20 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:20 --> Input Class Initialized
INFO - 2023-09-07 18:36:20 --> Language Class Initialized
INFO - 2023-09-07 18:36:21 --> Loader Class Initialized
INFO - 2023-09-07 18:36:21 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:21 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:21 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:21 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:21 --> Controller Class Initialized
INFO - 2023-09-07 18:36:21 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:21 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:21 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:21 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-09-07 18:36:21 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:21 --> Total execution time: 0.0508
INFO - 2023-09-07 18:36:42 --> Config Class Initialized
INFO - 2023-09-07 18:36:42 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:42 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:42 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:42 --> URI Class Initialized
INFO - 2023-09-07 18:36:42 --> Router Class Initialized
INFO - 2023-09-07 18:36:42 --> Output Class Initialized
INFO - 2023-09-07 18:36:42 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:42 --> Input Class Initialized
INFO - 2023-09-07 18:36:42 --> Language Class Initialized
INFO - 2023-09-07 18:36:42 --> Loader Class Initialized
INFO - 2023-09-07 18:36:42 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:42 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:42 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:42 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:42 --> Controller Class Initialized
INFO - 2023-09-07 18:36:42 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:42 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:42 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:42 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:42 --> Total execution time: 0.1069
INFO - 2023-09-07 18:36:42 --> Config Class Initialized
INFO - 2023-09-07 18:36:42 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:42 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:42 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:42 --> URI Class Initialized
INFO - 2023-09-07 18:36:42 --> Router Class Initialized
INFO - 2023-09-07 18:36:42 --> Output Class Initialized
INFO - 2023-09-07 18:36:42 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:42 --> Input Class Initialized
INFO - 2023-09-07 18:36:42 --> Language Class Initialized
INFO - 2023-09-07 18:36:42 --> Loader Class Initialized
INFO - 2023-09-07 18:36:42 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:42 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:42 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:42 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:42 --> Controller Class Initialized
INFO - 2023-09-07 18:36:42 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:43 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:43 --> Form Validation Class Initialized
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-09-07 18:36:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-09-07 18:36:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:43 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:43 --> Total execution time: 0.0627
INFO - 2023-09-07 18:36:46 --> Config Class Initialized
INFO - 2023-09-07 18:36:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:46 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:46 --> URI Class Initialized
INFO - 2023-09-07 18:36:46 --> Router Class Initialized
INFO - 2023-09-07 18:36:46 --> Output Class Initialized
INFO - 2023-09-07 18:36:46 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:46 --> Input Class Initialized
INFO - 2023-09-07 18:36:46 --> Language Class Initialized
INFO - 2023-09-07 18:36:46 --> Loader Class Initialized
INFO - 2023-09-07 18:36:46 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:46 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:46 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:46 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:46 --> Controller Class Initialized
INFO - 2023-09-07 18:36:46 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:46 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:46 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-07 18:36:46 --> Config Class Initialized
INFO - 2023-09-07 18:36:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:46 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:46 --> URI Class Initialized
INFO - 2023-09-07 18:36:46 --> Router Class Initialized
INFO - 2023-09-07 18:36:46 --> Output Class Initialized
INFO - 2023-09-07 18:36:46 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:46 --> Input Class Initialized
INFO - 2023-09-07 18:36:46 --> Language Class Initialized
INFO - 2023-09-07 18:36:46 --> Loader Class Initialized
INFO - 2023-09-07 18:36:46 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:46 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:46 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:46 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:46 --> Controller Class Initialized
INFO - 2023-09-07 18:36:46 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:46 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:46 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-09-07 18:36:46 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:46 --> Total execution time: 0.0586
INFO - 2023-09-07 18:36:48 --> Config Class Initialized
INFO - 2023-09-07 18:36:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:48 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:48 --> URI Class Initialized
INFO - 2023-09-07 18:36:48 --> Router Class Initialized
INFO - 2023-09-07 18:36:48 --> Output Class Initialized
INFO - 2023-09-07 18:36:48 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:48 --> Input Class Initialized
INFO - 2023-09-07 18:36:48 --> Language Class Initialized
INFO - 2023-09-07 18:36:48 --> Loader Class Initialized
INFO - 2023-09-07 18:36:48 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:48 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:48 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:48 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:48 --> Controller Class Initialized
INFO - 2023-09-07 18:36:48 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:48 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:48 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:48 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:48 --> Total execution time: 0.0501
INFO - 2023-09-07 18:36:49 --> Config Class Initialized
INFO - 2023-09-07 18:36:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:49 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:49 --> URI Class Initialized
INFO - 2023-09-07 18:36:49 --> Router Class Initialized
INFO - 2023-09-07 18:36:49 --> Output Class Initialized
INFO - 2023-09-07 18:36:49 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:49 --> Input Class Initialized
INFO - 2023-09-07 18:36:49 --> Language Class Initialized
INFO - 2023-09-07 18:36:49 --> Loader Class Initialized
INFO - 2023-09-07 18:36:49 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:49 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:49 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:49 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:49 --> Controller Class Initialized
INFO - 2023-09-07 18:36:49 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:49 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:49 --> Form Validation Class Initialized
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-09-07 18:36:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-09-07 18:36:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:49 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:49 --> Total execution time: 0.0699
INFO - 2023-09-07 18:36:52 --> Config Class Initialized
INFO - 2023-09-07 18:36:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:52 --> URI Class Initialized
INFO - 2023-09-07 18:36:52 --> Router Class Initialized
INFO - 2023-09-07 18:36:52 --> Output Class Initialized
INFO - 2023-09-07 18:36:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:52 --> Input Class Initialized
INFO - 2023-09-07 18:36:52 --> Language Class Initialized
INFO - 2023-09-07 18:36:52 --> Loader Class Initialized
INFO - 2023-09-07 18:36:52 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:52 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:52 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:52 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:52 --> Controller Class Initialized
INFO - 2023-09-07 18:36:52 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:52 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:52 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-07 18:36:52 --> Config Class Initialized
INFO - 2023-09-07 18:36:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:52 --> URI Class Initialized
INFO - 2023-09-07 18:36:52 --> Router Class Initialized
INFO - 2023-09-07 18:36:52 --> Output Class Initialized
INFO - 2023-09-07 18:36:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:52 --> Input Class Initialized
INFO - 2023-09-07 18:36:52 --> Language Class Initialized
INFO - 2023-09-07 18:36:52 --> Loader Class Initialized
INFO - 2023-09-07 18:36:52 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:52 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:52 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:52 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:52 --> Controller Class Initialized
INFO - 2023-09-07 18:36:52 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:52 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:52 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:52 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-09-07 18:36:52 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:52 --> Total execution time: 0.0536
INFO - 2023-09-07 18:36:54 --> Config Class Initialized
INFO - 2023-09-07 18:36:54 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:54 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:54 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:54 --> URI Class Initialized
INFO - 2023-09-07 18:36:54 --> Router Class Initialized
INFO - 2023-09-07 18:36:54 --> Output Class Initialized
INFO - 2023-09-07 18:36:54 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:54 --> Input Class Initialized
INFO - 2023-09-07 18:36:54 --> Language Class Initialized
INFO - 2023-09-07 18:36:54 --> Loader Class Initialized
INFO - 2023-09-07 18:36:54 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:54 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:54 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:54 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:54 --> Controller Class Initialized
INFO - 2023-09-07 18:36:54 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:54 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:54 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:54 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:54 --> Total execution time: 0.0665
INFO - 2023-09-07 18:36:55 --> Config Class Initialized
INFO - 2023-09-07 18:36:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:55 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:55 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:55 --> URI Class Initialized
INFO - 2023-09-07 18:36:55 --> Router Class Initialized
INFO - 2023-09-07 18:36:55 --> Output Class Initialized
INFO - 2023-09-07 18:36:55 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:55 --> Input Class Initialized
INFO - 2023-09-07 18:36:55 --> Language Class Initialized
INFO - 2023-09-07 18:36:55 --> Loader Class Initialized
INFO - 2023-09-07 18:36:55 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:55 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:55 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:55 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:55 --> Controller Class Initialized
INFO - 2023-09-07 18:36:55 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:55 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:55 --> Form Validation Class Initialized
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-09-07 18:36:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-09-07 18:36:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-09-07 18:36:55 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:55 --> Total execution time: 0.0497
INFO - 2023-09-07 18:36:58 --> Config Class Initialized
INFO - 2023-09-07 18:36:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:58 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:58 --> URI Class Initialized
INFO - 2023-09-07 18:36:58 --> Router Class Initialized
INFO - 2023-09-07 18:36:58 --> Output Class Initialized
INFO - 2023-09-07 18:36:58 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:58 --> Input Class Initialized
INFO - 2023-09-07 18:36:58 --> Language Class Initialized
INFO - 2023-09-07 18:36:58 --> Loader Class Initialized
INFO - 2023-09-07 18:36:58 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:58 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:58 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:58 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:58 --> Controller Class Initialized
INFO - 2023-09-07 18:36:58 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:58 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:58 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-07 18:36:58 --> Config Class Initialized
INFO - 2023-09-07 18:36:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:36:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:36:58 --> Utf8 Class Initialized
INFO - 2023-09-07 18:36:58 --> URI Class Initialized
INFO - 2023-09-07 18:36:58 --> Router Class Initialized
INFO - 2023-09-07 18:36:58 --> Output Class Initialized
INFO - 2023-09-07 18:36:58 --> Security Class Initialized
DEBUG - 2023-09-07 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:36:58 --> Input Class Initialized
INFO - 2023-09-07 18:36:58 --> Language Class Initialized
INFO - 2023-09-07 18:36:58 --> Loader Class Initialized
INFO - 2023-09-07 18:36:58 --> Helper loaded: url_helper
INFO - 2023-09-07 18:36:58 --> Helper loaded: file_helper
INFO - 2023-09-07 18:36:58 --> Database Driver Class Initialized
INFO - 2023-09-07 18:36:58 --> Email Class Initialized
DEBUG - 2023-09-07 18:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:36:58 --> Controller Class Initialized
INFO - 2023-09-07 18:36:58 --> Model "Banner_model" initialized
INFO - 2023-09-07 18:36:58 --> Helper loaded: form_helper
INFO - 2023-09-07 18:36:58 --> Form Validation Class Initialized
INFO - 2023-09-07 18:36:58 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-09-07 18:36:58 --> Final output sent to browser
DEBUG - 2023-09-07 18:36:58 --> Total execution time: 0.0496
INFO - 2023-09-07 18:37:48 --> Config Class Initialized
INFO - 2023-09-07 18:37:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:37:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:37:48 --> Utf8 Class Initialized
INFO - 2023-09-07 18:37:48 --> URI Class Initialized
DEBUG - 2023-09-07 18:37:48 --> No URI present. Default controller set.
INFO - 2023-09-07 18:37:48 --> Router Class Initialized
INFO - 2023-09-07 18:37:48 --> Output Class Initialized
INFO - 2023-09-07 18:37:48 --> Security Class Initialized
DEBUG - 2023-09-07 18:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:37:48 --> Input Class Initialized
INFO - 2023-09-07 18:37:48 --> Language Class Initialized
INFO - 2023-09-07 18:37:48 --> Loader Class Initialized
INFO - 2023-09-07 18:37:48 --> Helper loaded: url_helper
INFO - 2023-09-07 18:37:48 --> Helper loaded: file_helper
INFO - 2023-09-07 18:37:48 --> Database Driver Class Initialized
INFO - 2023-09-07 18:37:48 --> Email Class Initialized
DEBUG - 2023-09-07 18:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:37:48 --> Controller Class Initialized
INFO - 2023-09-07 18:37:48 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:37:48 --> Model "Home_model" initialized
INFO - 2023-09-07 18:37:48 --> Helper loaded: download_helper
INFO - 2023-09-07 18:37:48 --> Helper loaded: form_helper
INFO - 2023-09-07 18:37:48 --> Form Validation Class Initialized
INFO - 2023-09-07 18:37:48 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:37:48 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:37:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:37:48 --> Final output sent to browser
DEBUG - 2023-09-07 18:37:48 --> Total execution time: 0.2157
INFO - 2023-09-07 18:37:49 --> Config Class Initialized
INFO - 2023-09-07 18:37:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:37:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:37:49 --> Utf8 Class Initialized
INFO - 2023-09-07 18:37:49 --> URI Class Initialized
INFO - 2023-09-07 18:37:49 --> Router Class Initialized
INFO - 2023-09-07 18:37:49 --> Output Class Initialized
INFO - 2023-09-07 18:37:49 --> Security Class Initialized
DEBUG - 2023-09-07 18:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:37:49 --> Input Class Initialized
INFO - 2023-09-07 18:37:49 --> Language Class Initialized
ERROR - 2023-09-07 18:37:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:37:52 --> Config Class Initialized
INFO - 2023-09-07 18:37:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:37:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:37:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:37:52 --> URI Class Initialized
INFO - 2023-09-07 18:37:52 --> Router Class Initialized
INFO - 2023-09-07 18:37:52 --> Output Class Initialized
INFO - 2023-09-07 18:37:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:37:52 --> Input Class Initialized
INFO - 2023-09-07 18:37:52 --> Language Class Initialized
INFO - 2023-09-07 18:37:52 --> Loader Class Initialized
INFO - 2023-09-07 18:37:52 --> Helper loaded: url_helper
INFO - 2023-09-07 18:37:52 --> Helper loaded: file_helper
INFO - 2023-09-07 18:37:52 --> Database Driver Class Initialized
INFO - 2023-09-07 18:37:52 --> Email Class Initialized
DEBUG - 2023-09-07 18:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:37:52 --> Controller Class Initialized
INFO - 2023-09-07 18:37:52 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:37:52 --> Model "Home_model" initialized
INFO - 2023-09-07 18:37:52 --> Helper loaded: download_helper
INFO - 2023-09-07 18:37:52 --> Helper loaded: form_helper
INFO - 2023-09-07 18:37:52 --> Form Validation Class Initialized
INFO - 2023-09-07 18:37:52 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:37:52 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:37:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 18:37:52 --> Final output sent to browser
DEBUG - 2023-09-07 18:37:52 --> Total execution time: 0.0846
INFO - 2023-09-07 18:37:53 --> Config Class Initialized
INFO - 2023-09-07 18:37:53 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:37:53 --> Utf8 Class Initialized
INFO - 2023-09-07 18:37:53 --> URI Class Initialized
INFO - 2023-09-07 18:37:53 --> Router Class Initialized
INFO - 2023-09-07 18:37:53 --> Output Class Initialized
INFO - 2023-09-07 18:37:53 --> Security Class Initialized
DEBUG - 2023-09-07 18:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:37:53 --> Input Class Initialized
INFO - 2023-09-07 18:37:53 --> Language Class Initialized
ERROR - 2023-09-07 18:37:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:38:25 --> Config Class Initialized
INFO - 2023-09-07 18:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:38:25 --> Utf8 Class Initialized
INFO - 2023-09-07 18:38:25 --> URI Class Initialized
DEBUG - 2023-09-07 18:38:25 --> No URI present. Default controller set.
INFO - 2023-09-07 18:38:25 --> Router Class Initialized
INFO - 2023-09-07 18:38:25 --> Output Class Initialized
INFO - 2023-09-07 18:38:25 --> Security Class Initialized
DEBUG - 2023-09-07 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:38:25 --> Input Class Initialized
INFO - 2023-09-07 18:38:25 --> Language Class Initialized
INFO - 2023-09-07 18:38:25 --> Loader Class Initialized
INFO - 2023-09-07 18:38:25 --> Helper loaded: url_helper
INFO - 2023-09-07 18:38:25 --> Helper loaded: file_helper
INFO - 2023-09-07 18:38:25 --> Database Driver Class Initialized
INFO - 2023-09-07 18:38:25 --> Email Class Initialized
DEBUG - 2023-09-07 18:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:38:25 --> Controller Class Initialized
INFO - 2023-09-07 18:38:25 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:38:25 --> Model "Home_model" initialized
INFO - 2023-09-07 18:38:25 --> Helper loaded: download_helper
INFO - 2023-09-07 18:38:25 --> Helper loaded: form_helper
INFO - 2023-09-07 18:38:25 --> Form Validation Class Initialized
INFO - 2023-09-07 18:38:25 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:38:25 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:38:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:38:25 --> Final output sent to browser
DEBUG - 2023-09-07 18:38:25 --> Total execution time: 0.1564
INFO - 2023-09-07 18:40:45 --> Config Class Initialized
INFO - 2023-09-07 18:40:45 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:40:45 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:40:45 --> Utf8 Class Initialized
INFO - 2023-09-07 18:40:45 --> URI Class Initialized
DEBUG - 2023-09-07 18:40:45 --> No URI present. Default controller set.
INFO - 2023-09-07 18:40:45 --> Router Class Initialized
INFO - 2023-09-07 18:40:45 --> Output Class Initialized
INFO - 2023-09-07 18:40:45 --> Security Class Initialized
DEBUG - 2023-09-07 18:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:40:45 --> Input Class Initialized
INFO - 2023-09-07 18:40:45 --> Language Class Initialized
INFO - 2023-09-07 18:40:45 --> Loader Class Initialized
INFO - 2023-09-07 18:40:45 --> Helper loaded: url_helper
INFO - 2023-09-07 18:40:45 --> Helper loaded: file_helper
INFO - 2023-09-07 18:40:45 --> Database Driver Class Initialized
INFO - 2023-09-07 18:40:45 --> Email Class Initialized
DEBUG - 2023-09-07 18:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:40:45 --> Controller Class Initialized
INFO - 2023-09-07 18:40:45 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:40:45 --> Model "Home_model" initialized
INFO - 2023-09-07 18:40:45 --> Helper loaded: download_helper
INFO - 2023-09-07 18:40:45 --> Helper loaded: form_helper
INFO - 2023-09-07 18:40:45 --> Form Validation Class Initialized
INFO - 2023-09-07 18:40:45 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:40:45 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:40:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:40:45 --> Final output sent to browser
DEBUG - 2023-09-07 18:40:45 --> Total execution time: 0.2129
INFO - 2023-09-07 18:40:45 --> Config Class Initialized
INFO - 2023-09-07 18:40:45 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:40:45 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:40:45 --> Utf8 Class Initialized
INFO - 2023-09-07 18:40:45 --> URI Class Initialized
INFO - 2023-09-07 18:40:45 --> Router Class Initialized
INFO - 2023-09-07 18:40:45 --> Output Class Initialized
INFO - 2023-09-07 18:40:45 --> Security Class Initialized
DEBUG - 2023-09-07 18:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:40:45 --> Input Class Initialized
INFO - 2023-09-07 18:40:45 --> Language Class Initialized
ERROR - 2023-09-07 18:40:45 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:42:46 --> Config Class Initialized
INFO - 2023-09-07 18:42:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:42:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:42:46 --> Utf8 Class Initialized
INFO - 2023-09-07 18:42:46 --> URI Class Initialized
DEBUG - 2023-09-07 18:42:46 --> No URI present. Default controller set.
INFO - 2023-09-07 18:42:46 --> Router Class Initialized
INFO - 2023-09-07 18:42:46 --> Output Class Initialized
INFO - 2023-09-07 18:42:46 --> Security Class Initialized
DEBUG - 2023-09-07 18:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:42:46 --> Input Class Initialized
INFO - 2023-09-07 18:42:46 --> Language Class Initialized
INFO - 2023-09-07 18:42:46 --> Loader Class Initialized
INFO - 2023-09-07 18:42:46 --> Helper loaded: url_helper
INFO - 2023-09-07 18:42:46 --> Helper loaded: file_helper
INFO - 2023-09-07 18:42:46 --> Database Driver Class Initialized
INFO - 2023-09-07 18:42:46 --> Email Class Initialized
DEBUG - 2023-09-07 18:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:42:46 --> Controller Class Initialized
INFO - 2023-09-07 18:42:46 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:42:46 --> Model "Home_model" initialized
INFO - 2023-09-07 18:42:46 --> Helper loaded: download_helper
INFO - 2023-09-07 18:42:46 --> Helper loaded: form_helper
INFO - 2023-09-07 18:42:46 --> Form Validation Class Initialized
INFO - 2023-09-07 18:42:46 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:42:46 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:42:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:42:46 --> Final output sent to browser
DEBUG - 2023-09-07 18:42:47 --> Total execution time: 0.5449
INFO - 2023-09-07 18:42:47 --> Config Class Initialized
INFO - 2023-09-07 18:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:42:47 --> Utf8 Class Initialized
INFO - 2023-09-07 18:42:47 --> URI Class Initialized
INFO - 2023-09-07 18:42:47 --> Router Class Initialized
INFO - 2023-09-07 18:42:47 --> Output Class Initialized
INFO - 2023-09-07 18:42:47 --> Security Class Initialized
DEBUG - 2023-09-07 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:42:47 --> Input Class Initialized
INFO - 2023-09-07 18:42:47 --> Language Class Initialized
ERROR - 2023-09-07 18:42:47 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:47:29 --> Config Class Initialized
INFO - 2023-09-07 18:47:29 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:47:29 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:47:29 --> Utf8 Class Initialized
INFO - 2023-09-07 18:47:29 --> URI Class Initialized
DEBUG - 2023-09-07 18:47:29 --> No URI present. Default controller set.
INFO - 2023-09-07 18:47:29 --> Router Class Initialized
INFO - 2023-09-07 18:47:29 --> Output Class Initialized
INFO - 2023-09-07 18:47:29 --> Security Class Initialized
DEBUG - 2023-09-07 18:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:47:29 --> Input Class Initialized
INFO - 2023-09-07 18:47:29 --> Language Class Initialized
INFO - 2023-09-07 18:47:29 --> Loader Class Initialized
INFO - 2023-09-07 18:47:29 --> Helper loaded: url_helper
INFO - 2023-09-07 18:47:29 --> Helper loaded: file_helper
INFO - 2023-09-07 18:47:29 --> Database Driver Class Initialized
INFO - 2023-09-07 18:47:29 --> Email Class Initialized
DEBUG - 2023-09-07 18:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:47:29 --> Controller Class Initialized
INFO - 2023-09-07 18:47:29 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:47:29 --> Model "Home_model" initialized
INFO - 2023-09-07 18:47:29 --> Helper loaded: download_helper
INFO - 2023-09-07 18:47:29 --> Helper loaded: form_helper
INFO - 2023-09-07 18:47:29 --> Form Validation Class Initialized
INFO - 2023-09-07 18:47:29 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:47:29 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:47:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:47:29 --> Final output sent to browser
DEBUG - 2023-09-07 18:47:29 --> Total execution time: 0.1523
INFO - 2023-09-07 18:47:29 --> Config Class Initialized
INFO - 2023-09-07 18:47:29 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:47:29 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:47:29 --> Utf8 Class Initialized
INFO - 2023-09-07 18:47:29 --> URI Class Initialized
INFO - 2023-09-07 18:47:29 --> Router Class Initialized
INFO - 2023-09-07 18:47:29 --> Output Class Initialized
INFO - 2023-09-07 18:47:29 --> Security Class Initialized
DEBUG - 2023-09-07 18:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:47:29 --> Input Class Initialized
INFO - 2023-09-07 18:47:29 --> Language Class Initialized
ERROR - 2023-09-07 18:47:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:51:31 --> Config Class Initialized
INFO - 2023-09-07 18:51:31 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:51:31 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:51:31 --> Utf8 Class Initialized
INFO - 2023-09-07 18:51:31 --> URI Class Initialized
DEBUG - 2023-09-07 18:51:31 --> No URI present. Default controller set.
INFO - 2023-09-07 18:51:31 --> Router Class Initialized
INFO - 2023-09-07 18:51:31 --> Output Class Initialized
INFO - 2023-09-07 18:51:31 --> Security Class Initialized
DEBUG - 2023-09-07 18:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:51:31 --> Input Class Initialized
INFO - 2023-09-07 18:51:31 --> Language Class Initialized
INFO - 2023-09-07 18:51:31 --> Loader Class Initialized
INFO - 2023-09-07 18:51:31 --> Helper loaded: url_helper
INFO - 2023-09-07 18:51:31 --> Helper loaded: file_helper
INFO - 2023-09-07 18:51:31 --> Database Driver Class Initialized
INFO - 2023-09-07 18:51:31 --> Email Class Initialized
DEBUG - 2023-09-07 18:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:51:31 --> Controller Class Initialized
INFO - 2023-09-07 18:51:31 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:51:31 --> Model "Home_model" initialized
INFO - 2023-09-07 18:51:31 --> Helper loaded: download_helper
INFO - 2023-09-07 18:51:31 --> Helper loaded: form_helper
INFO - 2023-09-07 18:51:31 --> Form Validation Class Initialized
INFO - 2023-09-07 18:51:31 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:51:31 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:51:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:51:31 --> Final output sent to browser
DEBUG - 2023-09-07 18:51:31 --> Total execution time: 0.2986
INFO - 2023-09-07 18:51:32 --> Config Class Initialized
INFO - 2023-09-07 18:51:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:51:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:51:32 --> Utf8 Class Initialized
INFO - 2023-09-07 18:51:32 --> URI Class Initialized
INFO - 2023-09-07 18:51:32 --> Router Class Initialized
INFO - 2023-09-07 18:51:32 --> Output Class Initialized
INFO - 2023-09-07 18:51:32 --> Security Class Initialized
DEBUG - 2023-09-07 18:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:51:32 --> Input Class Initialized
INFO - 2023-09-07 18:51:32 --> Language Class Initialized
ERROR - 2023-09-07 18:51:32 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:52:32 --> Config Class Initialized
INFO - 2023-09-07 18:52:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:52:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:52:32 --> Utf8 Class Initialized
INFO - 2023-09-07 18:52:32 --> URI Class Initialized
DEBUG - 2023-09-07 18:52:32 --> No URI present. Default controller set.
INFO - 2023-09-07 18:52:32 --> Router Class Initialized
INFO - 2023-09-07 18:52:32 --> Output Class Initialized
INFO - 2023-09-07 18:52:32 --> Security Class Initialized
DEBUG - 2023-09-07 18:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:52:32 --> Input Class Initialized
INFO - 2023-09-07 18:52:32 --> Language Class Initialized
INFO - 2023-09-07 18:52:32 --> Loader Class Initialized
INFO - 2023-09-07 18:52:32 --> Helper loaded: url_helper
INFO - 2023-09-07 18:52:32 --> Helper loaded: file_helper
INFO - 2023-09-07 18:52:32 --> Database Driver Class Initialized
INFO - 2023-09-07 18:52:32 --> Email Class Initialized
DEBUG - 2023-09-07 18:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:52:32 --> Controller Class Initialized
INFO - 2023-09-07 18:52:32 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:52:32 --> Model "Home_model" initialized
INFO - 2023-09-07 18:52:32 --> Helper loaded: download_helper
INFO - 2023-09-07 18:52:32 --> Helper loaded: form_helper
INFO - 2023-09-07 18:52:32 --> Form Validation Class Initialized
INFO - 2023-09-07 18:52:32 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:52:32 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:52:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:52:32 --> Final output sent to browser
DEBUG - 2023-09-07 18:52:32 --> Total execution time: 0.1816
INFO - 2023-09-07 18:52:32 --> Config Class Initialized
INFO - 2023-09-07 18:52:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:52:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:52:32 --> Utf8 Class Initialized
INFO - 2023-09-07 18:52:32 --> URI Class Initialized
INFO - 2023-09-07 18:52:32 --> Router Class Initialized
INFO - 2023-09-07 18:52:32 --> Output Class Initialized
INFO - 2023-09-07 18:52:32 --> Security Class Initialized
DEBUG - 2023-09-07 18:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:52:32 --> Input Class Initialized
INFO - 2023-09-07 18:52:32 --> Language Class Initialized
ERROR - 2023-09-07 18:52:32 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:53:27 --> Config Class Initialized
INFO - 2023-09-07 18:53:27 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:53:27 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:53:27 --> Utf8 Class Initialized
INFO - 2023-09-07 18:53:27 --> URI Class Initialized
DEBUG - 2023-09-07 18:53:27 --> No URI present. Default controller set.
INFO - 2023-09-07 18:53:27 --> Router Class Initialized
INFO - 2023-09-07 18:53:27 --> Output Class Initialized
INFO - 2023-09-07 18:53:27 --> Security Class Initialized
DEBUG - 2023-09-07 18:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:53:27 --> Input Class Initialized
INFO - 2023-09-07 18:53:27 --> Language Class Initialized
INFO - 2023-09-07 18:53:27 --> Loader Class Initialized
INFO - 2023-09-07 18:53:27 --> Helper loaded: url_helper
INFO - 2023-09-07 18:53:27 --> Helper loaded: file_helper
INFO - 2023-09-07 18:53:27 --> Database Driver Class Initialized
INFO - 2023-09-07 18:53:27 --> Email Class Initialized
DEBUG - 2023-09-07 18:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:53:27 --> Controller Class Initialized
INFO - 2023-09-07 18:53:27 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:53:27 --> Model "Home_model" initialized
INFO - 2023-09-07 18:53:27 --> Helper loaded: download_helper
INFO - 2023-09-07 18:53:27 --> Helper loaded: form_helper
INFO - 2023-09-07 18:53:27 --> Form Validation Class Initialized
INFO - 2023-09-07 18:53:27 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:53:27 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:53:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:53:27 --> Final output sent to browser
DEBUG - 2023-09-07 18:53:27 --> Total execution time: 0.0985
INFO - 2023-09-07 18:53:27 --> Config Class Initialized
INFO - 2023-09-07 18:53:27 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:53:27 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:53:27 --> Utf8 Class Initialized
INFO - 2023-09-07 18:53:27 --> URI Class Initialized
INFO - 2023-09-07 18:53:27 --> Router Class Initialized
INFO - 2023-09-07 18:53:27 --> Output Class Initialized
INFO - 2023-09-07 18:53:27 --> Security Class Initialized
DEBUG - 2023-09-07 18:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:53:27 --> Input Class Initialized
INFO - 2023-09-07 18:53:27 --> Language Class Initialized
ERROR - 2023-09-07 18:53:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:53:50 --> Config Class Initialized
INFO - 2023-09-07 18:53:50 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:53:50 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:53:50 --> Utf8 Class Initialized
INFO - 2023-09-07 18:53:50 --> URI Class Initialized
DEBUG - 2023-09-07 18:53:50 --> No URI present. Default controller set.
INFO - 2023-09-07 18:53:50 --> Router Class Initialized
INFO - 2023-09-07 18:53:50 --> Output Class Initialized
INFO - 2023-09-07 18:53:50 --> Security Class Initialized
DEBUG - 2023-09-07 18:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:53:50 --> Input Class Initialized
INFO - 2023-09-07 18:53:50 --> Language Class Initialized
INFO - 2023-09-07 18:53:50 --> Loader Class Initialized
INFO - 2023-09-07 18:53:50 --> Helper loaded: url_helper
INFO - 2023-09-07 18:53:50 --> Helper loaded: file_helper
INFO - 2023-09-07 18:53:50 --> Database Driver Class Initialized
INFO - 2023-09-07 18:53:50 --> Email Class Initialized
DEBUG - 2023-09-07 18:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:53:50 --> Controller Class Initialized
INFO - 2023-09-07 18:53:50 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:53:50 --> Model "Home_model" initialized
INFO - 2023-09-07 18:53:50 --> Helper loaded: download_helper
INFO - 2023-09-07 18:53:50 --> Helper loaded: form_helper
INFO - 2023-09-07 18:53:50 --> Form Validation Class Initialized
INFO - 2023-09-07 18:53:50 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:53:50 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:53:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:53:51 --> Final output sent to browser
DEBUG - 2023-09-07 18:53:51 --> Total execution time: 0.1804
INFO - 2023-09-07 18:53:52 --> Config Class Initialized
INFO - 2023-09-07 18:53:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:53:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:53:52 --> Utf8 Class Initialized
INFO - 2023-09-07 18:53:52 --> URI Class Initialized
INFO - 2023-09-07 18:53:52 --> Router Class Initialized
INFO - 2023-09-07 18:53:52 --> Output Class Initialized
INFO - 2023-09-07 18:53:52 --> Security Class Initialized
DEBUG - 2023-09-07 18:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:53:52 --> Input Class Initialized
INFO - 2023-09-07 18:53:52 --> Language Class Initialized
ERROR - 2023-09-07 18:53:52 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 18:55:13 --> Config Class Initialized
INFO - 2023-09-07 18:55:13 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:55:13 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:55:13 --> Utf8 Class Initialized
INFO - 2023-09-07 18:55:13 --> URI Class Initialized
DEBUG - 2023-09-07 18:55:13 --> No URI present. Default controller set.
INFO - 2023-09-07 18:55:13 --> Router Class Initialized
INFO - 2023-09-07 18:55:13 --> Output Class Initialized
INFO - 2023-09-07 18:55:13 --> Security Class Initialized
DEBUG - 2023-09-07 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:55:13 --> Input Class Initialized
INFO - 2023-09-07 18:55:13 --> Language Class Initialized
INFO - 2023-09-07 18:55:13 --> Loader Class Initialized
INFO - 2023-09-07 18:55:13 --> Helper loaded: url_helper
INFO - 2023-09-07 18:55:13 --> Helper loaded: file_helper
INFO - 2023-09-07 18:55:13 --> Database Driver Class Initialized
INFO - 2023-09-07 18:55:13 --> Email Class Initialized
DEBUG - 2023-09-07 18:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 18:55:13 --> Controller Class Initialized
INFO - 2023-09-07 18:55:13 --> Model "Contact_model" initialized
INFO - 2023-09-07 18:55:13 --> Model "Home_model" initialized
INFO - 2023-09-07 18:55:13 --> Helper loaded: download_helper
INFO - 2023-09-07 18:55:13 --> Helper loaded: form_helper
INFO - 2023-09-07 18:55:13 --> Form Validation Class Initialized
INFO - 2023-09-07 18:55:13 --> Helper loaded: custom_helper
INFO - 2023-09-07 18:55:13 --> Model "Social_media_model" initialized
INFO - 2023-09-07 18:55:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 18:55:13 --> Final output sent to browser
DEBUG - 2023-09-07 18:55:13 --> Total execution time: 0.1156
INFO - 2023-09-07 18:55:14 --> Config Class Initialized
INFO - 2023-09-07 18:55:15 --> Hooks Class Initialized
DEBUG - 2023-09-07 18:55:15 --> UTF-8 Support Enabled
INFO - 2023-09-07 18:55:15 --> Utf8 Class Initialized
INFO - 2023-09-07 18:55:15 --> URI Class Initialized
INFO - 2023-09-07 18:55:15 --> Router Class Initialized
INFO - 2023-09-07 18:55:15 --> Output Class Initialized
INFO - 2023-09-07 18:55:15 --> Security Class Initialized
DEBUG - 2023-09-07 18:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 18:55:15 --> Input Class Initialized
INFO - 2023-09-07 18:55:15 --> Language Class Initialized
ERROR - 2023-09-07 18:55:15 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:05:39 --> Config Class Initialized
INFO - 2023-09-07 19:05:39 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:05:40 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:05:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:05:40 --> URI Class Initialized
DEBUG - 2023-09-07 19:05:40 --> No URI present. Default controller set.
INFO - 2023-09-07 19:05:40 --> Router Class Initialized
INFO - 2023-09-07 19:05:40 --> Output Class Initialized
INFO - 2023-09-07 19:05:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:05:40 --> Input Class Initialized
INFO - 2023-09-07 19:05:40 --> Language Class Initialized
INFO - 2023-09-07 19:05:40 --> Loader Class Initialized
INFO - 2023-09-07 19:05:40 --> Helper loaded: url_helper
INFO - 2023-09-07 19:05:40 --> Helper loaded: file_helper
INFO - 2023-09-07 19:05:40 --> Database Driver Class Initialized
INFO - 2023-09-07 19:05:40 --> Email Class Initialized
DEBUG - 2023-09-07 19:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:05:40 --> Controller Class Initialized
INFO - 2023-09-07 19:05:40 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:05:40 --> Model "Home_model" initialized
INFO - 2023-09-07 19:05:40 --> Helper loaded: download_helper
INFO - 2023-09-07 19:05:40 --> Helper loaded: form_helper
INFO - 2023-09-07 19:05:40 --> Form Validation Class Initialized
INFO - 2023-09-07 19:05:40 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:05:40 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:05:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:05:40 --> Final output sent to browser
DEBUG - 2023-09-07 19:05:41 --> Total execution time: 0.8657
INFO - 2023-09-07 19:05:41 --> Config Class Initialized
INFO - 2023-09-07 19:05:41 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:05:41 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:05:41 --> Utf8 Class Initialized
INFO - 2023-09-07 19:05:41 --> URI Class Initialized
INFO - 2023-09-07 19:05:41 --> Router Class Initialized
INFO - 2023-09-07 19:05:41 --> Output Class Initialized
INFO - 2023-09-07 19:05:41 --> Security Class Initialized
DEBUG - 2023-09-07 19:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:05:41 --> Input Class Initialized
INFO - 2023-09-07 19:05:41 --> Language Class Initialized
ERROR - 2023-09-07 19:05:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:07:19 --> Config Class Initialized
INFO - 2023-09-07 19:07:19 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:07:19 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:07:19 --> Utf8 Class Initialized
INFO - 2023-09-07 19:07:19 --> URI Class Initialized
DEBUG - 2023-09-07 19:07:19 --> No URI present. Default controller set.
INFO - 2023-09-07 19:07:19 --> Router Class Initialized
INFO - 2023-09-07 19:07:19 --> Output Class Initialized
INFO - 2023-09-07 19:07:19 --> Security Class Initialized
DEBUG - 2023-09-07 19:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:07:19 --> Input Class Initialized
INFO - 2023-09-07 19:07:19 --> Language Class Initialized
INFO - 2023-09-07 19:07:19 --> Loader Class Initialized
INFO - 2023-09-07 19:07:19 --> Helper loaded: url_helper
INFO - 2023-09-07 19:07:19 --> Helper loaded: file_helper
INFO - 2023-09-07 19:07:20 --> Database Driver Class Initialized
INFO - 2023-09-07 19:07:20 --> Email Class Initialized
DEBUG - 2023-09-07 19:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:07:20 --> Controller Class Initialized
INFO - 2023-09-07 19:07:20 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:07:20 --> Model "Home_model" initialized
INFO - 2023-09-07 19:07:20 --> Helper loaded: download_helper
INFO - 2023-09-07 19:07:20 --> Helper loaded: form_helper
INFO - 2023-09-07 19:07:20 --> Form Validation Class Initialized
INFO - 2023-09-07 19:07:20 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:07:20 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:07:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:07:20 --> Final output sent to browser
DEBUG - 2023-09-07 19:07:20 --> Total execution time: 0.4664
INFO - 2023-09-07 19:07:21 --> Config Class Initialized
INFO - 2023-09-07 19:07:21 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:07:21 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:07:21 --> Utf8 Class Initialized
INFO - 2023-09-07 19:07:21 --> URI Class Initialized
INFO - 2023-09-07 19:07:21 --> Router Class Initialized
INFO - 2023-09-07 19:07:21 --> Output Class Initialized
INFO - 2023-09-07 19:07:21 --> Security Class Initialized
DEBUG - 2023-09-07 19:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:07:21 --> Input Class Initialized
INFO - 2023-09-07 19:07:21 --> Language Class Initialized
ERROR - 2023-09-07 19:07:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:08:07 --> Config Class Initialized
INFO - 2023-09-07 19:08:07 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:08:07 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:08:07 --> Utf8 Class Initialized
INFO - 2023-09-07 19:08:07 --> URI Class Initialized
DEBUG - 2023-09-07 19:08:07 --> No URI present. Default controller set.
INFO - 2023-09-07 19:08:07 --> Router Class Initialized
INFO - 2023-09-07 19:08:07 --> Output Class Initialized
INFO - 2023-09-07 19:08:07 --> Security Class Initialized
DEBUG - 2023-09-07 19:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:08:07 --> Input Class Initialized
INFO - 2023-09-07 19:08:07 --> Language Class Initialized
INFO - 2023-09-07 19:08:07 --> Loader Class Initialized
INFO - 2023-09-07 19:08:07 --> Helper loaded: url_helper
INFO - 2023-09-07 19:08:07 --> Helper loaded: file_helper
INFO - 2023-09-07 19:08:07 --> Database Driver Class Initialized
INFO - 2023-09-07 19:08:07 --> Email Class Initialized
DEBUG - 2023-09-07 19:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:08:07 --> Controller Class Initialized
INFO - 2023-09-07 19:08:07 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:08:07 --> Model "Home_model" initialized
INFO - 2023-09-07 19:08:07 --> Helper loaded: download_helper
INFO - 2023-09-07 19:08:07 --> Helper loaded: form_helper
INFO - 2023-09-07 19:08:07 --> Form Validation Class Initialized
INFO - 2023-09-07 19:08:07 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:08:07 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:08:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:08:07 --> Final output sent to browser
DEBUG - 2023-09-07 19:08:08 --> Total execution time: 0.4500
INFO - 2023-09-07 19:08:08 --> Config Class Initialized
INFO - 2023-09-07 19:08:09 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:08:09 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:08:09 --> Utf8 Class Initialized
INFO - 2023-09-07 19:08:09 --> URI Class Initialized
INFO - 2023-09-07 19:08:09 --> Router Class Initialized
INFO - 2023-09-07 19:08:09 --> Output Class Initialized
INFO - 2023-09-07 19:08:09 --> Security Class Initialized
DEBUG - 2023-09-07 19:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:08:09 --> Input Class Initialized
INFO - 2023-09-07 19:08:09 --> Language Class Initialized
ERROR - 2023-09-07 19:08:09 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:10:59 --> Config Class Initialized
INFO - 2023-09-07 19:10:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:10:59 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:10:59 --> Utf8 Class Initialized
INFO - 2023-09-07 19:10:59 --> URI Class Initialized
DEBUG - 2023-09-07 19:10:59 --> No URI present. Default controller set.
INFO - 2023-09-07 19:10:59 --> Router Class Initialized
INFO - 2023-09-07 19:10:59 --> Output Class Initialized
INFO - 2023-09-07 19:10:59 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:00 --> Input Class Initialized
INFO - 2023-09-07 19:11:00 --> Language Class Initialized
INFO - 2023-09-07 19:11:00 --> Loader Class Initialized
INFO - 2023-09-07 19:11:00 --> Helper loaded: url_helper
INFO - 2023-09-07 19:11:00 --> Helper loaded: file_helper
INFO - 2023-09-07 19:11:00 --> Database Driver Class Initialized
INFO - 2023-09-07 19:11:00 --> Email Class Initialized
DEBUG - 2023-09-07 19:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:11:00 --> Controller Class Initialized
INFO - 2023-09-07 19:11:00 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:11:00 --> Model "Home_model" initialized
INFO - 2023-09-07 19:11:00 --> Helper loaded: download_helper
INFO - 2023-09-07 19:11:00 --> Helper loaded: form_helper
INFO - 2023-09-07 19:11:00 --> Form Validation Class Initialized
INFO - 2023-09-07 19:11:00 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:11:00 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:11:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:11:00 --> Final output sent to browser
DEBUG - 2023-09-07 19:11:00 --> Total execution time: 0.5469
INFO - 2023-09-07 19:11:01 --> Config Class Initialized
INFO - 2023-09-07 19:11:01 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:01 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:01 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:01 --> URI Class Initialized
INFO - 2023-09-07 19:11:01 --> Router Class Initialized
INFO - 2023-09-07 19:11:01 --> Output Class Initialized
INFO - 2023-09-07 19:11:01 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:01 --> Input Class Initialized
INFO - 2023-09-07 19:11:01 --> Language Class Initialized
ERROR - 2023-09-07 19:11:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:11:20 --> Config Class Initialized
INFO - 2023-09-07 19:11:20 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:20 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:20 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:20 --> URI Class Initialized
DEBUG - 2023-09-07 19:11:20 --> No URI present. Default controller set.
INFO - 2023-09-07 19:11:20 --> Router Class Initialized
INFO - 2023-09-07 19:11:20 --> Output Class Initialized
INFO - 2023-09-07 19:11:20 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:20 --> Input Class Initialized
INFO - 2023-09-07 19:11:20 --> Language Class Initialized
INFO - 2023-09-07 19:11:20 --> Loader Class Initialized
INFO - 2023-09-07 19:11:20 --> Helper loaded: url_helper
INFO - 2023-09-07 19:11:20 --> Helper loaded: file_helper
INFO - 2023-09-07 19:11:20 --> Database Driver Class Initialized
INFO - 2023-09-07 19:11:20 --> Email Class Initialized
DEBUG - 2023-09-07 19:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:11:20 --> Controller Class Initialized
INFO - 2023-09-07 19:11:20 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:11:20 --> Model "Home_model" initialized
INFO - 2023-09-07 19:11:20 --> Helper loaded: download_helper
INFO - 2023-09-07 19:11:20 --> Helper loaded: form_helper
INFO - 2023-09-07 19:11:20 --> Form Validation Class Initialized
INFO - 2023-09-07 19:11:20 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:11:20 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:11:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:11:20 --> Final output sent to browser
DEBUG - 2023-09-07 19:11:20 --> Total execution time: 0.3934
INFO - 2023-09-07 19:11:22 --> Config Class Initialized
INFO - 2023-09-07 19:11:22 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:22 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:22 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:22 --> URI Class Initialized
INFO - 2023-09-07 19:11:22 --> Router Class Initialized
INFO - 2023-09-07 19:11:22 --> Output Class Initialized
INFO - 2023-09-07 19:11:22 --> Security Class Initialized
INFO - 2023-09-07 19:11:38 --> Config Class Initialized
INFO - 2023-09-07 19:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:38 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:38 --> URI Class Initialized
DEBUG - 2023-09-07 19:11:38 --> No URI present. Default controller set.
INFO - 2023-09-07 19:11:38 --> Router Class Initialized
INFO - 2023-09-07 19:11:38 --> Output Class Initialized
INFO - 2023-09-07 19:11:38 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:38 --> Input Class Initialized
INFO - 2023-09-07 19:11:38 --> Language Class Initialized
INFO - 2023-09-07 19:11:38 --> Loader Class Initialized
INFO - 2023-09-07 19:11:38 --> Helper loaded: url_helper
INFO - 2023-09-07 19:11:38 --> Helper loaded: file_helper
INFO - 2023-09-07 19:11:38 --> Database Driver Class Initialized
INFO - 2023-09-07 19:11:38 --> Email Class Initialized
DEBUG - 2023-09-07 19:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:11:38 --> Controller Class Initialized
INFO - 2023-09-07 19:11:38 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:11:38 --> Model "Home_model" initialized
INFO - 2023-09-07 19:11:38 --> Helper loaded: download_helper
INFO - 2023-09-07 19:11:38 --> Helper loaded: form_helper
INFO - 2023-09-07 19:11:38 --> Form Validation Class Initialized
INFO - 2023-09-07 19:11:38 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:11:38 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:11:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:11:38 --> Final output sent to browser
DEBUG - 2023-09-07 19:11:38 --> Total execution time: 0.4486
INFO - 2023-09-07 19:11:40 --> Config Class Initialized
INFO - 2023-09-07 19:11:40 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:40 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:40 --> URI Class Initialized
INFO - 2023-09-07 19:11:40 --> Router Class Initialized
INFO - 2023-09-07 19:11:40 --> Output Class Initialized
INFO - 2023-09-07 19:11:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:40 --> Input Class Initialized
INFO - 2023-09-07 19:11:40 --> Language Class Initialized
ERROR - 2023-09-07 19:11:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:11:47 --> Config Class Initialized
INFO - 2023-09-07 19:11:47 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:47 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:47 --> URI Class Initialized
DEBUG - 2023-09-07 19:11:47 --> No URI present. Default controller set.
INFO - 2023-09-07 19:11:47 --> Router Class Initialized
INFO - 2023-09-07 19:11:47 --> Output Class Initialized
INFO - 2023-09-07 19:11:47 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:47 --> Input Class Initialized
INFO - 2023-09-07 19:11:47 --> Language Class Initialized
INFO - 2023-09-07 19:11:47 --> Loader Class Initialized
INFO - 2023-09-07 19:11:47 --> Helper loaded: url_helper
INFO - 2023-09-07 19:11:47 --> Helper loaded: file_helper
INFO - 2023-09-07 19:11:47 --> Database Driver Class Initialized
INFO - 2023-09-07 19:11:47 --> Email Class Initialized
DEBUG - 2023-09-07 19:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:11:47 --> Controller Class Initialized
INFO - 2023-09-07 19:11:47 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:11:47 --> Model "Home_model" initialized
INFO - 2023-09-07 19:11:47 --> Helper loaded: download_helper
INFO - 2023-09-07 19:11:47 --> Helper loaded: form_helper
INFO - 2023-09-07 19:11:47 --> Form Validation Class Initialized
INFO - 2023-09-07 19:11:47 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:11:47 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:11:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:11:47 --> Final output sent to browser
DEBUG - 2023-09-07 19:11:47 --> Total execution time: 0.3915
INFO - 2023-09-07 19:11:48 --> Config Class Initialized
INFO - 2023-09-07 19:11:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:11:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:11:48 --> Utf8 Class Initialized
INFO - 2023-09-07 19:11:48 --> URI Class Initialized
INFO - 2023-09-07 19:11:48 --> Router Class Initialized
INFO - 2023-09-07 19:11:49 --> Output Class Initialized
INFO - 2023-09-07 19:11:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:11:49 --> Input Class Initialized
INFO - 2023-09-07 19:11:49 --> Language Class Initialized
ERROR - 2023-09-07 19:11:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:12:10 --> Config Class Initialized
INFO - 2023-09-07 19:12:10 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:12:10 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:12:10 --> Utf8 Class Initialized
INFO - 2023-09-07 19:12:10 --> URI Class Initialized
DEBUG - 2023-09-07 19:12:10 --> No URI present. Default controller set.
INFO - 2023-09-07 19:12:10 --> Router Class Initialized
INFO - 2023-09-07 19:12:10 --> Output Class Initialized
INFO - 2023-09-07 19:12:10 --> Security Class Initialized
DEBUG - 2023-09-07 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:12:10 --> Input Class Initialized
INFO - 2023-09-07 19:12:10 --> Language Class Initialized
INFO - 2023-09-07 19:12:10 --> Loader Class Initialized
INFO - 2023-09-07 19:12:11 --> Helper loaded: url_helper
INFO - 2023-09-07 19:12:11 --> Helper loaded: file_helper
INFO - 2023-09-07 19:12:11 --> Database Driver Class Initialized
INFO - 2023-09-07 19:12:11 --> Email Class Initialized
DEBUG - 2023-09-07 19:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:12:11 --> Controller Class Initialized
INFO - 2023-09-07 19:12:11 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:12:11 --> Model "Home_model" initialized
INFO - 2023-09-07 19:12:12 --> Helper loaded: download_helper
INFO - 2023-09-07 19:12:12 --> Helper loaded: form_helper
INFO - 2023-09-07 19:12:12 --> Form Validation Class Initialized
INFO - 2023-09-07 19:12:12 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:12:12 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:12:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:12:12 --> Final output sent to browser
DEBUG - 2023-09-07 19:12:12 --> Total execution time: 1.7575
INFO - 2023-09-07 19:12:13 --> Config Class Initialized
INFO - 2023-09-07 19:12:13 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:12:13 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:12:13 --> Utf8 Class Initialized
INFO - 2023-09-07 19:12:13 --> URI Class Initialized
INFO - 2023-09-07 19:12:13 --> Router Class Initialized
INFO - 2023-09-07 19:12:13 --> Output Class Initialized
INFO - 2023-09-07 19:12:13 --> Security Class Initialized
DEBUG - 2023-09-07 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:12:13 --> Input Class Initialized
INFO - 2023-09-07 19:12:13 --> Language Class Initialized
ERROR - 2023-09-07 19:12:13 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:13:07 --> Config Class Initialized
INFO - 2023-09-07 19:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:13:07 --> Utf8 Class Initialized
INFO - 2023-09-07 19:13:07 --> URI Class Initialized
DEBUG - 2023-09-07 19:13:07 --> No URI present. Default controller set.
INFO - 2023-09-07 19:13:07 --> Router Class Initialized
INFO - 2023-09-07 19:13:07 --> Output Class Initialized
INFO - 2023-09-07 19:13:07 --> Security Class Initialized
DEBUG - 2023-09-07 19:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:13:07 --> Input Class Initialized
INFO - 2023-09-07 19:13:07 --> Language Class Initialized
INFO - 2023-09-07 19:13:07 --> Loader Class Initialized
INFO - 2023-09-07 19:13:07 --> Helper loaded: url_helper
INFO - 2023-09-07 19:13:07 --> Helper loaded: file_helper
INFO - 2023-09-07 19:13:07 --> Database Driver Class Initialized
INFO - 2023-09-07 19:13:07 --> Email Class Initialized
DEBUG - 2023-09-07 19:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:13:07 --> Controller Class Initialized
INFO - 2023-09-07 19:13:07 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:13:08 --> Model "Home_model" initialized
INFO - 2023-09-07 19:13:08 --> Helper loaded: download_helper
INFO - 2023-09-07 19:13:08 --> Helper loaded: form_helper
INFO - 2023-09-07 19:13:08 --> Form Validation Class Initialized
INFO - 2023-09-07 19:13:08 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:13:08 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:13:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:13:08 --> Final output sent to browser
DEBUG - 2023-09-07 19:13:08 --> Total execution time: 0.6107
INFO - 2023-09-07 19:13:10 --> Config Class Initialized
INFO - 2023-09-07 19:13:10 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:13:10 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:13:10 --> Utf8 Class Initialized
INFO - 2023-09-07 19:13:10 --> URI Class Initialized
INFO - 2023-09-07 19:13:10 --> Router Class Initialized
INFO - 2023-09-07 19:13:10 --> Output Class Initialized
INFO - 2023-09-07 19:13:10 --> Security Class Initialized
DEBUG - 2023-09-07 19:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:13:10 --> Input Class Initialized
INFO - 2023-09-07 19:13:10 --> Language Class Initialized
ERROR - 2023-09-07 19:13:10 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:15:48 --> Config Class Initialized
INFO - 2023-09-07 19:15:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:15:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:15:48 --> Utf8 Class Initialized
INFO - 2023-09-07 19:15:48 --> URI Class Initialized
DEBUG - 2023-09-07 19:15:48 --> No URI present. Default controller set.
INFO - 2023-09-07 19:15:48 --> Router Class Initialized
INFO - 2023-09-07 19:15:48 --> Output Class Initialized
INFO - 2023-09-07 19:15:48 --> Security Class Initialized
DEBUG - 2023-09-07 19:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:15:48 --> Input Class Initialized
INFO - 2023-09-07 19:15:48 --> Language Class Initialized
INFO - 2023-09-07 19:15:48 --> Loader Class Initialized
INFO - 2023-09-07 19:15:48 --> Helper loaded: url_helper
INFO - 2023-09-07 19:15:48 --> Helper loaded: file_helper
INFO - 2023-09-07 19:15:48 --> Database Driver Class Initialized
INFO - 2023-09-07 19:15:48 --> Email Class Initialized
DEBUG - 2023-09-07 19:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:15:48 --> Controller Class Initialized
INFO - 2023-09-07 19:15:48 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:15:48 --> Model "Home_model" initialized
INFO - 2023-09-07 19:15:48 --> Helper loaded: download_helper
INFO - 2023-09-07 19:15:48 --> Helper loaded: form_helper
INFO - 2023-09-07 19:15:48 --> Form Validation Class Initialized
INFO - 2023-09-07 19:15:48 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:15:48 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:15:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:15:48 --> Final output sent to browser
DEBUG - 2023-09-07 19:15:49 --> Total execution time: 0.7484
INFO - 2023-09-07 19:15:50 --> Config Class Initialized
INFO - 2023-09-07 19:15:50 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:15:50 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:15:50 --> Utf8 Class Initialized
INFO - 2023-09-07 19:15:50 --> URI Class Initialized
INFO - 2023-09-07 19:15:50 --> Config Class Initialized
INFO - 2023-09-07 19:15:50 --> Hooks Class Initialized
INFO - 2023-09-07 19:15:50 --> Router Class Initialized
DEBUG - 2023-09-07 19:15:50 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:15:50 --> Output Class Initialized
INFO - 2023-09-07 19:15:51 --> Utf8 Class Initialized
INFO - 2023-09-07 19:15:51 --> Security Class Initialized
DEBUG - 2023-09-07 19:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:15:51 --> Input Class Initialized
INFO - 2023-09-07 19:15:51 --> URI Class Initialized
INFO - 2023-09-07 19:15:51 --> Language Class Initialized
INFO - 2023-09-07 19:15:51 --> Router Class Initialized
ERROR - 2023-09-07 19:15:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:15:51 --> Output Class Initialized
INFO - 2023-09-07 19:15:51 --> Security Class Initialized
DEBUG - 2023-09-07 19:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:15:51 --> Input Class Initialized
INFO - 2023-09-07 19:15:51 --> Language Class Initialized
ERROR - 2023-09-07 19:15:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:16:03 --> Config Class Initialized
INFO - 2023-09-07 19:16:03 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:04 --> Config Class Initialized
DEBUG - 2023-09-07 19:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:04 --> Config Class Initialized
INFO - 2023-09-07 19:16:04 --> Config Class Initialized
INFO - 2023-09-07 19:16:04 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:04 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:04 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:04 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:16:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:04 --> URI Class Initialized
DEBUG - 2023-09-07 19:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:04 --> Router Class Initialized
INFO - 2023-09-07 19:16:04 --> Config Class Initialized
INFO - 2023-09-07 19:16:04 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:04 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:04 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:04 --> Output Class Initialized
INFO - 2023-09-07 19:16:04 --> Security Class Initialized
INFO - 2023-09-07 19:16:04 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:04 --> URI Class Initialized
INFO - 2023-09-07 19:16:04 --> URI Class Initialized
INFO - 2023-09-07 19:16:04 --> Router Class Initialized
DEBUG - 2023-09-07 19:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:04 --> URI Class Initialized
INFO - 2023-09-07 19:16:05 --> Config Class Initialized
INFO - 2023-09-07 19:16:05 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:05 --> Output Class Initialized
DEBUG - 2023-09-07 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:05 --> Input Class Initialized
INFO - 2023-09-07 19:16:05 --> Language Class Initialized
ERROR - 2023-09-07 19:16:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:05 --> URI Class Initialized
INFO - 2023-09-07 19:16:05 --> Security Class Initialized
INFO - 2023-09-07 19:16:05 --> Router Class Initialized
INFO - 2023-09-07 19:16:05 --> Router Class Initialized
INFO - 2023-09-07 19:16:05 --> Output Class Initialized
INFO - 2023-09-07 19:16:05 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:05 --> Output Class Initialized
INFO - 2023-09-07 19:16:05 --> Config Class Initialized
INFO - 2023-09-07 19:16:05 --> Router Class Initialized
INFO - 2023-09-07 19:16:05 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:05 --> Input Class Initialized
INFO - 2023-09-07 19:16:05 --> Input Class Initialized
DEBUG - 2023-09-07 19:16:05 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:05 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:05 --> URI Class Initialized
INFO - 2023-09-07 19:16:05 --> Router Class Initialized
INFO - 2023-09-07 19:16:05 --> Output Class Initialized
INFO - 2023-09-07 19:16:05 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:05 --> Input Class Initialized
INFO - 2023-09-07 19:16:05 --> Language Class Initialized
ERROR - 2023-09-07 19:16:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:05 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:05 --> Output Class Initialized
INFO - 2023-09-07 19:16:05 --> Security Class Initialized
INFO - 2023-09-07 19:16:05 --> Language Class Initialized
INFO - 2023-09-07 19:16:05 --> Security Class Initialized
ERROR - 2023-09-07 19:16:05 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:06 --> Language Class Initialized
DEBUG - 2023-09-07 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:06 --> Input Class Initialized
INFO - 2023-09-07 19:16:06 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:06 --> URI Class Initialized
INFO - 2023-09-07 19:16:06 --> Input Class Initialized
ERROR - 2023-09-07 19:16:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:06 --> Language Class Initialized
INFO - 2023-09-07 19:16:06 --> Language Class Initialized
INFO - 2023-09-07 19:16:06 --> Router Class Initialized
INFO - 2023-09-07 19:16:06 --> Output Class Initialized
ERROR - 2023-09-07 19:16:06 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:16:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:06 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:06 --> Input Class Initialized
INFO - 2023-09-07 19:16:06 --> Language Class Initialized
ERROR - 2023-09-07 19:16:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:26 --> Config Class Initialized
INFO - 2023-09-07 19:16:26 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:26 --> URI Class Initialized
DEBUG - 2023-09-07 19:16:26 --> No URI present. Default controller set.
INFO - 2023-09-07 19:16:26 --> Router Class Initialized
INFO - 2023-09-07 19:16:26 --> Output Class Initialized
INFO - 2023-09-07 19:16:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:26 --> Input Class Initialized
INFO - 2023-09-07 19:16:26 --> Language Class Initialized
INFO - 2023-09-07 19:16:26 --> Loader Class Initialized
INFO - 2023-09-07 19:16:26 --> Helper loaded: url_helper
INFO - 2023-09-07 19:16:26 --> Helper loaded: file_helper
INFO - 2023-09-07 19:16:26 --> Database Driver Class Initialized
INFO - 2023-09-07 19:16:26 --> Email Class Initialized
DEBUG - 2023-09-07 19:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:16:27 --> Controller Class Initialized
INFO - 2023-09-07 19:16:27 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:16:27 --> Model "Home_model" initialized
INFO - 2023-09-07 19:16:27 --> Helper loaded: download_helper
INFO - 2023-09-07 19:16:27 --> Helper loaded: form_helper
INFO - 2023-09-07 19:16:27 --> Form Validation Class Initialized
INFO - 2023-09-07 19:16:27 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:16:27 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:16:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:16:27 --> Final output sent to browser
DEBUG - 2023-09-07 19:16:27 --> Total execution time: 0.4069
INFO - 2023-09-07 19:16:29 --> Config Class Initialized
INFO - 2023-09-07 19:16:29 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:29 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:29 --> URI Class Initialized
INFO - 2023-09-07 19:16:29 --> Router Class Initialized
INFO - 2023-09-07 19:16:29 --> Output Class Initialized
INFO - 2023-09-07 19:16:29 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:29 --> Input Class Initialized
INFO - 2023-09-07 19:16:29 --> Language Class Initialized
ERROR - 2023-09-07 19:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:29 --> Config Class Initialized
INFO - 2023-09-07 19:16:30 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:30 --> Config Class Initialized
INFO - 2023-09-07 19:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:30 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:30 --> URI Class Initialized
INFO - 2023-09-07 19:16:30 --> Router Class Initialized
INFO - 2023-09-07 19:16:30 --> Output Class Initialized
INFO - 2023-09-07 19:16:30 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:30 --> Input Class Initialized
INFO - 2023-09-07 19:16:30 --> Language Class Initialized
ERROR - 2023-09-07 19:16:30 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:30 --> Config Class Initialized
INFO - 2023-09-07 19:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:30 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:31 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:31 --> URI Class Initialized
INFO - 2023-09-07 19:16:31 --> URI Class Initialized
INFO - 2023-09-07 19:16:31 --> Router Class Initialized
INFO - 2023-09-07 19:16:31 --> Router Class Initialized
INFO - 2023-09-07 19:16:32 --> Config Class Initialized
INFO - 2023-09-07 19:16:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:32 --> URI Class Initialized
INFO - 2023-09-07 19:16:32 --> Router Class Initialized
INFO - 2023-09-07 19:16:32 --> Output Class Initialized
INFO - 2023-09-07 19:16:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:32 --> Input Class Initialized
INFO - 2023-09-07 19:16:32 --> Language Class Initialized
ERROR - 2023-09-07 19:16:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:32 --> Output Class Initialized
INFO - 2023-09-07 19:16:32 --> Security Class Initialized
INFO - 2023-09-07 19:16:32 --> Output Class Initialized
INFO - 2023-09-07 19:16:32 --> Config Class Initialized
INFO - 2023-09-07 19:16:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:32 --> URI Class Initialized
INFO - 2023-09-07 19:16:32 --> Router Class Initialized
INFO - 2023-09-07 19:16:32 --> Output Class Initialized
INFO - 2023-09-07 19:16:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:32 --> Input Class Initialized
INFO - 2023-09-07 19:16:32 --> Language Class Initialized
ERROR - 2023-09-07 19:16:32 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:33 --> Input Class Initialized
INFO - 2023-09-07 19:16:33 --> Language Class Initialized
INFO - 2023-09-07 19:16:33 --> Config Class Initialized
INFO - 2023-09-07 19:16:33 --> Security Class Initialized
DEBUG - 2023-09-07 19:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:16:33 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:16:34 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:34 --> Config Class Initialized
INFO - 2023-09-07 19:16:34 --> Input Class Initialized
INFO - 2023-09-07 19:16:34 --> Config Class Initialized
INFO - 2023-09-07 19:16:35 --> Language Class Initialized
ERROR - 2023-09-07 19:16:35 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:16:35 --> Hooks Class Initialized
INFO - 2023-09-07 19:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:35 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:16:35 --> URI Class Initialized
INFO - 2023-09-07 19:16:35 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:36 --> URI Class Initialized
INFO - 2023-09-07 19:16:36 --> Router Class Initialized
INFO - 2023-09-07 19:16:36 --> Router Class Initialized
INFO - 2023-09-07 19:16:36 --> Utf8 Class Initialized
INFO - 2023-09-07 19:16:36 --> Output Class Initialized
INFO - 2023-09-07 19:16:36 --> URI Class Initialized
INFO - 2023-09-07 19:16:37 --> Router Class Initialized
INFO - 2023-09-07 19:16:37 --> Output Class Initialized
INFO - 2023-09-07 19:16:37 --> Security Class Initialized
INFO - 2023-09-07 19:16:37 --> Output Class Initialized
DEBUG - 2023-09-07 19:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:37 --> Security Class Initialized
INFO - 2023-09-07 19:16:37 --> Security Class Initialized
INFO - 2023-09-07 19:16:37 --> Input Class Initialized
DEBUG - 2023-09-07 19:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:37 --> Language Class Initialized
ERROR - 2023-09-07 19:16:37 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:16:37 --> Input Class Initialized
INFO - 2023-09-07 19:16:37 --> Language Class Initialized
INFO - 2023-09-07 19:16:37 --> Input Class Initialized
ERROR - 2023-09-07 19:16:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:16:37 --> Language Class Initialized
ERROR - 2023-09-07 19:16:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:17:25 --> Config Class Initialized
INFO - 2023-09-07 19:17:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:17:25 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:25 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:25 --> URI Class Initialized
DEBUG - 2023-09-07 19:17:25 --> No URI present. Default controller set.
INFO - 2023-09-07 19:17:25 --> Router Class Initialized
INFO - 2023-09-07 19:17:25 --> Output Class Initialized
INFO - 2023-09-07 19:17:25 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:25 --> Input Class Initialized
INFO - 2023-09-07 19:17:25 --> Language Class Initialized
INFO - 2023-09-07 19:17:26 --> Loader Class Initialized
INFO - 2023-09-07 19:17:26 --> Helper loaded: url_helper
INFO - 2023-09-07 19:17:26 --> Helper loaded: file_helper
INFO - 2023-09-07 19:17:26 --> Database Driver Class Initialized
INFO - 2023-09-07 19:17:26 --> Email Class Initialized
DEBUG - 2023-09-07 19:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:17:26 --> Controller Class Initialized
INFO - 2023-09-07 19:17:26 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:17:26 --> Model "Home_model" initialized
INFO - 2023-09-07 19:17:26 --> Helper loaded: download_helper
INFO - 2023-09-07 19:17:26 --> Helper loaded: form_helper
INFO - 2023-09-07 19:17:26 --> Form Validation Class Initialized
INFO - 2023-09-07 19:17:26 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:17:26 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:17:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:17:26 --> Final output sent to browser
DEBUG - 2023-09-07 19:17:27 --> Total execution time: 1.8804
INFO - 2023-09-07 19:17:29 --> Config Class Initialized
INFO - 2023-09-07 19:17:29 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:17:29 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:29 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:29 --> URI Class Initialized
INFO - 2023-09-07 19:17:29 --> Router Class Initialized
INFO - 2023-09-07 19:17:29 --> Output Class Initialized
INFO - 2023-09-07 19:17:29 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:30 --> Input Class Initialized
INFO - 2023-09-07 19:17:30 --> Language Class Initialized
INFO - 2023-09-07 19:17:30 --> Config Class Initialized
INFO - 2023-09-07 19:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:30 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:30 --> URI Class Initialized
INFO - 2023-09-07 19:17:30 --> Router Class Initialized
INFO - 2023-09-07 19:17:31 --> Output Class Initialized
INFO - 2023-09-07 19:17:31 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:31 --> Input Class Initialized
INFO - 2023-09-07 19:17:31 --> Language Class Initialized
ERROR - 2023-09-07 19:17:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:17:31 --> Config Class Initialized
INFO - 2023-09-07 19:17:31 --> Hooks Class Initialized
INFO - 2023-09-07 19:17:32 --> Config Class Initialized
INFO - 2023-09-07 19:17:32 --> Hooks Class Initialized
INFO - 2023-09-07 19:17:32 --> Config Class Initialized
DEBUG - 2023-09-07 19:17:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:32 --> Hooks Class Initialized
ERROR - 2023-09-07 19:17:32 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:17:32 --> Config Class Initialized
INFO - 2023-09-07 19:17:32 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:17:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:33 --> URI Class Initialized
INFO - 2023-09-07 19:17:33 --> Router Class Initialized
INFO - 2023-09-07 19:17:33 --> Output Class Initialized
INFO - 2023-09-07 19:17:33 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:33 --> Input Class Initialized
INFO - 2023-09-07 19:17:33 --> Language Class Initialized
ERROR - 2023-09-07 19:17:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:17:33 --> Hooks Class Initialized
INFO - 2023-09-07 19:17:33 --> Config Class Initialized
INFO - 2023-09-07 19:17:33 --> URI Class Initialized
DEBUG - 2023-09-07 19:17:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:17:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:33 --> Router Class Initialized
INFO - 2023-09-07 19:17:33 --> Config Class Initialized
INFO - 2023-09-07 19:17:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:17:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:33 --> URI Class Initialized
INFO - 2023-09-07 19:17:33 --> Router Class Initialized
INFO - 2023-09-07 19:17:33 --> Output Class Initialized
INFO - 2023-09-07 19:17:33 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:33 --> Input Class Initialized
INFO - 2023-09-07 19:17:33 --> Language Class Initialized
ERROR - 2023-09-07 19:17:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:17:33 --> Output Class Initialized
INFO - 2023-09-07 19:17:33 --> Hooks Class Initialized
INFO - 2023-09-07 19:17:33 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:17:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:17:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:33 --> Security Class Initialized
INFO - 2023-09-07 19:17:34 --> URI Class Initialized
INFO - 2023-09-07 19:17:34 --> Router Class Initialized
INFO - 2023-09-07 19:17:34 --> Utf8 Class Initialized
INFO - 2023-09-07 19:17:34 --> URI Class Initialized
DEBUG - 2023-09-07 19:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:34 --> URI Class Initialized
INFO - 2023-09-07 19:17:34 --> Router Class Initialized
INFO - 2023-09-07 19:17:34 --> Output Class Initialized
INFO - 2023-09-07 19:17:34 --> Input Class Initialized
INFO - 2023-09-07 19:17:34 --> Router Class Initialized
INFO - 2023-09-07 19:17:34 --> Language Class Initialized
INFO - 2023-09-07 19:17:34 --> Output Class Initialized
INFO - 2023-09-07 19:17:35 --> Security Class Initialized
INFO - 2023-09-07 19:17:35 --> Security Class Initialized
DEBUG - 2023-09-07 19:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:17:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:17:35 --> Output Class Initialized
INFO - 2023-09-07 19:17:35 --> Input Class Initialized
DEBUG - 2023-09-07 19:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:35 --> Input Class Initialized
INFO - 2023-09-07 19:17:35 --> Language Class Initialized
INFO - 2023-09-07 19:17:35 --> Security Class Initialized
INFO - 2023-09-07 19:17:35 --> Language Class Initialized
ERROR - 2023-09-07 19:17:36 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:17:36 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:17:36 --> Input Class Initialized
INFO - 2023-09-07 19:17:36 --> Language Class Initialized
ERROR - 2023-09-07 19:17:36 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:31 --> Config Class Initialized
INFO - 2023-09-07 19:20:31 --> Config Class Initialized
INFO - 2023-09-07 19:20:31 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> Config Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Config Class Initialized
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:32 --> Config Class Initialized
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Config Class Initialized
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Config Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:20:32 --> Hooks Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
DEBUG - 2023-09-07 19:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
INFO - 2023-09-07 19:20:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:20:32 --> URI Class Initialized
INFO - 2023-09-07 19:20:32 --> Router Class Initialized
INFO - 2023-09-07 19:20:32 --> Output Class Initialized
INFO - 2023-09-07 19:20:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:20:32 --> Input Class Initialized
INFO - 2023-09-07 19:20:32 --> Language Class Initialized
ERROR - 2023-09-07 19:20:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:37 --> Config Class Initialized
INFO - 2023-09-07 19:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:37 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:37 --> URI Class Initialized
DEBUG - 2023-09-07 19:21:37 --> No URI present. Default controller set.
INFO - 2023-09-07 19:21:37 --> Router Class Initialized
INFO - 2023-09-07 19:21:37 --> Output Class Initialized
INFO - 2023-09-07 19:21:37 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:37 --> Input Class Initialized
INFO - 2023-09-07 19:21:37 --> Language Class Initialized
INFO - 2023-09-07 19:21:37 --> Loader Class Initialized
INFO - 2023-09-07 19:21:37 --> Helper loaded: url_helper
INFO - 2023-09-07 19:21:37 --> Helper loaded: file_helper
INFO - 2023-09-07 19:21:37 --> Database Driver Class Initialized
INFO - 2023-09-07 19:21:37 --> Email Class Initialized
DEBUG - 2023-09-07 19:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:21:37 --> Controller Class Initialized
INFO - 2023-09-07 19:21:37 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:21:37 --> Model "Home_model" initialized
INFO - 2023-09-07 19:21:37 --> Helper loaded: download_helper
INFO - 2023-09-07 19:21:37 --> Helper loaded: form_helper
INFO - 2023-09-07 19:21:37 --> Form Validation Class Initialized
INFO - 2023-09-07 19:21:37 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:21:37 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:21:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:21:37 --> Final output sent to browser
DEBUG - 2023-09-07 19:21:37 --> Total execution time: 0.8027
INFO - 2023-09-07 19:21:38 --> Config Class Initialized
INFO - 2023-09-07 19:21:38 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:38 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:38 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:38 --> URI Class Initialized
INFO - 2023-09-07 19:21:38 --> Router Class Initialized
INFO - 2023-09-07 19:21:38 --> Output Class Initialized
INFO - 2023-09-07 19:21:38 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:38 --> Input Class Initialized
INFO - 2023-09-07 19:21:38 --> Language Class Initialized
ERROR - 2023-09-07 19:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:38 --> Config Class Initialized
INFO - 2023-09-07 19:21:38 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:38 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:38 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:38 --> URI Class Initialized
INFO - 2023-09-07 19:21:38 --> Router Class Initialized
INFO - 2023-09-07 19:21:38 --> Output Class Initialized
INFO - 2023-09-07 19:21:38 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:38 --> Input Class Initialized
INFO - 2023-09-07 19:21:38 --> Language Class Initialized
ERROR - 2023-09-07 19:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:38 --> Config Class Initialized
INFO - 2023-09-07 19:21:38 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:38 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:38 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:38 --> URI Class Initialized
INFO - 2023-09-07 19:21:38 --> Router Class Initialized
INFO - 2023-09-07 19:21:38 --> Output Class Initialized
INFO - 2023-09-07 19:21:38 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:38 --> Input Class Initialized
INFO - 2023-09-07 19:21:38 --> Language Class Initialized
ERROR - 2023-09-07 19:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:39 --> Config Class Initialized
INFO - 2023-09-07 19:21:39 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:39 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:39 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:39 --> URI Class Initialized
INFO - 2023-09-07 19:21:39 --> Router Class Initialized
INFO - 2023-09-07 19:21:39 --> Output Class Initialized
INFO - 2023-09-07 19:21:39 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:39 --> Input Class Initialized
INFO - 2023-09-07 19:21:39 --> Language Class Initialized
ERROR - 2023-09-07 19:21:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:39 --> Config Class Initialized
INFO - 2023-09-07 19:21:39 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:39 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:39 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:39 --> URI Class Initialized
INFO - 2023-09-07 19:21:39 --> Router Class Initialized
INFO - 2023-09-07 19:21:39 --> Output Class Initialized
INFO - 2023-09-07 19:21:39 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:39 --> Input Class Initialized
INFO - 2023-09-07 19:21:39 --> Language Class Initialized
ERROR - 2023-09-07 19:21:39 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:21:39 --> Config Class Initialized
INFO - 2023-09-07 19:21:39 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:39 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:39 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:39 --> URI Class Initialized
INFO - 2023-09-07 19:21:39 --> Router Class Initialized
INFO - 2023-09-07 19:21:39 --> Output Class Initialized
INFO - 2023-09-07 19:21:39 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:39 --> Input Class Initialized
INFO - 2023-09-07 19:21:39 --> Language Class Initialized
ERROR - 2023-09-07 19:21:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:40 --> Config Class Initialized
INFO - 2023-09-07 19:21:40 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:40 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:40 --> URI Class Initialized
INFO - 2023-09-07 19:21:40 --> Router Class Initialized
INFO - 2023-09-07 19:21:40 --> Output Class Initialized
INFO - 2023-09-07 19:21:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:40 --> Input Class Initialized
INFO - 2023-09-07 19:21:40 --> Language Class Initialized
ERROR - 2023-09-07 19:21:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:21:40 --> Config Class Initialized
INFO - 2023-09-07 19:21:40 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:21:40 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:21:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:21:40 --> URI Class Initialized
INFO - 2023-09-07 19:21:40 --> Router Class Initialized
INFO - 2023-09-07 19:21:40 --> Output Class Initialized
INFO - 2023-09-07 19:21:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:21:40 --> Input Class Initialized
INFO - 2023-09-07 19:21:40 --> Language Class Initialized
ERROR - 2023-09-07 19:21:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:23:52 --> Config Class Initialized
INFO - 2023-09-07 19:23:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:23:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:23:52 --> Utf8 Class Initialized
INFO - 2023-09-07 19:23:52 --> URI Class Initialized
DEBUG - 2023-09-07 19:23:52 --> No URI present. Default controller set.
INFO - 2023-09-07 19:23:52 --> Router Class Initialized
INFO - 2023-09-07 19:23:52 --> Output Class Initialized
INFO - 2023-09-07 19:23:52 --> Security Class Initialized
DEBUG - 2023-09-07 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:23:52 --> Input Class Initialized
INFO - 2023-09-07 19:23:53 --> Language Class Initialized
INFO - 2023-09-07 19:23:53 --> Loader Class Initialized
INFO - 2023-09-07 19:23:53 --> Helper loaded: url_helper
INFO - 2023-09-07 19:23:53 --> Helper loaded: file_helper
INFO - 2023-09-07 19:23:53 --> Database Driver Class Initialized
INFO - 2023-09-07 19:23:53 --> Email Class Initialized
DEBUG - 2023-09-07 19:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:23:53 --> Controller Class Initialized
INFO - 2023-09-07 19:23:53 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:23:53 --> Model "Home_model" initialized
INFO - 2023-09-07 19:23:53 --> Helper loaded: download_helper
INFO - 2023-09-07 19:23:53 --> Helper loaded: form_helper
INFO - 2023-09-07 19:23:53 --> Form Validation Class Initialized
INFO - 2023-09-07 19:23:53 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:23:53 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:23:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:23:53 --> Final output sent to browser
DEBUG - 2023-09-07 19:23:53 --> Total execution time: 0.8774
INFO - 2023-09-07 19:23:55 --> Config Class Initialized
INFO - 2023-09-07 19:23:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:23:55 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:23:55 --> Utf8 Class Initialized
INFO - 2023-09-07 19:23:55 --> URI Class Initialized
INFO - 2023-09-07 19:23:55 --> Router Class Initialized
INFO - 2023-09-07 19:23:55 --> Output Class Initialized
INFO - 2023-09-07 19:23:55 --> Security Class Initialized
DEBUG - 2023-09-07 19:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:23:57 --> Config Class Initialized
INFO - 2023-09-07 19:23:57 --> Input Class Initialized
INFO - 2023-09-07 19:23:57 --> Language Class Initialized
INFO - 2023-09-07 19:23:58 --> Config Class Initialized
INFO - 2023-09-07 19:23:59 --> Hooks Class Initialized
INFO - 2023-09-07 19:23:59 --> Config Class Initialized
INFO - 2023-09-07 19:23:59 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:00 --> UTF-8 Support Enabled
ERROR - 2023-09-07 19:24:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:00 --> Config Class Initialized
INFO - 2023-09-07 19:24:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:00 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:00 --> URI Class Initialized
INFO - 2023-09-07 19:24:00 --> Router Class Initialized
INFO - 2023-09-07 19:24:00 --> Output Class Initialized
INFO - 2023-09-07 19:24:00 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:00 --> Input Class Initialized
INFO - 2023-09-07 19:24:00 --> Language Class Initialized
ERROR - 2023-09-07 19:24:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:24:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:00 --> Config Class Initialized
INFO - 2023-09-07 19:24:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:00 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:00 --> URI Class Initialized
INFO - 2023-09-07 19:24:00 --> Router Class Initialized
INFO - 2023-09-07 19:24:00 --> Output Class Initialized
INFO - 2023-09-07 19:24:00 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:00 --> Input Class Initialized
INFO - 2023-09-07 19:24:00 --> Language Class Initialized
ERROR - 2023-09-07 19:24:00 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:24:00 --> Config Class Initialized
INFO - 2023-09-07 19:24:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:00 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:00 --> URI Class Initialized
INFO - 2023-09-07 19:24:00 --> Router Class Initialized
INFO - 2023-09-07 19:24:00 --> Output Class Initialized
INFO - 2023-09-07 19:24:00 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:00 --> Input Class Initialized
INFO - 2023-09-07 19:24:00 --> Language Class Initialized
ERROR - 2023-09-07 19:24:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:00 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:01 --> Config Class Initialized
INFO - 2023-09-07 19:24:01 --> Hooks Class Initialized
INFO - 2023-09-07 19:24:01 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:01 --> URI Class Initialized
INFO - 2023-09-07 19:24:01 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:01 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:01 --> Router Class Initialized
INFO - 2023-09-07 19:24:01 --> URI Class Initialized
INFO - 2023-09-07 19:24:01 --> Output Class Initialized
INFO - 2023-09-07 19:24:01 --> Router Class Initialized
DEBUG - 2023-09-07 19:24:02 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:02 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:02 --> Security Class Initialized
INFO - 2023-09-07 19:24:02 --> Output Class Initialized
INFO - 2023-09-07 19:24:02 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:02 --> URI Class Initialized
INFO - 2023-09-07 19:24:02 --> Input Class Initialized
INFO - 2023-09-07 19:24:02 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:02 --> Input Class Initialized
INFO - 2023-09-07 19:24:02 --> Language Class Initialized
ERROR - 2023-09-07 19:24:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:02 --> Router Class Initialized
INFO - 2023-09-07 19:24:02 --> URI Class Initialized
INFO - 2023-09-07 19:24:02 --> Output Class Initialized
INFO - 2023-09-07 19:24:02 --> Language Class Initialized
INFO - 2023-09-07 19:24:02 --> Router Class Initialized
INFO - 2023-09-07 19:24:02 --> Output Class Initialized
ERROR - 2023-09-07 19:24:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:02 --> Security Class Initialized
INFO - 2023-09-07 19:24:02 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:02 --> Input Class Initialized
INFO - 2023-09-07 19:24:02 --> Input Class Initialized
INFO - 2023-09-07 19:24:02 --> Language Class Initialized
INFO - 2023-09-07 19:24:02 --> Language Class Initialized
ERROR - 2023-09-07 19:24:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:24:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:32 --> URI Class Initialized
INFO - 2023-09-07 19:24:32 --> Router Class Initialized
INFO - 2023-09-07 19:24:32 --> Output Class Initialized
INFO - 2023-09-07 19:24:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:32 --> Input Class Initialized
INFO - 2023-09-07 19:24:32 --> Language Class Initialized
ERROR - 2023-09-07 19:24:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:32 --> URI Class Initialized
INFO - 2023-09-07 19:24:32 --> Router Class Initialized
INFO - 2023-09-07 19:24:32 --> Output Class Initialized
INFO - 2023-09-07 19:24:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:32 --> Input Class Initialized
INFO - 2023-09-07 19:24:32 --> Language Class Initialized
ERROR - 2023-09-07 19:24:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Config Class Initialized
INFO - 2023-09-07 19:24:32 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:32 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:32 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:32 --> URI Class Initialized
INFO - 2023-09-07 19:24:32 --> Router Class Initialized
INFO - 2023-09-07 19:24:32 --> Output Class Initialized
INFO - 2023-09-07 19:24:32 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:32 --> Input Class Initialized
INFO - 2023-09-07 19:24:32 --> Language Class Initialized
ERROR - 2023-09-07 19:24:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:33 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:24:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:33 --> Config Class Initialized
INFO - 2023-09-07 19:24:33 --> Utf8 Class Initialized
INFO - 2023-09-07 19:24:33 --> URI Class Initialized
INFO - 2023-09-07 19:24:33 --> URI Class Initialized
INFO - 2023-09-07 19:24:33 --> Router Class Initialized
INFO - 2023-09-07 19:24:33 --> Hooks Class Initialized
INFO - 2023-09-07 19:24:33 --> Router Class Initialized
INFO - 2023-09-07 19:24:33 --> URI Class Initialized
INFO - 2023-09-07 19:24:33 --> Output Class Initialized
INFO - 2023-09-07 19:24:33 --> Router Class Initialized
DEBUG - 2023-09-07 19:24:33 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:24:33 --> Security Class Initialized
INFO - 2023-09-07 19:24:33 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:33 --> Output Class Initialized
INFO - 2023-09-07 19:24:33 --> Input Class Initialized
INFO - 2023-09-07 19:24:33 --> Language Class Initialized
INFO - 2023-09-07 19:24:33 --> Output Class Initialized
INFO - 2023-09-07 19:24:33 --> URI Class Initialized
INFO - 2023-09-07 19:24:33 --> Router Class Initialized
INFO - 2023-09-07 19:24:33 --> Security Class Initialized
ERROR - 2023-09-07 19:24:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:33 --> Output Class Initialized
INFO - 2023-09-07 19:24:33 --> Security Class Initialized
INFO - 2023-09-07 19:24:33 --> Security Class Initialized
DEBUG - 2023-09-07 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:24:33 --> Input Class Initialized
INFO - 2023-09-07 19:24:33 --> Language Class Initialized
INFO - 2023-09-07 19:24:33 --> Input Class Initialized
ERROR - 2023-09-07 19:24:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:33 --> Language Class Initialized
ERROR - 2023-09-07 19:24:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:24:33 --> Input Class Initialized
INFO - 2023-09-07 19:24:33 --> Language Class Initialized
ERROR - 2023-09-07 19:24:33 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:19 --> Config Class Initialized
INFO - 2023-09-07 19:25:19 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:19 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:19 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:19 --> URI Class Initialized
DEBUG - 2023-09-07 19:25:19 --> No URI present. Default controller set.
INFO - 2023-09-07 19:25:20 --> Router Class Initialized
INFO - 2023-09-07 19:25:20 --> Output Class Initialized
INFO - 2023-09-07 19:25:20 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:20 --> Input Class Initialized
INFO - 2023-09-07 19:25:20 --> Language Class Initialized
INFO - 2023-09-07 19:25:20 --> Loader Class Initialized
INFO - 2023-09-07 19:25:20 --> Helper loaded: url_helper
INFO - 2023-09-07 19:25:20 --> Helper loaded: file_helper
INFO - 2023-09-07 19:25:20 --> Database Driver Class Initialized
INFO - 2023-09-07 19:25:20 --> Email Class Initialized
DEBUG - 2023-09-07 19:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:25:20 --> Controller Class Initialized
INFO - 2023-09-07 19:25:20 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:25:20 --> Model "Home_model" initialized
INFO - 2023-09-07 19:25:20 --> Helper loaded: download_helper
INFO - 2023-09-07 19:25:20 --> Helper loaded: form_helper
INFO - 2023-09-07 19:25:20 --> Form Validation Class Initialized
INFO - 2023-09-07 19:25:20 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:25:20 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:25:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:25:20 --> Final output sent to browser
DEBUG - 2023-09-07 19:25:20 --> Total execution time: 0.5721
INFO - 2023-09-07 19:25:22 --> Config Class Initialized
INFO - 2023-09-07 19:25:23 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:23 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:24 --> Config Class Initialized
INFO - 2023-09-07 19:25:24 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:24 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:24 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:24 --> URI Class Initialized
INFO - 2023-09-07 19:25:24 --> Router Class Initialized
INFO - 2023-09-07 19:25:24 --> Output Class Initialized
INFO - 2023-09-07 19:25:24 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:24 --> Input Class Initialized
INFO - 2023-09-07 19:25:24 --> Language Class Initialized
ERROR - 2023-09-07 19:25:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:24 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:24 --> URI Class Initialized
INFO - 2023-09-07 19:25:25 --> Config Class Initialized
INFO - 2023-09-07 19:25:25 --> Config Class Initialized
INFO - 2023-09-07 19:25:25 --> Router Class Initialized
INFO - 2023-09-07 19:25:25 --> Config Class Initialized
INFO - 2023-09-07 19:25:25 --> Hooks Class Initialized
INFO - 2023-09-07 19:25:25 --> Hooks Class Initialized
INFO - 2023-09-07 19:25:25 --> Config Class Initialized
INFO - 2023-09-07 19:25:25 --> Output Class Initialized
INFO - 2023-09-07 19:25:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:26 --> Security Class Initialized
INFO - 2023-09-07 19:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:26 --> URI Class Initialized
DEBUG - 2023-09-07 19:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:26 --> Input Class Initialized
INFO - 2023-09-07 19:25:26 --> URI Class Initialized
INFO - 2023-09-07 19:25:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:26 --> Router Class Initialized
INFO - 2023-09-07 19:25:26 --> Router Class Initialized
INFO - 2023-09-07 19:25:26 --> URI Class Initialized
INFO - 2023-09-07 19:25:26 --> Output Class Initialized
INFO - 2023-09-07 19:25:26 --> Language Class Initialized
INFO - 2023-09-07 19:25:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:26 --> Router Class Initialized
INFO - 2023-09-07 19:25:26 --> Config Class Initialized
INFO - 2023-09-07 19:25:26 --> Security Class Initialized
INFO - 2023-09-07 19:25:26 --> Output Class Initialized
INFO - 2023-09-07 19:25:26 --> URI Class Initialized
INFO - 2023-09-07 19:25:26 --> Output Class Initialized
ERROR - 2023-09-07 19:25:26 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:26 --> Input Class Initialized
INFO - 2023-09-07 19:25:26 --> Router Class Initialized
INFO - 2023-09-07 19:25:26 --> Output Class Initialized
INFO - 2023-09-07 19:25:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:26 --> Input Class Initialized
INFO - 2023-09-07 19:25:26 --> Language Class Initialized
ERROR - 2023-09-07 19:25:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:26 --> Hooks Class Initialized
INFO - 2023-09-07 19:25:26 --> Language Class Initialized
INFO - 2023-09-07 19:25:26 --> Input Class Initialized
INFO - 2023-09-07 19:25:26 --> Language Class Initialized
ERROR - 2023-09-07 19:25:26 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:25:26 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:26 --> Config Class Initialized
INFO - 2023-09-07 19:25:26 --> Security Class Initialized
INFO - 2023-09-07 19:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:27 --> Input Class Initialized
INFO - 2023-09-07 19:25:27 --> URI Class Initialized
INFO - 2023-09-07 19:25:27 --> Language Class Initialized
DEBUG - 2023-09-07 19:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:27 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:27 --> Router Class Initialized
INFO - 2023-09-07 19:25:28 --> URI Class Initialized
ERROR - 2023-09-07 19:25:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:28 --> Router Class Initialized
INFO - 2023-09-07 19:25:28 --> Output Class Initialized
INFO - 2023-09-07 19:25:28 --> Output Class Initialized
INFO - 2023-09-07 19:25:28 --> Security Class Initialized
INFO - 2023-09-07 19:25:28 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:28 --> Input Class Initialized
INFO - 2023-09-07 19:25:28 --> Input Class Initialized
INFO - 2023-09-07 19:25:28 --> Language Class Initialized
INFO - 2023-09-07 19:25:28 --> Language Class Initialized
ERROR - 2023-09-07 19:25:28 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:25:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:51 --> Config Class Initialized
INFO - 2023-09-07 19:25:51 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:51 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:51 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:51 --> URI Class Initialized
DEBUG - 2023-09-07 19:25:51 --> No URI present. Default controller set.
INFO - 2023-09-07 19:25:51 --> Router Class Initialized
INFO - 2023-09-07 19:25:51 --> Output Class Initialized
INFO - 2023-09-07 19:25:51 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:52 --> Input Class Initialized
INFO - 2023-09-07 19:25:52 --> Language Class Initialized
INFO - 2023-09-07 19:25:52 --> Loader Class Initialized
INFO - 2023-09-07 19:25:52 --> Helper loaded: url_helper
INFO - 2023-09-07 19:25:52 --> Helper loaded: file_helper
INFO - 2023-09-07 19:25:52 --> Database Driver Class Initialized
INFO - 2023-09-07 19:25:52 --> Email Class Initialized
DEBUG - 2023-09-07 19:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:25:52 --> Controller Class Initialized
INFO - 2023-09-07 19:25:52 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:25:52 --> Model "Home_model" initialized
INFO - 2023-09-07 19:25:52 --> Helper loaded: download_helper
INFO - 2023-09-07 19:25:52 --> Helper loaded: form_helper
INFO - 2023-09-07 19:25:52 --> Form Validation Class Initialized
INFO - 2023-09-07 19:25:52 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:25:52 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:25:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:25:52 --> Final output sent to browser
DEBUG - 2023-09-07 19:25:52 --> Total execution time: 0.6775
INFO - 2023-09-07 19:25:54 --> Config Class Initialized
INFO - 2023-09-07 19:25:54 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:54 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:54 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:54 --> URI Class Initialized
INFO - 2023-09-07 19:25:54 --> Router Class Initialized
INFO - 2023-09-07 19:25:54 --> Output Class Initialized
INFO - 2023-09-07 19:25:54 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:54 --> Input Class Initialized
INFO - 2023-09-07 19:25:54 --> Language Class Initialized
ERROR - 2023-09-07 19:25:54 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:25:54 --> Config Class Initialized
INFO - 2023-09-07 19:25:54 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:54 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:54 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:54 --> URI Class Initialized
INFO - 2023-09-07 19:25:54 --> Router Class Initialized
INFO - 2023-09-07 19:25:54 --> Output Class Initialized
INFO - 2023-09-07 19:25:54 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:55 --> Input Class Initialized
INFO - 2023-09-07 19:25:55 --> Language Class Initialized
ERROR - 2023-09-07 19:25:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:55 --> Config Class Initialized
INFO - 2023-09-07 19:25:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:55 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:55 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:55 --> URI Class Initialized
INFO - 2023-09-07 19:25:55 --> Router Class Initialized
INFO - 2023-09-07 19:25:55 --> Output Class Initialized
INFO - 2023-09-07 19:25:55 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:55 --> Input Class Initialized
INFO - 2023-09-07 19:25:55 --> Language Class Initialized
ERROR - 2023-09-07 19:25:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:56 --> Config Class Initialized
INFO - 2023-09-07 19:25:56 --> Config Class Initialized
INFO - 2023-09-07 19:25:56 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:56 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:56 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:56 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:56 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:56 --> URI Class Initialized
INFO - 2023-09-07 19:25:57 --> Router Class Initialized
INFO - 2023-09-07 19:25:57 --> Output Class Initialized
INFO - 2023-09-07 19:25:57 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:57 --> Input Class Initialized
INFO - 2023-09-07 19:25:57 --> Language Class Initialized
ERROR - 2023-09-07 19:25:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:57 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:57 --> URI Class Initialized
INFO - 2023-09-07 19:25:57 --> Router Class Initialized
INFO - 2023-09-07 19:25:57 --> Output Class Initialized
INFO - 2023-09-07 19:25:57 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:57 --> Input Class Initialized
INFO - 2023-09-07 19:25:57 --> Language Class Initialized
ERROR - 2023-09-07 19:25:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:58 --> Config Class Initialized
INFO - 2023-09-07 19:25:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:25:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:58 --> URI Class Initialized
INFO - 2023-09-07 19:25:58 --> Router Class Initialized
INFO - 2023-09-07 19:25:58 --> Output Class Initialized
INFO - 2023-09-07 19:25:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:58 --> Input Class Initialized
INFO - 2023-09-07 19:25:58 --> Language Class Initialized
ERROR - 2023-09-07 19:25:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:58 --> Config Class Initialized
INFO - 2023-09-07 19:25:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:25:58 --> Config Class Initialized
DEBUG - 2023-09-07 19:25:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:25:58 --> URI Class Initialized
INFO - 2023-09-07 19:25:58 --> Router Class Initialized
DEBUG - 2023-09-07 19:25:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:25:58 --> Output Class Initialized
INFO - 2023-09-07 19:25:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:25:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:58 --> URI Class Initialized
INFO - 2023-09-07 19:25:58 --> Input Class Initialized
INFO - 2023-09-07 19:25:58 --> Router Class Initialized
INFO - 2023-09-07 19:25:58 --> Language Class Initialized
ERROR - 2023-09-07 19:25:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:25:58 --> Output Class Initialized
INFO - 2023-09-07 19:25:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:25:58 --> Input Class Initialized
INFO - 2023-09-07 19:25:58 --> Language Class Initialized
ERROR - 2023-09-07 19:25:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:28:37 --> Config Class Initialized
INFO - 2023-09-07 19:28:37 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:28:37 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:37 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:37 --> URI Class Initialized
DEBUG - 2023-09-07 19:28:37 --> No URI present. Default controller set.
INFO - 2023-09-07 19:28:37 --> Router Class Initialized
INFO - 2023-09-07 19:28:37 --> Output Class Initialized
INFO - 2023-09-07 19:28:37 --> Security Class Initialized
DEBUG - 2023-09-07 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:37 --> Input Class Initialized
INFO - 2023-09-07 19:28:37 --> Language Class Initialized
INFO - 2023-09-07 19:28:37 --> Loader Class Initialized
INFO - 2023-09-07 19:28:37 --> Helper loaded: url_helper
INFO - 2023-09-07 19:28:37 --> Helper loaded: file_helper
INFO - 2023-09-07 19:28:38 --> Database Driver Class Initialized
INFO - 2023-09-07 19:28:38 --> Email Class Initialized
DEBUG - 2023-09-07 19:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:28:38 --> Controller Class Initialized
INFO - 2023-09-07 19:28:38 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:28:38 --> Model "Home_model" initialized
INFO - 2023-09-07 19:28:38 --> Helper loaded: download_helper
INFO - 2023-09-07 19:28:38 --> Helper loaded: form_helper
INFO - 2023-09-07 19:28:38 --> Form Validation Class Initialized
INFO - 2023-09-07 19:28:38 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:28:38 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:28:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:28:38 --> Final output sent to browser
DEBUG - 2023-09-07 19:28:38 --> Total execution time: 1.2563
INFO - 2023-09-07 19:28:39 --> Config Class Initialized
INFO - 2023-09-07 19:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:40 --> URI Class Initialized
INFO - 2023-09-07 19:28:40 --> Router Class Initialized
INFO - 2023-09-07 19:28:40 --> Output Class Initialized
INFO - 2023-09-07 19:28:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:41 --> Input Class Initialized
INFO - 2023-09-07 19:28:41 --> Language Class Initialized
ERROR - 2023-09-07 19:28:41 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:28:47 --> Config Class Initialized
INFO - 2023-09-07 19:28:47 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:47 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:47 --> Config Class Initialized
INFO - 2023-09-07 19:28:47 --> Config Class Initialized
INFO - 2023-09-07 19:28:47 --> Hooks Class Initialized
INFO - 2023-09-07 19:28:47 --> Config Class Initialized
DEBUG - 2023-09-07 19:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:47 --> Config Class Initialized
INFO - 2023-09-07 19:28:47 --> Hooks Class Initialized
INFO - 2023-09-07 19:28:47 --> Hooks Class Initialized
INFO - 2023-09-07 19:28:47 --> URI Class Initialized
INFO - 2023-09-07 19:28:47 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:28:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:47 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:47 --> Hooks Class Initialized
INFO - 2023-09-07 19:28:47 --> Router Class Initialized
INFO - 2023-09-07 19:28:47 --> URI Class Initialized
INFO - 2023-09-07 19:28:47 --> URI Class Initialized
INFO - 2023-09-07 19:28:47 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:47 --> Output Class Initialized
DEBUG - 2023-09-07 19:28:47 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:47 --> Router Class Initialized
INFO - 2023-09-07 19:28:47 --> Router Class Initialized
INFO - 2023-09-07 19:28:48 --> URI Class Initialized
INFO - 2023-09-07 19:28:48 --> Output Class Initialized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
INFO - 2023-09-07 19:28:48 --> Output Class Initialized
INFO - 2023-09-07 19:28:48 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
INFO - 2023-09-07 19:28:48 --> Router Class Initialized
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
INFO - 2023-09-07 19:28:48 --> URI Class Initialized
INFO - 2023-09-07 19:28:48 --> Router Class Initialized
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> Config Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> Output Class Initialized
INFO - 2023-09-07 19:28:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:28:48 --> UTF-8 Support Enabled
ERROR - 2023-09-07 19:28:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:48 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> URI Class Initialized
ERROR - 2023-09-07 19:28:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:28:48 --> Output Class Initialized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
ERROR - 2023-09-07 19:28:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:28:48 --> Router Class Initialized
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:48 --> Config Class Initialized
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Hooks Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
INFO - 2023-09-07 19:28:48 --> Output Class Initialized
INFO - 2023-09-07 19:28:48 --> Security Class Initialized
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:28:48 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:28:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Input Class Initialized
INFO - 2023-09-07 19:28:48 --> Utf8 Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> URI Class Initialized
INFO - 2023-09-07 19:28:48 --> Language Class Initialized
INFO - 2023-09-07 19:28:48 --> Router Class Initialized
ERROR - 2023-09-07 19:28:49 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:28:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:28:49 --> Output Class Initialized
INFO - 2023-09-07 19:28:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:28:49 --> Input Class Initialized
INFO - 2023-09-07 19:28:49 --> Language Class Initialized
ERROR - 2023-09-07 19:28:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:30:07 --> Config Class Initialized
INFO - 2023-09-07 19:30:07 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:07 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:07 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:07 --> URI Class Initialized
DEBUG - 2023-09-07 19:30:08 --> No URI present. Default controller set.
INFO - 2023-09-07 19:30:08 --> Router Class Initialized
INFO - 2023-09-07 19:30:08 --> Output Class Initialized
INFO - 2023-09-07 19:30:08 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:08 --> Input Class Initialized
INFO - 2023-09-07 19:30:08 --> Language Class Initialized
INFO - 2023-09-07 19:30:08 --> Loader Class Initialized
INFO - 2023-09-07 19:30:08 --> Helper loaded: url_helper
INFO - 2023-09-07 19:30:08 --> Helper loaded: file_helper
INFO - 2023-09-07 19:30:08 --> Database Driver Class Initialized
INFO - 2023-09-07 19:30:08 --> Email Class Initialized
DEBUG - 2023-09-07 19:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:30:08 --> Controller Class Initialized
INFO - 2023-09-07 19:30:08 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:30:08 --> Model "Home_model" initialized
INFO - 2023-09-07 19:30:08 --> Helper loaded: download_helper
INFO - 2023-09-07 19:30:08 --> Helper loaded: form_helper
INFO - 2023-09-07 19:30:08 --> Form Validation Class Initialized
INFO - 2023-09-07 19:30:08 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:30:08 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:30:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:30:08 --> Final output sent to browser
DEBUG - 2023-09-07 19:30:08 --> Total execution time: 0.5003
INFO - 2023-09-07 19:30:10 --> Config Class Initialized
INFO - 2023-09-07 19:30:11 --> Hooks Class Initialized
INFO - 2023-09-07 19:30:11 --> Config Class Initialized
INFO - 2023-09-07 19:30:11 --> Hooks Class Initialized
INFO - 2023-09-07 19:30:12 --> Config Class Initialized
INFO - 2023-09-07 19:30:12 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:12 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:12 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:12 --> URI Class Initialized
INFO - 2023-09-07 19:30:12 --> Router Class Initialized
INFO - 2023-09-07 19:30:12 --> Output Class Initialized
INFO - 2023-09-07 19:30:12 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:12 --> Input Class Initialized
INFO - 2023-09-07 19:30:12 --> Language Class Initialized
ERROR - 2023-09-07 19:30:12 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:30:12 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:12 --> Config Class Initialized
INFO - 2023-09-07 19:30:12 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:12 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:12 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:12 --> URI Class Initialized
INFO - 2023-09-07 19:30:12 --> Router Class Initialized
INFO - 2023-09-07 19:30:12 --> Output Class Initialized
INFO - 2023-09-07 19:30:12 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:12 --> Input Class Initialized
INFO - 2023-09-07 19:30:12 --> Language Class Initialized
ERROR - 2023-09-07 19:30:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:30:12 --> Config Class Initialized
INFO - 2023-09-07 19:30:12 --> Config Class Initialized
DEBUG - 2023-09-07 19:30:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:13 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:13 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:13 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:13 --> URI Class Initialized
INFO - 2023-09-07 19:30:13 --> Router Class Initialized
INFO - 2023-09-07 19:30:13 --> Output Class Initialized
INFO - 2023-09-07 19:30:13 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:13 --> Input Class Initialized
INFO - 2023-09-07 19:30:13 --> Language Class Initialized
ERROR - 2023-09-07 19:30:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:30:13 --> Hooks Class Initialized
INFO - 2023-09-07 19:30:13 --> URI Class Initialized
DEBUG - 2023-09-07 19:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:13 --> Router Class Initialized
INFO - 2023-09-07 19:30:13 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:14 --> URI Class Initialized
INFO - 2023-09-07 19:30:14 --> URI Class Initialized
INFO - 2023-09-07 19:30:14 --> Output Class Initialized
INFO - 2023-09-07 19:30:14 --> Router Class Initialized
INFO - 2023-09-07 19:30:14 --> Security Class Initialized
INFO - 2023-09-07 19:30:14 --> Output Class Initialized
INFO - 2023-09-07 19:30:14 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:14 --> Router Class Initialized
INFO - 2023-09-07 19:30:14 --> Output Class Initialized
INFO - 2023-09-07 19:30:14 --> Input Class Initialized
INFO - 2023-09-07 19:30:14 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:14 --> Input Class Initialized
INFO - 2023-09-07 19:30:14 --> Input Class Initialized
INFO - 2023-09-07 19:30:14 --> Language Class Initialized
INFO - 2023-09-07 19:30:14 --> Language Class Initialized
INFO - 2023-09-07 19:30:14 --> Language Class Initialized
ERROR - 2023-09-07 19:30:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:30:14 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:30:14 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:30:14 --> Config Class Initialized
INFO - 2023-09-07 19:30:14 --> Config Class Initialized
INFO - 2023-09-07 19:30:15 --> Hooks Class Initialized
INFO - 2023-09-07 19:30:15 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:30:15 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:15 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:15 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:15 --> URI Class Initialized
INFO - 2023-09-07 19:30:15 --> URI Class Initialized
INFO - 2023-09-07 19:30:15 --> Router Class Initialized
INFO - 2023-09-07 19:30:15 --> Router Class Initialized
INFO - 2023-09-07 19:30:15 --> Output Class Initialized
INFO - 2023-09-07 19:30:15 --> Output Class Initialized
INFO - 2023-09-07 19:30:15 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:15 --> Security Class Initialized
INFO - 2023-09-07 19:30:15 --> Input Class Initialized
DEBUG - 2023-09-07 19:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:15 --> Language Class Initialized
ERROR - 2023-09-07 19:30:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:30:15 --> Input Class Initialized
INFO - 2023-09-07 19:30:15 --> Language Class Initialized
ERROR - 2023-09-07 19:30:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:30:46 --> Config Class Initialized
INFO - 2023-09-07 19:30:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:46 --> URI Class Initialized
DEBUG - 2023-09-07 19:30:46 --> No URI present. Default controller set.
INFO - 2023-09-07 19:30:46 --> Router Class Initialized
INFO - 2023-09-07 19:30:46 --> Output Class Initialized
INFO - 2023-09-07 19:30:46 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:46 --> Input Class Initialized
INFO - 2023-09-07 19:30:46 --> Language Class Initialized
INFO - 2023-09-07 19:30:46 --> Loader Class Initialized
INFO - 2023-09-07 19:30:46 --> Helper loaded: url_helper
INFO - 2023-09-07 19:30:46 --> Helper loaded: file_helper
INFO - 2023-09-07 19:30:46 --> Database Driver Class Initialized
INFO - 2023-09-07 19:30:46 --> Email Class Initialized
DEBUG - 2023-09-07 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:30:46 --> Controller Class Initialized
INFO - 2023-09-07 19:30:46 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:30:46 --> Model "Home_model" initialized
INFO - 2023-09-07 19:30:46 --> Helper loaded: download_helper
INFO - 2023-09-07 19:30:46 --> Helper loaded: form_helper
INFO - 2023-09-07 19:30:46 --> Form Validation Class Initialized
INFO - 2023-09-07 19:30:46 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:30:46 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:30:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:30:47 --> Final output sent to browser
DEBUG - 2023-09-07 19:30:47 --> Total execution time: 0.7148
INFO - 2023-09-07 19:30:48 --> Config Class Initialized
INFO - 2023-09-07 19:30:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:30:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:30:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:30:49 --> URI Class Initialized
INFO - 2023-09-07 19:30:49 --> Router Class Initialized
INFO - 2023-09-07 19:30:49 --> Output Class Initialized
INFO - 2023-09-07 19:30:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:30:49 --> Input Class Initialized
INFO - 2023-09-07 19:30:49 --> Language Class Initialized
ERROR - 2023-09-07 19:30:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:32:19 --> Config Class Initialized
INFO - 2023-09-07 19:32:19 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:32:19 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:32:19 --> Utf8 Class Initialized
INFO - 2023-09-07 19:32:19 --> URI Class Initialized
DEBUG - 2023-09-07 19:32:19 --> No URI present. Default controller set.
INFO - 2023-09-07 19:32:19 --> Router Class Initialized
INFO - 2023-09-07 19:32:19 --> Output Class Initialized
INFO - 2023-09-07 19:32:19 --> Security Class Initialized
DEBUG - 2023-09-07 19:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:32:19 --> Input Class Initialized
INFO - 2023-09-07 19:32:19 --> Language Class Initialized
INFO - 2023-09-07 19:32:19 --> Loader Class Initialized
INFO - 2023-09-07 19:32:19 --> Helper loaded: url_helper
INFO - 2023-09-07 19:32:19 --> Helper loaded: file_helper
INFO - 2023-09-07 19:32:19 --> Database Driver Class Initialized
INFO - 2023-09-07 19:32:19 --> Email Class Initialized
DEBUG - 2023-09-07 19:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:32:19 --> Controller Class Initialized
INFO - 2023-09-07 19:32:19 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:32:19 --> Model "Home_model" initialized
INFO - 2023-09-07 19:32:19 --> Helper loaded: download_helper
INFO - 2023-09-07 19:32:19 --> Helper loaded: form_helper
INFO - 2023-09-07 19:32:19 --> Form Validation Class Initialized
INFO - 2023-09-07 19:32:19 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:32:19 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:32:19 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:32:19 --> Final output sent to browser
DEBUG - 2023-09-07 19:32:20 --> Total execution time: 0.7355
INFO - 2023-09-07 19:32:20 --> Config Class Initialized
INFO - 2023-09-07 19:32:21 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:32:21 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:32:21 --> Utf8 Class Initialized
INFO - 2023-09-07 19:32:21 --> URI Class Initialized
INFO - 2023-09-07 19:32:21 --> Router Class Initialized
INFO - 2023-09-07 19:32:21 --> Output Class Initialized
INFO - 2023-09-07 19:32:21 --> Security Class Initialized
DEBUG - 2023-09-07 19:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:32:21 --> Input Class Initialized
INFO - 2023-09-07 19:32:21 --> Language Class Initialized
ERROR - 2023-09-07 19:32:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:33:02 --> Config Class Initialized
INFO - 2023-09-07 19:33:02 --> Config Class Initialized
INFO - 2023-09-07 19:33:02 --> Hooks Class Initialized
INFO - 2023-09-07 19:33:02 --> Config Class Initialized
INFO - 2023-09-07 19:33:02 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:33:02 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:33:02 --> Config Class Initialized
DEBUG - 2023-09-07 19:33:02 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:33:03 --> Hooks Class Initialized
INFO - 2023-09-07 19:33:03 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:33:03 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:33:03 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Config Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Config Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Hooks Class Initialized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Hooks Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
DEBUG - 2023-09-07 19:33:03 --> UTF-8 Support Enabled
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
INFO - 2023-09-07 19:33:03 --> Config Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> Hooks Class Initialized
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
DEBUG - 2023-09-07 19:33:03 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
INFO - 2023-09-07 19:33:03 --> Utf8 Class Initialized
INFO - 2023-09-07 19:33:03 --> URI Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Router Class Initialized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Output Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Security Class Initialized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
DEBUG - 2023-09-07 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
INFO - 2023-09-07 19:33:03 --> Input Class Initialized
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:33:03 --> Language Class Initialized
ERROR - 2023-09-07 19:33:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:36:23 --> Config Class Initialized
INFO - 2023-09-07 19:36:23 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:36:24 --> Utf8 Class Initialized
INFO - 2023-09-07 19:36:24 --> URI Class Initialized
DEBUG - 2023-09-07 19:36:24 --> No URI present. Default controller set.
INFO - 2023-09-07 19:36:24 --> Router Class Initialized
INFO - 2023-09-07 19:36:24 --> Output Class Initialized
INFO - 2023-09-07 19:36:24 --> Security Class Initialized
DEBUG - 2023-09-07 19:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:36:24 --> Input Class Initialized
INFO - 2023-09-07 19:36:24 --> Language Class Initialized
INFO - 2023-09-07 19:36:24 --> Loader Class Initialized
INFO - 2023-09-07 19:36:24 --> Helper loaded: url_helper
INFO - 2023-09-07 19:36:24 --> Helper loaded: file_helper
INFO - 2023-09-07 19:36:24 --> Database Driver Class Initialized
INFO - 2023-09-07 19:36:24 --> Email Class Initialized
DEBUG - 2023-09-07 19:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:36:24 --> Controller Class Initialized
INFO - 2023-09-07 19:36:24 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:36:24 --> Model "Home_model" initialized
INFO - 2023-09-07 19:36:24 --> Helper loaded: download_helper
INFO - 2023-09-07 19:36:24 --> Helper loaded: form_helper
INFO - 2023-09-07 19:36:25 --> Form Validation Class Initialized
INFO - 2023-09-07 19:36:25 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:36:25 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:36:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:36:25 --> Final output sent to browser
DEBUG - 2023-09-07 19:36:25 --> Total execution time: 1.3032
INFO - 2023-09-07 19:36:27 --> Config Class Initialized
INFO - 2023-09-07 19:36:28 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:36:28 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:36:29 --> Utf8 Class Initialized
INFO - 2023-09-07 19:36:29 --> URI Class Initialized
INFO - 2023-09-07 19:36:29 --> Router Class Initialized
INFO - 2023-09-07 19:36:29 --> Output Class Initialized
INFO - 2023-09-07 19:36:29 --> Security Class Initialized
DEBUG - 2023-09-07 19:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:36:29 --> Input Class Initialized
INFO - 2023-09-07 19:36:29 --> Language Class Initialized
ERROR - 2023-09-07 19:36:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:36:45 --> Config Class Initialized
INFO - 2023-09-07 19:36:45 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:36:45 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:36:45 --> Utf8 Class Initialized
INFO - 2023-09-07 19:36:45 --> URI Class Initialized
DEBUG - 2023-09-07 19:36:45 --> No URI present. Default controller set.
INFO - 2023-09-07 19:36:45 --> Router Class Initialized
INFO - 2023-09-07 19:36:45 --> Output Class Initialized
INFO - 2023-09-07 19:36:45 --> Security Class Initialized
DEBUG - 2023-09-07 19:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:36:46 --> Input Class Initialized
INFO - 2023-09-07 19:36:46 --> Language Class Initialized
INFO - 2023-09-07 19:36:46 --> Loader Class Initialized
INFO - 2023-09-07 19:36:46 --> Helper loaded: url_helper
INFO - 2023-09-07 19:36:46 --> Helper loaded: file_helper
INFO - 2023-09-07 19:36:46 --> Database Driver Class Initialized
INFO - 2023-09-07 19:36:46 --> Email Class Initialized
DEBUG - 2023-09-07 19:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:36:46 --> Controller Class Initialized
INFO - 2023-09-07 19:36:46 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:36:46 --> Model "Home_model" initialized
INFO - 2023-09-07 19:36:46 --> Helper loaded: download_helper
INFO - 2023-09-07 19:36:46 --> Helper loaded: form_helper
INFO - 2023-09-07 19:36:46 --> Form Validation Class Initialized
INFO - 2023-09-07 19:36:46 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:36:46 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:36:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:36:46 --> Final output sent to browser
DEBUG - 2023-09-07 19:36:46 --> Total execution time: 0.5443
INFO - 2023-09-07 19:36:48 --> Config Class Initialized
INFO - 2023-09-07 19:36:48 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:36:48 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:36:48 --> Utf8 Class Initialized
INFO - 2023-09-07 19:36:48 --> URI Class Initialized
INFO - 2023-09-07 19:36:48 --> Router Class Initialized
INFO - 2023-09-07 19:36:48 --> Output Class Initialized
INFO - 2023-09-07 19:36:48 --> Security Class Initialized
DEBUG - 2023-09-07 19:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:36:48 --> Input Class Initialized
INFO - 2023-09-07 19:36:48 --> Language Class Initialized
ERROR - 2023-09-07 19:36:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:37:03 --> Config Class Initialized
INFO - 2023-09-07 19:37:03 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:37:03 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:37:04 --> Utf8 Class Initialized
INFO - 2023-09-07 19:37:04 --> URI Class Initialized
DEBUG - 2023-09-07 19:37:04 --> No URI present. Default controller set.
INFO - 2023-09-07 19:37:04 --> Router Class Initialized
INFO - 2023-09-07 19:37:04 --> Output Class Initialized
INFO - 2023-09-07 19:37:04 --> Security Class Initialized
DEBUG - 2023-09-07 19:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:37:04 --> Input Class Initialized
INFO - 2023-09-07 19:37:04 --> Language Class Initialized
INFO - 2023-09-07 19:37:04 --> Loader Class Initialized
INFO - 2023-09-07 19:37:04 --> Helper loaded: url_helper
INFO - 2023-09-07 19:37:04 --> Helper loaded: file_helper
INFO - 2023-09-07 19:37:04 --> Database Driver Class Initialized
INFO - 2023-09-07 19:37:04 --> Email Class Initialized
DEBUG - 2023-09-07 19:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:37:04 --> Controller Class Initialized
INFO - 2023-09-07 19:37:04 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:37:04 --> Model "Home_model" initialized
INFO - 2023-09-07 19:37:04 --> Helper loaded: download_helper
INFO - 2023-09-07 19:37:04 --> Helper loaded: form_helper
INFO - 2023-09-07 19:37:04 --> Form Validation Class Initialized
INFO - 2023-09-07 19:37:04 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:37:04 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:37:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:37:04 --> Final output sent to browser
DEBUG - 2023-09-07 19:37:04 --> Total execution time: 0.4160
INFO - 2023-09-07 19:37:06 --> Config Class Initialized
INFO - 2023-09-07 19:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:37:07 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:37:07 --> Utf8 Class Initialized
INFO - 2023-09-07 19:37:07 --> URI Class Initialized
INFO - 2023-09-07 19:37:07 --> Router Class Initialized
INFO - 2023-09-07 19:37:07 --> Output Class Initialized
INFO - 2023-09-07 19:37:07 --> Security Class Initialized
DEBUG - 2023-09-07 19:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:37:07 --> Input Class Initialized
INFO - 2023-09-07 19:37:07 --> Language Class Initialized
ERROR - 2023-09-07 19:37:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:38:25 --> Config Class Initialized
INFO - 2023-09-07 19:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:38:25 --> Utf8 Class Initialized
INFO - 2023-09-07 19:38:25 --> URI Class Initialized
INFO - 2023-09-07 19:38:25 --> Router Class Initialized
INFO - 2023-09-07 19:38:25 --> Output Class Initialized
INFO - 2023-09-07 19:38:25 --> Security Class Initialized
DEBUG - 2023-09-07 19:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:38:25 --> Input Class Initialized
INFO - 2023-09-07 19:38:25 --> Language Class Initialized
INFO - 2023-09-07 19:38:25 --> Loader Class Initialized
INFO - 2023-09-07 19:38:25 --> Helper loaded: url_helper
INFO - 2023-09-07 19:38:25 --> Helper loaded: file_helper
INFO - 2023-09-07 19:38:25 --> Database Driver Class Initialized
INFO - 2023-09-07 19:38:25 --> Email Class Initialized
DEBUG - 2023-09-07 19:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:38:25 --> Controller Class Initialized
INFO - 2023-09-07 19:38:25 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:38:25 --> Model "Home_model" initialized
INFO - 2023-09-07 19:38:25 --> Helper loaded: download_helper
INFO - 2023-09-07 19:38:25 --> Helper loaded: form_helper
INFO - 2023-09-07 19:38:25 --> Form Validation Class Initialized
INFO - 2023-09-07 19:38:25 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:38:25 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:38:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:38:25 --> Final output sent to browser
DEBUG - 2023-09-07 19:38:25 --> Total execution time: 0.5200
INFO - 2023-09-07 19:38:26 --> Config Class Initialized
INFO - 2023-09-07 19:38:26 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:38:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:38:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:38:26 --> URI Class Initialized
INFO - 2023-09-07 19:38:26 --> Router Class Initialized
INFO - 2023-09-07 19:38:26 --> Output Class Initialized
INFO - 2023-09-07 19:38:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:38:27 --> Input Class Initialized
INFO - 2023-09-07 19:38:27 --> Language Class Initialized
ERROR - 2023-09-07 19:38:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:25 --> Config Class Initialized
INFO - 2023-09-07 19:43:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:25 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:25 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:25 --> URI Class Initialized
INFO - 2023-09-07 19:43:26 --> Router Class Initialized
INFO - 2023-09-07 19:43:26 --> Output Class Initialized
INFO - 2023-09-07 19:43:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:26 --> Input Class Initialized
INFO - 2023-09-07 19:43:26 --> Language Class Initialized
INFO - 2023-09-07 19:43:26 --> Loader Class Initialized
INFO - 2023-09-07 19:43:26 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:26 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:26 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:26 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:26 --> Controller Class Initialized
INFO - 2023-09-07 19:43:26 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:26 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:26 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:26 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:26 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:26 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:26 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:43:26 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:26 --> Total execution time: 0.5260
INFO - 2023-09-07 19:43:27 --> Config Class Initialized
INFO - 2023-09-07 19:43:27 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:27 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:27 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:27 --> URI Class Initialized
INFO - 2023-09-07 19:43:27 --> Router Class Initialized
INFO - 2023-09-07 19:43:27 --> Output Class Initialized
INFO - 2023-09-07 19:43:27 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:27 --> Input Class Initialized
INFO - 2023-09-07 19:43:27 --> Language Class Initialized
ERROR - 2023-09-07 19:43:27 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:35 --> Config Class Initialized
INFO - 2023-09-07 19:43:35 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:35 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:35 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:35 --> URI Class Initialized
DEBUG - 2023-09-07 19:43:35 --> No URI present. Default controller set.
INFO - 2023-09-07 19:43:35 --> Router Class Initialized
INFO - 2023-09-07 19:43:35 --> Output Class Initialized
INFO - 2023-09-07 19:43:35 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:35 --> Input Class Initialized
INFO - 2023-09-07 19:43:36 --> Language Class Initialized
INFO - 2023-09-07 19:43:36 --> Loader Class Initialized
INFO - 2023-09-07 19:43:36 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:36 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:36 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:36 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:36 --> Controller Class Initialized
INFO - 2023-09-07 19:43:36 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:36 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:36 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:36 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:36 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:36 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:36 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:43:36 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:36 --> Total execution time: 0.3976
INFO - 2023-09-07 19:43:37 --> Config Class Initialized
INFO - 2023-09-07 19:43:37 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:37 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:37 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:37 --> URI Class Initialized
INFO - 2023-09-07 19:43:37 --> Router Class Initialized
INFO - 2023-09-07 19:43:37 --> Output Class Initialized
INFO - 2023-09-07 19:43:37 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:37 --> Input Class Initialized
INFO - 2023-09-07 19:43:37 --> Language Class Initialized
ERROR - 2023-09-07 19:43:37 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:38 --> Config Class Initialized
INFO - 2023-09-07 19:43:38 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:38 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:38 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:38 --> URI Class Initialized
INFO - 2023-09-07 19:43:38 --> Router Class Initialized
INFO - 2023-09-07 19:43:38 --> Output Class Initialized
INFO - 2023-09-07 19:43:39 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:39 --> Input Class Initialized
INFO - 2023-09-07 19:43:39 --> Language Class Initialized
INFO - 2023-09-07 19:43:39 --> Loader Class Initialized
INFO - 2023-09-07 19:43:39 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:39 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:39 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:39 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:39 --> Controller Class Initialized
INFO - 2023-09-07 19:43:39 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:39 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:39 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:39 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:39 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:39 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:39 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:43:39 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:39 --> Total execution time: 0.3913
INFO - 2023-09-07 19:43:40 --> Config Class Initialized
INFO - 2023-09-07 19:43:40 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:40 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:40 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:40 --> URI Class Initialized
INFO - 2023-09-07 19:43:40 --> Router Class Initialized
INFO - 2023-09-07 19:43:40 --> Output Class Initialized
INFO - 2023-09-07 19:43:40 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:40 --> Input Class Initialized
INFO - 2023-09-07 19:43:40 --> Language Class Initialized
ERROR - 2023-09-07 19:43:40 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:42 --> Config Class Initialized
INFO - 2023-09-07 19:43:42 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:42 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:42 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:42 --> URI Class Initialized
INFO - 2023-09-07 19:43:42 --> Router Class Initialized
INFO - 2023-09-07 19:43:42 --> Output Class Initialized
INFO - 2023-09-07 19:43:42 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:42 --> Input Class Initialized
INFO - 2023-09-07 19:43:42 --> Language Class Initialized
INFO - 2023-09-07 19:43:42 --> Loader Class Initialized
INFO - 2023-09-07 19:43:42 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:42 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:42 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:42 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:42 --> Controller Class Initialized
INFO - 2023-09-07 19:43:42 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:42 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:42 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:42 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:42 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:42 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:42 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-07 19:43:42 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:42 --> Total execution time: 0.3871
INFO - 2023-09-07 19:43:43 --> Config Class Initialized
INFO - 2023-09-07 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:43 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:43 --> URI Class Initialized
INFO - 2023-09-07 19:43:43 --> Router Class Initialized
INFO - 2023-09-07 19:43:43 --> Output Class Initialized
INFO - 2023-09-07 19:43:43 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:43 --> Input Class Initialized
INFO - 2023-09-07 19:43:43 --> Language Class Initialized
ERROR - 2023-09-07 19:43:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:43 --> Config Class Initialized
INFO - 2023-09-07 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:43 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:43 --> URI Class Initialized
INFO - 2023-09-07 19:43:43 --> Router Class Initialized
INFO - 2023-09-07 19:43:43 --> Output Class Initialized
INFO - 2023-09-07 19:43:43 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:43 --> Input Class Initialized
INFO - 2023-09-07 19:43:43 --> Language Class Initialized
ERROR - 2023-09-07 19:43:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:43 --> Config Class Initialized
INFO - 2023-09-07 19:43:43 --> Config Class Initialized
INFO - 2023-09-07 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:43 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:43 --> URI Class Initialized
INFO - 2023-09-07 19:43:43 --> Router Class Initialized
INFO - 2023-09-07 19:43:43 --> Output Class Initialized
INFO - 2023-09-07 19:43:43 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:43 --> Input Class Initialized
INFO - 2023-09-07 19:43:43 --> Language Class Initialized
ERROR - 2023-09-07 19:43:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:43 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:43 --> URI Class Initialized
INFO - 2023-09-07 19:43:43 --> Router Class Initialized
INFO - 2023-09-07 19:43:43 --> Output Class Initialized
INFO - 2023-09-07 19:43:43 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:43 --> Input Class Initialized
INFO - 2023-09-07 19:43:43 --> Language Class Initialized
ERROR - 2023-09-07 19:43:43 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:43 --> Config Class Initialized
INFO - 2023-09-07 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:43 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:43 --> URI Class Initialized
INFO - 2023-09-07 19:43:43 --> Router Class Initialized
INFO - 2023-09-07 19:43:43 --> Output Class Initialized
INFO - 2023-09-07 19:43:43 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:43 --> Input Class Initialized
INFO - 2023-09-07 19:43:43 --> Language Class Initialized
ERROR - 2023-09-07 19:43:44 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:44 --> Config Class Initialized
INFO - 2023-09-07 19:43:44 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:44 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:44 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:44 --> URI Class Initialized
INFO - 2023-09-07 19:43:44 --> Router Class Initialized
INFO - 2023-09-07 19:43:44 --> Output Class Initialized
INFO - 2023-09-07 19:43:44 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:44 --> Input Class Initialized
INFO - 2023-09-07 19:43:44 --> Language Class Initialized
ERROR - 2023-09-07 19:43:44 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:44 --> Config Class Initialized
INFO - 2023-09-07 19:43:44 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:44 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:44 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:44 --> URI Class Initialized
INFO - 2023-09-07 19:43:44 --> Router Class Initialized
INFO - 2023-09-07 19:43:44 --> Output Class Initialized
INFO - 2023-09-07 19:43:44 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:44 --> Input Class Initialized
INFO - 2023-09-07 19:43:44 --> Language Class Initialized
ERROR - 2023-09-07 19:43:44 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:46 --> Config Class Initialized
INFO - 2023-09-07 19:43:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:46 --> URI Class Initialized
INFO - 2023-09-07 19:43:46 --> Router Class Initialized
INFO - 2023-09-07 19:43:46 --> Output Class Initialized
INFO - 2023-09-07 19:43:46 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:46 --> Input Class Initialized
INFO - 2023-09-07 19:43:46 --> Language Class Initialized
INFO - 2023-09-07 19:43:46 --> Loader Class Initialized
INFO - 2023-09-07 19:43:46 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:46 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:46 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:46 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:46 --> Controller Class Initialized
INFO - 2023-09-07 19:43:46 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:46 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:46 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:46 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:46 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:46 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:46 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 19:43:46 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:46 --> Total execution time: 0.0879
INFO - 2023-09-07 19:43:46 --> Config Class Initialized
INFO - 2023-09-07 19:43:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:46 --> URI Class Initialized
INFO - 2023-09-07 19:43:46 --> Router Class Initialized
INFO - 2023-09-07 19:43:46 --> Output Class Initialized
INFO - 2023-09-07 19:43:46 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:46 --> Input Class Initialized
INFO - 2023-09-07 19:43:46 --> Language Class Initialized
ERROR - 2023-09-07 19:43:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
INFO - 2023-09-07 19:43:49 --> Loader Class Initialized
INFO - 2023-09-07 19:43:49 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:49 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:49 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:49 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:49 --> Controller Class Initialized
INFO - 2023-09-07 19:43:49 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:49 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:49 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:49 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:49 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:49 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:49 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-07 19:43:49 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:49 --> Total execution time: 0.0471
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:49 --> Config Class Initialized
INFO - 2023-09-07 19:43:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:49 --> URI Class Initialized
INFO - 2023-09-07 19:43:49 --> Router Class Initialized
INFO - 2023-09-07 19:43:49 --> Output Class Initialized
INFO - 2023-09-07 19:43:49 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:49 --> Input Class Initialized
INFO - 2023-09-07 19:43:49 --> Language Class Initialized
ERROR - 2023-09-07 19:43:49 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:50 --> Config Class Initialized
INFO - 2023-09-07 19:43:50 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:50 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:50 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:50 --> URI Class Initialized
INFO - 2023-09-07 19:43:50 --> Router Class Initialized
INFO - 2023-09-07 19:43:50 --> Output Class Initialized
INFO - 2023-09-07 19:43:50 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:50 --> Input Class Initialized
INFO - 2023-09-07 19:43:50 --> Language Class Initialized
ERROR - 2023-09-07 19:43:50 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:52 --> Config Class Initialized
INFO - 2023-09-07 19:43:52 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:52 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:52 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:52 --> URI Class Initialized
INFO - 2023-09-07 19:43:52 --> Router Class Initialized
INFO - 2023-09-07 19:43:52 --> Output Class Initialized
INFO - 2023-09-07 19:43:52 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:52 --> Input Class Initialized
INFO - 2023-09-07 19:43:52 --> Language Class Initialized
INFO - 2023-09-07 19:43:52 --> Loader Class Initialized
INFO - 2023-09-07 19:43:52 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:52 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:52 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:52 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:52 --> Controller Class Initialized
INFO - 2023-09-07 19:43:52 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:52 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:52 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:52 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:52 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:52 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:52 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:43:52 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:52 --> Total execution time: 0.0483
INFO - 2023-09-07 19:43:53 --> Config Class Initialized
INFO - 2023-09-07 19:43:53 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:53 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:53 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:53 --> URI Class Initialized
INFO - 2023-09-07 19:43:53 --> Router Class Initialized
INFO - 2023-09-07 19:43:53 --> Output Class Initialized
INFO - 2023-09-07 19:43:53 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:53 --> Input Class Initialized
INFO - 2023-09-07 19:43:53 --> Language Class Initialized
ERROR - 2023-09-07 19:43:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:55 --> Config Class Initialized
INFO - 2023-09-07 19:43:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:56 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:56 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:56 --> URI Class Initialized
INFO - 2023-09-07 19:43:56 --> Router Class Initialized
INFO - 2023-09-07 19:43:56 --> Output Class Initialized
INFO - 2023-09-07 19:43:56 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:56 --> Input Class Initialized
INFO - 2023-09-07 19:43:56 --> Language Class Initialized
INFO - 2023-09-07 19:43:56 --> Loader Class Initialized
INFO - 2023-09-07 19:43:56 --> Helper loaded: url_helper
INFO - 2023-09-07 19:43:56 --> Helper loaded: file_helper
INFO - 2023-09-07 19:43:56 --> Database Driver Class Initialized
INFO - 2023-09-07 19:43:56 --> Email Class Initialized
DEBUG - 2023-09-07 19:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:43:56 --> Controller Class Initialized
INFO - 2023-09-07 19:43:56 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:43:56 --> Model "Home_model" initialized
INFO - 2023-09-07 19:43:56 --> Helper loaded: download_helper
INFO - 2023-09-07 19:43:56 --> Helper loaded: form_helper
INFO - 2023-09-07 19:43:56 --> Form Validation Class Initialized
INFO - 2023-09-07 19:43:56 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:43:56 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:43:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-07 19:43:56 --> Final output sent to browser
DEBUG - 2023-09-07 19:43:56 --> Total execution time: 0.6988
INFO - 2023-09-07 19:43:57 --> Config Class Initialized
INFO - 2023-09-07 19:43:57 --> Hooks Class Initialized
INFO - 2023-09-07 19:43:57 --> Config Class Initialized
DEBUG - 2023-09-07 19:43:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:57 --> Config Class Initialized
INFO - 2023-09-07 19:43:57 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:57 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:57 --> Hooks Class Initialized
INFO - 2023-09-07 19:43:57 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:43:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:57 --> URI Class Initialized
INFO - 2023-09-07 19:43:57 --> URI Class Initialized
INFO - 2023-09-07 19:43:57 --> Router Class Initialized
INFO - 2023-09-07 19:43:57 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:57 --> Output Class Initialized
INFO - 2023-09-07 19:43:57 --> Router Class Initialized
INFO - 2023-09-07 19:43:57 --> Output Class Initialized
INFO - 2023-09-07 19:43:57 --> URI Class Initialized
INFO - 2023-09-07 19:43:57 --> Router Class Initialized
INFO - 2023-09-07 19:43:57 --> Security Class Initialized
INFO - 2023-09-07 19:43:57 --> Output Class Initialized
DEBUG - 2023-09-07 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:57 --> Security Class Initialized
INFO - 2023-09-07 19:43:57 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:57 --> Input Class Initialized
INFO - 2023-09-07 19:43:57 --> Input Class Initialized
INFO - 2023-09-07 19:43:57 --> Language Class Initialized
INFO - 2023-09-07 19:43:57 --> Language Class Initialized
ERROR - 2023-09-07 19:43:57 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-07 19:43:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:57 --> Input Class Initialized
INFO - 2023-09-07 19:43:57 --> Language Class Initialized
ERROR - 2023-09-07 19:43:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:57 --> Config Class Initialized
INFO - 2023-09-07 19:43:57 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:57 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:57 --> URI Class Initialized
INFO - 2023-09-07 19:43:57 --> Router Class Initialized
INFO - 2023-09-07 19:43:57 --> Output Class Initialized
INFO - 2023-09-07 19:43:57 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:57 --> Input Class Initialized
INFO - 2023-09-07 19:43:57 --> Language Class Initialized
ERROR - 2023-09-07 19:43:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:57 --> Config Class Initialized
INFO - 2023-09-07 19:43:58 --> Config Class Initialized
INFO - 2023-09-07 19:43:58 --> Config Class Initialized
INFO - 2023-09-07 19:43:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:43:58 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:58 --> URI Class Initialized
INFO - 2023-09-07 19:43:58 --> Router Class Initialized
INFO - 2023-09-07 19:43:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:43:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:58 --> Output Class Initialized
INFO - 2023-09-07 19:43:58 --> URI Class Initialized
INFO - 2023-09-07 19:43:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:43:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:43:58 --> Router Class Initialized
INFO - 2023-09-07 19:43:58 --> URI Class Initialized
INFO - 2023-09-07 19:43:58 --> Output Class Initialized
DEBUG - 2023-09-07 19:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:58 --> Input Class Initialized
INFO - 2023-09-07 19:43:58 --> Language Class Initialized
INFO - 2023-09-07 19:43:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:58 --> Router Class Initialized
ERROR - 2023-09-07 19:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:58 --> Input Class Initialized
INFO - 2023-09-07 19:43:58 --> Language Class Initialized
INFO - 2023-09-07 19:43:58 --> Output Class Initialized
ERROR - 2023-09-07 19:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:43:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:43:58 --> Input Class Initialized
INFO - 2023-09-07 19:43:58 --> Language Class Initialized
ERROR - 2023-09-07 19:43:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:44:00 --> Config Class Initialized
INFO - 2023-09-07 19:44:00 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:44:00 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:44:00 --> Utf8 Class Initialized
INFO - 2023-09-07 19:44:00 --> URI Class Initialized
INFO - 2023-09-07 19:44:00 --> Router Class Initialized
INFO - 2023-09-07 19:44:00 --> Output Class Initialized
INFO - 2023-09-07 19:44:00 --> Security Class Initialized
DEBUG - 2023-09-07 19:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:44:00 --> Input Class Initialized
INFO - 2023-09-07 19:44:00 --> Language Class Initialized
INFO - 2023-09-07 19:44:00 --> Loader Class Initialized
INFO - 2023-09-07 19:44:00 --> Helper loaded: url_helper
INFO - 2023-09-07 19:44:00 --> Helper loaded: file_helper
INFO - 2023-09-07 19:44:00 --> Database Driver Class Initialized
INFO - 2023-09-07 19:44:00 --> Email Class Initialized
DEBUG - 2023-09-07 19:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:44:00 --> Controller Class Initialized
INFO - 2023-09-07 19:44:00 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:44:00 --> Model "Home_model" initialized
INFO - 2023-09-07 19:44:00 --> Helper loaded: download_helper
INFO - 2023-09-07 19:44:00 --> Helper loaded: form_helper
INFO - 2023-09-07 19:44:00 --> Form Validation Class Initialized
INFO - 2023-09-07 19:44:00 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:44:00 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:44:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-07 19:44:01 --> Final output sent to browser
DEBUG - 2023-09-07 19:44:01 --> Total execution time: 0.3849
INFO - 2023-09-07 19:44:01 --> Config Class Initialized
INFO - 2023-09-07 19:44:01 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:44:01 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:44:01 --> Utf8 Class Initialized
INFO - 2023-09-07 19:44:01 --> URI Class Initialized
INFO - 2023-09-07 19:44:01 --> Router Class Initialized
INFO - 2023-09-07 19:44:01 --> Output Class Initialized
INFO - 2023-09-07 19:44:01 --> Security Class Initialized
DEBUG - 2023-09-07 19:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:44:01 --> Input Class Initialized
INFO - 2023-09-07 19:44:01 --> Language Class Initialized
ERROR - 2023-09-07 19:44:01 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:45:49 --> Config Class Initialized
INFO - 2023-09-07 19:45:49 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:45:49 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:45:49 --> Utf8 Class Initialized
INFO - 2023-09-07 19:45:49 --> URI Class Initialized
INFO - 2023-09-07 19:45:49 --> Router Class Initialized
INFO - 2023-09-07 19:45:49 --> Output Class Initialized
INFO - 2023-09-07 19:45:50 --> Security Class Initialized
DEBUG - 2023-09-07 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:45:50 --> Input Class Initialized
INFO - 2023-09-07 19:45:50 --> Language Class Initialized
INFO - 2023-09-07 19:45:50 --> Loader Class Initialized
INFO - 2023-09-07 19:45:50 --> Helper loaded: url_helper
INFO - 2023-09-07 19:45:50 --> Helper loaded: file_helper
INFO - 2023-09-07 19:45:50 --> Database Driver Class Initialized
INFO - 2023-09-07 19:45:50 --> Email Class Initialized
DEBUG - 2023-09-07 19:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:45:50 --> Controller Class Initialized
INFO - 2023-09-07 19:45:50 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:45:50 --> Model "Home_model" initialized
INFO - 2023-09-07 19:45:50 --> Helper loaded: download_helper
INFO - 2023-09-07 19:45:50 --> Helper loaded: form_helper
INFO - 2023-09-07 19:45:50 --> Form Validation Class Initialized
INFO - 2023-09-07 19:45:50 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:45:50 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:45:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:45:50 --> Final output sent to browser
DEBUG - 2023-09-07 19:45:50 --> Total execution time: 0.3537
INFO - 2023-09-07 19:45:51 --> Config Class Initialized
INFO - 2023-09-07 19:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:45:51 --> Utf8 Class Initialized
INFO - 2023-09-07 19:45:51 --> URI Class Initialized
INFO - 2023-09-07 19:45:51 --> Router Class Initialized
INFO - 2023-09-07 19:45:51 --> Output Class Initialized
INFO - 2023-09-07 19:45:51 --> Security Class Initialized
DEBUG - 2023-09-07 19:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:45:51 --> Input Class Initialized
INFO - 2023-09-07 19:45:51 --> Language Class Initialized
ERROR - 2023-09-07 19:45:51 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:47:25 --> Config Class Initialized
INFO - 2023-09-07 19:47:25 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:47:25 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:47:25 --> Utf8 Class Initialized
INFO - 2023-09-07 19:47:25 --> URI Class Initialized
INFO - 2023-09-07 19:47:25 --> Router Class Initialized
INFO - 2023-09-07 19:47:25 --> Output Class Initialized
INFO - 2023-09-07 19:47:25 --> Security Class Initialized
DEBUG - 2023-09-07 19:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:47:25 --> Input Class Initialized
INFO - 2023-09-07 19:47:25 --> Language Class Initialized
INFO - 2023-09-07 19:47:25 --> Loader Class Initialized
INFO - 2023-09-07 19:47:25 --> Helper loaded: url_helper
INFO - 2023-09-07 19:47:25 --> Helper loaded: file_helper
INFO - 2023-09-07 19:47:25 --> Database Driver Class Initialized
INFO - 2023-09-07 19:47:25 --> Email Class Initialized
DEBUG - 2023-09-07 19:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:47:25 --> Controller Class Initialized
INFO - 2023-09-07 19:47:25 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:47:25 --> Model "Home_model" initialized
INFO - 2023-09-07 19:47:25 --> Helper loaded: download_helper
INFO - 2023-09-07 19:47:25 --> Helper loaded: form_helper
INFO - 2023-09-07 19:47:25 --> Form Validation Class Initialized
INFO - 2023-09-07 19:47:25 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:47:25 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:47:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:47:25 --> Final output sent to browser
DEBUG - 2023-09-07 19:47:25 --> Total execution time: 0.4897
INFO - 2023-09-07 19:47:26 --> Config Class Initialized
INFO - 2023-09-07 19:47:26 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:47:26 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:47:26 --> Utf8 Class Initialized
INFO - 2023-09-07 19:47:26 --> URI Class Initialized
INFO - 2023-09-07 19:47:26 --> Router Class Initialized
INFO - 2023-09-07 19:47:26 --> Output Class Initialized
INFO - 2023-09-07 19:47:26 --> Security Class Initialized
DEBUG - 2023-09-07 19:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:47:26 --> Input Class Initialized
INFO - 2023-09-07 19:47:26 --> Language Class Initialized
ERROR - 2023-09-07 19:47:26 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:48:53 --> Config Class Initialized
INFO - 2023-09-07 19:48:53 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:48:53 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:48:53 --> Utf8 Class Initialized
INFO - 2023-09-07 19:48:53 --> URI Class Initialized
INFO - 2023-09-07 19:48:53 --> Router Class Initialized
INFO - 2023-09-07 19:48:53 --> Output Class Initialized
INFO - 2023-09-07 19:48:53 --> Security Class Initialized
DEBUG - 2023-09-07 19:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:48:54 --> Input Class Initialized
INFO - 2023-09-07 19:48:54 --> Language Class Initialized
INFO - 2023-09-07 19:48:54 --> Loader Class Initialized
INFO - 2023-09-07 19:48:54 --> Helper loaded: url_helper
INFO - 2023-09-07 19:48:54 --> Helper loaded: file_helper
INFO - 2023-09-07 19:48:54 --> Database Driver Class Initialized
INFO - 2023-09-07 19:48:54 --> Email Class Initialized
DEBUG - 2023-09-07 19:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:48:54 --> Controller Class Initialized
INFO - 2023-09-07 19:48:54 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:48:54 --> Model "Home_model" initialized
INFO - 2023-09-07 19:48:54 --> Helper loaded: download_helper
INFO - 2023-09-07 19:48:54 --> Helper loaded: form_helper
INFO - 2023-09-07 19:48:54 --> Form Validation Class Initialized
INFO - 2023-09-07 19:48:54 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:48:54 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:48:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-07 19:48:54 --> Final output sent to browser
DEBUG - 2023-09-07 19:48:54 --> Total execution time: 0.3523
INFO - 2023-09-07 19:48:55 --> Config Class Initialized
INFO - 2023-09-07 19:48:55 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:48:55 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:48:55 --> Utf8 Class Initialized
INFO - 2023-09-07 19:48:55 --> URI Class Initialized
INFO - 2023-09-07 19:48:55 --> Router Class Initialized
INFO - 2023-09-07 19:48:55 --> Output Class Initialized
INFO - 2023-09-07 19:48:55 --> Security Class Initialized
DEBUG - 2023-09-07 19:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:48:55 --> Input Class Initialized
INFO - 2023-09-07 19:48:55 --> Language Class Initialized
ERROR - 2023-09-07 19:48:55 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:49:44 --> Config Class Initialized
INFO - 2023-09-07 19:49:44 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:49:44 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:49:44 --> Utf8 Class Initialized
INFO - 2023-09-07 19:49:44 --> URI Class Initialized
INFO - 2023-09-07 19:49:44 --> Router Class Initialized
INFO - 2023-09-07 19:49:44 --> Output Class Initialized
INFO - 2023-09-07 19:49:44 --> Security Class Initialized
DEBUG - 2023-09-07 19:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:49:44 --> Input Class Initialized
INFO - 2023-09-07 19:49:45 --> Language Class Initialized
INFO - 2023-09-07 19:49:45 --> Loader Class Initialized
INFO - 2023-09-07 19:49:45 --> Helper loaded: url_helper
INFO - 2023-09-07 19:49:45 --> Helper loaded: file_helper
INFO - 2023-09-07 19:49:45 --> Database Driver Class Initialized
INFO - 2023-09-07 19:49:45 --> Email Class Initialized
DEBUG - 2023-09-07 19:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:49:45 --> Controller Class Initialized
INFO - 2023-09-07 19:49:45 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:49:45 --> Model "Home_model" initialized
INFO - 2023-09-07 19:49:45 --> Helper loaded: download_helper
INFO - 2023-09-07 19:49:45 --> Helper loaded: form_helper
INFO - 2023-09-07 19:49:45 --> Form Validation Class Initialized
INFO - 2023-09-07 19:49:45 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:49:45 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:49:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-07 19:49:45 --> Final output sent to browser
DEBUG - 2023-09-07 19:49:45 --> Total execution time: 0.6493
INFO - 2023-09-07 19:49:45 --> Config Class Initialized
INFO - 2023-09-07 19:49:45 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:49:45 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:49:45 --> Utf8 Class Initialized
INFO - 2023-09-07 19:49:45 --> URI Class Initialized
INFO - 2023-09-07 19:49:45 --> Router Class Initialized
INFO - 2023-09-07 19:49:45 --> Output Class Initialized
INFO - 2023-09-07 19:49:45 --> Security Class Initialized
DEBUG - 2023-09-07 19:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:49:45 --> Input Class Initialized
INFO - 2023-09-07 19:49:46 --> Language Class Initialized
ERROR - 2023-09-07 19:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:49:46 --> Config Class Initialized
INFO - 2023-09-07 19:49:46 --> Config Class Initialized
INFO - 2023-09-07 19:49:46 --> Hooks Class Initialized
INFO - 2023-09-07 19:49:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:49:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:49:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:49:46 --> URI Class Initialized
INFO - 2023-09-07 19:49:46 --> URI Class Initialized
INFO - 2023-09-07 19:49:46 --> Router Class Initialized
INFO - 2023-09-07 19:49:46 --> Router Class Initialized
INFO - 2023-09-07 19:49:46 --> Output Class Initialized
INFO - 2023-09-07 19:49:46 --> Security Class Initialized
INFO - 2023-09-07 19:49:46 --> Output Class Initialized
DEBUG - 2023-09-07 19:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:49:46 --> Security Class Initialized
INFO - 2023-09-07 19:49:46 --> Input Class Initialized
INFO - 2023-09-07 19:49:46 --> Language Class Initialized
DEBUG - 2023-09-07 19:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:49:46 --> Input Class Initialized
INFO - 2023-09-07 19:49:46 --> Language Class Initialized
ERROR - 2023-09-07 19:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:49:46 --> Config Class Initialized
INFO - 2023-09-07 19:49:46 --> Config Class Initialized
INFO - 2023-09-07 19:49:46 --> Hooks Class Initialized
INFO - 2023-09-07 19:49:46 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:49:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:49:46 --> Utf8 Class Initialized
DEBUG - 2023-09-07 19:49:46 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:49:46 --> URI Class Initialized
INFO - 2023-09-07 19:49:46 --> Utf8 Class Initialized
INFO - 2023-09-07 19:49:46 --> Router Class Initialized
INFO - 2023-09-07 19:49:46 --> Output Class Initialized
INFO - 2023-09-07 19:49:46 --> URI Class Initialized
INFO - 2023-09-07 19:49:46 --> Security Class Initialized
DEBUG - 2023-09-07 19:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:49:46 --> Router Class Initialized
INFO - 2023-09-07 19:49:46 --> Input Class Initialized
INFO - 2023-09-07 19:49:46 --> Language Class Initialized
INFO - 2023-09-07 19:49:46 --> Output Class Initialized
ERROR - 2023-09-07 19:49:46 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:49:46 --> Security Class Initialized
DEBUG - 2023-09-07 19:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:49:46 --> Input Class Initialized
INFO - 2023-09-07 19:49:46 --> Language Class Initialized
ERROR - 2023-09-07 19:49:47 --> 404 Page Not Found: Service-detail/assets
INFO - 2023-09-07 19:51:57 --> Config Class Initialized
INFO - 2023-09-07 19:51:57 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:51:57 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:51:57 --> Utf8 Class Initialized
INFO - 2023-09-07 19:51:57 --> URI Class Initialized
DEBUG - 2023-09-07 19:51:57 --> No URI present. Default controller set.
INFO - 2023-09-07 19:51:57 --> Router Class Initialized
INFO - 2023-09-07 19:51:57 --> Output Class Initialized
INFO - 2023-09-07 19:51:57 --> Security Class Initialized
DEBUG - 2023-09-07 19:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:51:57 --> Input Class Initialized
INFO - 2023-09-07 19:51:57 --> Language Class Initialized
INFO - 2023-09-07 19:51:57 --> Loader Class Initialized
INFO - 2023-09-07 19:51:57 --> Helper loaded: url_helper
INFO - 2023-09-07 19:51:57 --> Helper loaded: file_helper
INFO - 2023-09-07 19:51:57 --> Database Driver Class Initialized
INFO - 2023-09-07 19:51:57 --> Email Class Initialized
DEBUG - 2023-09-07 19:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:51:58 --> Controller Class Initialized
INFO - 2023-09-07 19:51:58 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:51:58 --> Model "Home_model" initialized
INFO - 2023-09-07 19:51:58 --> Helper loaded: download_helper
INFO - 2023-09-07 19:51:58 --> Helper loaded: form_helper
INFO - 2023-09-07 19:51:58 --> Form Validation Class Initialized
INFO - 2023-09-07 19:51:58 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:51:58 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:51:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:51:58 --> Final output sent to browser
DEBUG - 2023-09-07 19:51:58 --> Total execution time: 0.5785
INFO - 2023-09-07 19:51:58 --> Config Class Initialized
INFO - 2023-09-07 19:51:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:51:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:51:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:51:58 --> URI Class Initialized
INFO - 2023-09-07 19:51:58 --> Router Class Initialized
INFO - 2023-09-07 19:51:58 --> Output Class Initialized
INFO - 2023-09-07 19:51:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:51:58 --> Input Class Initialized
INFO - 2023-09-07 19:51:58 --> Language Class Initialized
ERROR - 2023-09-07 19:51:58 --> 404 Page Not Found: Assets/images
INFO - 2023-09-07 19:52:21 --> Config Class Initialized
INFO - 2023-09-07 19:52:21 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:21 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:21 --> URI Class Initialized
DEBUG - 2023-09-07 19:52:21 --> No URI present. Default controller set.
INFO - 2023-09-07 19:52:21 --> Router Class Initialized
INFO - 2023-09-07 19:52:21 --> Output Class Initialized
INFO - 2023-09-07 19:52:21 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:21 --> Input Class Initialized
INFO - 2023-09-07 19:52:21 --> Language Class Initialized
INFO - 2023-09-07 19:52:21 --> Loader Class Initialized
INFO - 2023-09-07 19:52:21 --> Helper loaded: url_helper
INFO - 2023-09-07 19:52:21 --> Helper loaded: file_helper
INFO - 2023-09-07 19:52:21 --> Database Driver Class Initialized
INFO - 2023-09-07 19:52:21 --> Email Class Initialized
DEBUG - 2023-09-07 19:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-07 19:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-07 19:52:21 --> Controller Class Initialized
INFO - 2023-09-07 19:52:21 --> Model "Contact_model" initialized
INFO - 2023-09-07 19:52:21 --> Model "Home_model" initialized
INFO - 2023-09-07 19:52:21 --> Helper loaded: download_helper
INFO - 2023-09-07 19:52:21 --> Helper loaded: form_helper
INFO - 2023-09-07 19:52:21 --> Form Validation Class Initialized
INFO - 2023-09-07 19:52:21 --> Helper loaded: custom_helper
INFO - 2023-09-07 19:52:21 --> Model "Social_media_model" initialized
INFO - 2023-09-07 19:52:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-07 19:52:21 --> Final output sent to browser
DEBUG - 2023-09-07 19:52:21 --> Total execution time: 0.1651
INFO - 2023-09-07 19:52:23 --> Config Class Initialized
INFO - 2023-09-07 19:52:23 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:23 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:23 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:23 --> URI Class Initialized
INFO - 2023-09-07 19:52:23 --> Router Class Initialized
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:58 --> URI Class Initialized
INFO - 2023-09-07 19:52:58 --> Router Class Initialized
INFO - 2023-09-07 19:52:58 --> Output Class Initialized
INFO - 2023-09-07 19:52:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:58 --> Input Class Initialized
INFO - 2023-09-07 19:52:58 --> Language Class Initialized
ERROR - 2023-09-07 19:52:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:58 --> URI Class Initialized
INFO - 2023-09-07 19:52:58 --> Router Class Initialized
INFO - 2023-09-07 19:52:58 --> Output Class Initialized
INFO - 2023-09-07 19:52:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:58 --> Input Class Initialized
INFO - 2023-09-07 19:52:58 --> Language Class Initialized
ERROR - 2023-09-07 19:52:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:58 --> URI Class Initialized
INFO - 2023-09-07 19:52:58 --> Router Class Initialized
INFO - 2023-09-07 19:52:58 --> Output Class Initialized
INFO - 2023-09-07 19:52:58 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:58 --> Input Class Initialized
INFO - 2023-09-07 19:52:58 --> Language Class Initialized
ERROR - 2023-09-07 19:52:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Config Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
INFO - 2023-09-07 19:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-07 19:52:58 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:59 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:59 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:59 --> URI Class Initialized
INFO - 2023-09-07 19:52:59 --> Router Class Initialized
INFO - 2023-09-07 19:52:59 --> URI Class Initialized
INFO - 2023-09-07 19:52:59 --> Output Class Initialized
INFO - 2023-09-07 19:52:59 --> Router Class Initialized
INFO - 2023-09-07 19:52:59 --> Utf8 Class Initialized
INFO - 2023-09-07 19:52:59 --> URI Class Initialized
INFO - 2023-09-07 19:52:59 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:59 --> Input Class Initialized
INFO - 2023-09-07 19:52:59 --> Output Class Initialized
INFO - 2023-09-07 19:52:59 --> URI Class Initialized
INFO - 2023-09-07 19:52:59 --> Router Class Initialized
INFO - 2023-09-07 19:52:59 --> Router Class Initialized
INFO - 2023-09-07 19:52:59 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:59 --> Input Class Initialized
INFO - 2023-09-07 19:52:59 --> Language Class Initialized
ERROR - 2023-09-07 19:52:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-07 19:52:59 --> Output Class Initialized
INFO - 2023-09-07 19:52:59 --> Language Class Initialized
INFO - 2023-09-07 19:52:59 --> Security Class Initialized
INFO - 2023-09-07 19:52:59 --> Output Class Initialized
INFO - 2023-09-07 19:52:59 --> Security Class Initialized
DEBUG - 2023-09-07 19:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 19:52:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-07 19:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-07 19:52:59 --> Input Class Initialized
INFO - 2023-09-07 19:52:59 --> Input Class Initialized
INFO - 2023-09-07 19:52:59 --> Language Class Initialized
INFO - 2023-09-07 19:52:59 --> Language Class Initialized
ERROR - 2023-09-07 19:52:59 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-07 19:52:59 --> 404 Page Not Found: Assets/home
