<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-09 16:35:26 --> Config Class Initialized
INFO - 2023-08-09 16:35:26 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:27 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:27 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:27 --> URI Class Initialized
DEBUG - 2023-08-09 16:35:28 --> No URI present. Default controller set.
INFO - 2023-08-09 16:35:28 --> Router Class Initialized
INFO - 2023-08-09 16:35:28 --> Output Class Initialized
INFO - 2023-08-09 16:35:28 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:28 --> Input Class Initialized
INFO - 2023-08-09 16:35:28 --> Language Class Initialized
INFO - 2023-08-09 16:35:29 --> Loader Class Initialized
INFO - 2023-08-09 16:35:29 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:29 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:30 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:30 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:30 --> Controller Class Initialized
INFO - 2023-08-09 16:35:30 --> File loaded: C:\xampp\htdocs\DW\application\views\welcome_message.php
INFO - 2023-08-09 16:35:30 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:30 --> Total execution time: 5.3133
INFO - 2023-08-09 16:35:35 --> Config Class Initialized
INFO - 2023-08-09 16:35:35 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:35 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:35 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:35 --> URI Class Initialized
INFO - 2023-08-09 16:35:35 --> Router Class Initialized
INFO - 2023-08-09 16:35:35 --> Output Class Initialized
INFO - 2023-08-09 16:35:35 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:35 --> Input Class Initialized
INFO - 2023-08-09 16:35:35 --> Language Class Initialized
INFO - 2023-08-09 16:35:35 --> Loader Class Initialized
INFO - 2023-08-09 16:35:35 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:35 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:35 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:35 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:35 --> Controller Class Initialized
INFO - 2023-08-09 16:35:35 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:35:35 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:35 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-09 16:35:35 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:35 --> Total execution time: 0.3409
INFO - 2023-08-09 16:35:36 --> Config Class Initialized
INFO - 2023-08-09 16:35:36 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:36 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:36 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:36 --> URI Class Initialized
INFO - 2023-08-09 16:35:36 --> Router Class Initialized
INFO - 2023-08-09 16:35:36 --> Output Class Initialized
INFO - 2023-08-09 16:35:36 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:36 --> Input Class Initialized
INFO - 2023-08-09 16:35:36 --> Language Class Initialized
ERROR - 2023-08-09 16:35:36 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-09 16:35:41 --> Config Class Initialized
INFO - 2023-08-09 16:35:41 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:41 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:41 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:41 --> URI Class Initialized
INFO - 2023-08-09 16:35:41 --> Router Class Initialized
INFO - 2023-08-09 16:35:41 --> Output Class Initialized
INFO - 2023-08-09 16:35:41 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:41 --> Input Class Initialized
INFO - 2023-08-09 16:35:41 --> Language Class Initialized
INFO - 2023-08-09 16:35:41 --> Loader Class Initialized
INFO - 2023-08-09 16:35:41 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:41 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:41 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:41 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:41 --> Controller Class Initialized
INFO - 2023-08-09 16:35:41 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:35:41 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:41 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:35:41 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:41 --> Total execution time: 0.2411
INFO - 2023-08-09 16:35:41 --> Config Class Initialized
INFO - 2023-08-09 16:35:41 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:41 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:41 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:41 --> URI Class Initialized
INFO - 2023-08-09 16:35:41 --> Router Class Initialized
INFO - 2023-08-09 16:35:41 --> Output Class Initialized
INFO - 2023-08-09 16:35:41 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:41 --> Input Class Initialized
INFO - 2023-08-09 16:35:41 --> Language Class Initialized
ERROR - 2023-08-09 16:35:41 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-09 16:35:43 --> Config Class Initialized
INFO - 2023-08-09 16:35:43 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:43 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:43 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:43 --> URI Class Initialized
INFO - 2023-08-09 16:35:43 --> Router Class Initialized
INFO - 2023-08-09 16:35:43 --> Output Class Initialized
INFO - 2023-08-09 16:35:43 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:43 --> Input Class Initialized
INFO - 2023-08-09 16:35:43 --> Language Class Initialized
INFO - 2023-08-09 16:35:43 --> Loader Class Initialized
INFO - 2023-08-09 16:35:43 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:43 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:43 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:43 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:43 --> Controller Class Initialized
INFO - 2023-08-09 16:35:43 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:35:43 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:43 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 16:35:43 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:43 --> Total execution time: 0.3564
INFO - 2023-08-09 16:35:46 --> Config Class Initialized
INFO - 2023-08-09 16:35:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:46 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:46 --> URI Class Initialized
INFO - 2023-08-09 16:35:46 --> Router Class Initialized
INFO - 2023-08-09 16:35:46 --> Output Class Initialized
INFO - 2023-08-09 16:35:46 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:46 --> Input Class Initialized
INFO - 2023-08-09 16:35:46 --> Language Class Initialized
INFO - 2023-08-09 16:35:46 --> Loader Class Initialized
INFO - 2023-08-09 16:35:46 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:46 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:46 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:46 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:46 --> Controller Class Initialized
INFO - 2023-08-09 16:35:46 --> Model "Services_model" initialized
INFO - 2023-08-09 16:35:46 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:46 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 16:35:46 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:46 --> Total execution time: 0.4670
INFO - 2023-08-09 16:35:48 --> Config Class Initialized
INFO - 2023-08-09 16:35:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:48 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:48 --> URI Class Initialized
INFO - 2023-08-09 16:35:48 --> Router Class Initialized
INFO - 2023-08-09 16:35:48 --> Output Class Initialized
INFO - 2023-08-09 16:35:48 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:48 --> Input Class Initialized
INFO - 2023-08-09 16:35:48 --> Language Class Initialized
INFO - 2023-08-09 16:35:48 --> Loader Class Initialized
INFO - 2023-08-09 16:35:48 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:48 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:48 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:48 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:48 --> Controller Class Initialized
INFO - 2023-08-09 16:35:48 --> Model "Training_model" initialized
INFO - 2023-08-09 16:35:48 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:48 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 16:35:48 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:48 --> Total execution time: 0.3675
INFO - 2023-08-09 16:35:51 --> Config Class Initialized
INFO - 2023-08-09 16:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:51 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:51 --> URI Class Initialized
INFO - 2023-08-09 16:35:51 --> Router Class Initialized
INFO - 2023-08-09 16:35:51 --> Output Class Initialized
INFO - 2023-08-09 16:35:51 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:51 --> Input Class Initialized
INFO - 2023-08-09 16:35:51 --> Language Class Initialized
INFO - 2023-08-09 16:35:52 --> Loader Class Initialized
INFO - 2023-08-09 16:35:52 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:52 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:52 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:52 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:52 --> Controller Class Initialized
INFO - 2023-08-09 16:35:52 --> Model "Faq_model" initialized
INFO - 2023-08-09 16:35:52 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:52 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 16:35:52 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:52 --> Total execution time: 0.2312
INFO - 2023-08-09 16:35:56 --> Config Class Initialized
INFO - 2023-08-09 16:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:56 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:56 --> URI Class Initialized
INFO - 2023-08-09 16:35:56 --> Router Class Initialized
INFO - 2023-08-09 16:35:56 --> Output Class Initialized
INFO - 2023-08-09 16:35:56 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:56 --> Input Class Initialized
INFO - 2023-08-09 16:35:56 --> Language Class Initialized
INFO - 2023-08-09 16:35:56 --> Loader Class Initialized
INFO - 2023-08-09 16:35:56 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:56 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:56 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:56 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:56 --> Controller Class Initialized
INFO - 2023-08-09 16:35:56 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 16:35:56 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:56 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 16:35:56 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:56 --> Total execution time: 0.1257
INFO - 2023-08-09 16:35:59 --> Config Class Initialized
INFO - 2023-08-09 16:35:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:35:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:35:59 --> Utf8 Class Initialized
INFO - 2023-08-09 16:35:59 --> URI Class Initialized
INFO - 2023-08-09 16:35:59 --> Router Class Initialized
INFO - 2023-08-09 16:35:59 --> Output Class Initialized
INFO - 2023-08-09 16:35:59 --> Security Class Initialized
DEBUG - 2023-08-09 16:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:35:59 --> Input Class Initialized
INFO - 2023-08-09 16:35:59 --> Language Class Initialized
INFO - 2023-08-09 16:35:59 --> Loader Class Initialized
INFO - 2023-08-09 16:35:59 --> Helper loaded: url_helper
INFO - 2023-08-09 16:35:59 --> Helper loaded: file_helper
INFO - 2023-08-09 16:35:59 --> Database Driver Class Initialized
INFO - 2023-08-09 16:35:59 --> Email Class Initialized
DEBUG - 2023-08-09 16:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:35:59 --> Controller Class Initialized
INFO - 2023-08-09 16:35:59 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 16:35:59 --> Helper loaded: form_helper
INFO - 2023-08-09 16:35:59 --> Form Validation Class Initialized
INFO - 2023-08-09 16:35:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 16:35:59 --> Final output sent to browser
DEBUG - 2023-08-09 16:35:59 --> Total execution time: 0.0466
INFO - 2023-08-09 16:36:12 --> Config Class Initialized
INFO - 2023-08-09 16:36:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:36:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:36:12 --> Utf8 Class Initialized
INFO - 2023-08-09 16:36:12 --> URI Class Initialized
INFO - 2023-08-09 16:36:12 --> Router Class Initialized
INFO - 2023-08-09 16:36:12 --> Output Class Initialized
INFO - 2023-08-09 16:36:12 --> Security Class Initialized
DEBUG - 2023-08-09 16:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:36:12 --> Input Class Initialized
INFO - 2023-08-09 16:36:12 --> Language Class Initialized
INFO - 2023-08-09 16:36:12 --> Loader Class Initialized
INFO - 2023-08-09 16:36:12 --> Helper loaded: url_helper
INFO - 2023-08-09 16:36:12 --> Helper loaded: file_helper
INFO - 2023-08-09 16:36:12 --> Database Driver Class Initialized
INFO - 2023-08-09 16:36:12 --> Email Class Initialized
DEBUG - 2023-08-09 16:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:36:12 --> Controller Class Initialized
INFO - 2023-08-09 16:36:12 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 16:36:12 --> Helper loaded: form_helper
INFO - 2023-08-09 16:36:12 --> Form Validation Class Initialized
INFO - 2023-08-09 16:36:12 --> Config Class Initialized
INFO - 2023-08-09 16:36:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:36:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:36:12 --> Utf8 Class Initialized
INFO - 2023-08-09 16:36:12 --> URI Class Initialized
INFO - 2023-08-09 16:36:12 --> Router Class Initialized
INFO - 2023-08-09 16:36:12 --> Output Class Initialized
INFO - 2023-08-09 16:36:12 --> Security Class Initialized
DEBUG - 2023-08-09 16:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:36:12 --> Input Class Initialized
INFO - 2023-08-09 16:36:12 --> Language Class Initialized
INFO - 2023-08-09 16:36:12 --> Loader Class Initialized
INFO - 2023-08-09 16:36:12 --> Helper loaded: url_helper
INFO - 2023-08-09 16:36:12 --> Helper loaded: file_helper
INFO - 2023-08-09 16:36:12 --> Database Driver Class Initialized
INFO - 2023-08-09 16:36:12 --> Email Class Initialized
DEBUG - 2023-08-09 16:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:36:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 16:36:13 --> Final output sent to browser
DEBUG - 2023-08-09 16:36:13 --> Total execution time: 0.7581
INFO - 2023-08-09 16:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:36:13 --> Controller Class Initialized
INFO - 2023-08-09 16:36:13 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 16:36:13 --> Helper loaded: form_helper
INFO - 2023-08-09 16:36:13 --> Form Validation Class Initialized
INFO - 2023-08-09 16:36:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 16:36:13 --> Final output sent to browser
DEBUG - 2023-08-09 16:36:13 --> Total execution time: 0.2572
INFO - 2023-08-09 16:37:40 --> Config Class Initialized
INFO - 2023-08-09 16:37:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:37:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:37:40 --> Utf8 Class Initialized
INFO - 2023-08-09 16:37:40 --> URI Class Initialized
INFO - 2023-08-09 16:37:40 --> Router Class Initialized
INFO - 2023-08-09 16:37:40 --> Output Class Initialized
INFO - 2023-08-09 16:37:41 --> Security Class Initialized
DEBUG - 2023-08-09 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:37:41 --> Input Class Initialized
INFO - 2023-08-09 16:37:41 --> Language Class Initialized
INFO - 2023-08-09 16:37:41 --> Loader Class Initialized
INFO - 2023-08-09 16:37:41 --> Helper loaded: url_helper
INFO - 2023-08-09 16:37:41 --> Helper loaded: file_helper
INFO - 2023-08-09 16:37:41 --> Database Driver Class Initialized
INFO - 2023-08-09 16:37:41 --> Email Class Initialized
DEBUG - 2023-08-09 16:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:37:41 --> Controller Class Initialized
INFO - 2023-08-09 16:37:41 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 16:37:41 --> Helper loaded: form_helper
INFO - 2023-08-09 16:37:41 --> Form Validation Class Initialized
INFO - 2023-08-09 16:37:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 16:37:41 --> Final output sent to browser
DEBUG - 2023-08-09 16:37:41 --> Total execution time: 1.9317
INFO - 2023-08-09 16:37:59 --> Config Class Initialized
INFO - 2023-08-09 16:37:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:37:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:37:59 --> Utf8 Class Initialized
INFO - 2023-08-09 16:37:59 --> URI Class Initialized
INFO - 2023-08-09 16:37:59 --> Router Class Initialized
INFO - 2023-08-09 16:37:59 --> Output Class Initialized
INFO - 2023-08-09 16:37:59 --> Security Class Initialized
DEBUG - 2023-08-09 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:37:59 --> Input Class Initialized
INFO - 2023-08-09 16:37:59 --> Language Class Initialized
INFO - 2023-08-09 16:38:00 --> Loader Class Initialized
INFO - 2023-08-09 16:38:00 --> Helper loaded: url_helper
INFO - 2023-08-09 16:38:00 --> Helper loaded: file_helper
INFO - 2023-08-09 16:38:00 --> Database Driver Class Initialized
INFO - 2023-08-09 16:38:00 --> Email Class Initialized
DEBUG - 2023-08-09 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:38:00 --> Controller Class Initialized
INFO - 2023-08-09 16:38:00 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 16:38:00 --> Helper loaded: form_helper
INFO - 2023-08-09 16:38:00 --> Form Validation Class Initialized
INFO - 2023-08-09 16:38:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 16:38:00 --> Final output sent to browser
DEBUG - 2023-08-09 16:38:00 --> Total execution time: 0.1752
INFO - 2023-08-09 16:38:03 --> Config Class Initialized
INFO - 2023-08-09 16:38:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:38:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:38:03 --> Utf8 Class Initialized
INFO - 2023-08-09 16:38:03 --> URI Class Initialized
INFO - 2023-08-09 16:38:03 --> Router Class Initialized
INFO - 2023-08-09 16:38:03 --> Output Class Initialized
INFO - 2023-08-09 16:38:03 --> Security Class Initialized
DEBUG - 2023-08-09 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:38:03 --> Input Class Initialized
INFO - 2023-08-09 16:38:03 --> Language Class Initialized
INFO - 2023-08-09 16:38:03 --> Loader Class Initialized
INFO - 2023-08-09 16:38:03 --> Helper loaded: url_helper
INFO - 2023-08-09 16:38:03 --> Helper loaded: file_helper
INFO - 2023-08-09 16:38:04 --> Database Driver Class Initialized
INFO - 2023-08-09 16:38:04 --> Email Class Initialized
DEBUG - 2023-08-09 16:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:38:04 --> Controller Class Initialized
INFO - 2023-08-09 16:38:04 --> Model "Faq_model" initialized
INFO - 2023-08-09 16:38:04 --> Helper loaded: form_helper
INFO - 2023-08-09 16:38:04 --> Form Validation Class Initialized
INFO - 2023-08-09 16:38:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 16:38:04 --> Final output sent to browser
DEBUG - 2023-08-09 16:38:04 --> Total execution time: 0.6627
INFO - 2023-08-09 16:38:18 --> Config Class Initialized
INFO - 2023-08-09 16:38:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:38:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:38:18 --> Utf8 Class Initialized
INFO - 2023-08-09 16:38:18 --> URI Class Initialized
INFO - 2023-08-09 16:38:18 --> Router Class Initialized
INFO - 2023-08-09 16:38:18 --> Output Class Initialized
INFO - 2023-08-09 16:38:18 --> Security Class Initialized
DEBUG - 2023-08-09 16:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:38:18 --> Input Class Initialized
INFO - 2023-08-09 16:38:18 --> Language Class Initialized
INFO - 2023-08-09 16:38:18 --> Loader Class Initialized
INFO - 2023-08-09 16:38:18 --> Helper loaded: url_helper
INFO - 2023-08-09 16:38:18 --> Helper loaded: file_helper
INFO - 2023-08-09 16:38:18 --> Database Driver Class Initialized
INFO - 2023-08-09 16:38:18 --> Email Class Initialized
DEBUG - 2023-08-09 16:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:38:18 --> Controller Class Initialized
INFO - 2023-08-09 16:38:18 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:38:18 --> Helper loaded: form_helper
INFO - 2023-08-09 16:38:18 --> Form Validation Class Initialized
INFO - 2023-08-09 16:38:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:38:18 --> Final output sent to browser
DEBUG - 2023-08-09 16:38:18 --> Total execution time: 0.0921
INFO - 2023-08-09 16:40:44 --> Config Class Initialized
INFO - 2023-08-09 16:40:44 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:40:44 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:40:44 --> Utf8 Class Initialized
INFO - 2023-08-09 16:40:44 --> URI Class Initialized
INFO - 2023-08-09 16:40:44 --> Router Class Initialized
INFO - 2023-08-09 16:40:44 --> Output Class Initialized
INFO - 2023-08-09 16:40:44 --> Security Class Initialized
DEBUG - 2023-08-09 16:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:40:44 --> Input Class Initialized
INFO - 2023-08-09 16:40:44 --> Language Class Initialized
INFO - 2023-08-09 16:40:44 --> Loader Class Initialized
INFO - 2023-08-09 16:40:44 --> Helper loaded: url_helper
INFO - 2023-08-09 16:40:44 --> Helper loaded: file_helper
INFO - 2023-08-09 16:40:44 --> Database Driver Class Initialized
INFO - 2023-08-09 16:40:44 --> Email Class Initialized
DEBUG - 2023-08-09 16:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:40:44 --> Controller Class Initialized
INFO - 2023-08-09 16:40:44 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:40:44 --> Helper loaded: form_helper
INFO - 2023-08-09 16:40:44 --> Form Validation Class Initialized
INFO - 2023-08-09 16:40:44 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:40:44 --> Final output sent to browser
DEBUG - 2023-08-09 16:40:44 --> Total execution time: 0.1295
INFO - 2023-08-09 16:40:46 --> Config Class Initialized
INFO - 2023-08-09 16:40:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:40:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:40:46 --> Utf8 Class Initialized
INFO - 2023-08-09 16:40:46 --> URI Class Initialized
INFO - 2023-08-09 16:40:46 --> Router Class Initialized
INFO - 2023-08-09 16:40:46 --> Output Class Initialized
INFO - 2023-08-09 16:40:46 --> Security Class Initialized
DEBUG - 2023-08-09 16:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:40:46 --> Input Class Initialized
INFO - 2023-08-09 16:40:46 --> Language Class Initialized
INFO - 2023-08-09 16:40:46 --> Loader Class Initialized
INFO - 2023-08-09 16:40:46 --> Helper loaded: url_helper
INFO - 2023-08-09 16:40:46 --> Helper loaded: file_helper
INFO - 2023-08-09 16:40:46 --> Database Driver Class Initialized
INFO - 2023-08-09 16:40:46 --> Email Class Initialized
DEBUG - 2023-08-09 16:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:40:46 --> Controller Class Initialized
INFO - 2023-08-09 16:40:46 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:40:46 --> Helper loaded: form_helper
INFO - 2023-08-09 16:40:46 --> Form Validation Class Initialized
INFO - 2023-08-09 16:40:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-09 16:40:46 --> Final output sent to browser
DEBUG - 2023-08-09 16:40:46 --> Total execution time: 0.0467
INFO - 2023-08-09 16:40:46 --> Config Class Initialized
INFO - 2023-08-09 16:40:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:40:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:40:46 --> Utf8 Class Initialized
INFO - 2023-08-09 16:40:46 --> URI Class Initialized
INFO - 2023-08-09 16:40:46 --> Router Class Initialized
INFO - 2023-08-09 16:40:46 --> Output Class Initialized
INFO - 2023-08-09 16:40:46 --> Security Class Initialized
DEBUG - 2023-08-09 16:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:40:46 --> Input Class Initialized
INFO - 2023-08-09 16:40:46 --> Language Class Initialized
ERROR - 2023-08-09 16:40:46 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-09 16:40:48 --> Config Class Initialized
INFO - 2023-08-09 16:40:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:40:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:40:48 --> Utf8 Class Initialized
INFO - 2023-08-09 16:40:48 --> URI Class Initialized
INFO - 2023-08-09 16:40:48 --> Router Class Initialized
INFO - 2023-08-09 16:40:48 --> Output Class Initialized
INFO - 2023-08-09 16:40:48 --> Security Class Initialized
DEBUG - 2023-08-09 16:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:40:48 --> Input Class Initialized
INFO - 2023-08-09 16:40:48 --> Language Class Initialized
INFO - 2023-08-09 16:40:48 --> Loader Class Initialized
INFO - 2023-08-09 16:40:48 --> Helper loaded: url_helper
INFO - 2023-08-09 16:40:48 --> Helper loaded: file_helper
INFO - 2023-08-09 16:40:48 --> Database Driver Class Initialized
INFO - 2023-08-09 16:40:48 --> Email Class Initialized
DEBUG - 2023-08-09 16:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:40:48 --> Controller Class Initialized
INFO - 2023-08-09 16:40:48 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:40:48 --> Helper loaded: form_helper
INFO - 2023-08-09 16:40:48 --> Form Validation Class Initialized
INFO - 2023-08-09 16:40:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 16:40:48 --> Final output sent to browser
DEBUG - 2023-08-09 16:40:48 --> Total execution time: 0.0520
INFO - 2023-08-09 16:41:08 --> Config Class Initialized
INFO - 2023-08-09 16:41:08 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:41:08 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:41:08 --> Utf8 Class Initialized
INFO - 2023-08-09 16:41:08 --> URI Class Initialized
INFO - 2023-08-09 16:41:08 --> Router Class Initialized
INFO - 2023-08-09 16:41:08 --> Output Class Initialized
INFO - 2023-08-09 16:41:08 --> Security Class Initialized
DEBUG - 2023-08-09 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:41:08 --> Input Class Initialized
INFO - 2023-08-09 16:41:08 --> Language Class Initialized
INFO - 2023-08-09 16:41:08 --> Loader Class Initialized
INFO - 2023-08-09 16:41:08 --> Helper loaded: url_helper
INFO - 2023-08-09 16:41:08 --> Helper loaded: file_helper
INFO - 2023-08-09 16:41:08 --> Database Driver Class Initialized
INFO - 2023-08-09 16:41:08 --> Email Class Initialized
DEBUG - 2023-08-09 16:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:41:08 --> Controller Class Initialized
INFO - 2023-08-09 16:41:08 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:41:08 --> Helper loaded: form_helper
INFO - 2023-08-09 16:41:08 --> Form Validation Class Initialized
INFO - 2023-08-09 16:41:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 16:41:08 --> Final output sent to browser
DEBUG - 2023-08-09 16:41:08 --> Total execution time: 0.1467
INFO - 2023-08-09 16:41:10 --> Config Class Initialized
INFO - 2023-08-09 16:41:10 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:41:10 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:41:10 --> Utf8 Class Initialized
INFO - 2023-08-09 16:41:10 --> URI Class Initialized
INFO - 2023-08-09 16:41:10 --> Router Class Initialized
INFO - 2023-08-09 16:41:10 --> Output Class Initialized
INFO - 2023-08-09 16:41:10 --> Security Class Initialized
DEBUG - 2023-08-09 16:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:41:10 --> Input Class Initialized
INFO - 2023-08-09 16:41:10 --> Language Class Initialized
INFO - 2023-08-09 16:41:10 --> Loader Class Initialized
INFO - 2023-08-09 16:41:10 --> Helper loaded: url_helper
INFO - 2023-08-09 16:41:10 --> Helper loaded: file_helper
INFO - 2023-08-09 16:41:10 --> Database Driver Class Initialized
INFO - 2023-08-09 16:41:10 --> Email Class Initialized
DEBUG - 2023-08-09 16:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:41:10 --> Controller Class Initialized
INFO - 2023-08-09 16:41:10 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:41:10 --> Helper loaded: form_helper
INFO - 2023-08-09 16:41:10 --> Form Validation Class Initialized
INFO - 2023-08-09 16:41:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-09 16:41:10 --> Final output sent to browser
DEBUG - 2023-08-09 16:41:10 --> Total execution time: 0.0458
INFO - 2023-08-09 16:41:13 --> Config Class Initialized
INFO - 2023-08-09 16:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:41:13 --> Utf8 Class Initialized
INFO - 2023-08-09 16:41:13 --> URI Class Initialized
INFO - 2023-08-09 16:41:13 --> Router Class Initialized
INFO - 2023-08-09 16:41:13 --> Output Class Initialized
INFO - 2023-08-09 16:41:13 --> Security Class Initialized
DEBUG - 2023-08-09 16:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:41:13 --> Input Class Initialized
INFO - 2023-08-09 16:41:13 --> Language Class Initialized
INFO - 2023-08-09 16:41:13 --> Loader Class Initialized
INFO - 2023-08-09 16:41:13 --> Helper loaded: url_helper
INFO - 2023-08-09 16:41:13 --> Helper loaded: file_helper
INFO - 2023-08-09 16:41:13 --> Database Driver Class Initialized
INFO - 2023-08-09 16:41:13 --> Email Class Initialized
DEBUG - 2023-08-09 16:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:41:13 --> Controller Class Initialized
INFO - 2023-08-09 16:41:13 --> Model "Services_model" initialized
INFO - 2023-08-09 16:41:13 --> Helper loaded: form_helper
INFO - 2023-08-09 16:41:13 --> Form Validation Class Initialized
INFO - 2023-08-09 16:41:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 16:41:13 --> Final output sent to browser
DEBUG - 2023-08-09 16:41:13 --> Total execution time: 0.0482
INFO - 2023-08-09 16:43:28 --> Config Class Initialized
INFO - 2023-08-09 16:43:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:43:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:43:28 --> Utf8 Class Initialized
INFO - 2023-08-09 16:43:28 --> URI Class Initialized
INFO - 2023-08-09 16:43:28 --> Router Class Initialized
INFO - 2023-08-09 16:43:28 --> Output Class Initialized
INFO - 2023-08-09 16:43:28 --> Security Class Initialized
DEBUG - 2023-08-09 16:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:43:28 --> Input Class Initialized
INFO - 2023-08-09 16:43:28 --> Language Class Initialized
INFO - 2023-08-09 16:43:28 --> Loader Class Initialized
INFO - 2023-08-09 16:43:28 --> Helper loaded: url_helper
INFO - 2023-08-09 16:43:28 --> Helper loaded: file_helper
INFO - 2023-08-09 16:43:28 --> Database Driver Class Initialized
INFO - 2023-08-09 16:43:28 --> Email Class Initialized
DEBUG - 2023-08-09 16:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:43:28 --> Controller Class Initialized
INFO - 2023-08-09 16:43:28 --> Model "Services_model" initialized
INFO - 2023-08-09 16:43:28 --> Helper loaded: form_helper
INFO - 2023-08-09 16:43:28 --> Form Validation Class Initialized
INFO - 2023-08-09 16:43:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 16:43:28 --> Final output sent to browser
DEBUG - 2023-08-09 16:43:28 --> Total execution time: 0.1775
INFO - 2023-08-09 16:45:20 --> Config Class Initialized
INFO - 2023-08-09 16:45:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:20 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:20 --> URI Class Initialized
INFO - 2023-08-09 16:45:20 --> Router Class Initialized
INFO - 2023-08-09 16:45:20 --> Output Class Initialized
INFO - 2023-08-09 16:45:21 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:21 --> Input Class Initialized
INFO - 2023-08-09 16:45:21 --> Language Class Initialized
INFO - 2023-08-09 16:45:21 --> Loader Class Initialized
INFO - 2023-08-09 16:45:21 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:21 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:21 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:21 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:21 --> Controller Class Initialized
INFO - 2023-08-09 16:45:21 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:45:21 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:21 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:45:21 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:21 --> Total execution time: 0.4929
INFO - 2023-08-09 16:45:23 --> Config Class Initialized
INFO - 2023-08-09 16:45:23 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:23 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:23 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:23 --> URI Class Initialized
INFO - 2023-08-09 16:45:23 --> Router Class Initialized
INFO - 2023-08-09 16:45:23 --> Output Class Initialized
INFO - 2023-08-09 16:45:23 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:23 --> Input Class Initialized
INFO - 2023-08-09 16:45:23 --> Language Class Initialized
ERROR - 2023-08-09 16:45:23 --> 404 Page Not Found: admin//index
INFO - 2023-08-09 16:45:25 --> Config Class Initialized
INFO - 2023-08-09 16:45:25 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:25 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:25 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:25 --> URI Class Initialized
INFO - 2023-08-09 16:45:25 --> Router Class Initialized
INFO - 2023-08-09 16:45:25 --> Output Class Initialized
INFO - 2023-08-09 16:45:25 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:25 --> Input Class Initialized
INFO - 2023-08-09 16:45:25 --> Language Class Initialized
INFO - 2023-08-09 16:45:25 --> Loader Class Initialized
INFO - 2023-08-09 16:45:25 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:25 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:25 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:25 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:25 --> Controller Class Initialized
INFO - 2023-08-09 16:45:25 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:45:25 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:25 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:45:25 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:25 --> Total execution time: 0.0500
INFO - 2023-08-09 16:45:27 --> Config Class Initialized
INFO - 2023-08-09 16:45:27 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:27 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:27 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:27 --> URI Class Initialized
INFO - 2023-08-09 16:45:27 --> Router Class Initialized
INFO - 2023-08-09 16:45:27 --> Output Class Initialized
INFO - 2023-08-09 16:45:27 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:27 --> Input Class Initialized
INFO - 2023-08-09 16:45:27 --> Language Class Initialized
INFO - 2023-08-09 16:45:27 --> Loader Class Initialized
INFO - 2023-08-09 16:45:27 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:27 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:27 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:27 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:27 --> Controller Class Initialized
INFO - 2023-08-09 16:45:27 --> Model "Gallery_model" initialized
INFO - 2023-08-09 16:45:27 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:27 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:27 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 16:45:27 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:27 --> Total execution time: 0.0442
INFO - 2023-08-09 16:45:33 --> Config Class Initialized
INFO - 2023-08-09 16:45:33 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:33 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:33 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:33 --> URI Class Initialized
INFO - 2023-08-09 16:45:33 --> Router Class Initialized
INFO - 2023-08-09 16:45:33 --> Output Class Initialized
INFO - 2023-08-09 16:45:33 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:33 --> Input Class Initialized
INFO - 2023-08-09 16:45:33 --> Language Class Initialized
INFO - 2023-08-09 16:45:33 --> Loader Class Initialized
INFO - 2023-08-09 16:45:33 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:33 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:33 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:33 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:33 --> Controller Class Initialized
INFO - 2023-08-09 16:45:33 --> Model "Services_model" initialized
INFO - 2023-08-09 16:45:33 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:33 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 16:45:33 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:33 --> Total execution time: 0.1797
INFO - 2023-08-09 16:45:36 --> Config Class Initialized
INFO - 2023-08-09 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:36 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:36 --> URI Class Initialized
INFO - 2023-08-09 16:45:36 --> Router Class Initialized
INFO - 2023-08-09 16:45:36 --> Output Class Initialized
INFO - 2023-08-09 16:45:36 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:36 --> Input Class Initialized
INFO - 2023-08-09 16:45:36 --> Language Class Initialized
INFO - 2023-08-09 16:45:36 --> Loader Class Initialized
INFO - 2023-08-09 16:45:36 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:36 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:36 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:36 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:36 --> Controller Class Initialized
INFO - 2023-08-09 16:45:36 --> Model "Training_model" initialized
INFO - 2023-08-09 16:45:36 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:36 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:36 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 16:45:36 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:36 --> Total execution time: 0.0538
INFO - 2023-08-09 16:45:38 --> Config Class Initialized
INFO - 2023-08-09 16:45:38 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:38 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:38 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:38 --> URI Class Initialized
INFO - 2023-08-09 16:45:38 --> Router Class Initialized
INFO - 2023-08-09 16:45:38 --> Output Class Initialized
INFO - 2023-08-09 16:45:38 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:38 --> Input Class Initialized
INFO - 2023-08-09 16:45:38 --> Language Class Initialized
INFO - 2023-08-09 16:45:38 --> Loader Class Initialized
INFO - 2023-08-09 16:45:38 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:38 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:38 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:38 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:38 --> Controller Class Initialized
INFO - 2023-08-09 16:45:38 --> Model "Faq_model" initialized
INFO - 2023-08-09 16:45:38 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:38 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 16:45:38 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:38 --> Total execution time: 0.0471
INFO - 2023-08-09 16:45:40 --> Config Class Initialized
INFO - 2023-08-09 16:45:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:40 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:40 --> URI Class Initialized
INFO - 2023-08-09 16:45:40 --> Router Class Initialized
INFO - 2023-08-09 16:45:40 --> Output Class Initialized
INFO - 2023-08-09 16:45:40 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:40 --> Input Class Initialized
INFO - 2023-08-09 16:45:40 --> Language Class Initialized
INFO - 2023-08-09 16:45:40 --> Loader Class Initialized
INFO - 2023-08-09 16:45:40 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:40 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:40 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:40 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:40 --> Controller Class Initialized
INFO - 2023-08-09 16:45:40 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 16:45:40 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:40 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 16:45:40 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:40 --> Total execution time: 0.0474
INFO - 2023-08-09 16:45:42 --> Config Class Initialized
INFO - 2023-08-09 16:45:42 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:45:42 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:45:42 --> Utf8 Class Initialized
INFO - 2023-08-09 16:45:42 --> URI Class Initialized
INFO - 2023-08-09 16:45:42 --> Router Class Initialized
INFO - 2023-08-09 16:45:42 --> Output Class Initialized
INFO - 2023-08-09 16:45:42 --> Security Class Initialized
DEBUG - 2023-08-09 16:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:45:42 --> Input Class Initialized
INFO - 2023-08-09 16:45:42 --> Language Class Initialized
INFO - 2023-08-09 16:45:42 --> Loader Class Initialized
INFO - 2023-08-09 16:45:42 --> Helper loaded: url_helper
INFO - 2023-08-09 16:45:42 --> Helper loaded: file_helper
INFO - 2023-08-09 16:45:42 --> Database Driver Class Initialized
INFO - 2023-08-09 16:45:42 --> Email Class Initialized
DEBUG - 2023-08-09 16:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:45:42 --> Controller Class Initialized
INFO - 2023-08-09 16:45:42 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 16:45:42 --> Helper loaded: form_helper
INFO - 2023-08-09 16:45:42 --> Form Validation Class Initialized
INFO - 2023-08-09 16:45:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 16:45:42 --> Final output sent to browser
DEBUG - 2023-08-09 16:45:42 --> Total execution time: 0.1795
INFO - 2023-08-09 16:46:20 --> Config Class Initialized
INFO - 2023-08-09 16:46:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:46:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:46:20 --> Utf8 Class Initialized
INFO - 2023-08-09 16:46:20 --> URI Class Initialized
INFO - 2023-08-09 16:46:20 --> Router Class Initialized
INFO - 2023-08-09 16:46:20 --> Output Class Initialized
INFO - 2023-08-09 16:46:20 --> Security Class Initialized
DEBUG - 2023-08-09 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:46:20 --> Input Class Initialized
INFO - 2023-08-09 16:46:20 --> Language Class Initialized
INFO - 2023-08-09 16:46:20 --> Loader Class Initialized
INFO - 2023-08-09 16:46:20 --> Helper loaded: url_helper
INFO - 2023-08-09 16:46:20 --> Helper loaded: file_helper
INFO - 2023-08-09 16:46:20 --> Database Driver Class Initialized
INFO - 2023-08-09 16:46:20 --> Email Class Initialized
DEBUG - 2023-08-09 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:46:20 --> Controller Class Initialized
INFO - 2023-08-09 16:46:20 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:46:20 --> Helper loaded: form_helper
INFO - 2023-08-09 16:46:20 --> Form Validation Class Initialized
INFO - 2023-08-09 16:46:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 16:46:20 --> Final output sent to browser
DEBUG - 2023-08-09 16:46:20 --> Total execution time: 0.0425
INFO - 2023-08-09 16:46:23 --> Config Class Initialized
INFO - 2023-08-09 16:46:23 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:46:23 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:46:23 --> Utf8 Class Initialized
INFO - 2023-08-09 16:46:23 --> URI Class Initialized
INFO - 2023-08-09 16:46:23 --> Router Class Initialized
INFO - 2023-08-09 16:46:23 --> Output Class Initialized
INFO - 2023-08-09 16:46:23 --> Security Class Initialized
DEBUG - 2023-08-09 16:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:46:23 --> Input Class Initialized
INFO - 2023-08-09 16:46:23 --> Language Class Initialized
INFO - 2023-08-09 16:46:23 --> Loader Class Initialized
INFO - 2023-08-09 16:46:23 --> Helper loaded: url_helper
INFO - 2023-08-09 16:46:23 --> Helper loaded: file_helper
INFO - 2023-08-09 16:46:23 --> Database Driver Class Initialized
INFO - 2023-08-09 16:46:23 --> Email Class Initialized
DEBUG - 2023-08-09 16:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:46:23 --> Controller Class Initialized
INFO - 2023-08-09 16:46:23 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:46:23 --> Helper loaded: form_helper
INFO - 2023-08-09 16:46:23 --> Form Validation Class Initialized
INFO - 2023-08-09 16:46:24 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-09 16:46:24 --> Final output sent to browser
DEBUG - 2023-08-09 16:46:24 --> Total execution time: 0.0427
INFO - 2023-08-09 16:46:34 --> Config Class Initialized
INFO - 2023-08-09 16:46:34 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:46:34 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:46:34 --> Utf8 Class Initialized
INFO - 2023-08-09 16:46:34 --> URI Class Initialized
INFO - 2023-08-09 16:46:34 --> Router Class Initialized
INFO - 2023-08-09 16:46:34 --> Output Class Initialized
INFO - 2023-08-09 16:46:34 --> Security Class Initialized
DEBUG - 2023-08-09 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:46:34 --> Input Class Initialized
INFO - 2023-08-09 16:46:34 --> Language Class Initialized
INFO - 2023-08-09 16:46:34 --> Loader Class Initialized
INFO - 2023-08-09 16:46:34 --> Helper loaded: url_helper
INFO - 2023-08-09 16:46:34 --> Helper loaded: file_helper
INFO - 2023-08-09 16:46:34 --> Database Driver Class Initialized
INFO - 2023-08-09 16:46:34 --> Email Class Initialized
DEBUG - 2023-08-09 16:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:46:34 --> Controller Class Initialized
INFO - 2023-08-09 16:46:34 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:46:34 --> Helper loaded: form_helper
INFO - 2023-08-09 16:46:34 --> Form Validation Class Initialized
INFO - 2023-08-09 16:46:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 16:46:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-09 16:46:34 --> Final output sent to browser
DEBUG - 2023-08-09 16:46:34 --> Total execution time: 0.0472
INFO - 2023-08-09 16:46:39 --> Config Class Initialized
INFO - 2023-08-09 16:46:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:46:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:46:39 --> Utf8 Class Initialized
INFO - 2023-08-09 16:46:39 --> URI Class Initialized
INFO - 2023-08-09 16:46:39 --> Router Class Initialized
INFO - 2023-08-09 16:46:39 --> Output Class Initialized
INFO - 2023-08-09 16:46:39 --> Security Class Initialized
DEBUG - 2023-08-09 16:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:46:39 --> Input Class Initialized
INFO - 2023-08-09 16:46:39 --> Language Class Initialized
INFO - 2023-08-09 16:46:39 --> Loader Class Initialized
INFO - 2023-08-09 16:46:39 --> Helper loaded: url_helper
INFO - 2023-08-09 16:46:39 --> Helper loaded: file_helper
INFO - 2023-08-09 16:46:39 --> Database Driver Class Initialized
INFO - 2023-08-09 16:46:39 --> Email Class Initialized
DEBUG - 2023-08-09 16:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:46:39 --> Controller Class Initialized
INFO - 2023-08-09 16:46:39 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:46:39 --> Helper loaded: form_helper
INFO - 2023-08-09 16:46:39 --> Form Validation Class Initialized
INFO - 2023-08-09 16:46:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 16:46:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-09 16:46:39 --> Final output sent to browser
DEBUG - 2023-08-09 16:46:39 --> Total execution time: 0.0550
INFO - 2023-08-09 16:46:45 --> Config Class Initialized
INFO - 2023-08-09 16:46:45 --> Hooks Class Initialized
DEBUG - 2023-08-09 16:46:45 --> UTF-8 Support Enabled
INFO - 2023-08-09 16:46:45 --> Utf8 Class Initialized
INFO - 2023-08-09 16:46:45 --> URI Class Initialized
INFO - 2023-08-09 16:46:45 --> Router Class Initialized
INFO - 2023-08-09 16:46:45 --> Output Class Initialized
INFO - 2023-08-09 16:46:45 --> Security Class Initialized
DEBUG - 2023-08-09 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 16:46:45 --> Input Class Initialized
INFO - 2023-08-09 16:46:45 --> Language Class Initialized
INFO - 2023-08-09 16:46:45 --> Loader Class Initialized
INFO - 2023-08-09 16:46:45 --> Helper loaded: url_helper
INFO - 2023-08-09 16:46:45 --> Helper loaded: file_helper
INFO - 2023-08-09 16:46:45 --> Database Driver Class Initialized
INFO - 2023-08-09 16:46:45 --> Email Class Initialized
DEBUG - 2023-08-09 16:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 16:46:45 --> Controller Class Initialized
INFO - 2023-08-09 16:46:45 --> Model "Banner_model" initialized
INFO - 2023-08-09 16:46:45 --> Helper loaded: form_helper
INFO - 2023-08-09 16:46:45 --> Form Validation Class Initialized
INFO - 2023-08-09 16:46:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-09 16:46:45 --> Severity: Warning --> Undefined variable $image_name C:\xampp\htdocs\DW\application\controllers\Admin\Banner.php 56
ERROR - 2023-08-09 16:46:45 --> Query error: Column 'image' cannot be null - Invalid query: INSERT INTO `banners` (`name`, `description`, `status`, `type`, `image`, `created_at`, `created_by`) VALUES ('oDXsNwOhMS', 'Tm0te9HDja', '2', '1', NULL, '2023-08-09 16:46:45', '2')
INFO - 2023-08-09 16:46:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-09 17:38:17 --> Config Class Initialized
INFO - 2023-08-09 17:38:17 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:17 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:17 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:17 --> URI Class Initialized
INFO - 2023-08-09 17:38:17 --> Router Class Initialized
INFO - 2023-08-09 17:38:17 --> Output Class Initialized
INFO - 2023-08-09 17:38:17 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:17 --> Input Class Initialized
INFO - 2023-08-09 17:38:17 --> Language Class Initialized
INFO - 2023-08-09 17:38:17 --> Loader Class Initialized
INFO - 2023-08-09 17:38:17 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:17 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:17 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:17 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:17 --> Controller Class Initialized
INFO - 2023-08-09 17:38:17 --> Model "Banner_model" initialized
INFO - 2023-08-09 17:38:17 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:17 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-09 17:38:17 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:17 --> Total execution time: 0.1065
INFO - 2023-08-09 17:38:22 --> Config Class Initialized
INFO - 2023-08-09 17:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:22 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:22 --> URI Class Initialized
INFO - 2023-08-09 17:38:22 --> Router Class Initialized
INFO - 2023-08-09 17:38:22 --> Output Class Initialized
INFO - 2023-08-09 17:38:22 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:22 --> Input Class Initialized
INFO - 2023-08-09 17:38:22 --> Language Class Initialized
INFO - 2023-08-09 17:38:22 --> Loader Class Initialized
INFO - 2023-08-09 17:38:22 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:22 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:22 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:23 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:23 --> Controller Class Initialized
INFO - 2023-08-09 17:38:23 --> Model "Banner_model" initialized
INFO - 2023-08-09 17:38:23 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:23 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:38:23 --> Config Class Initialized
INFO - 2023-08-09 17:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:23 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:23 --> URI Class Initialized
INFO - 2023-08-09 17:38:23 --> Router Class Initialized
INFO - 2023-08-09 17:38:23 --> Output Class Initialized
INFO - 2023-08-09 17:38:23 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:23 --> Input Class Initialized
INFO - 2023-08-09 17:38:23 --> Language Class Initialized
INFO - 2023-08-09 17:38:23 --> Loader Class Initialized
INFO - 2023-08-09 17:38:23 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:23 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:23 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:23 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:23 --> Controller Class Initialized
INFO - 2023-08-09 17:38:23 --> Model "Banner_model" initialized
INFO - 2023-08-09 17:38:23 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:23 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 17:38:23 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:23 --> Total execution time: 0.0658
INFO - 2023-08-09 17:38:29 --> Config Class Initialized
INFO - 2023-08-09 17:38:29 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:29 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:29 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:29 --> URI Class Initialized
INFO - 2023-08-09 17:38:29 --> Router Class Initialized
INFO - 2023-08-09 17:38:29 --> Output Class Initialized
INFO - 2023-08-09 17:38:29 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:29 --> Input Class Initialized
INFO - 2023-08-09 17:38:29 --> Language Class Initialized
INFO - 2023-08-09 17:38:29 --> Loader Class Initialized
INFO - 2023-08-09 17:38:29 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:29 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:29 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:29 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:30 --> Controller Class Initialized
INFO - 2023-08-09 17:38:30 --> Model "Services_model" initialized
INFO - 2023-08-09 17:38:30 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:30 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:38:30 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:30 --> Total execution time: 0.0700
INFO - 2023-08-09 17:38:45 --> Config Class Initialized
INFO - 2023-08-09 17:38:45 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:45 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:45 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:45 --> URI Class Initialized
INFO - 2023-08-09 17:38:45 --> Router Class Initialized
INFO - 2023-08-09 17:38:45 --> Output Class Initialized
INFO - 2023-08-09 17:38:45 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:45 --> Input Class Initialized
INFO - 2023-08-09 17:38:45 --> Language Class Initialized
INFO - 2023-08-09 17:38:45 --> Loader Class Initialized
INFO - 2023-08-09 17:38:45 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:45 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:45 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:45 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:45 --> Controller Class Initialized
INFO - 2023-08-09 17:38:45 --> Model "Services_model" initialized
INFO - 2023-08-09 17:38:45 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:46 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:38:46 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:46 --> Total execution time: 0.2162
INFO - 2023-08-09 17:38:48 --> Config Class Initialized
INFO - 2023-08-09 17:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:48 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:48 --> URI Class Initialized
INFO - 2023-08-09 17:38:48 --> Router Class Initialized
INFO - 2023-08-09 17:38:48 --> Output Class Initialized
INFO - 2023-08-09 17:38:48 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:48 --> Input Class Initialized
INFO - 2023-08-09 17:38:48 --> Language Class Initialized
INFO - 2023-08-09 17:38:48 --> Loader Class Initialized
INFO - 2023-08-09 17:38:48 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:48 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:48 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:48 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:48 --> Controller Class Initialized
INFO - 2023-08-09 17:38:48 --> Model "Services_model" initialized
INFO - 2023-08-09 17:38:48 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:48 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:38:48 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:48 --> Total execution time: 0.0465
INFO - 2023-08-09 17:38:50 --> Config Class Initialized
INFO - 2023-08-09 17:38:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:38:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:38:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:38:50 --> URI Class Initialized
INFO - 2023-08-09 17:38:50 --> Router Class Initialized
INFO - 2023-08-09 17:38:50 --> Output Class Initialized
INFO - 2023-08-09 17:38:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:38:50 --> Input Class Initialized
INFO - 2023-08-09 17:38:50 --> Language Class Initialized
INFO - 2023-08-09 17:38:50 --> Loader Class Initialized
INFO - 2023-08-09 17:38:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:38:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:38:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:38:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:38:50 --> Controller Class Initialized
INFO - 2023-08-09 17:38:50 --> Model "Training_model" initialized
INFO - 2023-08-09 17:38:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:38:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:38:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:38:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:38:50 --> Total execution time: 0.0539
INFO - 2023-08-09 17:39:15 --> Config Class Initialized
INFO - 2023-08-09 17:39:15 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:39:15 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:39:15 --> Utf8 Class Initialized
INFO - 2023-08-09 17:39:15 --> URI Class Initialized
INFO - 2023-08-09 17:39:15 --> Router Class Initialized
INFO - 2023-08-09 17:39:15 --> Output Class Initialized
INFO - 2023-08-09 17:39:15 --> Security Class Initialized
DEBUG - 2023-08-09 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:39:15 --> Input Class Initialized
INFO - 2023-08-09 17:39:15 --> Language Class Initialized
INFO - 2023-08-09 17:39:15 --> Loader Class Initialized
INFO - 2023-08-09 17:39:15 --> Helper loaded: url_helper
INFO - 2023-08-09 17:39:15 --> Helper loaded: file_helper
INFO - 2023-08-09 17:39:15 --> Database Driver Class Initialized
INFO - 2023-08-09 17:39:15 --> Email Class Initialized
DEBUG - 2023-08-09 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:39:15 --> Controller Class Initialized
INFO - 2023-08-09 17:39:15 --> Model "Training_model" initialized
INFO - 2023-08-09 17:39:15 --> Helper loaded: form_helper
INFO - 2023-08-09 17:39:15 --> Form Validation Class Initialized
INFO - 2023-08-09 17:39:15 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:39:15 --> Final output sent to browser
DEBUG - 2023-08-09 17:39:16 --> Total execution time: 0.1665
INFO - 2023-08-09 17:39:18 --> Config Class Initialized
INFO - 2023-08-09 17:39:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:39:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:39:18 --> Utf8 Class Initialized
INFO - 2023-08-09 17:39:18 --> URI Class Initialized
INFO - 2023-08-09 17:39:18 --> Router Class Initialized
INFO - 2023-08-09 17:39:18 --> Output Class Initialized
INFO - 2023-08-09 17:39:18 --> Security Class Initialized
DEBUG - 2023-08-09 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:39:18 --> Input Class Initialized
INFO - 2023-08-09 17:39:18 --> Language Class Initialized
INFO - 2023-08-09 17:39:18 --> Loader Class Initialized
INFO - 2023-08-09 17:39:18 --> Helper loaded: url_helper
INFO - 2023-08-09 17:39:18 --> Helper loaded: file_helper
INFO - 2023-08-09 17:39:18 --> Database Driver Class Initialized
INFO - 2023-08-09 17:39:18 --> Email Class Initialized
DEBUG - 2023-08-09 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:39:18 --> Controller Class Initialized
INFO - 2023-08-09 17:39:18 --> Model "Training_model" initialized
INFO - 2023-08-09 17:39:18 --> Helper loaded: form_helper
INFO - 2023-08-09 17:39:18 --> Form Validation Class Initialized
INFO - 2023-08-09 17:39:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:39:18 --> Final output sent to browser
DEBUG - 2023-08-09 17:39:18 --> Total execution time: 0.0454
INFO - 2023-08-09 17:39:18 --> Config Class Initialized
INFO - 2023-08-09 17:39:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:39:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:39:18 --> Utf8 Class Initialized
INFO - 2023-08-09 17:39:18 --> URI Class Initialized
INFO - 2023-08-09 17:39:18 --> Router Class Initialized
INFO - 2023-08-09 17:39:18 --> Output Class Initialized
INFO - 2023-08-09 17:39:18 --> Security Class Initialized
DEBUG - 2023-08-09 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:39:18 --> Input Class Initialized
INFO - 2023-08-09 17:39:18 --> Language Class Initialized
INFO - 2023-08-09 17:39:18 --> Loader Class Initialized
INFO - 2023-08-09 17:39:18 --> Helper loaded: url_helper
INFO - 2023-08-09 17:39:18 --> Helper loaded: file_helper
INFO - 2023-08-09 17:39:18 --> Database Driver Class Initialized
INFO - 2023-08-09 17:39:18 --> Email Class Initialized
DEBUG - 2023-08-09 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:39:18 --> Controller Class Initialized
INFO - 2023-08-09 17:39:18 --> Model "Training_model" initialized
INFO - 2023-08-09 17:39:18 --> Helper loaded: form_helper
INFO - 2023-08-09 17:39:18 --> Form Validation Class Initialized
INFO - 2023-08-09 17:39:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:39:18 --> Final output sent to browser
DEBUG - 2023-08-09 17:39:18 --> Total execution time: 0.0701
INFO - 2023-08-09 17:39:21 --> Config Class Initialized
INFO - 2023-08-09 17:39:21 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:39:21 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:39:21 --> Utf8 Class Initialized
INFO - 2023-08-09 17:39:21 --> URI Class Initialized
INFO - 2023-08-09 17:39:21 --> Router Class Initialized
INFO - 2023-08-09 17:39:21 --> Output Class Initialized
INFO - 2023-08-09 17:39:21 --> Security Class Initialized
DEBUG - 2023-08-09 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:39:21 --> Input Class Initialized
INFO - 2023-08-09 17:39:21 --> Language Class Initialized
INFO - 2023-08-09 17:39:21 --> Loader Class Initialized
INFO - 2023-08-09 17:39:21 --> Helper loaded: url_helper
INFO - 2023-08-09 17:39:21 --> Helper loaded: file_helper
INFO - 2023-08-09 17:39:21 --> Database Driver Class Initialized
INFO - 2023-08-09 17:39:21 --> Email Class Initialized
DEBUG - 2023-08-09 17:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:39:21 --> Controller Class Initialized
INFO - 2023-08-09 17:39:21 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:39:21 --> Helper loaded: form_helper
INFO - 2023-08-09 17:39:21 --> Form Validation Class Initialized
INFO - 2023-08-09 17:39:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 17:39:21 --> Final output sent to browser
DEBUG - 2023-08-09 17:39:21 --> Total execution time: 0.0541
INFO - 2023-08-09 17:39:46 --> Config Class Initialized
INFO - 2023-08-09 17:39:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:39:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:39:46 --> Utf8 Class Initialized
INFO - 2023-08-09 17:39:46 --> URI Class Initialized
INFO - 2023-08-09 17:39:46 --> Router Class Initialized
INFO - 2023-08-09 17:39:46 --> Output Class Initialized
INFO - 2023-08-09 17:39:46 --> Security Class Initialized
DEBUG - 2023-08-09 17:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:39:46 --> Input Class Initialized
INFO - 2023-08-09 17:39:46 --> Language Class Initialized
INFO - 2023-08-09 17:39:46 --> Loader Class Initialized
INFO - 2023-08-09 17:39:46 --> Helper loaded: url_helper
INFO - 2023-08-09 17:39:46 --> Helper loaded: file_helper
INFO - 2023-08-09 17:39:46 --> Database Driver Class Initialized
INFO - 2023-08-09 17:39:46 --> Email Class Initialized
DEBUG - 2023-08-09 17:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:39:46 --> Controller Class Initialized
INFO - 2023-08-09 17:39:46 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:39:46 --> Helper loaded: form_helper
INFO - 2023-08-09 17:39:46 --> Form Validation Class Initialized
INFO - 2023-08-09 17:39:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 17:39:46 --> Final output sent to browser
DEBUG - 2023-08-09 17:39:46 --> Total execution time: 0.0928
INFO - 2023-08-09 17:40:06 --> Config Class Initialized
INFO - 2023-08-09 17:40:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:06 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:06 --> URI Class Initialized
INFO - 2023-08-09 17:40:06 --> Router Class Initialized
INFO - 2023-08-09 17:40:06 --> Output Class Initialized
INFO - 2023-08-09 17:40:06 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:06 --> Input Class Initialized
INFO - 2023-08-09 17:40:06 --> Language Class Initialized
INFO - 2023-08-09 17:40:06 --> Loader Class Initialized
INFO - 2023-08-09 17:40:06 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:06 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:06 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:06 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:06 --> Controller Class Initialized
INFO - 2023-08-09 17:40:06 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:40:06 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:06 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:40:06 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:06 --> Total execution time: 0.0942
INFO - 2023-08-09 17:40:28 --> Config Class Initialized
INFO - 2023-08-09 17:40:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:28 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:28 --> URI Class Initialized
INFO - 2023-08-09 17:40:28 --> Router Class Initialized
INFO - 2023-08-09 17:40:28 --> Output Class Initialized
INFO - 2023-08-09 17:40:28 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:28 --> Input Class Initialized
INFO - 2023-08-09 17:40:28 --> Language Class Initialized
INFO - 2023-08-09 17:40:28 --> Loader Class Initialized
INFO - 2023-08-09 17:40:28 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:28 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:28 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:28 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:28 --> Controller Class Initialized
INFO - 2023-08-09 17:40:28 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:40:28 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:28 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:40:28 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:28 --> Total execution time: 0.1823
INFO - 2023-08-09 17:40:32 --> Config Class Initialized
INFO - 2023-08-09 17:40:32 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:32 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:32 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:32 --> URI Class Initialized
INFO - 2023-08-09 17:40:32 --> Router Class Initialized
INFO - 2023-08-09 17:40:32 --> Output Class Initialized
INFO - 2023-08-09 17:40:32 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:32 --> Input Class Initialized
INFO - 2023-08-09 17:40:32 --> Language Class Initialized
INFO - 2023-08-09 17:40:32 --> Loader Class Initialized
INFO - 2023-08-09 17:40:32 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:32 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:32 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:32 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:32 --> Controller Class Initialized
INFO - 2023-08-09 17:40:32 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:40:32 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:32 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_create.php
INFO - 2023-08-09 17:40:32 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:32 --> Total execution time: 0.0448
INFO - 2023-08-09 17:40:32 --> Config Class Initialized
INFO - 2023-08-09 17:40:32 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:32 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:32 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:32 --> URI Class Initialized
INFO - 2023-08-09 17:40:32 --> Router Class Initialized
INFO - 2023-08-09 17:40:32 --> Output Class Initialized
INFO - 2023-08-09 17:40:32 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:32 --> Input Class Initialized
INFO - 2023-08-09 17:40:32 --> Language Class Initialized
ERROR - 2023-08-09 17:40:32 --> 404 Page Not Found: admin/Testimonials/images
INFO - 2023-08-09 17:40:47 --> Config Class Initialized
INFO - 2023-08-09 17:40:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:47 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:47 --> URI Class Initialized
INFO - 2023-08-09 17:40:47 --> Router Class Initialized
INFO - 2023-08-09 17:40:47 --> Output Class Initialized
INFO - 2023-08-09 17:40:47 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:47 --> Input Class Initialized
INFO - 2023-08-09 17:40:47 --> Language Class Initialized
INFO - 2023-08-09 17:40:47 --> Loader Class Initialized
INFO - 2023-08-09 17:40:47 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:47 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:47 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:47 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:47 --> Controller Class Initialized
INFO - 2023-08-09 17:40:47 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:40:47 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:47 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:40:48 --> Config Class Initialized
INFO - 2023-08-09 17:40:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:48 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:48 --> URI Class Initialized
INFO - 2023-08-09 17:40:48 --> Router Class Initialized
INFO - 2023-08-09 17:40:48 --> Output Class Initialized
INFO - 2023-08-09 17:40:48 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:48 --> Input Class Initialized
INFO - 2023-08-09 17:40:48 --> Language Class Initialized
INFO - 2023-08-09 17:40:48 --> Loader Class Initialized
INFO - 2023-08-09 17:40:48 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:48 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:48 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:48 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:48 --> Controller Class Initialized
INFO - 2023-08-09 17:40:48 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:40:48 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:48 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:40:48 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:48 --> Total execution time: 0.0715
INFO - 2023-08-09 17:40:51 --> Config Class Initialized
INFO - 2023-08-09 17:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:51 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:51 --> URI Class Initialized
INFO - 2023-08-09 17:40:51 --> Router Class Initialized
INFO - 2023-08-09 17:40:51 --> Output Class Initialized
INFO - 2023-08-09 17:40:51 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:51 --> Input Class Initialized
INFO - 2023-08-09 17:40:51 --> Language Class Initialized
INFO - 2023-08-09 17:40:51 --> Loader Class Initialized
INFO - 2023-08-09 17:40:51 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:51 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:51 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:51 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:51 --> Controller Class Initialized
INFO - 2023-08-09 17:40:51 --> Model "Banner_model" initialized
INFO - 2023-08-09 17:40:51 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:51 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-09 17:40:51 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:51 --> Total execution time: 0.0500
INFO - 2023-08-09 17:40:54 --> Config Class Initialized
INFO - 2023-08-09 17:40:54 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:54 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:54 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:54 --> URI Class Initialized
INFO - 2023-08-09 17:40:54 --> Router Class Initialized
INFO - 2023-08-09 17:40:54 --> Output Class Initialized
INFO - 2023-08-09 17:40:54 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:54 --> Input Class Initialized
INFO - 2023-08-09 17:40:54 --> Language Class Initialized
INFO - 2023-08-09 17:40:54 --> Loader Class Initialized
INFO - 2023-08-09 17:40:54 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:54 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:54 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:54 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:54 --> Controller Class Initialized
INFO - 2023-08-09 17:40:54 --> Model "Gallery_model" initialized
INFO - 2023-08-09 17:40:54 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:54 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 17:40:54 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:54 --> Total execution time: 0.0484
INFO - 2023-08-09 17:40:56 --> Config Class Initialized
INFO - 2023-08-09 17:40:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:40:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:40:56 --> Utf8 Class Initialized
INFO - 2023-08-09 17:40:56 --> URI Class Initialized
INFO - 2023-08-09 17:40:56 --> Router Class Initialized
INFO - 2023-08-09 17:40:56 --> Output Class Initialized
INFO - 2023-08-09 17:40:56 --> Security Class Initialized
DEBUG - 2023-08-09 17:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:40:56 --> Input Class Initialized
INFO - 2023-08-09 17:40:56 --> Language Class Initialized
INFO - 2023-08-09 17:40:56 --> Loader Class Initialized
INFO - 2023-08-09 17:40:56 --> Helper loaded: url_helper
INFO - 2023-08-09 17:40:56 --> Helper loaded: file_helper
INFO - 2023-08-09 17:40:56 --> Database Driver Class Initialized
INFO - 2023-08-09 17:40:56 --> Email Class Initialized
DEBUG - 2023-08-09 17:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:40:56 --> Controller Class Initialized
INFO - 2023-08-09 17:40:56 --> Model "Gallery_model" initialized
INFO - 2023-08-09 17:40:56 --> Helper loaded: form_helper
INFO - 2023-08-09 17:40:56 --> Form Validation Class Initialized
INFO - 2023-08-09 17:40:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-09 17:40:56 --> Final output sent to browser
DEBUG - 2023-08-09 17:40:56 --> Total execution time: 0.0551
INFO - 2023-08-09 17:41:11 --> Config Class Initialized
INFO - 2023-08-09 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:11 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:11 --> URI Class Initialized
INFO - 2023-08-09 17:41:11 --> Router Class Initialized
INFO - 2023-08-09 17:41:11 --> Output Class Initialized
INFO - 2023-08-09 17:41:11 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:11 --> Input Class Initialized
INFO - 2023-08-09 17:41:11 --> Language Class Initialized
INFO - 2023-08-09 17:41:11 --> Loader Class Initialized
INFO - 2023-08-09 17:41:11 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:11 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:11 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:11 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:11 --> Controller Class Initialized
INFO - 2023-08-09 17:41:11 --> Model "Gallery_model" initialized
INFO - 2023-08-09 17:41:11 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:11 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:41:11 --> Config Class Initialized
INFO - 2023-08-09 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:11 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:11 --> URI Class Initialized
INFO - 2023-08-09 17:41:11 --> Router Class Initialized
INFO - 2023-08-09 17:41:11 --> Output Class Initialized
INFO - 2023-08-09 17:41:11 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:11 --> Input Class Initialized
INFO - 2023-08-09 17:41:11 --> Language Class Initialized
INFO - 2023-08-09 17:41:11 --> Loader Class Initialized
INFO - 2023-08-09 17:41:11 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:11 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:11 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:11 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:11 --> Controller Class Initialized
INFO - 2023-08-09 17:41:12 --> Model "Gallery_model" initialized
INFO - 2023-08-09 17:41:12 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:12 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-09 17:41:12 --> Final output sent to browser
DEBUG - 2023-08-09 17:41:12 --> Total execution time: 0.5394
INFO - 2023-08-09 17:41:16 --> Config Class Initialized
INFO - 2023-08-09 17:41:16 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:16 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:16 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:16 --> URI Class Initialized
INFO - 2023-08-09 17:41:16 --> Router Class Initialized
INFO - 2023-08-09 17:41:16 --> Output Class Initialized
INFO - 2023-08-09 17:41:16 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:16 --> Input Class Initialized
INFO - 2023-08-09 17:41:16 --> Language Class Initialized
INFO - 2023-08-09 17:41:16 --> Loader Class Initialized
INFO - 2023-08-09 17:41:16 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:16 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:16 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:16 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:16 --> Controller Class Initialized
INFO - 2023-08-09 17:41:16 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:16 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:16 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:41:16 --> Final output sent to browser
DEBUG - 2023-08-09 17:41:16 --> Total execution time: 0.0559
INFO - 2023-08-09 17:41:18 --> Config Class Initialized
INFO - 2023-08-09 17:41:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:18 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:18 --> URI Class Initialized
INFO - 2023-08-09 17:41:18 --> Router Class Initialized
INFO - 2023-08-09 17:41:18 --> Output Class Initialized
INFO - 2023-08-09 17:41:18 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:18 --> Input Class Initialized
INFO - 2023-08-09 17:41:18 --> Language Class Initialized
INFO - 2023-08-09 17:41:18 --> Loader Class Initialized
INFO - 2023-08-09 17:41:18 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:18 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:18 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:18 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:18 --> Controller Class Initialized
INFO - 2023-08-09 17:41:18 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:18 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:18 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:41:18 --> Final output sent to browser
DEBUG - 2023-08-09 17:41:18 --> Total execution time: 0.0449
INFO - 2023-08-09 17:41:33 --> Config Class Initialized
INFO - 2023-08-09 17:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:33 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:33 --> URI Class Initialized
INFO - 2023-08-09 17:41:33 --> Router Class Initialized
INFO - 2023-08-09 17:41:33 --> Output Class Initialized
INFO - 2023-08-09 17:41:33 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:33 --> Input Class Initialized
INFO - 2023-08-09 17:41:33 --> Language Class Initialized
INFO - 2023-08-09 17:41:33 --> Loader Class Initialized
INFO - 2023-08-09 17:41:33 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:33 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:33 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:33 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:33 --> Controller Class Initialized
INFO - 2023-08-09 17:41:33 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:33 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:33 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:41:33 --> Upload Class Initialized
INFO - 2023-08-09 17:41:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-08-09 17:41:33 --> The upload path does not appear to be valid.
INFO - 2023-08-09 17:41:33 --> Config Class Initialized
INFO - 2023-08-09 17:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:33 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:33 --> URI Class Initialized
INFO - 2023-08-09 17:41:33 --> Router Class Initialized
INFO - 2023-08-09 17:41:33 --> Output Class Initialized
INFO - 2023-08-09 17:41:33 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:33 --> Input Class Initialized
INFO - 2023-08-09 17:41:33 --> Language Class Initialized
INFO - 2023-08-09 17:41:33 --> Loader Class Initialized
INFO - 2023-08-09 17:41:33 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:33 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:33 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:33 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:33 --> Controller Class Initialized
INFO - 2023-08-09 17:41:33 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:33 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:33 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:41:33 --> Final output sent to browser
DEBUG - 2023-08-09 17:41:33 --> Total execution time: 0.1603
INFO - 2023-08-09 17:41:50 --> Config Class Initialized
INFO - 2023-08-09 17:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:50 --> URI Class Initialized
INFO - 2023-08-09 17:41:50 --> Router Class Initialized
INFO - 2023-08-09 17:41:50 --> Output Class Initialized
INFO - 2023-08-09 17:41:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:50 --> Input Class Initialized
INFO - 2023-08-09 17:41:50 --> Language Class Initialized
INFO - 2023-08-09 17:41:50 --> Loader Class Initialized
INFO - 2023-08-09 17:41:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:50 --> Controller Class Initialized
INFO - 2023-08-09 17:41:50 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:41:50 --> Upload Class Initialized
INFO - 2023-08-09 17:41:50 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-08-09 17:41:50 --> The upload path does not appear to be valid.
INFO - 2023-08-09 17:41:50 --> Config Class Initialized
INFO - 2023-08-09 17:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:41:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:41:50 --> URI Class Initialized
INFO - 2023-08-09 17:41:50 --> Router Class Initialized
INFO - 2023-08-09 17:41:50 --> Output Class Initialized
INFO - 2023-08-09 17:41:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:41:50 --> Input Class Initialized
INFO - 2023-08-09 17:41:50 --> Language Class Initialized
INFO - 2023-08-09 17:41:50 --> Loader Class Initialized
INFO - 2023-08-09 17:41:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:41:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:41:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:41:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:41:50 --> Controller Class Initialized
INFO - 2023-08-09 17:41:50 --> Model "Services_model" initialized
INFO - 2023-08-09 17:41:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:41:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:41:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:41:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:41:50 --> Total execution time: 0.0704
INFO - 2023-08-09 17:44:39 --> Config Class Initialized
INFO - 2023-08-09 17:44:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:44:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:44:39 --> Utf8 Class Initialized
INFO - 2023-08-09 17:44:39 --> URI Class Initialized
INFO - 2023-08-09 17:44:39 --> Router Class Initialized
INFO - 2023-08-09 17:44:39 --> Output Class Initialized
INFO - 2023-08-09 17:44:39 --> Security Class Initialized
DEBUG - 2023-08-09 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:44:39 --> Input Class Initialized
INFO - 2023-08-09 17:44:39 --> Language Class Initialized
INFO - 2023-08-09 17:44:39 --> Loader Class Initialized
INFO - 2023-08-09 17:44:39 --> Helper loaded: url_helper
INFO - 2023-08-09 17:44:39 --> Helper loaded: file_helper
INFO - 2023-08-09 17:44:39 --> Database Driver Class Initialized
INFO - 2023-08-09 17:44:39 --> Email Class Initialized
DEBUG - 2023-08-09 17:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:44:39 --> Controller Class Initialized
INFO - 2023-08-09 17:44:39 --> Model "Services_model" initialized
INFO - 2023-08-09 17:44:39 --> Helper loaded: form_helper
INFO - 2023-08-09 17:44:39 --> Form Validation Class Initialized
INFO - 2023-08-09 17:44:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:44:39 --> Final output sent to browser
DEBUG - 2023-08-09 17:44:39 --> Total execution time: 0.0826
INFO - 2023-08-09 17:44:55 --> Config Class Initialized
INFO - 2023-08-09 17:44:55 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:44:55 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:44:55 --> Utf8 Class Initialized
INFO - 2023-08-09 17:44:55 --> URI Class Initialized
INFO - 2023-08-09 17:44:55 --> Router Class Initialized
INFO - 2023-08-09 17:44:55 --> Output Class Initialized
INFO - 2023-08-09 17:44:55 --> Security Class Initialized
DEBUG - 2023-08-09 17:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:44:55 --> Input Class Initialized
INFO - 2023-08-09 17:44:55 --> Language Class Initialized
INFO - 2023-08-09 17:44:55 --> Loader Class Initialized
INFO - 2023-08-09 17:44:55 --> Helper loaded: url_helper
INFO - 2023-08-09 17:44:55 --> Helper loaded: file_helper
INFO - 2023-08-09 17:44:55 --> Database Driver Class Initialized
INFO - 2023-08-09 17:44:55 --> Email Class Initialized
DEBUG - 2023-08-09 17:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:44:55 --> Controller Class Initialized
INFO - 2023-08-09 17:44:55 --> Model "Services_model" initialized
INFO - 2023-08-09 17:44:55 --> Helper loaded: form_helper
INFO - 2023-08-09 17:44:55 --> Form Validation Class Initialized
INFO - 2023-08-09 17:44:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-09 17:44:55 --> Severity: Warning --> move_uploaded_file(./assets/images/services/1691595895female.jpg): Failed to open stream: No such file or directory C:\xampp\htdocs\DW\application\controllers\Admin\Services.php 40
ERROR - 2023-08-09 17:44:55 --> Severity: Warning --> move_uploaded_file(): Unable to move &quot;C:\xampp\tmp\php8429.tmp&quot; to &quot;./assets/images/services/1691595895female.jpg&quot; C:\xampp\htdocs\DW\application\controllers\Admin\Services.php 40
INFO - 2023-08-09 17:44:55 --> Config Class Initialized
INFO - 2023-08-09 17:44:55 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:44:55 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:44:55 --> Utf8 Class Initialized
INFO - 2023-08-09 17:44:55 --> URI Class Initialized
INFO - 2023-08-09 17:44:55 --> Router Class Initialized
INFO - 2023-08-09 17:44:55 --> Output Class Initialized
INFO - 2023-08-09 17:44:55 --> Security Class Initialized
DEBUG - 2023-08-09 17:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:44:55 --> Input Class Initialized
INFO - 2023-08-09 17:44:55 --> Language Class Initialized
INFO - 2023-08-09 17:44:55 --> Loader Class Initialized
INFO - 2023-08-09 17:44:55 --> Helper loaded: url_helper
INFO - 2023-08-09 17:44:55 --> Helper loaded: file_helper
INFO - 2023-08-09 17:44:55 --> Database Driver Class Initialized
INFO - 2023-08-09 17:44:55 --> Email Class Initialized
DEBUG - 2023-08-09 17:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:44:55 --> Controller Class Initialized
INFO - 2023-08-09 17:44:55 --> Model "Services_model" initialized
INFO - 2023-08-09 17:44:55 --> Helper loaded: form_helper
INFO - 2023-08-09 17:44:55 --> Form Validation Class Initialized
INFO - 2023-08-09 17:44:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:44:55 --> Final output sent to browser
DEBUG - 2023-08-09 17:44:55 --> Total execution time: 0.0471
INFO - 2023-08-09 17:44:55 --> Config Class Initialized
INFO - 2023-08-09 17:44:55 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:44:55 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:44:55 --> Utf8 Class Initialized
INFO - 2023-08-09 17:44:55 --> URI Class Initialized
INFO - 2023-08-09 17:44:55 --> Router Class Initialized
INFO - 2023-08-09 17:44:55 --> Output Class Initialized
INFO - 2023-08-09 17:44:55 --> Security Class Initialized
DEBUG - 2023-08-09 17:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:44:55 --> Input Class Initialized
INFO - 2023-08-09 17:44:55 --> Language Class Initialized
ERROR - 2023-08-09 17:44:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:45:25 --> Config Class Initialized
INFO - 2023-08-09 17:45:25 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:25 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:25 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:25 --> URI Class Initialized
INFO - 2023-08-09 17:45:25 --> Router Class Initialized
INFO - 2023-08-09 17:45:25 --> Output Class Initialized
INFO - 2023-08-09 17:45:25 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:25 --> Input Class Initialized
INFO - 2023-08-09 17:45:25 --> Language Class Initialized
INFO - 2023-08-09 17:45:25 --> Loader Class Initialized
INFO - 2023-08-09 17:45:25 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:25 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:25 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:25 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:25 --> Controller Class Initialized
INFO - 2023-08-09 17:45:25 --> Model "Services_model" initialized
INFO - 2023-08-09 17:45:25 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:25 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_create.php
INFO - 2023-08-09 17:45:25 --> Final output sent to browser
DEBUG - 2023-08-09 17:45:25 --> Total execution time: 0.0574
INFO - 2023-08-09 17:45:40 --> Config Class Initialized
INFO - 2023-08-09 17:45:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:40 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:40 --> URI Class Initialized
INFO - 2023-08-09 17:45:40 --> Router Class Initialized
INFO - 2023-08-09 17:45:40 --> Output Class Initialized
INFO - 2023-08-09 17:45:40 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:40 --> Input Class Initialized
INFO - 2023-08-09 17:45:40 --> Language Class Initialized
INFO - 2023-08-09 17:45:40 --> Loader Class Initialized
INFO - 2023-08-09 17:45:40 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:40 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:40 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:40 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:40 --> Controller Class Initialized
INFO - 2023-08-09 17:45:40 --> Model "Services_model" initialized
INFO - 2023-08-09 17:45:40 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:40 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:45:40 --> Config Class Initialized
INFO - 2023-08-09 17:45:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:40 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:40 --> URI Class Initialized
INFO - 2023-08-09 17:45:40 --> Router Class Initialized
INFO - 2023-08-09 17:45:40 --> Output Class Initialized
INFO - 2023-08-09 17:45:40 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:40 --> Input Class Initialized
INFO - 2023-08-09 17:45:40 --> Language Class Initialized
INFO - 2023-08-09 17:45:40 --> Loader Class Initialized
INFO - 2023-08-09 17:45:40 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:40 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:40 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:40 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:40 --> Controller Class Initialized
INFO - 2023-08-09 17:45:40 --> Model "Services_model" initialized
INFO - 2023-08-09 17:45:40 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:40 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:45:40 --> Final output sent to browser
DEBUG - 2023-08-09 17:45:40 --> Total execution time: 0.0817
INFO - 2023-08-09 17:45:40 --> Config Class Initialized
INFO - 2023-08-09 17:45:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:40 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:40 --> URI Class Initialized
INFO - 2023-08-09 17:45:40 --> Router Class Initialized
INFO - 2023-08-09 17:45:40 --> Output Class Initialized
INFO - 2023-08-09 17:45:40 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:40 --> Input Class Initialized
INFO - 2023-08-09 17:45:40 --> Language Class Initialized
ERROR - 2023-08-09 17:45:40 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:45:47 --> Config Class Initialized
INFO - 2023-08-09 17:45:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:47 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:47 --> URI Class Initialized
INFO - 2023-08-09 17:45:47 --> Router Class Initialized
INFO - 2023-08-09 17:45:47 --> Output Class Initialized
INFO - 2023-08-09 17:45:47 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:47 --> Input Class Initialized
INFO - 2023-08-09 17:45:47 --> Language Class Initialized
INFO - 2023-08-09 17:45:47 --> Loader Class Initialized
INFO - 2023-08-09 17:45:47 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:47 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:47 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:47 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:47 --> Controller Class Initialized
INFO - 2023-08-09 17:45:47 --> Model "Training_model" initialized
INFO - 2023-08-09 17:45:47 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:47 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:45:47 --> Final output sent to browser
DEBUG - 2023-08-09 17:45:47 --> Total execution time: 0.0450
INFO - 2023-08-09 17:45:50 --> Config Class Initialized
INFO - 2023-08-09 17:45:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:50 --> URI Class Initialized
INFO - 2023-08-09 17:45:50 --> Router Class Initialized
INFO - 2023-08-09 17:45:50 --> Output Class Initialized
INFO - 2023-08-09 17:45:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:50 --> Input Class Initialized
INFO - 2023-08-09 17:45:50 --> Language Class Initialized
INFO - 2023-08-09 17:45:50 --> Loader Class Initialized
INFO - 2023-08-09 17:45:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:50 --> Controller Class Initialized
INFO - 2023-08-09 17:45:50 --> Model "Training_model" initialized
INFO - 2023-08-09 17:45:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:45:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:45:50 --> Total execution time: 0.0515
INFO - 2023-08-09 17:45:50 --> Config Class Initialized
INFO - 2023-08-09 17:45:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:45:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:45:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:45:50 --> URI Class Initialized
INFO - 2023-08-09 17:45:50 --> Router Class Initialized
INFO - 2023-08-09 17:45:50 --> Output Class Initialized
INFO - 2023-08-09 17:45:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:45:50 --> Input Class Initialized
INFO - 2023-08-09 17:45:50 --> Language Class Initialized
INFO - 2023-08-09 17:45:50 --> Loader Class Initialized
INFO - 2023-08-09 17:45:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:45:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:45:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:45:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:45:50 --> Controller Class Initialized
INFO - 2023-08-09 17:45:50 --> Model "Training_model" initialized
INFO - 2023-08-09 17:45:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:45:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:45:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:45:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:45:50 --> Total execution time: 0.0390
INFO - 2023-08-09 17:49:56 --> Config Class Initialized
INFO - 2023-08-09 17:49:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:49:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:49:56 --> Utf8 Class Initialized
INFO - 2023-08-09 17:49:56 --> URI Class Initialized
INFO - 2023-08-09 17:49:56 --> Router Class Initialized
INFO - 2023-08-09 17:49:56 --> Output Class Initialized
INFO - 2023-08-09 17:49:56 --> Security Class Initialized
DEBUG - 2023-08-09 17:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:49:56 --> Input Class Initialized
INFO - 2023-08-09 17:49:56 --> Language Class Initialized
INFO - 2023-08-09 17:49:56 --> Loader Class Initialized
INFO - 2023-08-09 17:49:56 --> Helper loaded: url_helper
INFO - 2023-08-09 17:49:56 --> Helper loaded: file_helper
INFO - 2023-08-09 17:49:56 --> Database Driver Class Initialized
INFO - 2023-08-09 17:49:56 --> Email Class Initialized
DEBUG - 2023-08-09 17:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:49:56 --> Controller Class Initialized
INFO - 2023-08-09 17:49:56 --> Model "Services_model" initialized
INFO - 2023-08-09 17:49:56 --> Helper loaded: form_helper
INFO - 2023-08-09 17:49:56 --> Form Validation Class Initialized
INFO - 2023-08-09 17:49:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:49:56 --> Final output sent to browser
DEBUG - 2023-08-09 17:49:56 --> Total execution time: 0.0780
INFO - 2023-08-09 17:49:57 --> Config Class Initialized
INFO - 2023-08-09 17:49:57 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:49:57 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:49:57 --> Utf8 Class Initialized
INFO - 2023-08-09 17:49:57 --> URI Class Initialized
INFO - 2023-08-09 17:49:57 --> Router Class Initialized
INFO - 2023-08-09 17:49:57 --> Output Class Initialized
INFO - 2023-08-09 17:49:57 --> Security Class Initialized
DEBUG - 2023-08-09 17:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:49:57 --> Input Class Initialized
INFO - 2023-08-09 17:49:57 --> Language Class Initialized
ERROR - 2023-08-09 17:49:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:49:58 --> Config Class Initialized
INFO - 2023-08-09 17:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:49:58 --> Utf8 Class Initialized
INFO - 2023-08-09 17:49:59 --> URI Class Initialized
INFO - 2023-08-09 17:49:59 --> Router Class Initialized
INFO - 2023-08-09 17:49:59 --> Output Class Initialized
INFO - 2023-08-09 17:49:59 --> Security Class Initialized
DEBUG - 2023-08-09 17:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:49:59 --> Input Class Initialized
INFO - 2023-08-09 17:49:59 --> Language Class Initialized
INFO - 2023-08-09 17:49:59 --> Loader Class Initialized
INFO - 2023-08-09 17:49:59 --> Helper loaded: url_helper
INFO - 2023-08-09 17:49:59 --> Helper loaded: file_helper
INFO - 2023-08-09 17:49:59 --> Database Driver Class Initialized
INFO - 2023-08-09 17:49:59 --> Email Class Initialized
DEBUG - 2023-08-09 17:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:49:59 --> Controller Class Initialized
INFO - 2023-08-09 17:49:59 --> Model "Services_model" initialized
INFO - 2023-08-09 17:49:59 --> Helper loaded: form_helper
INFO - 2023-08-09 17:49:59 --> Form Validation Class Initialized
INFO - 2023-08-09 17:49:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-09 17:49:59 --> Final output sent to browser
DEBUG - 2023-08-09 17:49:59 --> Total execution time: 0.1689
INFO - 2023-08-09 17:49:59 --> Config Class Initialized
INFO - 2023-08-09 17:49:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:49:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:49:59 --> Utf8 Class Initialized
INFO - 2023-08-09 17:49:59 --> URI Class Initialized
INFO - 2023-08-09 17:49:59 --> Router Class Initialized
INFO - 2023-08-09 17:49:59 --> Output Class Initialized
INFO - 2023-08-09 17:49:59 --> Security Class Initialized
DEBUG - 2023-08-09 17:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:49:59 --> Input Class Initialized
INFO - 2023-08-09 17:49:59 --> Language Class Initialized
INFO - 2023-08-09 17:49:59 --> Loader Class Initialized
INFO - 2023-08-09 17:49:59 --> Helper loaded: url_helper
INFO - 2023-08-09 17:49:59 --> Helper loaded: file_helper
INFO - 2023-08-09 17:49:59 --> Database Driver Class Initialized
INFO - 2023-08-09 17:49:59 --> Email Class Initialized
DEBUG - 2023-08-09 17:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:49:59 --> Controller Class Initialized
INFO - 2023-08-09 17:49:59 --> Model "Services_model" initialized
INFO - 2023-08-09 17:49:59 --> Helper loaded: form_helper
INFO - 2023-08-09 17:49:59 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 39
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 46
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 56
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 71
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 85
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 86
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 87
ERROR - 2023-08-09 17:49:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 99
INFO - 2023-08-09 17:49:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-09 17:49:59 --> Final output sent to browser
DEBUG - 2023-08-09 17:49:59 --> Total execution time: 0.0504
INFO - 2023-08-09 17:50:03 --> Config Class Initialized
INFO - 2023-08-09 17:50:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:03 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:03 --> URI Class Initialized
INFO - 2023-08-09 17:50:03 --> Router Class Initialized
INFO - 2023-08-09 17:50:03 --> Output Class Initialized
INFO - 2023-08-09 17:50:03 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:03 --> Input Class Initialized
INFO - 2023-08-09 17:50:03 --> Language Class Initialized
INFO - 2023-08-09 17:50:03 --> Loader Class Initialized
INFO - 2023-08-09 17:50:03 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:03 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:03 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:03 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:03 --> Controller Class Initialized
INFO - 2023-08-09 17:50:03 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:03 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:03 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:50:03 --> Config Class Initialized
INFO - 2023-08-09 17:50:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:03 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:03 --> URI Class Initialized
INFO - 2023-08-09 17:50:03 --> Router Class Initialized
INFO - 2023-08-09 17:50:03 --> Output Class Initialized
INFO - 2023-08-09 17:50:03 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:03 --> Input Class Initialized
INFO - 2023-08-09 17:50:03 --> Language Class Initialized
INFO - 2023-08-09 17:50:03 --> Loader Class Initialized
INFO - 2023-08-09 17:50:03 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:03 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:03 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:03 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:03 --> Controller Class Initialized
INFO - 2023-08-09 17:50:03 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:03 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:03 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:50:03 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:03 --> Total execution time: 0.0874
INFO - 2023-08-09 17:50:03 --> Config Class Initialized
INFO - 2023-08-09 17:50:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:03 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:03 --> URI Class Initialized
INFO - 2023-08-09 17:50:03 --> Router Class Initialized
INFO - 2023-08-09 17:50:03 --> Output Class Initialized
INFO - 2023-08-09 17:50:03 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:03 --> Input Class Initialized
INFO - 2023-08-09 17:50:03 --> Language Class Initialized
ERROR - 2023-08-09 17:50:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:50:05 --> Config Class Initialized
INFO - 2023-08-09 17:50:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:05 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:05 --> URI Class Initialized
INFO - 2023-08-09 17:50:05 --> Router Class Initialized
INFO - 2023-08-09 17:50:05 --> Output Class Initialized
INFO - 2023-08-09 17:50:05 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:05 --> Input Class Initialized
INFO - 2023-08-09 17:50:05 --> Language Class Initialized
INFO - 2023-08-09 17:50:05 --> Loader Class Initialized
INFO - 2023-08-09 17:50:05 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:05 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:05 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:05 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:05 --> Controller Class Initialized
INFO - 2023-08-09 17:50:05 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:05 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:05 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-09 17:50:05 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:05 --> Total execution time: 0.0507
INFO - 2023-08-09 17:50:06 --> Config Class Initialized
INFO - 2023-08-09 17:50:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:06 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:06 --> URI Class Initialized
INFO - 2023-08-09 17:50:06 --> Router Class Initialized
INFO - 2023-08-09 17:50:06 --> Output Class Initialized
INFO - 2023-08-09 17:50:06 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:06 --> Input Class Initialized
INFO - 2023-08-09 17:50:06 --> Language Class Initialized
INFO - 2023-08-09 17:50:06 --> Loader Class Initialized
INFO - 2023-08-09 17:50:06 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:06 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:06 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:06 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:06 --> Controller Class Initialized
INFO - 2023-08-09 17:50:06 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:06 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:06 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 39
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 46
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 56
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 71
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 85
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 86
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 87
ERROR - 2023-08-09 17:50:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\services_edit.php 99
INFO - 2023-08-09 17:50:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_edit.php
INFO - 2023-08-09 17:50:06 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:06 --> Total execution time: 0.0484
INFO - 2023-08-09 17:50:13 --> Config Class Initialized
INFO - 2023-08-09 17:50:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:13 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:13 --> URI Class Initialized
INFO - 2023-08-09 17:50:13 --> Router Class Initialized
INFO - 2023-08-09 17:50:13 --> Output Class Initialized
INFO - 2023-08-09 17:50:13 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:13 --> Input Class Initialized
INFO - 2023-08-09 17:50:13 --> Language Class Initialized
INFO - 2023-08-09 17:50:13 --> Loader Class Initialized
INFO - 2023-08-09 17:50:13 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:13 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:13 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:13 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:13 --> Controller Class Initialized
INFO - 2023-08-09 17:50:13 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:13 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:13 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:50:14 --> Config Class Initialized
INFO - 2023-08-09 17:50:14 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:14 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:14 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:14 --> URI Class Initialized
INFO - 2023-08-09 17:50:14 --> Router Class Initialized
INFO - 2023-08-09 17:50:14 --> Output Class Initialized
INFO - 2023-08-09 17:50:14 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:14 --> Input Class Initialized
INFO - 2023-08-09 17:50:14 --> Language Class Initialized
INFO - 2023-08-09 17:50:14 --> Loader Class Initialized
INFO - 2023-08-09 17:50:14 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:14 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:14 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:14 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:14 --> Controller Class Initialized
INFO - 2023-08-09 17:50:14 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:14 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:14 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:14 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:50:14 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:14 --> Total execution time: 0.0458
INFO - 2023-08-09 17:50:14 --> Config Class Initialized
INFO - 2023-08-09 17:50:14 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:14 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:14 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:14 --> URI Class Initialized
INFO - 2023-08-09 17:50:14 --> Router Class Initialized
INFO - 2023-08-09 17:50:14 --> Output Class Initialized
INFO - 2023-08-09 17:50:14 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:14 --> Input Class Initialized
INFO - 2023-08-09 17:50:14 --> Language Class Initialized
ERROR - 2023-08-09 17:50:14 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:50:49 --> Config Class Initialized
INFO - 2023-08-09 17:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:49 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:49 --> URI Class Initialized
INFO - 2023-08-09 17:50:49 --> Router Class Initialized
INFO - 2023-08-09 17:50:49 --> Output Class Initialized
INFO - 2023-08-09 17:50:49 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:49 --> Input Class Initialized
INFO - 2023-08-09 17:50:49 --> Language Class Initialized
INFO - 2023-08-09 17:50:49 --> Loader Class Initialized
INFO - 2023-08-09 17:50:49 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:49 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:49 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:49 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:49 --> Controller Class Initialized
INFO - 2023-08-09 17:50:49 --> Model "Services_model" initialized
INFO - 2023-08-09 17:50:49 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:49 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 17:50:49 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:49 --> Total execution time: 0.0995
INFO - 2023-08-09 17:50:49 --> Config Class Initialized
INFO - 2023-08-09 17:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:49 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:49 --> URI Class Initialized
INFO - 2023-08-09 17:50:49 --> Router Class Initialized
INFO - 2023-08-09 17:50:49 --> Output Class Initialized
INFO - 2023-08-09 17:50:49 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:49 --> Input Class Initialized
INFO - 2023-08-09 17:50:49 --> Language Class Initialized
ERROR - 2023-08-09 17:50:49 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 17:50:57 --> Config Class Initialized
INFO - 2023-08-09 17:50:57 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:57 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:57 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:57 --> URI Class Initialized
INFO - 2023-08-09 17:50:57 --> Router Class Initialized
INFO - 2023-08-09 17:50:57 --> Output Class Initialized
INFO - 2023-08-09 17:50:57 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:57 --> Input Class Initialized
INFO - 2023-08-09 17:50:57 --> Language Class Initialized
INFO - 2023-08-09 17:50:57 --> Loader Class Initialized
INFO - 2023-08-09 17:50:57 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:57 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:57 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:57 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:57 --> Controller Class Initialized
INFO - 2023-08-09 17:50:57 --> Model "Training_model" initialized
INFO - 2023-08-09 17:50:57 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:57 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:50:57 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:57 --> Total execution time: 0.0651
INFO - 2023-08-09 17:50:59 --> Config Class Initialized
INFO - 2023-08-09 17:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:59 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:59 --> URI Class Initialized
INFO - 2023-08-09 17:50:59 --> Router Class Initialized
INFO - 2023-08-09 17:50:59 --> Output Class Initialized
INFO - 2023-08-09 17:50:59 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:59 --> Input Class Initialized
INFO - 2023-08-09 17:50:59 --> Language Class Initialized
INFO - 2023-08-09 17:50:59 --> Loader Class Initialized
INFO - 2023-08-09 17:50:59 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:59 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:59 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:59 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:59 --> Controller Class Initialized
INFO - 2023-08-09 17:50:59 --> Model "Training_model" initialized
INFO - 2023-08-09 17:50:59 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:59 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:50:59 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:59 --> Total execution time: 0.0507
INFO - 2023-08-09 17:50:59 --> Config Class Initialized
INFO - 2023-08-09 17:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:50:59 --> Utf8 Class Initialized
INFO - 2023-08-09 17:50:59 --> URI Class Initialized
INFO - 2023-08-09 17:50:59 --> Router Class Initialized
INFO - 2023-08-09 17:50:59 --> Output Class Initialized
INFO - 2023-08-09 17:50:59 --> Security Class Initialized
DEBUG - 2023-08-09 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:50:59 --> Input Class Initialized
INFO - 2023-08-09 17:50:59 --> Language Class Initialized
INFO - 2023-08-09 17:50:59 --> Loader Class Initialized
INFO - 2023-08-09 17:50:59 --> Helper loaded: url_helper
INFO - 2023-08-09 17:50:59 --> Helper loaded: file_helper
INFO - 2023-08-09 17:50:59 --> Database Driver Class Initialized
INFO - 2023-08-09 17:50:59 --> Email Class Initialized
DEBUG - 2023-08-09 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:50:59 --> Controller Class Initialized
INFO - 2023-08-09 17:50:59 --> Model "Training_model" initialized
INFO - 2023-08-09 17:50:59 --> Helper loaded: form_helper
INFO - 2023-08-09 17:50:59 --> Form Validation Class Initialized
INFO - 2023-08-09 17:50:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_create.php
INFO - 2023-08-09 17:50:59 --> Final output sent to browser
DEBUG - 2023-08-09 17:50:59 --> Total execution time: 0.0418
INFO - 2023-08-09 17:53:41 --> Config Class Initialized
INFO - 2023-08-09 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:53:41 --> Utf8 Class Initialized
INFO - 2023-08-09 17:53:41 --> URI Class Initialized
INFO - 2023-08-09 17:53:41 --> Router Class Initialized
INFO - 2023-08-09 17:53:41 --> Output Class Initialized
INFO - 2023-08-09 17:53:41 --> Security Class Initialized
DEBUG - 2023-08-09 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:53:41 --> Input Class Initialized
INFO - 2023-08-09 17:53:41 --> Language Class Initialized
INFO - 2023-08-09 17:53:41 --> Loader Class Initialized
INFO - 2023-08-09 17:53:41 --> Helper loaded: url_helper
INFO - 2023-08-09 17:53:41 --> Helper loaded: file_helper
INFO - 2023-08-09 17:53:41 --> Database Driver Class Initialized
INFO - 2023-08-09 17:53:41 --> Email Class Initialized
DEBUG - 2023-08-09 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:53:41 --> Controller Class Initialized
INFO - 2023-08-09 17:53:41 --> Model "Training_model" initialized
INFO - 2023-08-09 17:53:41 --> Helper loaded: form_helper
INFO - 2023-08-09 17:53:41 --> Form Validation Class Initialized
INFO - 2023-08-09 17:53:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:53:41 --> Config Class Initialized
INFO - 2023-08-09 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:53:41 --> Utf8 Class Initialized
INFO - 2023-08-09 17:53:41 --> URI Class Initialized
INFO - 2023-08-09 17:53:41 --> Router Class Initialized
INFO - 2023-08-09 17:53:41 --> Output Class Initialized
INFO - 2023-08-09 17:53:41 --> Security Class Initialized
DEBUG - 2023-08-09 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:53:41 --> Input Class Initialized
INFO - 2023-08-09 17:53:41 --> Language Class Initialized
INFO - 2023-08-09 17:53:41 --> Loader Class Initialized
INFO - 2023-08-09 17:53:41 --> Helper loaded: url_helper
INFO - 2023-08-09 17:53:41 --> Helper loaded: file_helper
INFO - 2023-08-09 17:53:41 --> Database Driver Class Initialized
INFO - 2023-08-09 17:53:41 --> Email Class Initialized
DEBUG - 2023-08-09 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:53:41 --> Controller Class Initialized
INFO - 2023-08-09 17:53:41 --> Model "Training_model" initialized
INFO - 2023-08-09 17:53:41 --> Helper loaded: form_helper
INFO - 2023-08-09 17:53:41 --> Form Validation Class Initialized
INFO - 2023-08-09 17:53:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:53:41 --> Final output sent to browser
DEBUG - 2023-08-09 17:53:41 --> Total execution time: 0.0739
INFO - 2023-08-09 17:53:51 --> Config Class Initialized
INFO - 2023-08-09 17:53:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:53:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:53:51 --> Utf8 Class Initialized
INFO - 2023-08-09 17:53:51 --> URI Class Initialized
INFO - 2023-08-09 17:53:51 --> Router Class Initialized
INFO - 2023-08-09 17:53:51 --> Output Class Initialized
INFO - 2023-08-09 17:53:51 --> Security Class Initialized
DEBUG - 2023-08-09 17:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:53:51 --> Input Class Initialized
INFO - 2023-08-09 17:53:51 --> Language Class Initialized
INFO - 2023-08-09 17:53:51 --> Loader Class Initialized
INFO - 2023-08-09 17:53:51 --> Helper loaded: url_helper
INFO - 2023-08-09 17:53:51 --> Helper loaded: file_helper
INFO - 2023-08-09 17:53:51 --> Database Driver Class Initialized
INFO - 2023-08-09 17:53:51 --> Email Class Initialized
DEBUG - 2023-08-09 17:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:53:51 --> Controller Class Initialized
INFO - 2023-08-09 17:53:51 --> Model "Training_model" initialized
INFO - 2023-08-09 17:53:51 --> Helper loaded: form_helper
INFO - 2023-08-09 17:53:51 --> Form Validation Class Initialized
INFO - 2023-08-09 17:53:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:53:51 --> Final output sent to browser
DEBUG - 2023-08-09 17:53:51 --> Total execution time: 0.0446
INFO - 2023-08-09 17:53:51 --> Config Class Initialized
INFO - 2023-08-09 17:53:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:53:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:53:51 --> Utf8 Class Initialized
INFO - 2023-08-09 17:53:51 --> URI Class Initialized
INFO - 2023-08-09 17:53:51 --> Router Class Initialized
INFO - 2023-08-09 17:53:51 --> Output Class Initialized
INFO - 2023-08-09 17:53:51 --> Security Class Initialized
DEBUG - 2023-08-09 17:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:53:51 --> Input Class Initialized
INFO - 2023-08-09 17:53:51 --> Language Class Initialized
INFO - 2023-08-09 17:53:51 --> Loader Class Initialized
INFO - 2023-08-09 17:53:51 --> Helper loaded: url_helper
INFO - 2023-08-09 17:53:51 --> Helper loaded: file_helper
INFO - 2023-08-09 17:53:51 --> Database Driver Class Initialized
INFO - 2023-08-09 17:53:51 --> Email Class Initialized
DEBUG - 2023-08-09 17:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:53:51 --> Controller Class Initialized
INFO - 2023-08-09 17:53:51 --> Model "Training_model" initialized
INFO - 2023-08-09 17:53:51 --> Helper loaded: form_helper
INFO - 2023-08-09 17:53:51 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 39
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 46
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 55
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 69
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 81
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 98
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 99
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 100
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 116
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 126
ERROR - 2023-08-09 17:53:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 127
INFO - 2023-08-09 17:53:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:53:51 --> Final output sent to browser
DEBUG - 2023-08-09 17:53:51 --> Total execution time: 0.0740
INFO - 2023-08-09 17:54:12 --> Config Class Initialized
INFO - 2023-08-09 17:54:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:54:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:54:12 --> Utf8 Class Initialized
INFO - 2023-08-09 17:54:12 --> URI Class Initialized
INFO - 2023-08-09 17:54:12 --> Router Class Initialized
INFO - 2023-08-09 17:54:12 --> Output Class Initialized
INFO - 2023-08-09 17:54:12 --> Security Class Initialized
DEBUG - 2023-08-09 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:54:12 --> Input Class Initialized
INFO - 2023-08-09 17:54:12 --> Language Class Initialized
INFO - 2023-08-09 17:54:12 --> Loader Class Initialized
INFO - 2023-08-09 17:54:12 --> Helper loaded: url_helper
INFO - 2023-08-09 17:54:12 --> Helper loaded: file_helper
INFO - 2023-08-09 17:54:12 --> Database Driver Class Initialized
INFO - 2023-08-09 17:54:12 --> Email Class Initialized
DEBUG - 2023-08-09 17:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:54:12 --> Controller Class Initialized
INFO - 2023-08-09 17:54:12 --> Model "Training_model" initialized
INFO - 2023-08-09 17:54:12 --> Helper loaded: form_helper
INFO - 2023-08-09 17:54:12 --> Form Validation Class Initialized
INFO - 2023-08-09 17:54:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:54:12 --> Config Class Initialized
INFO - 2023-08-09 17:54:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:54:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:54:12 --> Utf8 Class Initialized
INFO - 2023-08-09 17:54:12 --> URI Class Initialized
INFO - 2023-08-09 17:54:12 --> Router Class Initialized
INFO - 2023-08-09 17:54:12 --> Output Class Initialized
INFO - 2023-08-09 17:54:12 --> Security Class Initialized
DEBUG - 2023-08-09 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:54:12 --> Input Class Initialized
INFO - 2023-08-09 17:54:12 --> Language Class Initialized
INFO - 2023-08-09 17:54:12 --> Loader Class Initialized
INFO - 2023-08-09 17:54:12 --> Helper loaded: url_helper
INFO - 2023-08-09 17:54:12 --> Helper loaded: file_helper
INFO - 2023-08-09 17:54:12 --> Database Driver Class Initialized
INFO - 2023-08-09 17:54:12 --> Email Class Initialized
DEBUG - 2023-08-09 17:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:54:12 --> Controller Class Initialized
INFO - 2023-08-09 17:54:12 --> Model "Training_model" initialized
INFO - 2023-08-09 17:54:12 --> Helper loaded: form_helper
INFO - 2023-08-09 17:54:12 --> Form Validation Class Initialized
INFO - 2023-08-09 17:54:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:54:12 --> Final output sent to browser
DEBUG - 2023-08-09 17:54:12 --> Total execution time: 0.0653
INFO - 2023-08-09 17:55:10 --> Config Class Initialized
INFO - 2023-08-09 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:10 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:10 --> URI Class Initialized
INFO - 2023-08-09 17:55:10 --> Router Class Initialized
INFO - 2023-08-09 17:55:10 --> Output Class Initialized
INFO - 2023-08-09 17:55:10 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:10 --> Input Class Initialized
INFO - 2023-08-09 17:55:10 --> Language Class Initialized
INFO - 2023-08-09 17:55:10 --> Loader Class Initialized
INFO - 2023-08-09 17:55:10 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:10 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:10 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:10 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:10 --> Controller Class Initialized
INFO - 2023-08-09 17:55:10 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:10 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:10 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:55:10 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:10 --> Total execution time: 0.1861
INFO - 2023-08-09 17:55:10 --> Config Class Initialized
INFO - 2023-08-09 17:55:10 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:10 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:10 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:10 --> URI Class Initialized
INFO - 2023-08-09 17:55:10 --> Router Class Initialized
INFO - 2023-08-09 17:55:10 --> Output Class Initialized
INFO - 2023-08-09 17:55:10 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:10 --> Input Class Initialized
INFO - 2023-08-09 17:55:10 --> Language Class Initialized
INFO - 2023-08-09 17:55:10 --> Loader Class Initialized
INFO - 2023-08-09 17:55:10 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:10 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:10 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:10 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:10 --> Controller Class Initialized
INFO - 2023-08-09 17:55:10 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:10 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:11 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 39
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 46
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 55
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 69
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 81
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 98
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 99
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 100
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 116
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 126
ERROR - 2023-08-09 17:55:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 127
INFO - 2023-08-09 17:55:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:55:11 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:11 --> Total execution time: 0.4395
INFO - 2023-08-09 17:55:14 --> Config Class Initialized
INFO - 2023-08-09 17:55:14 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:14 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:14 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:14 --> URI Class Initialized
INFO - 2023-08-09 17:55:14 --> Router Class Initialized
INFO - 2023-08-09 17:55:14 --> Output Class Initialized
INFO - 2023-08-09 17:55:14 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:14 --> Input Class Initialized
INFO - 2023-08-09 17:55:14 --> Language Class Initialized
INFO - 2023-08-09 17:55:14 --> Loader Class Initialized
INFO - 2023-08-09 17:55:14 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:14 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:14 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:14 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:14 --> Controller Class Initialized
INFO - 2023-08-09 17:55:14 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:14 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:14 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:14 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:55:14 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:14 --> Total execution time: 0.0605
INFO - 2023-08-09 17:55:14 --> Config Class Initialized
INFO - 2023-08-09 17:55:14 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:14 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:14 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:14 --> URI Class Initialized
INFO - 2023-08-09 17:55:14 --> Router Class Initialized
INFO - 2023-08-09 17:55:14 --> Output Class Initialized
INFO - 2023-08-09 17:55:14 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:14 --> Input Class Initialized
INFO - 2023-08-09 17:55:14 --> Language Class Initialized
INFO - 2023-08-09 17:55:14 --> Loader Class Initialized
INFO - 2023-08-09 17:55:14 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:14 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:14 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:14 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:14 --> Controller Class Initialized
INFO - 2023-08-09 17:55:14 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:14 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:14 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 39
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 46
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 55
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 69
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 81
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 98
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 99
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 100
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 116
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 126
ERROR - 2023-08-09 17:55:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\training_edit.php 127
INFO - 2023-08-09 17:55:14 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_edit.php
INFO - 2023-08-09 17:55:14 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:14 --> Total execution time: 0.0557
INFO - 2023-08-09 17:55:24 --> Config Class Initialized
INFO - 2023-08-09 17:55:24 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:24 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:24 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:24 --> URI Class Initialized
INFO - 2023-08-09 17:55:24 --> Router Class Initialized
INFO - 2023-08-09 17:55:24 --> Output Class Initialized
INFO - 2023-08-09 17:55:24 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:24 --> Input Class Initialized
INFO - 2023-08-09 17:55:24 --> Language Class Initialized
INFO - 2023-08-09 17:55:24 --> Loader Class Initialized
INFO - 2023-08-09 17:55:24 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:24 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:24 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:24 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:24 --> Controller Class Initialized
INFO - 2023-08-09 17:55:24 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:24 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:24 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:55:24 --> Config Class Initialized
INFO - 2023-08-09 17:55:24 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:24 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:24 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:24 --> URI Class Initialized
INFO - 2023-08-09 17:55:24 --> Router Class Initialized
INFO - 2023-08-09 17:55:24 --> Output Class Initialized
INFO - 2023-08-09 17:55:24 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:24 --> Input Class Initialized
INFO - 2023-08-09 17:55:24 --> Language Class Initialized
INFO - 2023-08-09 17:55:24 --> Loader Class Initialized
INFO - 2023-08-09 17:55:24 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:24 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:24 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:24 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:24 --> Controller Class Initialized
INFO - 2023-08-09 17:55:24 --> Model "Training_model" initialized
INFO - 2023-08-09 17:55:24 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:24 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:24 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 17:55:24 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:24 --> Total execution time: 0.0390
INFO - 2023-08-09 17:55:24 --> Config Class Initialized
INFO - 2023-08-09 17:55:24 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:24 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:24 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:24 --> URI Class Initialized
INFO - 2023-08-09 17:55:24 --> Router Class Initialized
INFO - 2023-08-09 17:55:24 --> Output Class Initialized
INFO - 2023-08-09 17:55:24 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:24 --> Input Class Initialized
INFO - 2023-08-09 17:55:24 --> Language Class Initialized
ERROR - 2023-08-09 17:55:24 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-09 17:55:32 --> Config Class Initialized
INFO - 2023-08-09 17:55:32 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:32 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:32 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:32 --> URI Class Initialized
INFO - 2023-08-09 17:55:32 --> Router Class Initialized
INFO - 2023-08-09 17:55:32 --> Output Class Initialized
INFO - 2023-08-09 17:55:32 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:32 --> Input Class Initialized
INFO - 2023-08-09 17:55:32 --> Language Class Initialized
INFO - 2023-08-09 17:55:32 --> Loader Class Initialized
INFO - 2023-08-09 17:55:32 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:32 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:32 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:32 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:32 --> Controller Class Initialized
INFO - 2023-08-09 17:55:32 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:32 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:32 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 17:55:32 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:32 --> Total execution time: 0.0419
INFO - 2023-08-09 17:55:37 --> Config Class Initialized
INFO - 2023-08-09 17:55:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:37 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:37 --> URI Class Initialized
INFO - 2023-08-09 17:55:37 --> Router Class Initialized
INFO - 2023-08-09 17:55:37 --> Output Class Initialized
INFO - 2023-08-09 17:55:37 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:37 --> Input Class Initialized
INFO - 2023-08-09 17:55:37 --> Language Class Initialized
INFO - 2023-08-09 17:55:37 --> Loader Class Initialized
INFO - 2023-08-09 17:55:37 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:37 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:37 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:37 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:37 --> Controller Class Initialized
INFO - 2023-08-09 17:55:37 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:37 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:37 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-09 17:55:37 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:37 --> Total execution time: 0.0451
INFO - 2023-08-09 17:55:37 --> Config Class Initialized
INFO - 2023-08-09 17:55:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:37 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:37 --> URI Class Initialized
INFO - 2023-08-09 17:55:37 --> Router Class Initialized
INFO - 2023-08-09 17:55:37 --> Output Class Initialized
INFO - 2023-08-09 17:55:37 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:37 --> Input Class Initialized
INFO - 2023-08-09 17:55:37 --> Language Class Initialized
ERROR - 2023-08-09 17:55:37 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-09 17:55:49 --> Config Class Initialized
INFO - 2023-08-09 17:55:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:49 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:49 --> URI Class Initialized
INFO - 2023-08-09 17:55:49 --> Router Class Initialized
INFO - 2023-08-09 17:55:49 --> Output Class Initialized
INFO - 2023-08-09 17:55:49 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:49 --> Input Class Initialized
INFO - 2023-08-09 17:55:49 --> Language Class Initialized
INFO - 2023-08-09 17:55:50 --> Loader Class Initialized
INFO - 2023-08-09 17:55:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:50 --> Controller Class Initialized
INFO - 2023-08-09 17:55:50 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:55:50 --> Config Class Initialized
INFO - 2023-08-09 17:55:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:50 --> URI Class Initialized
INFO - 2023-08-09 17:55:50 --> Router Class Initialized
INFO - 2023-08-09 17:55:50 --> Output Class Initialized
INFO - 2023-08-09 17:55:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:50 --> Input Class Initialized
INFO - 2023-08-09 17:55:50 --> Language Class Initialized
INFO - 2023-08-09 17:55:50 --> Loader Class Initialized
INFO - 2023-08-09 17:55:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:50 --> Controller Class Initialized
INFO - 2023-08-09 17:55:50 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 17:55:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:50 --> Total execution time: 0.0614
INFO - 2023-08-09 17:55:58 --> Config Class Initialized
INFO - 2023-08-09 17:55:58 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:58 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:58 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:58 --> URI Class Initialized
INFO - 2023-08-09 17:55:58 --> Router Class Initialized
INFO - 2023-08-09 17:55:58 --> Output Class Initialized
INFO - 2023-08-09 17:55:58 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:58 --> Input Class Initialized
INFO - 2023-08-09 17:55:58 --> Language Class Initialized
INFO - 2023-08-09 17:55:58 --> Loader Class Initialized
INFO - 2023-08-09 17:55:58 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:58 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:58 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:58 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:58 --> Controller Class Initialized
INFO - 2023-08-09 17:55:58 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:58 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:58 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-09 17:55:58 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:58 --> Total execution time: 0.1008
INFO - 2023-08-09 17:55:58 --> Config Class Initialized
INFO - 2023-08-09 17:55:58 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:55:58 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:55:58 --> Utf8 Class Initialized
INFO - 2023-08-09 17:55:58 --> URI Class Initialized
INFO - 2023-08-09 17:55:58 --> Router Class Initialized
INFO - 2023-08-09 17:55:58 --> Output Class Initialized
INFO - 2023-08-09 17:55:58 --> Security Class Initialized
DEBUG - 2023-08-09 17:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:55:58 --> Input Class Initialized
INFO - 2023-08-09 17:55:58 --> Language Class Initialized
INFO - 2023-08-09 17:55:58 --> Loader Class Initialized
INFO - 2023-08-09 17:55:58 --> Helper loaded: url_helper
INFO - 2023-08-09 17:55:58 --> Helper loaded: file_helper
INFO - 2023-08-09 17:55:58 --> Database Driver Class Initialized
INFO - 2023-08-09 17:55:58 --> Email Class Initialized
DEBUG - 2023-08-09 17:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:55:58 --> Controller Class Initialized
INFO - 2023-08-09 17:55:58 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:55:58 --> Helper loaded: form_helper
INFO - 2023-08-09 17:55:58 --> Form Validation Class Initialized
INFO - 2023-08-09 17:55:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-09 17:55:58 --> Final output sent to browser
DEBUG - 2023-08-09 17:55:58 --> Total execution time: 0.0414
INFO - 2023-08-09 17:56:07 --> Config Class Initialized
INFO - 2023-08-09 17:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:07 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:07 --> URI Class Initialized
INFO - 2023-08-09 17:56:07 --> Router Class Initialized
INFO - 2023-08-09 17:56:07 --> Output Class Initialized
INFO - 2023-08-09 17:56:07 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:07 --> Input Class Initialized
INFO - 2023-08-09 17:56:07 --> Language Class Initialized
INFO - 2023-08-09 17:56:07 --> Loader Class Initialized
INFO - 2023-08-09 17:56:07 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:07 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:07 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:07 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:07 --> Controller Class Initialized
INFO - 2023-08-09 17:56:07 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:56:07 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:07 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:56:07 --> Config Class Initialized
INFO - 2023-08-09 17:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:07 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:07 --> URI Class Initialized
INFO - 2023-08-09 17:56:07 --> Router Class Initialized
INFO - 2023-08-09 17:56:07 --> Output Class Initialized
INFO - 2023-08-09 17:56:07 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:07 --> Input Class Initialized
INFO - 2023-08-09 17:56:07 --> Language Class Initialized
INFO - 2023-08-09 17:56:07 --> Loader Class Initialized
INFO - 2023-08-09 17:56:07 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:07 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:07 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:07 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:07 --> Controller Class Initialized
INFO - 2023-08-09 17:56:07 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:56:07 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:07 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 17:56:07 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:07 --> Total execution time: 0.0578
INFO - 2023-08-09 17:56:10 --> Config Class Initialized
INFO - 2023-08-09 17:56:10 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:10 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:10 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:10 --> URI Class Initialized
INFO - 2023-08-09 17:56:10 --> Router Class Initialized
INFO - 2023-08-09 17:56:10 --> Output Class Initialized
INFO - 2023-08-09 17:56:10 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:10 --> Input Class Initialized
INFO - 2023-08-09 17:56:10 --> Language Class Initialized
INFO - 2023-08-09 17:56:10 --> Loader Class Initialized
INFO - 2023-08-09 17:56:10 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:10 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:10 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:10 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:10 --> Controller Class Initialized
INFO - 2023-08-09 17:56:10 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:10 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:10 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:10 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 17:56:10 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:10 --> Total execution time: 0.0427
INFO - 2023-08-09 17:56:12 --> Config Class Initialized
INFO - 2023-08-09 17:56:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:12 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:12 --> URI Class Initialized
INFO - 2023-08-09 17:56:12 --> Router Class Initialized
INFO - 2023-08-09 17:56:12 --> Output Class Initialized
INFO - 2023-08-09 17:56:12 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:12 --> Input Class Initialized
INFO - 2023-08-09 17:56:12 --> Language Class Initialized
INFO - 2023-08-09 17:56:12 --> Loader Class Initialized
INFO - 2023-08-09 17:56:12 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:12 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:12 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:12 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:12 --> Controller Class Initialized
INFO - 2023-08-09 17:56:12 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:12 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:12 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-09 17:56:12 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:12 --> Total execution time: 0.0464
INFO - 2023-08-09 17:56:12 --> Config Class Initialized
INFO - 2023-08-09 17:56:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:12 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:12 --> URI Class Initialized
INFO - 2023-08-09 17:56:12 --> Router Class Initialized
INFO - 2023-08-09 17:56:12 --> Output Class Initialized
INFO - 2023-08-09 17:56:12 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:12 --> Input Class Initialized
INFO - 2023-08-09 17:56:12 --> Language Class Initialized
ERROR - 2023-08-09 17:56:12 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-09 17:56:23 --> Config Class Initialized
INFO - 2023-08-09 17:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:23 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:23 --> URI Class Initialized
INFO - 2023-08-09 17:56:23 --> Router Class Initialized
INFO - 2023-08-09 17:56:23 --> Output Class Initialized
INFO - 2023-08-09 17:56:23 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:23 --> Input Class Initialized
INFO - 2023-08-09 17:56:23 --> Language Class Initialized
INFO - 2023-08-09 17:56:23 --> Loader Class Initialized
INFO - 2023-08-09 17:56:23 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:23 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:23 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:23 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:23 --> Controller Class Initialized
INFO - 2023-08-09 17:56:23 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:23 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:23 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:56:23 --> Config Class Initialized
INFO - 2023-08-09 17:56:23 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:23 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:23 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:23 --> URI Class Initialized
INFO - 2023-08-09 17:56:23 --> Router Class Initialized
INFO - 2023-08-09 17:56:23 --> Output Class Initialized
INFO - 2023-08-09 17:56:23 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:23 --> Input Class Initialized
INFO - 2023-08-09 17:56:23 --> Language Class Initialized
INFO - 2023-08-09 17:56:23 --> Loader Class Initialized
INFO - 2023-08-09 17:56:23 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:23 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:23 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:23 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:23 --> Controller Class Initialized
INFO - 2023-08-09 17:56:23 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:23 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:23 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:23 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 17:56:23 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:23 --> Total execution time: 0.0657
INFO - 2023-08-09 17:56:28 --> Config Class Initialized
INFO - 2023-08-09 17:56:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:28 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:28 --> URI Class Initialized
INFO - 2023-08-09 17:56:28 --> Router Class Initialized
INFO - 2023-08-09 17:56:28 --> Output Class Initialized
INFO - 2023-08-09 17:56:28 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:28 --> Input Class Initialized
INFO - 2023-08-09 17:56:28 --> Language Class Initialized
INFO - 2023-08-09 17:56:28 --> Loader Class Initialized
INFO - 2023-08-09 17:56:28 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:28 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:28 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:28 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:28 --> Controller Class Initialized
INFO - 2023-08-09 17:56:28 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:28 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:28 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-09 17:56:28 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:28 --> Total execution time: 0.0405
INFO - 2023-08-09 17:56:28 --> Config Class Initialized
INFO - 2023-08-09 17:56:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:28 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:28 --> URI Class Initialized
INFO - 2023-08-09 17:56:28 --> Router Class Initialized
INFO - 2023-08-09 17:56:28 --> Output Class Initialized
INFO - 2023-08-09 17:56:28 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:28 --> Input Class Initialized
INFO - 2023-08-09 17:56:28 --> Language Class Initialized
ERROR - 2023-08-09 17:56:28 --> 404 Page Not Found: admin/Key_highlights/edit
INFO - 2023-08-09 17:56:39 --> Config Class Initialized
INFO - 2023-08-09 17:56:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:39 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:39 --> URI Class Initialized
INFO - 2023-08-09 17:56:39 --> Router Class Initialized
INFO - 2023-08-09 17:56:39 --> Output Class Initialized
INFO - 2023-08-09 17:56:39 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:39 --> Input Class Initialized
INFO - 2023-08-09 17:56:39 --> Language Class Initialized
INFO - 2023-08-09 17:56:39 --> Loader Class Initialized
INFO - 2023-08-09 17:56:39 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:39 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:39 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:39 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:39 --> Controller Class Initialized
INFO - 2023-08-09 17:56:39 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:39 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:39 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:56:39 --> Config Class Initialized
INFO - 2023-08-09 17:56:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:39 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:39 --> URI Class Initialized
INFO - 2023-08-09 17:56:39 --> Router Class Initialized
INFO - 2023-08-09 17:56:39 --> Output Class Initialized
INFO - 2023-08-09 17:56:39 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:39 --> Input Class Initialized
INFO - 2023-08-09 17:56:39 --> Language Class Initialized
INFO - 2023-08-09 17:56:39 --> Loader Class Initialized
INFO - 2023-08-09 17:56:39 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:39 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:39 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:39 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:39 --> Controller Class Initialized
INFO - 2023-08-09 17:56:39 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:56:39 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:39 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 17:56:39 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:39 --> Total execution time: 0.0605
INFO - 2023-08-09 17:56:44 --> Config Class Initialized
INFO - 2023-08-09 17:56:44 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:44 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:44 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:44 --> URI Class Initialized
INFO - 2023-08-09 17:56:44 --> Router Class Initialized
INFO - 2023-08-09 17:56:44 --> Output Class Initialized
INFO - 2023-08-09 17:56:44 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:44 --> Input Class Initialized
INFO - 2023-08-09 17:56:44 --> Language Class Initialized
INFO - 2023-08-09 17:56:44 --> Loader Class Initialized
INFO - 2023-08-09 17:56:44 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:44 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:44 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:44 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:44 --> Controller Class Initialized
INFO - 2023-08-09 17:56:44 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:56:44 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:44 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:44 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:56:44 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:44 --> Total execution time: 0.0537
INFO - 2023-08-09 17:56:46 --> Config Class Initialized
INFO - 2023-08-09 17:56:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:46 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:46 --> URI Class Initialized
INFO - 2023-08-09 17:56:46 --> Router Class Initialized
INFO - 2023-08-09 17:56:46 --> Output Class Initialized
INFO - 2023-08-09 17:56:46 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:46 --> Input Class Initialized
INFO - 2023-08-09 17:56:46 --> Language Class Initialized
INFO - 2023-08-09 17:56:46 --> Loader Class Initialized
INFO - 2023-08-09 17:56:46 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:46 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:46 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:46 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:46 --> Controller Class Initialized
INFO - 2023-08-09 17:56:46 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:56:46 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:46 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_create.php
INFO - 2023-08-09 17:56:46 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:46 --> Total execution time: 0.0389
INFO - 2023-08-09 17:56:46 --> Config Class Initialized
INFO - 2023-08-09 17:56:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:46 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:46 --> URI Class Initialized
INFO - 2023-08-09 17:56:46 --> Router Class Initialized
INFO - 2023-08-09 17:56:46 --> Output Class Initialized
INFO - 2023-08-09 17:56:46 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:46 --> Input Class Initialized
INFO - 2023-08-09 17:56:46 --> Language Class Initialized
ERROR - 2023-08-09 17:56:46 --> 404 Page Not Found: admin/Testimonials/images
INFO - 2023-08-09 17:56:50 --> Config Class Initialized
INFO - 2023-08-09 17:56:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:50 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:50 --> URI Class Initialized
INFO - 2023-08-09 17:56:50 --> Router Class Initialized
INFO - 2023-08-09 17:56:50 --> Output Class Initialized
INFO - 2023-08-09 17:56:50 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:50 --> Input Class Initialized
INFO - 2023-08-09 17:56:50 --> Language Class Initialized
INFO - 2023-08-09 17:56:50 --> Loader Class Initialized
INFO - 2023-08-09 17:56:50 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:50 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:50 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:50 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:50 --> Controller Class Initialized
INFO - 2023-08-09 17:56:50 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:56:50 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:50 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:56:50 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:50 --> Total execution time: 0.0477
INFO - 2023-08-09 17:56:53 --> Config Class Initialized
INFO - 2023-08-09 17:56:53 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:53 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:53 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:53 --> URI Class Initialized
INFO - 2023-08-09 17:56:53 --> Router Class Initialized
INFO - 2023-08-09 17:56:53 --> Output Class Initialized
INFO - 2023-08-09 17:56:53 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:53 --> Input Class Initialized
INFO - 2023-08-09 17:56:53 --> Language Class Initialized
INFO - 2023-08-09 17:56:53 --> Loader Class Initialized
INFO - 2023-08-09 17:56:53 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:53 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:53 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:53 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:53 --> Controller Class Initialized
INFO - 2023-08-09 17:56:53 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:56:53 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:53 --> Form Validation Class Initialized
INFO - 2023-08-09 17:56:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_edit.php
INFO - 2023-08-09 17:56:53 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:53 --> Total execution time: 0.0455
INFO - 2023-08-09 17:56:53 --> Config Class Initialized
INFO - 2023-08-09 17:56:53 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:56:53 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:56:53 --> Utf8 Class Initialized
INFO - 2023-08-09 17:56:53 --> URI Class Initialized
INFO - 2023-08-09 17:56:53 --> Router Class Initialized
INFO - 2023-08-09 17:56:53 --> Output Class Initialized
INFO - 2023-08-09 17:56:53 --> Security Class Initialized
DEBUG - 2023-08-09 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:56:53 --> Input Class Initialized
INFO - 2023-08-09 17:56:53 --> Language Class Initialized
INFO - 2023-08-09 17:56:53 --> Loader Class Initialized
INFO - 2023-08-09 17:56:53 --> Helper loaded: url_helper
INFO - 2023-08-09 17:56:53 --> Helper loaded: file_helper
INFO - 2023-08-09 17:56:53 --> Database Driver Class Initialized
INFO - 2023-08-09 17:56:53 --> Email Class Initialized
DEBUG - 2023-08-09 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:56:53 --> Controller Class Initialized
INFO - 2023-08-09 17:56:53 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:56:53 --> Helper loaded: form_helper
INFO - 2023-08-09 17:56:53 --> Form Validation Class Initialized
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 39
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "type" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 48
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "type" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 49
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "name" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 59
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 73
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 74
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "status" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 86
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "status" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 87
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "status" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 88
ERROR - 2023-08-09 17:56:53 --> Severity: Warning --> Attempt to read property "description" on null C:\xampp\htdocs\DW\application\views\admin\testimonials_edit.php 101
INFO - 2023-08-09 17:56:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_edit.php
INFO - 2023-08-09 17:56:53 --> Final output sent to browser
DEBUG - 2023-08-09 17:56:53 --> Total execution time: 0.0503
INFO - 2023-08-09 17:57:05 --> Config Class Initialized
INFO - 2023-08-09 17:57:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:57:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:57:05 --> Utf8 Class Initialized
INFO - 2023-08-09 17:57:05 --> URI Class Initialized
INFO - 2023-08-09 17:57:05 --> Router Class Initialized
INFO - 2023-08-09 17:57:05 --> Output Class Initialized
INFO - 2023-08-09 17:57:05 --> Security Class Initialized
DEBUG - 2023-08-09 17:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:57:05 --> Input Class Initialized
INFO - 2023-08-09 17:57:05 --> Language Class Initialized
INFO - 2023-08-09 17:57:05 --> Loader Class Initialized
INFO - 2023-08-09 17:57:05 --> Helper loaded: url_helper
INFO - 2023-08-09 17:57:05 --> Helper loaded: file_helper
INFO - 2023-08-09 17:57:05 --> Database Driver Class Initialized
INFO - 2023-08-09 17:57:05 --> Email Class Initialized
DEBUG - 2023-08-09 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:57:05 --> Controller Class Initialized
INFO - 2023-08-09 17:57:05 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:57:05 --> Helper loaded: form_helper
INFO - 2023-08-09 17:57:05 --> Form Validation Class Initialized
INFO - 2023-08-09 17:57:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 17:57:05 --> Config Class Initialized
INFO - 2023-08-09 17:57:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:57:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:57:05 --> Utf8 Class Initialized
INFO - 2023-08-09 17:57:05 --> URI Class Initialized
INFO - 2023-08-09 17:57:05 --> Router Class Initialized
INFO - 2023-08-09 17:57:05 --> Output Class Initialized
INFO - 2023-08-09 17:57:05 --> Security Class Initialized
DEBUG - 2023-08-09 17:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:57:05 --> Input Class Initialized
INFO - 2023-08-09 17:57:05 --> Language Class Initialized
INFO - 2023-08-09 17:57:05 --> Loader Class Initialized
INFO - 2023-08-09 17:57:05 --> Helper loaded: url_helper
INFO - 2023-08-09 17:57:05 --> Helper loaded: file_helper
INFO - 2023-08-09 17:57:05 --> Database Driver Class Initialized
INFO - 2023-08-09 17:57:05 --> Email Class Initialized
DEBUG - 2023-08-09 17:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:57:05 --> Controller Class Initialized
INFO - 2023-08-09 17:57:05 --> Model "Testimonials_model" initialized
INFO - 2023-08-09 17:57:05 --> Helper loaded: form_helper
INFO - 2023-08-09 17:57:05 --> Form Validation Class Initialized
INFO - 2023-08-09 17:57:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/testimonials_list.php
INFO - 2023-08-09 17:57:05 --> Final output sent to browser
DEBUG - 2023-08-09 17:57:05 --> Total execution time: 0.1240
INFO - 2023-08-09 17:57:51 --> Config Class Initialized
INFO - 2023-08-09 17:57:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:57:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:57:51 --> Utf8 Class Initialized
INFO - 2023-08-09 17:57:51 --> URI Class Initialized
INFO - 2023-08-09 17:57:51 --> Router Class Initialized
INFO - 2023-08-09 17:57:51 --> Output Class Initialized
INFO - 2023-08-09 17:57:51 --> Security Class Initialized
DEBUG - 2023-08-09 17:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:57:51 --> Input Class Initialized
INFO - 2023-08-09 17:57:51 --> Language Class Initialized
INFO - 2023-08-09 17:57:51 --> Loader Class Initialized
INFO - 2023-08-09 17:57:51 --> Helper loaded: url_helper
INFO - 2023-08-09 17:57:51 --> Helper loaded: file_helper
INFO - 2023-08-09 17:57:51 --> Database Driver Class Initialized
INFO - 2023-08-09 17:57:51 --> Email Class Initialized
DEBUG - 2023-08-09 17:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:57:51 --> Controller Class Initialized
INFO - 2023-08-09 17:57:51 --> Model "Key_highlights_model" initialized
INFO - 2023-08-09 17:57:51 --> Helper loaded: form_helper
INFO - 2023-08-09 17:57:51 --> Form Validation Class Initialized
INFO - 2023-08-09 17:57:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-09 17:57:51 --> Final output sent to browser
DEBUG - 2023-08-09 17:57:51 --> Total execution time: 0.0832
INFO - 2023-08-09 17:58:04 --> Config Class Initialized
INFO - 2023-08-09 17:58:04 --> Hooks Class Initialized
DEBUG - 2023-08-09 17:58:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 17:58:04 --> Utf8 Class Initialized
INFO - 2023-08-09 17:58:04 --> URI Class Initialized
INFO - 2023-08-09 17:58:04 --> Router Class Initialized
INFO - 2023-08-09 17:58:04 --> Output Class Initialized
INFO - 2023-08-09 17:58:04 --> Security Class Initialized
DEBUG - 2023-08-09 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 17:58:04 --> Input Class Initialized
INFO - 2023-08-09 17:58:04 --> Language Class Initialized
INFO - 2023-08-09 17:58:04 --> Loader Class Initialized
INFO - 2023-08-09 17:58:04 --> Helper loaded: url_helper
INFO - 2023-08-09 17:58:04 --> Helper loaded: file_helper
INFO - 2023-08-09 17:58:04 --> Database Driver Class Initialized
INFO - 2023-08-09 17:58:04 --> Email Class Initialized
DEBUG - 2023-08-09 17:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 17:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 17:58:04 --> Controller Class Initialized
INFO - 2023-08-09 17:58:04 --> Model "Faq_model" initialized
INFO - 2023-08-09 17:58:04 --> Helper loaded: form_helper
INFO - 2023-08-09 17:58:04 --> Form Validation Class Initialized
INFO - 2023-08-09 17:58:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 17:58:04 --> Final output sent to browser
DEBUG - 2023-08-09 17:58:04 --> Total execution time: 0.0661
INFO - 2023-08-09 18:03:09 --> Config Class Initialized
INFO - 2023-08-09 18:03:09 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:03:09 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:03:09 --> Utf8 Class Initialized
INFO - 2023-08-09 18:03:09 --> URI Class Initialized
INFO - 2023-08-09 18:03:09 --> Router Class Initialized
INFO - 2023-08-09 18:03:09 --> Output Class Initialized
INFO - 2023-08-09 18:03:09 --> Security Class Initialized
DEBUG - 2023-08-09 18:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:03:09 --> Input Class Initialized
INFO - 2023-08-09 18:03:09 --> Language Class Initialized
INFO - 2023-08-09 18:03:09 --> Loader Class Initialized
INFO - 2023-08-09 18:03:09 --> Helper loaded: url_helper
INFO - 2023-08-09 18:03:09 --> Helper loaded: file_helper
INFO - 2023-08-09 18:03:09 --> Database Driver Class Initialized
INFO - 2023-08-09 18:03:09 --> Email Class Initialized
DEBUG - 2023-08-09 18:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:03:09 --> Controller Class Initialized
INFO - 2023-08-09 18:03:09 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:03:09 --> Helper loaded: form_helper
INFO - 2023-08-09 18:03:09 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:03:09 --> Severity: error --> Exception: Too few arguments to function FAQ::index(), 0 passed in C:\xampp\htdocs\DW\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\DW\application\controllers\Admin\FAQ.php 11
INFO - 2023-08-09 18:03:13 --> Config Class Initialized
INFO - 2023-08-09 18:03:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:03:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:03:13 --> Utf8 Class Initialized
INFO - 2023-08-09 18:03:13 --> URI Class Initialized
INFO - 2023-08-09 18:03:13 --> Router Class Initialized
INFO - 2023-08-09 18:03:13 --> Output Class Initialized
INFO - 2023-08-09 18:03:13 --> Security Class Initialized
DEBUG - 2023-08-09 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:03:13 --> Input Class Initialized
INFO - 2023-08-09 18:03:13 --> Language Class Initialized
INFO - 2023-08-09 18:03:13 --> Loader Class Initialized
INFO - 2023-08-09 18:03:13 --> Helper loaded: url_helper
INFO - 2023-08-09 18:03:13 --> Helper loaded: file_helper
INFO - 2023-08-09 18:03:13 --> Database Driver Class Initialized
INFO - 2023-08-09 18:03:13 --> Email Class Initialized
DEBUG - 2023-08-09 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:03:13 --> Controller Class Initialized
INFO - 2023-08-09 18:03:13 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:03:13 --> Helper loaded: form_helper
INFO - 2023-08-09 18:03:13 --> Form Validation Class Initialized
INFO - 2023-08-09 18:03:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 18:03:13 --> Final output sent to browser
DEBUG - 2023-08-09 18:03:13 --> Total execution time: 0.0787
INFO - 2023-08-09 18:03:26 --> Config Class Initialized
INFO - 2023-08-09 18:03:26 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:03:26 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:03:26 --> Utf8 Class Initialized
INFO - 2023-08-09 18:03:26 --> URI Class Initialized
INFO - 2023-08-09 18:03:26 --> Router Class Initialized
INFO - 2023-08-09 18:03:26 --> Output Class Initialized
INFO - 2023-08-09 18:03:26 --> Security Class Initialized
DEBUG - 2023-08-09 18:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:03:26 --> Input Class Initialized
INFO - 2023-08-09 18:03:26 --> Language Class Initialized
INFO - 2023-08-09 18:03:26 --> Loader Class Initialized
INFO - 2023-08-09 18:03:26 --> Helper loaded: url_helper
INFO - 2023-08-09 18:03:26 --> Helper loaded: file_helper
INFO - 2023-08-09 18:03:26 --> Database Driver Class Initialized
INFO - 2023-08-09 18:03:26 --> Email Class Initialized
DEBUG - 2023-08-09 18:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:03:26 --> Controller Class Initialized
INFO - 2023-08-09 18:03:26 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:03:26 --> Helper loaded: form_helper
INFO - 2023-08-09 18:03:26 --> Form Validation Class Initialized
INFO - 2023-08-09 18:03:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 18:03:26 --> Final output sent to browser
DEBUG - 2023-08-09 18:03:26 --> Total execution time: 0.2560
INFO - 2023-08-09 18:03:34 --> Config Class Initialized
INFO - 2023-08-09 18:03:34 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:03:34 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:03:34 --> Utf8 Class Initialized
INFO - 2023-08-09 18:03:34 --> URI Class Initialized
INFO - 2023-08-09 18:03:34 --> Router Class Initialized
INFO - 2023-08-09 18:03:34 --> Output Class Initialized
INFO - 2023-08-09 18:03:34 --> Security Class Initialized
DEBUG - 2023-08-09 18:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:03:34 --> Input Class Initialized
INFO - 2023-08-09 18:03:34 --> Language Class Initialized
INFO - 2023-08-09 18:03:34 --> Loader Class Initialized
INFO - 2023-08-09 18:03:34 --> Helper loaded: url_helper
INFO - 2023-08-09 18:03:34 --> Helper loaded: file_helper
INFO - 2023-08-09 18:03:34 --> Database Driver Class Initialized
INFO - 2023-08-09 18:03:34 --> Email Class Initialized
DEBUG - 2023-08-09 18:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:03:34 --> Controller Class Initialized
INFO - 2023-08-09 18:03:34 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:03:34 --> Helper loaded: form_helper
INFO - 2023-08-09 18:03:34 --> Form Validation Class Initialized
INFO - 2023-08-09 18:03:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 18:03:34 --> Final output sent to browser
DEBUG - 2023-08-09 18:03:34 --> Total execution time: 0.0567
INFO - 2023-08-09 18:03:37 --> Config Class Initialized
INFO - 2023-08-09 18:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:03:37 --> Utf8 Class Initialized
INFO - 2023-08-09 18:03:37 --> URI Class Initialized
INFO - 2023-08-09 18:03:37 --> Router Class Initialized
INFO - 2023-08-09 18:03:37 --> Output Class Initialized
INFO - 2023-08-09 18:03:37 --> Security Class Initialized
DEBUG - 2023-08-09 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:03:37 --> Input Class Initialized
INFO - 2023-08-09 18:03:37 --> Language Class Initialized
INFO - 2023-08-09 18:03:37 --> Loader Class Initialized
INFO - 2023-08-09 18:03:37 --> Helper loaded: url_helper
INFO - 2023-08-09 18:03:37 --> Helper loaded: file_helper
INFO - 2023-08-09 18:03:37 --> Database Driver Class Initialized
INFO - 2023-08-09 18:03:37 --> Email Class Initialized
DEBUG - 2023-08-09 18:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:03:37 --> Controller Class Initialized
INFO - 2023-08-09 18:03:37 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:03:37 --> Helper loaded: form_helper
INFO - 2023-08-09 18:03:37 --> Form Validation Class Initialized
INFO - 2023-08-09 18:03:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 18:03:37 --> Final output sent to browser
DEBUG - 2023-08-09 18:03:37 --> Total execution time: 0.0559
INFO - 2023-08-09 18:06:56 --> Config Class Initialized
INFO - 2023-08-09 18:06:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:06:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:06:56 --> Utf8 Class Initialized
INFO - 2023-08-09 18:06:56 --> URI Class Initialized
INFO - 2023-08-09 18:06:56 --> Router Class Initialized
INFO - 2023-08-09 18:06:56 --> Output Class Initialized
INFO - 2023-08-09 18:06:56 --> Security Class Initialized
DEBUG - 2023-08-09 18:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:06:56 --> Input Class Initialized
INFO - 2023-08-09 18:06:56 --> Language Class Initialized
INFO - 2023-08-09 18:06:56 --> Loader Class Initialized
INFO - 2023-08-09 18:06:56 --> Helper loaded: url_helper
INFO - 2023-08-09 18:06:56 --> Helper loaded: file_helper
INFO - 2023-08-09 18:06:56 --> Database Driver Class Initialized
INFO - 2023-08-09 18:06:56 --> Email Class Initialized
DEBUG - 2023-08-09 18:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:06:56 --> Controller Class Initialized
INFO - 2023-08-09 18:06:56 --> Model "Services_model" initialized
INFO - 2023-08-09 18:06:56 --> Helper loaded: form_helper
INFO - 2023-08-09 18:06:56 --> Form Validation Class Initialized
INFO - 2023-08-09 18:06:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:06:56 --> Final output sent to browser
DEBUG - 2023-08-09 18:06:56 --> Total execution time: 0.0949
INFO - 2023-08-09 18:06:57 --> Config Class Initialized
INFO - 2023-08-09 18:06:57 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:06:57 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:06:57 --> Utf8 Class Initialized
INFO - 2023-08-09 18:06:57 --> URI Class Initialized
INFO - 2023-08-09 18:06:57 --> Router Class Initialized
INFO - 2023-08-09 18:06:57 --> Output Class Initialized
INFO - 2023-08-09 18:06:57 --> Security Class Initialized
DEBUG - 2023-08-09 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:06:57 --> Input Class Initialized
INFO - 2023-08-09 18:06:57 --> Language Class Initialized
ERROR - 2023-08-09 18:06:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 18:06:58 --> Config Class Initialized
INFO - 2023-08-09 18:06:58 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:06:58 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:06:58 --> Utf8 Class Initialized
INFO - 2023-08-09 18:06:58 --> URI Class Initialized
INFO - 2023-08-09 18:06:58 --> Router Class Initialized
INFO - 2023-08-09 18:06:58 --> Output Class Initialized
INFO - 2023-08-09 18:06:58 --> Security Class Initialized
DEBUG - 2023-08-09 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:06:58 --> Input Class Initialized
INFO - 2023-08-09 18:06:58 --> Language Class Initialized
INFO - 2023-08-09 18:06:58 --> Loader Class Initialized
INFO - 2023-08-09 18:06:58 --> Helper loaded: url_helper
INFO - 2023-08-09 18:06:58 --> Helper loaded: file_helper
INFO - 2023-08-09 18:06:58 --> Database Driver Class Initialized
INFO - 2023-08-09 18:06:58 --> Email Class Initialized
DEBUG - 2023-08-09 18:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:06:58 --> Controller Class Initialized
INFO - 2023-08-09 18:06:58 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:06:58 --> Helper loaded: form_helper
INFO - 2023-08-09 18:06:58 --> Form Validation Class Initialized
INFO - 2023-08-09 18:06:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:06:58 --> Final output sent to browser
DEBUG - 2023-08-09 18:06:58 --> Total execution time: 0.0463
INFO - 2023-08-09 18:07:00 --> Config Class Initialized
INFO - 2023-08-09 18:07:00 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:00 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:00 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:00 --> URI Class Initialized
INFO - 2023-08-09 18:07:00 --> Router Class Initialized
INFO - 2023-08-09 18:07:00 --> Output Class Initialized
INFO - 2023-08-09 18:07:00 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:00 --> Input Class Initialized
INFO - 2023-08-09 18:07:00 --> Language Class Initialized
INFO - 2023-08-09 18:07:00 --> Loader Class Initialized
INFO - 2023-08-09 18:07:00 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:00 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:00 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:00 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:00 --> Controller Class Initialized
INFO - 2023-08-09 18:07:00 --> Model "Services_model" initialized
INFO - 2023-08-09 18:07:00 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:00 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:07:00 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:00 --> Total execution time: 0.0492
INFO - 2023-08-09 18:07:02 --> Config Class Initialized
INFO - 2023-08-09 18:07:02 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:02 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:02 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:02 --> URI Class Initialized
INFO - 2023-08-09 18:07:02 --> Router Class Initialized
INFO - 2023-08-09 18:07:02 --> Output Class Initialized
INFO - 2023-08-09 18:07:02 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:02 --> Input Class Initialized
INFO - 2023-08-09 18:07:02 --> Language Class Initialized
INFO - 2023-08-09 18:07:02 --> Loader Class Initialized
INFO - 2023-08-09 18:07:02 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:02 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:02 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:02 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:02 --> Controller Class Initialized
INFO - 2023-08-09 18:07:02 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:07:02 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:02 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:07:02 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:02 --> Total execution time: 0.0480
INFO - 2023-08-09 18:07:03 --> Config Class Initialized
INFO - 2023-08-09 18:07:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:03 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:03 --> URI Class Initialized
INFO - 2023-08-09 18:07:03 --> Router Class Initialized
INFO - 2023-08-09 18:07:03 --> Output Class Initialized
INFO - 2023-08-09 18:07:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:03 --> Input Class Initialized
INFO - 2023-08-09 18:07:03 --> Language Class Initialized
INFO - 2023-08-09 18:07:03 --> Loader Class Initialized
INFO - 2023-08-09 18:07:03 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:03 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:03 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:03 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:03 --> Controller Class Initialized
INFO - 2023-08-09 18:07:03 --> Model "Gallery_model" initialized
INFO - 2023-08-09 18:07:03 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:03 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-09 18:07:03 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:03 --> Total execution time: 0.0512
INFO - 2023-08-09 18:07:04 --> Config Class Initialized
INFO - 2023-08-09 18:07:04 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:04 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:04 --> URI Class Initialized
INFO - 2023-08-09 18:07:04 --> Router Class Initialized
INFO - 2023-08-09 18:07:04 --> Output Class Initialized
INFO - 2023-08-09 18:07:04 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:04 --> Input Class Initialized
INFO - 2023-08-09 18:07:04 --> Language Class Initialized
ERROR - 2023-08-09 18:07:04 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-09 18:07:07 --> Config Class Initialized
INFO - 2023-08-09 18:07:07 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:07 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:07 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:07 --> URI Class Initialized
INFO - 2023-08-09 18:07:07 --> Router Class Initialized
INFO - 2023-08-09 18:07:07 --> Output Class Initialized
INFO - 2023-08-09 18:07:07 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:07 --> Input Class Initialized
INFO - 2023-08-09 18:07:07 --> Language Class Initialized
INFO - 2023-08-09 18:07:07 --> Loader Class Initialized
INFO - 2023-08-09 18:07:07 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:07 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:07 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:07 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:07 --> Controller Class Initialized
INFO - 2023-08-09 18:07:07 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:07:07 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:07 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:07:07 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:07 --> Total execution time: 0.0417
INFO - 2023-08-09 18:07:52 --> Config Class Initialized
INFO - 2023-08-09 18:07:52 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:52 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:52 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:52 --> URI Class Initialized
INFO - 2023-08-09 18:07:52 --> Router Class Initialized
INFO - 2023-08-09 18:07:52 --> Output Class Initialized
INFO - 2023-08-09 18:07:52 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:52 --> Input Class Initialized
INFO - 2023-08-09 18:07:52 --> Language Class Initialized
INFO - 2023-08-09 18:07:52 --> Loader Class Initialized
INFO - 2023-08-09 18:07:52 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:52 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:52 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:52 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:52 --> Controller Class Initialized
INFO - 2023-08-09 18:07:52 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:07:52 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:52 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:07:52 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:52 --> Total execution time: 0.1139
INFO - 2023-08-09 18:07:53 --> Config Class Initialized
INFO - 2023-08-09 18:07:53 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:53 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:53 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:53 --> URI Class Initialized
INFO - 2023-08-09 18:07:53 --> Router Class Initialized
INFO - 2023-08-09 18:07:53 --> Output Class Initialized
INFO - 2023-08-09 18:07:53 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:53 --> Input Class Initialized
INFO - 2023-08-09 18:07:53 --> Language Class Initialized
INFO - 2023-08-09 18:07:53 --> Loader Class Initialized
INFO - 2023-08-09 18:07:53 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:53 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:53 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:53 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:53 --> Controller Class Initialized
INFO - 2023-08-09 18:07:53 --> Model "Services_model" initialized
INFO - 2023-08-09 18:07:53 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:53 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:07:53 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:53 --> Total execution time: 0.0497
INFO - 2023-08-09 18:07:55 --> Config Class Initialized
INFO - 2023-08-09 18:07:55 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:55 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:55 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:55 --> URI Class Initialized
INFO - 2023-08-09 18:07:55 --> Router Class Initialized
INFO - 2023-08-09 18:07:55 --> Output Class Initialized
INFO - 2023-08-09 18:07:55 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:55 --> Input Class Initialized
INFO - 2023-08-09 18:07:55 --> Language Class Initialized
INFO - 2023-08-09 18:07:55 --> Loader Class Initialized
INFO - 2023-08-09 18:07:55 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:55 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:55 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:55 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:55 --> Controller Class Initialized
INFO - 2023-08-09 18:07:55 --> Model "Services_model" initialized
INFO - 2023-08-09 18:07:55 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:55 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:07:55 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:55 --> Total execution time: 0.0468
INFO - 2023-08-09 18:07:55 --> Config Class Initialized
INFO - 2023-08-09 18:07:55 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:55 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:55 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:55 --> URI Class Initialized
INFO - 2023-08-09 18:07:55 --> Router Class Initialized
INFO - 2023-08-09 18:07:55 --> Output Class Initialized
INFO - 2023-08-09 18:07:55 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:55 --> Input Class Initialized
INFO - 2023-08-09 18:07:55 --> Language Class Initialized
ERROR - 2023-08-09 18:07:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 18:07:59 --> Config Class Initialized
INFO - 2023-08-09 18:07:59 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:07:59 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:07:59 --> Utf8 Class Initialized
INFO - 2023-08-09 18:07:59 --> URI Class Initialized
INFO - 2023-08-09 18:07:59 --> Router Class Initialized
INFO - 2023-08-09 18:07:59 --> Output Class Initialized
INFO - 2023-08-09 18:07:59 --> Security Class Initialized
DEBUG - 2023-08-09 18:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:07:59 --> Input Class Initialized
INFO - 2023-08-09 18:07:59 --> Language Class Initialized
INFO - 2023-08-09 18:07:59 --> Loader Class Initialized
INFO - 2023-08-09 18:07:59 --> Helper loaded: url_helper
INFO - 2023-08-09 18:07:59 --> Helper loaded: file_helper
INFO - 2023-08-09 18:07:59 --> Database Driver Class Initialized
INFO - 2023-08-09 18:07:59 --> Email Class Initialized
DEBUG - 2023-08-09 18:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:07:59 --> Controller Class Initialized
INFO - 2023-08-09 18:07:59 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:07:59 --> Helper loaded: form_helper
INFO - 2023-08-09 18:07:59 --> Form Validation Class Initialized
INFO - 2023-08-09 18:07:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:07:59 --> Final output sent to browser
DEBUG - 2023-08-09 18:07:59 --> Total execution time: 0.0575
INFO - 2023-08-09 18:08:02 --> Config Class Initialized
INFO - 2023-08-09 18:08:02 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:02 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:02 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:02 --> URI Class Initialized
INFO - 2023-08-09 18:08:02 --> Router Class Initialized
INFO - 2023-08-09 18:08:02 --> Output Class Initialized
INFO - 2023-08-09 18:08:02 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:02 --> Input Class Initialized
INFO - 2023-08-09 18:08:02 --> Language Class Initialized
INFO - 2023-08-09 18:08:02 --> Loader Class Initialized
INFO - 2023-08-09 18:08:02 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:02 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:02 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:02 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:02 --> Controller Class Initialized
INFO - 2023-08-09 18:08:02 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:02 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:02 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:08:02 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\services_cards_create.php 45
INFO - 2023-08-09 18:08:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:08:02 --> Final output sent to browser
DEBUG - 2023-08-09 18:08:02 --> Total execution time: 0.0452
INFO - 2023-08-09 18:08:02 --> Config Class Initialized
INFO - 2023-08-09 18:08:02 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:02 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:02 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:02 --> URI Class Initialized
INFO - 2023-08-09 18:08:02 --> Router Class Initialized
INFO - 2023-08-09 18:08:02 --> Output Class Initialized
INFO - 2023-08-09 18:08:02 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:02 --> Input Class Initialized
INFO - 2023-08-09 18:08:02 --> Language Class Initialized
INFO - 2023-08-09 18:08:02 --> Loader Class Initialized
INFO - 2023-08-09 18:08:02 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:02 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:02 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:02 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:02 --> Controller Class Initialized
INFO - 2023-08-09 18:08:02 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:02 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:02 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:08:02 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\views\admin\services_cards_create.php 45
INFO - 2023-08-09 18:08:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:08:02 --> Final output sent to browser
DEBUG - 2023-08-09 18:08:02 --> Total execution time: 0.0426
INFO - 2023-08-09 18:08:32 --> Config Class Initialized
INFO - 2023-08-09 18:08:32 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:32 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:32 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:32 --> URI Class Initialized
INFO - 2023-08-09 18:08:32 --> Router Class Initialized
INFO - 2023-08-09 18:08:32 --> Output Class Initialized
INFO - 2023-08-09 18:08:32 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:32 --> Input Class Initialized
INFO - 2023-08-09 18:08:32 --> Language Class Initialized
INFO - 2023-08-09 18:08:32 --> Loader Class Initialized
INFO - 2023-08-09 18:08:32 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:32 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:32 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:32 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:32 --> Controller Class Initialized
INFO - 2023-08-09 18:08:32 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:32 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:32 --> Form Validation Class Initialized
INFO - 2023-08-09 18:08:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:08:32 --> Final output sent to browser
DEBUG - 2023-08-09 18:08:32 --> Total execution time: 0.1442
INFO - 2023-08-09 18:08:32 --> Config Class Initialized
INFO - 2023-08-09 18:08:32 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:32 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:32 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:32 --> URI Class Initialized
INFO - 2023-08-09 18:08:32 --> Router Class Initialized
INFO - 2023-08-09 18:08:32 --> Output Class Initialized
INFO - 2023-08-09 18:08:32 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:32 --> Input Class Initialized
INFO - 2023-08-09 18:08:32 --> Language Class Initialized
INFO - 2023-08-09 18:08:32 --> Loader Class Initialized
INFO - 2023-08-09 18:08:32 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:32 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:32 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:32 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:32 --> Controller Class Initialized
INFO - 2023-08-09 18:08:32 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:32 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:32 --> Form Validation Class Initialized
INFO - 2023-08-09 18:08:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:08:32 --> Final output sent to browser
DEBUG - 2023-08-09 18:08:32 --> Total execution time: 0.2083
INFO - 2023-08-09 18:08:56 --> Config Class Initialized
INFO - 2023-08-09 18:08:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:56 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:56 --> URI Class Initialized
INFO - 2023-08-09 18:08:56 --> Router Class Initialized
INFO - 2023-08-09 18:08:56 --> Output Class Initialized
INFO - 2023-08-09 18:08:56 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:56 --> Input Class Initialized
INFO - 2023-08-09 18:08:56 --> Language Class Initialized
INFO - 2023-08-09 18:08:56 --> Loader Class Initialized
INFO - 2023-08-09 18:08:56 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:56 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:56 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:56 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:56 --> Controller Class Initialized
INFO - 2023-08-09 18:08:56 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:56 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:56 --> Form Validation Class Initialized
INFO - 2023-08-09 18:08:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-09 18:08:56 --> Severity: Warning --> move_uploaded_file(./assets/images/serice_cards/1691597336Book-my-gold-PNG.png): Failed to open stream: No such file or directory C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 42
ERROR - 2023-08-09 18:08:56 --> Severity: Warning --> move_uploaded_file(): Unable to move &quot;C:\xampp\tmp\php8108.tmp&quot; to &quot;./assets/images/serice_cards/1691597336Book-my-gold-PNG.png&quot; C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 42
INFO - 2023-08-09 18:08:56 --> Config Class Initialized
INFO - 2023-08-09 18:08:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:56 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:56 --> URI Class Initialized
INFO - 2023-08-09 18:08:56 --> Router Class Initialized
INFO - 2023-08-09 18:08:56 --> Output Class Initialized
INFO - 2023-08-09 18:08:56 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:56 --> Input Class Initialized
INFO - 2023-08-09 18:08:56 --> Language Class Initialized
INFO - 2023-08-09 18:08:56 --> Loader Class Initialized
INFO - 2023-08-09 18:08:56 --> Helper loaded: url_helper
INFO - 2023-08-09 18:08:56 --> Helper loaded: file_helper
INFO - 2023-08-09 18:08:56 --> Database Driver Class Initialized
INFO - 2023-08-09 18:08:56 --> Email Class Initialized
DEBUG - 2023-08-09 18:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:08:56 --> Controller Class Initialized
INFO - 2023-08-09 18:08:56 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:08:56 --> Helper loaded: form_helper
INFO - 2023-08-09 18:08:56 --> Form Validation Class Initialized
INFO - 2023-08-09 18:08:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:08:56 --> Final output sent to browser
DEBUG - 2023-08-09 18:08:56 --> Total execution time: 0.0507
INFO - 2023-08-09 18:08:56 --> Config Class Initialized
INFO - 2023-08-09 18:08:56 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:08:56 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:08:56 --> Utf8 Class Initialized
INFO - 2023-08-09 18:08:56 --> URI Class Initialized
INFO - 2023-08-09 18:08:56 --> Router Class Initialized
INFO - 2023-08-09 18:08:56 --> Output Class Initialized
INFO - 2023-08-09 18:08:56 --> Security Class Initialized
DEBUG - 2023-08-09 18:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:08:56 --> Input Class Initialized
INFO - 2023-08-09 18:08:56 --> Language Class Initialized
ERROR - 2023-08-09 18:08:56 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 18:11:46 --> Config Class Initialized
INFO - 2023-08-09 18:11:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:11:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:11:46 --> Utf8 Class Initialized
INFO - 2023-08-09 18:11:46 --> URI Class Initialized
INFO - 2023-08-09 18:11:46 --> Router Class Initialized
INFO - 2023-08-09 18:11:46 --> Output Class Initialized
INFO - 2023-08-09 18:11:46 --> Security Class Initialized
DEBUG - 2023-08-09 18:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:11:46 --> Input Class Initialized
INFO - 2023-08-09 18:11:46 --> Language Class Initialized
INFO - 2023-08-09 18:11:46 --> Loader Class Initialized
INFO - 2023-08-09 18:11:47 --> Helper loaded: url_helper
INFO - 2023-08-09 18:11:47 --> Helper loaded: file_helper
INFO - 2023-08-09 18:11:47 --> Database Driver Class Initialized
INFO - 2023-08-09 18:11:47 --> Email Class Initialized
DEBUG - 2023-08-09 18:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:11:47 --> Controller Class Initialized
INFO - 2023-08-09 18:11:47 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:11:47 --> Helper loaded: form_helper
INFO - 2023-08-09 18:11:47 --> Form Validation Class Initialized
INFO - 2023-08-09 18:11:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:11:47 --> Final output sent to browser
DEBUG - 2023-08-09 18:11:47 --> Total execution time: 0.5247
INFO - 2023-08-09 18:11:47 --> Config Class Initialized
INFO - 2023-08-09 18:11:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:11:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:11:47 --> Utf8 Class Initialized
INFO - 2023-08-09 18:11:47 --> URI Class Initialized
INFO - 2023-08-09 18:11:47 --> Router Class Initialized
INFO - 2023-08-09 18:11:47 --> Output Class Initialized
INFO - 2023-08-09 18:11:47 --> Security Class Initialized
DEBUG - 2023-08-09 18:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:11:47 --> Input Class Initialized
INFO - 2023-08-09 18:11:47 --> Language Class Initialized
INFO - 2023-08-09 18:11:47 --> Loader Class Initialized
INFO - 2023-08-09 18:11:47 --> Helper loaded: url_helper
INFO - 2023-08-09 18:11:47 --> Helper loaded: file_helper
INFO - 2023-08-09 18:11:47 --> Database Driver Class Initialized
INFO - 2023-08-09 18:11:47 --> Email Class Initialized
DEBUG - 2023-08-09 18:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:11:47 --> Controller Class Initialized
INFO - 2023-08-09 18:11:47 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:11:47 --> Helper loaded: form_helper
INFO - 2023-08-09 18:11:47 --> Form Validation Class Initialized
INFO - 2023-08-09 18:11:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:11:47 --> Final output sent to browser
DEBUG - 2023-08-09 18:11:47 --> Total execution time: 0.0944
INFO - 2023-08-09 18:11:53 --> Config Class Initialized
INFO - 2023-08-09 18:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:11:54 --> Utf8 Class Initialized
INFO - 2023-08-09 18:11:54 --> URI Class Initialized
INFO - 2023-08-09 18:11:54 --> Router Class Initialized
INFO - 2023-08-09 18:11:54 --> Output Class Initialized
INFO - 2023-08-09 18:11:54 --> Security Class Initialized
DEBUG - 2023-08-09 18:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:11:54 --> Input Class Initialized
INFO - 2023-08-09 18:11:54 --> Language Class Initialized
INFO - 2023-08-09 18:11:54 --> Loader Class Initialized
INFO - 2023-08-09 18:11:54 --> Helper loaded: url_helper
INFO - 2023-08-09 18:11:54 --> Helper loaded: file_helper
INFO - 2023-08-09 18:11:54 --> Database Driver Class Initialized
INFO - 2023-08-09 18:11:54 --> Email Class Initialized
DEBUG - 2023-08-09 18:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:11:54 --> Controller Class Initialized
INFO - 2023-08-09 18:11:54 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:11:54 --> Helper loaded: form_helper
INFO - 2023-08-09 18:11:54 --> Form Validation Class Initialized
INFO - 2023-08-09 18:11:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 18:11:54 --> Config Class Initialized
INFO - 2023-08-09 18:11:54 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:11:54 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:11:54 --> Utf8 Class Initialized
INFO - 2023-08-09 18:11:54 --> URI Class Initialized
INFO - 2023-08-09 18:11:54 --> Router Class Initialized
INFO - 2023-08-09 18:11:54 --> Output Class Initialized
INFO - 2023-08-09 18:11:54 --> Security Class Initialized
DEBUG - 2023-08-09 18:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:11:54 --> Input Class Initialized
INFO - 2023-08-09 18:11:54 --> Language Class Initialized
INFO - 2023-08-09 18:11:54 --> Loader Class Initialized
INFO - 2023-08-09 18:11:54 --> Helper loaded: url_helper
INFO - 2023-08-09 18:11:54 --> Helper loaded: file_helper
INFO - 2023-08-09 18:11:55 --> Database Driver Class Initialized
INFO - 2023-08-09 18:11:55 --> Email Class Initialized
DEBUG - 2023-08-09 18:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:11:55 --> Controller Class Initialized
INFO - 2023-08-09 18:11:55 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:11:55 --> Helper loaded: form_helper
INFO - 2023-08-09 18:11:55 --> Form Validation Class Initialized
INFO - 2023-08-09 18:11:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:11:55 --> Final output sent to browser
DEBUG - 2023-08-09 18:11:55 --> Total execution time: 0.6130
INFO - 2023-08-09 18:12:05 --> Config Class Initialized
INFO - 2023-08-09 18:12:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:12:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:12:05 --> Utf8 Class Initialized
INFO - 2023-08-09 18:12:05 --> URI Class Initialized
INFO - 2023-08-09 18:12:05 --> Router Class Initialized
INFO - 2023-08-09 18:12:05 --> Output Class Initialized
INFO - 2023-08-09 18:12:05 --> Security Class Initialized
DEBUG - 2023-08-09 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:12:05 --> Input Class Initialized
INFO - 2023-08-09 18:12:05 --> Language Class Initialized
INFO - 2023-08-09 18:12:05 --> Loader Class Initialized
INFO - 2023-08-09 18:12:06 --> Helper loaded: url_helper
INFO - 2023-08-09 18:12:06 --> Helper loaded: file_helper
INFO - 2023-08-09 18:12:06 --> Database Driver Class Initialized
INFO - 2023-08-09 18:12:06 --> Email Class Initialized
DEBUG - 2023-08-09 18:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:12:06 --> Controller Class Initialized
INFO - 2023-08-09 18:12:06 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:12:06 --> Helper loaded: form_helper
INFO - 2023-08-09 18:12:06 --> Form Validation Class Initialized
INFO - 2023-08-09 18:12:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:12:06 --> Final output sent to browser
DEBUG - 2023-08-09 18:12:06 --> Total execution time: 0.4672
INFO - 2023-08-09 18:12:06 --> Config Class Initialized
INFO - 2023-08-09 18:12:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:12:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:12:06 --> Utf8 Class Initialized
INFO - 2023-08-09 18:12:06 --> URI Class Initialized
INFO - 2023-08-09 18:12:06 --> Router Class Initialized
INFO - 2023-08-09 18:12:06 --> Output Class Initialized
INFO - 2023-08-09 18:12:06 --> Security Class Initialized
DEBUG - 2023-08-09 18:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:12:06 --> Input Class Initialized
INFO - 2023-08-09 18:12:06 --> Language Class Initialized
INFO - 2023-08-09 18:12:06 --> Loader Class Initialized
INFO - 2023-08-09 18:12:06 --> Helper loaded: url_helper
INFO - 2023-08-09 18:12:06 --> Helper loaded: file_helper
INFO - 2023-08-09 18:12:06 --> Database Driver Class Initialized
INFO - 2023-08-09 18:12:06 --> Email Class Initialized
DEBUG - 2023-08-09 18:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:12:06 --> Controller Class Initialized
INFO - 2023-08-09 18:12:06 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:12:06 --> Helper loaded: form_helper
INFO - 2023-08-09 18:12:07 --> Form Validation Class Initialized
INFO - 2023-08-09 18:12:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:12:07 --> Final output sent to browser
DEBUG - 2023-08-09 18:12:07 --> Total execution time: 0.4848
INFO - 2023-08-09 18:12:08 --> Config Class Initialized
INFO - 2023-08-09 18:12:08 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:12:08 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:12:08 --> Utf8 Class Initialized
INFO - 2023-08-09 18:12:08 --> URI Class Initialized
INFO - 2023-08-09 18:12:08 --> Router Class Initialized
INFO - 2023-08-09 18:12:08 --> Output Class Initialized
INFO - 2023-08-09 18:12:08 --> Security Class Initialized
DEBUG - 2023-08-09 18:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:12:08 --> Input Class Initialized
INFO - 2023-08-09 18:12:13 --> Config Class Initialized
INFO - 2023-08-09 18:12:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:12:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:12:13 --> Utf8 Class Initialized
INFO - 2023-08-09 18:12:13 --> URI Class Initialized
INFO - 2023-08-09 18:12:13 --> Router Class Initialized
INFO - 2023-08-09 18:12:13 --> Output Class Initialized
INFO - 2023-08-09 18:12:13 --> Security Class Initialized
DEBUG - 2023-08-09 18:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:12:13 --> Input Class Initialized
INFO - 2023-08-09 18:12:13 --> Language Class Initialized
INFO - 2023-08-09 18:12:13 --> Loader Class Initialized
INFO - 2023-08-09 18:12:13 --> Helper loaded: url_helper
INFO - 2023-08-09 18:12:13 --> Helper loaded: file_helper
INFO - 2023-08-09 18:12:13 --> Database Driver Class Initialized
INFO - 2023-08-09 18:12:13 --> Email Class Initialized
DEBUG - 2023-08-09 18:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:12:13 --> Controller Class Initialized
INFO - 2023-08-09 18:12:13 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:12:13 --> Helper loaded: form_helper
INFO - 2023-08-09 18:12:13 --> Form Validation Class Initialized
INFO - 2023-08-09 18:12:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:12:14 --> Final output sent to browser
DEBUG - 2023-08-09 18:12:14 --> Total execution time: 0.4352
INFO - 2023-08-09 18:13:19 --> Config Class Initialized
INFO - 2023-08-09 18:13:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:19 --> URI Class Initialized
INFO - 2023-08-09 18:13:19 --> Router Class Initialized
INFO - 2023-08-09 18:13:19 --> Output Class Initialized
INFO - 2023-08-09 18:13:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:19 --> Input Class Initialized
INFO - 2023-08-09 18:13:19 --> Language Class Initialized
INFO - 2023-08-09 18:13:19 --> Loader Class Initialized
INFO - 2023-08-09 18:13:19 --> Helper loaded: url_helper
INFO - 2023-08-09 18:13:19 --> Helper loaded: file_helper
INFO - 2023-08-09 18:13:19 --> Database Driver Class Initialized
INFO - 2023-08-09 18:13:19 --> Email Class Initialized
DEBUG - 2023-08-09 18:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:13:19 --> Controller Class Initialized
INFO - 2023-08-09 18:13:19 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:13:19 --> Helper loaded: form_helper
INFO - 2023-08-09 18:13:19 --> Form Validation Class Initialized
INFO - 2023-08-09 18:13:19 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:13:19 --> Final output sent to browser
DEBUG - 2023-08-09 18:13:19 --> Total execution time: 0.2212
INFO - 2023-08-09 18:13:19 --> Config Class Initialized
INFO - 2023-08-09 18:13:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:19 --> URI Class Initialized
INFO - 2023-08-09 18:13:19 --> Router Class Initialized
INFO - 2023-08-09 18:13:19 --> Output Class Initialized
INFO - 2023-08-09 18:13:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:19 --> Input Class Initialized
INFO - 2023-08-09 18:13:19 --> Language Class Initialized
INFO - 2023-08-09 18:13:19 --> Loader Class Initialized
INFO - 2023-08-09 18:13:19 --> Helper loaded: url_helper
INFO - 2023-08-09 18:13:19 --> Helper loaded: file_helper
INFO - 2023-08-09 18:13:19 --> Database Driver Class Initialized
INFO - 2023-08-09 18:13:19 --> Email Class Initialized
DEBUG - 2023-08-09 18:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:13:19 --> Controller Class Initialized
INFO - 2023-08-09 18:13:19 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:13:19 --> Helper loaded: form_helper
INFO - 2023-08-09 18:13:19 --> Form Validation Class Initialized
INFO - 2023-08-09 18:13:19 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:13:19 --> Final output sent to browser
DEBUG - 2023-08-09 18:13:19 --> Total execution time: 0.0550
INFO - 2023-08-09 18:13:30 --> Config Class Initialized
INFO - 2023-08-09 18:13:30 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:30 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:30 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:30 --> URI Class Initialized
INFO - 2023-08-09 18:13:30 --> Router Class Initialized
INFO - 2023-08-09 18:13:30 --> Output Class Initialized
INFO - 2023-08-09 18:13:30 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:30 --> Input Class Initialized
INFO - 2023-08-09 18:13:30 --> Language Class Initialized
ERROR - 2023-08-09 18:13:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:13:30 --> Config Class Initialized
INFO - 2023-08-09 18:13:30 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:30 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:30 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:30 --> URI Class Initialized
INFO - 2023-08-09 18:13:30 --> Router Class Initialized
INFO - 2023-08-09 18:13:30 --> Output Class Initialized
INFO - 2023-08-09 18:13:30 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:30 --> Input Class Initialized
INFO - 2023-08-09 18:13:30 --> Language Class Initialized
ERROR - 2023-08-09 18:13:30 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:13:37 --> Config Class Initialized
INFO - 2023-08-09 18:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:37 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:37 --> URI Class Initialized
INFO - 2023-08-09 18:13:37 --> Router Class Initialized
INFO - 2023-08-09 18:13:37 --> Output Class Initialized
INFO - 2023-08-09 18:13:37 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:37 --> Input Class Initialized
INFO - 2023-08-09 18:13:37 --> Language Class Initialized
INFO - 2023-08-09 18:13:37 --> Loader Class Initialized
INFO - 2023-08-09 18:13:37 --> Helper loaded: url_helper
INFO - 2023-08-09 18:13:37 --> Helper loaded: file_helper
INFO - 2023-08-09 18:13:37 --> Database Driver Class Initialized
INFO - 2023-08-09 18:13:37 --> Email Class Initialized
DEBUG - 2023-08-09 18:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:13:37 --> Controller Class Initialized
INFO - 2023-08-09 18:13:37 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:13:37 --> Helper loaded: form_helper
INFO - 2023-08-09 18:13:37 --> Form Validation Class Initialized
INFO - 2023-08-09 18:13:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:13:37 --> Final output sent to browser
DEBUG - 2023-08-09 18:13:37 --> Total execution time: 0.1826
INFO - 2023-08-09 18:13:37 --> Config Class Initialized
INFO - 2023-08-09 18:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:37 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:37 --> URI Class Initialized
INFO - 2023-08-09 18:13:37 --> Router Class Initialized
INFO - 2023-08-09 18:13:37 --> Output Class Initialized
INFO - 2023-08-09 18:13:37 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:37 --> Input Class Initialized
INFO - 2023-08-09 18:13:37 --> Language Class Initialized
ERROR - 2023-08-09 18:13:37 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:13:37 --> Config Class Initialized
INFO - 2023-08-09 18:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:37 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:37 --> URI Class Initialized
INFO - 2023-08-09 18:13:37 --> Router Class Initialized
INFO - 2023-08-09 18:13:37 --> Output Class Initialized
INFO - 2023-08-09 18:13:37 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:37 --> Input Class Initialized
INFO - 2023-08-09 18:13:37 --> Language Class Initialized
ERROR - 2023-08-09 18:13:37 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:13:38 --> Config Class Initialized
INFO - 2023-08-09 18:13:38 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:13:38 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:13:38 --> Utf8 Class Initialized
INFO - 2023-08-09 18:13:38 --> URI Class Initialized
INFO - 2023-08-09 18:13:38 --> Router Class Initialized
INFO - 2023-08-09 18:13:38 --> Output Class Initialized
INFO - 2023-08-09 18:13:38 --> Security Class Initialized
DEBUG - 2023-08-09 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:13:38 --> Input Class Initialized
INFO - 2023-08-09 18:13:38 --> Language Class Initialized
INFO - 2023-08-09 18:13:38 --> Loader Class Initialized
INFO - 2023-08-09 18:13:38 --> Helper loaded: url_helper
INFO - 2023-08-09 18:13:38 --> Helper loaded: file_helper
INFO - 2023-08-09 18:13:38 --> Database Driver Class Initialized
INFO - 2023-08-09 18:13:38 --> Email Class Initialized
DEBUG - 2023-08-09 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:13:38 --> Controller Class Initialized
INFO - 2023-08-09 18:13:38 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:13:38 --> Helper loaded: form_helper
INFO - 2023-08-09 18:13:38 --> Form Validation Class Initialized
INFO - 2023-08-09 18:13:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:13:38 --> Final output sent to browser
DEBUG - 2023-08-09 18:13:38 --> Total execution time: 0.0447
INFO - 2023-08-09 18:15:36 --> Config Class Initialized
INFO - 2023-08-09 18:15:36 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:15:36 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:15:36 --> Utf8 Class Initialized
INFO - 2023-08-09 18:15:36 --> URI Class Initialized
INFO - 2023-08-09 18:15:36 --> Router Class Initialized
INFO - 2023-08-09 18:15:36 --> Output Class Initialized
INFO - 2023-08-09 18:15:36 --> Security Class Initialized
DEBUG - 2023-08-09 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:15:36 --> Input Class Initialized
INFO - 2023-08-09 18:15:36 --> Language Class Initialized
INFO - 2023-08-09 18:15:36 --> Loader Class Initialized
INFO - 2023-08-09 18:15:36 --> Helper loaded: url_helper
INFO - 2023-08-09 18:15:36 --> Helper loaded: file_helper
INFO - 2023-08-09 18:15:36 --> Database Driver Class Initialized
INFO - 2023-08-09 18:15:36 --> Email Class Initialized
DEBUG - 2023-08-09 18:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:15:37 --> Controller Class Initialized
INFO - 2023-08-09 18:15:37 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:15:37 --> Helper loaded: form_helper
INFO - 2023-08-09 18:15:37 --> Form Validation Class Initialized
INFO - 2023-08-09 18:15:37 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:15:37 --> Final output sent to browser
DEBUG - 2023-08-09 18:15:37 --> Total execution time: 0.2902
INFO - 2023-08-09 18:15:37 --> Config Class Initialized
INFO - 2023-08-09 18:15:37 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:15:37 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:15:37 --> Utf8 Class Initialized
INFO - 2023-08-09 18:15:37 --> URI Class Initialized
INFO - 2023-08-09 18:15:37 --> Router Class Initialized
INFO - 2023-08-09 18:15:37 --> Output Class Initialized
INFO - 2023-08-09 18:15:37 --> Security Class Initialized
DEBUG - 2023-08-09 18:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:15:37 --> Input Class Initialized
INFO - 2023-08-09 18:15:37 --> Language Class Initialized
ERROR - 2023-08-09 18:15:37 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:15:38 --> Config Class Initialized
INFO - 2023-08-09 18:15:38 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:15:38 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:15:38 --> Utf8 Class Initialized
INFO - 2023-08-09 18:15:38 --> URI Class Initialized
INFO - 2023-08-09 18:15:38 --> Router Class Initialized
INFO - 2023-08-09 18:15:38 --> Output Class Initialized
INFO - 2023-08-09 18:15:38 --> Security Class Initialized
DEBUG - 2023-08-09 18:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:15:38 --> Input Class Initialized
INFO - 2023-08-09 18:15:38 --> Language Class Initialized
ERROR - 2023-08-09 18:15:38 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:15:38 --> Config Class Initialized
INFO - 2023-08-09 18:15:38 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:15:38 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:15:38 --> Utf8 Class Initialized
INFO - 2023-08-09 18:15:38 --> URI Class Initialized
INFO - 2023-08-09 18:15:38 --> Router Class Initialized
INFO - 2023-08-09 18:15:38 --> Output Class Initialized
INFO - 2023-08-09 18:15:38 --> Security Class Initialized
DEBUG - 2023-08-09 18:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:15:38 --> Input Class Initialized
INFO - 2023-08-09 18:15:38 --> Language Class Initialized
INFO - 2023-08-09 18:15:38 --> Loader Class Initialized
INFO - 2023-08-09 18:15:38 --> Helper loaded: url_helper
INFO - 2023-08-09 18:15:38 --> Helper loaded: file_helper
INFO - 2023-08-09 18:15:38 --> Database Driver Class Initialized
INFO - 2023-08-09 18:15:38 --> Email Class Initialized
DEBUG - 2023-08-09 18:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:15:38 --> Controller Class Initialized
INFO - 2023-08-09 18:15:38 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:15:38 --> Helper loaded: form_helper
INFO - 2023-08-09 18:15:38 --> Form Validation Class Initialized
INFO - 2023-08-09 18:15:38 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:15:38 --> Final output sent to browser
DEBUG - 2023-08-09 18:15:38 --> Total execution time: 0.0674
INFO - 2023-08-09 18:15:42 --> Config Class Initialized
INFO - 2023-08-09 18:15:42 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:15:42 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:15:42 --> Utf8 Class Initialized
INFO - 2023-08-09 18:15:42 --> URI Class Initialized
INFO - 2023-08-09 18:15:42 --> Router Class Initialized
INFO - 2023-08-09 18:15:42 --> Output Class Initialized
INFO - 2023-08-09 18:15:42 --> Security Class Initialized
DEBUG - 2023-08-09 18:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:15:42 --> Input Class Initialized
INFO - 2023-08-09 18:15:42 --> Language Class Initialized
INFO - 2023-08-09 18:15:42 --> Loader Class Initialized
INFO - 2023-08-09 18:15:42 --> Helper loaded: url_helper
INFO - 2023-08-09 18:15:42 --> Helper loaded: file_helper
INFO - 2023-08-09 18:15:42 --> Database Driver Class Initialized
INFO - 2023-08-09 18:15:42 --> Email Class Initialized
DEBUG - 2023-08-09 18:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:15:42 --> Controller Class Initialized
INFO - 2023-08-09 18:15:42 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:15:42 --> Helper loaded: form_helper
INFO - 2023-08-09 18:15:42 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:02 --> Config Class Initialized
INFO - 2023-08-09 18:16:02 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:02 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:03 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:03 --> URI Class Initialized
INFO - 2023-08-09 18:16:03 --> Router Class Initialized
INFO - 2023-08-09 18:16:03 --> Output Class Initialized
INFO - 2023-08-09 18:16:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:03 --> Input Class Initialized
INFO - 2023-08-09 18:16:03 --> Language Class Initialized
INFO - 2023-08-09 18:16:03 --> Loader Class Initialized
INFO - 2023-08-09 18:16:03 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:03 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:03 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:03 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:03 --> Controller Class Initialized
INFO - 2023-08-09 18:16:03 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:03 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:03 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:04 --> Config Class Initialized
INFO - 2023-08-09 18:16:04 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:04 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:04 --> URI Class Initialized
INFO - 2023-08-09 18:16:04 --> Router Class Initialized
INFO - 2023-08-09 18:16:04 --> Output Class Initialized
INFO - 2023-08-09 18:16:04 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:04 --> Input Class Initialized
INFO - 2023-08-09 18:16:04 --> Language Class Initialized
INFO - 2023-08-09 18:16:04 --> Loader Class Initialized
INFO - 2023-08-09 18:16:04 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:04 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:04 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:04 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:04 --> Controller Class Initialized
INFO - 2023-08-09 18:16:04 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:04 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:04 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:05 --> Config Class Initialized
INFO - 2023-08-09 18:16:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:05 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:05 --> URI Class Initialized
INFO - 2023-08-09 18:16:05 --> Router Class Initialized
INFO - 2023-08-09 18:16:05 --> Output Class Initialized
INFO - 2023-08-09 18:16:05 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:05 --> Input Class Initialized
INFO - 2023-08-09 18:16:05 --> Language Class Initialized
INFO - 2023-08-09 18:16:05 --> Loader Class Initialized
INFO - 2023-08-09 18:16:05 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:05 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:05 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:05 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:05 --> Controller Class Initialized
INFO - 2023-08-09 18:16:05 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:05 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:05 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:43 --> Config Class Initialized
INFO - 2023-08-09 18:16:43 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:43 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:43 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:43 --> URI Class Initialized
INFO - 2023-08-09 18:16:43 --> Router Class Initialized
INFO - 2023-08-09 18:16:43 --> Output Class Initialized
INFO - 2023-08-09 18:16:43 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:43 --> Input Class Initialized
INFO - 2023-08-09 18:16:43 --> Language Class Initialized
INFO - 2023-08-09 18:16:43 --> Loader Class Initialized
INFO - 2023-08-09 18:16:43 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:43 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:43 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:43 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:43 --> Controller Class Initialized
INFO - 2023-08-09 18:16:43 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:43 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:43 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:44 --> Config Class Initialized
INFO - 2023-08-09 18:16:44 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:44 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:44 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:44 --> URI Class Initialized
INFO - 2023-08-09 18:16:44 --> Router Class Initialized
INFO - 2023-08-09 18:16:44 --> Output Class Initialized
INFO - 2023-08-09 18:16:44 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:44 --> Input Class Initialized
INFO - 2023-08-09 18:16:44 --> Language Class Initialized
INFO - 2023-08-09 18:16:44 --> Loader Class Initialized
INFO - 2023-08-09 18:16:44 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:44 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:44 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:44 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:44 --> Controller Class Initialized
INFO - 2023-08-09 18:16:44 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:44 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:44 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:45 --> Config Class Initialized
INFO - 2023-08-09 18:16:45 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:45 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:45 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:45 --> URI Class Initialized
INFO - 2023-08-09 18:16:45 --> Router Class Initialized
INFO - 2023-08-09 18:16:45 --> Output Class Initialized
INFO - 2023-08-09 18:16:45 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:45 --> Input Class Initialized
INFO - 2023-08-09 18:16:45 --> Language Class Initialized
INFO - 2023-08-09 18:16:45 --> Loader Class Initialized
INFO - 2023-08-09 18:16:45 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:45 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:45 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:45 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:45 --> Controller Class Initialized
INFO - 2023-08-09 18:16:45 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:45 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:45 --> Form Validation Class Initialized
INFO - 2023-08-09 18:16:45 --> Config Class Initialized
INFO - 2023-08-09 18:16:45 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:16:45 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:16:45 --> Utf8 Class Initialized
INFO - 2023-08-09 18:16:45 --> URI Class Initialized
INFO - 2023-08-09 18:16:45 --> Router Class Initialized
INFO - 2023-08-09 18:16:45 --> Output Class Initialized
INFO - 2023-08-09 18:16:45 --> Security Class Initialized
DEBUG - 2023-08-09 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:16:45 --> Input Class Initialized
INFO - 2023-08-09 18:16:45 --> Language Class Initialized
INFO - 2023-08-09 18:16:45 --> Loader Class Initialized
INFO - 2023-08-09 18:16:45 --> Helper loaded: url_helper
INFO - 2023-08-09 18:16:45 --> Helper loaded: file_helper
INFO - 2023-08-09 18:16:45 --> Database Driver Class Initialized
INFO - 2023-08-09 18:16:45 --> Email Class Initialized
DEBUG - 2023-08-09 18:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:16:45 --> Controller Class Initialized
INFO - 2023-08-09 18:16:45 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:16:45 --> Helper loaded: form_helper
INFO - 2023-08-09 18:16:45 --> Form Validation Class Initialized
INFO - 2023-08-09 18:19:00 --> Config Class Initialized
INFO - 2023-08-09 18:19:00 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:19:00 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:19:00 --> Utf8 Class Initialized
INFO - 2023-08-09 18:19:00 --> URI Class Initialized
INFO - 2023-08-09 18:19:00 --> Router Class Initialized
INFO - 2023-08-09 18:19:00 --> Output Class Initialized
INFO - 2023-08-09 18:19:00 --> Security Class Initialized
DEBUG - 2023-08-09 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:19:00 --> Input Class Initialized
INFO - 2023-08-09 18:19:00 --> Language Class Initialized
INFO - 2023-08-09 18:19:00 --> Loader Class Initialized
INFO - 2023-08-09 18:19:00 --> Helper loaded: url_helper
INFO - 2023-08-09 18:19:00 --> Helper loaded: file_helper
INFO - 2023-08-09 18:19:00 --> Database Driver Class Initialized
INFO - 2023-08-09 18:19:00 --> Email Class Initialized
DEBUG - 2023-08-09 18:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:19:00 --> Controller Class Initialized
INFO - 2023-08-09 18:19:00 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:19:00 --> Helper loaded: form_helper
INFO - 2023-08-09 18:19:00 --> Form Validation Class Initialized
INFO - 2023-08-09 18:19:00 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:19:00 --> Final output sent to browser
DEBUG - 2023-08-09 18:19:01 --> Total execution time: 0.5684
INFO - 2023-08-09 18:19:02 --> Config Class Initialized
INFO - 2023-08-09 18:19:02 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:19:02 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:19:02 --> Utf8 Class Initialized
INFO - 2023-08-09 18:19:03 --> URI Class Initialized
INFO - 2023-08-09 18:19:03 --> Router Class Initialized
INFO - 2023-08-09 18:19:03 --> Output Class Initialized
INFO - 2023-08-09 18:19:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:19:03 --> Input Class Initialized
INFO - 2023-08-09 18:19:03 --> Language Class Initialized
ERROR - 2023-08-09 18:19:03 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:19:03 --> Config Class Initialized
INFO - 2023-08-09 18:19:03 --> Config Class Initialized
INFO - 2023-08-09 18:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:19:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:19:04 --> Hooks Class Initialized
INFO - 2023-08-09 18:19:04 --> Utf8 Class Initialized
DEBUG - 2023-08-09 18:19:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:19:04 --> URI Class Initialized
INFO - 2023-08-09 18:19:04 --> Utf8 Class Initialized
INFO - 2023-08-09 18:19:04 --> Router Class Initialized
INFO - 2023-08-09 18:19:04 --> URI Class Initialized
INFO - 2023-08-09 18:19:04 --> Output Class Initialized
INFO - 2023-08-09 18:19:04 --> Router Class Initialized
INFO - 2023-08-09 18:19:04 --> Security Class Initialized
INFO - 2023-08-09 18:19:04 --> Output Class Initialized
DEBUG - 2023-08-09 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:19:04 --> Security Class Initialized
INFO - 2023-08-09 18:19:04 --> Input Class Initialized
DEBUG - 2023-08-09 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:19:04 --> Language Class Initialized
INFO - 2023-08-09 18:19:04 --> Input Class Initialized
ERROR - 2023-08-09 18:19:04 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:19:04 --> Language Class Initialized
INFO - 2023-08-09 18:19:04 --> Loader Class Initialized
INFO - 2023-08-09 18:19:04 --> Helper loaded: url_helper
INFO - 2023-08-09 18:19:04 --> Helper loaded: file_helper
INFO - 2023-08-09 18:19:04 --> Database Driver Class Initialized
INFO - 2023-08-09 18:19:04 --> Email Class Initialized
DEBUG - 2023-08-09 18:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:19:04 --> Controller Class Initialized
INFO - 2023-08-09 18:19:04 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:19:04 --> Helper loaded: form_helper
INFO - 2023-08-09 18:19:04 --> Form Validation Class Initialized
INFO - 2023-08-09 18:19:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:19:04 --> Final output sent to browser
DEBUG - 2023-08-09 18:19:04 --> Total execution time: 0.6134
INFO - 2023-08-09 18:22:25 --> Config Class Initialized
INFO - 2023-08-09 18:22:25 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:22:25 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:22:25 --> Utf8 Class Initialized
INFO - 2023-08-09 18:22:25 --> URI Class Initialized
INFO - 2023-08-09 18:22:25 --> Router Class Initialized
INFO - 2023-08-09 18:22:25 --> Output Class Initialized
INFO - 2023-08-09 18:22:25 --> Security Class Initialized
DEBUG - 2023-08-09 18:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:22:25 --> Input Class Initialized
INFO - 2023-08-09 18:22:25 --> Language Class Initialized
INFO - 2023-08-09 18:22:25 --> Loader Class Initialized
INFO - 2023-08-09 18:22:25 --> Helper loaded: url_helper
INFO - 2023-08-09 18:22:25 --> Helper loaded: file_helper
INFO - 2023-08-09 18:22:25 --> Database Driver Class Initialized
INFO - 2023-08-09 18:22:25 --> Email Class Initialized
DEBUG - 2023-08-09 18:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:22:25 --> Controller Class Initialized
INFO - 2023-08-09 18:22:25 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:22:26 --> Helper loaded: form_helper
INFO - 2023-08-09 18:22:26 --> Form Validation Class Initialized
INFO - 2023-08-09 18:22:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:22:26 --> Final output sent to browser
DEBUG - 2023-08-09 18:22:26 --> Total execution time: 0.0978
INFO - 2023-08-09 18:22:27 --> Config Class Initialized
INFO - 2023-08-09 18:22:27 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:22:27 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:22:27 --> Utf8 Class Initialized
INFO - 2023-08-09 18:22:27 --> URI Class Initialized
INFO - 2023-08-09 18:22:27 --> Router Class Initialized
INFO - 2023-08-09 18:22:27 --> Output Class Initialized
INFO - 2023-08-09 18:22:27 --> Security Class Initialized
DEBUG - 2023-08-09 18:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:22:27 --> Input Class Initialized
INFO - 2023-08-09 18:22:27 --> Language Class Initialized
ERROR - 2023-08-09 18:22:27 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:22:28 --> Config Class Initialized
INFO - 2023-08-09 18:22:28 --> Config Class Initialized
INFO - 2023-08-09 18:22:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:22:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:22:28 --> Utf8 Class Initialized
INFO - 2023-08-09 18:22:28 --> URI Class Initialized
INFO - 2023-08-09 18:22:28 --> Router Class Initialized
INFO - 2023-08-09 18:22:28 --> Output Class Initialized
INFO - 2023-08-09 18:22:28 --> Security Class Initialized
DEBUG - 2023-08-09 18:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:22:28 --> Input Class Initialized
INFO - 2023-08-09 18:22:28 --> Language Class Initialized
INFO - 2023-08-09 18:22:28 --> Loader Class Initialized
INFO - 2023-08-09 18:22:28 --> Helper loaded: url_helper
INFO - 2023-08-09 18:22:28 --> Helper loaded: file_helper
INFO - 2023-08-09 18:22:28 --> Database Driver Class Initialized
INFO - 2023-08-09 18:22:28 --> Email Class Initialized
DEBUG - 2023-08-09 18:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:22:28 --> Controller Class Initialized
INFO - 2023-08-09 18:22:28 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:22:28 --> Helper loaded: form_helper
INFO - 2023-08-09 18:22:28 --> Form Validation Class Initialized
INFO - 2023-08-09 18:22:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:22:28 --> Final output sent to browser
DEBUG - 2023-08-09 18:22:28 --> Total execution time: 0.0478
INFO - 2023-08-09 18:22:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:22:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:22:28 --> Utf8 Class Initialized
INFO - 2023-08-09 18:22:29 --> URI Class Initialized
INFO - 2023-08-09 18:22:29 --> Router Class Initialized
INFO - 2023-08-09 18:22:29 --> Output Class Initialized
INFO - 2023-08-09 18:22:29 --> Security Class Initialized
DEBUG - 2023-08-09 18:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:22:29 --> Input Class Initialized
INFO - 2023-08-09 18:22:29 --> Language Class Initialized
ERROR - 2023-08-09 18:22:29 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:24:18 --> Config Class Initialized
INFO - 2023-08-09 18:24:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:18 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:18 --> URI Class Initialized
INFO - 2023-08-09 18:24:18 --> Router Class Initialized
INFO - 2023-08-09 18:24:18 --> Output Class Initialized
INFO - 2023-08-09 18:24:18 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:18 --> Input Class Initialized
INFO - 2023-08-09 18:24:18 --> Language Class Initialized
INFO - 2023-08-09 18:24:18 --> Loader Class Initialized
INFO - 2023-08-09 18:24:18 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:18 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:18 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:18 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:18 --> Controller Class Initialized
INFO - 2023-08-09 18:24:18 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:18 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:18 --> Form Validation Class Initialized
INFO - 2023-08-09 18:24:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:24:18 --> Final output sent to browser
DEBUG - 2023-08-09 18:24:19 --> Total execution time: 0.4033
INFO - 2023-08-09 18:24:19 --> Config Class Initialized
INFO - 2023-08-09 18:24:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:19 --> URI Class Initialized
INFO - 2023-08-09 18:24:19 --> Router Class Initialized
INFO - 2023-08-09 18:24:19 --> Output Class Initialized
INFO - 2023-08-09 18:24:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:19 --> Input Class Initialized
INFO - 2023-08-09 18:24:19 --> Language Class Initialized
ERROR - 2023-08-09 18:24:19 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:24:19 --> Config Class Initialized
INFO - 2023-08-09 18:24:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:19 --> URI Class Initialized
INFO - 2023-08-09 18:24:19 --> Router Class Initialized
INFO - 2023-08-09 18:24:19 --> Output Class Initialized
INFO - 2023-08-09 18:24:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:19 --> Input Class Initialized
INFO - 2023-08-09 18:24:19 --> Language Class Initialized
ERROR - 2023-08-09 18:24:19 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:24:20 --> Config Class Initialized
INFO - 2023-08-09 18:24:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:20 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:20 --> URI Class Initialized
INFO - 2023-08-09 18:24:20 --> Router Class Initialized
INFO - 2023-08-09 18:24:20 --> Output Class Initialized
INFO - 2023-08-09 18:24:20 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:20 --> Input Class Initialized
INFO - 2023-08-09 18:24:20 --> Language Class Initialized
INFO - 2023-08-09 18:24:20 --> Loader Class Initialized
INFO - 2023-08-09 18:24:20 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:20 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:20 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:20 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:20 --> Controller Class Initialized
INFO - 2023-08-09 18:24:20 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:20 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:21 --> Form Validation Class Initialized
INFO - 2023-08-09 18:24:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:24:21 --> Final output sent to browser
DEBUG - 2023-08-09 18:24:21 --> Total execution time: 0.4212
INFO - 2023-08-09 18:24:45 --> Config Class Initialized
INFO - 2023-08-09 18:24:45 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:45 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:45 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:45 --> URI Class Initialized
INFO - 2023-08-09 18:24:46 --> Router Class Initialized
INFO - 2023-08-09 18:24:46 --> Output Class Initialized
INFO - 2023-08-09 18:24:46 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:46 --> Input Class Initialized
INFO - 2023-08-09 18:24:46 --> Language Class Initialized
INFO - 2023-08-09 18:24:46 --> Loader Class Initialized
INFO - 2023-08-09 18:24:46 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:46 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:46 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:46 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:46 --> Controller Class Initialized
INFO - 2023-08-09 18:24:46 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:46 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:46 --> Form Validation Class Initialized
INFO - 2023-08-09 18:24:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:24:46 --> Final output sent to browser
DEBUG - 2023-08-09 18:24:46 --> Total execution time: 0.3993
INFO - 2023-08-09 18:24:47 --> Config Class Initialized
INFO - 2023-08-09 18:24:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:47 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:47 --> URI Class Initialized
INFO - 2023-08-09 18:24:47 --> Router Class Initialized
INFO - 2023-08-09 18:24:47 --> Output Class Initialized
INFO - 2023-08-09 18:24:47 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:47 --> Input Class Initialized
INFO - 2023-08-09 18:24:47 --> Language Class Initialized
ERROR - 2023-08-09 18:24:47 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:24:47 --> Config Class Initialized
INFO - 2023-08-09 18:24:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:47 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:47 --> URI Class Initialized
INFO - 2023-08-09 18:24:47 --> Router Class Initialized
INFO - 2023-08-09 18:24:47 --> Output Class Initialized
INFO - 2023-08-09 18:24:47 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:47 --> Input Class Initialized
INFO - 2023-08-09 18:24:47 --> Language Class Initialized
ERROR - 2023-08-09 18:24:47 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:24:47 --> Config Class Initialized
INFO - 2023-08-09 18:24:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:47 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:47 --> URI Class Initialized
INFO - 2023-08-09 18:24:47 --> Router Class Initialized
INFO - 2023-08-09 18:24:47 --> Output Class Initialized
INFO - 2023-08-09 18:24:47 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:47 --> Input Class Initialized
INFO - 2023-08-09 18:24:47 --> Language Class Initialized
INFO - 2023-08-09 18:24:47 --> Loader Class Initialized
INFO - 2023-08-09 18:24:47 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:47 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:47 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:47 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:47 --> Controller Class Initialized
INFO - 2023-08-09 18:24:47 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:47 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:47 --> Form Validation Class Initialized
INFO - 2023-08-09 18:24:47 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:24:47 --> Final output sent to browser
DEBUG - 2023-08-09 18:24:47 --> Total execution time: 0.0458
INFO - 2023-08-09 18:24:51 --> Config Class Initialized
INFO - 2023-08-09 18:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:51 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:51 --> URI Class Initialized
INFO - 2023-08-09 18:24:51 --> Router Class Initialized
INFO - 2023-08-09 18:24:51 --> Output Class Initialized
INFO - 2023-08-09 18:24:51 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:51 --> Input Class Initialized
INFO - 2023-08-09 18:24:51 --> Language Class Initialized
INFO - 2023-08-09 18:24:51 --> Loader Class Initialized
INFO - 2023-08-09 18:24:51 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:51 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:51 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:51 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:51 --> Controller Class Initialized
INFO - 2023-08-09 18:24:51 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:51 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:51 --> Form Validation Class Initialized
INFO - 2023-08-09 18:24:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-09 18:24:51 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 112
INFO - 2023-08-09 18:24:51 --> Config Class Initialized
INFO - 2023-08-09 18:24:51 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:24:51 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:24:51 --> Utf8 Class Initialized
INFO - 2023-08-09 18:24:51 --> URI Class Initialized
INFO - 2023-08-09 18:24:51 --> Router Class Initialized
INFO - 2023-08-09 18:24:51 --> Output Class Initialized
INFO - 2023-08-09 18:24:51 --> Security Class Initialized
DEBUG - 2023-08-09 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:24:51 --> Input Class Initialized
INFO - 2023-08-09 18:24:51 --> Language Class Initialized
INFO - 2023-08-09 18:24:51 --> Loader Class Initialized
INFO - 2023-08-09 18:24:51 --> Helper loaded: url_helper
INFO - 2023-08-09 18:24:51 --> Helper loaded: file_helper
INFO - 2023-08-09 18:24:51 --> Database Driver Class Initialized
INFO - 2023-08-09 18:24:51 --> Email Class Initialized
DEBUG - 2023-08-09 18:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:24:51 --> Controller Class Initialized
INFO - 2023-08-09 18:24:51 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:24:51 --> Helper loaded: form_helper
INFO - 2023-08-09 18:24:51 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:24:51 --> Severity: error --> Exception: Too few arguments to function Services_cards::index(), 0 passed in C:\xampp\htdocs\DW\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 13
INFO - 2023-08-09 18:25:18 --> Config Class Initialized
INFO - 2023-08-09 18:25:18 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:25:18 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:25:18 --> Utf8 Class Initialized
INFO - 2023-08-09 18:25:18 --> URI Class Initialized
INFO - 2023-08-09 18:25:18 --> Router Class Initialized
INFO - 2023-08-09 18:25:18 --> Output Class Initialized
INFO - 2023-08-09 18:25:18 --> Security Class Initialized
DEBUG - 2023-08-09 18:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:25:18 --> Input Class Initialized
INFO - 2023-08-09 18:25:18 --> Language Class Initialized
INFO - 2023-08-09 18:25:18 --> Loader Class Initialized
INFO - 2023-08-09 18:25:18 --> Helper loaded: url_helper
INFO - 2023-08-09 18:25:18 --> Helper loaded: file_helper
INFO - 2023-08-09 18:25:18 --> Database Driver Class Initialized
INFO - 2023-08-09 18:25:18 --> Email Class Initialized
DEBUG - 2023-08-09 18:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:25:18 --> Controller Class Initialized
INFO - 2023-08-09 18:25:18 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:25:18 --> Helper loaded: form_helper
INFO - 2023-08-09 18:25:18 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:25:18 --> Severity: error --> Exception: Too few arguments to function Services_cards::index(), 0 passed in C:\xampp\htdocs\DW\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 13
INFO - 2023-08-09 18:25:19 --> Config Class Initialized
INFO - 2023-08-09 18:25:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:25:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:25:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:25:19 --> URI Class Initialized
INFO - 2023-08-09 18:25:19 --> Router Class Initialized
INFO - 2023-08-09 18:25:19 --> Output Class Initialized
INFO - 2023-08-09 18:25:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:25:19 --> Input Class Initialized
INFO - 2023-08-09 18:25:19 --> Language Class Initialized
INFO - 2023-08-09 18:25:19 --> Loader Class Initialized
INFO - 2023-08-09 18:25:19 --> Helper loaded: url_helper
INFO - 2023-08-09 18:25:19 --> Helper loaded: file_helper
INFO - 2023-08-09 18:25:19 --> Database Driver Class Initialized
INFO - 2023-08-09 18:25:19 --> Email Class Initialized
DEBUG - 2023-08-09 18:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:25:19 --> Controller Class Initialized
INFO - 2023-08-09 18:25:19 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:25:19 --> Helper loaded: form_helper
INFO - 2023-08-09 18:25:19 --> Form Validation Class Initialized
INFO - 2023-08-09 18:25:19 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:25:19 --> Final output sent to browser
DEBUG - 2023-08-09 18:25:19 --> Total execution time: 0.1010
INFO - 2023-08-09 18:25:19 --> Config Class Initialized
INFO - 2023-08-09 18:25:19 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:25:19 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:25:19 --> Utf8 Class Initialized
INFO - 2023-08-09 18:25:19 --> URI Class Initialized
INFO - 2023-08-09 18:25:19 --> Router Class Initialized
INFO - 2023-08-09 18:25:19 --> Output Class Initialized
INFO - 2023-08-09 18:25:19 --> Security Class Initialized
DEBUG - 2023-08-09 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:25:19 --> Input Class Initialized
INFO - 2023-08-09 18:25:19 --> Language Class Initialized
ERROR - 2023-08-09 18:25:19 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:25:20 --> Config Class Initialized
INFO - 2023-08-09 18:25:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:25:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:25:20 --> Utf8 Class Initialized
INFO - 2023-08-09 18:25:20 --> URI Class Initialized
INFO - 2023-08-09 18:25:20 --> Router Class Initialized
INFO - 2023-08-09 18:25:20 --> Output Class Initialized
INFO - 2023-08-09 18:25:20 --> Security Class Initialized
DEBUG - 2023-08-09 18:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:25:21 --> Input Class Initialized
INFO - 2023-08-09 18:25:21 --> Language Class Initialized
ERROR - 2023-08-09 18:25:21 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:25:21 --> Config Class Initialized
INFO - 2023-08-09 18:25:21 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:25:21 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:25:21 --> Utf8 Class Initialized
INFO - 2023-08-09 18:25:21 --> URI Class Initialized
INFO - 2023-08-09 18:25:21 --> Router Class Initialized
INFO - 2023-08-09 18:25:21 --> Output Class Initialized
INFO - 2023-08-09 18:25:21 --> Security Class Initialized
DEBUG - 2023-08-09 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:25:21 --> Input Class Initialized
INFO - 2023-08-09 18:25:21 --> Language Class Initialized
INFO - 2023-08-09 18:25:21 --> Loader Class Initialized
INFO - 2023-08-09 18:25:21 --> Helper loaded: url_helper
INFO - 2023-08-09 18:25:21 --> Helper loaded: file_helper
INFO - 2023-08-09 18:25:21 --> Database Driver Class Initialized
INFO - 2023-08-09 18:25:21 --> Email Class Initialized
DEBUG - 2023-08-09 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:25:21 --> Controller Class Initialized
INFO - 2023-08-09 18:25:21 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:25:21 --> Helper loaded: form_helper
INFO - 2023-08-09 18:25:21 --> Form Validation Class Initialized
INFO - 2023-08-09 18:25:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:25:21 --> Final output sent to browser
DEBUG - 2023-08-09 18:25:21 --> Total execution time: 0.0522
INFO - 2023-08-09 18:26:08 --> Config Class Initialized
INFO - 2023-08-09 18:26:08 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:08 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:08 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:08 --> URI Class Initialized
INFO - 2023-08-09 18:26:08 --> Router Class Initialized
INFO - 2023-08-09 18:26:08 --> Output Class Initialized
INFO - 2023-08-09 18:26:08 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:08 --> Input Class Initialized
INFO - 2023-08-09 18:26:08 --> Language Class Initialized
INFO - 2023-08-09 18:26:08 --> Loader Class Initialized
INFO - 2023-08-09 18:26:08 --> Helper loaded: url_helper
INFO - 2023-08-09 18:26:08 --> Helper loaded: file_helper
INFO - 2023-08-09 18:26:08 --> Database Driver Class Initialized
INFO - 2023-08-09 18:26:08 --> Email Class Initialized
DEBUG - 2023-08-09 18:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:26:08 --> Controller Class Initialized
INFO - 2023-08-09 18:26:08 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:26:08 --> Helper loaded: form_helper
INFO - 2023-08-09 18:26:08 --> Form Validation Class Initialized
INFO - 2023-08-09 18:26:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:26:08 --> Final output sent to browser
DEBUG - 2023-08-09 18:26:08 --> Total execution time: 0.0999
INFO - 2023-08-09 18:26:08 --> Config Class Initialized
INFO - 2023-08-09 18:26:08 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:08 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:08 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:08 --> URI Class Initialized
INFO - 2023-08-09 18:26:08 --> Router Class Initialized
INFO - 2023-08-09 18:26:08 --> Output Class Initialized
INFO - 2023-08-09 18:26:08 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:08 --> Input Class Initialized
INFO - 2023-08-09 18:26:08 --> Language Class Initialized
ERROR - 2023-08-09 18:26:08 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:26:09 --> Config Class Initialized
INFO - 2023-08-09 18:26:09 --> Config Class Initialized
INFO - 2023-08-09 18:26:09 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:09 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:09 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:09 --> URI Class Initialized
INFO - 2023-08-09 18:26:09 --> Router Class Initialized
INFO - 2023-08-09 18:26:09 --> Output Class Initialized
INFO - 2023-08-09 18:26:09 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:09 --> Input Class Initialized
INFO - 2023-08-09 18:26:09 --> Language Class Initialized
INFO - 2023-08-09 18:26:09 --> Loader Class Initialized
INFO - 2023-08-09 18:26:09 --> Helper loaded: url_helper
INFO - 2023-08-09 18:26:09 --> Helper loaded: file_helper
INFO - 2023-08-09 18:26:09 --> Database Driver Class Initialized
INFO - 2023-08-09 18:26:09 --> Email Class Initialized
DEBUG - 2023-08-09 18:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:26:09 --> Controller Class Initialized
INFO - 2023-08-09 18:26:09 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:26:09 --> Helper loaded: form_helper
INFO - 2023-08-09 18:26:09 --> Form Validation Class Initialized
INFO - 2023-08-09 18:26:09 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:26:09 --> Final output sent to browser
DEBUG - 2023-08-09 18:26:09 --> Total execution time: 0.0533
INFO - 2023-08-09 18:26:09 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:09 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:09 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:09 --> URI Class Initialized
INFO - 2023-08-09 18:26:10 --> Router Class Initialized
INFO - 2023-08-09 18:26:10 --> Output Class Initialized
INFO - 2023-08-09 18:26:10 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:10 --> Input Class Initialized
INFO - 2023-08-09 18:26:10 --> Language Class Initialized
ERROR - 2023-08-09 18:26:10 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:26:13 --> Config Class Initialized
INFO - 2023-08-09 18:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:13 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:13 --> URI Class Initialized
INFO - 2023-08-09 18:26:13 --> Router Class Initialized
INFO - 2023-08-09 18:26:13 --> Output Class Initialized
INFO - 2023-08-09 18:26:13 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:13 --> Input Class Initialized
INFO - 2023-08-09 18:26:13 --> Language Class Initialized
INFO - 2023-08-09 18:26:13 --> Loader Class Initialized
INFO - 2023-08-09 18:26:13 --> Helper loaded: url_helper
INFO - 2023-08-09 18:26:13 --> Helper loaded: file_helper
INFO - 2023-08-09 18:26:13 --> Database Driver Class Initialized
INFO - 2023-08-09 18:26:13 --> Email Class Initialized
DEBUG - 2023-08-09 18:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:26:13 --> Controller Class Initialized
INFO - 2023-08-09 18:26:13 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:26:13 --> Helper loaded: form_helper
INFO - 2023-08-09 18:26:13 --> Form Validation Class Initialized
INFO - 2023-08-09 18:26:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-09 18:26:13 --> Severity: Warning --> Undefined variable $service_id C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 112
INFO - 2023-08-09 18:26:13 --> Config Class Initialized
INFO - 2023-08-09 18:26:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:26:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:26:13 --> Utf8 Class Initialized
INFO - 2023-08-09 18:26:13 --> URI Class Initialized
INFO - 2023-08-09 18:26:13 --> Router Class Initialized
INFO - 2023-08-09 18:26:13 --> Output Class Initialized
INFO - 2023-08-09 18:26:13 --> Security Class Initialized
DEBUG - 2023-08-09 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:26:13 --> Input Class Initialized
INFO - 2023-08-09 18:26:13 --> Language Class Initialized
INFO - 2023-08-09 18:26:13 --> Loader Class Initialized
INFO - 2023-08-09 18:26:13 --> Helper loaded: url_helper
INFO - 2023-08-09 18:26:13 --> Helper loaded: file_helper
INFO - 2023-08-09 18:26:13 --> Database Driver Class Initialized
INFO - 2023-08-09 18:26:13 --> Email Class Initialized
DEBUG - 2023-08-09 18:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:26:13 --> Controller Class Initialized
INFO - 2023-08-09 18:26:13 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:26:13 --> Helper loaded: form_helper
INFO - 2023-08-09 18:26:13 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:26:13 --> Severity: error --> Exception: Too few arguments to function Services_cards::index(), 0 passed in C:\xampp\htdocs\DW\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 13
INFO - 2023-08-09 18:27:15 --> Config Class Initialized
INFO - 2023-08-09 18:27:15 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:15 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:15 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:15 --> URI Class Initialized
INFO - 2023-08-09 18:27:15 --> Router Class Initialized
INFO - 2023-08-09 18:27:15 --> Output Class Initialized
INFO - 2023-08-09 18:27:15 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:15 --> Input Class Initialized
INFO - 2023-08-09 18:27:15 --> Language Class Initialized
INFO - 2023-08-09 18:27:15 --> Loader Class Initialized
INFO - 2023-08-09 18:27:15 --> Helper loaded: url_helper
INFO - 2023-08-09 18:27:15 --> Helper loaded: file_helper
INFO - 2023-08-09 18:27:15 --> Database Driver Class Initialized
INFO - 2023-08-09 18:27:15 --> Email Class Initialized
DEBUG - 2023-08-09 18:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:27:15 --> Controller Class Initialized
INFO - 2023-08-09 18:27:15 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:27:15 --> Helper loaded: form_helper
INFO - 2023-08-09 18:27:15 --> Form Validation Class Initialized
ERROR - 2023-08-09 18:27:15 --> Severity: error --> Exception: Too few arguments to function Services_cards::index(), 0 passed in C:\xampp\htdocs\DW\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\DW\application\controllers\Admin\Services_cards.php 13
INFO - 2023-08-09 18:27:27 --> Config Class Initialized
INFO - 2023-08-09 18:27:27 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:27 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:27 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:27 --> URI Class Initialized
INFO - 2023-08-09 18:27:27 --> Router Class Initialized
INFO - 2023-08-09 18:27:27 --> Output Class Initialized
INFO - 2023-08-09 18:27:27 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:27 --> Input Class Initialized
INFO - 2023-08-09 18:27:27 --> Language Class Initialized
INFO - 2023-08-09 18:27:27 --> Loader Class Initialized
INFO - 2023-08-09 18:27:27 --> Helper loaded: url_helper
INFO - 2023-08-09 18:27:27 --> Helper loaded: file_helper
INFO - 2023-08-09 18:27:27 --> Database Driver Class Initialized
INFO - 2023-08-09 18:27:27 --> Email Class Initialized
DEBUG - 2023-08-09 18:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:27:27 --> Controller Class Initialized
INFO - 2023-08-09 18:27:27 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:27:27 --> Helper loaded: form_helper
INFO - 2023-08-09 18:27:27 --> Form Validation Class Initialized
INFO - 2023-08-09 18:27:27 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:27:28 --> Final output sent to browser
DEBUG - 2023-08-09 18:27:28 --> Total execution time: 0.0911
INFO - 2023-08-09 18:27:28 --> Config Class Initialized
INFO - 2023-08-09 18:27:28 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:28 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:28 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:28 --> URI Class Initialized
INFO - 2023-08-09 18:27:28 --> Router Class Initialized
INFO - 2023-08-09 18:27:28 --> Output Class Initialized
INFO - 2023-08-09 18:27:28 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:28 --> Input Class Initialized
INFO - 2023-08-09 18:27:28 --> Language Class Initialized
ERROR - 2023-08-09 18:27:28 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:27:29 --> Config Class Initialized
INFO - 2023-08-09 18:27:29 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:29 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:29 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:29 --> URI Class Initialized
INFO - 2023-08-09 18:27:29 --> Router Class Initialized
INFO - 2023-08-09 18:27:29 --> Output Class Initialized
INFO - 2023-08-09 18:27:29 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:29 --> Input Class Initialized
INFO - 2023-08-09 18:27:29 --> Language Class Initialized
ERROR - 2023-08-09 18:27:29 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:27:29 --> Config Class Initialized
INFO - 2023-08-09 18:27:29 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:29 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:29 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:29 --> URI Class Initialized
INFO - 2023-08-09 18:27:29 --> Router Class Initialized
INFO - 2023-08-09 18:27:29 --> Output Class Initialized
INFO - 2023-08-09 18:27:29 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:29 --> Input Class Initialized
INFO - 2023-08-09 18:27:29 --> Language Class Initialized
INFO - 2023-08-09 18:27:29 --> Loader Class Initialized
INFO - 2023-08-09 18:27:29 --> Helper loaded: url_helper
INFO - 2023-08-09 18:27:29 --> Helper loaded: file_helper
INFO - 2023-08-09 18:27:29 --> Database Driver Class Initialized
INFO - 2023-08-09 18:27:29 --> Email Class Initialized
DEBUG - 2023-08-09 18:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:27:29 --> Controller Class Initialized
INFO - 2023-08-09 18:27:29 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:27:29 --> Helper loaded: form_helper
INFO - 2023-08-09 18:27:29 --> Form Validation Class Initialized
INFO - 2023-08-09 18:27:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_edit.php
INFO - 2023-08-09 18:27:29 --> Final output sent to browser
DEBUG - 2023-08-09 18:27:29 --> Total execution time: 0.0508
INFO - 2023-08-09 18:27:39 --> Config Class Initialized
INFO - 2023-08-09 18:27:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:39 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:39 --> URI Class Initialized
INFO - 2023-08-09 18:27:39 --> Router Class Initialized
INFO - 2023-08-09 18:27:39 --> Output Class Initialized
INFO - 2023-08-09 18:27:39 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:39 --> Input Class Initialized
INFO - 2023-08-09 18:27:39 --> Language Class Initialized
INFO - 2023-08-09 18:27:39 --> Loader Class Initialized
INFO - 2023-08-09 18:27:39 --> Helper loaded: url_helper
INFO - 2023-08-09 18:27:39 --> Helper loaded: file_helper
INFO - 2023-08-09 18:27:39 --> Database Driver Class Initialized
INFO - 2023-08-09 18:27:39 --> Email Class Initialized
DEBUG - 2023-08-09 18:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:27:39 --> Controller Class Initialized
INFO - 2023-08-09 18:27:39 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:27:39 --> Helper loaded: form_helper
INFO - 2023-08-09 18:27:39 --> Form Validation Class Initialized
INFO - 2023-08-09 18:27:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 18:27:39 --> Config Class Initialized
INFO - 2023-08-09 18:27:39 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:39 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:39 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:39 --> URI Class Initialized
INFO - 2023-08-09 18:27:39 --> Router Class Initialized
INFO - 2023-08-09 18:27:39 --> Output Class Initialized
INFO - 2023-08-09 18:27:39 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:39 --> Input Class Initialized
INFO - 2023-08-09 18:27:39 --> Language Class Initialized
INFO - 2023-08-09 18:27:39 --> Loader Class Initialized
INFO - 2023-08-09 18:27:39 --> Helper loaded: url_helper
INFO - 2023-08-09 18:27:39 --> Helper loaded: file_helper
INFO - 2023-08-09 18:27:39 --> Database Driver Class Initialized
INFO - 2023-08-09 18:27:39 --> Email Class Initialized
DEBUG - 2023-08-09 18:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:27:39 --> Controller Class Initialized
INFO - 2023-08-09 18:27:39 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:27:39 --> Helper loaded: form_helper
INFO - 2023-08-09 18:27:39 --> Form Validation Class Initialized
INFO - 2023-08-09 18:27:39 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:27:39 --> Final output sent to browser
DEBUG - 2023-08-09 18:27:39 --> Total execution time: 0.0524
INFO - 2023-08-09 18:27:40 --> Config Class Initialized
INFO - 2023-08-09 18:27:40 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:40 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:40 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:41 --> URI Class Initialized
INFO - 2023-08-09 18:27:41 --> Router Class Initialized
INFO - 2023-08-09 18:27:41 --> Output Class Initialized
INFO - 2023-08-09 18:27:41 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:41 --> Input Class Initialized
INFO - 2023-08-09 18:27:41 --> Language Class Initialized
ERROR - 2023-08-09 18:27:41 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:27:41 --> Config Class Initialized
INFO - 2023-08-09 18:27:41 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:27:41 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:27:41 --> Utf8 Class Initialized
INFO - 2023-08-09 18:27:41 --> URI Class Initialized
INFO - 2023-08-09 18:27:41 --> Router Class Initialized
INFO - 2023-08-09 18:27:41 --> Output Class Initialized
INFO - 2023-08-09 18:27:41 --> Security Class Initialized
DEBUG - 2023-08-09 18:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:27:41 --> Input Class Initialized
INFO - 2023-08-09 18:27:41 --> Language Class Initialized
ERROR - 2023-08-09 18:27:41 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:05 --> Config Class Initialized
INFO - 2023-08-09 18:28:05 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:05 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:05 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:05 --> URI Class Initialized
INFO - 2023-08-09 18:28:05 --> Router Class Initialized
INFO - 2023-08-09 18:28:05 --> Output Class Initialized
INFO - 2023-08-09 18:28:05 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:05 --> Input Class Initialized
INFO - 2023-08-09 18:28:05 --> Language Class Initialized
INFO - 2023-08-09 18:28:05 --> Loader Class Initialized
INFO - 2023-08-09 18:28:05 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:05 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:05 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:05 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:05 --> Controller Class Initialized
INFO - 2023-08-09 18:28:05 --> Model "Services_model" initialized
INFO - 2023-08-09 18:28:05 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:05 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:28:05 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:05 --> Total execution time: 0.0733
INFO - 2023-08-09 18:28:06 --> Config Class Initialized
INFO - 2023-08-09 18:28:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:06 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:06 --> URI Class Initialized
INFO - 2023-08-09 18:28:06 --> Router Class Initialized
INFO - 2023-08-09 18:28:06 --> Output Class Initialized
INFO - 2023-08-09 18:28:06 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:06 --> Input Class Initialized
INFO - 2023-08-09 18:28:06 --> Language Class Initialized
ERROR - 2023-08-09 18:28:06 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 18:28:06 --> Config Class Initialized
INFO - 2023-08-09 18:28:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:06 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:06 --> URI Class Initialized
INFO - 2023-08-09 18:28:06 --> Router Class Initialized
INFO - 2023-08-09 18:28:06 --> Output Class Initialized
INFO - 2023-08-09 18:28:06 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:06 --> Input Class Initialized
INFO - 2023-08-09 18:28:06 --> Language Class Initialized
ERROR - 2023-08-09 18:28:06 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:06 --> Config Class Initialized
INFO - 2023-08-09 18:28:06 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:06 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:06 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:06 --> URI Class Initialized
INFO - 2023-08-09 18:28:06 --> Router Class Initialized
INFO - 2023-08-09 18:28:06 --> Output Class Initialized
INFO - 2023-08-09 18:28:06 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:06 --> Input Class Initialized
INFO - 2023-08-09 18:28:06 --> Language Class Initialized
ERROR - 2023-08-09 18:28:06 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:16 --> Config Class Initialized
INFO - 2023-08-09 18:28:16 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:16 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:16 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:16 --> URI Class Initialized
INFO - 2023-08-09 18:28:16 --> Router Class Initialized
INFO - 2023-08-09 18:28:16 --> Output Class Initialized
INFO - 2023-08-09 18:28:16 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:16 --> Input Class Initialized
INFO - 2023-08-09 18:28:16 --> Language Class Initialized
INFO - 2023-08-09 18:28:16 --> Loader Class Initialized
INFO - 2023-08-09 18:28:16 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:16 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:16 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:16 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:16 --> Controller Class Initialized
INFO - 2023-08-09 18:28:16 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:16 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:16 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:28:16 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:16 --> Total execution time: 0.0567
INFO - 2023-08-09 18:28:17 --> Config Class Initialized
INFO - 2023-08-09 18:28:17 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:17 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:17 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:17 --> URI Class Initialized
INFO - 2023-08-09 18:28:17 --> Router Class Initialized
INFO - 2023-08-09 18:28:17 --> Output Class Initialized
INFO - 2023-08-09 18:28:17 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:17 --> Input Class Initialized
INFO - 2023-08-09 18:28:17 --> Language Class Initialized
ERROR - 2023-08-09 18:28:17 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:17 --> Config Class Initialized
INFO - 2023-08-09 18:28:17 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:17 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:17 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:17 --> URI Class Initialized
INFO - 2023-08-09 18:28:17 --> Router Class Initialized
INFO - 2023-08-09 18:28:17 --> Output Class Initialized
INFO - 2023-08-09 18:28:17 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:17 --> Input Class Initialized
INFO - 2023-08-09 18:28:17 --> Language Class Initialized
ERROR - 2023-08-09 18:28:17 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:20 --> Config Class Initialized
INFO - 2023-08-09 18:28:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:20 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:20 --> URI Class Initialized
INFO - 2023-08-09 18:28:20 --> Router Class Initialized
INFO - 2023-08-09 18:28:20 --> Output Class Initialized
INFO - 2023-08-09 18:28:20 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:20 --> Input Class Initialized
INFO - 2023-08-09 18:28:20 --> Language Class Initialized
INFO - 2023-08-09 18:28:20 --> Loader Class Initialized
INFO - 2023-08-09 18:28:20 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:20 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:20 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:20 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:20 --> Controller Class Initialized
INFO - 2023-08-09 18:28:20 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:20 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:20 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:28:20 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:20 --> Total execution time: 0.0478
INFO - 2023-08-09 18:28:20 --> Config Class Initialized
INFO - 2023-08-09 18:28:20 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:20 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:20 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:20 --> URI Class Initialized
INFO - 2023-08-09 18:28:20 --> Router Class Initialized
INFO - 2023-08-09 18:28:20 --> Output Class Initialized
INFO - 2023-08-09 18:28:20 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:20 --> Input Class Initialized
INFO - 2023-08-09 18:28:20 --> Language Class Initialized
ERROR - 2023-08-09 18:28:20 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:21 --> Config Class Initialized
INFO - 2023-08-09 18:28:21 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:21 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:21 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:21 --> URI Class Initialized
INFO - 2023-08-09 18:28:21 --> Router Class Initialized
INFO - 2023-08-09 18:28:21 --> Output Class Initialized
INFO - 2023-08-09 18:28:21 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:21 --> Input Class Initialized
INFO - 2023-08-09 18:28:21 --> Language Class Initialized
ERROR - 2023-08-09 18:28:21 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:21 --> Config Class Initialized
INFO - 2023-08-09 18:28:21 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:21 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:21 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:21 --> URI Class Initialized
INFO - 2023-08-09 18:28:21 --> Router Class Initialized
INFO - 2023-08-09 18:28:21 --> Output Class Initialized
INFO - 2023-08-09 18:28:21 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:21 --> Input Class Initialized
INFO - 2023-08-09 18:28:21 --> Language Class Initialized
INFO - 2023-08-09 18:28:21 --> Loader Class Initialized
INFO - 2023-08-09 18:28:21 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:21 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:21 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:21 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:21 --> Controller Class Initialized
INFO - 2023-08-09 18:28:21 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:21 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:21 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:21 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:28:21 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:21 --> Total execution time: 0.0470
INFO - 2023-08-09 18:28:34 --> Config Class Initialized
INFO - 2023-08-09 18:28:34 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:34 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:34 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:34 --> URI Class Initialized
INFO - 2023-08-09 18:28:34 --> Router Class Initialized
INFO - 2023-08-09 18:28:34 --> Output Class Initialized
INFO - 2023-08-09 18:28:34 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:34 --> Input Class Initialized
INFO - 2023-08-09 18:28:34 --> Language Class Initialized
INFO - 2023-08-09 18:28:34 --> Loader Class Initialized
INFO - 2023-08-09 18:28:34 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:34 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:34 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:34 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:34 --> Controller Class Initialized
INFO - 2023-08-09 18:28:34 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:34 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:34 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-09 18:28:34 --> Config Class Initialized
INFO - 2023-08-09 18:28:34 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:34 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:34 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:34 --> URI Class Initialized
INFO - 2023-08-09 18:28:34 --> Router Class Initialized
INFO - 2023-08-09 18:28:34 --> Output Class Initialized
INFO - 2023-08-09 18:28:34 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:34 --> Input Class Initialized
INFO - 2023-08-09 18:28:34 --> Language Class Initialized
INFO - 2023-08-09 18:28:34 --> Loader Class Initialized
INFO - 2023-08-09 18:28:34 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:34 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:34 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:34 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:35 --> Controller Class Initialized
INFO - 2023-08-09 18:28:35 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:35 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:35 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:35 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:28:35 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:35 --> Total execution time: 0.0690
INFO - 2023-08-09 18:28:35 --> Config Class Initialized
INFO - 2023-08-09 18:28:35 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:35 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:35 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:35 --> URI Class Initialized
INFO - 2023-08-09 18:28:35 --> Router Class Initialized
INFO - 2023-08-09 18:28:35 --> Output Class Initialized
INFO - 2023-08-09 18:28:35 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:35 --> Input Class Initialized
INFO - 2023-08-09 18:28:35 --> Language Class Initialized
ERROR - 2023-08-09 18:28:35 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:36 --> Config Class Initialized
INFO - 2023-08-09 18:28:36 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:36 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:36 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:36 --> URI Class Initialized
INFO - 2023-08-09 18:28:36 --> Router Class Initialized
INFO - 2023-08-09 18:28:36 --> Output Class Initialized
INFO - 2023-08-09 18:28:36 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:36 --> Input Class Initialized
INFO - 2023-08-09 18:28:36 --> Language Class Initialized
ERROR - 2023-08-09 18:28:36 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:46 --> Config Class Initialized
INFO - 2023-08-09 18:28:46 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:46 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:46 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:46 --> URI Class Initialized
INFO - 2023-08-09 18:28:46 --> Router Class Initialized
INFO - 2023-08-09 18:28:46 --> Output Class Initialized
INFO - 2023-08-09 18:28:46 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:46 --> Input Class Initialized
INFO - 2023-08-09 18:28:46 --> Language Class Initialized
INFO - 2023-08-09 18:28:46 --> Loader Class Initialized
INFO - 2023-08-09 18:28:46 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:46 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:46 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:46 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:46 --> Controller Class Initialized
INFO - 2023-08-09 18:28:46 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:46 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:46 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:28:46 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:46 --> Total execution time: 0.0778
INFO - 2023-08-09 18:28:47 --> Config Class Initialized
INFO - 2023-08-09 18:28:47 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:47 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:47 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:47 --> URI Class Initialized
INFO - 2023-08-09 18:28:47 --> Router Class Initialized
INFO - 2023-08-09 18:28:47 --> Output Class Initialized
INFO - 2023-08-09 18:28:47 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:47 --> Input Class Initialized
INFO - 2023-08-09 18:28:47 --> Language Class Initialized
ERROR - 2023-08-09 18:28:47 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:48 --> Config Class Initialized
INFO - 2023-08-09 18:28:48 --> Config Class Initialized
INFO - 2023-08-09 18:28:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:48 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:48 --> URI Class Initialized
INFO - 2023-08-09 18:28:48 --> Router Class Initialized
INFO - 2023-08-09 18:28:48 --> Output Class Initialized
INFO - 2023-08-09 18:28:48 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:48 --> Input Class Initialized
INFO - 2023-08-09 18:28:48 --> Language Class Initialized
INFO - 2023-08-09 18:28:48 --> Loader Class Initialized
INFO - 2023-08-09 18:28:48 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:48 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:48 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:48 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:48 --> Controller Class Initialized
INFO - 2023-08-09 18:28:48 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:48 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:48 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_list.php
INFO - 2023-08-09 18:28:48 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:48 --> Total execution time: 0.7120
INFO - 2023-08-09 18:28:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:48 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:48 --> URI Class Initialized
INFO - 2023-08-09 18:28:48 --> Router Class Initialized
INFO - 2023-08-09 18:28:48 --> Output Class Initialized
INFO - 2023-08-09 18:28:48 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:48 --> Input Class Initialized
INFO - 2023-08-09 18:28:48 --> Language Class Initialized
ERROR - 2023-08-09 18:28:48 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:48 --> Config Class Initialized
INFO - 2023-08-09 18:28:48 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:48 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:48 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:48 --> URI Class Initialized
INFO - 2023-08-09 18:28:48 --> Router Class Initialized
INFO - 2023-08-09 18:28:48 --> Output Class Initialized
INFO - 2023-08-09 18:28:48 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:48 --> Input Class Initialized
INFO - 2023-08-09 18:28:48 --> Language Class Initialized
INFO - 2023-08-09 18:28:48 --> Loader Class Initialized
INFO - 2023-08-09 18:28:48 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:48 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:48 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:48 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:48 --> Controller Class Initialized
INFO - 2023-08-09 18:28:48 --> Model "Services_cards_model" initialized
INFO - 2023-08-09 18:28:48 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:48 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_cards_create.php
INFO - 2023-08-09 18:28:48 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:48 --> Total execution time: 0.4351
INFO - 2023-08-09 18:28:49 --> Config Class Initialized
INFO - 2023-08-09 18:28:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:49 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:49 --> URI Class Initialized
INFO - 2023-08-09 18:28:49 --> Router Class Initialized
INFO - 2023-08-09 18:28:49 --> Output Class Initialized
INFO - 2023-08-09 18:28:49 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:49 --> Input Class Initialized
INFO - 2023-08-09 18:28:49 --> Language Class Initialized
ERROR - 2023-08-09 18:28:49 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:49 --> Config Class Initialized
INFO - 2023-08-09 18:28:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:49 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:49 --> URI Class Initialized
INFO - 2023-08-09 18:28:49 --> Router Class Initialized
INFO - 2023-08-09 18:28:49 --> Output Class Initialized
INFO - 2023-08-09 18:28:49 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:49 --> Input Class Initialized
INFO - 2023-08-09 18:28:49 --> Language Class Initialized
ERROR - 2023-08-09 18:28:49 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:49 --> Config Class Initialized
INFO - 2023-08-09 18:28:49 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:49 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:49 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:49 --> URI Class Initialized
INFO - 2023-08-09 18:28:49 --> Router Class Initialized
INFO - 2023-08-09 18:28:49 --> Output Class Initialized
INFO - 2023-08-09 18:28:49 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:49 --> Input Class Initialized
INFO - 2023-08-09 18:28:49 --> Language Class Initialized
INFO - 2023-08-09 18:28:49 --> Loader Class Initialized
INFO - 2023-08-09 18:28:50 --> Helper loaded: url_helper
INFO - 2023-08-09 18:28:50 --> Helper loaded: file_helper
INFO - 2023-08-09 18:28:50 --> Database Driver Class Initialized
INFO - 2023-08-09 18:28:50 --> Email Class Initialized
DEBUG - 2023-08-09 18:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:28:50 --> Controller Class Initialized
INFO - 2023-08-09 18:28:50 --> Model "Services_model" initialized
INFO - 2023-08-09 18:28:50 --> Helper loaded: form_helper
INFO - 2023-08-09 18:28:50 --> Form Validation Class Initialized
INFO - 2023-08-09 18:28:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:28:50 --> Final output sent to browser
DEBUG - 2023-08-09 18:28:50 --> Total execution time: 1.0703
INFO - 2023-08-09 18:28:50 --> Config Class Initialized
INFO - 2023-08-09 18:28:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:50 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:50 --> URI Class Initialized
INFO - 2023-08-09 18:28:50 --> Router Class Initialized
INFO - 2023-08-09 18:28:50 --> Output Class Initialized
INFO - 2023-08-09 18:28:50 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:50 --> Input Class Initialized
INFO - 2023-08-09 18:28:50 --> Language Class Initialized
ERROR - 2023-08-09 18:28:50 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:28:50 --> Config Class Initialized
INFO - 2023-08-09 18:28:50 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:28:50 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:28:50 --> Utf8 Class Initialized
INFO - 2023-08-09 18:28:50 --> URI Class Initialized
INFO - 2023-08-09 18:28:50 --> Router Class Initialized
INFO - 2023-08-09 18:28:50 --> Output Class Initialized
INFO - 2023-08-09 18:28:50 --> Security Class Initialized
DEBUG - 2023-08-09 18:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:28:50 --> Input Class Initialized
INFO - 2023-08-09 18:28:50 --> Language Class Initialized
ERROR - 2023-08-09 18:28:50 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:03 --> Config Class Initialized
INFO - 2023-08-09 18:29:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:03 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:03 --> URI Class Initialized
INFO - 2023-08-09 18:29:03 --> Router Class Initialized
INFO - 2023-08-09 18:29:03 --> Output Class Initialized
INFO - 2023-08-09 18:29:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:03 --> Input Class Initialized
INFO - 2023-08-09 18:29:03 --> Language Class Initialized
INFO - 2023-08-09 18:29:03 --> Loader Class Initialized
INFO - 2023-08-09 18:29:03 --> Helper loaded: url_helper
INFO - 2023-08-09 18:29:03 --> Helper loaded: file_helper
INFO - 2023-08-09 18:29:03 --> Database Driver Class Initialized
INFO - 2023-08-09 18:29:03 --> Email Class Initialized
DEBUG - 2023-08-09 18:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:29:03 --> Controller Class Initialized
INFO - 2023-08-09 18:29:03 --> Model "Services_model" initialized
INFO - 2023-08-09 18:29:03 --> Helper loaded: form_helper
INFO - 2023-08-09 18:29:03 --> Form Validation Class Initialized
INFO - 2023-08-09 18:29:03 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/services_list.php
INFO - 2023-08-09 18:29:03 --> Final output sent to browser
DEBUG - 2023-08-09 18:29:03 --> Total execution time: 0.0517
INFO - 2023-08-09 18:29:03 --> Config Class Initialized
INFO - 2023-08-09 18:29:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:03 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:03 --> URI Class Initialized
INFO - 2023-08-09 18:29:03 --> Router Class Initialized
INFO - 2023-08-09 18:29:03 --> Output Class Initialized
INFO - 2023-08-09 18:29:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:03 --> Input Class Initialized
INFO - 2023-08-09 18:29:03 --> Language Class Initialized
ERROR - 2023-08-09 18:29:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-09 18:29:03 --> Config Class Initialized
INFO - 2023-08-09 18:29:03 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:03 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:03 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:03 --> URI Class Initialized
INFO - 2023-08-09 18:29:03 --> Router Class Initialized
INFO - 2023-08-09 18:29:03 --> Output Class Initialized
INFO - 2023-08-09 18:29:03 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:03 --> Input Class Initialized
INFO - 2023-08-09 18:29:03 --> Language Class Initialized
ERROR - 2023-08-09 18:29:03 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:04 --> Config Class Initialized
INFO - 2023-08-09 18:29:04 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:04 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:04 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:04 --> URI Class Initialized
INFO - 2023-08-09 18:29:04 --> Router Class Initialized
INFO - 2023-08-09 18:29:04 --> Output Class Initialized
INFO - 2023-08-09 18:29:04 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:04 --> Input Class Initialized
INFO - 2023-08-09 18:29:04 --> Language Class Initialized
ERROR - 2023-08-09 18:29:04 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:08 --> Config Class Initialized
INFO - 2023-08-09 18:29:08 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:08 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:08 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:08 --> URI Class Initialized
INFO - 2023-08-09 18:29:08 --> Router Class Initialized
INFO - 2023-08-09 18:29:08 --> Output Class Initialized
INFO - 2023-08-09 18:29:08 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:08 --> Input Class Initialized
INFO - 2023-08-09 18:29:08 --> Language Class Initialized
INFO - 2023-08-09 18:29:08 --> Loader Class Initialized
INFO - 2023-08-09 18:29:08 --> Helper loaded: url_helper
INFO - 2023-08-09 18:29:08 --> Helper loaded: file_helper
INFO - 2023-08-09 18:29:08 --> Database Driver Class Initialized
INFO - 2023-08-09 18:29:08 --> Email Class Initialized
DEBUG - 2023-08-09 18:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:29:08 --> Controller Class Initialized
INFO - 2023-08-09 18:29:08 --> Model "Training_model" initialized
INFO - 2023-08-09 18:29:08 --> Helper loaded: form_helper
INFO - 2023-08-09 18:29:08 --> Form Validation Class Initialized
INFO - 2023-08-09 18:29:08 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/training_list.php
INFO - 2023-08-09 18:29:08 --> Final output sent to browser
DEBUG - 2023-08-09 18:29:08 --> Total execution time: 0.0562
INFO - 2023-08-09 18:29:09 --> Config Class Initialized
INFO - 2023-08-09 18:29:09 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:09 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:09 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:09 --> URI Class Initialized
INFO - 2023-08-09 18:29:09 --> Router Class Initialized
INFO - 2023-08-09 18:29:09 --> Output Class Initialized
INFO - 2023-08-09 18:29:09 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:09 --> Input Class Initialized
INFO - 2023-08-09 18:29:09 --> Language Class Initialized
ERROR - 2023-08-09 18:29:09 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:09 --> Config Class Initialized
INFO - 2023-08-09 18:29:09 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:09 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:09 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:09 --> URI Class Initialized
INFO - 2023-08-09 18:29:09 --> Router Class Initialized
INFO - 2023-08-09 18:29:09 --> Output Class Initialized
INFO - 2023-08-09 18:29:09 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:09 --> Input Class Initialized
INFO - 2023-08-09 18:29:09 --> Language Class Initialized
ERROR - 2023-08-09 18:29:09 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:11 --> Config Class Initialized
INFO - 2023-08-09 18:29:11 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:11 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:11 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:11 --> URI Class Initialized
INFO - 2023-08-09 18:29:11 --> Router Class Initialized
INFO - 2023-08-09 18:29:11 --> Output Class Initialized
INFO - 2023-08-09 18:29:11 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:11 --> Input Class Initialized
INFO - 2023-08-09 18:29:11 --> Language Class Initialized
INFO - 2023-08-09 18:29:11 --> Loader Class Initialized
INFO - 2023-08-09 18:29:11 --> Helper loaded: url_helper
INFO - 2023-08-09 18:29:11 --> Helper loaded: file_helper
INFO - 2023-08-09 18:29:11 --> Database Driver Class Initialized
INFO - 2023-08-09 18:29:12 --> Email Class Initialized
DEBUG - 2023-08-09 18:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-09 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-09 18:29:12 --> Controller Class Initialized
INFO - 2023-08-09 18:29:12 --> Model "Faq_model" initialized
INFO - 2023-08-09 18:29:12 --> Helper loaded: form_helper
INFO - 2023-08-09 18:29:12 --> Form Validation Class Initialized
INFO - 2023-08-09 18:29:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-09 18:29:12 --> Final output sent to browser
DEBUG - 2023-08-09 18:29:12 --> Total execution time: 0.0923
INFO - 2023-08-09 18:29:12 --> Config Class Initialized
INFO - 2023-08-09 18:29:12 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:12 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:12 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:12 --> URI Class Initialized
INFO - 2023-08-09 18:29:12 --> Router Class Initialized
INFO - 2023-08-09 18:29:12 --> Output Class Initialized
INFO - 2023-08-09 18:29:12 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:12 --> Input Class Initialized
INFO - 2023-08-09 18:29:12 --> Language Class Initialized
ERROR - 2023-08-09 18:29:12 --> 404 Page Not Found: Assets/admin
INFO - 2023-08-09 18:29:13 --> Config Class Initialized
INFO - 2023-08-09 18:29:13 --> Hooks Class Initialized
DEBUG - 2023-08-09 18:29:13 --> UTF-8 Support Enabled
INFO - 2023-08-09 18:29:13 --> Utf8 Class Initialized
INFO - 2023-08-09 18:29:13 --> URI Class Initialized
INFO - 2023-08-09 18:29:13 --> Router Class Initialized
INFO - 2023-08-09 18:29:13 --> Output Class Initialized
INFO - 2023-08-09 18:29:13 --> Security Class Initialized
DEBUG - 2023-08-09 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-09 18:29:13 --> Input Class Initialized
INFO - 2023-08-09 18:29:13 --> Language Class Initialized
ERROR - 2023-08-09 18:29:13 --> 404 Page Not Found: Assets/admin
