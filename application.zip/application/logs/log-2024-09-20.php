<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-20 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 08:08:38 --> No URI present. Default controller set.
DEBUG - 2024-09-20 08:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-20 08:08:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'dw' C:\xampp\htdocs\dw\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-09-20 08:08:38 --> Unable to connect to the database
