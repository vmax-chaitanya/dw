<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.2233
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.0908
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.1259
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.1646
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.1720
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:24 --> Total execution time: 0.2134
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2538
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2253
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2345
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2498
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2183
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2631
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2659
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2599
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2633
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2662
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2685
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2856
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2903
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.3063
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.3048
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.3001
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2992
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2881
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2766
DEBUG - 2024-11-09 10:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:25 --> Total execution time: 0.2856
DEBUG - 2024-11-09 10:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 10:37:26 --> UTF-8 Support Enabled
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 10:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3120
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 10:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3276
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3286
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3318
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3269
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 15:07:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 15:07:26 --> Total execution time: 0.3032
DEBUG - 2024-11-09 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2285
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.1470
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2148
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.1506
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2144
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2185
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2335
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2487
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.3082
DEBUG - 2024-11-09 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 11:34:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 11:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:51 --> Total execution time: 0.2595
DEBUG - 2024-11-09 11:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:52 --> Total execution time: 0.3203
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:52 --> Total execution time: 0.3537
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:52 --> Total execution time: 0.3450
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:52 --> Total execution time: 0.4069
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:04:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:04:52 --> Total execution time: 0.4293
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.1982
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.2127
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.2759
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.3633
DEBUG - 2024-11-09 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.4520
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.1828
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 16:32:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 16:32:01 --> Total execution time: 0.2607
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:18 --> Total execution time: 0.2141
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:18 --> Total execution time: 0.2114
DEBUG - 2024-11-09 12:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.3031
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.3605
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4301
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4594
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.5271
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4661
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4151
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:33:19 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.3099
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.3794
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4516
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.4235
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:19 --> Total execution time: 0.3513
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:03:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:03:20 --> Total execution time: 0.4295
DEBUG - 2024-11-09 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:47 --> Total execution time: 0.2033
DEBUG - 2024-11-09 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:34:47 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:47 --> Total execution time: 0.1842
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:47 --> Total execution time: 0.1900
DEBUG - 2024-11-09 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:47 --> Total execution time: 0.2142
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:47 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3160
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3382
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.2396
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3194
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3547
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:34:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3996
DEBUG - 2024-11-09 12:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.4485
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.2977
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.3751
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.4252
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:04:48 --> Total execution time: 0.4096
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:50 --> Total execution time: 0.1907
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:50 --> Total execution time: 0.2034
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:50 --> Total execution time: 0.2372
DEBUG - 2024-11-09 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:50 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:50 --> Total execution time: 0.3650
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4424
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.5406
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.6260
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.5367
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.5149
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:35:51 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.3442
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4224
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4930
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4961
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4528
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:05:51 --> Total execution time: 0.4787
DEBUG - 2024-11-09 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:22 --> Total execution time: 0.1779
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:22 --> Total execution time: 0.2454
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:22 --> Total execution time: 0.2584
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:22 --> Total execution time: 0.3575
DEBUG - 2024-11-09 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:22 --> Total execution time: 0.4106
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:36:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3649
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3159
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3786
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3361
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3841
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.4701
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.3736
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.4673
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.4801
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:23 --> Total execution time: 0.4795
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.1722
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.1868
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.1996
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.2812
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.3579
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.4297
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:42 --> Total execution time: 0.5080
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:42 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.4291
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.4044
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:43 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3881
DEBUG - 2024-11-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3257
DEBUG - 2024-11-09 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3983
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3953
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3419
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:43 --> Total execution time: 0.3749
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:53 --> Total execution time: 0.1848
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:36:53 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:53 --> Total execution time: 0.2644
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:53 --> Total execution time: 0.3542
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:54 --> Total execution time: 0.4267
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:54 --> Total execution time: 0.5068
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:54 --> Total execution time: 0.4300
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:06:54 --> Total execution time: 0.4892
DEBUG - 2024-11-09 12:38:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:21 --> Total execution time: 0.1586
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.2012
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.2978
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.3277
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.3815
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.3523
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.3734
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.4619
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.3906
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:22 --> Total execution time: 0.4619
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:22 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:22 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4461
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4445
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4477
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4198
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4156
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4245
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4300
DEBUG - 2024-11-09 12:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4451
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.3856
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4741
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4465
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:23 --> Total execution time: 0.4096
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:30 --> Total execution time: 0.1775
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:38:30 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:30 --> Total execution time: 0.2432
DEBUG - 2024-11-09 12:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:30 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:31 --> Total execution time: 0.3187
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:31 --> Total execution time: 0.4035
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:31 --> Total execution time: 0.4929
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:31 --> Total execution time: 0.5501
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:31 --> Total execution time: 0.5000
DEBUG - 2024-11-09 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:55 --> Total execution time: 0.2385
DEBUG - 2024-11-09 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.1876
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.2586
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.3024
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.3511
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.3160
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.3827
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.4048
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.5168
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.5168
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:56 --> Total execution time: 0.4954
DEBUG - 2024-11-09 12:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.5224
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:38:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.5372
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.5259
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:38:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4459
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4535
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4394
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4144
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4257
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:38:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.4297
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.1334
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:08:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:08:57 --> Total execution time: 0.2063
DEBUG - 2024-11-09 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:06 --> Total execution time: 0.1763
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:06 --> Total execution time: 0.2513
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:06 --> Total execution time: 0.3444
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:06 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:07 --> Total execution time: 0.4299
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:39:07 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:07 --> Total execution time: 0.5145
DEBUG - 2024-11-09 12:39:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:07 --> Total execution time: 0.1898
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:09:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:09:07 --> Total execution time: 0.2247
DEBUG - 2024-11-09 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:56 --> Total execution time: 0.1883
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:56 --> Total execution time: 0.2325
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:56 --> Total execution time: 0.3080
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:56 --> Total execution time: 0.2913
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:56 --> Total execution time: 0.3737
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.4209
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3992
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.4406
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3040
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:44:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3417
DEBUG - 2024-11-09 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.4245
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.2821
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3491
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3916
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:14:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:14:57 --> Total execution time: 0.3950
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:11 --> Total execution time: 0.1935
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:11 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:11 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.2131
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.2977
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3042
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3796
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3962
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.2158
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.2619
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3173
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:46:12 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3519
DEBUG - 2024-11-09 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3289
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3739
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3900
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.3866
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:12 --> Total execution time: 0.4016
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:53 --> Total execution time: 0.1468
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.1776
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.2391
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.3030
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.3633
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.4329
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.5533
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.4257
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.4176
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.3657
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.4261
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.3556
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.2527
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:54 --> Total execution time: 0.3319
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:16:54 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:16:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:16:55 --> Total execution time: 0.3909
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.1492
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:16 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.2095
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.2729
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.3344
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.4017
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.3306
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:16 --> Total execution time: 0.3768
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:57 --> Total execution time: 0.1886
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:57 --> Total execution time: 0.1679
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:57 --> Total execution time: 0.2346
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:57 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.2868
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.3463
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.3677
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4103
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4568
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4678
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4562
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4723
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4784
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4857
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4728
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4687
DEBUG - 2024-11-09 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:47:58 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:58 --> Total execution time: 0.4599
DEBUG - 2024-11-09 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:59 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:47:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4676
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4529
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4442
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4399
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4337
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:17:59 --> Total execution time: 0.4217
DEBUG - 2024-11-09 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.1284
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.1537
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.1770
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.2272
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.3143
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.3975
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.5135
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.4636
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.4340
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:50:48 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:48 --> Total execution time: 0.4751
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:48 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4615
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4159
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4107
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4278
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4261
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4051
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:50:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4123
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4133
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.4091
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.3897
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.3633
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:20:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:20:49 --> Total execution time: 0.3994
DEBUG - 2024-11-09 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:21:59 --> Total execution time: 0.2209
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.2448
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.2844
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.2972
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.3667
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.3673
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.3581
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.4092
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.3014
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:00 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.3279
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:00 --> Total execution time: 0.4096
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:00 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:01 --> Total execution time: 0.2938
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:01 --> Total execution time: 0.3775
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:01 --> Total execution time: 0.4167
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:01 --> Total execution time: 0.4162
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.1553
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.2414
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.2502
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.3375
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.4204
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:24 --> Total execution time: 0.4904
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:52:24 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:24 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.5571
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:52:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.4423
DEBUG - 2024-11-09 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:52:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.4080
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:52:25 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.3837
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.2850
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.3478
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.3501
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.3607
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:22:25 --> Total execution time: 0.3613
DEBUG - 2024-11-09 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:25:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:25:53 --> Total execution time: 0.1957
DEBUG - 2024-11-09 12:56:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:48 --> Total execution time: 0.1762
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.2029
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.2779
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.3681
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.4062
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.5200
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.5185
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.4075
DEBUG - 2024-11-09 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.2259
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:49 --> Total execution time: 0.2563
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:49 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:50 --> Total execution time: 0.3117
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:50 --> Total execution time: 0.3481
DEBUG - 2024-11-09 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:50 --> Total execution time: 0.1577
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:50 --> Total execution time: 0.2024
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:26:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:26:50 --> Total execution time: 0.2549
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:03 --> Total execution time: 0.1641
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 17:29:03 --> Total execution time: 0.1859
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:03 --> Total execution time: 0.1921
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:03 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:59:03 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.2526
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.3279
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.3999
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.4848
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.4177
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.4034
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.4058
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-09 12:59:04 --> UTF-8 Support Enabled
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-09 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.2882
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
DEBUG - 2024-11-09 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.3639
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.4020
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.2792
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_description C:\xampp\htdocs\dw\application\views\home\includes\styles.php 2
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $meta_keywords C:\xampp\htdocs\dw\application\views\home\includes\styles.php 3
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $page_title C:\xampp\htdocs\dw\application\views\home\includes\styles.php 7
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 40
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 66
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $captcha_image C:\xampp\htdocs\dw\application\views\home\includes\footer.php 42
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
ERROR - 2024-11-09 17:29:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 175
DEBUG - 2024-11-09 17:29:04 --> Total execution time: 0.3482
