<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-05-01 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:32:27 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:02:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:02:28 --> Total execution time: 2.1406
DEBUG - 2024-05-01 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:44:15 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:14:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:14:15 --> Total execution time: 0.0986
DEBUG - 2024-05-01 10:45:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:45:38 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:15:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:15:38 --> Total execution time: 0.1443
DEBUG - 2024-05-01 10:46:31 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:46:31 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:16:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:16:31 --> Total execution time: 0.1240
DEBUG - 2024-05-01 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:46:39 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:16:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:16:39 --> Total execution time: 0.0757
DEBUG - 2024-05-01 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:48:37 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:18:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:18:37 --> Total execution time: 0.0788
DEBUG - 2024-05-01 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:48:43 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:18:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:18:43 --> Total execution time: 0.1388
DEBUG - 2024-05-01 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:51:00 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:21:00 --> Total execution time: 0.1195
DEBUG - 2024-05-01 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:51:55 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> Undefined array key "grid" C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 261
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:21:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:21:55 --> Total execution time: 0.1123
DEBUG - 2024-05-01 10:51:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:51:58 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> Undefined array key "grid" C:\xampp\htdocs\dw\system\helpers\captcha_helper.php 261
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:21:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:21:59 --> Total execution time: 0.1356
DEBUG - 2024-05-01 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:52:25 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:22:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:22:25 --> Total execution time: 0.1531
DEBUG - 2024-05-01 10:52:52 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:52:52 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:22:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:22:52 --> Total execution time: 0.1283
DEBUG - 2024-05-01 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:52:57 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:22:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:22:57 --> Total execution time: 0.1285
DEBUG - 2024-05-01 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-01 14:23:01 --> Total execution time: 0.0514
DEBUG - 2024-05-01 10:53:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-01 14:23:02 --> Total execution time: 0.1038
DEBUG - 2024-05-01 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:53:22 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:23:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:23:22 --> Total execution time: 0.0953
DEBUG - 2024-05-01 10:53:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:53:36 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:23:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:23:36 --> Total execution time: 0.1314
DEBUG - 2024-05-01 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:53:40 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:23:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:23:40 --> Total execution time: 0.1298
DEBUG - 2024-05-01 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:54:08 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:24:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:24:08 --> Total execution time: 0.1083
DEBUG - 2024-05-01 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:54:24 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:24:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:24:24 --> Total execution time: 0.1470
DEBUG - 2024-05-01 10:54:28 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:54:28 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:24:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:24:28 --> Total execution time: 0.1354
DEBUG - 2024-05-01 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:54:35 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:24:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:24:35 --> Total execution time: 0.1158
DEBUG - 2024-05-01 10:54:58 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:54:58 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:24:59 --> Total execution time: 0.1332
DEBUG - 2024-05-01 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:25:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:25:16 --> Total execution time: 0.1867
DEBUG - 2024-05-01 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 10:55:21 --> No URI present. Default controller set.
DEBUG - 2024-05-01 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 10:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:25:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:25:21 --> Total execution time: 0.0909
DEBUG - 2024-05-01 11:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:31:12 --> Total execution time: 0.2132
DEBUG - 2024-05-01 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:35:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:35:45 --> Total execution time: 0.0654
DEBUG - 2024-05-01 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:36:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:36:35 --> Total execution time: 0.1467
DEBUG - 2024-05-01 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:39:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:39:25 --> Total execution time: 0.0966
DEBUG - 2024-05-01 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:40:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:40:02 --> Total execution time: 0.1227
DEBUG - 2024-05-01 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:40:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:40:07 --> Total execution time: 0.0818
DEBUG - 2024-05-01 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:10:50 --> No URI present. Default controller set.
DEBUG - 2024-05-01 11:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:40:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:40:50 --> Total execution time: 0.0889
DEBUG - 2024-05-01 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:41:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:41:16 --> Total execution time: 0.0673
DEBUG - 2024-05-01 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-01 11:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-01 11:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-05-01 14:44:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-05-01 14:44:16 --> Total execution time: 0.1103
