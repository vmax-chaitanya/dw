<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-24 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2024-04-24 07:31:51 --> No URI present. Default controller set.
DEBUG - 2024-04-24 07:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-24 07:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> Undefined variable $h_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 38
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> Undefined variable $other_services C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\header.php 64
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> Undefined variable $f_other_services C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
ERROR - 2024-04-24 11:01:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\includes\footer.php 148
DEBUG - 2024-04-24 11:01:53 --> Total execution time: 2.9447
