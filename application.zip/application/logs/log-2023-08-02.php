<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-02 17:10:01 --> Config Class Initialized
INFO - 2023-08-02 17:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:10:01 --> Utf8 Class Initialized
INFO - 2023-08-02 17:10:01 --> URI Class Initialized
DEBUG - 2023-08-02 17:10:01 --> No URI present. Default controller set.
INFO - 2023-08-02 17:10:01 --> Router Class Initialized
INFO - 2023-08-02 17:10:01 --> Output Class Initialized
INFO - 2023-08-02 17:10:01 --> Security Class Initialized
DEBUG - 2023-08-02 17:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:10:01 --> Input Class Initialized
INFO - 2023-08-02 17:10:01 --> Language Class Initialized
INFO - 2023-08-02 17:10:01 --> Loader Class Initialized
INFO - 2023-08-02 17:10:01 --> Helper loaded: url_helper
INFO - 2023-08-02 17:10:01 --> Helper loaded: file_helper
INFO - 2023-08-02 17:10:01 --> Database Driver Class Initialized
INFO - 2023-08-02 17:10:01 --> Email Class Initialized
DEBUG - 2023-08-02 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:10:01 --> Controller Class Initialized
INFO - 2023-08-02 17:10:01 --> File loaded: C:\xampp\htdocs\DW\application\views\welcome_message.php
INFO - 2023-08-02 17:10:01 --> Final output sent to browser
DEBUG - 2023-08-02 17:10:01 --> Total execution time: 0.0624
INFO - 2023-08-02 17:10:09 --> Config Class Initialized
INFO - 2023-08-02 17:10:09 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:10:09 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:10:09 --> Utf8 Class Initialized
INFO - 2023-08-02 17:10:09 --> URI Class Initialized
INFO - 2023-08-02 17:10:09 --> Router Class Initialized
INFO - 2023-08-02 17:10:09 --> Output Class Initialized
INFO - 2023-08-02 17:10:09 --> Security Class Initialized
DEBUG - 2023-08-02 17:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:10:09 --> Input Class Initialized
INFO - 2023-08-02 17:10:09 --> Language Class Initialized
ERROR - 2023-08-02 17:10:09 --> 404 Page Not Found: admin//index
INFO - 2023-08-02 17:10:28 --> Config Class Initialized
INFO - 2023-08-02 17:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:10:28 --> Utf8 Class Initialized
INFO - 2023-08-02 17:10:28 --> URI Class Initialized
INFO - 2023-08-02 17:10:28 --> Router Class Initialized
INFO - 2023-08-02 17:10:28 --> Output Class Initialized
INFO - 2023-08-02 17:10:28 --> Security Class Initialized
DEBUG - 2023-08-02 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:10:28 --> Input Class Initialized
INFO - 2023-08-02 17:10:28 --> Language Class Initialized
INFO - 2023-08-02 17:10:28 --> Loader Class Initialized
INFO - 2023-08-02 17:10:28 --> Helper loaded: url_helper
INFO - 2023-08-02 17:10:28 --> Helper loaded: file_helper
INFO - 2023-08-02 17:10:28 --> Database Driver Class Initialized
INFO - 2023-08-02 17:10:28 --> Email Class Initialized
DEBUG - 2023-08-02 17:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:10:28 --> Controller Class Initialized
INFO - 2023-08-02 17:10:28 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:10:28 --> Helper loaded: form_helper
INFO - 2023-08-02 17:10:28 --> Form Validation Class Initialized
INFO - 2023-08-02 17:10:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:10:28 --> Final output sent to browser
DEBUG - 2023-08-02 17:10:28 --> Total execution time: 0.0869
INFO - 2023-08-02 17:10:28 --> Config Class Initialized
INFO - 2023-08-02 17:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:10:28 --> Utf8 Class Initialized
INFO - 2023-08-02 17:10:28 --> URI Class Initialized
INFO - 2023-08-02 17:10:28 --> Router Class Initialized
INFO - 2023-08-02 17:10:28 --> Output Class Initialized
INFO - 2023-08-02 17:10:28 --> Security Class Initialized
DEBUG - 2023-08-02 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:10:28 --> Input Class Initialized
INFO - 2023-08-02 17:10:28 --> Language Class Initialized
ERROR - 2023-08-02 17:10:28 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:10:29 --> Config Class Initialized
INFO - 2023-08-02 17:10:29 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:10:29 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:10:29 --> Utf8 Class Initialized
INFO - 2023-08-02 17:10:29 --> URI Class Initialized
INFO - 2023-08-02 17:10:29 --> Router Class Initialized
INFO - 2023-08-02 17:10:29 --> Output Class Initialized
INFO - 2023-08-02 17:10:29 --> Security Class Initialized
DEBUG - 2023-08-02 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:10:29 --> Input Class Initialized
INFO - 2023-08-02 17:10:29 --> Language Class Initialized
ERROR - 2023-08-02 17:10:29 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:12:40 --> Config Class Initialized
INFO - 2023-08-02 17:12:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:40 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:40 --> URI Class Initialized
INFO - 2023-08-02 17:12:40 --> Router Class Initialized
INFO - 2023-08-02 17:12:40 --> Output Class Initialized
INFO - 2023-08-02 17:12:40 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:40 --> Input Class Initialized
INFO - 2023-08-02 17:12:40 --> Language Class Initialized
INFO - 2023-08-02 17:12:40 --> Loader Class Initialized
INFO - 2023-08-02 17:12:40 --> Helper loaded: url_helper
INFO - 2023-08-02 17:12:40 --> Helper loaded: file_helper
INFO - 2023-08-02 17:12:40 --> Database Driver Class Initialized
INFO - 2023-08-02 17:12:40 --> Email Class Initialized
DEBUG - 2023-08-02 17:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:12:40 --> Controller Class Initialized
INFO - 2023-08-02 17:12:40 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:12:40 --> Helper loaded: form_helper
INFO - 2023-08-02 17:12:40 --> Form Validation Class Initialized
INFO - 2023-08-02 17:12:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:12:40 --> Final output sent to browser
DEBUG - 2023-08-02 17:12:40 --> Total execution time: 0.1608
INFO - 2023-08-02 17:12:41 --> Config Class Initialized
INFO - 2023-08-02 17:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:41 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:41 --> URI Class Initialized
INFO - 2023-08-02 17:12:41 --> Router Class Initialized
INFO - 2023-08-02 17:12:41 --> Output Class Initialized
INFO - 2023-08-02 17:12:41 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:41 --> Input Class Initialized
INFO - 2023-08-02 17:12:41 --> Language Class Initialized
ERROR - 2023-08-02 17:12:41 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:12:43 --> Config Class Initialized
INFO - 2023-08-02 17:12:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:43 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:43 --> URI Class Initialized
INFO - 2023-08-02 17:12:43 --> Router Class Initialized
INFO - 2023-08-02 17:12:43 --> Output Class Initialized
INFO - 2023-08-02 17:12:43 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:43 --> Input Class Initialized
INFO - 2023-08-02 17:12:43 --> Language Class Initialized
INFO - 2023-08-02 17:12:43 --> Loader Class Initialized
INFO - 2023-08-02 17:12:43 --> Helper loaded: url_helper
INFO - 2023-08-02 17:12:43 --> Helper loaded: file_helper
INFO - 2023-08-02 17:12:43 --> Database Driver Class Initialized
INFO - 2023-08-02 17:12:43 --> Email Class Initialized
DEBUG - 2023-08-02 17:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:12:43 --> Controller Class Initialized
INFO - 2023-08-02 17:12:43 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:12:43 --> Helper loaded: form_helper
INFO - 2023-08-02 17:12:43 --> Form Validation Class Initialized
INFO - 2023-08-02 17:12:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-02 17:12:43 --> Final output sent to browser
DEBUG - 2023-08-02 17:12:43 --> Total execution time: 0.0465
INFO - 2023-08-02 17:12:43 --> Config Class Initialized
INFO - 2023-08-02 17:12:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:43 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:43 --> URI Class Initialized
INFO - 2023-08-02 17:12:43 --> Router Class Initialized
INFO - 2023-08-02 17:12:43 --> Output Class Initialized
INFO - 2023-08-02 17:12:43 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:43 --> Input Class Initialized
INFO - 2023-08-02 17:12:43 --> Language Class Initialized
ERROR - 2023-08-02 17:12:43 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:12:46 --> Config Class Initialized
INFO - 2023-08-02 17:12:46 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:46 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:46 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:46 --> URI Class Initialized
INFO - 2023-08-02 17:12:46 --> Router Class Initialized
INFO - 2023-08-02 17:12:46 --> Output Class Initialized
INFO - 2023-08-02 17:12:46 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:46 --> Input Class Initialized
INFO - 2023-08-02 17:12:46 --> Language Class Initialized
INFO - 2023-08-02 17:12:46 --> Loader Class Initialized
INFO - 2023-08-02 17:12:46 --> Helper loaded: url_helper
INFO - 2023-08-02 17:12:46 --> Helper loaded: file_helper
INFO - 2023-08-02 17:12:46 --> Database Driver Class Initialized
INFO - 2023-08-02 17:12:46 --> Email Class Initialized
DEBUG - 2023-08-02 17:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:12:46 --> Controller Class Initialized
INFO - 2023-08-02 17:12:46 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:12:46 --> Helper loaded: form_helper
INFO - 2023-08-02 17:12:46 --> Form Validation Class Initialized
INFO - 2023-08-02 17:12:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:12:46 --> Final output sent to browser
DEBUG - 2023-08-02 17:12:46 --> Total execution time: 0.0521
INFO - 2023-08-02 17:12:50 --> Config Class Initialized
INFO - 2023-08-02 17:12:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:50 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:50 --> URI Class Initialized
INFO - 2023-08-02 17:12:50 --> Router Class Initialized
INFO - 2023-08-02 17:12:50 --> Output Class Initialized
INFO - 2023-08-02 17:12:50 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:50 --> Input Class Initialized
INFO - 2023-08-02 17:12:50 --> Language Class Initialized
INFO - 2023-08-02 17:12:50 --> Loader Class Initialized
INFO - 2023-08-02 17:12:50 --> Helper loaded: url_helper
INFO - 2023-08-02 17:12:50 --> Helper loaded: file_helper
INFO - 2023-08-02 17:12:50 --> Database Driver Class Initialized
INFO - 2023-08-02 17:12:50 --> Email Class Initialized
DEBUG - 2023-08-02 17:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:12:50 --> Controller Class Initialized
INFO - 2023-08-02 17:12:50 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:12:50 --> Helper loaded: form_helper
INFO - 2023-08-02 17:12:50 --> Form Validation Class Initialized
INFO - 2023-08-02 17:12:50 --> Final output sent to browser
DEBUG - 2023-08-02 17:12:50 --> Total execution time: 0.0592
INFO - 2023-08-02 17:12:53 --> Config Class Initialized
INFO - 2023-08-02 17:12:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:12:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:12:53 --> Utf8 Class Initialized
INFO - 2023-08-02 17:12:53 --> URI Class Initialized
INFO - 2023-08-02 17:12:53 --> Router Class Initialized
INFO - 2023-08-02 17:12:53 --> Output Class Initialized
INFO - 2023-08-02 17:12:53 --> Security Class Initialized
DEBUG - 2023-08-02 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:12:53 --> Input Class Initialized
INFO - 2023-08-02 17:12:53 --> Language Class Initialized
INFO - 2023-08-02 17:12:53 --> Loader Class Initialized
INFO - 2023-08-02 17:12:53 --> Helper loaded: url_helper
INFO - 2023-08-02 17:12:53 --> Helper loaded: file_helper
INFO - 2023-08-02 17:12:53 --> Database Driver Class Initialized
INFO - 2023-08-02 17:12:53 --> Email Class Initialized
DEBUG - 2023-08-02 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:12:53 --> Controller Class Initialized
INFO - 2023-08-02 17:12:53 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:12:53 --> Helper loaded: form_helper
INFO - 2023-08-02 17:12:53 --> Form Validation Class Initialized
INFO - 2023-08-02 17:12:53 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:12:53 --> Final output sent to browser
DEBUG - 2023-08-02 17:12:53 --> Total execution time: 0.0562
INFO - 2023-08-02 17:14:25 --> Config Class Initialized
INFO - 2023-08-02 17:14:25 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:25 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:25 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:25 --> URI Class Initialized
INFO - 2023-08-02 17:14:25 --> Router Class Initialized
INFO - 2023-08-02 17:14:25 --> Output Class Initialized
INFO - 2023-08-02 17:14:25 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:25 --> Input Class Initialized
INFO - 2023-08-02 17:14:25 --> Language Class Initialized
INFO - 2023-08-02 17:14:25 --> Loader Class Initialized
INFO - 2023-08-02 17:14:25 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:25 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:25 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:25 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:25 --> Controller Class Initialized
INFO - 2023-08-02 17:14:25 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:25 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:25 --> Form Validation Class Initialized
INFO - 2023-08-02 17:14:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:14:26 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:26 --> Total execution time: 0.4956
INFO - 2023-08-02 17:14:26 --> Config Class Initialized
INFO - 2023-08-02 17:14:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:26 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:26 --> URI Class Initialized
INFO - 2023-08-02 17:14:26 --> Router Class Initialized
INFO - 2023-08-02 17:14:26 --> Output Class Initialized
INFO - 2023-08-02 17:14:26 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:26 --> Input Class Initialized
INFO - 2023-08-02 17:14:26 --> Language Class Initialized
ERROR - 2023-08-02 17:14:26 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:14:28 --> Config Class Initialized
INFO - 2023-08-02 17:14:28 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:28 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:28 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:28 --> URI Class Initialized
INFO - 2023-08-02 17:14:28 --> Router Class Initialized
INFO - 2023-08-02 17:14:28 --> Output Class Initialized
INFO - 2023-08-02 17:14:28 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:28 --> Input Class Initialized
INFO - 2023-08-02 17:14:28 --> Language Class Initialized
INFO - 2023-08-02 17:14:28 --> Loader Class Initialized
INFO - 2023-08-02 17:14:28 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:28 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:28 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:28 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:28 --> Controller Class Initialized
INFO - 2023-08-02 17:14:28 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:28 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:28 --> Form Validation Class Initialized
INFO - 2023-08-02 17:14:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:14:28 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:28 --> Total execution time: 0.0512
INFO - 2023-08-02 17:14:28 --> Config Class Initialized
INFO - 2023-08-02 17:14:28 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:28 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:28 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:28 --> URI Class Initialized
INFO - 2023-08-02 17:14:28 --> Router Class Initialized
INFO - 2023-08-02 17:14:28 --> Output Class Initialized
INFO - 2023-08-02 17:14:28 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:28 --> Input Class Initialized
INFO - 2023-08-02 17:14:28 --> Language Class Initialized
INFO - 2023-08-02 17:14:28 --> Loader Class Initialized
INFO - 2023-08-02 17:14:28 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:28 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:28 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:28 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:28 --> Controller Class Initialized
INFO - 2023-08-02 17:14:28 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:28 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:28 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 39
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 48
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 58
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 59
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 72
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 73
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 83
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 99
ERROR - 2023-08-02 17:14:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 111
INFO - 2023-08-02 17:14:28 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:14:28 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:28 --> Total execution time: 0.0494
INFO - 2023-08-02 17:14:29 --> Config Class Initialized
INFO - 2023-08-02 17:14:29 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:29 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:29 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:29 --> URI Class Initialized
INFO - 2023-08-02 17:14:29 --> Router Class Initialized
INFO - 2023-08-02 17:14:29 --> Output Class Initialized
INFO - 2023-08-02 17:14:29 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:29 --> Input Class Initialized
INFO - 2023-08-02 17:14:29 --> Language Class Initialized
INFO - 2023-08-02 17:14:29 --> Loader Class Initialized
INFO - 2023-08-02 17:14:29 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:29 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:29 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:29 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:29 --> Controller Class Initialized
INFO - 2023-08-02 17:14:29 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:29 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:29 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 39
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 48
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 58
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 59
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 72
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 73
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 83
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 99
ERROR - 2023-08-02 17:14:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 111
INFO - 2023-08-02 17:14:29 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:14:29 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:29 --> Total execution time: 0.0636
INFO - 2023-08-02 17:14:40 --> Config Class Initialized
INFO - 2023-08-02 17:14:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:40 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:40 --> URI Class Initialized
INFO - 2023-08-02 17:14:40 --> Router Class Initialized
INFO - 2023-08-02 17:14:40 --> Output Class Initialized
INFO - 2023-08-02 17:14:40 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:40 --> Input Class Initialized
INFO - 2023-08-02 17:14:40 --> Language Class Initialized
INFO - 2023-08-02 17:14:40 --> Loader Class Initialized
INFO - 2023-08-02 17:14:40 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:40 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:40 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:40 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:40 --> Controller Class Initialized
INFO - 2023-08-02 17:14:40 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:40 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:40 --> Form Validation Class Initialized
INFO - 2023-08-02 17:14:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:14:40 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:40 --> Total execution time: 0.1135
INFO - 2023-08-02 17:14:59 --> Config Class Initialized
INFO - 2023-08-02 17:14:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:59 --> URI Class Initialized
INFO - 2023-08-02 17:14:59 --> Router Class Initialized
INFO - 2023-08-02 17:14:59 --> Output Class Initialized
INFO - 2023-08-02 17:14:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:59 --> Input Class Initialized
INFO - 2023-08-02 17:14:59 --> Language Class Initialized
INFO - 2023-08-02 17:14:59 --> Loader Class Initialized
INFO - 2023-08-02 17:14:59 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:59 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:59 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:59 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:59 --> Controller Class Initialized
INFO - 2023-08-02 17:14:59 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:59 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:59 --> Form Validation Class Initialized
INFO - 2023-08-02 17:14:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:14:59 --> Config Class Initialized
INFO - 2023-08-02 17:14:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:59 --> URI Class Initialized
INFO - 2023-08-02 17:14:59 --> Router Class Initialized
INFO - 2023-08-02 17:14:59 --> Output Class Initialized
INFO - 2023-08-02 17:14:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:59 --> Input Class Initialized
INFO - 2023-08-02 17:14:59 --> Language Class Initialized
INFO - 2023-08-02 17:14:59 --> Loader Class Initialized
INFO - 2023-08-02 17:14:59 --> Helper loaded: url_helper
INFO - 2023-08-02 17:14:59 --> Helper loaded: file_helper
INFO - 2023-08-02 17:14:59 --> Database Driver Class Initialized
INFO - 2023-08-02 17:14:59 --> Email Class Initialized
DEBUG - 2023-08-02 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:14:59 --> Controller Class Initialized
INFO - 2023-08-02 17:14:59 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:14:59 --> Helper loaded: form_helper
INFO - 2023-08-02 17:14:59 --> Form Validation Class Initialized
INFO - 2023-08-02 17:14:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:14:59 --> Final output sent to browser
DEBUG - 2023-08-02 17:14:59 --> Total execution time: 0.0425
INFO - 2023-08-02 17:14:59 --> Config Class Initialized
INFO - 2023-08-02 17:14:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:14:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:14:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:14:59 --> URI Class Initialized
INFO - 2023-08-02 17:14:59 --> Router Class Initialized
INFO - 2023-08-02 17:14:59 --> Output Class Initialized
INFO - 2023-08-02 17:14:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:14:59 --> Input Class Initialized
INFO - 2023-08-02 17:14:59 --> Language Class Initialized
ERROR - 2023-08-02 17:14:59 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:15:00 --> Config Class Initialized
INFO - 2023-08-02 17:15:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:00 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:00 --> URI Class Initialized
INFO - 2023-08-02 17:15:00 --> Router Class Initialized
INFO - 2023-08-02 17:15:00 --> Output Class Initialized
INFO - 2023-08-02 17:15:00 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:00 --> Input Class Initialized
INFO - 2023-08-02 17:15:00 --> Language Class Initialized
ERROR - 2023-08-02 17:15:00 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-02 17:15:04 --> Config Class Initialized
INFO - 2023-08-02 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:04 --> URI Class Initialized
INFO - 2023-08-02 17:15:04 --> Router Class Initialized
INFO - 2023-08-02 17:15:04 --> Output Class Initialized
INFO - 2023-08-02 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:04 --> Input Class Initialized
INFO - 2023-08-02 17:15:04 --> Language Class Initialized
INFO - 2023-08-02 17:15:04 --> Loader Class Initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: url_helper
INFO - 2023-08-02 17:15:04 --> Helper loaded: file_helper
INFO - 2023-08-02 17:15:04 --> Database Driver Class Initialized
INFO - 2023-08-02 17:15:04 --> Email Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:15:04 --> Controller Class Initialized
INFO - 2023-08-02 17:15:04 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: form_helper
INFO - 2023-08-02 17:15:04 --> Form Validation Class Initialized
INFO - 2023-08-02 17:15:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:15:04 --> Final output sent to browser
DEBUG - 2023-08-02 17:15:04 --> Total execution time: 0.0390
INFO - 2023-08-02 17:15:04 --> Config Class Initialized
INFO - 2023-08-02 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:04 --> URI Class Initialized
INFO - 2023-08-02 17:15:04 --> Router Class Initialized
INFO - 2023-08-02 17:15:04 --> Output Class Initialized
INFO - 2023-08-02 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:04 --> Input Class Initialized
INFO - 2023-08-02 17:15:04 --> Language Class Initialized
INFO - 2023-08-02 17:15:04 --> Loader Class Initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: url_helper
INFO - 2023-08-02 17:15:04 --> Helper loaded: file_helper
INFO - 2023-08-02 17:15:04 --> Database Driver Class Initialized
INFO - 2023-08-02 17:15:04 --> Email Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:15:04 --> Controller Class Initialized
INFO - 2023-08-02 17:15:04 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: form_helper
INFO - 2023-08-02 17:15:04 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 39
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 48
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 58
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 59
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 72
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 73
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 83
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 99
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 111
INFO - 2023-08-02 17:15:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:15:04 --> Final output sent to browser
DEBUG - 2023-08-02 17:15:04 --> Total execution time: 0.2055
INFO - 2023-08-02 17:15:04 --> Config Class Initialized
INFO - 2023-08-02 17:15:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:04 --> URI Class Initialized
INFO - 2023-08-02 17:15:04 --> Router Class Initialized
INFO - 2023-08-02 17:15:04 --> Output Class Initialized
INFO - 2023-08-02 17:15:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:04 --> Input Class Initialized
INFO - 2023-08-02 17:15:04 --> Language Class Initialized
INFO - 2023-08-02 17:15:04 --> Loader Class Initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: url_helper
INFO - 2023-08-02 17:15:04 --> Helper loaded: file_helper
INFO - 2023-08-02 17:15:04 --> Database Driver Class Initialized
INFO - 2023-08-02 17:15:04 --> Email Class Initialized
DEBUG - 2023-08-02 17:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:15:04 --> Controller Class Initialized
INFO - 2023-08-02 17:15:04 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:15:04 --> Helper loaded: form_helper
INFO - 2023-08-02 17:15:04 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 39
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 48
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 58
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 59
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 72
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 73
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 83
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 99
ERROR - 2023-08-02 17:15:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\banner_edit.php 111
INFO - 2023-08-02 17:15:04 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_edit.php
INFO - 2023-08-02 17:15:04 --> Final output sent to browser
DEBUG - 2023-08-02 17:15:04 --> Total execution time: 0.0552
INFO - 2023-08-02 17:15:12 --> Config Class Initialized
INFO - 2023-08-02 17:15:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:12 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:12 --> URI Class Initialized
INFO - 2023-08-02 17:15:12 --> Router Class Initialized
INFO - 2023-08-02 17:15:12 --> Output Class Initialized
INFO - 2023-08-02 17:15:12 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:12 --> Input Class Initialized
INFO - 2023-08-02 17:15:12 --> Language Class Initialized
INFO - 2023-08-02 17:15:12 --> Loader Class Initialized
INFO - 2023-08-02 17:15:12 --> Helper loaded: url_helper
INFO - 2023-08-02 17:15:12 --> Helper loaded: file_helper
INFO - 2023-08-02 17:15:12 --> Database Driver Class Initialized
INFO - 2023-08-02 17:15:12 --> Email Class Initialized
DEBUG - 2023-08-02 17:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:15:12 --> Controller Class Initialized
INFO - 2023-08-02 17:15:12 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:15:12 --> Helper loaded: form_helper
INFO - 2023-08-02 17:15:12 --> Form Validation Class Initialized
INFO - 2023-08-02 17:15:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:15:12 --> Config Class Initialized
INFO - 2023-08-02 17:15:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:12 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:12 --> URI Class Initialized
INFO - 2023-08-02 17:15:12 --> Router Class Initialized
INFO - 2023-08-02 17:15:12 --> Output Class Initialized
INFO - 2023-08-02 17:15:12 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:12 --> Input Class Initialized
INFO - 2023-08-02 17:15:12 --> Language Class Initialized
INFO - 2023-08-02 17:15:12 --> Loader Class Initialized
INFO - 2023-08-02 17:15:12 --> Helper loaded: url_helper
INFO - 2023-08-02 17:15:12 --> Helper loaded: file_helper
INFO - 2023-08-02 17:15:12 --> Database Driver Class Initialized
INFO - 2023-08-02 17:15:12 --> Email Class Initialized
DEBUG - 2023-08-02 17:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:15:12 --> Controller Class Initialized
INFO - 2023-08-02 17:15:12 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:15:12 --> Helper loaded: form_helper
INFO - 2023-08-02 17:15:12 --> Form Validation Class Initialized
INFO - 2023-08-02 17:15:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banners_list.php
INFO - 2023-08-02 17:15:12 --> Final output sent to browser
DEBUG - 2023-08-02 17:15:12 --> Total execution time: 0.0436
INFO - 2023-08-02 17:15:13 --> Config Class Initialized
INFO - 2023-08-02 17:15:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:15:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:15:13 --> Utf8 Class Initialized
INFO - 2023-08-02 17:15:13 --> URI Class Initialized
INFO - 2023-08-02 17:15:13 --> Router Class Initialized
INFO - 2023-08-02 17:15:13 --> Output Class Initialized
INFO - 2023-08-02 17:15:13 --> Security Class Initialized
DEBUG - 2023-08-02 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:15:13 --> Input Class Initialized
INFO - 2023-08-02 17:15:13 --> Language Class Initialized
ERROR - 2023-08-02 17:15:13 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:27:55 --> Config Class Initialized
INFO - 2023-08-02 17:27:55 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:27:55 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:27:55 --> Utf8 Class Initialized
INFO - 2023-08-02 17:27:55 --> URI Class Initialized
INFO - 2023-08-02 17:27:55 --> Router Class Initialized
INFO - 2023-08-02 17:27:55 --> Output Class Initialized
INFO - 2023-08-02 17:27:55 --> Security Class Initialized
DEBUG - 2023-08-02 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:27:55 --> Input Class Initialized
INFO - 2023-08-02 17:27:55 --> Language Class Initialized
INFO - 2023-08-02 17:27:55 --> Loader Class Initialized
INFO - 2023-08-02 17:27:55 --> Helper loaded: url_helper
INFO - 2023-08-02 17:27:55 --> Helper loaded: file_helper
INFO - 2023-08-02 17:27:55 --> Database Driver Class Initialized
INFO - 2023-08-02 17:27:56 --> Email Class Initialized
DEBUG - 2023-08-02 17:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:27:56 --> Controller Class Initialized
INFO - 2023-08-02 17:27:56 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:27:56 --> Helper loaded: form_helper
INFO - 2023-08-02 17:27:56 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:27:56 --> Query error: Table 'dw.faq' doesn't exist - Invalid query: SELECT *
FROM `faq`
INFO - 2023-08-02 17:27:56 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-02 17:28:15 --> Config Class Initialized
INFO - 2023-08-02 17:28:15 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:28:15 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:28:15 --> Utf8 Class Initialized
INFO - 2023-08-02 17:28:15 --> URI Class Initialized
INFO - 2023-08-02 17:28:15 --> Router Class Initialized
INFO - 2023-08-02 17:28:15 --> Output Class Initialized
INFO - 2023-08-02 17:28:15 --> Security Class Initialized
DEBUG - 2023-08-02 17:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:28:15 --> Input Class Initialized
INFO - 2023-08-02 17:28:15 --> Language Class Initialized
INFO - 2023-08-02 17:28:15 --> Loader Class Initialized
INFO - 2023-08-02 17:28:15 --> Helper loaded: url_helper
INFO - 2023-08-02 17:28:15 --> Helper loaded: file_helper
INFO - 2023-08-02 17:28:15 --> Database Driver Class Initialized
INFO - 2023-08-02 17:28:15 --> Email Class Initialized
DEBUG - 2023-08-02 17:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:28:15 --> Controller Class Initialized
INFO - 2023-08-02 17:28:15 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:28:15 --> Helper loaded: form_helper
INFO - 2023-08-02 17:28:15 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:28:15 --> Query error: Table 'dw.pages' doesn't exist - Invalid query: SELECT *
FROM `pages`
INFO - 2023-08-02 17:28:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-02 17:28:59 --> Config Class Initialized
INFO - 2023-08-02 17:28:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:28:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:28:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:28:59 --> URI Class Initialized
INFO - 2023-08-02 17:28:59 --> Router Class Initialized
INFO - 2023-08-02 17:28:59 --> Output Class Initialized
INFO - 2023-08-02 17:28:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:28:59 --> Input Class Initialized
INFO - 2023-08-02 17:28:59 --> Language Class Initialized
INFO - 2023-08-02 17:28:59 --> Loader Class Initialized
INFO - 2023-08-02 17:28:59 --> Helper loaded: url_helper
INFO - 2023-08-02 17:28:59 --> Helper loaded: file_helper
INFO - 2023-08-02 17:28:59 --> Database Driver Class Initialized
INFO - 2023-08-02 17:28:59 --> Email Class Initialized
DEBUG - 2023-08-02 17:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:28:59 --> Controller Class Initialized
INFO - 2023-08-02 17:28:59 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:28:59 --> Helper loaded: form_helper
INFO - 2023-08-02 17:28:59 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:28:59 --> Query error: Table 'dw.pages' doesn't exist - Invalid query: SELECT *
FROM `pages`
INFO - 2023-08-02 17:28:59 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-02 17:29:40 --> Config Class Initialized
INFO - 2023-08-02 17:29:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:29:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:29:40 --> Utf8 Class Initialized
INFO - 2023-08-02 17:29:40 --> URI Class Initialized
INFO - 2023-08-02 17:29:40 --> Router Class Initialized
INFO - 2023-08-02 17:29:40 --> Output Class Initialized
INFO - 2023-08-02 17:29:40 --> Security Class Initialized
DEBUG - 2023-08-02 17:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:29:40 --> Input Class Initialized
INFO - 2023-08-02 17:29:40 --> Language Class Initialized
INFO - 2023-08-02 17:29:41 --> Loader Class Initialized
INFO - 2023-08-02 17:29:41 --> Helper loaded: url_helper
INFO - 2023-08-02 17:29:41 --> Helper loaded: file_helper
INFO - 2023-08-02 17:29:41 --> Database Driver Class Initialized
INFO - 2023-08-02 17:29:41 --> Email Class Initialized
DEBUG - 2023-08-02 17:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:29:41 --> Controller Class Initialized
INFO - 2023-08-02 17:29:41 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:29:41 --> Helper loaded: form_helper
INFO - 2023-08-02 17:29:41 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:29:41 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\DW\application\controllers\Admin\FAQ.php 20
INFO - 2023-08-02 17:29:41 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-02 17:29:41 --> Final output sent to browser
DEBUG - 2023-08-02 17:29:41 --> Total execution time: 0.4148
INFO - 2023-08-02 17:29:41 --> Config Class Initialized
INFO - 2023-08-02 17:29:41 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:29:41 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:29:41 --> Utf8 Class Initialized
INFO - 2023-08-02 17:29:41 --> URI Class Initialized
INFO - 2023-08-02 17:29:41 --> Router Class Initialized
INFO - 2023-08-02 17:29:41 --> Output Class Initialized
INFO - 2023-08-02 17:29:41 --> Security Class Initialized
DEBUG - 2023-08-02 17:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:29:41 --> Input Class Initialized
INFO - 2023-08-02 17:29:41 --> Language Class Initialized
ERROR - 2023-08-02 17:29:41 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-02 17:33:10 --> Config Class Initialized
INFO - 2023-08-02 17:33:10 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:33:10 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:33:10 --> Utf8 Class Initialized
INFO - 2023-08-02 17:33:10 --> URI Class Initialized
INFO - 2023-08-02 17:33:10 --> Router Class Initialized
INFO - 2023-08-02 17:33:11 --> Output Class Initialized
INFO - 2023-08-02 17:33:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:33:11 --> Input Class Initialized
INFO - 2023-08-02 17:33:11 --> Language Class Initialized
INFO - 2023-08-02 17:33:11 --> Loader Class Initialized
INFO - 2023-08-02 17:33:11 --> Helper loaded: url_helper
INFO - 2023-08-02 17:33:11 --> Helper loaded: file_helper
INFO - 2023-08-02 17:33:11 --> Database Driver Class Initialized
INFO - 2023-08-02 17:33:11 --> Email Class Initialized
DEBUG - 2023-08-02 17:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:33:11 --> Controller Class Initialized
INFO - 2023-08-02 17:33:11 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:33:11 --> Helper loaded: form_helper
INFO - 2023-08-02 17:33:11 --> Form Validation Class Initialized
INFO - 2023-08-02 17:33:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-02 17:33:11 --> Final output sent to browser
DEBUG - 2023-08-02 17:33:11 --> Total execution time: 0.3667
INFO - 2023-08-02 17:33:11 --> Config Class Initialized
INFO - 2023-08-02 17:33:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:33:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:33:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:33:11 --> URI Class Initialized
INFO - 2023-08-02 17:33:11 --> Router Class Initialized
INFO - 2023-08-02 17:33:11 --> Output Class Initialized
INFO - 2023-08-02 17:33:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:33:11 --> Input Class Initialized
INFO - 2023-08-02 17:33:11 --> Language Class Initialized
ERROR - 2023-08-02 17:33:11 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-02 17:33:11 --> Config Class Initialized
INFO - 2023-08-02 17:33:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:33:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:33:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:33:11 --> URI Class Initialized
INFO - 2023-08-02 17:33:11 --> Router Class Initialized
INFO - 2023-08-02 17:33:11 --> Output Class Initialized
INFO - 2023-08-02 17:33:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:33:11 --> Input Class Initialized
INFO - 2023-08-02 17:33:11 --> Language Class Initialized
ERROR - 2023-08-02 17:33:11 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-02 17:33:40 --> Config Class Initialized
INFO - 2023-08-02 17:33:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:33:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:33:40 --> Utf8 Class Initialized
INFO - 2023-08-02 17:33:40 --> URI Class Initialized
INFO - 2023-08-02 17:33:40 --> Router Class Initialized
INFO - 2023-08-02 17:33:40 --> Output Class Initialized
INFO - 2023-08-02 17:33:40 --> Security Class Initialized
DEBUG - 2023-08-02 17:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:33:40 --> Input Class Initialized
INFO - 2023-08-02 17:33:40 --> Language Class Initialized
INFO - 2023-08-02 17:33:40 --> Loader Class Initialized
INFO - 2023-08-02 17:33:40 --> Helper loaded: url_helper
INFO - 2023-08-02 17:33:40 --> Helper loaded: file_helper
INFO - 2023-08-02 17:33:40 --> Database Driver Class Initialized
INFO - 2023-08-02 17:33:40 --> Email Class Initialized
DEBUG - 2023-08-02 17:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:33:40 --> Controller Class Initialized
INFO - 2023-08-02 17:33:40 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:33:40 --> Helper loaded: form_helper
INFO - 2023-08-02 17:33:40 --> Form Validation Class Initialized
INFO - 2023-08-02 17:33:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-02 17:33:40 --> Query error: Table 'dw.faq' doesn't exist - Invalid query: INSERT INTO `faq` (`type`, `page_id`, `question`, `answer`, `status`, `created_at`, `created_by`) VALUES ('2', '3', 'ffffff', 'ffff', '1', '2023-08-02 17:33:40', '2')
INFO - 2023-08-02 17:33:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-08-02 17:35:04 --> Config Class Initialized
INFO - 2023-08-02 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:35:04 --> URI Class Initialized
INFO - 2023-08-02 17:35:04 --> Router Class Initialized
INFO - 2023-08-02 17:35:04 --> Output Class Initialized
INFO - 2023-08-02 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:35:04 --> Input Class Initialized
INFO - 2023-08-02 17:35:04 --> Language Class Initialized
INFO - 2023-08-02 17:35:04 --> Loader Class Initialized
INFO - 2023-08-02 17:35:04 --> Helper loaded: url_helper
INFO - 2023-08-02 17:35:04 --> Helper loaded: file_helper
INFO - 2023-08-02 17:35:04 --> Database Driver Class Initialized
INFO - 2023-08-02 17:35:04 --> Email Class Initialized
DEBUG - 2023-08-02 17:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:35:04 --> Controller Class Initialized
INFO - 2023-08-02 17:35:04 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:35:04 --> Helper loaded: form_helper
INFO - 2023-08-02 17:35:04 --> Form Validation Class Initialized
INFO - 2023-08-02 17:35:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:35:04 --> Config Class Initialized
INFO - 2023-08-02 17:35:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:35:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:35:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:35:04 --> URI Class Initialized
INFO - 2023-08-02 17:35:04 --> Router Class Initialized
INFO - 2023-08-02 17:35:04 --> Output Class Initialized
INFO - 2023-08-02 17:35:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:35:04 --> Input Class Initialized
INFO - 2023-08-02 17:35:05 --> Language Class Initialized
INFO - 2023-08-02 17:35:05 --> Loader Class Initialized
INFO - 2023-08-02 17:35:05 --> Helper loaded: url_helper
INFO - 2023-08-02 17:35:05 --> Helper loaded: file_helper
INFO - 2023-08-02 17:35:05 --> Database Driver Class Initialized
INFO - 2023-08-02 17:35:05 --> Email Class Initialized
DEBUG - 2023-08-02 17:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:35:05 --> Controller Class Initialized
INFO - 2023-08-02 17:35:05 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:35:05 --> Helper loaded: form_helper
INFO - 2023-08-02 17:35:05 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:35:05 --> Severity: Warning --> Undefined variable $banners C:\xampp\htdocs\DW\application\views\admin\faq_list.php 66
ERROR - 2023-08-02 17:35:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\DW\application\views\admin\faq_list.php 66
INFO - 2023-08-02 17:35:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-02 17:35:05 --> Final output sent to browser
DEBUG - 2023-08-02 17:35:05 --> Total execution time: 0.5181
INFO - 2023-08-02 17:35:05 --> Config Class Initialized
INFO - 2023-08-02 17:35:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:35:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:35:05 --> Utf8 Class Initialized
INFO - 2023-08-02 17:35:05 --> URI Class Initialized
INFO - 2023-08-02 17:35:05 --> Router Class Initialized
INFO - 2023-08-02 17:35:05 --> Output Class Initialized
INFO - 2023-08-02 17:35:05 --> Security Class Initialized
DEBUG - 2023-08-02 17:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:35:05 --> Input Class Initialized
INFO - 2023-08-02 17:35:05 --> Language Class Initialized
ERROR - 2023-08-02 17:35:05 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:38:11 --> Config Class Initialized
INFO - 2023-08-02 17:38:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:38:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:38:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:38:11 --> URI Class Initialized
INFO - 2023-08-02 17:38:11 --> Router Class Initialized
INFO - 2023-08-02 17:38:11 --> Output Class Initialized
INFO - 2023-08-02 17:38:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:38:11 --> Input Class Initialized
INFO - 2023-08-02 17:38:11 --> Language Class Initialized
INFO - 2023-08-02 17:38:11 --> Loader Class Initialized
INFO - 2023-08-02 17:38:11 --> Helper loaded: url_helper
INFO - 2023-08-02 17:38:11 --> Helper loaded: file_helper
INFO - 2023-08-02 17:38:11 --> Database Driver Class Initialized
INFO - 2023-08-02 17:38:11 --> Email Class Initialized
DEBUG - 2023-08-02 17:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:38:11 --> Controller Class Initialized
INFO - 2023-08-02 17:38:11 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:38:11 --> Helper loaded: form_helper
INFO - 2023-08-02 17:38:11 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:38:11 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\faq_list.php 67
INFO - 2023-08-02 17:38:11 --> Config Class Initialized
INFO - 2023-08-02 17:38:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:38:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:38:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:38:11 --> URI Class Initialized
INFO - 2023-08-02 17:38:11 --> Router Class Initialized
INFO - 2023-08-02 17:38:11 --> Output Class Initialized
INFO - 2023-08-02 17:38:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:38:11 --> Input Class Initialized
INFO - 2023-08-02 17:38:11 --> Language Class Initialized
ERROR - 2023-08-02 17:38:11 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:39:17 --> Config Class Initialized
INFO - 2023-08-02 17:39:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:39:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:39:17 --> Utf8 Class Initialized
INFO - 2023-08-02 17:39:17 --> URI Class Initialized
INFO - 2023-08-02 17:39:17 --> Router Class Initialized
INFO - 2023-08-02 17:39:17 --> Output Class Initialized
INFO - 2023-08-02 17:39:17 --> Security Class Initialized
DEBUG - 2023-08-02 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:39:17 --> Input Class Initialized
INFO - 2023-08-02 17:39:17 --> Language Class Initialized
INFO - 2023-08-02 17:39:17 --> Loader Class Initialized
INFO - 2023-08-02 17:39:17 --> Helper loaded: url_helper
INFO - 2023-08-02 17:39:17 --> Helper loaded: file_helper
INFO - 2023-08-02 17:39:17 --> Database Driver Class Initialized
INFO - 2023-08-02 17:39:17 --> Email Class Initialized
DEBUG - 2023-08-02 17:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:39:17 --> Controller Class Initialized
INFO - 2023-08-02 17:39:17 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:39:17 --> Helper loaded: form_helper
INFO - 2023-08-02 17:39:17 --> Form Validation Class Initialized
INFO - 2023-08-02 17:39:47 --> Config Class Initialized
INFO - 2023-08-02 17:39:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:39:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:39:48 --> Utf8 Class Initialized
INFO - 2023-08-02 17:39:48 --> URI Class Initialized
INFO - 2023-08-02 17:39:48 --> Router Class Initialized
INFO - 2023-08-02 17:39:48 --> Output Class Initialized
INFO - 2023-08-02 17:39:48 --> Security Class Initialized
DEBUG - 2023-08-02 17:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:39:48 --> Input Class Initialized
INFO - 2023-08-02 17:39:48 --> Language Class Initialized
INFO - 2023-08-02 17:39:48 --> Loader Class Initialized
INFO - 2023-08-02 17:39:48 --> Helper loaded: url_helper
INFO - 2023-08-02 17:39:48 --> Helper loaded: file_helper
INFO - 2023-08-02 17:39:48 --> Database Driver Class Initialized
INFO - 2023-08-02 17:39:48 --> Email Class Initialized
DEBUG - 2023-08-02 17:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:39:48 --> Controller Class Initialized
INFO - 2023-08-02 17:39:48 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:39:48 --> Helper loaded: form_helper
INFO - 2023-08-02 17:39:48 --> Form Validation Class Initialized
INFO - 2023-08-02 17:40:02 --> Config Class Initialized
INFO - 2023-08-02 17:40:02 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:02 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:02 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:02 --> URI Class Initialized
INFO - 2023-08-02 17:40:02 --> Router Class Initialized
INFO - 2023-08-02 17:40:02 --> Output Class Initialized
INFO - 2023-08-02 17:40:02 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:02 --> Input Class Initialized
INFO - 2023-08-02 17:40:02 --> Language Class Initialized
INFO - 2023-08-02 17:40:02 --> Loader Class Initialized
INFO - 2023-08-02 17:40:02 --> Helper loaded: url_helper
INFO - 2023-08-02 17:40:02 --> Helper loaded: file_helper
INFO - 2023-08-02 17:40:02 --> Database Driver Class Initialized
INFO - 2023-08-02 17:40:02 --> Email Class Initialized
DEBUG - 2023-08-02 17:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:40:02 --> Controller Class Initialized
INFO - 2023-08-02 17:40:03 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:40:03 --> Helper loaded: form_helper
INFO - 2023-08-02 17:40:03 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:40:03 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\faq_list.php 71
INFO - 2023-08-02 17:40:03 --> Config Class Initialized
INFO - 2023-08-02 17:40:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:03 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:03 --> URI Class Initialized
INFO - 2023-08-02 17:40:03 --> Router Class Initialized
INFO - 2023-08-02 17:40:03 --> Output Class Initialized
INFO - 2023-08-02 17:40:03 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:03 --> Input Class Initialized
INFO - 2023-08-02 17:40:03 --> Language Class Initialized
ERROR - 2023-08-02 17:40:03 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:40:29 --> Config Class Initialized
INFO - 2023-08-02 17:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:29 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:29 --> URI Class Initialized
INFO - 2023-08-02 17:40:29 --> Router Class Initialized
INFO - 2023-08-02 17:40:29 --> Output Class Initialized
INFO - 2023-08-02 17:40:29 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:29 --> Input Class Initialized
INFO - 2023-08-02 17:40:29 --> Language Class Initialized
INFO - 2023-08-02 17:40:29 --> Loader Class Initialized
INFO - 2023-08-02 17:40:29 --> Helper loaded: url_helper
INFO - 2023-08-02 17:40:29 --> Helper loaded: file_helper
INFO - 2023-08-02 17:40:29 --> Database Driver Class Initialized
INFO - 2023-08-02 17:40:29 --> Email Class Initialized
DEBUG - 2023-08-02 17:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:40:30 --> Controller Class Initialized
INFO - 2023-08-02 17:40:30 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:40:30 --> Helper loaded: form_helper
INFO - 2023-08-02 17:40:30 --> Form Validation Class Initialized
INFO - 2023-08-02 17:40:30 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-02 17:40:30 --> Final output sent to browser
DEBUG - 2023-08-02 17:40:30 --> Total execution time: 0.5526
INFO - 2023-08-02 17:40:30 --> Config Class Initialized
INFO - 2023-08-02 17:40:30 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:30 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:30 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:30 --> URI Class Initialized
INFO - 2023-08-02 17:40:30 --> Router Class Initialized
INFO - 2023-08-02 17:40:30 --> Output Class Initialized
INFO - 2023-08-02 17:40:30 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:30 --> Input Class Initialized
INFO - 2023-08-02 17:40:30 --> Language Class Initialized
ERROR - 2023-08-02 17:40:30 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:40:49 --> Config Class Initialized
INFO - 2023-08-02 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:49 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:49 --> URI Class Initialized
INFO - 2023-08-02 17:40:49 --> Router Class Initialized
INFO - 2023-08-02 17:40:49 --> Output Class Initialized
INFO - 2023-08-02 17:40:49 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:49 --> Input Class Initialized
INFO - 2023-08-02 17:40:49 --> Language Class Initialized
INFO - 2023-08-02 17:40:49 --> Loader Class Initialized
INFO - 2023-08-02 17:40:49 --> Helper loaded: url_helper
INFO - 2023-08-02 17:40:49 --> Helper loaded: file_helper
INFO - 2023-08-02 17:40:49 --> Database Driver Class Initialized
INFO - 2023-08-02 17:40:49 --> Email Class Initialized
DEBUG - 2023-08-02 17:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:40:49 --> Controller Class Initialized
INFO - 2023-08-02 17:40:49 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:40:49 --> Helper loaded: form_helper
INFO - 2023-08-02 17:40:49 --> Form Validation Class Initialized
INFO - 2023-08-02 17:40:49 --> Config Class Initialized
INFO - 2023-08-02 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:49 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:49 --> URI Class Initialized
INFO - 2023-08-02 17:40:49 --> Router Class Initialized
INFO - 2023-08-02 17:40:49 --> Output Class Initialized
INFO - 2023-08-02 17:40:49 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:49 --> Input Class Initialized
INFO - 2023-08-02 17:40:49 --> Language Class Initialized
INFO - 2023-08-02 17:40:49 --> Loader Class Initialized
INFO - 2023-08-02 17:40:49 --> Helper loaded: url_helper
INFO - 2023-08-02 17:40:49 --> Helper loaded: file_helper
INFO - 2023-08-02 17:40:49 --> Database Driver Class Initialized
INFO - 2023-08-02 17:40:49 --> Email Class Initialized
DEBUG - 2023-08-02 17:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:40:49 --> Controller Class Initialized
INFO - 2023-08-02 17:40:49 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:40:49 --> Helper loaded: form_helper
INFO - 2023-08-02 17:40:49 --> Form Validation Class Initialized
INFO - 2023-08-02 17:40:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-02 17:40:49 --> Final output sent to browser
DEBUG - 2023-08-02 17:40:49 --> Total execution time: 0.0449
INFO - 2023-08-02 17:40:49 --> Config Class Initialized
INFO - 2023-08-02 17:40:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:49 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:49 --> URI Class Initialized
INFO - 2023-08-02 17:40:49 --> Router Class Initialized
INFO - 2023-08-02 17:40:49 --> Output Class Initialized
INFO - 2023-08-02 17:40:49 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:49 --> Input Class Initialized
INFO - 2023-08-02 17:40:49 --> Language Class Initialized
ERROR - 2023-08-02 17:40:49 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:40:51 --> Config Class Initialized
INFO - 2023-08-02 17:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:51 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:51 --> URI Class Initialized
INFO - 2023-08-02 17:40:51 --> Router Class Initialized
INFO - 2023-08-02 17:40:51 --> Output Class Initialized
INFO - 2023-08-02 17:40:51 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:51 --> Input Class Initialized
INFO - 2023-08-02 17:40:51 --> Language Class Initialized
INFO - 2023-08-02 17:40:51 --> Loader Class Initialized
INFO - 2023-08-02 17:40:51 --> Helper loaded: url_helper
INFO - 2023-08-02 17:40:51 --> Helper loaded: file_helper
INFO - 2023-08-02 17:40:51 --> Database Driver Class Initialized
INFO - 2023-08-02 17:40:51 --> Email Class Initialized
DEBUG - 2023-08-02 17:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:40:51 --> Controller Class Initialized
INFO - 2023-08-02 17:40:51 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:40:51 --> Helper loaded: form_helper
INFO - 2023-08-02 17:40:51 --> Form Validation Class Initialized
INFO - 2023-08-02 17:40:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-02 17:40:51 --> Final output sent to browser
DEBUG - 2023-08-02 17:40:51 --> Total execution time: 0.2020
INFO - 2023-08-02 17:40:52 --> Config Class Initialized
INFO - 2023-08-02 17:40:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:52 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:52 --> URI Class Initialized
INFO - 2023-08-02 17:40:52 --> Router Class Initialized
INFO - 2023-08-02 17:40:52 --> Output Class Initialized
INFO - 2023-08-02 17:40:52 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:52 --> Input Class Initialized
INFO - 2023-08-02 17:40:52 --> Language Class Initialized
ERROR - 2023-08-02 17:40:52 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:40:52 --> Config Class Initialized
INFO - 2023-08-02 17:40:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:40:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:40:52 --> Utf8 Class Initialized
INFO - 2023-08-02 17:40:52 --> URI Class Initialized
INFO - 2023-08-02 17:40:52 --> Router Class Initialized
INFO - 2023-08-02 17:40:52 --> Output Class Initialized
INFO - 2023-08-02 17:40:52 --> Security Class Initialized
DEBUG - 2023-08-02 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:40:52 --> Input Class Initialized
INFO - 2023-08-02 17:40:52 --> Language Class Initialized
ERROR - 2023-08-02 17:40:52 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:41:11 --> Config Class Initialized
INFO - 2023-08-02 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:11 --> URI Class Initialized
INFO - 2023-08-02 17:41:11 --> Router Class Initialized
INFO - 2023-08-02 17:41:11 --> Output Class Initialized
INFO - 2023-08-02 17:41:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:11 --> Input Class Initialized
INFO - 2023-08-02 17:41:11 --> Language Class Initialized
INFO - 2023-08-02 17:41:11 --> Loader Class Initialized
INFO - 2023-08-02 17:41:11 --> Helper loaded: url_helper
INFO - 2023-08-02 17:41:11 --> Helper loaded: file_helper
INFO - 2023-08-02 17:41:11 --> Database Driver Class Initialized
INFO - 2023-08-02 17:41:11 --> Email Class Initialized
DEBUG - 2023-08-02 17:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:41:11 --> Controller Class Initialized
INFO - 2023-08-02 17:41:11 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:41:11 --> Helper loaded: form_helper
INFO - 2023-08-02 17:41:11 --> Form Validation Class Initialized
INFO - 2023-08-02 17:41:11 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_create.php
INFO - 2023-08-02 17:41:11 --> Final output sent to browser
DEBUG - 2023-08-02 17:41:11 --> Total execution time: 0.0895
INFO - 2023-08-02 17:41:11 --> Config Class Initialized
INFO - 2023-08-02 17:41:11 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:11 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:11 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:11 --> URI Class Initialized
INFO - 2023-08-02 17:41:11 --> Router Class Initialized
INFO - 2023-08-02 17:41:11 --> Output Class Initialized
INFO - 2023-08-02 17:41:11 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:11 --> Input Class Initialized
INFO - 2023-08-02 17:41:11 --> Language Class Initialized
ERROR - 2023-08-02 17:41:11 --> 404 Page Not Found: admin/Faq/images
INFO - 2023-08-02 17:41:27 --> Config Class Initialized
INFO - 2023-08-02 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:27 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:27 --> URI Class Initialized
INFO - 2023-08-02 17:41:27 --> Router Class Initialized
INFO - 2023-08-02 17:41:27 --> Output Class Initialized
INFO - 2023-08-02 17:41:27 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:27 --> Input Class Initialized
INFO - 2023-08-02 17:41:27 --> Language Class Initialized
INFO - 2023-08-02 17:41:27 --> Loader Class Initialized
INFO - 2023-08-02 17:41:27 --> Helper loaded: url_helper
INFO - 2023-08-02 17:41:27 --> Helper loaded: file_helper
INFO - 2023-08-02 17:41:27 --> Database Driver Class Initialized
INFO - 2023-08-02 17:41:27 --> Email Class Initialized
DEBUG - 2023-08-02 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:41:27 --> Controller Class Initialized
INFO - 2023-08-02 17:41:27 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:41:27 --> Helper loaded: form_helper
INFO - 2023-08-02 17:41:27 --> Form Validation Class Initialized
INFO - 2023-08-02 17:41:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:41:27 --> Config Class Initialized
INFO - 2023-08-02 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:27 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:27 --> URI Class Initialized
INFO - 2023-08-02 17:41:27 --> Router Class Initialized
INFO - 2023-08-02 17:41:27 --> Output Class Initialized
INFO - 2023-08-02 17:41:27 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:27 --> Input Class Initialized
INFO - 2023-08-02 17:41:27 --> Language Class Initialized
INFO - 2023-08-02 17:41:27 --> Loader Class Initialized
INFO - 2023-08-02 17:41:27 --> Helper loaded: url_helper
INFO - 2023-08-02 17:41:27 --> Helper loaded: file_helper
INFO - 2023-08-02 17:41:27 --> Database Driver Class Initialized
INFO - 2023-08-02 17:41:27 --> Email Class Initialized
DEBUG - 2023-08-02 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:41:27 --> Controller Class Initialized
INFO - 2023-08-02 17:41:27 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:41:27 --> Helper loaded: form_helper
INFO - 2023-08-02 17:41:27 --> Form Validation Class Initialized
INFO - 2023-08-02 17:41:27 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-02 17:41:27 --> Final output sent to browser
DEBUG - 2023-08-02 17:41:27 --> Total execution time: 0.0664
INFO - 2023-08-02 17:41:27 --> Config Class Initialized
INFO - 2023-08-02 17:41:27 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:27 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:27 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:27 --> URI Class Initialized
INFO - 2023-08-02 17:41:27 --> Router Class Initialized
INFO - 2023-08-02 17:41:27 --> Output Class Initialized
INFO - 2023-08-02 17:41:27 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:27 --> Input Class Initialized
INFO - 2023-08-02 17:41:27 --> Language Class Initialized
ERROR - 2023-08-02 17:41:27 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:41:47 --> Config Class Initialized
INFO - 2023-08-02 17:41:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:41:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:41:47 --> Utf8 Class Initialized
INFO - 2023-08-02 17:41:47 --> URI Class Initialized
INFO - 2023-08-02 17:41:47 --> Router Class Initialized
INFO - 2023-08-02 17:41:47 --> Output Class Initialized
INFO - 2023-08-02 17:41:47 --> Security Class Initialized
DEBUG - 2023-08-02 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:41:47 --> Input Class Initialized
INFO - 2023-08-02 17:41:47 --> Language Class Initialized
INFO - 2023-08-02 17:41:47 --> Loader Class Initialized
INFO - 2023-08-02 17:41:47 --> Helper loaded: url_helper
INFO - 2023-08-02 17:41:47 --> Helper loaded: file_helper
INFO - 2023-08-02 17:41:47 --> Database Driver Class Initialized
INFO - 2023-08-02 17:41:47 --> Email Class Initialized
DEBUG - 2023-08-02 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:41:47 --> Controller Class Initialized
INFO - 2023-08-02 17:41:47 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:41:47 --> Helper loaded: form_helper
INFO - 2023-08-02 17:41:47 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:41:47 --> Severity: error --> Exception: Call to undefined method Faq_model::get_all_pages() C:\xampp\htdocs\DW\application\controllers\Admin\FAQ.php 60
INFO - 2023-08-02 17:42:04 --> Config Class Initialized
INFO - 2023-08-02 17:42:04 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:42:04 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:42:04 --> Utf8 Class Initialized
INFO - 2023-08-02 17:42:04 --> URI Class Initialized
INFO - 2023-08-02 17:42:04 --> Router Class Initialized
INFO - 2023-08-02 17:42:04 --> Output Class Initialized
INFO - 2023-08-02 17:42:04 --> Security Class Initialized
DEBUG - 2023-08-02 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:42:04 --> Input Class Initialized
INFO - 2023-08-02 17:42:04 --> Language Class Initialized
INFO - 2023-08-02 17:42:04 --> Loader Class Initialized
INFO - 2023-08-02 17:42:04 --> Helper loaded: url_helper
INFO - 2023-08-02 17:42:04 --> Helper loaded: file_helper
INFO - 2023-08-02 17:42:04 --> Database Driver Class Initialized
INFO - 2023-08-02 17:42:04 --> Email Class Initialized
DEBUG - 2023-08-02 17:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:42:04 --> Controller Class Initialized
INFO - 2023-08-02 17:42:04 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:42:04 --> Helper loaded: form_helper
INFO - 2023-08-02 17:42:04 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:42:04 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:04 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:04 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
INFO - 2023-08-02 17:42:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:42:05 --> Final output sent to browser
DEBUG - 2023-08-02 17:42:05 --> Total execution time: 0.5315
INFO - 2023-08-02 17:42:05 --> Config Class Initialized
INFO - 2023-08-02 17:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:42:05 --> Utf8 Class Initialized
INFO - 2023-08-02 17:42:05 --> URI Class Initialized
INFO - 2023-08-02 17:42:05 --> Router Class Initialized
INFO - 2023-08-02 17:42:05 --> Output Class Initialized
INFO - 2023-08-02 17:42:05 --> Security Class Initialized
DEBUG - 2023-08-02 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:42:05 --> Input Class Initialized
INFO - 2023-08-02 17:42:05 --> Language Class Initialized
INFO - 2023-08-02 17:42:05 --> Loader Class Initialized
INFO - 2023-08-02 17:42:05 --> Helper loaded: url_helper
INFO - 2023-08-02 17:42:05 --> Helper loaded: file_helper
INFO - 2023-08-02 17:42:05 --> Database Driver Class Initialized
INFO - 2023-08-02 17:42:05 --> Email Class Initialized
DEBUG - 2023-08-02 17:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:42:05 --> Controller Class Initialized
INFO - 2023-08-02 17:42:05 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:42:05 --> Helper loaded: form_helper
INFO - 2023-08-02 17:42:05 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
ERROR - 2023-08-02 17:42:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
INFO - 2023-08-02 17:42:05 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:42:06 --> Final output sent to browser
DEBUG - 2023-08-02 17:42:06 --> Total execution time: 0.4988
INFO - 2023-08-02 17:42:06 --> Config Class Initialized
INFO - 2023-08-02 17:42:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:42:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:42:06 --> Utf8 Class Initialized
INFO - 2023-08-02 17:42:06 --> URI Class Initialized
INFO - 2023-08-02 17:42:06 --> Router Class Initialized
INFO - 2023-08-02 17:42:06 --> Output Class Initialized
INFO - 2023-08-02 17:42:06 --> Security Class Initialized
DEBUG - 2023-08-02 17:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:42:06 --> Input Class Initialized
INFO - 2023-08-02 17:42:06 --> Language Class Initialized
INFO - 2023-08-02 17:42:06 --> Loader Class Initialized
INFO - 2023-08-02 17:42:06 --> Helper loaded: url_helper
INFO - 2023-08-02 17:42:06 --> Helper loaded: file_helper
INFO - 2023-08-02 17:42:06 --> Database Driver Class Initialized
INFO - 2023-08-02 17:42:06 --> Email Class Initialized
DEBUG - 2023-08-02 17:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:42:06 --> Controller Class Initialized
INFO - 2023-08-02 17:42:06 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:42:06 --> Helper loaded: form_helper
INFO - 2023-08-02 17:42:06 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 39
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 48
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 58
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 59
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 72
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 73
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 83
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 99
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Undefined variable $banner C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
ERROR - 2023-08-02 17:42:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 111
INFO - 2023-08-02 17:42:06 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:42:06 --> Final output sent to browser
DEBUG - 2023-08-02 17:42:06 --> Total execution time: 0.0755
INFO - 2023-08-02 17:43:47 --> Config Class Initialized
INFO - 2023-08-02 17:43:47 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:47 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:47 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:47 --> URI Class Initialized
INFO - 2023-08-02 17:43:47 --> Router Class Initialized
INFO - 2023-08-02 17:43:47 --> Output Class Initialized
INFO - 2023-08-02 17:43:47 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:47 --> Input Class Initialized
INFO - 2023-08-02 17:43:47 --> Language Class Initialized
INFO - 2023-08-02 17:43:47 --> Loader Class Initialized
INFO - 2023-08-02 17:43:47 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:47 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:47 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:47 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:47 --> Controller Class Initialized
INFO - 2023-08-02 17:43:47 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:47 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:47 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
INFO - 2023-08-02 17:43:48 --> Config Class Initialized
INFO - 2023-08-02 17:43:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:48 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:48 --> URI Class Initialized
INFO - 2023-08-02 17:43:48 --> Router Class Initialized
INFO - 2023-08-02 17:43:48 --> Output Class Initialized
INFO - 2023-08-02 17:43:48 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:48 --> Input Class Initialized
INFO - 2023-08-02 17:43:48 --> Language Class Initialized
INFO - 2023-08-02 17:43:48 --> Loader Class Initialized
INFO - 2023-08-02 17:43:48 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:48 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:48 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:48 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:48 --> Controller Class Initialized
INFO - 2023-08-02 17:43:48 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:48 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:48 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:48 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:48 --> Total execution time: 0.2522
INFO - 2023-08-02 17:43:48 --> Config Class Initialized
INFO - 2023-08-02 17:43:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:48 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:48 --> URI Class Initialized
INFO - 2023-08-02 17:43:48 --> Router Class Initialized
INFO - 2023-08-02 17:43:48 --> Output Class Initialized
INFO - 2023-08-02 17:43:48 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:48 --> Input Class Initialized
INFO - 2023-08-02 17:43:48 --> Language Class Initialized
INFO - 2023-08-02 17:43:48 --> Loader Class Initialized
INFO - 2023-08-02 17:43:48 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:48 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:48 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:48 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:48 --> Controller Class Initialized
INFO - 2023-08-02 17:43:48 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:48 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:48 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:48 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:48 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:48 --> Total execution time: 0.0578
INFO - 2023-08-02 17:43:50 --> Config Class Initialized
INFO - 2023-08-02 17:43:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:50 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:50 --> URI Class Initialized
INFO - 2023-08-02 17:43:50 --> Router Class Initialized
INFO - 2023-08-02 17:43:50 --> Output Class Initialized
INFO - 2023-08-02 17:43:50 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:50 --> Input Class Initialized
INFO - 2023-08-02 17:43:50 --> Language Class Initialized
INFO - 2023-08-02 17:43:50 --> Loader Class Initialized
INFO - 2023-08-02 17:43:50 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:50 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:50 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:50 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:50 --> Controller Class Initialized
INFO - 2023-08-02 17:43:50 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:50 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:50 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:50 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
INFO - 2023-08-02 17:43:50 --> Config Class Initialized
INFO - 2023-08-02 17:43:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:50 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:50 --> URI Class Initialized
INFO - 2023-08-02 17:43:50 --> Router Class Initialized
INFO - 2023-08-02 17:43:50 --> Output Class Initialized
INFO - 2023-08-02 17:43:50 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:50 --> Input Class Initialized
INFO - 2023-08-02 17:43:50 --> Language Class Initialized
INFO - 2023-08-02 17:43:50 --> Loader Class Initialized
INFO - 2023-08-02 17:43:50 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:50 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:50 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:50 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:50 --> Controller Class Initialized
INFO - 2023-08-02 17:43:50 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:50 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:50 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:50 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:50 --> Total execution time: 0.0551
INFO - 2023-08-02 17:43:50 --> Config Class Initialized
INFO - 2023-08-02 17:43:50 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:50 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:50 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:50 --> URI Class Initialized
INFO - 2023-08-02 17:43:50 --> Router Class Initialized
INFO - 2023-08-02 17:43:50 --> Output Class Initialized
INFO - 2023-08-02 17:43:50 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:50 --> Input Class Initialized
INFO - 2023-08-02 17:43:50 --> Language Class Initialized
INFO - 2023-08-02 17:43:51 --> Loader Class Initialized
INFO - 2023-08-02 17:43:51 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:51 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:51 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:51 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:51 --> Controller Class Initialized
INFO - 2023-08-02 17:43:51 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:51 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:51 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:51 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:51 --> Total execution time: 0.0585
INFO - 2023-08-02 17:43:51 --> Config Class Initialized
INFO - 2023-08-02 17:43:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:51 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:51 --> URI Class Initialized
INFO - 2023-08-02 17:43:51 --> Router Class Initialized
INFO - 2023-08-02 17:43:51 --> Output Class Initialized
INFO - 2023-08-02 17:43:51 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:51 --> Input Class Initialized
INFO - 2023-08-02 17:43:51 --> Language Class Initialized
INFO - 2023-08-02 17:43:51 --> Loader Class Initialized
INFO - 2023-08-02 17:43:51 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:51 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:51 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:51 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:51 --> Controller Class Initialized
INFO - 2023-08-02 17:43:51 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:51 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:51 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
INFO - 2023-08-02 17:43:52 --> Config Class Initialized
INFO - 2023-08-02 17:43:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:52 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:52 --> URI Class Initialized
INFO - 2023-08-02 17:43:52 --> Router Class Initialized
INFO - 2023-08-02 17:43:52 --> Output Class Initialized
INFO - 2023-08-02 17:43:52 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:52 --> Input Class Initialized
INFO - 2023-08-02 17:43:52 --> Language Class Initialized
INFO - 2023-08-02 17:43:52 --> Loader Class Initialized
INFO - 2023-08-02 17:43:52 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:52 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:52 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:52 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:52 --> Controller Class Initialized
INFO - 2023-08-02 17:43:52 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:52 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:52 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:52 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:52 --> Total execution time: 0.0688
INFO - 2023-08-02 17:43:52 --> Config Class Initialized
INFO - 2023-08-02 17:43:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:43:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:43:52 --> Utf8 Class Initialized
INFO - 2023-08-02 17:43:52 --> URI Class Initialized
INFO - 2023-08-02 17:43:52 --> Router Class Initialized
INFO - 2023-08-02 17:43:52 --> Output Class Initialized
INFO - 2023-08-02 17:43:52 --> Security Class Initialized
DEBUG - 2023-08-02 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:43:52 --> Input Class Initialized
INFO - 2023-08-02 17:43:52 --> Language Class Initialized
INFO - 2023-08-02 17:43:52 --> Loader Class Initialized
INFO - 2023-08-02 17:43:52 --> Helper loaded: url_helper
INFO - 2023-08-02 17:43:52 --> Helper loaded: file_helper
INFO - 2023-08-02 17:43:52 --> Database Driver Class Initialized
INFO - 2023-08-02 17:43:52 --> Email Class Initialized
DEBUG - 2023-08-02 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:43:52 --> Controller Class Initialized
INFO - 2023-08-02 17:43:52 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:43:52 --> Helper loaded: form_helper
INFO - 2023-08-02 17:43:52 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:43:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:43:52 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:43:52 --> Final output sent to browser
DEBUG - 2023-08-02 17:43:52 --> Total execution time: 0.0773
INFO - 2023-08-02 17:44:48 --> Config Class Initialized
INFO - 2023-08-02 17:44:48 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:44:48 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:44:48 --> Utf8 Class Initialized
INFO - 2023-08-02 17:44:48 --> URI Class Initialized
INFO - 2023-08-02 17:44:48 --> Router Class Initialized
INFO - 2023-08-02 17:44:48 --> Output Class Initialized
INFO - 2023-08-02 17:44:48 --> Security Class Initialized
DEBUG - 2023-08-02 17:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:44:48 --> Input Class Initialized
INFO - 2023-08-02 17:44:48 --> Language Class Initialized
INFO - 2023-08-02 17:44:48 --> Loader Class Initialized
INFO - 2023-08-02 17:44:48 --> Helper loaded: url_helper
INFO - 2023-08-02 17:44:48 --> Helper loaded: file_helper
INFO - 2023-08-02 17:44:48 --> Database Driver Class Initialized
INFO - 2023-08-02 17:44:48 --> Email Class Initialized
DEBUG - 2023-08-02 17:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:44:49 --> Controller Class Initialized
INFO - 2023-08-02 17:44:49 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:44:49 --> Helper loaded: form_helper
INFO - 2023-08-02 17:44:49 --> Form Validation Class Initialized
INFO - 2023-08-02 17:44:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:44:49 --> Final output sent to browser
DEBUG - 2023-08-02 17:44:49 --> Total execution time: 0.5604
INFO - 2023-08-02 17:44:49 --> Config Class Initialized
INFO - 2023-08-02 17:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:44:49 --> Utf8 Class Initialized
INFO - 2023-08-02 17:44:49 --> URI Class Initialized
INFO - 2023-08-02 17:44:49 --> Router Class Initialized
INFO - 2023-08-02 17:44:49 --> Output Class Initialized
INFO - 2023-08-02 17:44:49 --> Security Class Initialized
DEBUG - 2023-08-02 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:44:49 --> Input Class Initialized
INFO - 2023-08-02 17:44:49 --> Language Class Initialized
INFO - 2023-08-02 17:44:49 --> Loader Class Initialized
INFO - 2023-08-02 17:44:49 --> Helper loaded: url_helper
INFO - 2023-08-02 17:44:49 --> Helper loaded: file_helper
INFO - 2023-08-02 17:44:49 --> Database Driver Class Initialized
INFO - 2023-08-02 17:44:49 --> Email Class Initialized
DEBUG - 2023-08-02 17:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:44:49 --> Controller Class Initialized
INFO - 2023-08-02 17:44:49 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:44:49 --> Helper loaded: form_helper
INFO - 2023-08-02 17:44:49 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:44:49 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:44:49 --> Final output sent to browser
INFO - 2023-08-02 17:44:49 --> Config Class Initialized
INFO - 2023-08-02 17:44:49 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:44:49 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:44:49 --> Utf8 Class Initialized
INFO - 2023-08-02 17:44:49 --> URI Class Initialized
INFO - 2023-08-02 17:44:49 --> Router Class Initialized
INFO - 2023-08-02 17:44:49 --> Output Class Initialized
INFO - 2023-08-02 17:44:49 --> Security Class Initialized
DEBUG - 2023-08-02 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:44:49 --> Input Class Initialized
INFO - 2023-08-02 17:44:49 --> Language Class Initialized
INFO - 2023-08-02 17:44:49 --> Loader Class Initialized
INFO - 2023-08-02 17:44:49 --> Helper loaded: url_helper
INFO - 2023-08-02 17:44:49 --> Helper loaded: file_helper
INFO - 2023-08-02 17:44:49 --> Database Driver Class Initialized
INFO - 2023-08-02 17:44:49 --> Email Class Initialized
DEBUG - 2023-08-02 17:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-02 17:44:50 --> Total execution time: 0.3741
INFO - 2023-08-02 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:44:50 --> Controller Class Initialized
INFO - 2023-08-02 17:44:50 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:44:50 --> Helper loaded: form_helper
INFO - 2023-08-02 17:44:50 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 40
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 49
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 50
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 60
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 71
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 80
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 81
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 82
ERROR - 2023-08-02 17:44:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\faq_edit.php 95
INFO - 2023-08-02 17:44:50 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_edit.php
INFO - 2023-08-02 17:44:50 --> Final output sent to browser
DEBUG - 2023-08-02 17:44:50 --> Total execution time: 0.0984
INFO - 2023-08-02 17:45:00 --> Config Class Initialized
INFO - 2023-08-02 17:45:00 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:45:00 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:45:00 --> Utf8 Class Initialized
INFO - 2023-08-02 17:45:00 --> URI Class Initialized
INFO - 2023-08-02 17:45:00 --> Router Class Initialized
INFO - 2023-08-02 17:45:00 --> Output Class Initialized
INFO - 2023-08-02 17:45:00 --> Security Class Initialized
DEBUG - 2023-08-02 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:45:01 --> Input Class Initialized
INFO - 2023-08-02 17:45:01 --> Language Class Initialized
INFO - 2023-08-02 17:45:01 --> Loader Class Initialized
INFO - 2023-08-02 17:45:01 --> Helper loaded: url_helper
INFO - 2023-08-02 17:45:01 --> Helper loaded: file_helper
INFO - 2023-08-02 17:45:01 --> Database Driver Class Initialized
INFO - 2023-08-02 17:45:01 --> Email Class Initialized
DEBUG - 2023-08-02 17:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:45:01 --> Controller Class Initialized
INFO - 2023-08-02 17:45:01 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:45:01 --> Helper loaded: form_helper
INFO - 2023-08-02 17:45:01 --> Form Validation Class Initialized
INFO - 2023-08-02 17:45:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:45:01 --> Config Class Initialized
INFO - 2023-08-02 17:45:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:45:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:45:01 --> Utf8 Class Initialized
INFO - 2023-08-02 17:45:01 --> URI Class Initialized
INFO - 2023-08-02 17:45:01 --> Router Class Initialized
INFO - 2023-08-02 17:45:01 --> Output Class Initialized
INFO - 2023-08-02 17:45:01 --> Security Class Initialized
DEBUG - 2023-08-02 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:45:01 --> Input Class Initialized
INFO - 2023-08-02 17:45:01 --> Language Class Initialized
INFO - 2023-08-02 17:45:01 --> Loader Class Initialized
INFO - 2023-08-02 17:45:01 --> Helper loaded: url_helper
INFO - 2023-08-02 17:45:01 --> Helper loaded: file_helper
INFO - 2023-08-02 17:45:01 --> Database Driver Class Initialized
INFO - 2023-08-02 17:45:01 --> Email Class Initialized
DEBUG - 2023-08-02 17:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:45:01 --> Controller Class Initialized
INFO - 2023-08-02 17:45:01 --> Model "Faq_model" initialized
INFO - 2023-08-02 17:45:01 --> Helper loaded: form_helper
INFO - 2023-08-02 17:45:01 --> Form Validation Class Initialized
INFO - 2023-08-02 17:45:01 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/faq_list.php
INFO - 2023-08-02 17:45:01 --> Final output sent to browser
DEBUG - 2023-08-02 17:45:01 --> Total execution time: 0.0741
INFO - 2023-08-02 17:45:01 --> Config Class Initialized
INFO - 2023-08-02 17:45:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:45:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:45:01 --> Utf8 Class Initialized
INFO - 2023-08-02 17:45:01 --> URI Class Initialized
INFO - 2023-08-02 17:45:01 --> Router Class Initialized
INFO - 2023-08-02 17:45:01 --> Output Class Initialized
INFO - 2023-08-02 17:45:01 --> Security Class Initialized
DEBUG - 2023-08-02 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:45:01 --> Input Class Initialized
INFO - 2023-08-02 17:45:01 --> Language Class Initialized
ERROR - 2023-08-02 17:45:01 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:50:42 --> Config Class Initialized
INFO - 2023-08-02 17:50:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:50:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:50:42 --> Utf8 Class Initialized
INFO - 2023-08-02 17:50:42 --> URI Class Initialized
INFO - 2023-08-02 17:50:42 --> Router Class Initialized
INFO - 2023-08-02 17:50:42 --> Output Class Initialized
INFO - 2023-08-02 17:50:42 --> Security Class Initialized
DEBUG - 2023-08-02 17:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:50:43 --> Input Class Initialized
INFO - 2023-08-02 17:50:43 --> Language Class Initialized
INFO - 2023-08-02 17:50:43 --> Loader Class Initialized
INFO - 2023-08-02 17:50:43 --> Helper loaded: url_helper
INFO - 2023-08-02 17:50:43 --> Helper loaded: file_helper
INFO - 2023-08-02 17:50:43 --> Database Driver Class Initialized
INFO - 2023-08-02 17:50:43 --> Email Class Initialized
DEBUG - 2023-08-02 17:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:50:43 --> Controller Class Initialized
INFO - 2023-08-02 17:50:43 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:50:43 --> Helper loaded: form_helper
INFO - 2023-08-02 17:50:43 --> Form Validation Class Initialized
INFO - 2023-08-02 17:50:43 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-02 17:50:43 --> Final output sent to browser
DEBUG - 2023-08-02 17:50:43 --> Total execution time: 0.4765
INFO - 2023-08-02 17:50:43 --> Config Class Initialized
INFO - 2023-08-02 17:50:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:50:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:50:43 --> Utf8 Class Initialized
INFO - 2023-08-02 17:50:43 --> URI Class Initialized
INFO - 2023-08-02 17:50:43 --> Router Class Initialized
INFO - 2023-08-02 17:50:43 --> Output Class Initialized
INFO - 2023-08-02 17:50:43 --> Security Class Initialized
DEBUG - 2023-08-02 17:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:50:43 --> Input Class Initialized
INFO - 2023-08-02 17:50:43 --> Language Class Initialized
ERROR - 2023-08-02 17:50:43 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-02 17:50:43 --> Config Class Initialized
INFO - 2023-08-02 17:50:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:50:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:50:43 --> Utf8 Class Initialized
INFO - 2023-08-02 17:50:43 --> URI Class Initialized
INFO - 2023-08-02 17:50:43 --> Router Class Initialized
INFO - 2023-08-02 17:50:43 --> Output Class Initialized
INFO - 2023-08-02 17:50:43 --> Security Class Initialized
DEBUG - 2023-08-02 17:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:50:43 --> Input Class Initialized
INFO - 2023-08-02 17:50:43 --> Language Class Initialized
ERROR - 2023-08-02 17:50:43 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-02 17:51:57 --> Config Class Initialized
INFO - 2023-08-02 17:51:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:51:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:51:57 --> Utf8 Class Initialized
INFO - 2023-08-02 17:51:57 --> URI Class Initialized
INFO - 2023-08-02 17:51:57 --> Router Class Initialized
INFO - 2023-08-02 17:51:57 --> Output Class Initialized
INFO - 2023-08-02 17:51:57 --> Security Class Initialized
DEBUG - 2023-08-02 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:51:57 --> Input Class Initialized
INFO - 2023-08-02 17:51:57 --> Language Class Initialized
INFO - 2023-08-02 17:51:57 --> Loader Class Initialized
INFO - 2023-08-02 17:51:57 --> Helper loaded: url_helper
INFO - 2023-08-02 17:51:57 --> Helper loaded: file_helper
INFO - 2023-08-02 17:51:57 --> Database Driver Class Initialized
INFO - 2023-08-02 17:51:57 --> Email Class Initialized
DEBUG - 2023-08-02 17:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:51:57 --> Controller Class Initialized
INFO - 2023-08-02 17:51:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:51:57 --> Helper loaded: form_helper
INFO - 2023-08-02 17:51:57 --> Form Validation Class Initialized
INFO - 2023-08-02 17:51:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:51:57 --> Config Class Initialized
INFO - 2023-08-02 17:51:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:51:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:51:57 --> Utf8 Class Initialized
INFO - 2023-08-02 17:51:57 --> URI Class Initialized
INFO - 2023-08-02 17:51:57 --> Router Class Initialized
INFO - 2023-08-02 17:51:57 --> Output Class Initialized
INFO - 2023-08-02 17:51:57 --> Security Class Initialized
DEBUG - 2023-08-02 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:51:57 --> Input Class Initialized
INFO - 2023-08-02 17:51:57 --> Language Class Initialized
INFO - 2023-08-02 17:51:57 --> Loader Class Initialized
INFO - 2023-08-02 17:51:57 --> Helper loaded: url_helper
INFO - 2023-08-02 17:51:57 --> Helper loaded: file_helper
INFO - 2023-08-02 17:51:57 --> Database Driver Class Initialized
INFO - 2023-08-02 17:51:57 --> Email Class Initialized
DEBUG - 2023-08-02 17:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:51:57 --> Controller Class Initialized
INFO - 2023-08-02 17:51:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:51:57 --> Helper loaded: form_helper
INFO - 2023-08-02 17:51:57 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:51:57 --> Severity: Warning --> Undefined variable $faqs C:\xampp\htdocs\DW\application\views\admin\gallery_list.php 65
ERROR - 2023-08-02 17:51:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\DW\application\views\admin\gallery_list.php 65
INFO - 2023-08-02 17:51:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 17:51:57 --> Final output sent to browser
DEBUG - 2023-08-02 17:51:57 --> Total execution time: 0.0595
INFO - 2023-08-02 17:51:58 --> Config Class Initialized
INFO - 2023-08-02 17:51:58 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:51:58 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:51:58 --> Utf8 Class Initialized
INFO - 2023-08-02 17:51:58 --> URI Class Initialized
INFO - 2023-08-02 17:51:58 --> Router Class Initialized
INFO - 2023-08-02 17:51:58 --> Output Class Initialized
INFO - 2023-08-02 17:51:58 --> Security Class Initialized
DEBUG - 2023-08-02 17:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:51:58 --> Input Class Initialized
INFO - 2023-08-02 17:51:58 --> Language Class Initialized
ERROR - 2023-08-02 17:51:58 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:54:05 --> Config Class Initialized
INFO - 2023-08-02 17:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:05 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:05 --> URI Class Initialized
INFO - 2023-08-02 17:54:05 --> Router Class Initialized
INFO - 2023-08-02 17:54:05 --> Output Class Initialized
INFO - 2023-08-02 17:54:05 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:05 --> Input Class Initialized
INFO - 2023-08-02 17:54:05 --> Language Class Initialized
INFO - 2023-08-02 17:54:05 --> Loader Class Initialized
INFO - 2023-08-02 17:54:05 --> Helper loaded: url_helper
INFO - 2023-08-02 17:54:05 --> Helper loaded: file_helper
INFO - 2023-08-02 17:54:05 --> Database Driver Class Initialized
INFO - 2023-08-02 17:54:05 --> Email Class Initialized
DEBUG - 2023-08-02 17:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:54:05 --> Controller Class Initialized
INFO - 2023-08-02 17:54:05 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:54:05 --> Helper loaded: form_helper
INFO - 2023-08-02 17:54:05 --> Form Validation Class Initialized
ERROR - 2023-08-02 17:54:05 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\gallery_list.php 71
INFO - 2023-08-02 17:54:05 --> Config Class Initialized
INFO - 2023-08-02 17:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:05 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:05 --> URI Class Initialized
INFO - 2023-08-02 17:54:05 --> Router Class Initialized
INFO - 2023-08-02 17:54:05 --> Output Class Initialized
INFO - 2023-08-02 17:54:05 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:05 --> Input Class Initialized
INFO - 2023-08-02 17:54:05 --> Language Class Initialized
ERROR - 2023-08-02 17:54:05 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:54:34 --> Config Class Initialized
INFO - 2023-08-02 17:54:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:34 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:34 --> URI Class Initialized
INFO - 2023-08-02 17:54:34 --> Router Class Initialized
INFO - 2023-08-02 17:54:34 --> Output Class Initialized
INFO - 2023-08-02 17:54:34 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:34 --> Input Class Initialized
INFO - 2023-08-02 17:54:34 --> Language Class Initialized
INFO - 2023-08-02 17:54:34 --> Loader Class Initialized
INFO - 2023-08-02 17:54:34 --> Helper loaded: url_helper
INFO - 2023-08-02 17:54:34 --> Helper loaded: file_helper
INFO - 2023-08-02 17:54:34 --> Database Driver Class Initialized
INFO - 2023-08-02 17:54:34 --> Email Class Initialized
DEBUG - 2023-08-02 17:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:54:34 --> Controller Class Initialized
INFO - 2023-08-02 17:54:34 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:54:34 --> Helper loaded: form_helper
INFO - 2023-08-02 17:54:34 --> Form Validation Class Initialized
INFO - 2023-08-02 17:54:34 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 17:54:34 --> Final output sent to browser
DEBUG - 2023-08-02 17:54:34 --> Total execution time: 0.4383
INFO - 2023-08-02 17:54:34 --> Config Class Initialized
INFO - 2023-08-02 17:54:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:34 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:34 --> URI Class Initialized
INFO - 2023-08-02 17:54:34 --> Router Class Initialized
INFO - 2023-08-02 17:54:34 --> Output Class Initialized
INFO - 2023-08-02 17:54:34 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:34 --> Input Class Initialized
INFO - 2023-08-02 17:54:34 --> Language Class Initialized
ERROR - 2023-08-02 17:54:34 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 17:54:34 --> Config Class Initialized
INFO - 2023-08-02 17:54:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:34 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:34 --> URI Class Initialized
INFO - 2023-08-02 17:54:34 --> Router Class Initialized
INFO - 2023-08-02 17:54:34 --> Output Class Initialized
INFO - 2023-08-02 17:54:34 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:34 --> Input Class Initialized
INFO - 2023-08-02 17:54:34 --> Language Class Initialized
ERROR - 2023-08-02 17:54:34 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:54:51 --> Config Class Initialized
INFO - 2023-08-02 17:54:51 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:51 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:51 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:51 --> URI Class Initialized
INFO - 2023-08-02 17:54:51 --> Router Class Initialized
INFO - 2023-08-02 17:54:51 --> Output Class Initialized
INFO - 2023-08-02 17:54:51 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:51 --> Input Class Initialized
INFO - 2023-08-02 17:54:51 --> Language Class Initialized
INFO - 2023-08-02 17:54:51 --> Loader Class Initialized
INFO - 2023-08-02 17:54:51 --> Helper loaded: url_helper
INFO - 2023-08-02 17:54:51 --> Helper loaded: file_helper
INFO - 2023-08-02 17:54:51 --> Database Driver Class Initialized
INFO - 2023-08-02 17:54:51 --> Email Class Initialized
DEBUG - 2023-08-02 17:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:54:51 --> Controller Class Initialized
INFO - 2023-08-02 17:54:51 --> Model "Banner_model" initialized
INFO - 2023-08-02 17:54:51 --> Helper loaded: form_helper
INFO - 2023-08-02 17:54:51 --> Form Validation Class Initialized
INFO - 2023-08-02 17:54:51 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/banner_create.php
INFO - 2023-08-02 17:54:51 --> Final output sent to browser
DEBUG - 2023-08-02 17:54:51 --> Total execution time: 0.4584
INFO - 2023-08-02 17:54:52 --> Config Class Initialized
INFO - 2023-08-02 17:54:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:52 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:52 --> URI Class Initialized
INFO - 2023-08-02 17:54:52 --> Router Class Initialized
INFO - 2023-08-02 17:54:52 --> Output Class Initialized
INFO - 2023-08-02 17:54:52 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:52 --> Input Class Initialized
INFO - 2023-08-02 17:54:52 --> Language Class Initialized
ERROR - 2023-08-02 17:54:52 --> 404 Page Not Found: admin/Banner/images
INFO - 2023-08-02 17:54:59 --> Config Class Initialized
INFO - 2023-08-02 17:54:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:59 --> URI Class Initialized
INFO - 2023-08-02 17:54:59 --> Router Class Initialized
INFO - 2023-08-02 17:54:59 --> Output Class Initialized
INFO - 2023-08-02 17:54:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:59 --> Input Class Initialized
INFO - 2023-08-02 17:54:59 --> Language Class Initialized
INFO - 2023-08-02 17:54:59 --> Loader Class Initialized
INFO - 2023-08-02 17:54:59 --> Helper loaded: url_helper
INFO - 2023-08-02 17:54:59 --> Helper loaded: file_helper
INFO - 2023-08-02 17:54:59 --> Database Driver Class Initialized
INFO - 2023-08-02 17:54:59 --> Email Class Initialized
DEBUG - 2023-08-02 17:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:54:59 --> Controller Class Initialized
INFO - 2023-08-02 17:54:59 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:54:59 --> Helper loaded: form_helper
INFO - 2023-08-02 17:54:59 --> Form Validation Class Initialized
INFO - 2023-08-02 17:54:59 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-02 17:54:59 --> Final output sent to browser
DEBUG - 2023-08-02 17:54:59 --> Total execution time: 0.4001
INFO - 2023-08-02 17:54:59 --> Config Class Initialized
INFO - 2023-08-02 17:54:59 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:54:59 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:54:59 --> Utf8 Class Initialized
INFO - 2023-08-02 17:54:59 --> URI Class Initialized
INFO - 2023-08-02 17:54:59 --> Router Class Initialized
INFO - 2023-08-02 17:54:59 --> Output Class Initialized
INFO - 2023-08-02 17:54:59 --> Security Class Initialized
DEBUG - 2023-08-02 17:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:54:59 --> Input Class Initialized
INFO - 2023-08-02 17:54:59 --> Language Class Initialized
ERROR - 2023-08-02 17:54:59 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-02 17:55:22 --> Config Class Initialized
INFO - 2023-08-02 17:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:55:22 --> Utf8 Class Initialized
INFO - 2023-08-02 17:55:22 --> URI Class Initialized
INFO - 2023-08-02 17:55:22 --> Router Class Initialized
INFO - 2023-08-02 17:55:22 --> Output Class Initialized
INFO - 2023-08-02 17:55:22 --> Security Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:55:22 --> Input Class Initialized
INFO - 2023-08-02 17:55:22 --> Language Class Initialized
INFO - 2023-08-02 17:55:22 --> Loader Class Initialized
INFO - 2023-08-02 17:55:22 --> Helper loaded: url_helper
INFO - 2023-08-02 17:55:22 --> Helper loaded: file_helper
INFO - 2023-08-02 17:55:22 --> Database Driver Class Initialized
INFO - 2023-08-02 17:55:22 --> Email Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:55:22 --> Controller Class Initialized
INFO - 2023-08-02 17:55:22 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:55:22 --> Helper loaded: form_helper
INFO - 2023-08-02 17:55:22 --> Form Validation Class Initialized
INFO - 2023-08-02 17:55:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 17:55:22 --> Config Class Initialized
INFO - 2023-08-02 17:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:55:22 --> Utf8 Class Initialized
INFO - 2023-08-02 17:55:22 --> URI Class Initialized
INFO - 2023-08-02 17:55:22 --> Router Class Initialized
INFO - 2023-08-02 17:55:22 --> Output Class Initialized
INFO - 2023-08-02 17:55:22 --> Security Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:55:22 --> Input Class Initialized
INFO - 2023-08-02 17:55:22 --> Language Class Initialized
INFO - 2023-08-02 17:55:22 --> Loader Class Initialized
INFO - 2023-08-02 17:55:22 --> Helper loaded: url_helper
INFO - 2023-08-02 17:55:22 --> Helper loaded: file_helper
INFO - 2023-08-02 17:55:22 --> Database Driver Class Initialized
INFO - 2023-08-02 17:55:22 --> Email Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:55:22 --> Controller Class Initialized
INFO - 2023-08-02 17:55:22 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:55:22 --> Helper loaded: form_helper
INFO - 2023-08-02 17:55:22 --> Form Validation Class Initialized
INFO - 2023-08-02 17:55:22 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 17:55:22 --> Final output sent to browser
DEBUG - 2023-08-02 17:55:22 --> Total execution time: 0.0648
INFO - 2023-08-02 17:55:22 --> Config Class Initialized
INFO - 2023-08-02 17:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:55:22 --> Utf8 Class Initialized
INFO - 2023-08-02 17:55:22 --> URI Class Initialized
INFO - 2023-08-02 17:55:22 --> Router Class Initialized
INFO - 2023-08-02 17:55:22 --> Output Class Initialized
INFO - 2023-08-02 17:55:22 --> Security Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:55:22 --> Input Class Initialized
INFO - 2023-08-02 17:55:22 --> Language Class Initialized
ERROR - 2023-08-02 17:55:22 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:55:22 --> Config Class Initialized
INFO - 2023-08-02 17:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:55:22 --> Utf8 Class Initialized
INFO - 2023-08-02 17:55:22 --> URI Class Initialized
INFO - 2023-08-02 17:55:22 --> Router Class Initialized
INFO - 2023-08-02 17:55:22 --> Output Class Initialized
INFO - 2023-08-02 17:55:22 --> Security Class Initialized
DEBUG - 2023-08-02 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:55:22 --> Input Class Initialized
INFO - 2023-08-02 17:55:22 --> Language Class Initialized
ERROR - 2023-08-02 17:55:22 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 17:59:33 --> Config Class Initialized
INFO - 2023-08-02 17:59:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:33 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:33 --> URI Class Initialized
INFO - 2023-08-02 17:59:33 --> Router Class Initialized
INFO - 2023-08-02 17:59:33 --> Output Class Initialized
INFO - 2023-08-02 17:59:33 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:33 --> Input Class Initialized
INFO - 2023-08-02 17:59:33 --> Language Class Initialized
INFO - 2023-08-02 17:59:33 --> Loader Class Initialized
INFO - 2023-08-02 17:59:33 --> Helper loaded: url_helper
INFO - 2023-08-02 17:59:33 --> Helper loaded: file_helper
INFO - 2023-08-02 17:59:33 --> Database Driver Class Initialized
INFO - 2023-08-02 17:59:33 --> Email Class Initialized
DEBUG - 2023-08-02 17:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:59:33 --> Controller Class Initialized
INFO - 2023-08-02 17:59:33 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:59:33 --> Helper loaded: form_helper
INFO - 2023-08-02 17:59:33 --> Form Validation Class Initialized
INFO - 2023-08-02 17:59:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-02 17:59:33 --> Final output sent to browser
DEBUG - 2023-08-02 17:59:33 --> Total execution time: 0.1635
INFO - 2023-08-02 17:59:34 --> Config Class Initialized
INFO - 2023-08-02 17:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:34 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:34 --> URI Class Initialized
INFO - 2023-08-02 17:59:34 --> Router Class Initialized
INFO - 2023-08-02 17:59:34 --> Output Class Initialized
INFO - 2023-08-02 17:59:34 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:34 --> Input Class Initialized
INFO - 2023-08-02 17:59:34 --> Language Class Initialized
ERROR - 2023-08-02 17:59:34 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-02 17:59:53 --> Config Class Initialized
INFO - 2023-08-02 17:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:53 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:53 --> URI Class Initialized
INFO - 2023-08-02 17:59:53 --> Router Class Initialized
INFO - 2023-08-02 17:59:53 --> Output Class Initialized
INFO - 2023-08-02 17:59:53 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:53 --> Input Class Initialized
INFO - 2023-08-02 17:59:53 --> Language Class Initialized
INFO - 2023-08-02 17:59:53 --> Loader Class Initialized
INFO - 2023-08-02 17:59:53 --> Helper loaded: url_helper
INFO - 2023-08-02 17:59:53 --> Helper loaded: file_helper
INFO - 2023-08-02 17:59:53 --> Database Driver Class Initialized
INFO - 2023-08-02 17:59:53 --> Email Class Initialized
DEBUG - 2023-08-02 17:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:59:53 --> Controller Class Initialized
INFO - 2023-08-02 17:59:53 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:59:53 --> Helper loaded: form_helper
INFO - 2023-08-02 17:59:53 --> Form Validation Class Initialized
INFO - 2023-08-02 17:59:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-08-02 17:59:53 --> Severity: Warning --> move_uploaded_file(./assets/images/gallery/1690991993female.jpg): Failed to open stream: No such file or directory C:\xampp\htdocs\DW\application\controllers\Admin\Gallery.php 38
ERROR - 2023-08-02 17:59:53 --> Severity: Warning --> move_uploaded_file(): Unable to move &quot;C:\xampp\tmp\php9779.tmp&quot; to &quot;./assets/images/gallery/1690991993female.jpg&quot; C:\xampp\htdocs\DW\application\controllers\Admin\Gallery.php 38
INFO - 2023-08-02 17:59:54 --> Config Class Initialized
INFO - 2023-08-02 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:54 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:54 --> URI Class Initialized
INFO - 2023-08-02 17:59:54 --> Router Class Initialized
INFO - 2023-08-02 17:59:54 --> Output Class Initialized
INFO - 2023-08-02 17:59:54 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:54 --> Input Class Initialized
INFO - 2023-08-02 17:59:54 --> Language Class Initialized
INFO - 2023-08-02 17:59:54 --> Loader Class Initialized
INFO - 2023-08-02 17:59:54 --> Helper loaded: url_helper
INFO - 2023-08-02 17:59:54 --> Helper loaded: file_helper
INFO - 2023-08-02 17:59:54 --> Database Driver Class Initialized
INFO - 2023-08-02 17:59:54 --> Email Class Initialized
DEBUG - 2023-08-02 17:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 17:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 17:59:54 --> Controller Class Initialized
INFO - 2023-08-02 17:59:54 --> Model "Gallery_model" initialized
INFO - 2023-08-02 17:59:54 --> Helper loaded: form_helper
INFO - 2023-08-02 17:59:54 --> Form Validation Class Initialized
INFO - 2023-08-02 17:59:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 17:59:54 --> Final output sent to browser
DEBUG - 2023-08-02 17:59:54 --> Total execution time: 0.0461
INFO - 2023-08-02 17:59:54 --> Config Class Initialized
INFO - 2023-08-02 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:54 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:54 --> URI Class Initialized
INFO - 2023-08-02 17:59:54 --> Router Class Initialized
INFO - 2023-08-02 17:59:54 --> Output Class Initialized
INFO - 2023-08-02 17:59:54 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:54 --> Input Class Initialized
INFO - 2023-08-02 17:59:54 --> Language Class Initialized
ERROR - 2023-08-02 17:59:54 --> 404 Page Not Found: Assets/images
INFO - 2023-08-02 17:59:54 --> Config Class Initialized
INFO - 2023-08-02 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:54 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:54 --> URI Class Initialized
INFO - 2023-08-02 17:59:54 --> Router Class Initialized
INFO - 2023-08-02 17:59:54 --> Output Class Initialized
INFO - 2023-08-02 17:59:54 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:54 --> Input Class Initialized
INFO - 2023-08-02 17:59:54 --> Language Class Initialized
ERROR - 2023-08-02 17:59:54 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 17:59:54 --> Config Class Initialized
INFO - 2023-08-02 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 17:59:54 --> Utf8 Class Initialized
INFO - 2023-08-02 17:59:54 --> URI Class Initialized
INFO - 2023-08-02 17:59:54 --> Router Class Initialized
INFO - 2023-08-02 17:59:54 --> Output Class Initialized
INFO - 2023-08-02 17:59:54 --> Security Class Initialized
DEBUG - 2023-08-02 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 17:59:54 --> Input Class Initialized
INFO - 2023-08-02 17:59:54 --> Language Class Initialized
ERROR - 2023-08-02 17:59:54 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:01:01 --> Config Class Initialized
INFO - 2023-08-02 18:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:01 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:01 --> URI Class Initialized
INFO - 2023-08-02 18:01:01 --> Router Class Initialized
INFO - 2023-08-02 18:01:01 --> Output Class Initialized
INFO - 2023-08-02 18:01:01 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:02 --> Input Class Initialized
INFO - 2023-08-02 18:01:02 --> Language Class Initialized
INFO - 2023-08-02 18:01:02 --> Loader Class Initialized
INFO - 2023-08-02 18:01:02 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:02 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:02 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:02 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:02 --> Controller Class Initialized
INFO - 2023-08-02 18:01:02 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:02 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:02 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:02 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_create.php
INFO - 2023-08-02 18:01:02 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:02 --> Total execution time: 0.4176
INFO - 2023-08-02 18:01:02 --> Config Class Initialized
INFO - 2023-08-02 18:01:02 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:02 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:02 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:02 --> URI Class Initialized
INFO - 2023-08-02 18:01:02 --> Router Class Initialized
INFO - 2023-08-02 18:01:02 --> Output Class Initialized
INFO - 2023-08-02 18:01:02 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:02 --> Input Class Initialized
INFO - 2023-08-02 18:01:02 --> Language Class Initialized
ERROR - 2023-08-02 18:01:02 --> 404 Page Not Found: admin/Gallery/images
INFO - 2023-08-02 18:01:18 --> Config Class Initialized
INFO - 2023-08-02 18:01:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:18 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:18 --> URI Class Initialized
INFO - 2023-08-02 18:01:18 --> Router Class Initialized
INFO - 2023-08-02 18:01:18 --> Output Class Initialized
INFO - 2023-08-02 18:01:18 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:18 --> Input Class Initialized
INFO - 2023-08-02 18:01:18 --> Language Class Initialized
INFO - 2023-08-02 18:01:18 --> Loader Class Initialized
INFO - 2023-08-02 18:01:18 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:18 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:18 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:18 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:18 --> Controller Class Initialized
INFO - 2023-08-02 18:01:18 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:18 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:18 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:01:18 --> Config Class Initialized
INFO - 2023-08-02 18:01:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:18 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:18 --> URI Class Initialized
INFO - 2023-08-02 18:01:18 --> Router Class Initialized
INFO - 2023-08-02 18:01:18 --> Output Class Initialized
INFO - 2023-08-02 18:01:18 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:18 --> Input Class Initialized
INFO - 2023-08-02 18:01:18 --> Language Class Initialized
INFO - 2023-08-02 18:01:18 --> Loader Class Initialized
INFO - 2023-08-02 18:01:18 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:18 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:18 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:18 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:18 --> Controller Class Initialized
INFO - 2023-08-02 18:01:18 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:18 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:18 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:01:18 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:18 --> Total execution time: 0.1913
INFO - 2023-08-02 18:01:19 --> Config Class Initialized
INFO - 2023-08-02 18:01:19 --> Config Class Initialized
INFO - 2023-08-02 18:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:19 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:19 --> URI Class Initialized
INFO - 2023-08-02 18:01:19 --> Router Class Initialized
INFO - 2023-08-02 18:01:19 --> Output Class Initialized
INFO - 2023-08-02 18:01:19 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:19 --> Input Class Initialized
INFO - 2023-08-02 18:01:19 --> Language Class Initialized
ERROR - 2023-08-02 18:01:19 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:19 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:19 --> URI Class Initialized
INFO - 2023-08-02 18:01:19 --> Router Class Initialized
INFO - 2023-08-02 18:01:19 --> Output Class Initialized
INFO - 2023-08-02 18:01:19 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:19 --> Input Class Initialized
INFO - 2023-08-02 18:01:19 --> Language Class Initialized
ERROR - 2023-08-02 18:01:19 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:01:19 --> Config Class Initialized
INFO - 2023-08-02 18:01:19 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:19 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:19 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:19 --> URI Class Initialized
INFO - 2023-08-02 18:01:19 --> Router Class Initialized
INFO - 2023-08-02 18:01:19 --> Output Class Initialized
INFO - 2023-08-02 18:01:19 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:19 --> Input Class Initialized
INFO - 2023-08-02 18:01:19 --> Language Class Initialized
ERROR - 2023-08-02 18:01:19 --> 404 Page Not Found: Assets/images
INFO - 2023-08-02 18:01:39 --> Config Class Initialized
INFO - 2023-08-02 18:01:39 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:39 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:39 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:39 --> URI Class Initialized
INFO - 2023-08-02 18:01:39 --> Router Class Initialized
INFO - 2023-08-02 18:01:39 --> Output Class Initialized
INFO - 2023-08-02 18:01:39 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:40 --> Input Class Initialized
INFO - 2023-08-02 18:01:40 --> Language Class Initialized
INFO - 2023-08-02 18:01:40 --> Loader Class Initialized
INFO - 2023-08-02 18:01:40 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:40 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:40 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:40 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:40 --> Controller Class Initialized
INFO - 2023-08-02 18:01:40 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:40 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:40 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:40 --> Config Class Initialized
INFO - 2023-08-02 18:01:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:40 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:40 --> URI Class Initialized
INFO - 2023-08-02 18:01:40 --> Router Class Initialized
INFO - 2023-08-02 18:01:40 --> Output Class Initialized
INFO - 2023-08-02 18:01:40 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:40 --> Input Class Initialized
INFO - 2023-08-02 18:01:40 --> Language Class Initialized
INFO - 2023-08-02 18:01:40 --> Loader Class Initialized
INFO - 2023-08-02 18:01:40 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:40 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:40 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:40 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:40 --> Controller Class Initialized
INFO - 2023-08-02 18:01:40 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:40 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:40 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:01:40 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:40 --> Total execution time: 0.4208
INFO - 2023-08-02 18:01:40 --> Config Class Initialized
INFO - 2023-08-02 18:01:40 --> Config Class Initialized
INFO - 2023-08-02 18:01:40 --> Hooks Class Initialized
INFO - 2023-08-02 18:01:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-02 18:01:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:40 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:41 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:41 --> URI Class Initialized
INFO - 2023-08-02 18:01:41 --> URI Class Initialized
INFO - 2023-08-02 18:01:41 --> Router Class Initialized
INFO - 2023-08-02 18:01:41 --> Router Class Initialized
INFO - 2023-08-02 18:01:41 --> Output Class Initialized
INFO - 2023-08-02 18:01:41 --> Output Class Initialized
INFO - 2023-08-02 18:01:41 --> Security Class Initialized
INFO - 2023-08-02 18:01:41 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-02 18:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:41 --> Input Class Initialized
INFO - 2023-08-02 18:01:41 --> Input Class Initialized
INFO - 2023-08-02 18:01:41 --> Language Class Initialized
INFO - 2023-08-02 18:01:41 --> Language Class Initialized
ERROR - 2023-08-02 18:01:41 --> 404 Page Not Found: admin/Images/faces
ERROR - 2023-08-02 18:01:41 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:01:45 --> Config Class Initialized
INFO - 2023-08-02 18:01:45 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:45 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:45 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:45 --> URI Class Initialized
INFO - 2023-08-02 18:01:45 --> Router Class Initialized
INFO - 2023-08-02 18:01:45 --> Output Class Initialized
INFO - 2023-08-02 18:01:45 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:45 --> Input Class Initialized
INFO - 2023-08-02 18:01:45 --> Language Class Initialized
INFO - 2023-08-02 18:01:45 --> Loader Class Initialized
INFO - 2023-08-02 18:01:45 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:45 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:45 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:45 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:45 --> Controller Class Initialized
INFO - 2023-08-02 18:01:45 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:45 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:45 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:45 --> Config Class Initialized
INFO - 2023-08-02 18:01:45 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:45 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:45 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:45 --> URI Class Initialized
INFO - 2023-08-02 18:01:45 --> Router Class Initialized
INFO - 2023-08-02 18:01:45 --> Output Class Initialized
INFO - 2023-08-02 18:01:45 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:45 --> Input Class Initialized
INFO - 2023-08-02 18:01:45 --> Language Class Initialized
INFO - 2023-08-02 18:01:45 --> Loader Class Initialized
INFO - 2023-08-02 18:01:45 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:45 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:45 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:45 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:45 --> Controller Class Initialized
INFO - 2023-08-02 18:01:45 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:46 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:46 --> Form Validation Class Initialized
INFO - 2023-08-02 18:01:46 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:01:46 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:46 --> Total execution time: 0.1092
INFO - 2023-08-02 18:01:46 --> Config Class Initialized
INFO - 2023-08-02 18:01:46 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:46 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:46 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:46 --> URI Class Initialized
INFO - 2023-08-02 18:01:46 --> Router Class Initialized
INFO - 2023-08-02 18:01:46 --> Output Class Initialized
INFO - 2023-08-02 18:01:46 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:46 --> Input Class Initialized
INFO - 2023-08-02 18:01:46 --> Language Class Initialized
ERROR - 2023-08-02 18:01:46 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:01:46 --> Config Class Initialized
INFO - 2023-08-02 18:01:46 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:46 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:46 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:46 --> URI Class Initialized
INFO - 2023-08-02 18:01:46 --> Router Class Initialized
INFO - 2023-08-02 18:01:46 --> Output Class Initialized
INFO - 2023-08-02 18:01:46 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:46 --> Input Class Initialized
INFO - 2023-08-02 18:01:46 --> Language Class Initialized
ERROR - 2023-08-02 18:01:46 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:01:54 --> Config Class Initialized
INFO - 2023-08-02 18:01:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:54 --> URI Class Initialized
INFO - 2023-08-02 18:01:54 --> Router Class Initialized
INFO - 2023-08-02 18:01:54 --> Output Class Initialized
INFO - 2023-08-02 18:01:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:54 --> Input Class Initialized
INFO - 2023-08-02 18:01:54 --> Language Class Initialized
INFO - 2023-08-02 18:01:54 --> Loader Class Initialized
INFO - 2023-08-02 18:01:54 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:54 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:54 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:54 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:54 --> Controller Class Initialized
INFO - 2023-08-02 18:01:54 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:54 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:54 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:54 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
INFO - 2023-08-02 18:01:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:01:55 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:55 --> Total execution time: 0.8252
INFO - 2023-08-02 18:01:55 --> Config Class Initialized
INFO - 2023-08-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:55 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:55 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:55 --> URI Class Initialized
INFO - 2023-08-02 18:01:55 --> Router Class Initialized
INFO - 2023-08-02 18:01:55 --> Output Class Initialized
INFO - 2023-08-02 18:01:55 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:55 --> Input Class Initialized
INFO - 2023-08-02 18:01:55 --> Language Class Initialized
INFO - 2023-08-02 18:01:55 --> Loader Class Initialized
INFO - 2023-08-02 18:01:55 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:55 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:55 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:55 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:55 --> Controller Class Initialized
INFO - 2023-08-02 18:01:55 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:55 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:55 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
ERROR - 2023-08-02 18:01:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
INFO - 2023-08-02 18:01:55 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:01:55 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:55 --> Total execution time: 0.4728
INFO - 2023-08-02 18:01:55 --> Config Class Initialized
INFO - 2023-08-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:01:55 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:01:55 --> Utf8 Class Initialized
INFO - 2023-08-02 18:01:55 --> URI Class Initialized
INFO - 2023-08-02 18:01:55 --> Router Class Initialized
INFO - 2023-08-02 18:01:55 --> Output Class Initialized
INFO - 2023-08-02 18:01:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:01:56 --> Input Class Initialized
INFO - 2023-08-02 18:01:56 --> Language Class Initialized
INFO - 2023-08-02 18:01:56 --> Loader Class Initialized
INFO - 2023-08-02 18:01:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:01:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:01:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:01:56 --> Email Class Initialized
DEBUG - 2023-08-02 18:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:01:56 --> Controller Class Initialized
INFO - 2023-08-02 18:01:56 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:01:56 --> Helper loaded: form_helper
INFO - 2023-08-02 18:01:56 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 50
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 71
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 80
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 81
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 82
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Undefined variable $faq C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
ERROR - 2023-08-02 18:01:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 95
INFO - 2023-08-02 18:01:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:01:56 --> Final output sent to browser
DEBUG - 2023-08-02 18:01:56 --> Total execution time: 0.1344
INFO - 2023-08-02 18:03:32 --> Config Class Initialized
INFO - 2023-08-02 18:03:32 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:32 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:32 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:32 --> URI Class Initialized
INFO - 2023-08-02 18:03:32 --> Router Class Initialized
INFO - 2023-08-02 18:03:32 --> Output Class Initialized
INFO - 2023-08-02 18:03:32 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:32 --> Input Class Initialized
INFO - 2023-08-02 18:03:32 --> Language Class Initialized
INFO - 2023-08-02 18:03:32 --> Loader Class Initialized
INFO - 2023-08-02 18:03:32 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:32 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:32 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:32 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:32 --> Controller Class Initialized
INFO - 2023-08-02 18:03:32 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:32 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:32 --> Form Validation Class Initialized
INFO - 2023-08-02 18:03:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:32 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:32 --> Total execution time: 0.3687
INFO - 2023-08-02 18:03:32 --> Config Class Initialized
INFO - 2023-08-02 18:03:32 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:32 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:32 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:32 --> URI Class Initialized
INFO - 2023-08-02 18:03:32 --> Router Class Initialized
INFO - 2023-08-02 18:03:32 --> Output Class Initialized
INFO - 2023-08-02 18:03:32 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:32 --> Input Class Initialized
INFO - 2023-08-02 18:03:32 --> Language Class Initialized
INFO - 2023-08-02 18:03:32 --> Loader Class Initialized
INFO - 2023-08-02 18:03:32 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:32 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:32 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:32 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:32 --> Controller Class Initialized
INFO - 2023-08-02 18:03:32 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:32 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:32 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 85
ERROR - 2023-08-02 18:03:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 104
INFO - 2023-08-02 18:03:32 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:32 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:32 --> Total execution time: 0.0552
INFO - 2023-08-02 18:03:33 --> Config Class Initialized
INFO - 2023-08-02 18:03:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:33 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:33 --> URI Class Initialized
INFO - 2023-08-02 18:03:33 --> Router Class Initialized
INFO - 2023-08-02 18:03:33 --> Output Class Initialized
INFO - 2023-08-02 18:03:33 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:33 --> Input Class Initialized
INFO - 2023-08-02 18:03:33 --> Language Class Initialized
INFO - 2023-08-02 18:03:33 --> Loader Class Initialized
INFO - 2023-08-02 18:03:33 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:33 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:33 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:33 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:33 --> Controller Class Initialized
INFO - 2023-08-02 18:03:33 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:33 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:33 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 85
ERROR - 2023-08-02 18:03:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 104
INFO - 2023-08-02 18:03:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:33 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:33 --> Total execution time: 0.0620
INFO - 2023-08-02 18:03:56 --> Config Class Initialized
INFO - 2023-08-02 18:03:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:56 --> URI Class Initialized
INFO - 2023-08-02 18:03:56 --> Router Class Initialized
INFO - 2023-08-02 18:03:56 --> Output Class Initialized
INFO - 2023-08-02 18:03:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:56 --> Input Class Initialized
INFO - 2023-08-02 18:03:56 --> Language Class Initialized
INFO - 2023-08-02 18:03:56 --> Loader Class Initialized
INFO - 2023-08-02 18:03:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:56 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:56 --> Controller Class Initialized
INFO - 2023-08-02 18:03:56 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:56 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:56 --> Form Validation Class Initialized
INFO - 2023-08-02 18:03:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:56 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:56 --> Total execution time: 0.3184
INFO - 2023-08-02 18:03:57 --> Config Class Initialized
INFO - 2023-08-02 18:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:57 --> URI Class Initialized
INFO - 2023-08-02 18:03:57 --> Router Class Initialized
INFO - 2023-08-02 18:03:57 --> Output Class Initialized
INFO - 2023-08-02 18:03:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:57 --> Input Class Initialized
INFO - 2023-08-02 18:03:57 --> Language Class Initialized
INFO - 2023-08-02 18:03:57 --> Loader Class Initialized
INFO - 2023-08-02 18:03:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:57 --> Controller Class Initialized
INFO - 2023-08-02 18:03:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:57 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
INFO - 2023-08-02 18:03:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:57 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:57 --> Total execution time: 0.5291
INFO - 2023-08-02 18:03:57 --> Config Class Initialized
INFO - 2023-08-02 18:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:03:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:03:57 --> URI Class Initialized
INFO - 2023-08-02 18:03:57 --> Router Class Initialized
INFO - 2023-08-02 18:03:57 --> Output Class Initialized
INFO - 2023-08-02 18:03:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:03:57 --> Input Class Initialized
INFO - 2023-08-02 18:03:57 --> Language Class Initialized
INFO - 2023-08-02 18:03:57 --> Loader Class Initialized
INFO - 2023-08-02 18:03:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:03:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:03:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:03:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:03:57 --> Controller Class Initialized
INFO - 2023-08-02 18:03:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:03:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:03:57 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:03:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
INFO - 2023-08-02 18:03:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:03:57 --> Final output sent to browser
DEBUG - 2023-08-02 18:03:57 --> Total execution time: 0.0639
INFO - 2023-08-02 18:04:12 --> Config Class Initialized
INFO - 2023-08-02 18:04:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:04:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:04:12 --> Utf8 Class Initialized
INFO - 2023-08-02 18:04:12 --> URI Class Initialized
INFO - 2023-08-02 18:04:12 --> Router Class Initialized
INFO - 2023-08-02 18:04:12 --> Output Class Initialized
INFO - 2023-08-02 18:04:12 --> Security Class Initialized
DEBUG - 2023-08-02 18:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:04:12 --> Input Class Initialized
INFO - 2023-08-02 18:04:12 --> Language Class Initialized
INFO - 2023-08-02 18:04:12 --> Loader Class Initialized
INFO - 2023-08-02 18:04:12 --> Helper loaded: url_helper
INFO - 2023-08-02 18:04:12 --> Helper loaded: file_helper
INFO - 2023-08-02 18:04:12 --> Database Driver Class Initialized
INFO - 2023-08-02 18:04:12 --> Email Class Initialized
DEBUG - 2023-08-02 18:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:04:12 --> Controller Class Initialized
INFO - 2023-08-02 18:04:12 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:04:12 --> Helper loaded: form_helper
INFO - 2023-08-02 18:04:12 --> Form Validation Class Initialized
INFO - 2023-08-02 18:04:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:04:12 --> Config Class Initialized
INFO - 2023-08-02 18:04:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:04:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:04:12 --> Utf8 Class Initialized
INFO - 2023-08-02 18:04:12 --> URI Class Initialized
INFO - 2023-08-02 18:04:12 --> Router Class Initialized
INFO - 2023-08-02 18:04:12 --> Output Class Initialized
INFO - 2023-08-02 18:04:12 --> Security Class Initialized
DEBUG - 2023-08-02 18:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:04:12 --> Input Class Initialized
INFO - 2023-08-02 18:04:12 --> Language Class Initialized
INFO - 2023-08-02 18:04:12 --> Loader Class Initialized
INFO - 2023-08-02 18:04:12 --> Helper loaded: url_helper
INFO - 2023-08-02 18:04:12 --> Helper loaded: file_helper
INFO - 2023-08-02 18:04:12 --> Database Driver Class Initialized
INFO - 2023-08-02 18:04:12 --> Email Class Initialized
DEBUG - 2023-08-02 18:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:04:12 --> Controller Class Initialized
INFO - 2023-08-02 18:04:12 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:04:12 --> Helper loaded: form_helper
INFO - 2023-08-02 18:04:12 --> Form Validation Class Initialized
INFO - 2023-08-02 18:04:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:04:12 --> Final output sent to browser
DEBUG - 2023-08-02 18:04:12 --> Total execution time: 0.0647
INFO - 2023-08-02 18:04:13 --> Config Class Initialized
INFO - 2023-08-02 18:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:04:13 --> Utf8 Class Initialized
INFO - 2023-08-02 18:04:13 --> URI Class Initialized
INFO - 2023-08-02 18:04:13 --> Router Class Initialized
INFO - 2023-08-02 18:04:13 --> Output Class Initialized
INFO - 2023-08-02 18:04:13 --> Security Class Initialized
DEBUG - 2023-08-02 18:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:04:13 --> Input Class Initialized
INFO - 2023-08-02 18:04:13 --> Language Class Initialized
ERROR - 2023-08-02 18:04:13 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:04:13 --> Config Class Initialized
INFO - 2023-08-02 18:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:04:13 --> Utf8 Class Initialized
INFO - 2023-08-02 18:04:13 --> URI Class Initialized
INFO - 2023-08-02 18:04:13 --> Router Class Initialized
INFO - 2023-08-02 18:04:13 --> Output Class Initialized
INFO - 2023-08-02 18:04:13 --> Security Class Initialized
DEBUG - 2023-08-02 18:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:04:13 --> Input Class Initialized
INFO - 2023-08-02 18:04:13 --> Language Class Initialized
ERROR - 2023-08-02 18:04:13 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:05:17 --> Config Class Initialized
INFO - 2023-08-02 18:05:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:05:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:05:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:05:17 --> URI Class Initialized
INFO - 2023-08-02 18:05:17 --> Router Class Initialized
INFO - 2023-08-02 18:05:17 --> Output Class Initialized
INFO - 2023-08-02 18:05:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:05:17 --> Input Class Initialized
INFO - 2023-08-02 18:05:17 --> Language Class Initialized
INFO - 2023-08-02 18:05:17 --> Loader Class Initialized
INFO - 2023-08-02 18:05:17 --> Helper loaded: url_helper
INFO - 2023-08-02 18:05:17 --> Helper loaded: file_helper
INFO - 2023-08-02 18:05:17 --> Database Driver Class Initialized
INFO - 2023-08-02 18:05:17 --> Email Class Initialized
DEBUG - 2023-08-02 18:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:05:17 --> Controller Class Initialized
INFO - 2023-08-02 18:05:17 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:05:17 --> Helper loaded: form_helper
INFO - 2023-08-02 18:05:17 --> Form Validation Class Initialized
INFO - 2023-08-02 18:05:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:05:17 --> Final output sent to browser
DEBUG - 2023-08-02 18:05:17 --> Total execution time: 0.1153
INFO - 2023-08-02 18:05:17 --> Config Class Initialized
INFO - 2023-08-02 18:05:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:05:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:05:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:05:17 --> URI Class Initialized
INFO - 2023-08-02 18:05:17 --> Router Class Initialized
INFO - 2023-08-02 18:05:17 --> Output Class Initialized
INFO - 2023-08-02 18:05:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:05:17 --> Input Class Initialized
INFO - 2023-08-02 18:05:17 --> Language Class Initialized
INFO - 2023-08-02 18:05:17 --> Loader Class Initialized
INFO - 2023-08-02 18:05:17 --> Helper loaded: url_helper
INFO - 2023-08-02 18:05:17 --> Helper loaded: file_helper
INFO - 2023-08-02 18:05:17 --> Database Driver Class Initialized
INFO - 2023-08-02 18:05:17 --> Email Class Initialized
DEBUG - 2023-08-02 18:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:05:17 --> Controller Class Initialized
INFO - 2023-08-02 18:05:17 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:05:17 --> Helper loaded: form_helper
INFO - 2023-08-02 18:05:17 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:05:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
INFO - 2023-08-02 18:05:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:05:17 --> Final output sent to browser
DEBUG - 2023-08-02 18:05:17 --> Total execution time: 0.1935
INFO - 2023-08-02 18:05:17 --> Config Class Initialized
INFO - 2023-08-02 18:05:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:05:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:05:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:05:17 --> URI Class Initialized
INFO - 2023-08-02 18:05:17 --> Router Class Initialized
INFO - 2023-08-02 18:05:17 --> Output Class Initialized
INFO - 2023-08-02 18:05:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:05:17 --> Input Class Initialized
INFO - 2023-08-02 18:05:17 --> Language Class Initialized
ERROR - 2023-08-02 18:05:17 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:05:18 --> Config Class Initialized
INFO - 2023-08-02 18:05:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:05:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:05:18 --> Utf8 Class Initialized
INFO - 2023-08-02 18:05:18 --> URI Class Initialized
INFO - 2023-08-02 18:05:18 --> Router Class Initialized
INFO - 2023-08-02 18:05:18 --> Output Class Initialized
INFO - 2023-08-02 18:05:18 --> Security Class Initialized
DEBUG - 2023-08-02 18:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:05:18 --> Input Class Initialized
INFO - 2023-08-02 18:05:18 --> Language Class Initialized
INFO - 2023-08-02 18:05:18 --> Loader Class Initialized
INFO - 2023-08-02 18:05:18 --> Helper loaded: url_helper
INFO - 2023-08-02 18:05:18 --> Helper loaded: file_helper
INFO - 2023-08-02 18:05:18 --> Database Driver Class Initialized
INFO - 2023-08-02 18:05:18 --> Email Class Initialized
DEBUG - 2023-08-02 18:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:05:18 --> Controller Class Initialized
INFO - 2023-08-02 18:05:18 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:05:18 --> Helper loaded: form_helper
INFO - 2023-08-02 18:05:18 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:05:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
INFO - 2023-08-02 18:05:18 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:05:18 --> Final output sent to browser
DEBUG - 2023-08-02 18:05:18 --> Total execution time: 0.0591
INFO - 2023-08-02 18:06:53 --> Config Class Initialized
INFO - 2023-08-02 18:06:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:53 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:53 --> URI Class Initialized
INFO - 2023-08-02 18:06:53 --> Router Class Initialized
INFO - 2023-08-02 18:06:53 --> Output Class Initialized
INFO - 2023-08-02 18:06:53 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:53 --> Input Class Initialized
INFO - 2023-08-02 18:06:53 --> Language Class Initialized
INFO - 2023-08-02 18:06:53 --> Loader Class Initialized
INFO - 2023-08-02 18:06:53 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:53 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:53 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:53 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:53 --> Controller Class Initialized
INFO - 2023-08-02 18:06:53 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:53 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:53 --> Form Validation Class Initialized
INFO - 2023-08-02 18:06:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:54 --> Final output sent to browser
DEBUG - 2023-08-02 18:06:54 --> Total execution time: 0.1843
INFO - 2023-08-02 18:06:54 --> Config Class Initialized
INFO - 2023-08-02 18:06:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:54 --> URI Class Initialized
INFO - 2023-08-02 18:06:54 --> Router Class Initialized
INFO - 2023-08-02 18:06:54 --> Output Class Initialized
INFO - 2023-08-02 18:06:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:54 --> Input Class Initialized
INFO - 2023-08-02 18:06:54 --> Language Class Initialized
INFO - 2023-08-02 18:06:54 --> Loader Class Initialized
INFO - 2023-08-02 18:06:54 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:54 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:54 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:54 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:54 --> Controller Class Initialized
INFO - 2023-08-02 18:06:54 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:54 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:54 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:06:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:54 --> Final output sent to browser
DEBUG - 2023-08-02 18:06:54 --> Total execution time: 0.0828
INFO - 2023-08-02 18:06:54 --> Config Class Initialized
INFO - 2023-08-02 18:06:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:54 --> URI Class Initialized
INFO - 2023-08-02 18:06:54 --> Router Class Initialized
INFO - 2023-08-02 18:06:54 --> Output Class Initialized
INFO - 2023-08-02 18:06:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:54 --> Input Class Initialized
INFO - 2023-08-02 18:06:54 --> Language Class Initialized
ERROR - 2023-08-02 18:06:54 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:06:54 --> Config Class Initialized
INFO - 2023-08-02 18:06:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:54 --> URI Class Initialized
INFO - 2023-08-02 18:06:54 --> Router Class Initialized
INFO - 2023-08-02 18:06:54 --> Output Class Initialized
INFO - 2023-08-02 18:06:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:54 --> Input Class Initialized
INFO - 2023-08-02 18:06:54 --> Language Class Initialized
INFO - 2023-08-02 18:06:54 --> Loader Class Initialized
INFO - 2023-08-02 18:06:54 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:54 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:54 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:54 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:54 --> Controller Class Initialized
INFO - 2023-08-02 18:06:54 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:54 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:54 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:06:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:06:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:54 --> Final output sent to browser
DEBUG - 2023-08-02 18:06:54 --> Total execution time: 0.0603
INFO - 2023-08-02 18:06:56 --> Config Class Initialized
INFO - 2023-08-02 18:06:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:56 --> URI Class Initialized
INFO - 2023-08-02 18:06:56 --> Router Class Initialized
INFO - 2023-08-02 18:06:56 --> Output Class Initialized
INFO - 2023-08-02 18:06:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:56 --> Input Class Initialized
INFO - 2023-08-02 18:06:56 --> Language Class Initialized
INFO - 2023-08-02 18:06:56 --> Loader Class Initialized
INFO - 2023-08-02 18:06:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:56 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:56 --> Controller Class Initialized
INFO - 2023-08-02 18:06:56 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:56 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:56 --> Form Validation Class Initialized
INFO - 2023-08-02 18:06:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:56 --> Final output sent to browser
DEBUG - 2023-08-02 18:06:56 --> Total execution time: 0.0544
INFO - 2023-08-02 18:06:56 --> Config Class Initialized
INFO - 2023-08-02 18:06:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:56 --> URI Class Initialized
INFO - 2023-08-02 18:06:56 --> Router Class Initialized
INFO - 2023-08-02 18:06:56 --> Output Class Initialized
INFO - 2023-08-02 18:06:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:57 --> Input Class Initialized
INFO - 2023-08-02 18:06:57 --> Language Class Initialized
INFO - 2023-08-02 18:06:57 --> Loader Class Initialized
INFO - 2023-08-02 18:06:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:57 --> Controller Class Initialized
INFO - 2023-08-02 18:06:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:57 --> Config Class Initialized
INFO - 2023-08-02 18:06:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:57 --> URI Class Initialized
INFO - 2023-08-02 18:06:57 --> Router Class Initialized
INFO - 2023-08-02 18:06:57 --> Output Class Initialized
INFO - 2023-08-02 18:06:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:57 --> Input Class Initialized
INFO - 2023-08-02 18:06:57 --> Language Class Initialized
ERROR - 2023-08-02 18:06:57 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:06:57 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:06:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:57 --> Final output sent to browser
INFO - 2023-08-02 18:06:57 --> Config Class Initialized
INFO - 2023-08-02 18:06:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:06:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:06:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:06:57 --> URI Class Initialized
INFO - 2023-08-02 18:06:57 --> Router Class Initialized
INFO - 2023-08-02 18:06:57 --> Output Class Initialized
INFO - 2023-08-02 18:06:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:06:57 --> Input Class Initialized
INFO - 2023-08-02 18:06:57 --> Language Class Initialized
INFO - 2023-08-02 18:06:57 --> Loader Class Initialized
INFO - 2023-08-02 18:06:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:06:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:06:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:06:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-08-02 18:06:57 --> Total execution time: 0.4714
INFO - 2023-08-02 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:06:57 --> Controller Class Initialized
INFO - 2023-08-02 18:06:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:06:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:06:57 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:06:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:06:57 --> Final output sent to browser
DEBUG - 2023-08-02 18:06:57 --> Total execution time: 0.0626
INFO - 2023-08-02 18:09:53 --> Config Class Initialized
INFO - 2023-08-02 18:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:09:53 --> Utf8 Class Initialized
INFO - 2023-08-02 18:09:53 --> URI Class Initialized
INFO - 2023-08-02 18:09:53 --> Router Class Initialized
INFO - 2023-08-02 18:09:53 --> Output Class Initialized
INFO - 2023-08-02 18:09:53 --> Security Class Initialized
DEBUG - 2023-08-02 18:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:09:53 --> Input Class Initialized
INFO - 2023-08-02 18:09:53 --> Language Class Initialized
INFO - 2023-08-02 18:09:53 --> Loader Class Initialized
INFO - 2023-08-02 18:09:53 --> Helper loaded: url_helper
INFO - 2023-08-02 18:09:53 --> Helper loaded: file_helper
INFO - 2023-08-02 18:09:53 --> Database Driver Class Initialized
INFO - 2023-08-02 18:09:53 --> Email Class Initialized
DEBUG - 2023-08-02 18:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:09:53 --> Controller Class Initialized
INFO - 2023-08-02 18:09:53 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:09:54 --> Helper loaded: form_helper
INFO - 2023-08-02 18:09:54 --> Form Validation Class Initialized
INFO - 2023-08-02 18:09:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:09:54 --> Config Class Initialized
INFO - 2023-08-02 18:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:09:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:09:54 --> URI Class Initialized
INFO - 2023-08-02 18:09:54 --> Router Class Initialized
INFO - 2023-08-02 18:09:54 --> Output Class Initialized
INFO - 2023-08-02 18:09:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:09:54 --> Input Class Initialized
INFO - 2023-08-02 18:09:54 --> Language Class Initialized
INFO - 2023-08-02 18:09:54 --> Loader Class Initialized
INFO - 2023-08-02 18:09:54 --> Helper loaded: url_helper
INFO - 2023-08-02 18:09:54 --> Helper loaded: file_helper
INFO - 2023-08-02 18:09:54 --> Database Driver Class Initialized
INFO - 2023-08-02 18:09:54 --> Email Class Initialized
DEBUG - 2023-08-02 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:09:54 --> Controller Class Initialized
INFO - 2023-08-02 18:09:54 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:09:54 --> Helper loaded: form_helper
INFO - 2023-08-02 18:09:54 --> Form Validation Class Initialized
INFO - 2023-08-02 18:09:54 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:09:54 --> Final output sent to browser
DEBUG - 2023-08-02 18:09:54 --> Total execution time: 0.0962
INFO - 2023-08-02 18:09:54 --> Config Class Initialized
INFO - 2023-08-02 18:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:09:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:09:54 --> URI Class Initialized
INFO - 2023-08-02 18:09:54 --> Router Class Initialized
INFO - 2023-08-02 18:09:54 --> Output Class Initialized
INFO - 2023-08-02 18:09:54 --> Security Class Initialized
DEBUG - 2023-08-02 18:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:09:54 --> Input Class Initialized
INFO - 2023-08-02 18:09:54 --> Language Class Initialized
ERROR - 2023-08-02 18:09:54 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:09:54 --> Config Class Initialized
INFO - 2023-08-02 18:09:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:09:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:09:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:09:54 --> URI Class Initialized
INFO - 2023-08-02 18:09:54 --> Router Class Initialized
INFO - 2023-08-02 18:09:55 --> Output Class Initialized
INFO - 2023-08-02 18:09:55 --> Security Class Initialized
DEBUG - 2023-08-02 18:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:09:55 --> Input Class Initialized
INFO - 2023-08-02 18:09:55 --> Language Class Initialized
ERROR - 2023-08-02 18:09:55 --> 404 Page Not Found: Your_image_file_path_herejpg/index
INFO - 2023-08-02 18:11:17 --> Config Class Initialized
INFO - 2023-08-02 18:11:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:17 --> URI Class Initialized
INFO - 2023-08-02 18:11:17 --> Router Class Initialized
INFO - 2023-08-02 18:11:17 --> Output Class Initialized
INFO - 2023-08-02 18:11:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:17 --> Input Class Initialized
INFO - 2023-08-02 18:11:17 --> Language Class Initialized
INFO - 2023-08-02 18:11:17 --> Loader Class Initialized
INFO - 2023-08-02 18:11:17 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:17 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:17 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:17 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:17 --> Controller Class Initialized
INFO - 2023-08-02 18:11:17 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:17 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:17 --> Form Validation Class Initialized
INFO - 2023-08-02 18:11:17 --> Config Class Initialized
INFO - 2023-08-02 18:11:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:17 --> URI Class Initialized
INFO - 2023-08-02 18:11:17 --> Router Class Initialized
INFO - 2023-08-02 18:11:17 --> Output Class Initialized
INFO - 2023-08-02 18:11:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:17 --> Input Class Initialized
INFO - 2023-08-02 18:11:17 --> Language Class Initialized
INFO - 2023-08-02 18:11:17 --> Loader Class Initialized
INFO - 2023-08-02 18:11:17 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:17 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:17 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:17 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:17 --> Controller Class Initialized
INFO - 2023-08-02 18:11:17 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:17 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:17 --> Form Validation Class Initialized
INFO - 2023-08-02 18:11:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:11:17 --> Final output sent to browser
DEBUG - 2023-08-02 18:11:17 --> Total execution time: 0.0851
INFO - 2023-08-02 18:11:18 --> Config Class Initialized
INFO - 2023-08-02 18:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:18 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:18 --> URI Class Initialized
INFO - 2023-08-02 18:11:18 --> Router Class Initialized
INFO - 2023-08-02 18:11:18 --> Output Class Initialized
INFO - 2023-08-02 18:11:18 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:18 --> Input Class Initialized
INFO - 2023-08-02 18:11:18 --> Language Class Initialized
ERROR - 2023-08-02 18:11:18 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:11:20 --> Config Class Initialized
INFO - 2023-08-02 18:11:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:20 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:20 --> URI Class Initialized
INFO - 2023-08-02 18:11:20 --> Router Class Initialized
INFO - 2023-08-02 18:11:20 --> Output Class Initialized
INFO - 2023-08-02 18:11:20 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:20 --> Input Class Initialized
INFO - 2023-08-02 18:11:20 --> Language Class Initialized
INFO - 2023-08-02 18:11:20 --> Loader Class Initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:20 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:20 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:20 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:20 --> Controller Class Initialized
INFO - 2023-08-02 18:11:20 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:20 --> Form Validation Class Initialized
INFO - 2023-08-02 18:11:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:11:20 --> Final output sent to browser
DEBUG - 2023-08-02 18:11:20 --> Total execution time: 0.0505
INFO - 2023-08-02 18:11:20 --> Config Class Initialized
INFO - 2023-08-02 18:11:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:20 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:20 --> URI Class Initialized
INFO - 2023-08-02 18:11:20 --> Router Class Initialized
INFO - 2023-08-02 18:11:20 --> Output Class Initialized
INFO - 2023-08-02 18:11:20 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:20 --> Input Class Initialized
INFO - 2023-08-02 18:11:20 --> Language Class Initialized
INFO - 2023-08-02 18:11:20 --> Loader Class Initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:20 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:20 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:20 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:20 --> Controller Class Initialized
INFO - 2023-08-02 18:11:20 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:20 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:11:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:11:20 --> Final output sent to browser
DEBUG - 2023-08-02 18:11:20 --> Total execution time: 0.0570
INFO - 2023-08-02 18:11:20 --> Config Class Initialized
INFO - 2023-08-02 18:11:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:20 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:20 --> URI Class Initialized
INFO - 2023-08-02 18:11:20 --> Router Class Initialized
INFO - 2023-08-02 18:11:20 --> Output Class Initialized
INFO - 2023-08-02 18:11:20 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:20 --> Input Class Initialized
INFO - 2023-08-02 18:11:20 --> Language Class Initialized
INFO - 2023-08-02 18:11:20 --> Loader Class Initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:20 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:20 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:20 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:20 --> Controller Class Initialized
INFO - 2023-08-02 18:11:20 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:20 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:20 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 40
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 49
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 59
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 60
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 61
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 74
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 75
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 76
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 87
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 105
ERROR - 2023-08-02 18:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\DW\application\views\admin\gallery_edit.php 116
INFO - 2023-08-02 18:11:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_edit.php
INFO - 2023-08-02 18:11:20 --> Final output sent to browser
DEBUG - 2023-08-02 18:11:20 --> Total execution time: 0.0480
INFO - 2023-08-02 18:11:56 --> Config Class Initialized
INFO - 2023-08-02 18:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:56 --> URI Class Initialized
INFO - 2023-08-02 18:11:56 --> Router Class Initialized
INFO - 2023-08-02 18:11:56 --> Output Class Initialized
INFO - 2023-08-02 18:11:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:56 --> Input Class Initialized
INFO - 2023-08-02 18:11:56 --> Language Class Initialized
INFO - 2023-08-02 18:11:56 --> Loader Class Initialized
INFO - 2023-08-02 18:11:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:57 --> Controller Class Initialized
INFO - 2023-08-02 18:11:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:57 --> Form Validation Class Initialized
INFO - 2023-08-02 18:11:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:11:57 --> Config Class Initialized
INFO - 2023-08-02 18:11:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:57 --> URI Class Initialized
INFO - 2023-08-02 18:11:57 --> Router Class Initialized
INFO - 2023-08-02 18:11:57 --> Output Class Initialized
INFO - 2023-08-02 18:11:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:57 --> Input Class Initialized
INFO - 2023-08-02 18:11:57 --> Language Class Initialized
INFO - 2023-08-02 18:11:57 --> Loader Class Initialized
INFO - 2023-08-02 18:11:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:11:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:11:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:11:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:11:57 --> Controller Class Initialized
INFO - 2023-08-02 18:11:57 --> Model "Gallery_model" initialized
INFO - 2023-08-02 18:11:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:11:57 --> Form Validation Class Initialized
INFO - 2023-08-02 18:11:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/gallery_list.php
INFO - 2023-08-02 18:11:57 --> Final output sent to browser
DEBUG - 2023-08-02 18:11:57 --> Total execution time: 0.0865
INFO - 2023-08-02 18:11:57 --> Config Class Initialized
INFO - 2023-08-02 18:11:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:11:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:11:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:11:57 --> URI Class Initialized
INFO - 2023-08-02 18:11:57 --> Router Class Initialized
INFO - 2023-08-02 18:11:57 --> Output Class Initialized
INFO - 2023-08-02 18:11:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:11:57 --> Input Class Initialized
INFO - 2023-08-02 18:11:57 --> Language Class Initialized
ERROR - 2023-08-02 18:11:57 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:21:52 --> Config Class Initialized
INFO - 2023-08-02 18:21:52 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:21:52 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:21:52 --> Utf8 Class Initialized
INFO - 2023-08-02 18:21:52 --> URI Class Initialized
INFO - 2023-08-02 18:21:52 --> Router Class Initialized
INFO - 2023-08-02 18:21:52 --> Output Class Initialized
INFO - 2023-08-02 18:21:52 --> Security Class Initialized
DEBUG - 2023-08-02 18:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:21:52 --> Input Class Initialized
INFO - 2023-08-02 18:21:52 --> Language Class Initialized
INFO - 2023-08-02 18:21:52 --> Loader Class Initialized
INFO - 2023-08-02 18:21:52 --> Helper loaded: url_helper
INFO - 2023-08-02 18:21:52 --> Helper loaded: file_helper
INFO - 2023-08-02 18:21:52 --> Database Driver Class Initialized
INFO - 2023-08-02 18:21:52 --> Email Class Initialized
DEBUG - 2023-08-02 18:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:21:52 --> Controller Class Initialized
ERROR - 2023-08-02 18:21:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Key_highlights_model C:\xampp\htdocs\DW\system\core\Loader.php 349
INFO - 2023-08-02 18:21:58 --> Config Class Initialized
INFO - 2023-08-02 18:21:58 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:21:58 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:21:58 --> Utf8 Class Initialized
INFO - 2023-08-02 18:21:58 --> URI Class Initialized
INFO - 2023-08-02 18:21:58 --> Router Class Initialized
INFO - 2023-08-02 18:21:58 --> Output Class Initialized
INFO - 2023-08-02 18:21:58 --> Security Class Initialized
DEBUG - 2023-08-02 18:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:21:58 --> Input Class Initialized
INFO - 2023-08-02 18:21:58 --> Language Class Initialized
INFO - 2023-08-02 18:21:59 --> Loader Class Initialized
INFO - 2023-08-02 18:21:59 --> Helper loaded: url_helper
INFO - 2023-08-02 18:21:59 --> Helper loaded: file_helper
INFO - 2023-08-02 18:21:59 --> Database Driver Class Initialized
INFO - 2023-08-02 18:21:59 --> Email Class Initialized
DEBUG - 2023-08-02 18:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:21:59 --> Controller Class Initialized
ERROR - 2023-08-02 18:21:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Key_highlights_model C:\xampp\htdocs\DW\system\core\Loader.php 349
INFO - 2023-08-02 18:22:42 --> Config Class Initialized
INFO - 2023-08-02 18:22:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:22:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:22:42 --> Utf8 Class Initialized
INFO - 2023-08-02 18:22:42 --> URI Class Initialized
INFO - 2023-08-02 18:22:42 --> Router Class Initialized
INFO - 2023-08-02 18:22:42 --> Output Class Initialized
INFO - 2023-08-02 18:22:42 --> Security Class Initialized
DEBUG - 2023-08-02 18:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:22:42 --> Input Class Initialized
INFO - 2023-08-02 18:22:42 --> Language Class Initialized
INFO - 2023-08-02 18:22:42 --> Loader Class Initialized
INFO - 2023-08-02 18:22:42 --> Helper loaded: url_helper
INFO - 2023-08-02 18:22:42 --> Helper loaded: file_helper
INFO - 2023-08-02 18:22:42 --> Database Driver Class Initialized
INFO - 2023-08-02 18:22:42 --> Email Class Initialized
DEBUG - 2023-08-02 18:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:22:42 --> Controller Class Initialized
INFO - 2023-08-02 18:22:42 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:22:42 --> Helper loaded: form_helper
INFO - 2023-08-02 18:22:42 --> Form Validation Class Initialized
INFO - 2023-08-02 18:22:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-02 18:22:42 --> Final output sent to browser
DEBUG - 2023-08-02 18:22:42 --> Total execution time: 0.2925
INFO - 2023-08-02 18:22:43 --> Config Class Initialized
INFO - 2023-08-02 18:22:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:22:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:22:43 --> Utf8 Class Initialized
INFO - 2023-08-02 18:22:43 --> URI Class Initialized
INFO - 2023-08-02 18:22:43 --> Router Class Initialized
INFO - 2023-08-02 18:22:43 --> Output Class Initialized
INFO - 2023-08-02 18:22:43 --> Security Class Initialized
DEBUG - 2023-08-02 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:22:43 --> Input Class Initialized
INFO - 2023-08-02 18:22:43 --> Language Class Initialized
ERROR - 2023-08-02 18:22:43 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-02 18:22:43 --> Config Class Initialized
INFO - 2023-08-02 18:22:43 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:22:43 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:22:43 --> Utf8 Class Initialized
INFO - 2023-08-02 18:22:43 --> URI Class Initialized
INFO - 2023-08-02 18:22:43 --> Router Class Initialized
INFO - 2023-08-02 18:22:43 --> Output Class Initialized
INFO - 2023-08-02 18:22:43 --> Security Class Initialized
DEBUG - 2023-08-02 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:22:43 --> Input Class Initialized
INFO - 2023-08-02 18:22:43 --> Language Class Initialized
ERROR - 2023-08-02 18:22:43 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-02 18:23:16 --> Config Class Initialized
INFO - 2023-08-02 18:23:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:23:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:23:16 --> Utf8 Class Initialized
INFO - 2023-08-02 18:23:16 --> URI Class Initialized
INFO - 2023-08-02 18:23:16 --> Router Class Initialized
INFO - 2023-08-02 18:23:16 --> Output Class Initialized
INFO - 2023-08-02 18:23:16 --> Security Class Initialized
DEBUG - 2023-08-02 18:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:23:16 --> Input Class Initialized
INFO - 2023-08-02 18:23:16 --> Language Class Initialized
INFO - 2023-08-02 18:23:16 --> Loader Class Initialized
INFO - 2023-08-02 18:23:16 --> Helper loaded: url_helper
INFO - 2023-08-02 18:23:16 --> Helper loaded: file_helper
INFO - 2023-08-02 18:23:16 --> Database Driver Class Initialized
INFO - 2023-08-02 18:23:16 --> Email Class Initialized
DEBUG - 2023-08-02 18:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:23:16 --> Controller Class Initialized
INFO - 2023-08-02 18:23:16 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:23:16 --> Helper loaded: form_helper
INFO - 2023-08-02 18:23:16 --> Form Validation Class Initialized
INFO - 2023-08-02 18:23:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:23:16 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-02 18:23:16 --> Final output sent to browser
DEBUG - 2023-08-02 18:23:16 --> Total execution time: 0.1735
INFO - 2023-08-02 18:23:16 --> Config Class Initialized
INFO - 2023-08-02 18:23:16 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:23:16 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:23:16 --> Utf8 Class Initialized
INFO - 2023-08-02 18:23:16 --> URI Class Initialized
INFO - 2023-08-02 18:23:16 --> Router Class Initialized
INFO - 2023-08-02 18:23:16 --> Output Class Initialized
INFO - 2023-08-02 18:23:16 --> Security Class Initialized
DEBUG - 2023-08-02 18:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:23:16 --> Input Class Initialized
INFO - 2023-08-02 18:23:16 --> Language Class Initialized
ERROR - 2023-08-02 18:23:16 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-02 18:25:06 --> Config Class Initialized
INFO - 2023-08-02 18:25:06 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:25:06 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:25:06 --> Utf8 Class Initialized
INFO - 2023-08-02 18:25:06 --> URI Class Initialized
INFO - 2023-08-02 18:25:06 --> Router Class Initialized
INFO - 2023-08-02 18:25:06 --> Output Class Initialized
INFO - 2023-08-02 18:25:06 --> Security Class Initialized
DEBUG - 2023-08-02 18:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:25:06 --> Input Class Initialized
INFO - 2023-08-02 18:25:06 --> Language Class Initialized
INFO - 2023-08-02 18:25:06 --> Loader Class Initialized
INFO - 2023-08-02 18:25:06 --> Helper loaded: url_helper
INFO - 2023-08-02 18:25:06 --> Helper loaded: file_helper
INFO - 2023-08-02 18:25:06 --> Database Driver Class Initialized
INFO - 2023-08-02 18:25:07 --> Email Class Initialized
DEBUG - 2023-08-02 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:25:07 --> Controller Class Initialized
INFO - 2023-08-02 18:25:07 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:25:07 --> Helper loaded: form_helper
INFO - 2023-08-02 18:25:07 --> Form Validation Class Initialized
INFO - 2023-08-02 18:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:25:07 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_create.php
INFO - 2023-08-02 18:25:07 --> Final output sent to browser
DEBUG - 2023-08-02 18:25:07 --> Total execution time: 0.1615
INFO - 2023-08-02 18:25:07 --> Config Class Initialized
INFO - 2023-08-02 18:25:07 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:25:07 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:25:07 --> Utf8 Class Initialized
INFO - 2023-08-02 18:25:07 --> URI Class Initialized
INFO - 2023-08-02 18:25:07 --> Router Class Initialized
INFO - 2023-08-02 18:25:07 --> Output Class Initialized
INFO - 2023-08-02 18:25:07 --> Security Class Initialized
DEBUG - 2023-08-02 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:25:07 --> Input Class Initialized
INFO - 2023-08-02 18:25:07 --> Language Class Initialized
ERROR - 2023-08-02 18:25:07 --> 404 Page Not Found: admin/Key_highlights/images
INFO - 2023-08-02 18:25:13 --> Config Class Initialized
INFO - 2023-08-02 18:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:25:13 --> Utf8 Class Initialized
INFO - 2023-08-02 18:25:13 --> URI Class Initialized
INFO - 2023-08-02 18:25:13 --> Router Class Initialized
INFO - 2023-08-02 18:25:13 --> Output Class Initialized
INFO - 2023-08-02 18:25:13 --> Security Class Initialized
DEBUG - 2023-08-02 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:25:13 --> Input Class Initialized
INFO - 2023-08-02 18:25:13 --> Language Class Initialized
INFO - 2023-08-02 18:25:13 --> Loader Class Initialized
INFO - 2023-08-02 18:25:13 --> Helper loaded: url_helper
INFO - 2023-08-02 18:25:13 --> Helper loaded: file_helper
INFO - 2023-08-02 18:25:13 --> Database Driver Class Initialized
INFO - 2023-08-02 18:25:13 --> Email Class Initialized
DEBUG - 2023-08-02 18:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:25:13 --> Controller Class Initialized
INFO - 2023-08-02 18:25:13 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:25:13 --> Helper loaded: form_helper
INFO - 2023-08-02 18:25:13 --> Form Validation Class Initialized
INFO - 2023-08-02 18:25:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:25:13 --> Config Class Initialized
INFO - 2023-08-02 18:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:25:13 --> Utf8 Class Initialized
INFO - 2023-08-02 18:25:13 --> URI Class Initialized
INFO - 2023-08-02 18:25:13 --> Router Class Initialized
INFO - 2023-08-02 18:25:13 --> Output Class Initialized
INFO - 2023-08-02 18:25:13 --> Security Class Initialized
DEBUG - 2023-08-02 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:25:13 --> Input Class Initialized
INFO - 2023-08-02 18:25:13 --> Language Class Initialized
INFO - 2023-08-02 18:25:13 --> Loader Class Initialized
INFO - 2023-08-02 18:25:13 --> Helper loaded: url_helper
INFO - 2023-08-02 18:25:13 --> Helper loaded: file_helper
INFO - 2023-08-02 18:25:13 --> Database Driver Class Initialized
INFO - 2023-08-02 18:25:13 --> Email Class Initialized
DEBUG - 2023-08-02 18:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:25:13 --> Controller Class Initialized
INFO - 2023-08-02 18:25:13 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:25:13 --> Helper loaded: form_helper
INFO - 2023-08-02 18:25:13 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:25:13 --> Severity: Warning --> Undefined variable $banners C:\xampp\htdocs\DW\application\views\admin\key_highlights_list.php 66
ERROR - 2023-08-02 18:25:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\DW\application\views\admin\key_highlights_list.php 66
INFO - 2023-08-02 18:25:13 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-02 18:25:13 --> Final output sent to browser
DEBUG - 2023-08-02 18:25:13 --> Total execution time: 0.0637
INFO - 2023-08-02 18:25:14 --> Config Class Initialized
INFO - 2023-08-02 18:25:14 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:25:14 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:25:14 --> Utf8 Class Initialized
INFO - 2023-08-02 18:25:14 --> URI Class Initialized
INFO - 2023-08-02 18:25:14 --> Router Class Initialized
INFO - 2023-08-02 18:25:14 --> Output Class Initialized
INFO - 2023-08-02 18:25:14 --> Security Class Initialized
DEBUG - 2023-08-02 18:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:25:14 --> Input Class Initialized
INFO - 2023-08-02 18:25:14 --> Language Class Initialized
ERROR - 2023-08-02 18:25:14 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:27:03 --> Config Class Initialized
INFO - 2023-08-02 18:27:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:27:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:27:03 --> Utf8 Class Initialized
INFO - 2023-08-02 18:27:03 --> URI Class Initialized
INFO - 2023-08-02 18:27:03 --> Router Class Initialized
INFO - 2023-08-02 18:27:03 --> Output Class Initialized
INFO - 2023-08-02 18:27:03 --> Security Class Initialized
DEBUG - 2023-08-02 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:27:03 --> Input Class Initialized
INFO - 2023-08-02 18:27:03 --> Language Class Initialized
INFO - 2023-08-02 18:27:03 --> Loader Class Initialized
INFO - 2023-08-02 18:27:03 --> Helper loaded: url_helper
INFO - 2023-08-02 18:27:03 --> Helper loaded: file_helper
INFO - 2023-08-02 18:27:03 --> Database Driver Class Initialized
INFO - 2023-08-02 18:27:03 --> Email Class Initialized
DEBUG - 2023-08-02 18:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:27:03 --> Controller Class Initialized
INFO - 2023-08-02 18:27:03 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:27:03 --> Helper loaded: form_helper
INFO - 2023-08-02 18:27:03 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:27:03 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\key_highlights_list.php 70
INFO - 2023-08-02 18:27:03 --> Config Class Initialized
INFO - 2023-08-02 18:27:03 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:27:03 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:27:03 --> Utf8 Class Initialized
INFO - 2023-08-02 18:27:03 --> URI Class Initialized
INFO - 2023-08-02 18:27:03 --> Router Class Initialized
INFO - 2023-08-02 18:27:03 --> Output Class Initialized
INFO - 2023-08-02 18:27:03 --> Security Class Initialized
DEBUG - 2023-08-02 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:27:03 --> Input Class Initialized
INFO - 2023-08-02 18:27:03 --> Language Class Initialized
ERROR - 2023-08-02 18:27:03 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:27:05 --> Config Class Initialized
INFO - 2023-08-02 18:27:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:27:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:27:05 --> Utf8 Class Initialized
INFO - 2023-08-02 18:27:05 --> URI Class Initialized
INFO - 2023-08-02 18:27:05 --> Router Class Initialized
INFO - 2023-08-02 18:27:05 --> Output Class Initialized
INFO - 2023-08-02 18:27:05 --> Security Class Initialized
DEBUG - 2023-08-02 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:27:05 --> Input Class Initialized
INFO - 2023-08-02 18:27:05 --> Language Class Initialized
INFO - 2023-08-02 18:27:05 --> Loader Class Initialized
INFO - 2023-08-02 18:27:05 --> Helper loaded: url_helper
INFO - 2023-08-02 18:27:05 --> Helper loaded: file_helper
INFO - 2023-08-02 18:27:05 --> Database Driver Class Initialized
INFO - 2023-08-02 18:27:05 --> Email Class Initialized
DEBUG - 2023-08-02 18:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:27:05 --> Controller Class Initialized
INFO - 2023-08-02 18:27:05 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:27:05 --> Helper loaded: form_helper
INFO - 2023-08-02 18:27:05 --> Form Validation Class Initialized
ERROR - 2023-08-02 18:27:05 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\DW\application\views\admin\key_highlights_list.php 70
INFO - 2023-08-02 18:27:05 --> Config Class Initialized
INFO - 2023-08-02 18:27:05 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:27:05 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:27:05 --> Utf8 Class Initialized
INFO - 2023-08-02 18:27:05 --> URI Class Initialized
INFO - 2023-08-02 18:27:05 --> Router Class Initialized
INFO - 2023-08-02 18:27:05 --> Output Class Initialized
INFO - 2023-08-02 18:27:05 --> Security Class Initialized
DEBUG - 2023-08-02 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:27:05 --> Input Class Initialized
INFO - 2023-08-02 18:27:05 --> Language Class Initialized
ERROR - 2023-08-02 18:27:05 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:28:17 --> Config Class Initialized
INFO - 2023-08-02 18:28:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:28:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:28:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:28:17 --> URI Class Initialized
INFO - 2023-08-02 18:28:17 --> Router Class Initialized
INFO - 2023-08-02 18:28:17 --> Output Class Initialized
INFO - 2023-08-02 18:28:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:28:17 --> Input Class Initialized
INFO - 2023-08-02 18:28:17 --> Language Class Initialized
INFO - 2023-08-02 18:28:17 --> Loader Class Initialized
INFO - 2023-08-02 18:28:17 --> Helper loaded: url_helper
INFO - 2023-08-02 18:28:17 --> Helper loaded: file_helper
INFO - 2023-08-02 18:28:17 --> Database Driver Class Initialized
INFO - 2023-08-02 18:28:17 --> Email Class Initialized
DEBUG - 2023-08-02 18:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:28:17 --> Controller Class Initialized
INFO - 2023-08-02 18:28:17 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:28:17 --> Helper loaded: form_helper
INFO - 2023-08-02 18:28:17 --> Form Validation Class Initialized
INFO - 2023-08-02 18:28:17 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-02 18:28:17 --> Final output sent to browser
DEBUG - 2023-08-02 18:28:17 --> Total execution time: 0.1980
INFO - 2023-08-02 18:28:17 --> Config Class Initialized
INFO - 2023-08-02 18:28:17 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:28:17 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:28:17 --> Utf8 Class Initialized
INFO - 2023-08-02 18:28:17 --> URI Class Initialized
INFO - 2023-08-02 18:28:17 --> Router Class Initialized
INFO - 2023-08-02 18:28:17 --> Output Class Initialized
INFO - 2023-08-02 18:28:17 --> Security Class Initialized
DEBUG - 2023-08-02 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:28:17 --> Input Class Initialized
INFO - 2023-08-02 18:28:17 --> Language Class Initialized
ERROR - 2023-08-02 18:28:17 --> 404 Page Not Found: admin/Images/faces
INFO - 2023-08-02 18:30:33 --> Config Class Initialized
INFO - 2023-08-02 18:30:33 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:30:33 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:30:33 --> Utf8 Class Initialized
INFO - 2023-08-02 18:30:33 --> URI Class Initialized
INFO - 2023-08-02 18:30:33 --> Router Class Initialized
INFO - 2023-08-02 18:30:33 --> Output Class Initialized
INFO - 2023-08-02 18:30:33 --> Security Class Initialized
DEBUG - 2023-08-02 18:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:30:33 --> Input Class Initialized
INFO - 2023-08-02 18:30:33 --> Language Class Initialized
INFO - 2023-08-02 18:30:33 --> Loader Class Initialized
INFO - 2023-08-02 18:30:33 --> Helper loaded: url_helper
INFO - 2023-08-02 18:30:33 --> Helper loaded: file_helper
INFO - 2023-08-02 18:30:33 --> Database Driver Class Initialized
INFO - 2023-08-02 18:30:33 --> Email Class Initialized
DEBUG - 2023-08-02 18:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:30:33 --> Controller Class Initialized
INFO - 2023-08-02 18:30:33 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:30:33 --> Helper loaded: form_helper
INFO - 2023-08-02 18:30:33 --> Form Validation Class Initialized
INFO - 2023-08-02 18:30:33 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:30:33 --> Final output sent to browser
DEBUG - 2023-08-02 18:30:33 --> Total execution time: 0.0848
INFO - 2023-08-02 18:30:36 --> Config Class Initialized
INFO - 2023-08-02 18:30:36 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:30:36 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:30:36 --> Utf8 Class Initialized
INFO - 2023-08-02 18:30:36 --> URI Class Initialized
INFO - 2023-08-02 18:30:36 --> Router Class Initialized
INFO - 2023-08-02 18:30:36 --> Output Class Initialized
INFO - 2023-08-02 18:30:36 --> Security Class Initialized
DEBUG - 2023-08-02 18:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:30:36 --> Input Class Initialized
INFO - 2023-08-02 18:30:36 --> Language Class Initialized
INFO - 2023-08-02 18:30:36 --> Loader Class Initialized
INFO - 2023-08-02 18:30:36 --> Helper loaded: url_helper
INFO - 2023-08-02 18:30:36 --> Helper loaded: file_helper
INFO - 2023-08-02 18:30:36 --> Database Driver Class Initialized
INFO - 2023-08-02 18:30:36 --> Email Class Initialized
DEBUG - 2023-08-02 18:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:30:36 --> Controller Class Initialized
INFO - 2023-08-02 18:30:36 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:30:36 --> Helper loaded: form_helper
INFO - 2023-08-02 18:30:36 --> Form Validation Class Initialized
INFO - 2023-08-02 18:30:36 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:30:36 --> Final output sent to browser
DEBUG - 2023-08-02 18:30:36 --> Total execution time: 0.0443
INFO - 2023-08-02 18:30:40 --> Config Class Initialized
INFO - 2023-08-02 18:30:40 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:30:40 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:30:40 --> Utf8 Class Initialized
INFO - 2023-08-02 18:30:40 --> URI Class Initialized
INFO - 2023-08-02 18:30:40 --> Router Class Initialized
INFO - 2023-08-02 18:30:40 --> Output Class Initialized
INFO - 2023-08-02 18:30:40 --> Security Class Initialized
DEBUG - 2023-08-02 18:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:30:40 --> Input Class Initialized
INFO - 2023-08-02 18:30:40 --> Language Class Initialized
INFO - 2023-08-02 18:30:40 --> Loader Class Initialized
INFO - 2023-08-02 18:30:40 --> Helper loaded: url_helper
INFO - 2023-08-02 18:30:40 --> Helper loaded: file_helper
INFO - 2023-08-02 18:30:40 --> Database Driver Class Initialized
INFO - 2023-08-02 18:30:40 --> Email Class Initialized
DEBUG - 2023-08-02 18:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:30:40 --> Controller Class Initialized
INFO - 2023-08-02 18:30:40 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:30:40 --> Helper loaded: form_helper
INFO - 2023-08-02 18:30:40 --> Form Validation Class Initialized
INFO - 2023-08-02 18:30:40 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-02 18:30:40 --> Final output sent to browser
DEBUG - 2023-08-02 18:30:40 --> Total execution time: 0.0547
INFO - 2023-08-02 18:30:42 --> Config Class Initialized
INFO - 2023-08-02 18:30:42 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:30:42 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:30:42 --> Utf8 Class Initialized
INFO - 2023-08-02 18:30:42 --> URI Class Initialized
INFO - 2023-08-02 18:30:42 --> Router Class Initialized
INFO - 2023-08-02 18:30:42 --> Output Class Initialized
INFO - 2023-08-02 18:30:42 --> Security Class Initialized
DEBUG - 2023-08-02 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:30:42 --> Input Class Initialized
INFO - 2023-08-02 18:30:42 --> Language Class Initialized
INFO - 2023-08-02 18:30:42 --> Loader Class Initialized
INFO - 2023-08-02 18:30:42 --> Helper loaded: url_helper
INFO - 2023-08-02 18:30:42 --> Helper loaded: file_helper
INFO - 2023-08-02 18:30:42 --> Database Driver Class Initialized
INFO - 2023-08-02 18:30:42 --> Email Class Initialized
DEBUG - 2023-08-02 18:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:30:42 --> Controller Class Initialized
INFO - 2023-08-02 18:30:42 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:30:42 --> Helper loaded: form_helper
INFO - 2023-08-02 18:30:42 --> Form Validation Class Initialized
INFO - 2023-08-02 18:30:42 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:30:42 --> Final output sent to browser
DEBUG - 2023-08-02 18:30:42 --> Total execution time: 0.0545
INFO - 2023-08-02 18:31:20 --> Config Class Initialized
INFO - 2023-08-02 18:31:20 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:31:20 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:31:20 --> Utf8 Class Initialized
INFO - 2023-08-02 18:31:20 --> URI Class Initialized
INFO - 2023-08-02 18:31:20 --> Router Class Initialized
INFO - 2023-08-02 18:31:20 --> Output Class Initialized
INFO - 2023-08-02 18:31:20 --> Security Class Initialized
DEBUG - 2023-08-02 18:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:31:20 --> Input Class Initialized
INFO - 2023-08-02 18:31:20 --> Language Class Initialized
INFO - 2023-08-02 18:31:20 --> Loader Class Initialized
INFO - 2023-08-02 18:31:20 --> Helper loaded: url_helper
INFO - 2023-08-02 18:31:20 --> Helper loaded: file_helper
INFO - 2023-08-02 18:31:20 --> Database Driver Class Initialized
INFO - 2023-08-02 18:31:20 --> Email Class Initialized
DEBUG - 2023-08-02 18:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:31:20 --> Controller Class Initialized
INFO - 2023-08-02 18:31:20 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:31:20 --> Helper loaded: form_helper
INFO - 2023-08-02 18:31:20 --> Form Validation Class Initialized
INFO - 2023-08-02 18:31:20 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:31:20 --> Final output sent to browser
DEBUG - 2023-08-02 18:31:20 --> Total execution time: 0.0864
INFO - 2023-08-02 18:31:26 --> Config Class Initialized
INFO - 2023-08-02 18:31:26 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:31:26 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:31:26 --> Utf8 Class Initialized
INFO - 2023-08-02 18:31:26 --> URI Class Initialized
INFO - 2023-08-02 18:31:26 --> Router Class Initialized
INFO - 2023-08-02 18:31:26 --> Output Class Initialized
INFO - 2023-08-02 18:31:26 --> Security Class Initialized
DEBUG - 2023-08-02 18:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:31:26 --> Input Class Initialized
INFO - 2023-08-02 18:31:26 --> Language Class Initialized
INFO - 2023-08-02 18:31:26 --> Loader Class Initialized
INFO - 2023-08-02 18:31:26 --> Helper loaded: url_helper
INFO - 2023-08-02 18:31:26 --> Helper loaded: file_helper
INFO - 2023-08-02 18:31:26 --> Database Driver Class Initialized
INFO - 2023-08-02 18:31:26 --> Email Class Initialized
DEBUG - 2023-08-02 18:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:31:26 --> Controller Class Initialized
INFO - 2023-08-02 18:31:26 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:31:26 --> Helper loaded: form_helper
INFO - 2023-08-02 18:31:26 --> Form Validation Class Initialized
INFO - 2023-08-02 18:31:26 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-02 18:31:26 --> Final output sent to browser
DEBUG - 2023-08-02 18:31:26 --> Total execution time: 0.0432
INFO - 2023-08-02 18:41:54 --> Config Class Initialized
INFO - 2023-08-02 18:41:54 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:41:54 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:41:54 --> Utf8 Class Initialized
INFO - 2023-08-02 18:41:54 --> URI Class Initialized
INFO - 2023-08-02 18:41:55 --> Router Class Initialized
INFO - 2023-08-02 18:41:55 --> Output Class Initialized
INFO - 2023-08-02 18:41:55 --> Security Class Initialized
DEBUG - 2023-08-02 18:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:41:55 --> Input Class Initialized
INFO - 2023-08-02 18:41:55 --> Language Class Initialized
INFO - 2023-08-02 18:41:56 --> Loader Class Initialized
INFO - 2023-08-02 18:41:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:41:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:41:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:41:56 --> Email Class Initialized
DEBUG - 2023-08-02 18:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:41:57 --> Controller Class Initialized
INFO - 2023-08-02 18:41:57 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:41:58 --> Helper loaded: form_helper
INFO - 2023-08-02 18:41:58 --> Form Validation Class Initialized
INFO - 2023-08-02 18:41:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:41:58 --> Final output sent to browser
DEBUG - 2023-08-02 18:41:58 --> Total execution time: 3.9928
INFO - 2023-08-02 18:42:22 --> Config Class Initialized
INFO - 2023-08-02 18:42:22 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:42:22 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:42:22 --> Utf8 Class Initialized
INFO - 2023-08-02 18:42:22 --> URI Class Initialized
INFO - 2023-08-02 18:42:22 --> Router Class Initialized
INFO - 2023-08-02 18:42:22 --> Output Class Initialized
INFO - 2023-08-02 18:42:22 --> Security Class Initialized
DEBUG - 2023-08-02 18:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:42:22 --> Input Class Initialized
INFO - 2023-08-02 18:42:22 --> Language Class Initialized
INFO - 2023-08-02 18:42:22 --> Loader Class Initialized
INFO - 2023-08-02 18:42:22 --> Helper loaded: url_helper
INFO - 2023-08-02 18:42:22 --> Helper loaded: file_helper
INFO - 2023-08-02 18:42:22 --> Database Driver Class Initialized
INFO - 2023-08-02 18:42:22 --> Email Class Initialized
DEBUG - 2023-08-02 18:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:42:22 --> Controller Class Initialized
INFO - 2023-08-02 18:42:22 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:42:22 --> Helper loaded: form_helper
INFO - 2023-08-02 18:42:22 --> Form Validation Class Initialized
INFO - 2023-08-02 18:42:22 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:42:22 --> Final output sent to browser
DEBUG - 2023-08-02 18:42:22 --> Total execution time: 0.3380
INFO - 2023-08-02 18:42:57 --> Config Class Initialized
INFO - 2023-08-02 18:42:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:42:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:42:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:42:57 --> URI Class Initialized
INFO - 2023-08-02 18:42:57 --> Router Class Initialized
INFO - 2023-08-02 18:42:57 --> Output Class Initialized
INFO - 2023-08-02 18:42:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:42:57 --> Input Class Initialized
INFO - 2023-08-02 18:42:57 --> Language Class Initialized
INFO - 2023-08-02 18:42:57 --> Loader Class Initialized
INFO - 2023-08-02 18:42:57 --> Helper loaded: url_helper
INFO - 2023-08-02 18:42:57 --> Helper loaded: file_helper
INFO - 2023-08-02 18:42:57 --> Database Driver Class Initialized
INFO - 2023-08-02 18:42:57 --> Email Class Initialized
DEBUG - 2023-08-02 18:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:42:57 --> Controller Class Initialized
INFO - 2023-08-02 18:42:57 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:42:57 --> Helper loaded: form_helper
INFO - 2023-08-02 18:42:57 --> Form Validation Class Initialized
INFO - 2023-08-02 18:42:57 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:42:57 --> Final output sent to browser
DEBUG - 2023-08-02 18:42:57 --> Total execution time: 0.1243
INFO - 2023-08-02 18:42:58 --> Config Class Initialized
INFO - 2023-08-02 18:42:58 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:42:58 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:42:58 --> Utf8 Class Initialized
INFO - 2023-08-02 18:42:58 --> URI Class Initialized
INFO - 2023-08-02 18:42:58 --> Router Class Initialized
INFO - 2023-08-02 18:42:58 --> Output Class Initialized
INFO - 2023-08-02 18:42:58 --> Security Class Initialized
DEBUG - 2023-08-02 18:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:42:58 --> Input Class Initialized
INFO - 2023-08-02 18:42:58 --> Language Class Initialized
INFO - 2023-08-02 18:42:58 --> Loader Class Initialized
INFO - 2023-08-02 18:42:58 --> Helper loaded: url_helper
INFO - 2023-08-02 18:42:58 --> Helper loaded: file_helper
INFO - 2023-08-02 18:42:58 --> Database Driver Class Initialized
INFO - 2023-08-02 18:42:58 --> Email Class Initialized
DEBUG - 2023-08-02 18:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:42:58 --> Controller Class Initialized
INFO - 2023-08-02 18:42:58 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:42:58 --> Helper loaded: form_helper
INFO - 2023-08-02 18:42:58 --> Form Validation Class Initialized
INFO - 2023-08-02 18:42:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:42:58 --> Final output sent to browser
DEBUG - 2023-08-02 18:42:58 --> Total execution time: 0.0436
INFO - 2023-08-02 18:42:58 --> Config Class Initialized
INFO - 2023-08-02 18:42:58 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:42:58 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:42:58 --> Utf8 Class Initialized
INFO - 2023-08-02 18:42:58 --> URI Class Initialized
INFO - 2023-08-02 18:42:58 --> Router Class Initialized
INFO - 2023-08-02 18:42:58 --> Output Class Initialized
INFO - 2023-08-02 18:42:58 --> Security Class Initialized
DEBUG - 2023-08-02 18:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:42:58 --> Input Class Initialized
INFO - 2023-08-02 18:42:58 --> Language Class Initialized
INFO - 2023-08-02 18:42:58 --> Loader Class Initialized
INFO - 2023-08-02 18:42:58 --> Helper loaded: url_helper
INFO - 2023-08-02 18:42:58 --> Helper loaded: file_helper
INFO - 2023-08-02 18:42:58 --> Database Driver Class Initialized
INFO - 2023-08-02 18:42:58 --> Email Class Initialized
DEBUG - 2023-08-02 18:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:42:58 --> Controller Class Initialized
INFO - 2023-08-02 18:42:58 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:42:58 --> Helper loaded: form_helper
INFO - 2023-08-02 18:42:58 --> Form Validation Class Initialized
INFO - 2023-08-02 18:42:58 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:42:58 --> Final output sent to browser
DEBUG - 2023-08-02 18:42:58 --> Total execution time: 0.0662
INFO - 2023-08-02 18:43:12 --> Config Class Initialized
INFO - 2023-08-02 18:43:12 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:43:12 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:43:12 --> Utf8 Class Initialized
INFO - 2023-08-02 18:43:12 --> URI Class Initialized
INFO - 2023-08-02 18:43:12 --> Router Class Initialized
INFO - 2023-08-02 18:43:12 --> Output Class Initialized
INFO - 2023-08-02 18:43:12 --> Security Class Initialized
DEBUG - 2023-08-02 18:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:43:12 --> Input Class Initialized
INFO - 2023-08-02 18:43:12 --> Language Class Initialized
INFO - 2023-08-02 18:43:12 --> Loader Class Initialized
INFO - 2023-08-02 18:43:12 --> Helper loaded: url_helper
INFO - 2023-08-02 18:43:12 --> Helper loaded: file_helper
INFO - 2023-08-02 18:43:12 --> Database Driver Class Initialized
INFO - 2023-08-02 18:43:12 --> Email Class Initialized
DEBUG - 2023-08-02 18:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:43:12 --> Controller Class Initialized
INFO - 2023-08-02 18:43:12 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:43:12 --> Helper loaded: form_helper
INFO - 2023-08-02 18:43:12 --> Form Validation Class Initialized
INFO - 2023-08-02 18:43:12 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:43:12 --> Final output sent to browser
DEBUG - 2023-08-02 18:43:12 --> Total execution time: 0.1326
INFO - 2023-08-02 18:44:56 --> Config Class Initialized
INFO - 2023-08-02 18:44:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:44:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:44:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:44:56 --> URI Class Initialized
INFO - 2023-08-02 18:44:56 --> Router Class Initialized
INFO - 2023-08-02 18:44:56 --> Output Class Initialized
INFO - 2023-08-02 18:44:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:44:56 --> Input Class Initialized
INFO - 2023-08-02 18:44:56 --> Language Class Initialized
INFO - 2023-08-02 18:44:56 --> Loader Class Initialized
INFO - 2023-08-02 18:44:56 --> Helper loaded: url_helper
INFO - 2023-08-02 18:44:56 --> Helper loaded: file_helper
INFO - 2023-08-02 18:44:56 --> Database Driver Class Initialized
INFO - 2023-08-02 18:44:56 --> Email Class Initialized
DEBUG - 2023-08-02 18:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:44:56 --> Controller Class Initialized
INFO - 2023-08-02 18:44:56 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:44:56 --> Helper loaded: form_helper
INFO - 2023-08-02 18:44:56 --> Form Validation Class Initialized
INFO - 2023-08-02 18:44:56 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_edit.php
INFO - 2023-08-02 18:44:56 --> Final output sent to browser
DEBUG - 2023-08-02 18:44:56 --> Total execution time: 0.1217
INFO - 2023-08-02 18:44:56 --> Config Class Initialized
INFO - 2023-08-02 18:44:56 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:44:56 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:44:56 --> Utf8 Class Initialized
INFO - 2023-08-02 18:44:56 --> URI Class Initialized
INFO - 2023-08-02 18:44:56 --> Router Class Initialized
INFO - 2023-08-02 18:44:56 --> Output Class Initialized
INFO - 2023-08-02 18:44:56 --> Security Class Initialized
DEBUG - 2023-08-02 18:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:44:56 --> Input Class Initialized
INFO - 2023-08-02 18:44:56 --> Language Class Initialized
ERROR - 2023-08-02 18:44:56 --> 404 Page Not Found: admin/Key_highlights/edit
INFO - 2023-08-02 18:44:57 --> Config Class Initialized
INFO - 2023-08-02 18:44:57 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:44:57 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:44:57 --> Utf8 Class Initialized
INFO - 2023-08-02 18:44:57 --> URI Class Initialized
INFO - 2023-08-02 18:44:57 --> Router Class Initialized
INFO - 2023-08-02 18:44:57 --> Output Class Initialized
INFO - 2023-08-02 18:44:57 --> Security Class Initialized
DEBUG - 2023-08-02 18:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:44:57 --> Input Class Initialized
INFO - 2023-08-02 18:44:57 --> Language Class Initialized
ERROR - 2023-08-02 18:44:57 --> 404 Page Not Found: admin/Key_highlights/edit
INFO - 2023-08-02 18:45:25 --> Config Class Initialized
INFO - 2023-08-02 18:45:25 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:45:25 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:45:25 --> Utf8 Class Initialized
INFO - 2023-08-02 18:45:25 --> URI Class Initialized
INFO - 2023-08-02 18:45:25 --> Router Class Initialized
INFO - 2023-08-02 18:45:25 --> Output Class Initialized
INFO - 2023-08-02 18:45:25 --> Security Class Initialized
DEBUG - 2023-08-02 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:45:25 --> Input Class Initialized
INFO - 2023-08-02 18:45:25 --> Language Class Initialized
INFO - 2023-08-02 18:45:25 --> Loader Class Initialized
INFO - 2023-08-02 18:45:25 --> Helper loaded: url_helper
INFO - 2023-08-02 18:45:25 --> Helper loaded: file_helper
INFO - 2023-08-02 18:45:25 --> Database Driver Class Initialized
INFO - 2023-08-02 18:45:25 --> Email Class Initialized
DEBUG - 2023-08-02 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:45:25 --> Controller Class Initialized
INFO - 2023-08-02 18:45:25 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:45:25 --> Helper loaded: form_helper
INFO - 2023-08-02 18:45:25 --> Form Validation Class Initialized
INFO - 2023-08-02 18:45:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-02 18:45:25 --> Config Class Initialized
INFO - 2023-08-02 18:45:25 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:45:25 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:45:25 --> Utf8 Class Initialized
INFO - 2023-08-02 18:45:25 --> URI Class Initialized
INFO - 2023-08-02 18:45:25 --> Router Class Initialized
INFO - 2023-08-02 18:45:25 --> Output Class Initialized
INFO - 2023-08-02 18:45:25 --> Security Class Initialized
DEBUG - 2023-08-02 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:45:25 --> Input Class Initialized
INFO - 2023-08-02 18:45:25 --> Language Class Initialized
INFO - 2023-08-02 18:45:25 --> Loader Class Initialized
INFO - 2023-08-02 18:45:25 --> Helper loaded: url_helper
INFO - 2023-08-02 18:45:25 --> Helper loaded: file_helper
INFO - 2023-08-02 18:45:25 --> Database Driver Class Initialized
INFO - 2023-08-02 18:45:25 --> Email Class Initialized
DEBUG - 2023-08-02 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-02 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-02 18:45:25 --> Controller Class Initialized
INFO - 2023-08-02 18:45:25 --> Model "Key_highlights_model" initialized
INFO - 2023-08-02 18:45:25 --> Helper loaded: form_helper
INFO - 2023-08-02 18:45:25 --> Form Validation Class Initialized
INFO - 2023-08-02 18:45:25 --> File loaded: C:\xampp\htdocs\DW\application\views\admin/key_highlights_list.php
INFO - 2023-08-02 18:45:25 --> Final output sent to browser
DEBUG - 2023-08-02 18:45:25 --> Total execution time: 0.0982
INFO - 2023-08-02 18:45:25 --> Config Class Initialized
INFO - 2023-08-02 18:45:25 --> Hooks Class Initialized
DEBUG - 2023-08-02 18:45:25 --> UTF-8 Support Enabled
INFO - 2023-08-02 18:45:25 --> Utf8 Class Initialized
INFO - 2023-08-02 18:45:25 --> URI Class Initialized
INFO - 2023-08-02 18:45:25 --> Router Class Initialized
INFO - 2023-08-02 18:45:25 --> Output Class Initialized
INFO - 2023-08-02 18:45:25 --> Security Class Initialized
DEBUG - 2023-08-02 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-02 18:45:25 --> Input Class Initialized
INFO - 2023-08-02 18:45:25 --> Language Class Initialized
ERROR - 2023-08-02 18:45:25 --> 404 Page Not Found: admin/Images/faces
