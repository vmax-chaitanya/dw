<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-20 07:01:27 --> Config Class Initialized
INFO - 2023-09-20 07:01:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:01:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:01:28 --> Utf8 Class Initialized
INFO - 2023-09-20 07:01:28 --> URI Class Initialized
DEBUG - 2023-09-20 07:01:28 --> No URI present. Default controller set.
INFO - 2023-09-20 07:01:28 --> Router Class Initialized
INFO - 2023-09-20 07:01:28 --> Output Class Initialized
INFO - 2023-09-20 07:01:28 --> Security Class Initialized
DEBUG - 2023-09-20 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:01:28 --> Input Class Initialized
INFO - 2023-09-20 07:01:28 --> Language Class Initialized
INFO - 2023-09-20 07:01:28 --> Loader Class Initialized
INFO - 2023-09-20 07:01:28 --> Helper loaded: url_helper
INFO - 2023-09-20 07:01:28 --> Helper loaded: file_helper
INFO - 2023-09-20 07:01:28 --> Database Driver Class Initialized
INFO - 2023-09-20 07:01:28 --> Email Class Initialized
DEBUG - 2023-09-20 07:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:01:28 --> Controller Class Initialized
INFO - 2023-09-20 07:01:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:01:28 --> Model "Home_model" initialized
INFO - 2023-09-20 07:01:28 --> Helper loaded: download_helper
INFO - 2023-09-20 07:01:28 --> Helper loaded: form_helper
INFO - 2023-09-20 07:01:28 --> Form Validation Class Initialized
INFO - 2023-09-20 07:01:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:01:28 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:01:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 07:01:29 --> Final output sent to browser
DEBUG - 2023-09-20 07:01:29 --> Total execution time: 1.1553
INFO - 2023-09-20 07:02:46 --> Config Class Initialized
INFO - 2023-09-20 07:02:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:02:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:02:46 --> Utf8 Class Initialized
INFO - 2023-09-20 07:02:46 --> URI Class Initialized
DEBUG - 2023-09-20 07:02:46 --> No URI present. Default controller set.
INFO - 2023-09-20 07:02:46 --> Router Class Initialized
INFO - 2023-09-20 07:02:46 --> Output Class Initialized
INFO - 2023-09-20 07:02:46 --> Security Class Initialized
DEBUG - 2023-09-20 07:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:02:46 --> Input Class Initialized
INFO - 2023-09-20 07:02:46 --> Language Class Initialized
INFO - 2023-09-20 07:02:46 --> Loader Class Initialized
INFO - 2023-09-20 07:02:46 --> Helper loaded: url_helper
INFO - 2023-09-20 07:02:46 --> Helper loaded: file_helper
INFO - 2023-09-20 07:02:46 --> Database Driver Class Initialized
INFO - 2023-09-20 07:02:46 --> Email Class Initialized
DEBUG - 2023-09-20 07:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:02:46 --> Controller Class Initialized
INFO - 2023-09-20 07:02:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:02:46 --> Model "Home_model" initialized
INFO - 2023-09-20 07:02:46 --> Helper loaded: download_helper
INFO - 2023-09-20 07:02:46 --> Helper loaded: form_helper
INFO - 2023-09-20 07:02:46 --> Form Validation Class Initialized
INFO - 2023-09-20 07:02:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:02:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:02:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 07:02:46 --> Final output sent to browser
DEBUG - 2023-09-20 07:02:46 --> Total execution time: 0.0692
INFO - 2023-09-20 07:02:49 --> Config Class Initialized
INFO - 2023-09-20 07:02:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:02:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:02:49 --> Utf8 Class Initialized
INFO - 2023-09-20 07:02:49 --> URI Class Initialized
DEBUG - 2023-09-20 07:02:49 --> No URI present. Default controller set.
INFO - 2023-09-20 07:02:49 --> Router Class Initialized
INFO - 2023-09-20 07:02:49 --> Output Class Initialized
INFO - 2023-09-20 07:02:49 --> Security Class Initialized
DEBUG - 2023-09-20 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:02:49 --> Input Class Initialized
INFO - 2023-09-20 07:02:49 --> Language Class Initialized
INFO - 2023-09-20 07:02:49 --> Loader Class Initialized
INFO - 2023-09-20 07:02:49 --> Helper loaded: url_helper
INFO - 2023-09-20 07:02:49 --> Helper loaded: file_helper
INFO - 2023-09-20 07:02:49 --> Database Driver Class Initialized
INFO - 2023-09-20 07:02:49 --> Email Class Initialized
DEBUG - 2023-09-20 07:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:02:49 --> Controller Class Initialized
INFO - 2023-09-20 07:02:49 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:02:49 --> Model "Home_model" initialized
INFO - 2023-09-20 07:02:49 --> Helper loaded: download_helper
INFO - 2023-09-20 07:02:49 --> Helper loaded: form_helper
INFO - 2023-09-20 07:02:49 --> Form Validation Class Initialized
INFO - 2023-09-20 07:02:49 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:02:49 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:02:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 07:02:49 --> Final output sent to browser
DEBUG - 2023-09-20 07:02:49 --> Total execution time: 0.0623
INFO - 2023-09-20 07:02:57 --> Config Class Initialized
INFO - 2023-09-20 07:02:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:02:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:02:57 --> Utf8 Class Initialized
INFO - 2023-09-20 07:02:57 --> URI Class Initialized
INFO - 2023-09-20 07:02:57 --> Router Class Initialized
INFO - 2023-09-20 07:02:57 --> Output Class Initialized
INFO - 2023-09-20 07:02:57 --> Security Class Initialized
DEBUG - 2023-09-20 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:02:57 --> Input Class Initialized
INFO - 2023-09-20 07:02:57 --> Language Class Initialized
INFO - 2023-09-20 07:02:57 --> Loader Class Initialized
INFO - 2023-09-20 07:02:57 --> Helper loaded: url_helper
INFO - 2023-09-20 07:02:57 --> Helper loaded: file_helper
INFO - 2023-09-20 07:02:57 --> Database Driver Class Initialized
INFO - 2023-09-20 07:02:57 --> Email Class Initialized
DEBUG - 2023-09-20 07:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:02:57 --> Controller Class Initialized
INFO - 2023-09-20 07:02:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:02:57 --> Model "Home_model" initialized
INFO - 2023-09-20 07:02:57 --> Helper loaded: download_helper
INFO - 2023-09-20 07:02:57 --> Helper loaded: form_helper
INFO - 2023-09-20 07:02:57 --> Form Validation Class Initialized
INFO - 2023-09-20 07:02:57 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:02:57 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:02:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 07:02:57 --> Final output sent to browser
DEBUG - 2023-09-20 07:02:57 --> Total execution time: 0.0670
INFO - 2023-09-20 07:24:09 --> Config Class Initialized
INFO - 2023-09-20 07:24:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:24:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:24:09 --> Utf8 Class Initialized
INFO - 2023-09-20 07:24:09 --> URI Class Initialized
DEBUG - 2023-09-20 07:24:09 --> No URI present. Default controller set.
INFO - 2023-09-20 07:24:09 --> Router Class Initialized
INFO - 2023-09-20 07:24:09 --> Output Class Initialized
INFO - 2023-09-20 07:24:09 --> Security Class Initialized
DEBUG - 2023-09-20 07:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:24:09 --> Input Class Initialized
INFO - 2023-09-20 07:24:09 --> Language Class Initialized
INFO - 2023-09-20 07:24:09 --> Loader Class Initialized
INFO - 2023-09-20 07:24:09 --> Helper loaded: url_helper
INFO - 2023-09-20 07:24:09 --> Helper loaded: file_helper
INFO - 2023-09-20 07:24:09 --> Database Driver Class Initialized
INFO - 2023-09-20 07:24:09 --> Email Class Initialized
DEBUG - 2023-09-20 07:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:24:09 --> Controller Class Initialized
INFO - 2023-09-20 07:24:09 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:24:09 --> Model "Home_model" initialized
INFO - 2023-09-20 07:24:09 --> Helper loaded: download_helper
INFO - 2023-09-20 07:24:09 --> Helper loaded: form_helper
INFO - 2023-09-20 07:24:09 --> Form Validation Class Initialized
INFO - 2023-09-20 07:24:09 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:24:09 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:24:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 07:24:09 --> Final output sent to browser
DEBUG - 2023-09-20 07:24:09 --> Total execution time: 0.0654
INFO - 2023-09-20 07:24:18 --> Config Class Initialized
INFO - 2023-09-20 07:24:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:24:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:24:18 --> Utf8 Class Initialized
INFO - 2023-09-20 07:24:18 --> URI Class Initialized
INFO - 2023-09-20 07:24:18 --> Router Class Initialized
INFO - 2023-09-20 07:24:18 --> Output Class Initialized
INFO - 2023-09-20 07:24:18 --> Security Class Initialized
DEBUG - 2023-09-20 07:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:24:18 --> Input Class Initialized
INFO - 2023-09-20 07:24:18 --> Language Class Initialized
INFO - 2023-09-20 07:24:18 --> Loader Class Initialized
INFO - 2023-09-20 07:24:18 --> Helper loaded: url_helper
INFO - 2023-09-20 07:24:18 --> Helper loaded: file_helper
INFO - 2023-09-20 07:24:18 --> Database Driver Class Initialized
INFO - 2023-09-20 07:24:18 --> Email Class Initialized
DEBUG - 2023-09-20 07:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 07:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:24:18 --> Controller Class Initialized
INFO - 2023-09-20 07:24:18 --> Model "Contact_model" initialized
INFO - 2023-09-20 07:24:18 --> Model "Home_model" initialized
INFO - 2023-09-20 07:24:18 --> Helper loaded: download_helper
INFO - 2023-09-20 07:24:18 --> Helper loaded: form_helper
INFO - 2023-09-20 07:24:18 --> Form Validation Class Initialized
INFO - 2023-09-20 07:24:18 --> Helper loaded: custom_helper
INFO - 2023-09-20 07:24:18 --> Model "Social_media_model" initialized
INFO - 2023-09-20 07:24:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 07:24:18 --> Final output sent to browser
DEBUG - 2023-09-20 07:24:18 --> Total execution time: 0.0559
