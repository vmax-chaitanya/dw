<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-20 16:26:33 --> Config Class Initialized
INFO - 2023-09-20 16:26:33 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:26:33 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:26:33 --> Utf8 Class Initialized
INFO - 2023-09-20 16:26:33 --> URI Class Initialized
DEBUG - 2023-09-20 16:26:33 --> No URI present. Default controller set.
INFO - 2023-09-20 16:26:33 --> Router Class Initialized
INFO - 2023-09-20 16:26:33 --> Output Class Initialized
INFO - 2023-09-20 16:26:33 --> Security Class Initialized
DEBUG - 2023-09-20 16:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:26:33 --> Input Class Initialized
INFO - 2023-09-20 16:26:33 --> Language Class Initialized
INFO - 2023-09-20 16:26:33 --> Loader Class Initialized
INFO - 2023-09-20 16:26:33 --> Helper loaded: url_helper
INFO - 2023-09-20 16:26:33 --> Helper loaded: file_helper
INFO - 2023-09-20 16:26:33 --> Database Driver Class Initialized
INFO - 2023-09-20 16:26:33 --> Email Class Initialized
DEBUG - 2023-09-20 16:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:26:33 --> Controller Class Initialized
INFO - 2023-09-20 16:26:33 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:26:33 --> Model "Home_model" initialized
INFO - 2023-09-20 16:26:33 --> Helper loaded: download_helper
INFO - 2023-09-20 16:26:33 --> Helper loaded: form_helper
INFO - 2023-09-20 16:26:33 --> Form Validation Class Initialized
INFO - 2023-09-20 16:26:33 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:26:33 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:26:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 16:26:33 --> Final output sent to browser
DEBUG - 2023-09-20 16:26:33 --> Total execution time: 0.2198
INFO - 2023-09-20 16:26:37 --> Config Class Initialized
INFO - 2023-09-20 16:26:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:26:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:26:37 --> Utf8 Class Initialized
INFO - 2023-09-20 16:26:37 --> URI Class Initialized
INFO - 2023-09-20 16:26:37 --> Router Class Initialized
INFO - 2023-09-20 16:26:37 --> Output Class Initialized
INFO - 2023-09-20 16:26:37 --> Security Class Initialized
DEBUG - 2023-09-20 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:26:37 --> Input Class Initialized
INFO - 2023-09-20 16:26:37 --> Language Class Initialized
INFO - 2023-09-20 16:26:37 --> Loader Class Initialized
INFO - 2023-09-20 16:26:37 --> Helper loaded: url_helper
INFO - 2023-09-20 16:26:37 --> Helper loaded: file_helper
INFO - 2023-09-20 16:26:37 --> Database Driver Class Initialized
INFO - 2023-09-20 16:26:37 --> Email Class Initialized
DEBUG - 2023-09-20 16:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:26:37 --> Controller Class Initialized
INFO - 2023-09-20 16:26:37 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:26:37 --> Model "Home_model" initialized
INFO - 2023-09-20 16:26:37 --> Helper loaded: download_helper
INFO - 2023-09-20 16:26:38 --> Helper loaded: form_helper
INFO - 2023-09-20 16:26:38 --> Form Validation Class Initialized
INFO - 2023-09-20 16:26:38 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:26:38 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:26:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-20 16:26:38 --> Final output sent to browser
DEBUG - 2023-09-20 16:26:38 --> Total execution time: 0.0876
INFO - 2023-09-20 16:27:39 --> Config Class Initialized
INFO - 2023-09-20 16:27:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:27:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:27:40 --> Utf8 Class Initialized
INFO - 2023-09-20 16:27:40 --> URI Class Initialized
INFO - 2023-09-20 16:27:40 --> Router Class Initialized
INFO - 2023-09-20 16:27:40 --> Output Class Initialized
INFO - 2023-09-20 16:27:40 --> Security Class Initialized
DEBUG - 2023-09-20 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:27:40 --> Input Class Initialized
INFO - 2023-09-20 16:27:40 --> Language Class Initialized
INFO - 2023-09-20 16:27:40 --> Loader Class Initialized
INFO - 2023-09-20 16:27:40 --> Helper loaded: url_helper
INFO - 2023-09-20 16:27:40 --> Helper loaded: file_helper
INFO - 2023-09-20 16:27:40 --> Database Driver Class Initialized
INFO - 2023-09-20 16:27:40 --> Email Class Initialized
DEBUG - 2023-09-20 16:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:27:40 --> Controller Class Initialized
INFO - 2023-09-20 16:27:40 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:27:40 --> Model "Home_model" initialized
INFO - 2023-09-20 16:27:40 --> Helper loaded: download_helper
INFO - 2023-09-20 16:27:40 --> Helper loaded: form_helper
INFO - 2023-09-20 16:27:40 --> Form Validation Class Initialized
INFO - 2023-09-20 16:27:40 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:27:40 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:27:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-20 16:27:40 --> Final output sent to browser
DEBUG - 2023-09-20 16:27:40 --> Total execution time: 0.5932
INFO - 2023-09-20 16:27:48 --> Config Class Initialized
INFO - 2023-09-20 16:27:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:27:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:27:48 --> Utf8 Class Initialized
INFO - 2023-09-20 16:27:48 --> URI Class Initialized
INFO - 2023-09-20 16:27:48 --> Router Class Initialized
INFO - 2023-09-20 16:27:48 --> Output Class Initialized
INFO - 2023-09-20 16:27:48 --> Security Class Initialized
DEBUG - 2023-09-20 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:27:48 --> Input Class Initialized
INFO - 2023-09-20 16:27:48 --> Language Class Initialized
INFO - 2023-09-20 16:27:48 --> Loader Class Initialized
INFO - 2023-09-20 16:27:48 --> Helper loaded: url_helper
INFO - 2023-09-20 16:27:48 --> Helper loaded: file_helper
INFO - 2023-09-20 16:27:48 --> Database Driver Class Initialized
INFO - 2023-09-20 16:27:48 --> Email Class Initialized
DEBUG - 2023-09-20 16:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:27:48 --> Controller Class Initialized
INFO - 2023-09-20 16:27:48 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:27:48 --> Model "Home_model" initialized
INFO - 2023-09-20 16:27:48 --> Helper loaded: download_helper
INFO - 2023-09-20 16:27:48 --> Helper loaded: form_helper
INFO - 2023-09-20 16:27:48 --> Form Validation Class Initialized
INFO - 2023-09-20 16:27:48 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:27:48 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:27:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 16:27:48 --> Final output sent to browser
DEBUG - 2023-09-20 16:27:48 --> Total execution time: 0.1007
INFO - 2023-09-20 16:27:53 --> Config Class Initialized
INFO - 2023-09-20 16:27:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:27:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:27:53 --> Utf8 Class Initialized
INFO - 2023-09-20 16:27:53 --> URI Class Initialized
INFO - 2023-09-20 16:27:53 --> Router Class Initialized
INFO - 2023-09-20 16:27:53 --> Output Class Initialized
INFO - 2023-09-20 16:27:53 --> Security Class Initialized
DEBUG - 2023-09-20 16:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:27:53 --> Input Class Initialized
INFO - 2023-09-20 16:27:53 --> Language Class Initialized
INFO - 2023-09-20 16:27:53 --> Loader Class Initialized
INFO - 2023-09-20 16:27:53 --> Helper loaded: url_helper
INFO - 2023-09-20 16:27:53 --> Helper loaded: file_helper
INFO - 2023-09-20 16:27:53 --> Database Driver Class Initialized
INFO - 2023-09-20 16:27:53 --> Email Class Initialized
DEBUG - 2023-09-20 16:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:27:53 --> Controller Class Initialized
INFO - 2023-09-20 16:27:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:27:53 --> Model "Home_model" initialized
INFO - 2023-09-20 16:27:53 --> Helper loaded: download_helper
INFO - 2023-09-20 16:27:53 --> Helper loaded: form_helper
INFO - 2023-09-20 16:27:53 --> Form Validation Class Initialized
INFO - 2023-09-20 16:27:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:27:53 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:27:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:27:53 --> Final output sent to browser
DEBUG - 2023-09-20 16:27:53 --> Total execution time: 0.1208
INFO - 2023-09-20 16:27:53 --> Config Class Initialized
INFO - 2023-09-20 16:27:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:27:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:27:53 --> Utf8 Class Initialized
INFO - 2023-09-20 16:27:53 --> URI Class Initialized
INFO - 2023-09-20 16:27:53 --> Router Class Initialized
INFO - 2023-09-20 16:27:53 --> Output Class Initialized
INFO - 2023-09-20 16:27:53 --> Security Class Initialized
DEBUG - 2023-09-20 16:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:27:53 --> Input Class Initialized
INFO - 2023-09-20 16:27:53 --> Language Class Initialized
ERROR - 2023-09-20 16:27:53 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 16:29:44 --> Config Class Initialized
INFO - 2023-09-20 16:29:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:29:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:29:44 --> Utf8 Class Initialized
INFO - 2023-09-20 16:29:44 --> URI Class Initialized
INFO - 2023-09-20 16:29:44 --> Router Class Initialized
INFO - 2023-09-20 16:29:44 --> Output Class Initialized
INFO - 2023-09-20 16:29:44 --> Security Class Initialized
DEBUG - 2023-09-20 16:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:29:44 --> Input Class Initialized
INFO - 2023-09-20 16:29:44 --> Language Class Initialized
INFO - 2023-09-20 16:29:44 --> Loader Class Initialized
INFO - 2023-09-20 16:29:44 --> Helper loaded: url_helper
INFO - 2023-09-20 16:29:44 --> Helper loaded: file_helper
INFO - 2023-09-20 16:29:44 --> Database Driver Class Initialized
INFO - 2023-09-20 16:29:44 --> Email Class Initialized
DEBUG - 2023-09-20 16:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:29:44 --> Controller Class Initialized
INFO - 2023-09-20 16:29:44 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:29:44 --> Model "Home_model" initialized
INFO - 2023-09-20 16:29:44 --> Helper loaded: download_helper
INFO - 2023-09-20 16:29:44 --> Helper loaded: form_helper
INFO - 2023-09-20 16:29:44 --> Form Validation Class Initialized
INFO - 2023-09-20 16:29:44 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:29:44 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:29:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:29:44 --> Final output sent to browser
DEBUG - 2023-09-20 16:29:44 --> Total execution time: 0.2258
INFO - 2023-09-20 16:29:45 --> Config Class Initialized
INFO - 2023-09-20 16:29:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:29:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:29:45 --> Utf8 Class Initialized
INFO - 2023-09-20 16:29:45 --> URI Class Initialized
INFO - 2023-09-20 16:29:45 --> Router Class Initialized
INFO - 2023-09-20 16:29:45 --> Output Class Initialized
INFO - 2023-09-20 16:29:45 --> Security Class Initialized
DEBUG - 2023-09-20 16:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:29:45 --> Input Class Initialized
INFO - 2023-09-20 16:29:45 --> Language Class Initialized
ERROR - 2023-09-20 16:29:45 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 16:31:02 --> Config Class Initialized
INFO - 2023-09-20 16:31:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:31:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:31:02 --> Utf8 Class Initialized
INFO - 2023-09-20 16:31:02 --> URI Class Initialized
INFO - 2023-09-20 16:31:02 --> Router Class Initialized
INFO - 2023-09-20 16:31:02 --> Output Class Initialized
INFO - 2023-09-20 16:31:02 --> Security Class Initialized
DEBUG - 2023-09-20 16:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:31:02 --> Input Class Initialized
INFO - 2023-09-20 16:31:02 --> Language Class Initialized
INFO - 2023-09-20 16:31:02 --> Loader Class Initialized
INFO - 2023-09-20 16:31:02 --> Helper loaded: url_helper
INFO - 2023-09-20 16:31:02 --> Helper loaded: file_helper
INFO - 2023-09-20 16:31:02 --> Database Driver Class Initialized
INFO - 2023-09-20 16:31:02 --> Email Class Initialized
DEBUG - 2023-09-20 16:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:31:02 --> Controller Class Initialized
INFO - 2023-09-20 16:31:02 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:31:02 --> Model "Home_model" initialized
INFO - 2023-09-20 16:31:02 --> Helper loaded: download_helper
INFO - 2023-09-20 16:31:02 --> Helper loaded: form_helper
INFO - 2023-09-20 16:31:02 --> Form Validation Class Initialized
INFO - 2023-09-20 16:31:02 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:31:02 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:31:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:31:02 --> Final output sent to browser
DEBUG - 2023-09-20 16:31:02 --> Total execution time: 0.2105
INFO - 2023-09-20 16:31:03 --> Config Class Initialized
INFO - 2023-09-20 16:31:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:31:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:31:03 --> Utf8 Class Initialized
INFO - 2023-09-20 16:31:03 --> URI Class Initialized
INFO - 2023-09-20 16:31:03 --> Router Class Initialized
INFO - 2023-09-20 16:31:03 --> Output Class Initialized
INFO - 2023-09-20 16:31:03 --> Security Class Initialized
DEBUG - 2023-09-20 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:31:03 --> Input Class Initialized
INFO - 2023-09-20 16:31:03 --> Language Class Initialized
ERROR - 2023-09-20 16:31:03 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 16:31:32 --> Config Class Initialized
INFO - 2023-09-20 16:31:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:31:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:31:32 --> Utf8 Class Initialized
INFO - 2023-09-20 16:31:32 --> URI Class Initialized
DEBUG - 2023-09-20 16:31:32 --> No URI present. Default controller set.
INFO - 2023-09-20 16:31:32 --> Router Class Initialized
INFO - 2023-09-20 16:31:32 --> Output Class Initialized
INFO - 2023-09-20 16:31:32 --> Security Class Initialized
DEBUG - 2023-09-20 16:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:31:32 --> Input Class Initialized
INFO - 2023-09-20 16:31:32 --> Language Class Initialized
INFO - 2023-09-20 16:31:32 --> Loader Class Initialized
INFO - 2023-09-20 16:31:32 --> Helper loaded: url_helper
INFO - 2023-09-20 16:31:32 --> Helper loaded: file_helper
INFO - 2023-09-20 16:31:32 --> Database Driver Class Initialized
INFO - 2023-09-20 16:31:32 --> Email Class Initialized
DEBUG - 2023-09-20 16:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:31:32 --> Controller Class Initialized
INFO - 2023-09-20 16:31:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:31:32 --> Model "Home_model" initialized
INFO - 2023-09-20 16:31:32 --> Helper loaded: download_helper
INFO - 2023-09-20 16:31:32 --> Helper loaded: form_helper
INFO - 2023-09-20 16:31:32 --> Form Validation Class Initialized
INFO - 2023-09-20 16:31:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:31:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:31:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 16:31:32 --> Final output sent to browser
DEBUG - 2023-09-20 16:31:32 --> Total execution time: 0.2053
INFO - 2023-09-20 16:31:46 --> Config Class Initialized
INFO - 2023-09-20 16:31:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:31:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:31:46 --> Utf8 Class Initialized
INFO - 2023-09-20 16:31:46 --> URI Class Initialized
INFO - 2023-09-20 16:31:46 --> Router Class Initialized
INFO - 2023-09-20 16:31:46 --> Output Class Initialized
INFO - 2023-09-20 16:31:46 --> Security Class Initialized
DEBUG - 2023-09-20 16:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:31:46 --> Input Class Initialized
INFO - 2023-09-20 16:31:46 --> Language Class Initialized
INFO - 2023-09-20 16:31:46 --> Loader Class Initialized
INFO - 2023-09-20 16:31:46 --> Helper loaded: url_helper
INFO - 2023-09-20 16:31:46 --> Helper loaded: file_helper
INFO - 2023-09-20 16:31:46 --> Database Driver Class Initialized
INFO - 2023-09-20 16:31:46 --> Email Class Initialized
DEBUG - 2023-09-20 16:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:31:46 --> Controller Class Initialized
INFO - 2023-09-20 16:31:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:31:46 --> Model "Home_model" initialized
INFO - 2023-09-20 16:31:46 --> Helper loaded: download_helper
INFO - 2023-09-20 16:31:46 --> Helper loaded: form_helper
INFO - 2023-09-20 16:31:46 --> Form Validation Class Initialized
INFO - 2023-09-20 16:31:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:31:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:31:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:31:46 --> Final output sent to browser
DEBUG - 2023-09-20 16:31:46 --> Total execution time: 0.1297
INFO - 2023-09-20 16:33:54 --> Config Class Initialized
INFO - 2023-09-20 16:33:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:33:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:54 --> Utf8 Class Initialized
INFO - 2023-09-20 16:33:54 --> URI Class Initialized
INFO - 2023-09-20 16:33:54 --> Router Class Initialized
INFO - 2023-09-20 16:33:54 --> Output Class Initialized
INFO - 2023-09-20 16:33:54 --> Security Class Initialized
DEBUG - 2023-09-20 16:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:54 --> Input Class Initialized
INFO - 2023-09-20 16:33:54 --> Language Class Initialized
ERROR - 2023-09-20 16:33:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:33:54 --> Config Class Initialized
INFO - 2023-09-20 16:33:54 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Config Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> Config Class Initialized
INFO - 2023-09-20 16:33:55 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Config Class Initialized
INFO - 2023-09-20 16:33:55 --> Config Class Initialized
INFO - 2023-09-20 16:33:55 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Config Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
INFO - 2023-09-20 16:33:55 --> Hooks Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
DEBUG - 2023-09-20 16:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
INFO - 2023-09-20 16:33:55 --> Security Class Initialized
INFO - 2023-09-20 16:33:55 --> Security Class Initialized
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
DEBUG - 2023-09-20 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:55 --> Utf8 Class Initialized
INFO - 2023-09-20 16:33:55 --> Input Class Initialized
DEBUG - 2023-09-20 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:55 --> Security Class Initialized
INFO - 2023-09-20 16:33:55 --> Security Class Initialized
DEBUG - 2023-09-20 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:55 --> Input Class Initialized
INFO - 2023-09-20 16:33:55 --> Language Class Initialized
DEBUG - 2023-09-20 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:55 --> URI Class Initialized
INFO - 2023-09-20 16:33:55 --> Security Class Initialized
INFO - 2023-09-20 16:33:55 --> Input Class Initialized
INFO - 2023-09-20 16:33:55 --> Input Class Initialized
INFO - 2023-09-20 16:33:55 --> Router Class Initialized
INFO - 2023-09-20 16:33:55 --> Language Class Initialized
ERROR - 2023-09-20 16:33:55 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:33:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:33:55 --> Language Class Initialized
DEBUG - 2023-09-20 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:55 --> Language Class Initialized
INFO - 2023-09-20 16:33:55 --> Input Class Initialized
ERROR - 2023-09-20 16:33:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:33:55 --> Output Class Initialized
INFO - 2023-09-20 16:33:56 --> Language Class Initialized
INFO - 2023-09-20 16:33:56 --> Security Class Initialized
ERROR - 2023-09-20 16:33:56 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:33:56 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 16:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:33:56 --> Input Class Initialized
INFO - 2023-09-20 16:33:56 --> Language Class Initialized
ERROR - 2023-09-20 16:33:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:03 --> Config Class Initialized
INFO - 2023-09-20 16:37:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:03 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:03 --> URI Class Initialized
INFO - 2023-09-20 16:37:03 --> Router Class Initialized
INFO - 2023-09-20 16:37:03 --> Output Class Initialized
INFO - 2023-09-20 16:37:03 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:03 --> Input Class Initialized
INFO - 2023-09-20 16:37:03 --> Language Class Initialized
INFO - 2023-09-20 16:37:03 --> Loader Class Initialized
INFO - 2023-09-20 16:37:03 --> Helper loaded: url_helper
INFO - 2023-09-20 16:37:03 --> Helper loaded: file_helper
INFO - 2023-09-20 16:37:03 --> Database Driver Class Initialized
INFO - 2023-09-20 16:37:03 --> Email Class Initialized
DEBUG - 2023-09-20 16:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:37:03 --> Controller Class Initialized
INFO - 2023-09-20 16:37:03 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:37:03 --> Model "Home_model" initialized
INFO - 2023-09-20 16:37:03 --> Helper loaded: download_helper
INFO - 2023-09-20 16:37:03 --> Helper loaded: form_helper
INFO - 2023-09-20 16:37:03 --> Form Validation Class Initialized
INFO - 2023-09-20 16:37:03 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:37:03 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:37:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:37:03 --> Final output sent to browser
DEBUG - 2023-09-20 16:37:03 --> Total execution time: 0.2377
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:37:05 --> Config Class Initialized
INFO - 2023-09-20 16:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:37:05 --> URI Class Initialized
INFO - 2023-09-20 16:37:05 --> Router Class Initialized
INFO - 2023-09-20 16:37:05 --> Output Class Initialized
INFO - 2023-09-20 16:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:37:05 --> Input Class Initialized
INFO - 2023-09-20 16:37:05 --> Language Class Initialized
ERROR - 2023-09-20 16:37:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:39:07 --> Config Class Initialized
INFO - 2023-09-20 16:39:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:07 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:07 --> URI Class Initialized
INFO - 2023-09-20 16:39:07 --> Router Class Initialized
INFO - 2023-09-20 16:39:07 --> Output Class Initialized
INFO - 2023-09-20 16:39:07 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:07 --> Input Class Initialized
INFO - 2023-09-20 16:39:07 --> Language Class Initialized
INFO - 2023-09-20 16:39:08 --> Loader Class Initialized
INFO - 2023-09-20 16:39:08 --> Helper loaded: url_helper
INFO - 2023-09-20 16:39:08 --> Helper loaded: file_helper
INFO - 2023-09-20 16:39:08 --> Database Driver Class Initialized
INFO - 2023-09-20 16:39:08 --> Email Class Initialized
DEBUG - 2023-09-20 16:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:39:08 --> Controller Class Initialized
INFO - 2023-09-20 16:39:08 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:39:08 --> Model "Home_model" initialized
INFO - 2023-09-20 16:39:08 --> Helper loaded: download_helper
INFO - 2023-09-20 16:39:08 --> Helper loaded: form_helper
INFO - 2023-09-20 16:39:08 --> Form Validation Class Initialized
INFO - 2023-09-20 16:39:08 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:39:08 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:39:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:39:08 --> Final output sent to browser
DEBUG - 2023-09-20 16:39:08 --> Total execution time: 0.1625
INFO - 2023-09-20 16:39:10 --> Config Class Initialized
INFO - 2023-09-20 16:39:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:10 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:10 --> URI Class Initialized
INFO - 2023-09-20 16:39:10 --> Router Class Initialized
INFO - 2023-09-20 16:39:10 --> Output Class Initialized
INFO - 2023-09-20 16:39:10 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:10 --> Input Class Initialized
INFO - 2023-09-20 16:39:10 --> Language Class Initialized
ERROR - 2023-09-20 16:39:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:39:11 --> Config Class Initialized
INFO - 2023-09-20 16:39:11 --> Config Class Initialized
INFO - 2023-09-20 16:39:11 --> Config Class Initialized
INFO - 2023-09-20 16:39:11 --> Config Class Initialized
INFO - 2023-09-20 16:39:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:11 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:11 --> URI Class Initialized
INFO - 2023-09-20 16:39:11 --> Router Class Initialized
INFO - 2023-09-20 16:39:11 --> Output Class Initialized
INFO - 2023-09-20 16:39:11 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:11 --> Input Class Initialized
INFO - 2023-09-20 16:39:11 --> Language Class Initialized
ERROR - 2023-09-20 16:39:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:39:11 --> Hooks Class Initialized
INFO - 2023-09-20 16:39:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:11 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:39:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:11 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:11 --> URI Class Initialized
INFO - 2023-09-20 16:39:11 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:11 --> URI Class Initialized
INFO - 2023-09-20 16:39:11 --> Router Class Initialized
INFO - 2023-09-20 16:39:11 --> URI Class Initialized
INFO - 2023-09-20 16:39:11 --> Output Class Initialized
INFO - 2023-09-20 16:39:11 --> Router Class Initialized
INFO - 2023-09-20 16:39:11 --> Router Class Initialized
INFO - 2023-09-20 16:39:11 --> Security Class Initialized
INFO - 2023-09-20 16:39:11 --> Output Class Initialized
INFO - 2023-09-20 16:39:11 --> Output Class Initialized
INFO - 2023-09-20 16:39:11 --> Security Class Initialized
INFO - 2023-09-20 16:39:11 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 16:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 16:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:11 --> Input Class Initialized
INFO - 2023-09-20 16:39:11 --> Input Class Initialized
INFO - 2023-09-20 16:39:11 --> Input Class Initialized
INFO - 2023-09-20 16:39:11 --> Language Class Initialized
INFO - 2023-09-20 16:39:11 --> Language Class Initialized
ERROR - 2023-09-20 16:39:11 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:39:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:39:11 --> Language Class Initialized
ERROR - 2023-09-20 16:39:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:39:14 --> Config Class Initialized
INFO - 2023-09-20 16:39:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:14 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:14 --> URI Class Initialized
INFO - 2023-09-20 16:39:14 --> Router Class Initialized
INFO - 2023-09-20 16:39:14 --> Output Class Initialized
INFO - 2023-09-20 16:39:14 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:14 --> Input Class Initialized
INFO - 2023-09-20 16:39:14 --> Language Class Initialized
INFO - 2023-09-20 16:39:14 --> Loader Class Initialized
INFO - 2023-09-20 16:39:14 --> Helper loaded: url_helper
INFO - 2023-09-20 16:39:14 --> Helper loaded: file_helper
INFO - 2023-09-20 16:39:14 --> Database Driver Class Initialized
INFO - 2023-09-20 16:39:14 --> Email Class Initialized
DEBUG - 2023-09-20 16:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:39:14 --> Controller Class Initialized
INFO - 2023-09-20 16:39:14 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:39:14 --> Model "Home_model" initialized
INFO - 2023-09-20 16:39:14 --> Helper loaded: download_helper
INFO - 2023-09-20 16:39:14 --> Helper loaded: form_helper
INFO - 2023-09-20 16:39:14 --> Form Validation Class Initialized
INFO - 2023-09-20 16:39:14 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:39:14 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:39:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:39:14 --> Final output sent to browser
DEBUG - 2023-09-20 16:39:14 --> Total execution time: 0.1125
INFO - 2023-09-20 16:39:31 --> Config Class Initialized
INFO - 2023-09-20 16:39:31 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:39:31 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:39:31 --> Utf8 Class Initialized
INFO - 2023-09-20 16:39:31 --> URI Class Initialized
INFO - 2023-09-20 16:39:31 --> Router Class Initialized
INFO - 2023-09-20 16:39:31 --> Output Class Initialized
INFO - 2023-09-20 16:39:31 --> Security Class Initialized
DEBUG - 2023-09-20 16:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:39:31 --> Input Class Initialized
INFO - 2023-09-20 16:39:31 --> Language Class Initialized
INFO - 2023-09-20 16:39:31 --> Loader Class Initialized
INFO - 2023-09-20 16:39:31 --> Helper loaded: url_helper
INFO - 2023-09-20 16:39:31 --> Helper loaded: file_helper
INFO - 2023-09-20 16:39:31 --> Database Driver Class Initialized
INFO - 2023-09-20 16:39:31 --> Email Class Initialized
DEBUG - 2023-09-20 16:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:39:32 --> Controller Class Initialized
INFO - 2023-09-20 16:39:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:39:32 --> Model "Home_model" initialized
INFO - 2023-09-20 16:39:32 --> Helper loaded: download_helper
INFO - 2023-09-20 16:39:32 --> Helper loaded: form_helper
INFO - 2023-09-20 16:39:32 --> Form Validation Class Initialized
INFO - 2023-09-20 16:39:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:39:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:39:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:39:32 --> Final output sent to browser
DEBUG - 2023-09-20 16:39:32 --> Total execution time: 0.3666
INFO - 2023-09-20 16:40:40 --> Config Class Initialized
INFO - 2023-09-20 16:40:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:40:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:40:40 --> Utf8 Class Initialized
INFO - 2023-09-20 16:40:40 --> URI Class Initialized
INFO - 2023-09-20 16:40:40 --> Router Class Initialized
INFO - 2023-09-20 16:40:40 --> Output Class Initialized
INFO - 2023-09-20 16:40:40 --> Security Class Initialized
DEBUG - 2023-09-20 16:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:40:40 --> Input Class Initialized
INFO - 2023-09-20 16:40:40 --> Language Class Initialized
INFO - 2023-09-20 16:40:40 --> Loader Class Initialized
INFO - 2023-09-20 16:40:40 --> Helper loaded: url_helper
INFO - 2023-09-20 16:40:40 --> Helper loaded: file_helper
INFO - 2023-09-20 16:40:40 --> Database Driver Class Initialized
INFO - 2023-09-20 16:40:40 --> Email Class Initialized
DEBUG - 2023-09-20 16:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:40:40 --> Controller Class Initialized
INFO - 2023-09-20 16:40:40 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:40:40 --> Model "Home_model" initialized
INFO - 2023-09-20 16:40:40 --> Helper loaded: download_helper
INFO - 2023-09-20 16:40:40 --> Helper loaded: form_helper
INFO - 2023-09-20 16:40:40 --> Form Validation Class Initialized
INFO - 2023-09-20 16:40:40 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:40:40 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:40:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:40:40 --> Final output sent to browser
DEBUG - 2023-09-20 16:40:40 --> Total execution time: 0.0935
INFO - 2023-09-20 16:40:46 --> Config Class Initialized
INFO - 2023-09-20 16:40:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:40:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:40:46 --> Utf8 Class Initialized
INFO - 2023-09-20 16:40:46 --> URI Class Initialized
INFO - 2023-09-20 16:40:46 --> Router Class Initialized
INFO - 2023-09-20 16:40:46 --> Output Class Initialized
INFO - 2023-09-20 16:40:46 --> Security Class Initialized
DEBUG - 2023-09-20 16:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:40:46 --> Input Class Initialized
INFO - 2023-09-20 16:40:46 --> Language Class Initialized
INFO - 2023-09-20 16:40:46 --> Loader Class Initialized
INFO - 2023-09-20 16:40:46 --> Helper loaded: url_helper
INFO - 2023-09-20 16:40:46 --> Helper loaded: file_helper
INFO - 2023-09-20 16:40:46 --> Database Driver Class Initialized
INFO - 2023-09-20 16:40:46 --> Email Class Initialized
DEBUG - 2023-09-20 16:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:40:46 --> Controller Class Initialized
INFO - 2023-09-20 16:40:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:40:46 --> Model "Home_model" initialized
INFO - 2023-09-20 16:40:46 --> Helper loaded: download_helper
INFO - 2023-09-20 16:40:46 --> Helper loaded: form_helper
INFO - 2023-09-20 16:40:46 --> Form Validation Class Initialized
INFO - 2023-09-20 16:40:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:40:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:40:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:40:46 --> Final output sent to browser
DEBUG - 2023-09-20 16:40:46 --> Total execution time: 0.0882
INFO - 2023-09-20 16:40:53 --> Config Class Initialized
INFO - 2023-09-20 16:40:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:40:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:40:53 --> Utf8 Class Initialized
INFO - 2023-09-20 16:40:53 --> URI Class Initialized
INFO - 2023-09-20 16:40:53 --> Router Class Initialized
INFO - 2023-09-20 16:40:53 --> Output Class Initialized
INFO - 2023-09-20 16:40:53 --> Security Class Initialized
DEBUG - 2023-09-20 16:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:40:53 --> Input Class Initialized
INFO - 2023-09-20 16:40:53 --> Language Class Initialized
INFO - 2023-09-20 16:40:53 --> Loader Class Initialized
INFO - 2023-09-20 16:40:53 --> Helper loaded: url_helper
INFO - 2023-09-20 16:40:53 --> Helper loaded: file_helper
INFO - 2023-09-20 16:40:53 --> Database Driver Class Initialized
INFO - 2023-09-20 16:40:53 --> Email Class Initialized
DEBUG - 2023-09-20 16:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:40:53 --> Controller Class Initialized
INFO - 2023-09-20 16:40:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:40:53 --> Model "Home_model" initialized
INFO - 2023-09-20 16:40:53 --> Helper loaded: download_helper
INFO - 2023-09-20 16:40:53 --> Helper loaded: form_helper
INFO - 2023-09-20 16:40:53 --> Form Validation Class Initialized
INFO - 2023-09-20 16:40:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:40:53 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:40:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:40:53 --> Final output sent to browser
DEBUG - 2023-09-20 16:40:53 --> Total execution time: 0.0900
INFO - 2023-09-20 16:42:27 --> Config Class Initialized
INFO - 2023-09-20 16:42:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:42:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:42:27 --> Utf8 Class Initialized
INFO - 2023-09-20 16:42:27 --> URI Class Initialized
INFO - 2023-09-20 16:42:27 --> Router Class Initialized
INFO - 2023-09-20 16:42:27 --> Output Class Initialized
INFO - 2023-09-20 16:42:27 --> Security Class Initialized
DEBUG - 2023-09-20 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:42:27 --> Input Class Initialized
INFO - 2023-09-20 16:42:27 --> Language Class Initialized
INFO - 2023-09-20 16:42:27 --> Loader Class Initialized
INFO - 2023-09-20 16:42:27 --> Helper loaded: url_helper
INFO - 2023-09-20 16:42:27 --> Helper loaded: file_helper
INFO - 2023-09-20 16:42:27 --> Database Driver Class Initialized
INFO - 2023-09-20 16:42:27 --> Email Class Initialized
DEBUG - 2023-09-20 16:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:42:27 --> Controller Class Initialized
INFO - 2023-09-20 16:42:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:42:27 --> Model "Home_model" initialized
INFO - 2023-09-20 16:42:27 --> Helper loaded: download_helper
INFO - 2023-09-20 16:42:27 --> Helper loaded: form_helper
INFO - 2023-09-20 16:42:27 --> Form Validation Class Initialized
INFO - 2023-09-20 16:42:27 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:42:27 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:42:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 16:42:27 --> Final output sent to browser
DEBUG - 2023-09-20 16:42:27 --> Total execution time: 0.1603
INFO - 2023-09-20 16:42:56 --> Config Class Initialized
INFO - 2023-09-20 16:42:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:42:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:42:56 --> Utf8 Class Initialized
INFO - 2023-09-20 16:42:56 --> URI Class Initialized
INFO - 2023-09-20 16:42:56 --> Router Class Initialized
INFO - 2023-09-20 16:42:56 --> Output Class Initialized
INFO - 2023-09-20 16:42:56 --> Security Class Initialized
DEBUG - 2023-09-20 16:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:42:56 --> Input Class Initialized
INFO - 2023-09-20 16:42:56 --> Language Class Initialized
INFO - 2023-09-20 16:42:56 --> Loader Class Initialized
INFO - 2023-09-20 16:42:56 --> Helper loaded: url_helper
INFO - 2023-09-20 16:42:56 --> Helper loaded: file_helper
INFO - 2023-09-20 16:42:56 --> Database Driver Class Initialized
INFO - 2023-09-20 16:42:56 --> Email Class Initialized
DEBUG - 2023-09-20 16:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:42:56 --> Controller Class Initialized
INFO - 2023-09-20 16:42:56 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:42:56 --> Model "Home_model" initialized
INFO - 2023-09-20 16:42:56 --> Helper loaded: download_helper
INFO - 2023-09-20 16:42:56 --> Helper loaded: form_helper
INFO - 2023-09-20 16:42:56 --> Form Validation Class Initialized
INFO - 2023-09-20 16:42:56 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:42:56 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:42:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 16:42:56 --> Final output sent to browser
DEBUG - 2023-09-20 16:42:56 --> Total execution time: 0.1817
INFO - 2023-09-20 16:46:53 --> Config Class Initialized
INFO - 2023-09-20 16:46:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:46:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:46:53 --> Utf8 Class Initialized
INFO - 2023-09-20 16:46:53 --> URI Class Initialized
INFO - 2023-09-20 16:46:53 --> Router Class Initialized
INFO - 2023-09-20 16:46:53 --> Output Class Initialized
INFO - 2023-09-20 16:46:53 --> Security Class Initialized
DEBUG - 2023-09-20 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:46:53 --> Input Class Initialized
INFO - 2023-09-20 16:46:53 --> Language Class Initialized
INFO - 2023-09-20 16:46:53 --> Loader Class Initialized
INFO - 2023-09-20 16:46:53 --> Helper loaded: url_helper
INFO - 2023-09-20 16:46:53 --> Helper loaded: file_helper
INFO - 2023-09-20 16:46:53 --> Database Driver Class Initialized
INFO - 2023-09-20 16:46:53 --> Email Class Initialized
DEBUG - 2023-09-20 16:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:46:53 --> Controller Class Initialized
INFO - 2023-09-20 16:46:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:46:53 --> Model "Home_model" initialized
INFO - 2023-09-20 16:46:53 --> Helper loaded: download_helper
INFO - 2023-09-20 16:46:53 --> Helper loaded: form_helper
INFO - 2023-09-20 16:46:53 --> Form Validation Class Initialized
INFO - 2023-09-20 16:46:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:46:53 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:46:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 16:46:53 --> Final output sent to browser
DEBUG - 2023-09-20 16:46:53 --> Total execution time: 0.1468
INFO - 2023-09-20 16:47:10 --> Config Class Initialized
INFO - 2023-09-20 16:47:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:47:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:47:10 --> Utf8 Class Initialized
INFO - 2023-09-20 16:47:10 --> URI Class Initialized
INFO - 2023-09-20 16:47:10 --> Router Class Initialized
INFO - 2023-09-20 16:47:10 --> Output Class Initialized
INFO - 2023-09-20 16:47:10 --> Security Class Initialized
DEBUG - 2023-09-20 16:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:47:10 --> Input Class Initialized
INFO - 2023-09-20 16:47:10 --> Language Class Initialized
INFO - 2023-09-20 16:47:10 --> Loader Class Initialized
INFO - 2023-09-20 16:47:10 --> Helper loaded: url_helper
INFO - 2023-09-20 16:47:10 --> Helper loaded: file_helper
INFO - 2023-09-20 16:47:10 --> Database Driver Class Initialized
INFO - 2023-09-20 16:47:10 --> Email Class Initialized
DEBUG - 2023-09-20 16:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:47:10 --> Controller Class Initialized
INFO - 2023-09-20 16:47:10 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:47:10 --> Model "Home_model" initialized
INFO - 2023-09-20 16:47:10 --> Helper loaded: download_helper
INFO - 2023-09-20 16:47:10 --> Helper loaded: form_helper
INFO - 2023-09-20 16:47:11 --> Form Validation Class Initialized
INFO - 2023-09-20 16:47:11 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:47:11 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:47:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 16:47:11 --> Final output sent to browser
DEBUG - 2023-09-20 16:47:11 --> Total execution time: 0.1267
INFO - 2023-09-20 16:48:22 --> Config Class Initialized
INFO - 2023-09-20 16:48:22 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:48:22 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:48:22 --> Utf8 Class Initialized
INFO - 2023-09-20 16:48:22 --> URI Class Initialized
INFO - 2023-09-20 16:48:22 --> Router Class Initialized
INFO - 2023-09-20 16:48:22 --> Output Class Initialized
INFO - 2023-09-20 16:48:22 --> Security Class Initialized
DEBUG - 2023-09-20 16:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:48:22 --> Input Class Initialized
INFO - 2023-09-20 16:48:22 --> Language Class Initialized
INFO - 2023-09-20 16:48:22 --> Loader Class Initialized
INFO - 2023-09-20 16:48:22 --> Helper loaded: url_helper
INFO - 2023-09-20 16:48:22 --> Helper loaded: file_helper
INFO - 2023-09-20 16:48:22 --> Database Driver Class Initialized
INFO - 2023-09-20 16:48:22 --> Email Class Initialized
DEBUG - 2023-09-20 16:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:48:22 --> Controller Class Initialized
INFO - 2023-09-20 16:48:22 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:48:22 --> Model "Home_model" initialized
INFO - 2023-09-20 16:48:22 --> Helper loaded: download_helper
INFO - 2023-09-20 16:48:22 --> Helper loaded: form_helper
INFO - 2023-09-20 16:48:22 --> Form Validation Class Initialized
INFO - 2023-09-20 16:48:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:48:23 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:48:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:48:23 --> Final output sent to browser
DEBUG - 2023-09-20 16:48:23 --> Total execution time: 0.2109
INFO - 2023-09-20 16:55:28 --> Config Class Initialized
INFO - 2023-09-20 16:55:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:55:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:55:28 --> Utf8 Class Initialized
INFO - 2023-09-20 16:55:28 --> URI Class Initialized
INFO - 2023-09-20 16:55:28 --> Router Class Initialized
INFO - 2023-09-20 16:55:28 --> Output Class Initialized
INFO - 2023-09-20 16:55:28 --> Security Class Initialized
DEBUG - 2023-09-20 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:55:28 --> Input Class Initialized
INFO - 2023-09-20 16:55:28 --> Language Class Initialized
INFO - 2023-09-20 16:55:28 --> Loader Class Initialized
INFO - 2023-09-20 16:55:28 --> Helper loaded: url_helper
INFO - 2023-09-20 16:55:28 --> Helper loaded: file_helper
INFO - 2023-09-20 16:55:28 --> Database Driver Class Initialized
INFO - 2023-09-20 16:55:28 --> Email Class Initialized
DEBUG - 2023-09-20 16:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:55:28 --> Controller Class Initialized
INFO - 2023-09-20 16:55:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:55:28 --> Model "Home_model" initialized
INFO - 2023-09-20 16:55:28 --> Helper loaded: download_helper
INFO - 2023-09-20 16:55:28 --> Helper loaded: form_helper
INFO - 2023-09-20 16:55:28 --> Form Validation Class Initialized
INFO - 2023-09-20 16:55:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:55:28 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:55:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 16:55:28 --> Final output sent to browser
DEBUG - 2023-09-20 16:55:28 --> Total execution time: 0.2362
INFO - 2023-09-20 16:55:45 --> Config Class Initialized
INFO - 2023-09-20 16:55:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:55:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:55:45 --> Utf8 Class Initialized
INFO - 2023-09-20 16:55:45 --> URI Class Initialized
DEBUG - 2023-09-20 16:55:45 --> No URI present. Default controller set.
INFO - 2023-09-20 16:55:45 --> Router Class Initialized
INFO - 2023-09-20 16:55:45 --> Output Class Initialized
INFO - 2023-09-20 16:55:45 --> Security Class Initialized
DEBUG - 2023-09-20 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:55:45 --> Input Class Initialized
INFO - 2023-09-20 16:55:45 --> Language Class Initialized
INFO - 2023-09-20 16:55:45 --> Loader Class Initialized
INFO - 2023-09-20 16:55:45 --> Helper loaded: url_helper
INFO - 2023-09-20 16:55:45 --> Helper loaded: file_helper
INFO - 2023-09-20 16:55:45 --> Database Driver Class Initialized
INFO - 2023-09-20 16:55:45 --> Email Class Initialized
DEBUG - 2023-09-20 16:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:55:45 --> Controller Class Initialized
INFO - 2023-09-20 16:55:45 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:55:45 --> Model "Home_model" initialized
INFO - 2023-09-20 16:55:45 --> Helper loaded: download_helper
INFO - 2023-09-20 16:55:45 --> Helper loaded: form_helper
INFO - 2023-09-20 16:55:45 --> Form Validation Class Initialized
INFO - 2023-09-20 16:55:45 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:55:45 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:55:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 16:55:45 --> Final output sent to browser
DEBUG - 2023-09-20 16:55:45 --> Total execution time: 0.1482
INFO - 2023-09-20 16:56:01 --> Config Class Initialized
INFO - 2023-09-20 16:56:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:56:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:01 --> Utf8 Class Initialized
INFO - 2023-09-20 16:56:01 --> URI Class Initialized
INFO - 2023-09-20 16:56:01 --> Router Class Initialized
INFO - 2023-09-20 16:56:01 --> Output Class Initialized
INFO - 2023-09-20 16:56:01 --> Security Class Initialized
DEBUG - 2023-09-20 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:56:01 --> Input Class Initialized
INFO - 2023-09-20 16:56:01 --> Language Class Initialized
ERROR - 2023-09-20 16:56:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:56:02 --> Config Class Initialized
INFO - 2023-09-20 16:56:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:56:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:02 --> Config Class Initialized
INFO - 2023-09-20 16:56:02 --> Hooks Class Initialized
INFO - 2023-09-20 16:56:02 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:56:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:02 --> URI Class Initialized
INFO - 2023-09-20 16:56:02 --> Utf8 Class Initialized
INFO - 2023-09-20 16:56:02 --> Router Class Initialized
INFO - 2023-09-20 16:56:02 --> URI Class Initialized
INFO - 2023-09-20 16:56:02 --> Output Class Initialized
INFO - 2023-09-20 16:56:02 --> Router Class Initialized
INFO - 2023-09-20 16:56:02 --> Security Class Initialized
INFO - 2023-09-20 16:56:02 --> Output Class Initialized
DEBUG - 2023-09-20 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:56:02 --> Security Class Initialized
INFO - 2023-09-20 16:56:02 --> Input Class Initialized
DEBUG - 2023-09-20 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:56:02 --> Language Class Initialized
INFO - 2023-09-20 16:56:02 --> Input Class Initialized
INFO - 2023-09-20 16:56:02 --> Language Class Initialized
ERROR - 2023-09-20 16:56:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:56:02 --> Config Class Initialized
ERROR - 2023-09-20 16:56:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:56:02 --> Config Class Initialized
INFO - 2023-09-20 16:56:02 --> Config Class Initialized
INFO - 2023-09-20 16:56:02 --> Hooks Class Initialized
INFO - 2023-09-20 16:56:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:56:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:03 --> Hooks Class Initialized
INFO - 2023-09-20 16:56:03 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 16:56:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:03 --> Utf8 Class Initialized
INFO - 2023-09-20 16:56:03 --> Utf8 Class Initialized
INFO - 2023-09-20 16:56:03 --> URI Class Initialized
INFO - 2023-09-20 16:56:03 --> URI Class Initialized
INFO - 2023-09-20 16:56:03 --> URI Class Initialized
INFO - 2023-09-20 16:56:03 --> Router Class Initialized
INFO - 2023-09-20 16:56:03 --> Router Class Initialized
INFO - 2023-09-20 16:56:03 --> Router Class Initialized
INFO - 2023-09-20 16:56:03 --> Output Class Initialized
INFO - 2023-09-20 16:56:03 --> Output Class Initialized
INFO - 2023-09-20 16:56:03 --> Output Class Initialized
INFO - 2023-09-20 16:56:03 --> Security Class Initialized
INFO - 2023-09-20 16:56:03 --> Security Class Initialized
INFO - 2023-09-20 16:56:03 --> Security Class Initialized
DEBUG - 2023-09-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:56:03 --> Input Class Initialized
INFO - 2023-09-20 16:56:03 --> Input Class Initialized
INFO - 2023-09-20 16:56:03 --> Input Class Initialized
INFO - 2023-09-20 16:56:03 --> Language Class Initialized
INFO - 2023-09-20 16:56:03 --> Language Class Initialized
INFO - 2023-09-20 16:56:03 --> Language Class Initialized
ERROR - 2023-09-20 16:56:03 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:56:03 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:56:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:56:03 --> Config Class Initialized
INFO - 2023-09-20 16:56:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:56:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:56:03 --> Utf8 Class Initialized
INFO - 2023-09-20 16:56:03 --> URI Class Initialized
INFO - 2023-09-20 16:56:03 --> Router Class Initialized
INFO - 2023-09-20 16:56:03 --> Output Class Initialized
INFO - 2023-09-20 16:56:03 --> Security Class Initialized
DEBUG - 2023-09-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:56:03 --> Input Class Initialized
INFO - 2023-09-20 16:56:03 --> Language Class Initialized
ERROR - 2023-09-20 16:56:03 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:57:05 --> Config Class Initialized
INFO - 2023-09-20 16:57:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:57:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:57:05 --> Utf8 Class Initialized
INFO - 2023-09-20 16:57:05 --> URI Class Initialized
DEBUG - 2023-09-20 16:57:05 --> No URI present. Default controller set.
INFO - 2023-09-20 16:57:05 --> Router Class Initialized
INFO - 2023-09-20 16:57:05 --> Output Class Initialized
INFO - 2023-09-20 16:57:05 --> Security Class Initialized
DEBUG - 2023-09-20 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:57:05 --> Input Class Initialized
INFO - 2023-09-20 16:57:05 --> Language Class Initialized
INFO - 2023-09-20 16:57:05 --> Loader Class Initialized
INFO - 2023-09-20 16:57:05 --> Helper loaded: url_helper
INFO - 2023-09-20 16:57:05 --> Helper loaded: file_helper
INFO - 2023-09-20 16:57:05 --> Database Driver Class Initialized
INFO - 2023-09-20 16:57:05 --> Email Class Initialized
DEBUG - 2023-09-20 16:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 16:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 16:57:05 --> Controller Class Initialized
INFO - 2023-09-20 16:57:05 --> Model "Contact_model" initialized
INFO - 2023-09-20 16:57:05 --> Model "Home_model" initialized
INFO - 2023-09-20 16:57:05 --> Helper loaded: download_helper
INFO - 2023-09-20 16:57:05 --> Helper loaded: form_helper
INFO - 2023-09-20 16:57:05 --> Form Validation Class Initialized
INFO - 2023-09-20 16:57:05 --> Helper loaded: custom_helper
INFO - 2023-09-20 16:57:05 --> Model "Social_media_model" initialized
INFO - 2023-09-20 16:57:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 16:57:05 --> Final output sent to browser
DEBUG - 2023-09-20 16:57:06 --> Total execution time: 0.1637
INFO - 2023-09-20 16:57:08 --> Config Class Initialized
INFO - 2023-09-20 16:57:08 --> Hooks Class Initialized
INFO - 2023-09-20 16:57:08 --> Config Class Initialized
INFO - 2023-09-20 16:57:08 --> Config Class Initialized
INFO - 2023-09-20 16:57:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 16:57:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:57:08 --> Utf8 Class Initialized
INFO - 2023-09-20 16:57:08 --> URI Class Initialized
INFO - 2023-09-20 16:57:08 --> Router Class Initialized
INFO - 2023-09-20 16:57:08 --> Output Class Initialized
INFO - 2023-09-20 16:57:08 --> Security Class Initialized
DEBUG - 2023-09-20 16:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:57:08 --> Input Class Initialized
INFO - 2023-09-20 16:57:08 --> Language Class Initialized
ERROR - 2023-09-20 16:57:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:57:08 --> Hooks Class Initialized
INFO - 2023-09-20 16:57:09 --> Config Class Initialized
DEBUG - 2023-09-20 16:57:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:57:09 --> Hooks Class Initialized
INFO - 2023-09-20 16:57:09 --> Utf8 Class Initialized
DEBUG - 2023-09-20 16:57:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 16:57:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 16:57:09 --> Utf8 Class Initialized
INFO - 2023-09-20 16:57:09 --> URI Class Initialized
INFO - 2023-09-20 16:57:09 --> Utf8 Class Initialized
INFO - 2023-09-20 16:57:09 --> URI Class Initialized
INFO - 2023-09-20 16:57:09 --> Router Class Initialized
INFO - 2023-09-20 16:57:09 --> URI Class Initialized
INFO - 2023-09-20 16:57:09 --> Router Class Initialized
INFO - 2023-09-20 16:57:09 --> Output Class Initialized
INFO - 2023-09-20 16:57:09 --> Router Class Initialized
INFO - 2023-09-20 16:57:09 --> Output Class Initialized
INFO - 2023-09-20 16:57:09 --> Security Class Initialized
INFO - 2023-09-20 16:57:09 --> Output Class Initialized
INFO - 2023-09-20 16:57:09 --> Security Class Initialized
DEBUG - 2023-09-20 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:57:09 --> Security Class Initialized
DEBUG - 2023-09-20 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:57:09 --> Input Class Initialized
DEBUG - 2023-09-20 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 16:57:09 --> Input Class Initialized
INFO - 2023-09-20 16:57:09 --> Language Class Initialized
INFO - 2023-09-20 16:57:09 --> Input Class Initialized
INFO - 2023-09-20 16:57:09 --> Language Class Initialized
ERROR - 2023-09-20 16:57:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 16:57:09 --> Language Class Initialized
ERROR - 2023-09-20 16:57:09 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 16:57:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:02:32 --> Config Class Initialized
INFO - 2023-09-20 17:02:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:02:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:02:32 --> Utf8 Class Initialized
INFO - 2023-09-20 17:02:32 --> URI Class Initialized
INFO - 2023-09-20 17:02:32 --> Router Class Initialized
INFO - 2023-09-20 17:02:32 --> Output Class Initialized
INFO - 2023-09-20 17:02:32 --> Security Class Initialized
DEBUG - 2023-09-20 17:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:02:32 --> Input Class Initialized
INFO - 2023-09-20 17:02:32 --> Language Class Initialized
INFO - 2023-09-20 17:02:32 --> Loader Class Initialized
INFO - 2023-09-20 17:02:32 --> Helper loaded: url_helper
INFO - 2023-09-20 17:02:32 --> Helper loaded: file_helper
INFO - 2023-09-20 17:02:32 --> Database Driver Class Initialized
INFO - 2023-09-20 17:02:32 --> Email Class Initialized
DEBUG - 2023-09-20 17:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:02:32 --> Controller Class Initialized
INFO - 2023-09-20 17:02:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:02:32 --> Model "Home_model" initialized
INFO - 2023-09-20 17:02:32 --> Helper loaded: download_helper
INFO - 2023-09-20 17:02:32 --> Helper loaded: form_helper
INFO - 2023-09-20 17:02:32 --> Form Validation Class Initialized
INFO - 2023-09-20 17:02:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:02:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:02:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:02:33 --> Final output sent to browser
DEBUG - 2023-09-20 17:02:33 --> Total execution time: 0.9737
INFO - 2023-09-20 17:02:45 --> Config Class Initialized
INFO - 2023-09-20 17:02:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:02:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:02:45 --> Utf8 Class Initialized
INFO - 2023-09-20 17:02:45 --> URI Class Initialized
INFO - 2023-09-20 17:02:45 --> Router Class Initialized
INFO - 2023-09-20 17:02:45 --> Output Class Initialized
INFO - 2023-09-20 17:02:45 --> Security Class Initialized
DEBUG - 2023-09-20 17:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:02:45 --> Input Class Initialized
INFO - 2023-09-20 17:02:45 --> Language Class Initialized
INFO - 2023-09-20 17:02:45 --> Loader Class Initialized
INFO - 2023-09-20 17:02:45 --> Helper loaded: url_helper
INFO - 2023-09-20 17:02:45 --> Helper loaded: file_helper
INFO - 2023-09-20 17:02:45 --> Database Driver Class Initialized
INFO - 2023-09-20 17:02:45 --> Email Class Initialized
DEBUG - 2023-09-20 17:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:02:45 --> Controller Class Initialized
INFO - 2023-09-20 17:02:45 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:02:45 --> Model "Home_model" initialized
INFO - 2023-09-20 17:02:45 --> Helper loaded: download_helper
INFO - 2023-09-20 17:02:45 --> Helper loaded: form_helper
INFO - 2023-09-20 17:02:45 --> Form Validation Class Initialized
INFO - 2023-09-20 17:02:45 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:02:45 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:02:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:02:45 --> Final output sent to browser
DEBUG - 2023-09-20 17:02:45 --> Total execution time: 0.1504
INFO - 2023-09-20 17:03:36 --> Config Class Initialized
INFO - 2023-09-20 17:03:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:03:36 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:03:36 --> Utf8 Class Initialized
INFO - 2023-09-20 17:03:36 --> URI Class Initialized
INFO - 2023-09-20 17:03:36 --> Router Class Initialized
INFO - 2023-09-20 17:03:37 --> Output Class Initialized
INFO - 2023-09-20 17:03:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:03:37 --> Input Class Initialized
INFO - 2023-09-20 17:03:37 --> Language Class Initialized
INFO - 2023-09-20 17:03:37 --> Loader Class Initialized
INFO - 2023-09-20 17:03:37 --> Helper loaded: url_helper
INFO - 2023-09-20 17:03:37 --> Helper loaded: file_helper
INFO - 2023-09-20 17:03:37 --> Database Driver Class Initialized
INFO - 2023-09-20 17:03:37 --> Email Class Initialized
DEBUG - 2023-09-20 17:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:03:37 --> Controller Class Initialized
INFO - 2023-09-20 17:03:37 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:03:37 --> Model "Home_model" initialized
INFO - 2023-09-20 17:03:37 --> Helper loaded: download_helper
INFO - 2023-09-20 17:03:37 --> Helper loaded: form_helper
INFO - 2023-09-20 17:03:38 --> Form Validation Class Initialized
INFO - 2023-09-20 17:03:38 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:03:38 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:03:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:03:38 --> Final output sent to browser
DEBUG - 2023-09-20 17:03:38 --> Total execution time: 12.5740
INFO - 2023-09-20 17:04:05 --> Config Class Initialized
INFO - 2023-09-20 17:04:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:04:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:04:05 --> Utf8 Class Initialized
INFO - 2023-09-20 17:04:05 --> URI Class Initialized
INFO - 2023-09-20 17:04:05 --> Router Class Initialized
INFO - 2023-09-20 17:04:05 --> Output Class Initialized
INFO - 2023-09-20 17:04:05 --> Security Class Initialized
DEBUG - 2023-09-20 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:04:05 --> Input Class Initialized
INFO - 2023-09-20 17:04:05 --> Language Class Initialized
INFO - 2023-09-20 17:04:05 --> Loader Class Initialized
INFO - 2023-09-20 17:04:05 --> Helper loaded: url_helper
INFO - 2023-09-20 17:04:05 --> Helper loaded: file_helper
INFO - 2023-09-20 17:04:05 --> Database Driver Class Initialized
INFO - 2023-09-20 17:04:05 --> Email Class Initialized
DEBUG - 2023-09-20 17:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:04:05 --> Controller Class Initialized
INFO - 2023-09-20 17:04:05 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:04:05 --> Model "Home_model" initialized
INFO - 2023-09-20 17:04:05 --> Helper loaded: download_helper
INFO - 2023-09-20 17:04:05 --> Helper loaded: form_helper
INFO - 2023-09-20 17:04:05 --> Form Validation Class Initialized
INFO - 2023-09-20 17:04:05 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:04:05 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:04:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:04:05 --> Final output sent to browser
DEBUG - 2023-09-20 17:04:05 --> Total execution time: 0.2999
INFO - 2023-09-20 17:04:41 --> Config Class Initialized
INFO - 2023-09-20 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:04:41 --> Utf8 Class Initialized
INFO - 2023-09-20 17:04:41 --> URI Class Initialized
INFO - 2023-09-20 17:04:41 --> Router Class Initialized
INFO - 2023-09-20 17:04:41 --> Output Class Initialized
INFO - 2023-09-20 17:04:41 --> Security Class Initialized
DEBUG - 2023-09-20 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:04:41 --> Input Class Initialized
INFO - 2023-09-20 17:04:41 --> Language Class Initialized
INFO - 2023-09-20 17:04:41 --> Loader Class Initialized
INFO - 2023-09-20 17:04:41 --> Helper loaded: url_helper
INFO - 2023-09-20 17:04:41 --> Helper loaded: file_helper
INFO - 2023-09-20 17:04:41 --> Database Driver Class Initialized
INFO - 2023-09-20 17:04:41 --> Email Class Initialized
DEBUG - 2023-09-20 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:04:41 --> Controller Class Initialized
INFO - 2023-09-20 17:04:41 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:04:41 --> Model "Home_model" initialized
INFO - 2023-09-20 17:04:41 --> Helper loaded: download_helper
INFO - 2023-09-20 17:04:41 --> Helper loaded: form_helper
INFO - 2023-09-20 17:04:41 --> Form Validation Class Initialized
INFO - 2023-09-20 17:04:41 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:04:41 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:04:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:04:41 --> Final output sent to browser
DEBUG - 2023-09-20 17:04:41 --> Total execution time: 0.1708
INFO - 2023-09-20 17:05:46 --> Config Class Initialized
INFO - 2023-09-20 17:05:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:05:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:05:46 --> Utf8 Class Initialized
INFO - 2023-09-20 17:05:46 --> URI Class Initialized
INFO - 2023-09-20 17:05:46 --> Router Class Initialized
INFO - 2023-09-20 17:05:46 --> Output Class Initialized
INFO - 2023-09-20 17:05:46 --> Security Class Initialized
DEBUG - 2023-09-20 17:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:05:46 --> Input Class Initialized
INFO - 2023-09-20 17:05:46 --> Language Class Initialized
INFO - 2023-09-20 17:05:46 --> Loader Class Initialized
INFO - 2023-09-20 17:05:46 --> Helper loaded: url_helper
INFO - 2023-09-20 17:05:46 --> Helper loaded: file_helper
INFO - 2023-09-20 17:05:46 --> Database Driver Class Initialized
INFO - 2023-09-20 17:05:46 --> Email Class Initialized
DEBUG - 2023-09-20 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:05:46 --> Controller Class Initialized
INFO - 2023-09-20 17:05:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:05:46 --> Model "Home_model" initialized
INFO - 2023-09-20 17:05:46 --> Helper loaded: download_helper
INFO - 2023-09-20 17:05:46 --> Helper loaded: form_helper
INFO - 2023-09-20 17:05:46 --> Form Validation Class Initialized
INFO - 2023-09-20 17:05:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:05:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:05:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:05:46 --> Final output sent to browser
DEBUG - 2023-09-20 17:05:47 --> Total execution time: 0.1589
INFO - 2023-09-20 17:05:53 --> Config Class Initialized
INFO - 2023-09-20 17:05:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:05:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:05:53 --> Utf8 Class Initialized
INFO - 2023-09-20 17:05:53 --> URI Class Initialized
INFO - 2023-09-20 17:05:53 --> Router Class Initialized
INFO - 2023-09-20 17:05:53 --> Output Class Initialized
INFO - 2023-09-20 17:05:53 --> Security Class Initialized
DEBUG - 2023-09-20 17:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:05:53 --> Input Class Initialized
INFO - 2023-09-20 17:05:53 --> Language Class Initialized
INFO - 2023-09-20 17:05:53 --> Loader Class Initialized
INFO - 2023-09-20 17:05:53 --> Helper loaded: url_helper
INFO - 2023-09-20 17:05:53 --> Helper loaded: file_helper
INFO - 2023-09-20 17:05:53 --> Database Driver Class Initialized
INFO - 2023-09-20 17:05:54 --> Email Class Initialized
DEBUG - 2023-09-20 17:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:05:54 --> Controller Class Initialized
INFO - 2023-09-20 17:05:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:05:54 --> Model "Home_model" initialized
INFO - 2023-09-20 17:05:54 --> Helper loaded: download_helper
INFO - 2023-09-20 17:05:54 --> Helper loaded: form_helper
INFO - 2023-09-20 17:05:54 --> Form Validation Class Initialized
INFO - 2023-09-20 17:05:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:05:54 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:05:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:05:54 --> Final output sent to browser
DEBUG - 2023-09-20 17:05:54 --> Total execution time: 0.3271
INFO - 2023-09-20 17:06:04 --> Config Class Initialized
INFO - 2023-09-20 17:06:04 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:06:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:06:04 --> Utf8 Class Initialized
INFO - 2023-09-20 17:06:04 --> URI Class Initialized
INFO - 2023-09-20 17:06:04 --> Router Class Initialized
INFO - 2023-09-20 17:06:04 --> Output Class Initialized
INFO - 2023-09-20 17:06:04 --> Security Class Initialized
DEBUG - 2023-09-20 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:06:04 --> Input Class Initialized
INFO - 2023-09-20 17:06:04 --> Language Class Initialized
INFO - 2023-09-20 17:06:04 --> Loader Class Initialized
INFO - 2023-09-20 17:06:04 --> Helper loaded: url_helper
INFO - 2023-09-20 17:06:04 --> Helper loaded: file_helper
INFO - 2023-09-20 17:06:04 --> Database Driver Class Initialized
INFO - 2023-09-20 17:06:04 --> Email Class Initialized
DEBUG - 2023-09-20 17:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:06:04 --> Controller Class Initialized
INFO - 2023-09-20 17:06:04 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:06:04 --> Model "Home_model" initialized
INFO - 2023-09-20 17:06:04 --> Helper loaded: download_helper
INFO - 2023-09-20 17:06:04 --> Helper loaded: form_helper
INFO - 2023-09-20 17:06:04 --> Form Validation Class Initialized
INFO - 2023-09-20 17:06:04 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:06:04 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:06:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:06:04 --> Final output sent to browser
DEBUG - 2023-09-20 17:06:04 --> Total execution time: 0.1479
INFO - 2023-09-20 17:06:08 --> Config Class Initialized
INFO - 2023-09-20 17:06:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:06:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:06:08 --> Utf8 Class Initialized
INFO - 2023-09-20 17:06:08 --> URI Class Initialized
INFO - 2023-09-20 17:06:08 --> Router Class Initialized
INFO - 2023-09-20 17:06:08 --> Output Class Initialized
INFO - 2023-09-20 17:06:08 --> Security Class Initialized
DEBUG - 2023-09-20 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:06:08 --> Input Class Initialized
INFO - 2023-09-20 17:06:08 --> Language Class Initialized
INFO - 2023-09-20 17:06:08 --> Loader Class Initialized
INFO - 2023-09-20 17:06:08 --> Helper loaded: url_helper
INFO - 2023-09-20 17:06:08 --> Helper loaded: file_helper
INFO - 2023-09-20 17:06:08 --> Database Driver Class Initialized
INFO - 2023-09-20 17:06:08 --> Email Class Initialized
DEBUG - 2023-09-20 17:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:06:08 --> Controller Class Initialized
INFO - 2023-09-20 17:06:08 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:06:08 --> Model "Home_model" initialized
INFO - 2023-09-20 17:06:08 --> Helper loaded: download_helper
INFO - 2023-09-20 17:06:08 --> Helper loaded: form_helper
INFO - 2023-09-20 17:06:08 --> Form Validation Class Initialized
INFO - 2023-09-20 17:06:08 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:06:08 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:06:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:06:08 --> Final output sent to browser
DEBUG - 2023-09-20 17:06:08 --> Total execution time: 0.0757
INFO - 2023-09-20 17:08:58 --> Config Class Initialized
INFO - 2023-09-20 17:08:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:08:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:08:58 --> Utf8 Class Initialized
INFO - 2023-09-20 17:08:58 --> URI Class Initialized
INFO - 2023-09-20 17:08:58 --> Router Class Initialized
INFO - 2023-09-20 17:08:58 --> Output Class Initialized
INFO - 2023-09-20 17:08:58 --> Security Class Initialized
DEBUG - 2023-09-20 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:08:58 --> Input Class Initialized
INFO - 2023-09-20 17:08:58 --> Language Class Initialized
INFO - 2023-09-20 17:08:58 --> Loader Class Initialized
INFO - 2023-09-20 17:08:58 --> Helper loaded: url_helper
INFO - 2023-09-20 17:08:58 --> Helper loaded: file_helper
INFO - 2023-09-20 17:08:58 --> Database Driver Class Initialized
INFO - 2023-09-20 17:08:58 --> Email Class Initialized
DEBUG - 2023-09-20 17:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:08:59 --> Controller Class Initialized
INFO - 2023-09-20 17:08:59 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:08:59 --> Model "Home_model" initialized
INFO - 2023-09-20 17:08:59 --> Helper loaded: download_helper
INFO - 2023-09-20 17:08:59 --> Helper loaded: form_helper
INFO - 2023-09-20 17:08:59 --> Form Validation Class Initialized
INFO - 2023-09-20 17:08:59 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:08:59 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:08:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:08:59 --> Final output sent to browser
DEBUG - 2023-09-20 17:08:59 --> Total execution time: 0.1765
INFO - 2023-09-20 17:09:14 --> Config Class Initialized
INFO - 2023-09-20 17:09:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:09:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:09:14 --> Utf8 Class Initialized
INFO - 2023-09-20 17:09:14 --> URI Class Initialized
INFO - 2023-09-20 17:09:14 --> Router Class Initialized
INFO - 2023-09-20 17:09:14 --> Output Class Initialized
INFO - 2023-09-20 17:09:14 --> Security Class Initialized
DEBUG - 2023-09-20 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:09:14 --> Input Class Initialized
INFO - 2023-09-20 17:09:14 --> Language Class Initialized
INFO - 2023-09-20 17:09:14 --> Loader Class Initialized
INFO - 2023-09-20 17:09:14 --> Helper loaded: url_helper
INFO - 2023-09-20 17:09:14 --> Helper loaded: file_helper
INFO - 2023-09-20 17:09:14 --> Database Driver Class Initialized
INFO - 2023-09-20 17:09:14 --> Email Class Initialized
DEBUG - 2023-09-20 17:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:09:14 --> Controller Class Initialized
INFO - 2023-09-20 17:09:14 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:09:14 --> Model "Home_model" initialized
INFO - 2023-09-20 17:09:14 --> Helper loaded: download_helper
INFO - 2023-09-20 17:09:14 --> Helper loaded: form_helper
INFO - 2023-09-20 17:09:14 --> Form Validation Class Initialized
INFO - 2023-09-20 17:09:14 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:09:14 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:09:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:09:14 --> Final output sent to browser
DEBUG - 2023-09-20 17:09:14 --> Total execution time: 0.0979
INFO - 2023-09-20 17:09:23 --> Config Class Initialized
INFO - 2023-09-20 17:09:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:09:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:09:23 --> Utf8 Class Initialized
INFO - 2023-09-20 17:09:23 --> URI Class Initialized
INFO - 2023-09-20 17:09:23 --> Router Class Initialized
INFO - 2023-09-20 17:09:23 --> Output Class Initialized
INFO - 2023-09-20 17:09:23 --> Security Class Initialized
DEBUG - 2023-09-20 17:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:09:23 --> Input Class Initialized
INFO - 2023-09-20 17:09:23 --> Language Class Initialized
INFO - 2023-09-20 17:09:23 --> Loader Class Initialized
INFO - 2023-09-20 17:09:23 --> Helper loaded: url_helper
INFO - 2023-09-20 17:09:23 --> Helper loaded: file_helper
INFO - 2023-09-20 17:09:23 --> Database Driver Class Initialized
INFO - 2023-09-20 17:09:23 --> Email Class Initialized
DEBUG - 2023-09-20 17:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:09:23 --> Controller Class Initialized
INFO - 2023-09-20 17:09:23 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:09:23 --> Model "Home_model" initialized
INFO - 2023-09-20 17:09:23 --> Helper loaded: download_helper
INFO - 2023-09-20 17:09:23 --> Helper loaded: form_helper
INFO - 2023-09-20 17:09:23 --> Form Validation Class Initialized
INFO - 2023-09-20 17:09:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:09:23 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:09:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:09:23 --> Final output sent to browser
DEBUG - 2023-09-20 17:09:23 --> Total execution time: 0.2066
INFO - 2023-09-20 17:09:27 --> Config Class Initialized
INFO - 2023-09-20 17:09:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:09:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:09:27 --> Utf8 Class Initialized
INFO - 2023-09-20 17:09:27 --> URI Class Initialized
INFO - 2023-09-20 17:09:27 --> Router Class Initialized
INFO - 2023-09-20 17:09:27 --> Output Class Initialized
INFO - 2023-09-20 17:09:27 --> Security Class Initialized
DEBUG - 2023-09-20 17:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:09:27 --> Input Class Initialized
INFO - 2023-09-20 17:09:27 --> Language Class Initialized
INFO - 2023-09-20 17:09:27 --> Loader Class Initialized
INFO - 2023-09-20 17:09:27 --> Helper loaded: url_helper
INFO - 2023-09-20 17:09:27 --> Helper loaded: file_helper
INFO - 2023-09-20 17:09:27 --> Database Driver Class Initialized
INFO - 2023-09-20 17:09:27 --> Email Class Initialized
DEBUG - 2023-09-20 17:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:09:27 --> Controller Class Initialized
INFO - 2023-09-20 17:09:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:09:27 --> Model "Home_model" initialized
INFO - 2023-09-20 17:09:27 --> Helper loaded: download_helper
INFO - 2023-09-20 17:09:27 --> Helper loaded: form_helper
INFO - 2023-09-20 17:09:27 --> Form Validation Class Initialized
INFO - 2023-09-20 17:09:27 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:09:27 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:09:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:09:27 --> Final output sent to browser
DEBUG - 2023-09-20 17:09:27 --> Total execution time: 0.0659
INFO - 2023-09-20 17:10:01 --> Config Class Initialized
INFO - 2023-09-20 17:10:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:01 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:01 --> URI Class Initialized
INFO - 2023-09-20 17:10:01 --> Router Class Initialized
INFO - 2023-09-20 17:10:01 --> Output Class Initialized
INFO - 2023-09-20 17:10:01 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:01 --> Input Class Initialized
INFO - 2023-09-20 17:10:01 --> Language Class Initialized
INFO - 2023-09-20 17:10:01 --> Loader Class Initialized
INFO - 2023-09-20 17:10:01 --> Helper loaded: url_helper
INFO - 2023-09-20 17:10:01 --> Helper loaded: file_helper
INFO - 2023-09-20 17:10:01 --> Database Driver Class Initialized
INFO - 2023-09-20 17:10:01 --> Email Class Initialized
DEBUG - 2023-09-20 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:10:01 --> Controller Class Initialized
INFO - 2023-09-20 17:10:01 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:10:01 --> Model "Home_model" initialized
INFO - 2023-09-20 17:10:01 --> Helper loaded: download_helper
INFO - 2023-09-20 17:10:01 --> Helper loaded: form_helper
INFO - 2023-09-20 17:10:01 --> Form Validation Class Initialized
ERROR - 2023-09-20 17:10:01 --> Query error: Unknown column 'coupon_id' in 'field list' - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `subject`, `coupon_id`, `message`, `services_ids`, `status`, `created_at`) VALUES ('CHAITU', 'REASH@GMAIL.COM', '9098878987', 'SSDFS', 'FFFFFFFFFF', 'SDFS', '8', 1, '2023-09-20 17:10:01')
INFO - 2023-09-20 17:10:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-20 17:10:10 --> Config Class Initialized
INFO - 2023-09-20 17:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:10 --> URI Class Initialized
INFO - 2023-09-20 17:10:10 --> Router Class Initialized
INFO - 2023-09-20 17:10:10 --> Output Class Initialized
INFO - 2023-09-20 17:10:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:10 --> Input Class Initialized
INFO - 2023-09-20 17:10:10 --> Language Class Initialized
ERROR - 2023-09-20 17:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:10 --> Config Class Initialized
INFO - 2023-09-20 17:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:10 --> URI Class Initialized
INFO - 2023-09-20 17:10:10 --> Router Class Initialized
INFO - 2023-09-20 17:10:10 --> Output Class Initialized
INFO - 2023-09-20 17:10:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:10 --> Input Class Initialized
INFO - 2023-09-20 17:10:10 --> Language Class Initialized
ERROR - 2023-09-20 17:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:10 --> Config Class Initialized
INFO - 2023-09-20 17:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:10 --> URI Class Initialized
INFO - 2023-09-20 17:10:10 --> Router Class Initialized
INFO - 2023-09-20 17:10:10 --> Output Class Initialized
INFO - 2023-09-20 17:10:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:10 --> Input Class Initialized
INFO - 2023-09-20 17:10:10 --> Language Class Initialized
ERROR - 2023-09-20 17:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:10 --> Config Class Initialized
INFO - 2023-09-20 17:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:10 --> URI Class Initialized
INFO - 2023-09-20 17:10:10 --> Router Class Initialized
INFO - 2023-09-20 17:10:10 --> Output Class Initialized
INFO - 2023-09-20 17:10:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:10 --> Input Class Initialized
INFO - 2023-09-20 17:10:10 --> Language Class Initialized
ERROR - 2023-09-20 17:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:10 --> Config Class Initialized
INFO - 2023-09-20 17:10:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:10 --> URI Class Initialized
INFO - 2023-09-20 17:10:10 --> Router Class Initialized
INFO - 2023-09-20 17:10:10 --> Output Class Initialized
INFO - 2023-09-20 17:10:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:10 --> Input Class Initialized
INFO - 2023-09-20 17:10:10 --> Language Class Initialized
ERROR - 2023-09-20 17:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:11 --> Config Class Initialized
INFO - 2023-09-20 17:10:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:11 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:11 --> URI Class Initialized
INFO - 2023-09-20 17:10:11 --> Router Class Initialized
INFO - 2023-09-20 17:10:11 --> Output Class Initialized
INFO - 2023-09-20 17:10:11 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:11 --> Input Class Initialized
INFO - 2023-09-20 17:10:11 --> Language Class Initialized
ERROR - 2023-09-20 17:10:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:11 --> Config Class Initialized
INFO - 2023-09-20 17:10:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:11 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:11 --> URI Class Initialized
INFO - 2023-09-20 17:10:11 --> Router Class Initialized
INFO - 2023-09-20 17:10:11 --> Output Class Initialized
INFO - 2023-09-20 17:10:11 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:11 --> Input Class Initialized
INFO - 2023-09-20 17:10:11 --> Language Class Initialized
ERROR - 2023-09-20 17:10:11 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:10:13 --> Config Class Initialized
INFO - 2023-09-20 17:10:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:10:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:10:13 --> Utf8 Class Initialized
INFO - 2023-09-20 17:10:13 --> URI Class Initialized
INFO - 2023-09-20 17:10:13 --> Router Class Initialized
INFO - 2023-09-20 17:10:13 --> Output Class Initialized
INFO - 2023-09-20 17:10:13 --> Security Class Initialized
DEBUG - 2023-09-20 17:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:10:13 --> Input Class Initialized
INFO - 2023-09-20 17:10:13 --> Language Class Initialized
INFO - 2023-09-20 17:10:13 --> Loader Class Initialized
INFO - 2023-09-20 17:10:13 --> Helper loaded: url_helper
INFO - 2023-09-20 17:10:13 --> Helper loaded: file_helper
INFO - 2023-09-20 17:10:13 --> Database Driver Class Initialized
INFO - 2023-09-20 17:10:13 --> Email Class Initialized
DEBUG - 2023-09-20 17:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:10:13 --> Controller Class Initialized
INFO - 2023-09-20 17:10:13 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:10:13 --> Model "Home_model" initialized
INFO - 2023-09-20 17:10:13 --> Helper loaded: download_helper
INFO - 2023-09-20 17:10:13 --> Helper loaded: form_helper
INFO - 2023-09-20 17:10:13 --> Form Validation Class Initialized
ERROR - 2023-09-20 17:10:13 --> Query error: Unknown column 'coupon_id' in 'field list' - Invalid query: INSERT INTO `contact` (`name`, `email`, `mobile`, `subject`, `coupon_id`, `message`, `services_ids`, `status`, `created_at`) VALUES ('CHAITU', 'REASH@GMAIL.COM', '9098878987', 'SSDFS', 'FFFFFFFFFF', 'SDFS', '8', 1, '2023-09-20 17:10:13')
INFO - 2023-09-20 17:10:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-20 17:11:05 --> Config Class Initialized
INFO - 2023-09-20 17:11:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:11:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:11:05 --> Utf8 Class Initialized
INFO - 2023-09-20 17:11:05 --> URI Class Initialized
INFO - 2023-09-20 17:11:05 --> Router Class Initialized
INFO - 2023-09-20 17:11:05 --> Output Class Initialized
INFO - 2023-09-20 17:11:05 --> Security Class Initialized
DEBUG - 2023-09-20 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:11:05 --> Input Class Initialized
INFO - 2023-09-20 17:11:05 --> Language Class Initialized
INFO - 2023-09-20 17:11:05 --> Loader Class Initialized
INFO - 2023-09-20 17:11:05 --> Helper loaded: url_helper
INFO - 2023-09-20 17:11:05 --> Helper loaded: file_helper
INFO - 2023-09-20 17:11:05 --> Database Driver Class Initialized
INFO - 2023-09-20 17:11:05 --> Email Class Initialized
DEBUG - 2023-09-20 17:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:11:05 --> Controller Class Initialized
INFO - 2023-09-20 17:11:05 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:11:05 --> Model "Home_model" initialized
INFO - 2023-09-20 17:11:05 --> Helper loaded: download_helper
INFO - 2023-09-20 17:11:05 --> Helper loaded: form_helper
INFO - 2023-09-20 17:11:05 --> Form Validation Class Initialized
INFO - 2023-09-20 17:11:42 --> Config Class Initialized
INFO - 2023-09-20 17:11:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:11:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:11:42 --> Utf8 Class Initialized
INFO - 2023-09-20 17:11:42 --> URI Class Initialized
INFO - 2023-09-20 17:11:42 --> Router Class Initialized
INFO - 2023-09-20 17:11:42 --> Output Class Initialized
INFO - 2023-09-20 17:11:42 --> Security Class Initialized
DEBUG - 2023-09-20 17:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:11:42 --> Input Class Initialized
INFO - 2023-09-20 17:11:42 --> Language Class Initialized
INFO - 2023-09-20 17:11:42 --> Loader Class Initialized
INFO - 2023-09-20 17:11:42 --> Helper loaded: url_helper
INFO - 2023-09-20 17:11:42 --> Helper loaded: file_helper
INFO - 2023-09-20 17:11:42 --> Database Driver Class Initialized
INFO - 2023-09-20 17:11:42 --> Email Class Initialized
DEBUG - 2023-09-20 17:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:11:42 --> Controller Class Initialized
INFO - 2023-09-20 17:11:42 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:11:42 --> Model "Home_model" initialized
INFO - 2023-09-20 17:11:42 --> Helper loaded: download_helper
INFO - 2023-09-20 17:11:42 --> Helper loaded: form_helper
INFO - 2023-09-20 17:11:42 --> Form Validation Class Initialized
INFO - 2023-09-20 17:11:42 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:11:42 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:11:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:11:42 --> Final output sent to browser
DEBUG - 2023-09-20 17:11:42 --> Total execution time: 0.0997
INFO - 2023-09-20 17:13:43 --> Config Class Initialized
INFO - 2023-09-20 17:13:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:13:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:43 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:43 --> URI Class Initialized
INFO - 2023-09-20 17:13:43 --> Router Class Initialized
INFO - 2023-09-20 17:13:43 --> Output Class Initialized
INFO - 2023-09-20 17:13:43 --> Security Class Initialized
DEBUG - 2023-09-20 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:43 --> Input Class Initialized
INFO - 2023-09-20 17:13:43 --> Language Class Initialized
INFO - 2023-09-20 17:13:43 --> Loader Class Initialized
INFO - 2023-09-20 17:13:43 --> Helper loaded: url_helper
INFO - 2023-09-20 17:13:43 --> Helper loaded: file_helper
INFO - 2023-09-20 17:13:43 --> Database Driver Class Initialized
INFO - 2023-09-20 17:13:43 --> Email Class Initialized
DEBUG - 2023-09-20 17:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:13:43 --> Controller Class Initialized
INFO - 2023-09-20 17:13:43 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:13:43 --> Model "Home_model" initialized
INFO - 2023-09-20 17:13:43 --> Helper loaded: download_helper
INFO - 2023-09-20 17:13:43 --> Helper loaded: form_helper
INFO - 2023-09-20 17:13:43 --> Form Validation Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
INFO - 2023-09-20 17:13:50 --> Config Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> Hooks Class Initialized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
DEBUG - 2023-09-20 17:13:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> URI Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Router Class Initialized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> Output Class Initialized
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Security Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:13:50 --> Input Class Initialized
INFO - 2023-09-20 17:13:50 --> Language Class Initialized
ERROR - 2023-09-20 17:13:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:14:16 --> Config Class Initialized
INFO - 2023-09-20 17:14:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:14:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:14:16 --> Utf8 Class Initialized
INFO - 2023-09-20 17:14:16 --> URI Class Initialized
INFO - 2023-09-20 17:14:16 --> Router Class Initialized
INFO - 2023-09-20 17:14:16 --> Output Class Initialized
INFO - 2023-09-20 17:14:16 --> Security Class Initialized
DEBUG - 2023-09-20 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:14:16 --> Input Class Initialized
INFO - 2023-09-20 17:14:16 --> Language Class Initialized
INFO - 2023-09-20 17:14:16 --> Loader Class Initialized
INFO - 2023-09-20 17:14:16 --> Helper loaded: url_helper
INFO - 2023-09-20 17:14:16 --> Helper loaded: file_helper
INFO - 2023-09-20 17:14:16 --> Database Driver Class Initialized
INFO - 2023-09-20 17:14:16 --> Email Class Initialized
DEBUG - 2023-09-20 17:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:14:16 --> Controller Class Initialized
INFO - 2023-09-20 17:14:16 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:14:16 --> Model "Home_model" initialized
INFO - 2023-09-20 17:14:16 --> Helper loaded: download_helper
INFO - 2023-09-20 17:14:16 --> Helper loaded: form_helper
INFO - 2023-09-20 17:14:16 --> Form Validation Class Initialized
INFO - 2023-09-20 17:15:43 --> Config Class Initialized
INFO - 2023-09-20 17:15:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:15:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:43 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:43 --> URI Class Initialized
INFO - 2023-09-20 17:15:43 --> Router Class Initialized
INFO - 2023-09-20 17:15:43 --> Output Class Initialized
INFO - 2023-09-20 17:15:43 --> Security Class Initialized
DEBUG - 2023-09-20 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:43 --> Input Class Initialized
INFO - 2023-09-20 17:15:43 --> Language Class Initialized
INFO - 2023-09-20 17:15:43 --> Loader Class Initialized
INFO - 2023-09-20 17:15:43 --> Helper loaded: url_helper
INFO - 2023-09-20 17:15:43 --> Helper loaded: file_helper
INFO - 2023-09-20 17:15:43 --> Database Driver Class Initialized
INFO - 2023-09-20 17:15:43 --> Email Class Initialized
DEBUG - 2023-09-20 17:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:15:43 --> Controller Class Initialized
INFO - 2023-09-20 17:15:43 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:15:43 --> Model "Home_model" initialized
INFO - 2023-09-20 17:15:43 --> Helper loaded: download_helper
INFO - 2023-09-20 17:15:43 --> Helper loaded: form_helper
INFO - 2023-09-20 17:15:43 --> Form Validation Class Initialized
INFO - 2023-09-20 17:15:43 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:15:43 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:15:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:15:43 --> Final output sent to browser
DEBUG - 2023-09-20 17:15:43 --> Total execution time: 0.1780
INFO - 2023-09-20 17:15:54 --> Config Class Initialized
INFO - 2023-09-20 17:15:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:15:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:54 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:54 --> URI Class Initialized
INFO - 2023-09-20 17:15:54 --> Router Class Initialized
INFO - 2023-09-20 17:15:54 --> Output Class Initialized
INFO - 2023-09-20 17:15:54 --> Security Class Initialized
DEBUG - 2023-09-20 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:54 --> Input Class Initialized
INFO - 2023-09-20 17:15:54 --> Language Class Initialized
INFO - 2023-09-20 17:15:54 --> Loader Class Initialized
INFO - 2023-09-20 17:15:54 --> Helper loaded: url_helper
INFO - 2023-09-20 17:15:54 --> Helper loaded: file_helper
INFO - 2023-09-20 17:15:54 --> Database Driver Class Initialized
INFO - 2023-09-20 17:15:54 --> Email Class Initialized
DEBUG - 2023-09-20 17:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:15:54 --> Controller Class Initialized
INFO - 2023-09-20 17:15:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:15:54 --> Model "Home_model" initialized
INFO - 2023-09-20 17:15:54 --> Helper loaded: download_helper
INFO - 2023-09-20 17:15:54 --> Helper loaded: form_helper
INFO - 2023-09-20 17:15:54 --> Form Validation Class Initialized
INFO - 2023-09-20 17:15:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:15:54 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:15:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 17:15:54 --> Final output sent to browser
DEBUG - 2023-09-20 17:15:54 --> Total execution time: 0.1187
INFO - 2023-09-20 17:15:57 --> Config Class Initialized
INFO - 2023-09-20 17:15:57 --> Hooks Class Initialized
INFO - 2023-09-20 17:15:57 --> Config Class Initialized
DEBUG - 2023-09-20 17:15:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:58 --> Config Class Initialized
INFO - 2023-09-20 17:15:58 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:58 --> Hooks Class Initialized
INFO - 2023-09-20 17:15:58 --> URI Class Initialized
DEBUG - 2023-09-20 17:15:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:58 --> Hooks Class Initialized
INFO - 2023-09-20 17:15:58 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:58 --> Router Class Initialized
DEBUG - 2023-09-20 17:15:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:58 --> URI Class Initialized
INFO - 2023-09-20 17:15:58 --> Output Class Initialized
INFO - 2023-09-20 17:15:58 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:58 --> Router Class Initialized
INFO - 2023-09-20 17:15:58 --> Security Class Initialized
INFO - 2023-09-20 17:15:58 --> URI Class Initialized
INFO - 2023-09-20 17:15:58 --> Output Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Router Class Initialized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
INFO - 2023-09-20 17:15:59 --> Output Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:15:59 --> Config Class Initialized
INFO - 2023-09-20 17:15:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:15:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:59 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:59 --> URI Class Initialized
INFO - 2023-09-20 17:15:59 --> Router Class Initialized
INFO - 2023-09-20 17:15:59 --> Output Class Initialized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:15:59 --> Config Class Initialized
INFO - 2023-09-20 17:15:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:15:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:59 --> Config Class Initialized
INFO - 2023-09-20 17:15:59 --> Config Class Initialized
INFO - 2023-09-20 17:15:59 --> Hooks Class Initialized
INFO - 2023-09-20 17:15:59 --> Hooks Class Initialized
INFO - 2023-09-20 17:15:59 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:15:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 17:15:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:15:59 --> URI Class Initialized
INFO - 2023-09-20 17:15:59 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:59 --> Router Class Initialized
INFO - 2023-09-20 17:15:59 --> Utf8 Class Initialized
INFO - 2023-09-20 17:15:59 --> URI Class Initialized
INFO - 2023-09-20 17:15:59 --> Output Class Initialized
INFO - 2023-09-20 17:15:59 --> Router Class Initialized
INFO - 2023-09-20 17:15:59 --> Output Class Initialized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
INFO - 2023-09-20 17:15:59 --> URI Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
INFO - 2023-09-20 17:15:59 --> Router Class Initialized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:15:59 --> Output Class Initialized
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
INFO - 2023-09-20 17:15:59 --> Security Class Initialized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
DEBUG - 2023-09-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:15:59 --> Input Class Initialized
INFO - 2023-09-20 17:15:59 --> Language Class Initialized
ERROR - 2023-09-20 17:15:59 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:16:36 --> Config Class Initialized
INFO - 2023-09-20 17:16:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:16:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:16:37 --> URI Class Initialized
INFO - 2023-09-20 17:16:37 --> Router Class Initialized
INFO - 2023-09-20 17:16:37 --> Output Class Initialized
INFO - 2023-09-20 17:16:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:16:37 --> Input Class Initialized
INFO - 2023-09-20 17:16:37 --> Language Class Initialized
INFO - 2023-09-20 17:16:37 --> Loader Class Initialized
INFO - 2023-09-20 17:16:37 --> Helper loaded: url_helper
INFO - 2023-09-20 17:16:37 --> Helper loaded: file_helper
INFO - 2023-09-20 17:16:37 --> Database Driver Class Initialized
INFO - 2023-09-20 17:16:37 --> Email Class Initialized
DEBUG - 2023-09-20 17:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:16:37 --> Controller Class Initialized
INFO - 2023-09-20 17:16:37 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:16:37 --> Model "Home_model" initialized
INFO - 2023-09-20 17:16:37 --> Helper loaded: download_helper
INFO - 2023-09-20 17:16:37 --> Helper loaded: form_helper
INFO - 2023-09-20 17:16:37 --> Form Validation Class Initialized
INFO - 2023-09-20 17:17:22 --> Config Class Initialized
INFO - 2023-09-20 17:17:22 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:22 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:22 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:22 --> URI Class Initialized
INFO - 2023-09-20 17:17:22 --> Router Class Initialized
INFO - 2023-09-20 17:17:22 --> Output Class Initialized
INFO - 2023-09-20 17:17:22 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:22 --> Input Class Initialized
INFO - 2023-09-20 17:17:22 --> Language Class Initialized
INFO - 2023-09-20 17:17:22 --> Loader Class Initialized
INFO - 2023-09-20 17:17:22 --> Helper loaded: url_helper
INFO - 2023-09-20 17:17:22 --> Helper loaded: file_helper
INFO - 2023-09-20 17:17:22 --> Database Driver Class Initialized
INFO - 2023-09-20 17:17:22 --> Email Class Initialized
DEBUG - 2023-09-20 17:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:17:22 --> Controller Class Initialized
INFO - 2023-09-20 17:17:22 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:17:22 --> Model "Home_model" initialized
INFO - 2023-09-20 17:17:22 --> Helper loaded: download_helper
INFO - 2023-09-20 17:17:22 --> Helper loaded: form_helper
INFO - 2023-09-20 17:17:22 --> Form Validation Class Initialized
INFO - 2023-09-20 17:17:28 --> Config Class Initialized
INFO - 2023-09-20 17:17:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:28 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:28 --> URI Class Initialized
INFO - 2023-09-20 17:17:28 --> Router Class Initialized
INFO - 2023-09-20 17:17:28 --> Output Class Initialized
INFO - 2023-09-20 17:17:28 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:28 --> Input Class Initialized
INFO - 2023-09-20 17:17:28 --> Language Class Initialized
INFO - 2023-09-20 17:17:28 --> Loader Class Initialized
INFO - 2023-09-20 17:17:28 --> Helper loaded: url_helper
INFO - 2023-09-20 17:17:28 --> Helper loaded: file_helper
INFO - 2023-09-20 17:17:28 --> Database Driver Class Initialized
INFO - 2023-09-20 17:17:28 --> Email Class Initialized
DEBUG - 2023-09-20 17:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:17:28 --> Controller Class Initialized
INFO - 2023-09-20 17:17:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:17:28 --> Model "Home_model" initialized
INFO - 2023-09-20 17:17:28 --> Helper loaded: download_helper
INFO - 2023-09-20 17:17:28 --> Helper loaded: form_helper
INFO - 2023-09-20 17:17:28 --> Form Validation Class Initialized
INFO - 2023-09-20 17:17:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:17:28 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:17:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:17:28 --> Final output sent to browser
DEBUG - 2023-09-20 17:17:28 --> Total execution time: 0.0715
INFO - 2023-09-20 17:17:29 --> Config Class Initialized
INFO - 2023-09-20 17:17:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:29 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:29 --> URI Class Initialized
INFO - 2023-09-20 17:17:29 --> Router Class Initialized
INFO - 2023-09-20 17:17:29 --> Output Class Initialized
INFO - 2023-09-20 17:17:29 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:29 --> Input Class Initialized
INFO - 2023-09-20 17:17:29 --> Language Class Initialized
ERROR - 2023-09-20 17:17:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:29 --> Config Class Initialized
INFO - 2023-09-20 17:17:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:29 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:29 --> URI Class Initialized
INFO - 2023-09-20 17:17:29 --> Router Class Initialized
INFO - 2023-09-20 17:17:29 --> Output Class Initialized
INFO - 2023-09-20 17:17:29 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:29 --> Input Class Initialized
INFO - 2023-09-20 17:17:29 --> Language Class Initialized
ERROR - 2023-09-20 17:17:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:30 --> Config Class Initialized
INFO - 2023-09-20 17:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:30 --> URI Class Initialized
INFO - 2023-09-20 17:17:30 --> Router Class Initialized
INFO - 2023-09-20 17:17:30 --> Output Class Initialized
INFO - 2023-09-20 17:17:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:30 --> Input Class Initialized
INFO - 2023-09-20 17:17:30 --> Language Class Initialized
ERROR - 2023-09-20 17:17:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:30 --> Config Class Initialized
INFO - 2023-09-20 17:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:30 --> URI Class Initialized
INFO - 2023-09-20 17:17:30 --> Router Class Initialized
INFO - 2023-09-20 17:17:30 --> Output Class Initialized
INFO - 2023-09-20 17:17:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:30 --> Input Class Initialized
INFO - 2023-09-20 17:17:30 --> Language Class Initialized
ERROR - 2023-09-20 17:17:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:30 --> Config Class Initialized
INFO - 2023-09-20 17:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:30 --> URI Class Initialized
INFO - 2023-09-20 17:17:30 --> Router Class Initialized
INFO - 2023-09-20 17:17:30 --> Output Class Initialized
INFO - 2023-09-20 17:17:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:30 --> Input Class Initialized
INFO - 2023-09-20 17:17:30 --> Language Class Initialized
ERROR - 2023-09-20 17:17:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:30 --> Config Class Initialized
INFO - 2023-09-20 17:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:30 --> URI Class Initialized
INFO - 2023-09-20 17:17:30 --> Router Class Initialized
INFO - 2023-09-20 17:17:30 --> Output Class Initialized
INFO - 2023-09-20 17:17:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:30 --> Input Class Initialized
INFO - 2023-09-20 17:17:30 --> Language Class Initialized
ERROR - 2023-09-20 17:17:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:17:30 --> Config Class Initialized
INFO - 2023-09-20 17:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:17:31 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:17:31 --> Utf8 Class Initialized
INFO - 2023-09-20 17:17:31 --> URI Class Initialized
INFO - 2023-09-20 17:17:31 --> Router Class Initialized
INFO - 2023-09-20 17:17:31 --> Output Class Initialized
INFO - 2023-09-20 17:17:31 --> Security Class Initialized
DEBUG - 2023-09-20 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:17:31 --> Input Class Initialized
INFO - 2023-09-20 17:17:31 --> Language Class Initialized
ERROR - 2023-09-20 17:17:31 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:18:03 --> Config Class Initialized
INFO - 2023-09-20 17:18:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:18:03 --> Utf8 Class Initialized
INFO - 2023-09-20 17:18:03 --> URI Class Initialized
INFO - 2023-09-20 17:18:03 --> Router Class Initialized
INFO - 2023-09-20 17:18:03 --> Output Class Initialized
INFO - 2023-09-20 17:18:03 --> Security Class Initialized
DEBUG - 2023-09-20 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:18:03 --> Input Class Initialized
INFO - 2023-09-20 17:18:03 --> Language Class Initialized
INFO - 2023-09-20 17:18:03 --> Loader Class Initialized
INFO - 2023-09-20 17:18:03 --> Helper loaded: url_helper
INFO - 2023-09-20 17:18:03 --> Helper loaded: file_helper
INFO - 2023-09-20 17:18:03 --> Database Driver Class Initialized
INFO - 2023-09-20 17:18:03 --> Email Class Initialized
DEBUG - 2023-09-20 17:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:18:03 --> Controller Class Initialized
INFO - 2023-09-20 17:18:03 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:18:03 --> Model "Home_model" initialized
INFO - 2023-09-20 17:18:03 --> Helper loaded: download_helper
INFO - 2023-09-20 17:18:03 --> Helper loaded: form_helper
INFO - 2023-09-20 17:18:03 --> Form Validation Class Initialized
INFO - 2023-09-20 17:21:02 --> Config Class Initialized
INFO - 2023-09-20 17:21:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:02 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:02 --> URI Class Initialized
INFO - 2023-09-20 17:21:02 --> Router Class Initialized
INFO - 2023-09-20 17:21:02 --> Output Class Initialized
INFO - 2023-09-20 17:21:02 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:02 --> Input Class Initialized
INFO - 2023-09-20 17:21:02 --> Language Class Initialized
INFO - 2023-09-20 17:21:02 --> Loader Class Initialized
INFO - 2023-09-20 17:21:02 --> Helper loaded: url_helper
INFO - 2023-09-20 17:21:02 --> Helper loaded: file_helper
INFO - 2023-09-20 17:21:02 --> Database Driver Class Initialized
INFO - 2023-09-20 17:21:02 --> Email Class Initialized
DEBUG - 2023-09-20 17:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:21:02 --> Controller Class Initialized
INFO - 2023-09-20 17:21:02 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:21:02 --> Model "Home_model" initialized
INFO - 2023-09-20 17:21:02 --> Helper loaded: download_helper
INFO - 2023-09-20 17:21:02 --> Helper loaded: form_helper
INFO - 2023-09-20 17:21:02 --> Form Validation Class Initialized
INFO - 2023-09-20 17:21:02 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:21:02 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:21:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:21:02 --> Final output sent to browser
DEBUG - 2023-09-20 17:21:02 --> Total execution time: 0.2304
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:37 --> URI Class Initialized
INFO - 2023-09-20 17:21:37 --> Router Class Initialized
INFO - 2023-09-20 17:21:37 --> Output Class Initialized
INFO - 2023-09-20 17:21:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:37 --> Input Class Initialized
INFO - 2023-09-20 17:21:37 --> Language Class Initialized
ERROR - 2023-09-20 17:21:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:37 --> URI Class Initialized
INFO - 2023-09-20 17:21:37 --> Router Class Initialized
INFO - 2023-09-20 17:21:37 --> Output Class Initialized
INFO - 2023-09-20 17:21:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:37 --> Input Class Initialized
INFO - 2023-09-20 17:21:37 --> Language Class Initialized
ERROR - 2023-09-20 17:21:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
INFO - 2023-09-20 17:21:37 --> Config Class Initialized
INFO - 2023-09-20 17:21:37 --> URI Class Initialized
DEBUG - 2023-09-20 17:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:37 --> Router Class Initialized
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:37 --> Hooks Class Initialized
INFO - 2023-09-20 17:21:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:37 --> Output Class Initialized
DEBUG - 2023-09-20 17:21:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:38 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:21:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:38 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:38 --> URI Class Initialized
INFO - 2023-09-20 17:21:38 --> Router Class Initialized
INFO - 2023-09-20 17:21:38 --> Output Class Initialized
INFO - 2023-09-20 17:21:38 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:38 --> Input Class Initialized
INFO - 2023-09-20 17:21:38 --> Language Class Initialized
ERROR - 2023-09-20 17:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:21:38 --> URI Class Initialized
INFO - 2023-09-20 17:21:38 --> URI Class Initialized
INFO - 2023-09-20 17:21:38 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:38 --> Security Class Initialized
INFO - 2023-09-20 17:21:38 --> URI Class Initialized
INFO - 2023-09-20 17:21:38 --> Router Class Initialized
INFO - 2023-09-20 17:21:38 --> Output Class Initialized
INFO - 2023-09-20 17:21:38 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:38 --> Input Class Initialized
INFO - 2023-09-20 17:21:38 --> Language Class Initialized
ERROR - 2023-09-20 17:21:38 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:38 --> Router Class Initialized
INFO - 2023-09-20 17:21:38 --> Input Class Initialized
INFO - 2023-09-20 17:21:38 --> Output Class Initialized
INFO - 2023-09-20 17:21:38 --> Router Class Initialized
INFO - 2023-09-20 17:21:38 --> Language Class Initialized
INFO - 2023-09-20 17:21:38 --> Security Class Initialized
ERROR - 2023-09-20 17:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:21:38 --> Output Class Initialized
INFO - 2023-09-20 17:21:38 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:38 --> Input Class Initialized
INFO - 2023-09-20 17:21:38 --> Input Class Initialized
INFO - 2023-09-20 17:21:38 --> Language Class Initialized
INFO - 2023-09-20 17:21:38 --> Language Class Initialized
ERROR - 2023-09-20 17:21:38 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 17:21:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:21:40 --> Config Class Initialized
INFO - 2023-09-20 17:21:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:21:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:21:40 --> Utf8 Class Initialized
INFO - 2023-09-20 17:21:40 --> URI Class Initialized
INFO - 2023-09-20 17:21:40 --> Router Class Initialized
INFO - 2023-09-20 17:21:40 --> Output Class Initialized
INFO - 2023-09-20 17:21:40 --> Security Class Initialized
DEBUG - 2023-09-20 17:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:21:40 --> Input Class Initialized
INFO - 2023-09-20 17:21:40 --> Language Class Initialized
INFO - 2023-09-20 17:21:40 --> Loader Class Initialized
INFO - 2023-09-20 17:21:40 --> Helper loaded: url_helper
INFO - 2023-09-20 17:21:40 --> Helper loaded: file_helper
INFO - 2023-09-20 17:21:40 --> Database Driver Class Initialized
INFO - 2023-09-20 17:21:40 --> Email Class Initialized
DEBUG - 2023-09-20 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:21:40 --> Controller Class Initialized
INFO - 2023-09-20 17:21:40 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:21:40 --> Model "Home_model" initialized
INFO - 2023-09-20 17:21:40 --> Helper loaded: download_helper
INFO - 2023-09-20 17:21:40 --> Helper loaded: form_helper
INFO - 2023-09-20 17:21:40 --> Form Validation Class Initialized
INFO - 2023-09-20 17:22:16 --> Config Class Initialized
INFO - 2023-09-20 17:22:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:16 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:16 --> URI Class Initialized
DEBUG - 2023-09-20 17:22:16 --> No URI present. Default controller set.
INFO - 2023-09-20 17:22:16 --> Router Class Initialized
INFO - 2023-09-20 17:22:16 --> Output Class Initialized
INFO - 2023-09-20 17:22:16 --> Security Class Initialized
DEBUG - 2023-09-20 17:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:16 --> Input Class Initialized
INFO - 2023-09-20 17:22:16 --> Language Class Initialized
INFO - 2023-09-20 17:22:16 --> Loader Class Initialized
INFO - 2023-09-20 17:22:16 --> Helper loaded: url_helper
INFO - 2023-09-20 17:22:16 --> Helper loaded: file_helper
INFO - 2023-09-20 17:22:16 --> Database Driver Class Initialized
INFO - 2023-09-20 17:22:16 --> Email Class Initialized
DEBUG - 2023-09-20 17:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:22:16 --> Controller Class Initialized
INFO - 2023-09-20 17:22:16 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:22:16 --> Model "Home_model" initialized
INFO - 2023-09-20 17:22:16 --> Helper loaded: download_helper
INFO - 2023-09-20 17:22:16 --> Helper loaded: form_helper
INFO - 2023-09-20 17:22:16 --> Form Validation Class Initialized
INFO - 2023-09-20 17:22:16 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:22:16 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:22:16 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:22:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:22:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:22:17 --> Final output sent to browser
DEBUG - 2023-09-20 17:22:17 --> Total execution time: 0.2250
INFO - 2023-09-20 17:22:18 --> Config Class Initialized
INFO - 2023-09-20 17:22:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:18 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:18 --> URI Class Initialized
INFO - 2023-09-20 17:22:18 --> Router Class Initialized
INFO - 2023-09-20 17:22:18 --> Output Class Initialized
INFO - 2023-09-20 17:22:18 --> Security Class Initialized
DEBUG - 2023-09-20 17:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:18 --> Input Class Initialized
INFO - 2023-09-20 17:22:18 --> Language Class Initialized
ERROR - 2023-09-20 17:22:18 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:18 --> Config Class Initialized
INFO - 2023-09-20 17:22:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:18 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:18 --> URI Class Initialized
INFO - 2023-09-20 17:22:18 --> Router Class Initialized
INFO - 2023-09-20 17:22:19 --> Output Class Initialized
INFO - 2023-09-20 17:22:19 --> Security Class Initialized
INFO - 2023-09-20 17:22:20 --> Config Class Initialized
INFO - 2023-09-20 17:22:20 --> Config Class Initialized
INFO - 2023-09-20 17:22:20 --> Hooks Class Initialized
INFO - 2023-09-20 17:22:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:22:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:20 --> URI Class Initialized
INFO - 2023-09-20 17:22:20 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
INFO - 2023-09-20 17:22:20 --> URI Class Initialized
INFO - 2023-09-20 17:22:20 --> Router Class Initialized
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
INFO - 2023-09-20 17:22:20 --> Router Class Initialized
INFO - 2023-09-20 17:22:20 --> Output Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:20 --> Security Class Initialized
INFO - 2023-09-20 17:22:20 --> Output Class Initialized
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Security Class Initialized
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:20 --> Config Class Initialized
INFO - 2023-09-20 17:22:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:20 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:20 --> URI Class Initialized
INFO - 2023-09-20 17:22:20 --> Router Class Initialized
INFO - 2023-09-20 17:22:20 --> Output Class Initialized
INFO - 2023-09-20 17:22:20 --> Security Class Initialized
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:20 --> Config Class Initialized
INFO - 2023-09-20 17:22:20 --> Hooks Class Initialized
INFO - 2023-09-20 17:22:20 --> Config Class Initialized
DEBUG - 2023-09-20 17:22:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:20 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:20 --> Hooks Class Initialized
INFO - 2023-09-20 17:22:20 --> URI Class Initialized
DEBUG - 2023-09-20 17:22:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:20 --> Router Class Initialized
INFO - 2023-09-20 17:22:20 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:20 --> Output Class Initialized
INFO - 2023-09-20 17:22:20 --> URI Class Initialized
INFO - 2023-09-20 17:22:20 --> Security Class Initialized
INFO - 2023-09-20 17:22:20 --> Router Class Initialized
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Output Class Initialized
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
INFO - 2023-09-20 17:22:20 --> Security Class Initialized
DEBUG - 2023-09-20 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:20 --> Input Class Initialized
INFO - 2023-09-20 17:22:20 --> Language Class Initialized
ERROR - 2023-09-20 17:22:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:22:59 --> Config Class Initialized
INFO - 2023-09-20 17:22:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:22:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:22:59 --> Utf8 Class Initialized
INFO - 2023-09-20 17:22:59 --> URI Class Initialized
INFO - 2023-09-20 17:22:59 --> Router Class Initialized
INFO - 2023-09-20 17:22:59 --> Output Class Initialized
INFO - 2023-09-20 17:22:59 --> Security Class Initialized
DEBUG - 2023-09-20 17:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:22:59 --> Input Class Initialized
INFO - 2023-09-20 17:22:59 --> Language Class Initialized
INFO - 2023-09-20 17:22:59 --> Loader Class Initialized
INFO - 2023-09-20 17:22:59 --> Helper loaded: url_helper
INFO - 2023-09-20 17:22:59 --> Helper loaded: file_helper
INFO - 2023-09-20 17:22:59 --> Database Driver Class Initialized
INFO - 2023-09-20 17:22:59 --> Email Class Initialized
DEBUG - 2023-09-20 17:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:22:59 --> Controller Class Initialized
INFO - 2023-09-20 17:22:59 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:22:59 --> Model "Home_model" initialized
INFO - 2023-09-20 17:22:59 --> Helper loaded: download_helper
INFO - 2023-09-20 17:22:59 --> Helper loaded: form_helper
INFO - 2023-09-20 17:22:59 --> Form Validation Class Initialized
INFO - 2023-09-20 17:26:55 --> Config Class Initialized
INFO - 2023-09-20 17:26:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:26:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:26:55 --> Utf8 Class Initialized
INFO - 2023-09-20 17:26:55 --> URI Class Initialized
DEBUG - 2023-09-20 17:26:55 --> No URI present. Default controller set.
INFO - 2023-09-20 17:26:55 --> Router Class Initialized
INFO - 2023-09-20 17:26:55 --> Output Class Initialized
INFO - 2023-09-20 17:26:55 --> Security Class Initialized
DEBUG - 2023-09-20 17:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:26:55 --> Input Class Initialized
INFO - 2023-09-20 17:26:55 --> Language Class Initialized
INFO - 2023-09-20 17:26:55 --> Loader Class Initialized
INFO - 2023-09-20 17:26:55 --> Helper loaded: url_helper
INFO - 2023-09-20 17:26:55 --> Helper loaded: file_helper
INFO - 2023-09-20 17:26:55 --> Database Driver Class Initialized
INFO - 2023-09-20 17:26:55 --> Email Class Initialized
DEBUG - 2023-09-20 17:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:26:55 --> Controller Class Initialized
INFO - 2023-09-20 17:26:55 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:26:55 --> Model "Home_model" initialized
INFO - 2023-09-20 17:26:55 --> Helper loaded: download_helper
INFO - 2023-09-20 17:26:55 --> Helper loaded: form_helper
INFO - 2023-09-20 17:26:55 --> Form Validation Class Initialized
INFO - 2023-09-20 17:26:55 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:26:55 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:26:55 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:26:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:26:55 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:26:55 --> Final output sent to browser
DEBUG - 2023-09-20 17:26:55 --> Total execution time: 0.3029
INFO - 2023-09-20 17:27:27 --> Config Class Initialized
INFO - 2023-09-20 17:27:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:27:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:27:27 --> Utf8 Class Initialized
INFO - 2023-09-20 17:27:27 --> URI Class Initialized
DEBUG - 2023-09-20 17:27:27 --> No URI present. Default controller set.
INFO - 2023-09-20 17:27:27 --> Router Class Initialized
INFO - 2023-09-20 17:27:27 --> Output Class Initialized
INFO - 2023-09-20 17:27:27 --> Security Class Initialized
DEBUG - 2023-09-20 17:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:27:27 --> Input Class Initialized
INFO - 2023-09-20 17:27:27 --> Language Class Initialized
INFO - 2023-09-20 17:27:27 --> Loader Class Initialized
INFO - 2023-09-20 17:27:27 --> Helper loaded: url_helper
INFO - 2023-09-20 17:27:27 --> Helper loaded: file_helper
INFO - 2023-09-20 17:27:27 --> Database Driver Class Initialized
INFO - 2023-09-20 17:27:27 --> Email Class Initialized
DEBUG - 2023-09-20 17:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:27:27 --> Controller Class Initialized
INFO - 2023-09-20 17:27:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:27:27 --> Model "Home_model" initialized
INFO - 2023-09-20 17:27:27 --> Helper loaded: download_helper
INFO - 2023-09-20 17:27:27 --> Helper loaded: form_helper
INFO - 2023-09-20 17:27:27 --> Form Validation Class Initialized
INFO - 2023-09-20 17:27:27 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:27:27 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:27:27 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:27:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:27:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:27:27 --> Final output sent to browser
DEBUG - 2023-09-20 17:27:27 --> Total execution time: 0.2273
INFO - 2023-09-20 17:27:42 --> Config Class Initialized
INFO - 2023-09-20 17:27:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:27:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:27:42 --> Utf8 Class Initialized
INFO - 2023-09-20 17:27:42 --> URI Class Initialized
DEBUG - 2023-09-20 17:27:42 --> No URI present. Default controller set.
INFO - 2023-09-20 17:27:42 --> Router Class Initialized
INFO - 2023-09-20 17:27:42 --> Output Class Initialized
INFO - 2023-09-20 17:27:42 --> Security Class Initialized
DEBUG - 2023-09-20 17:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:27:42 --> Input Class Initialized
INFO - 2023-09-20 17:27:42 --> Language Class Initialized
INFO - 2023-09-20 17:27:42 --> Loader Class Initialized
INFO - 2023-09-20 17:27:42 --> Helper loaded: url_helper
INFO - 2023-09-20 17:27:42 --> Helper loaded: file_helper
INFO - 2023-09-20 17:27:42 --> Database Driver Class Initialized
INFO - 2023-09-20 17:27:42 --> Email Class Initialized
DEBUG - 2023-09-20 17:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:27:42 --> Controller Class Initialized
INFO - 2023-09-20 17:27:42 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:27:42 --> Model "Home_model" initialized
INFO - 2023-09-20 17:27:42 --> Helper loaded: download_helper
INFO - 2023-09-20 17:27:42 --> Helper loaded: form_helper
INFO - 2023-09-20 17:27:42 --> Form Validation Class Initialized
INFO - 2023-09-20 17:27:42 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:27:42 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:27:42 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:27:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:27:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:27:42 --> Final output sent to browser
DEBUG - 2023-09-20 17:27:43 --> Total execution time: 0.4125
INFO - 2023-09-20 17:29:59 --> Config Class Initialized
INFO - 2023-09-20 17:29:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:29:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:29:59 --> Utf8 Class Initialized
INFO - 2023-09-20 17:29:59 --> URI Class Initialized
DEBUG - 2023-09-20 17:29:59 --> No URI present. Default controller set.
INFO - 2023-09-20 17:29:59 --> Router Class Initialized
INFO - 2023-09-20 17:29:59 --> Output Class Initialized
INFO - 2023-09-20 17:29:59 --> Security Class Initialized
DEBUG - 2023-09-20 17:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:29:59 --> Input Class Initialized
INFO - 2023-09-20 17:29:59 --> Language Class Initialized
INFO - 2023-09-20 17:29:59 --> Loader Class Initialized
INFO - 2023-09-20 17:29:59 --> Helper loaded: url_helper
INFO - 2023-09-20 17:29:59 --> Helper loaded: file_helper
INFO - 2023-09-20 17:29:59 --> Database Driver Class Initialized
INFO - 2023-09-20 17:29:59 --> Email Class Initialized
DEBUG - 2023-09-20 17:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:29:59 --> Controller Class Initialized
INFO - 2023-09-20 17:29:59 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:29:59 --> Model "Home_model" initialized
INFO - 2023-09-20 17:29:59 --> Helper loaded: download_helper
INFO - 2023-09-20 17:29:59 --> Helper loaded: form_helper
INFO - 2023-09-20 17:29:59 --> Form Validation Class Initialized
INFO - 2023-09-20 17:29:59 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:29:59 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:29:59 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:29:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:29:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:29:59 --> Final output sent to browser
DEBUG - 2023-09-20 17:30:00 --> Total execution time: 0.1287
INFO - 2023-09-20 17:31:30 --> Config Class Initialized
INFO - 2023-09-20 17:31:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:30 --> URI Class Initialized
INFO - 2023-09-20 17:31:30 --> Router Class Initialized
INFO - 2023-09-20 17:31:30 --> Output Class Initialized
INFO - 2023-09-20 17:31:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:30 --> Input Class Initialized
INFO - 2023-09-20 17:31:30 --> Language Class Initialized
INFO - 2023-09-20 17:31:30 --> Loader Class Initialized
INFO - 2023-09-20 17:31:30 --> Helper loaded: url_helper
INFO - 2023-09-20 17:31:30 --> Helper loaded: file_helper
INFO - 2023-09-20 17:31:30 --> Database Driver Class Initialized
INFO - 2023-09-20 17:31:30 --> Email Class Initialized
DEBUG - 2023-09-20 17:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:31:30 --> Controller Class Initialized
INFO - 2023-09-20 17:31:30 --> Config Class Initialized
INFO - 2023-09-20 17:31:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:30 --> URI Class Initialized
INFO - 2023-09-20 17:31:30 --> Router Class Initialized
INFO - 2023-09-20 17:31:30 --> Output Class Initialized
INFO - 2023-09-20 17:31:30 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:30 --> Input Class Initialized
INFO - 2023-09-20 17:31:30 --> Language Class Initialized
INFO - 2023-09-20 17:31:30 --> Loader Class Initialized
INFO - 2023-09-20 17:31:30 --> Helper loaded: url_helper
INFO - 2023-09-20 17:31:30 --> Helper loaded: file_helper
INFO - 2023-09-20 17:31:30 --> Database Driver Class Initialized
INFO - 2023-09-20 17:31:30 --> Email Class Initialized
DEBUG - 2023-09-20 17:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:31:30 --> Controller Class Initialized
INFO - 2023-09-20 17:31:31 --> Model "User_model" initialized
INFO - 2023-09-20 17:31:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-09-20 17:31:31 --> Final output sent to browser
DEBUG - 2023-09-20 17:31:31 --> Total execution time: 0.2614
INFO - 2023-09-20 17:31:32 --> Config Class Initialized
INFO - 2023-09-20 17:31:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:32 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:32 --> URI Class Initialized
INFO - 2023-09-20 17:31:32 --> Router Class Initialized
INFO - 2023-09-20 17:31:32 --> Output Class Initialized
INFO - 2023-09-20 17:31:32 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:32 --> Input Class Initialized
INFO - 2023-09-20 17:31:32 --> Language Class Initialized
ERROR - 2023-09-20 17:31:32 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 17:31:39 --> Config Class Initialized
INFO - 2023-09-20 17:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:39 --> URI Class Initialized
INFO - 2023-09-20 17:31:39 --> Router Class Initialized
INFO - 2023-09-20 17:31:39 --> Output Class Initialized
INFO - 2023-09-20 17:31:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:39 --> Input Class Initialized
INFO - 2023-09-20 17:31:39 --> Language Class Initialized
INFO - 2023-09-20 17:31:39 --> Loader Class Initialized
INFO - 2023-09-20 17:31:39 --> Helper loaded: url_helper
INFO - 2023-09-20 17:31:39 --> Helper loaded: file_helper
INFO - 2023-09-20 17:31:39 --> Database Driver Class Initialized
INFO - 2023-09-20 17:31:39 --> Email Class Initialized
DEBUG - 2023-09-20 17:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:31:39 --> Controller Class Initialized
INFO - 2023-09-20 17:31:39 --> Model "User_model" initialized
INFO - 2023-09-20 17:31:39 --> Config Class Initialized
INFO - 2023-09-20 17:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:39 --> URI Class Initialized
INFO - 2023-09-20 17:31:39 --> Router Class Initialized
INFO - 2023-09-20 17:31:39 --> Output Class Initialized
INFO - 2023-09-20 17:31:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:39 --> Input Class Initialized
INFO - 2023-09-20 17:31:39 --> Language Class Initialized
INFO - 2023-09-20 17:31:39 --> Loader Class Initialized
INFO - 2023-09-20 17:31:39 --> Helper loaded: url_helper
INFO - 2023-09-20 17:31:39 --> Helper loaded: file_helper
INFO - 2023-09-20 17:31:39 --> Database Driver Class Initialized
INFO - 2023-09-20 17:31:39 --> Email Class Initialized
DEBUG - 2023-09-20 17:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:31:39 --> Controller Class Initialized
INFO - 2023-09-20 17:31:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-09-20 17:31:39 --> Final output sent to browser
DEBUG - 2023-09-20 17:31:39 --> Total execution time: 0.1872
INFO - 2023-09-20 17:31:51 --> Config Class Initialized
INFO - 2023-09-20 17:31:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:51 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:51 --> URI Class Initialized
INFO - 2023-09-20 17:31:51 --> Router Class Initialized
INFO - 2023-09-20 17:31:51 --> Output Class Initialized
INFO - 2023-09-20 17:31:51 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:51 --> Input Class Initialized
INFO - 2023-09-20 17:31:51 --> Language Class Initialized
INFO - 2023-09-20 17:31:51 --> Loader Class Initialized
INFO - 2023-09-20 17:31:51 --> Helper loaded: url_helper
INFO - 2023-09-20 17:31:51 --> Helper loaded: file_helper
INFO - 2023-09-20 17:31:51 --> Database Driver Class Initialized
INFO - 2023-09-20 17:31:51 --> Email Class Initialized
DEBUG - 2023-09-20 17:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:31:51 --> Controller Class Initialized
INFO - 2023-09-20 17:31:51 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:31:51 --> Helper loaded: form_helper
INFO - 2023-09-20 17:31:51 --> Form Validation Class Initialized
INFO - 2023-09-20 17:31:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-20 17:31:51 --> Final output sent to browser
DEBUG - 2023-09-20 17:31:51 --> Total execution time: 0.2996
INFO - 2023-09-20 17:31:52 --> Config Class Initialized
INFO - 2023-09-20 17:31:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:31:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:31:52 --> Utf8 Class Initialized
INFO - 2023-09-20 17:31:52 --> URI Class Initialized
INFO - 2023-09-20 17:31:52 --> Router Class Initialized
INFO - 2023-09-20 17:31:52 --> Output Class Initialized
INFO - 2023-09-20 17:31:52 --> Security Class Initialized
DEBUG - 2023-09-20 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:31:52 --> Input Class Initialized
INFO - 2023-09-20 17:31:52 --> Language Class Initialized
ERROR - 2023-09-20 17:31:52 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-20 17:32:28 --> Config Class Initialized
INFO - 2023-09-20 17:32:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:32:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:32:28 --> Utf8 Class Initialized
INFO - 2023-09-20 17:32:28 --> URI Class Initialized
DEBUG - 2023-09-20 17:32:28 --> No URI present. Default controller set.
INFO - 2023-09-20 17:32:28 --> Router Class Initialized
INFO - 2023-09-20 17:32:28 --> Output Class Initialized
INFO - 2023-09-20 17:32:28 --> Security Class Initialized
DEBUG - 2023-09-20 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:32:28 --> Input Class Initialized
INFO - 2023-09-20 17:32:28 --> Language Class Initialized
INFO - 2023-09-20 17:32:28 --> Loader Class Initialized
INFO - 2023-09-20 17:32:28 --> Helper loaded: url_helper
INFO - 2023-09-20 17:32:28 --> Helper loaded: file_helper
INFO - 2023-09-20 17:32:28 --> Database Driver Class Initialized
INFO - 2023-09-20 17:32:28 --> Email Class Initialized
DEBUG - 2023-09-20 17:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:32:28 --> Controller Class Initialized
INFO - 2023-09-20 17:32:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:32:28 --> Model "Home_model" initialized
INFO - 2023-09-20 17:32:28 --> Helper loaded: download_helper
INFO - 2023-09-20 17:32:28 --> Helper loaded: form_helper
INFO - 2023-09-20 17:32:28 --> Form Validation Class Initialized
INFO - 2023-09-20 17:32:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:32:28 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:32:28 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:32:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:32:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:32:28 --> Final output sent to browser
DEBUG - 2023-09-20 17:32:28 --> Total execution time: 0.4030
INFO - 2023-09-20 17:35:28 --> Config Class Initialized
INFO - 2023-09-20 17:35:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:35:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:35:28 --> Utf8 Class Initialized
INFO - 2023-09-20 17:35:28 --> URI Class Initialized
DEBUG - 2023-09-20 17:35:28 --> No URI present. Default controller set.
INFO - 2023-09-20 17:35:28 --> Router Class Initialized
INFO - 2023-09-20 17:35:28 --> Output Class Initialized
INFO - 2023-09-20 17:35:28 --> Security Class Initialized
DEBUG - 2023-09-20 17:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:35:28 --> Input Class Initialized
INFO - 2023-09-20 17:35:28 --> Language Class Initialized
INFO - 2023-09-20 17:35:28 --> Loader Class Initialized
INFO - 2023-09-20 17:35:28 --> Helper loaded: url_helper
INFO - 2023-09-20 17:35:28 --> Helper loaded: file_helper
INFO - 2023-09-20 17:35:28 --> Database Driver Class Initialized
INFO - 2023-09-20 17:35:28 --> Email Class Initialized
DEBUG - 2023-09-20 17:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:35:28 --> Controller Class Initialized
INFO - 2023-09-20 17:35:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:35:28 --> Model "Home_model" initialized
INFO - 2023-09-20 17:35:28 --> Helper loaded: download_helper
INFO - 2023-09-20 17:35:28 --> Helper loaded: form_helper
INFO - 2023-09-20 17:35:28 --> Form Validation Class Initialized
INFO - 2023-09-20 17:35:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:35:28 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:35:28 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:35:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:35:28 --> Final output sent to browser
DEBUG - 2023-09-20 17:35:29 --> Total execution time: 0.1698
INFO - 2023-09-20 17:35:45 --> Config Class Initialized
INFO - 2023-09-20 17:35:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:35:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:35:45 --> Utf8 Class Initialized
INFO - 2023-09-20 17:35:45 --> URI Class Initialized
DEBUG - 2023-09-20 17:35:45 --> No URI present. Default controller set.
INFO - 2023-09-20 17:35:45 --> Router Class Initialized
INFO - 2023-09-20 17:35:45 --> Output Class Initialized
INFO - 2023-09-20 17:35:45 --> Security Class Initialized
DEBUG - 2023-09-20 17:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:35:45 --> Input Class Initialized
INFO - 2023-09-20 17:35:45 --> Language Class Initialized
INFO - 2023-09-20 17:35:45 --> Loader Class Initialized
INFO - 2023-09-20 17:35:45 --> Helper loaded: url_helper
INFO - 2023-09-20 17:35:45 --> Helper loaded: file_helper
INFO - 2023-09-20 17:35:45 --> Database Driver Class Initialized
INFO - 2023-09-20 17:35:45 --> Email Class Initialized
DEBUG - 2023-09-20 17:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:35:45 --> Controller Class Initialized
INFO - 2023-09-20 17:35:45 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:35:45 --> Model "Home_model" initialized
INFO - 2023-09-20 17:35:45 --> Helper loaded: download_helper
INFO - 2023-09-20 17:35:45 --> Helper loaded: form_helper
INFO - 2023-09-20 17:35:45 --> Form Validation Class Initialized
INFO - 2023-09-20 17:35:45 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:35:45 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:35:45 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:35:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:35:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:35:45 --> Final output sent to browser
DEBUG - 2023-09-20 17:35:45 --> Total execution time: 0.2043
INFO - 2023-09-20 17:35:53 --> Config Class Initialized
INFO - 2023-09-20 17:35:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:35:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:35:53 --> Utf8 Class Initialized
INFO - 2023-09-20 17:35:53 --> URI Class Initialized
DEBUG - 2023-09-20 17:35:53 --> No URI present. Default controller set.
INFO - 2023-09-20 17:35:53 --> Router Class Initialized
INFO - 2023-09-20 17:35:53 --> Output Class Initialized
INFO - 2023-09-20 17:35:53 --> Security Class Initialized
DEBUG - 2023-09-20 17:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:35:53 --> Input Class Initialized
INFO - 2023-09-20 17:35:53 --> Language Class Initialized
INFO - 2023-09-20 17:35:53 --> Loader Class Initialized
INFO - 2023-09-20 17:35:53 --> Helper loaded: url_helper
INFO - 2023-09-20 17:35:53 --> Helper loaded: file_helper
INFO - 2023-09-20 17:35:53 --> Database Driver Class Initialized
INFO - 2023-09-20 17:35:53 --> Email Class Initialized
DEBUG - 2023-09-20 17:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:35:53 --> Controller Class Initialized
INFO - 2023-09-20 17:35:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:35:53 --> Model "Home_model" initialized
INFO - 2023-09-20 17:35:53 --> Helper loaded: download_helper
INFO - 2023-09-20 17:35:53 --> Helper loaded: form_helper
INFO - 2023-09-20 17:35:53 --> Form Validation Class Initialized
INFO - 2023-09-20 17:35:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:35:53 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:35:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:35:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:35:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:35:53 --> Final output sent to browser
DEBUG - 2023-09-20 17:35:54 --> Total execution time: 0.1433
INFO - 2023-09-20 17:36:04 --> Config Class Initialized
INFO - 2023-09-20 17:36:04 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:36:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:36:04 --> Utf8 Class Initialized
INFO - 2023-09-20 17:36:04 --> URI Class Initialized
DEBUG - 2023-09-20 17:36:04 --> No URI present. Default controller set.
INFO - 2023-09-20 17:36:04 --> Router Class Initialized
INFO - 2023-09-20 17:36:04 --> Output Class Initialized
INFO - 2023-09-20 17:36:04 --> Security Class Initialized
DEBUG - 2023-09-20 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:36:04 --> Input Class Initialized
INFO - 2023-09-20 17:36:04 --> Language Class Initialized
INFO - 2023-09-20 17:36:04 --> Loader Class Initialized
INFO - 2023-09-20 17:36:04 --> Helper loaded: url_helper
INFO - 2023-09-20 17:36:04 --> Helper loaded: file_helper
INFO - 2023-09-20 17:36:04 --> Database Driver Class Initialized
INFO - 2023-09-20 17:36:04 --> Email Class Initialized
DEBUG - 2023-09-20 17:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:36:04 --> Controller Class Initialized
INFO - 2023-09-20 17:36:04 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:36:04 --> Model "Home_model" initialized
INFO - 2023-09-20 17:36:04 --> Helper loaded: download_helper
INFO - 2023-09-20 17:36:04 --> Helper loaded: form_helper
INFO - 2023-09-20 17:36:04 --> Form Validation Class Initialized
INFO - 2023-09-20 17:36:04 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:36:04 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:36:04 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:36:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:36:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:36:04 --> Final output sent to browser
DEBUG - 2023-09-20 17:36:04 --> Total execution time: 0.1772
INFO - 2023-09-20 17:39:18 --> Config Class Initialized
INFO - 2023-09-20 17:39:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:39:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:39:19 --> Utf8 Class Initialized
INFO - 2023-09-20 17:39:19 --> URI Class Initialized
INFO - 2023-09-20 17:39:20 --> Router Class Initialized
INFO - 2023-09-20 17:39:20 --> Output Class Initialized
INFO - 2023-09-20 17:39:21 --> Security Class Initialized
DEBUG - 2023-09-20 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:39:21 --> Input Class Initialized
INFO - 2023-09-20 17:39:21 --> Language Class Initialized
ERROR - 2023-09-20 17:39:22 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:39:24 --> Config Class Initialized
INFO - 2023-09-20 17:39:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:39:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:39:29 --> Config Class Initialized
INFO - 2023-09-20 17:39:29 --> Config Class Initialized
INFO - 2023-09-20 17:39:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:39:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:39:29 --> Utf8 Class Initialized
INFO - 2023-09-20 17:39:29 --> URI Class Initialized
INFO - 2023-09-20 17:39:29 --> Router Class Initialized
INFO - 2023-09-20 17:39:29 --> Output Class Initialized
INFO - 2023-09-20 17:39:29 --> Security Class Initialized
DEBUG - 2023-09-20 17:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:39:29 --> Input Class Initialized
INFO - 2023-09-20 17:39:29 --> Language Class Initialized
ERROR - 2023-09-20 17:39:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:39:32 --> Config Class Initialized
INFO - 2023-09-20 17:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:39:32 --> Utf8 Class Initialized
INFO - 2023-09-20 17:39:32 --> URI Class Initialized
INFO - 2023-09-20 17:39:32 --> Router Class Initialized
INFO - 2023-09-20 17:39:32 --> Output Class Initialized
INFO - 2023-09-20 17:39:32 --> Security Class Initialized
DEBUG - 2023-09-20 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:39:32 --> Input Class Initialized
INFO - 2023-09-20 17:39:32 --> Language Class Initialized
ERROR - 2023-09-20 17:39:32 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:39:33 --> Utf8 Class Initialized
INFO - 2023-09-20 17:39:34 --> URI Class Initialized
INFO - 2023-09-20 17:40:57 --> Config Class Initialized
INFO - 2023-09-20 17:40:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:40:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:40:57 --> Utf8 Class Initialized
INFO - 2023-09-20 17:40:57 --> URI Class Initialized
DEBUG - 2023-09-20 17:40:57 --> No URI present. Default controller set.
INFO - 2023-09-20 17:40:57 --> Router Class Initialized
INFO - 2023-09-20 17:40:57 --> Output Class Initialized
INFO - 2023-09-20 17:40:57 --> Security Class Initialized
DEBUG - 2023-09-20 17:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:40:57 --> Input Class Initialized
INFO - 2023-09-20 17:40:57 --> Language Class Initialized
INFO - 2023-09-20 17:40:57 --> Loader Class Initialized
INFO - 2023-09-20 17:40:57 --> Helper loaded: url_helper
INFO - 2023-09-20 17:40:57 --> Helper loaded: file_helper
INFO - 2023-09-20 17:40:57 --> Database Driver Class Initialized
INFO - 2023-09-20 17:40:57 --> Email Class Initialized
DEBUG - 2023-09-20 17:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:40:57 --> Controller Class Initialized
INFO - 2023-09-20 17:40:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:40:57 --> Model "Home_model" initialized
INFO - 2023-09-20 17:40:57 --> Helper loaded: download_helper
INFO - 2023-09-20 17:40:57 --> Helper loaded: form_helper
INFO - 2023-09-20 17:40:57 --> Form Validation Class Initialized
INFO - 2023-09-20 17:40:57 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:40:57 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:40:57 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:40:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:40:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:40:58 --> Final output sent to browser
DEBUG - 2023-09-20 17:40:58 --> Total execution time: 0.1839
INFO - 2023-09-20 17:41:00 --> Config Class Initialized
INFO - 2023-09-20 17:41:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:41:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:00 --> Utf8 Class Initialized
INFO - 2023-09-20 17:41:00 --> URI Class Initialized
INFO - 2023-09-20 17:41:00 --> Router Class Initialized
INFO - 2023-09-20 17:41:00 --> Output Class Initialized
INFO - 2023-09-20 17:41:00 --> Security Class Initialized
DEBUG - 2023-09-20 17:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:41:00 --> Input Class Initialized
INFO - 2023-09-20 17:41:00 --> Language Class Initialized
ERROR - 2023-09-20 17:41:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:41:00 --> Config Class Initialized
INFO - 2023-09-20 17:41:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:41:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:00 --> Utf8 Class Initialized
INFO - 2023-09-20 17:41:00 --> URI Class Initialized
INFO - 2023-09-20 17:41:00 --> Router Class Initialized
INFO - 2023-09-20 17:41:00 --> Output Class Initialized
INFO - 2023-09-20 17:41:00 --> Security Class Initialized
DEBUG - 2023-09-20 17:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:41:00 --> Input Class Initialized
INFO - 2023-09-20 17:41:00 --> Language Class Initialized
ERROR - 2023-09-20 17:41:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:41:02 --> Config Class Initialized
INFO - 2023-09-20 17:41:02 --> Config Class Initialized
INFO - 2023-09-20 17:41:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:41:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:02 --> Utf8 Class Initialized
INFO - 2023-09-20 17:41:02 --> URI Class Initialized
INFO - 2023-09-20 17:41:02 --> Router Class Initialized
INFO - 2023-09-20 17:41:02 --> Output Class Initialized
INFO - 2023-09-20 17:41:02 --> Hooks Class Initialized
INFO - 2023-09-20 17:41:03 --> Security Class Initialized
DEBUG - 2023-09-20 17:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:41:03 --> Input Class Initialized
INFO - 2023-09-20 17:41:03 --> Language Class Initialized
ERROR - 2023-09-20 17:41:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:41:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:04 --> Utf8 Class Initialized
INFO - 2023-09-20 17:41:05 --> URI Class Initialized
INFO - 2023-09-20 17:41:05 --> Router Class Initialized
INFO - 2023-09-20 17:41:05 --> Output Class Initialized
INFO - 2023-09-20 17:41:05 --> Security Class Initialized
DEBUG - 2023-09-20 17:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:41:05 --> Input Class Initialized
INFO - 2023-09-20 17:41:05 --> Language Class Initialized
ERROR - 2023-09-20 17:41:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:41:05 --> Config Class Initialized
INFO - 2023-09-20 17:41:06 --> Config Class Initialized
INFO - 2023-09-20 17:41:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:41:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:07 --> Hooks Class Initialized
INFO - 2023-09-20 17:41:07 --> Config Class Initialized
DEBUG - 2023-09-20 17:41:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:41:08 --> Utf8 Class Initialized
INFO - 2023-09-20 17:41:09 --> Hooks Class Initialized
INFO - 2023-09-20 17:41:09 --> Utf8 Class Initialized
INFO - 2023-09-20 17:44:06 --> Config Class Initialized
INFO - 2023-09-20 17:44:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:44:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:44:06 --> Utf8 Class Initialized
INFO - 2023-09-20 17:44:06 --> URI Class Initialized
INFO - 2023-09-20 17:44:06 --> Router Class Initialized
INFO - 2023-09-20 17:44:06 --> Output Class Initialized
INFO - 2023-09-20 17:44:06 --> Security Class Initialized
DEBUG - 2023-09-20 17:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:44:06 --> Input Class Initialized
INFO - 2023-09-20 17:44:06 --> Language Class Initialized
INFO - 2023-09-20 17:44:06 --> Loader Class Initialized
INFO - 2023-09-20 17:44:06 --> Helper loaded: url_helper
INFO - 2023-09-20 17:44:06 --> Helper loaded: file_helper
INFO - 2023-09-20 17:44:06 --> Database Driver Class Initialized
INFO - 2023-09-20 17:44:06 --> Email Class Initialized
DEBUG - 2023-09-20 17:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:44:06 --> Controller Class Initialized
INFO - 2023-09-20 17:44:06 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:44:06 --> Model "Home_model" initialized
INFO - 2023-09-20 17:44:06 --> Helper loaded: download_helper
INFO - 2023-09-20 17:44:07 --> Helper loaded: form_helper
INFO - 2023-09-20 17:44:07 --> Form Validation Class Initialized
INFO - 2023-09-20 17:44:07 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:44:07 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:44:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:44:07 --> Final output sent to browser
DEBUG - 2023-09-20 17:44:07 --> Total execution time: 0.9013
INFO - 2023-09-20 17:44:23 --> Config Class Initialized
INFO - 2023-09-20 17:44:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:44:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:44:23 --> Utf8 Class Initialized
INFO - 2023-09-20 17:44:23 --> URI Class Initialized
INFO - 2023-09-20 17:44:23 --> Router Class Initialized
INFO - 2023-09-20 17:44:23 --> Output Class Initialized
INFO - 2023-09-20 17:44:23 --> Security Class Initialized
DEBUG - 2023-09-20 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:44:23 --> Input Class Initialized
INFO - 2023-09-20 17:44:23 --> Language Class Initialized
INFO - 2023-09-20 17:44:23 --> Loader Class Initialized
INFO - 2023-09-20 17:44:23 --> Helper loaded: url_helper
INFO - 2023-09-20 17:44:23 --> Helper loaded: file_helper
INFO - 2023-09-20 17:44:23 --> Database Driver Class Initialized
INFO - 2023-09-20 17:44:23 --> Email Class Initialized
DEBUG - 2023-09-20 17:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:44:23 --> Controller Class Initialized
INFO - 2023-09-20 17:44:23 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:44:23 --> Model "Home_model" initialized
INFO - 2023-09-20 17:44:23 --> Helper loaded: download_helper
INFO - 2023-09-20 17:44:23 --> Helper loaded: form_helper
INFO - 2023-09-20 17:44:23 --> Form Validation Class Initialized
INFO - 2023-09-20 17:44:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:44:24 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:44:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:44:24 --> Final output sent to browser
DEBUG - 2023-09-20 17:44:24 --> Total execution time: 0.1512
INFO - 2023-09-20 17:46:08 --> Config Class Initialized
INFO - 2023-09-20 17:46:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:46:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:46:08 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:08 --> URI Class Initialized
INFO - 2023-09-20 17:46:08 --> Router Class Initialized
INFO - 2023-09-20 17:46:08 --> Output Class Initialized
INFO - 2023-09-20 17:46:09 --> Config Class Initialized
INFO - 2023-09-20 17:46:10 --> Config Class Initialized
INFO - 2023-09-20 17:46:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:46:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:46:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:10 --> URI Class Initialized
INFO - 2023-09-20 17:46:10 --> Router Class Initialized
INFO - 2023-09-20 17:46:10 --> Output Class Initialized
INFO - 2023-09-20 17:46:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:10 --> Input Class Initialized
INFO - 2023-09-20 17:46:10 --> Language Class Initialized
ERROR - 2023-09-20 17:46:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:46:10 --> Security Class Initialized
INFO - 2023-09-20 17:46:10 --> Config Class Initialized
INFO - 2023-09-20 17:46:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:46:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:46:10 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:10 --> URI Class Initialized
INFO - 2023-09-20 17:46:10 --> Router Class Initialized
INFO - 2023-09-20 17:46:10 --> Output Class Initialized
INFO - 2023-09-20 17:46:10 --> Security Class Initialized
DEBUG - 2023-09-20 17:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:10 --> Input Class Initialized
INFO - 2023-09-20 17:46:10 --> Language Class Initialized
ERROR - 2023-09-20 17:46:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:46:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 17:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:12 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:12 --> Input Class Initialized
INFO - 2023-09-20 17:46:12 --> URI Class Initialized
INFO - 2023-09-20 17:46:12 --> Config Class Initialized
INFO - 2023-09-20 17:46:13 --> Hooks Class Initialized
INFO - 2023-09-20 17:46:13 --> Config Class Initialized
INFO - 2023-09-20 17:46:13 --> Router Class Initialized
INFO - 2023-09-20 17:46:13 --> Language Class Initialized
DEBUG - 2023-09-20 17:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:46:14 --> Output Class Initialized
INFO - 2023-09-20 17:46:14 --> Hooks Class Initialized
INFO - 2023-09-20 17:46:14 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:14 --> URI Class Initialized
INFO - 2023-09-20 17:46:14 --> Router Class Initialized
INFO - 2023-09-20 17:46:14 --> Output Class Initialized
INFO - 2023-09-20 17:46:14 --> Security Class Initialized
DEBUG - 2023-09-20 17:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:14 --> Input Class Initialized
INFO - 2023-09-20 17:46:14 --> Language Class Initialized
ERROR - 2023-09-20 17:46:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:46:14 --> Security Class Initialized
ERROR - 2023-09-20 17:46:14 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:46:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:15 --> Config Class Initialized
INFO - 2023-09-20 17:46:15 --> Hooks Class Initialized
INFO - 2023-09-20 17:46:15 --> Input Class Initialized
INFO - 2023-09-20 17:46:15 --> Language Class Initialized
ERROR - 2023-09-20 17:46:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:46:16 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:46:16 --> URI Class Initialized
INFO - 2023-09-20 17:46:16 --> Utf8 Class Initialized
INFO - 2023-09-20 17:46:17 --> URI Class Initialized
INFO - 2023-09-20 17:46:17 --> Router Class Initialized
INFO - 2023-09-20 17:46:17 --> Output Class Initialized
INFO - 2023-09-20 17:46:17 --> Router Class Initialized
INFO - 2023-09-20 17:46:17 --> Output Class Initialized
INFO - 2023-09-20 17:46:18 --> Security Class Initialized
DEBUG - 2023-09-20 17:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:18 --> Security Class Initialized
INFO - 2023-09-20 17:46:18 --> Input Class Initialized
DEBUG - 2023-09-20 17:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:46:19 --> Language Class Initialized
INFO - 2023-09-20 17:46:19 --> Input Class Initialized
ERROR - 2023-09-20 17:46:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:46:19 --> Language Class Initialized
ERROR - 2023-09-20 17:46:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:34 --> Config Class Initialized
INFO - 2023-09-20 17:49:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:34 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:34 --> URI Class Initialized
INFO - 2023-09-20 17:49:34 --> Router Class Initialized
INFO - 2023-09-20 17:49:34 --> Output Class Initialized
INFO - 2023-09-20 17:49:34 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:34 --> Input Class Initialized
INFO - 2023-09-20 17:49:34 --> Language Class Initialized
ERROR - 2023-09-20 17:49:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:34 --> Config Class Initialized
INFO - 2023-09-20 17:49:35 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:35 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:35 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:35 --> URI Class Initialized
INFO - 2023-09-20 17:49:35 --> Router Class Initialized
INFO - 2023-09-20 17:49:35 --> Output Class Initialized
INFO - 2023-09-20 17:49:35 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:35 --> Input Class Initialized
INFO - 2023-09-20 17:49:35 --> Language Class Initialized
ERROR - 2023-09-20 17:49:35 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:36 --> Config Class Initialized
INFO - 2023-09-20 17:49:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:36 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:36 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:36 --> URI Class Initialized
INFO - 2023-09-20 17:49:36 --> Router Class Initialized
INFO - 2023-09-20 17:49:36 --> Output Class Initialized
INFO - 2023-09-20 17:49:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:37 --> Input Class Initialized
INFO - 2023-09-20 17:49:37 --> Language Class Initialized
ERROR - 2023-09-20 17:49:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:37 --> Config Class Initialized
INFO - 2023-09-20 17:49:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:37 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:37 --> URI Class Initialized
INFO - 2023-09-20 17:49:37 --> Router Class Initialized
INFO - 2023-09-20 17:49:37 --> Output Class Initialized
INFO - 2023-09-20 17:49:37 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:37 --> Input Class Initialized
INFO - 2023-09-20 17:49:37 --> Language Class Initialized
ERROR - 2023-09-20 17:49:37 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:38 --> Config Class Initialized
INFO - 2023-09-20 17:49:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:39 --> URI Class Initialized
INFO - 2023-09-20 17:49:39 --> Router Class Initialized
INFO - 2023-09-20 17:49:39 --> Output Class Initialized
INFO - 2023-09-20 17:49:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:39 --> Input Class Initialized
INFO - 2023-09-20 17:49:39 --> Language Class Initialized
ERROR - 2023-09-20 17:49:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:39 --> Config Class Initialized
INFO - 2023-09-20 17:49:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:39 --> URI Class Initialized
INFO - 2023-09-20 17:49:39 --> Router Class Initialized
INFO - 2023-09-20 17:49:39 --> Output Class Initialized
INFO - 2023-09-20 17:49:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:39 --> Input Class Initialized
INFO - 2023-09-20 17:49:39 --> Language Class Initialized
ERROR - 2023-09-20 17:49:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:49:39 --> Config Class Initialized
INFO - 2023-09-20 17:49:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:49:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:49:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:49:39 --> URI Class Initialized
INFO - 2023-09-20 17:49:39 --> Router Class Initialized
INFO - 2023-09-20 17:49:39 --> Output Class Initialized
INFO - 2023-09-20 17:49:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:49:39 --> Input Class Initialized
INFO - 2023-09-20 17:49:39 --> Language Class Initialized
ERROR - 2023-09-20 17:49:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:08 --> Config Class Initialized
INFO - 2023-09-20 17:51:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:08 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:08 --> URI Class Initialized
DEBUG - 2023-09-20 17:51:08 --> No URI present. Default controller set.
INFO - 2023-09-20 17:51:08 --> Router Class Initialized
INFO - 2023-09-20 17:51:08 --> Output Class Initialized
INFO - 2023-09-20 17:51:08 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:08 --> Input Class Initialized
INFO - 2023-09-20 17:51:08 --> Language Class Initialized
INFO - 2023-09-20 17:51:08 --> Loader Class Initialized
INFO - 2023-09-20 17:51:08 --> Helper loaded: url_helper
INFO - 2023-09-20 17:51:08 --> Helper loaded: file_helper
INFO - 2023-09-20 17:51:08 --> Database Driver Class Initialized
INFO - 2023-09-20 17:51:08 --> Email Class Initialized
DEBUG - 2023-09-20 17:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:51:08 --> Controller Class Initialized
INFO - 2023-09-20 17:51:08 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:51:08 --> Model "Home_model" initialized
INFO - 2023-09-20 17:51:08 --> Helper loaded: download_helper
INFO - 2023-09-20 17:51:08 --> Helper loaded: form_helper
INFO - 2023-09-20 17:51:08 --> Form Validation Class Initialized
INFO - 2023-09-20 17:51:09 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:51:09 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:51:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:51:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:51:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:51:09 --> Final output sent to browser
DEBUG - 2023-09-20 17:51:09 --> Total execution time: 1.5392
INFO - 2023-09-20 17:51:12 --> Config Class Initialized
INFO - 2023-09-20 17:51:12 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:12 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:12 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:12 --> URI Class Initialized
INFO - 2023-09-20 17:51:12 --> Router Class Initialized
INFO - 2023-09-20 17:51:12 --> Output Class Initialized
INFO - 2023-09-20 17:51:12 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:12 --> Input Class Initialized
INFO - 2023-09-20 17:51:12 --> Language Class Initialized
ERROR - 2023-09-20 17:51:12 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:13 --> Config Class Initialized
INFO - 2023-09-20 17:51:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:13 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:13 --> URI Class Initialized
INFO - 2023-09-20 17:51:13 --> Router Class Initialized
INFO - 2023-09-20 17:51:13 --> Output Class Initialized
INFO - 2023-09-20 17:51:13 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:13 --> Input Class Initialized
INFO - 2023-09-20 17:51:13 --> Language Class Initialized
ERROR - 2023-09-20 17:51:13 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:15 --> Config Class Initialized
INFO - 2023-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:15 --> URI Class Initialized
INFO - 2023-09-20 17:51:15 --> Router Class Initialized
INFO - 2023-09-20 17:51:15 --> Output Class Initialized
INFO - 2023-09-20 17:51:15 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:15 --> Input Class Initialized
INFO - 2023-09-20 17:51:15 --> Language Class Initialized
ERROR - 2023-09-20 17:51:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:15 --> Config Class Initialized
INFO - 2023-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:15 --> URI Class Initialized
INFO - 2023-09-20 17:51:15 --> Router Class Initialized
INFO - 2023-09-20 17:51:15 --> Output Class Initialized
INFO - 2023-09-20 17:51:15 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:15 --> Input Class Initialized
INFO - 2023-09-20 17:51:15 --> Language Class Initialized
ERROR - 2023-09-20 17:51:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:15 --> Config Class Initialized
INFO - 2023-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:15 --> URI Class Initialized
INFO - 2023-09-20 17:51:15 --> Router Class Initialized
INFO - 2023-09-20 17:51:15 --> Output Class Initialized
INFO - 2023-09-20 17:51:15 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:15 --> Input Class Initialized
INFO - 2023-09-20 17:51:15 --> Language Class Initialized
ERROR - 2023-09-20 17:51:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:15 --> Config Class Initialized
INFO - 2023-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:15 --> URI Class Initialized
INFO - 2023-09-20 17:51:15 --> Router Class Initialized
INFO - 2023-09-20 17:51:15 --> Output Class Initialized
INFO - 2023-09-20 17:51:15 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:15 --> Input Class Initialized
INFO - 2023-09-20 17:51:15 --> Language Class Initialized
ERROR - 2023-09-20 17:51:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:15 --> Config Class Initialized
INFO - 2023-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:15 --> URI Class Initialized
INFO - 2023-09-20 17:51:15 --> Router Class Initialized
INFO - 2023-09-20 17:51:15 --> Output Class Initialized
INFO - 2023-09-20 17:51:15 --> Security Class Initialized
INFO - 2023-09-20 17:51:25 --> Config Class Initialized
INFO - 2023-09-20 17:51:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:25 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:25 --> URI Class Initialized
INFO - 2023-09-20 17:51:25 --> Router Class Initialized
INFO - 2023-09-20 17:51:25 --> Output Class Initialized
INFO - 2023-09-20 17:51:25 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:25 --> Input Class Initialized
INFO - 2023-09-20 17:51:25 --> Language Class Initialized
INFO - 2023-09-20 17:51:25 --> Loader Class Initialized
INFO - 2023-09-20 17:51:25 --> Helper loaded: url_helper
INFO - 2023-09-20 17:51:25 --> Helper loaded: file_helper
INFO - 2023-09-20 17:51:25 --> Database Driver Class Initialized
INFO - 2023-09-20 17:51:25 --> Email Class Initialized
DEBUG - 2023-09-20 17:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:51:25 --> Controller Class Initialized
INFO - 2023-09-20 17:51:25 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:51:25 --> Model "Home_model" initialized
INFO - 2023-09-20 17:51:25 --> Helper loaded: download_helper
INFO - 2023-09-20 17:51:25 --> Helper loaded: form_helper
INFO - 2023-09-20 17:51:25 --> Form Validation Class Initialized
INFO - 2023-09-20 17:51:25 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:51:25 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:51:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-09-20 17:51:26 --> Final output sent to browser
DEBUG - 2023-09-20 17:51:26 --> Total execution time: 0.6230
INFO - 2023-09-20 17:51:26 --> Config Class Initialized
INFO - 2023-09-20 17:51:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:26 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:26 --> URI Class Initialized
INFO - 2023-09-20 17:51:26 --> Router Class Initialized
INFO - 2023-09-20 17:51:26 --> Output Class Initialized
INFO - 2023-09-20 17:51:26 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:26 --> Input Class Initialized
INFO - 2023-09-20 17:51:26 --> Language Class Initialized
ERROR - 2023-09-20 17:51:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:27 --> Config Class Initialized
INFO - 2023-09-20 17:51:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:27 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:27 --> URI Class Initialized
INFO - 2023-09-20 17:51:27 --> Router Class Initialized
INFO - 2023-09-20 17:51:27 --> Output Class Initialized
INFO - 2023-09-20 17:51:27 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:27 --> Input Class Initialized
INFO - 2023-09-20 17:51:27 --> Language Class Initialized
ERROR - 2023-09-20 17:51:27 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:28 --> Config Class Initialized
INFO - 2023-09-20 17:51:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:28 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:28 --> URI Class Initialized
INFO - 2023-09-20 17:51:28 --> Router Class Initialized
INFO - 2023-09-20 17:51:28 --> Output Class Initialized
INFO - 2023-09-20 17:51:28 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:28 --> Input Class Initialized
INFO - 2023-09-20 17:51:28 --> Language Class Initialized
ERROR - 2023-09-20 17:51:28 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:29 --> Config Class Initialized
INFO - 2023-09-20 17:51:29 --> Hooks Class Initialized
INFO - 2023-09-20 17:51:29 --> Config Class Initialized
INFO - 2023-09-20 17:51:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:29 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:29 --> URI Class Initialized
INFO - 2023-09-20 17:51:29 --> Router Class Initialized
INFO - 2023-09-20 17:51:29 --> Output Class Initialized
INFO - 2023-09-20 17:51:29 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:29 --> Input Class Initialized
INFO - 2023-09-20 17:51:29 --> Language Class Initialized
ERROR - 2023-09-20 17:51:29 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:51:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:30 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:30 --> Config Class Initialized
INFO - 2023-09-20 17:51:30 --> URI Class Initialized
INFO - 2023-09-20 17:51:31 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:31 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:31 --> Router Class Initialized
INFO - 2023-09-20 17:51:32 --> Config Class Initialized
INFO - 2023-09-20 17:51:32 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:32 --> Hooks Class Initialized
INFO - 2023-09-20 17:51:32 --> Output Class Initialized
DEBUG - 2023-09-20 17:51:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:32 --> URI Class Initialized
INFO - 2023-09-20 17:51:32 --> Router Class Initialized
INFO - 2023-09-20 17:51:32 --> Security Class Initialized
INFO - 2023-09-20 17:51:33 --> Output Class Initialized
DEBUG - 2023-09-20 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:33 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:33 --> URI Class Initialized
INFO - 2023-09-20 17:51:33 --> Input Class Initialized
INFO - 2023-09-20 17:51:34 --> Security Class Initialized
INFO - 2023-09-20 17:51:34 --> Router Class Initialized
INFO - 2023-09-20 17:51:34 --> Language Class Initialized
ERROR - 2023-09-20 17:51:34 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:34 --> Output Class Initialized
INFO - 2023-09-20 17:51:34 --> Input Class Initialized
INFO - 2023-09-20 17:51:34 --> Security Class Initialized
INFO - 2023-09-20 17:51:34 --> Language Class Initialized
DEBUG - 2023-09-20 17:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 17:51:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:34 --> Input Class Initialized
INFO - 2023-09-20 17:51:34 --> Language Class Initialized
ERROR - 2023-09-20 17:51:34 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:46 --> Config Class Initialized
INFO - 2023-09-20 17:51:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:46 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:46 --> URI Class Initialized
INFO - 2023-09-20 17:51:46 --> Router Class Initialized
INFO - 2023-09-20 17:51:46 --> Output Class Initialized
INFO - 2023-09-20 17:51:46 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:46 --> Input Class Initialized
INFO - 2023-09-20 17:51:46 --> Language Class Initialized
INFO - 2023-09-20 17:51:46 --> Loader Class Initialized
INFO - 2023-09-20 17:51:46 --> Helper loaded: url_helper
INFO - 2023-09-20 17:51:46 --> Helper loaded: file_helper
INFO - 2023-09-20 17:51:46 --> Database Driver Class Initialized
INFO - 2023-09-20 17:51:46 --> Email Class Initialized
DEBUG - 2023-09-20 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:51:46 --> Controller Class Initialized
INFO - 2023-09-20 17:51:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:51:46 --> Model "Home_model" initialized
INFO - 2023-09-20 17:51:46 --> Helper loaded: download_helper
INFO - 2023-09-20 17:51:46 --> Helper loaded: form_helper
INFO - 2023-09-20 17:51:46 --> Form Validation Class Initialized
INFO - 2023-09-20 17:51:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:51:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:51:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-20 17:51:47 --> Final output sent to browser
DEBUG - 2023-09-20 17:51:47 --> Total execution time: 0.6347
INFO - 2023-09-20 17:51:48 --> Config Class Initialized
INFO - 2023-09-20 17:51:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:48 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:48 --> URI Class Initialized
INFO - 2023-09-20 17:51:48 --> Router Class Initialized
INFO - 2023-09-20 17:51:48 --> Output Class Initialized
INFO - 2023-09-20 17:51:48 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:48 --> Input Class Initialized
INFO - 2023-09-20 17:51:48 --> Language Class Initialized
ERROR - 2023-09-20 17:51:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:48 --> Config Class Initialized
INFO - 2023-09-20 17:51:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:48 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:49 --> URI Class Initialized
INFO - 2023-09-20 17:51:49 --> Router Class Initialized
INFO - 2023-09-20 17:51:49 --> Output Class Initialized
INFO - 2023-09-20 17:51:49 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:50 --> Input Class Initialized
INFO - 2023-09-20 17:51:50 --> Language Class Initialized
ERROR - 2023-09-20 17:51:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:51 --> Config Class Initialized
INFO - 2023-09-20 17:51:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:51 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:51 --> URI Class Initialized
INFO - 2023-09-20 17:51:51 --> Router Class Initialized
INFO - 2023-09-20 17:51:51 --> Output Class Initialized
INFO - 2023-09-20 17:51:51 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:51 --> Input Class Initialized
INFO - 2023-09-20 17:51:51 --> Language Class Initialized
ERROR - 2023-09-20 17:51:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:51 --> Config Class Initialized
INFO - 2023-09-20 17:51:52 --> Config Class Initialized
INFO - 2023-09-20 17:51:52 --> Hooks Class Initialized
INFO - 2023-09-20 17:51:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:51:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:52 --> Config Class Initialized
INFO - 2023-09-20 17:51:52 --> Hooks Class Initialized
INFO - 2023-09-20 17:51:52 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:51:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:52 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:52 --> Config Class Initialized
INFO - 2023-09-20 17:51:52 --> Hooks Class Initialized
INFO - 2023-09-20 17:51:52 --> URI Class Initialized
DEBUG - 2023-09-20 17:51:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:52 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:52 --> Router Class Initialized
INFO - 2023-09-20 17:51:52 --> URI Class Initialized
DEBUG - 2023-09-20 17:51:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:51:52 --> Output Class Initialized
INFO - 2023-09-20 17:51:52 --> Router Class Initialized
INFO - 2023-09-20 17:51:52 --> URI Class Initialized
INFO - 2023-09-20 17:51:52 --> Security Class Initialized
INFO - 2023-09-20 17:51:52 --> Router Class Initialized
INFO - 2023-09-20 17:51:52 --> Utf8 Class Initialized
INFO - 2023-09-20 17:51:53 --> Output Class Initialized
INFO - 2023-09-20 17:51:53 --> URI Class Initialized
DEBUG - 2023-09-20 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:53 --> Output Class Initialized
INFO - 2023-09-20 17:51:53 --> Input Class Initialized
INFO - 2023-09-20 17:51:53 --> Security Class Initialized
INFO - 2023-09-20 17:51:53 --> Router Class Initialized
DEBUG - 2023-09-20 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:53 --> Input Class Initialized
INFO - 2023-09-20 17:51:53 --> Language Class Initialized
ERROR - 2023-09-20 17:51:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:53 --> Output Class Initialized
INFO - 2023-09-20 17:51:53 --> Security Class Initialized
INFO - 2023-09-20 17:51:53 --> Language Class Initialized
INFO - 2023-09-20 17:51:53 --> Security Class Initialized
DEBUG - 2023-09-20 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:53 --> Input Class Initialized
ERROR - 2023-09-20 17:51:53 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:51:53 --> Language Class Initialized
INFO - 2023-09-20 17:51:53 --> Input Class Initialized
ERROR - 2023-09-20 17:51:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:51:53 --> Language Class Initialized
ERROR - 2023-09-20 17:51:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:53:00 --> Config Class Initialized
INFO - 2023-09-20 17:53:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:53:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:53:00 --> Utf8 Class Initialized
INFO - 2023-09-20 17:53:00 --> URI Class Initialized
INFO - 2023-09-20 17:53:00 --> Router Class Initialized
INFO - 2023-09-20 17:53:00 --> Output Class Initialized
INFO - 2023-09-20 17:53:00 --> Security Class Initialized
DEBUG - 2023-09-20 17:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:53:00 --> Input Class Initialized
INFO - 2023-09-20 17:53:00 --> Language Class Initialized
INFO - 2023-09-20 17:53:00 --> Loader Class Initialized
INFO - 2023-09-20 17:53:00 --> Helper loaded: url_helper
INFO - 2023-09-20 17:53:00 --> Helper loaded: file_helper
INFO - 2023-09-20 17:53:00 --> Database Driver Class Initialized
INFO - 2023-09-20 17:53:00 --> Email Class Initialized
DEBUG - 2023-09-20 17:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:53:00 --> Controller Class Initialized
INFO - 2023-09-20 17:53:00 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:53:00 --> Model "Home_model" initialized
INFO - 2023-09-20 17:53:00 --> Helper loaded: download_helper
INFO - 2023-09-20 17:53:00 --> Helper loaded: form_helper
INFO - 2023-09-20 17:53:00 --> Form Validation Class Initialized
INFO - 2023-09-20 17:53:00 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:53:00 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:53:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-20 17:53:00 --> Final output sent to browser
DEBUG - 2023-09-20 17:53:00 --> Total execution time: 0.1419
INFO - 2023-09-20 17:54:14 --> Config Class Initialized
INFO - 2023-09-20 17:54:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:14 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:14 --> URI Class Initialized
DEBUG - 2023-09-20 17:54:14 --> No URI present. Default controller set.
INFO - 2023-09-20 17:54:14 --> Router Class Initialized
INFO - 2023-09-20 17:54:14 --> Output Class Initialized
INFO - 2023-09-20 17:54:14 --> Security Class Initialized
DEBUG - 2023-09-20 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:14 --> Input Class Initialized
INFO - 2023-09-20 17:54:14 --> Language Class Initialized
INFO - 2023-09-20 17:54:14 --> Loader Class Initialized
INFO - 2023-09-20 17:54:14 --> Helper loaded: url_helper
INFO - 2023-09-20 17:54:14 --> Helper loaded: file_helper
INFO - 2023-09-20 17:54:14 --> Database Driver Class Initialized
INFO - 2023-09-20 17:54:14 --> Email Class Initialized
DEBUG - 2023-09-20 17:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:54:14 --> Controller Class Initialized
INFO - 2023-09-20 17:54:14 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:54:14 --> Model "Home_model" initialized
INFO - 2023-09-20 17:54:14 --> Helper loaded: download_helper
INFO - 2023-09-20 17:54:14 --> Helper loaded: form_helper
INFO - 2023-09-20 17:54:14 --> Form Validation Class Initialized
INFO - 2023-09-20 17:54:14 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:54:14 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 17:54:14 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 17:54:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 17:54:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 17:54:14 --> Final output sent to browser
DEBUG - 2023-09-20 17:54:14 --> Total execution time: 0.1315
INFO - 2023-09-20 17:54:38 --> Config Class Initialized
INFO - 2023-09-20 17:54:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:38 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:38 --> URI Class Initialized
INFO - 2023-09-20 17:54:38 --> Router Class Initialized
INFO - 2023-09-20 17:54:38 --> Output Class Initialized
INFO - 2023-09-20 17:54:38 --> Security Class Initialized
DEBUG - 2023-09-20 17:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:38 --> Input Class Initialized
INFO - 2023-09-20 17:54:38 --> Language Class Initialized
ERROR - 2023-09-20 17:54:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:54:38 --> Config Class Initialized
INFO - 2023-09-20 17:54:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> Config Class Initialized
INFO - 2023-09-20 17:54:39 --> Hooks Class Initialized
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:54:39 --> Config Class Initialized
INFO - 2023-09-20 17:54:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:54:39 --> Config Class Initialized
INFO - 2023-09-20 17:54:39 --> Config Class Initialized
INFO - 2023-09-20 17:54:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:54:39 --> Config Class Initialized
INFO - 2023-09-20 17:54:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> Hooks Class Initialized
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
DEBUG - 2023-09-20 17:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Utf8 Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> URI Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
INFO - 2023-09-20 17:54:39 --> Router Class Initialized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
INFO - 2023-09-20 17:54:39 --> Output Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Security Class Initialized
DEBUG - 2023-09-20 17:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
INFO - 2023-09-20 17:54:39 --> Input Class Initialized
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
INFO - 2023-09-20 17:54:39 --> Language Class Initialized
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 17:54:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:59:50 --> Config Class Initialized
INFO - 2023-09-20 17:59:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:59:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:50 --> Utf8 Class Initialized
INFO - 2023-09-20 17:59:50 --> URI Class Initialized
INFO - 2023-09-20 17:59:50 --> Router Class Initialized
INFO - 2023-09-20 17:59:50 --> Output Class Initialized
INFO - 2023-09-20 17:59:50 --> Security Class Initialized
DEBUG - 2023-09-20 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:59:50 --> Input Class Initialized
INFO - 2023-09-20 17:59:50 --> Language Class Initialized
INFO - 2023-09-20 17:59:50 --> Loader Class Initialized
INFO - 2023-09-20 17:59:50 --> Helper loaded: url_helper
INFO - 2023-09-20 17:59:50 --> Helper loaded: file_helper
INFO - 2023-09-20 17:59:50 --> Database Driver Class Initialized
INFO - 2023-09-20 17:59:50 --> Email Class Initialized
DEBUG - 2023-09-20 17:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 17:59:50 --> Controller Class Initialized
INFO - 2023-09-20 17:59:50 --> Model "Contact_model" initialized
INFO - 2023-09-20 17:59:50 --> Model "Home_model" initialized
INFO - 2023-09-20 17:59:50 --> Helper loaded: download_helper
INFO - 2023-09-20 17:59:50 --> Helper loaded: form_helper
INFO - 2023-09-20 17:59:50 --> Form Validation Class Initialized
INFO - 2023-09-20 17:59:50 --> Helper loaded: custom_helper
INFO - 2023-09-20 17:59:50 --> Model "Social_media_model" initialized
INFO - 2023-09-20 17:59:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 17:59:50 --> Final output sent to browser
DEBUG - 2023-09-20 17:59:50 --> Total execution time: 0.2983
INFO - 2023-09-20 17:59:53 --> Config Class Initialized
INFO - 2023-09-20 17:59:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:59:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:53 --> Utf8 Class Initialized
INFO - 2023-09-20 17:59:53 --> URI Class Initialized
INFO - 2023-09-20 17:59:53 --> Router Class Initialized
INFO - 2023-09-20 17:59:53 --> Output Class Initialized
INFO - 2023-09-20 17:59:53 --> Security Class Initialized
DEBUG - 2023-09-20 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:59:53 --> Input Class Initialized
INFO - 2023-09-20 17:59:53 --> Language Class Initialized
ERROR - 2023-09-20 17:59:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:59:53 --> Config Class Initialized
INFO - 2023-09-20 17:59:53 --> Config Class Initialized
INFO - 2023-09-20 17:59:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:59:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:53 --> Utf8 Class Initialized
INFO - 2023-09-20 17:59:53 --> URI Class Initialized
INFO - 2023-09-20 17:59:53 --> Router Class Initialized
INFO - 2023-09-20 17:59:53 --> Output Class Initialized
INFO - 2023-09-20 17:59:53 --> Security Class Initialized
DEBUG - 2023-09-20 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:59:53 --> Input Class Initialized
INFO - 2023-09-20 17:59:53 --> Language Class Initialized
ERROR - 2023-09-20 17:59:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:59:54 --> Config Class Initialized
INFO - 2023-09-20 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:54 --> Hooks Class Initialized
INFO - 2023-09-20 17:59:54 --> Config Class Initialized
INFO - 2023-09-20 17:59:54 --> Config Class Initialized
INFO - 2023-09-20 17:59:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 17:59:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:54 --> Utf8 Class Initialized
INFO - 2023-09-20 17:59:54 --> URI Class Initialized
INFO - 2023-09-20 17:59:54 --> Router Class Initialized
INFO - 2023-09-20 17:59:54 --> Output Class Initialized
INFO - 2023-09-20 17:59:54 --> Security Class Initialized
DEBUG - 2023-09-20 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:59:54 --> Input Class Initialized
INFO - 2023-09-20 17:59:54 --> Language Class Initialized
ERROR - 2023-09-20 17:59:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:59:54 --> Config Class Initialized
DEBUG - 2023-09-20 17:59:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 17:59:55 --> Utf8 Class Initialized
INFO - 2023-09-20 17:59:55 --> URI Class Initialized
INFO - 2023-09-20 17:59:55 --> Router Class Initialized
INFO - 2023-09-20 17:59:55 --> Output Class Initialized
INFO - 2023-09-20 17:59:55 --> Security Class Initialized
DEBUG - 2023-09-20 17:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 17:59:55 --> Input Class Initialized
INFO - 2023-09-20 17:59:55 --> Language Class Initialized
ERROR - 2023-09-20 17:59:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 17:59:55 --> Hooks Class Initialized
INFO - 2023-09-20 17:59:55 --> Utf8 Class Initialized
INFO - 2023-09-20 18:00:46 --> Config Class Initialized
INFO - 2023-09-20 18:00:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:00:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:00:46 --> Utf8 Class Initialized
INFO - 2023-09-20 18:00:46 --> URI Class Initialized
INFO - 2023-09-20 18:00:46 --> Router Class Initialized
INFO - 2023-09-20 18:00:46 --> Output Class Initialized
INFO - 2023-09-20 18:00:46 --> Security Class Initialized
DEBUG - 2023-09-20 18:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:00:46 --> Input Class Initialized
INFO - 2023-09-20 18:00:46 --> Language Class Initialized
INFO - 2023-09-20 18:00:46 --> Loader Class Initialized
INFO - 2023-09-20 18:00:46 --> Helper loaded: url_helper
INFO - 2023-09-20 18:00:46 --> Helper loaded: file_helper
INFO - 2023-09-20 18:00:46 --> Database Driver Class Initialized
INFO - 2023-09-20 18:00:46 --> Email Class Initialized
DEBUG - 2023-09-20 18:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:00:46 --> Controller Class Initialized
INFO - 2023-09-20 18:00:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:00:46 --> Model "Home_model" initialized
INFO - 2023-09-20 18:00:46 --> Helper loaded: download_helper
INFO - 2023-09-20 18:00:46 --> Helper loaded: form_helper
INFO - 2023-09-20 18:00:46 --> Form Validation Class Initialized
INFO - 2023-09-20 18:00:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:00:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:00:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:00:46 --> Final output sent to browser
DEBUG - 2023-09-20 18:00:46 --> Total execution time: 0.1374
INFO - 2023-09-20 18:02:40 --> Config Class Initialized
INFO - 2023-09-20 18:02:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:02:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:02:40 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:40 --> URI Class Initialized
INFO - 2023-09-20 18:02:40 --> Router Class Initialized
INFO - 2023-09-20 18:02:40 --> Output Class Initialized
INFO - 2023-09-20 18:02:40 --> Security Class Initialized
DEBUG - 2023-09-20 18:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:02:40 --> Input Class Initialized
INFO - 2023-09-20 18:02:40 --> Language Class Initialized
ERROR - 2023-09-20 18:02:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:40 --> Config Class Initialized
INFO - 2023-09-20 18:02:40 --> Config Class Initialized
INFO - 2023-09-20 18:02:40 --> Hooks Class Initialized
INFO - 2023-09-20 18:02:40 --> Config Class Initialized
DEBUG - 2023-09-20 18:02:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:02:40 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:40 --> Hooks Class Initialized
INFO - 2023-09-20 18:02:40 --> Hooks Class Initialized
INFO - 2023-09-20 18:02:40 --> URI Class Initialized
DEBUG - 2023-09-20 18:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 18:02:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:02:40 --> Router Class Initialized
INFO - 2023-09-20 18:02:40 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:40 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:40 --> URI Class Initialized
INFO - 2023-09-20 18:02:40 --> URI Class Initialized
INFO - 2023-09-20 18:02:40 --> Output Class Initialized
INFO - 2023-09-20 18:02:40 --> Router Class Initialized
INFO - 2023-09-20 18:02:40 --> Security Class Initialized
INFO - 2023-09-20 18:02:40 --> Output Class Initialized
INFO - 2023-09-20 18:02:40 --> Router Class Initialized
DEBUG - 2023-09-20 18:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:02:40 --> Output Class Initialized
INFO - 2023-09-20 18:02:40 --> Security Class Initialized
INFO - 2023-09-20 18:02:40 --> Input Class Initialized
INFO - 2023-09-20 18:02:40 --> Security Class Initialized
INFO - 2023-09-20 18:02:40 --> Language Class Initialized
DEBUG - 2023-09-20 18:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 18:02:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:40 --> Input Class Initialized
DEBUG - 2023-09-20 18:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:02:40 --> Language Class Initialized
INFO - 2023-09-20 18:02:40 --> Input Class Initialized
ERROR - 2023-09-20 18:02:40 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:40 --> Language Class Initialized
ERROR - 2023-09-20 18:02:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:41 --> Config Class Initialized
INFO - 2023-09-20 18:02:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:02:41 --> Config Class Initialized
INFO - 2023-09-20 18:02:41 --> Config Class Initialized
INFO - 2023-09-20 18:02:41 --> Hooks Class Initialized
INFO - 2023-09-20 18:02:41 --> Hooks Class Initialized
INFO - 2023-09-20 18:02:41 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:41 --> URI Class Initialized
DEBUG - 2023-09-20 18:02:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 18:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:02:41 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:41 --> Router Class Initialized
INFO - 2023-09-20 18:02:41 --> Utf8 Class Initialized
INFO - 2023-09-20 18:02:41 --> URI Class Initialized
INFO - 2023-09-20 18:02:41 --> Output Class Initialized
INFO - 2023-09-20 18:02:41 --> URI Class Initialized
INFO - 2023-09-20 18:02:41 --> Security Class Initialized
INFO - 2023-09-20 18:02:41 --> Router Class Initialized
DEBUG - 2023-09-20 18:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:02:41 --> Output Class Initialized
INFO - 2023-09-20 18:02:41 --> Router Class Initialized
INFO - 2023-09-20 18:02:41 --> Input Class Initialized
INFO - 2023-09-20 18:02:41 --> Security Class Initialized
INFO - 2023-09-20 18:02:41 --> Output Class Initialized
INFO - 2023-09-20 18:02:41 --> Language Class Initialized
DEBUG - 2023-09-20 18:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 18:02:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:41 --> Security Class Initialized
INFO - 2023-09-20 18:02:41 --> Input Class Initialized
DEBUG - 2023-09-20 18:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:02:41 --> Language Class Initialized
INFO - 2023-09-20 18:02:41 --> Input Class Initialized
ERROR - 2023-09-20 18:02:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:02:41 --> Language Class Initialized
ERROR - 2023-09-20 18:02:41 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:03:30 --> Config Class Initialized
INFO - 2023-09-20 18:03:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:03:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:03:30 --> Utf8 Class Initialized
INFO - 2023-09-20 18:03:30 --> URI Class Initialized
INFO - 2023-09-20 18:03:30 --> Router Class Initialized
INFO - 2023-09-20 18:03:30 --> Output Class Initialized
INFO - 2023-09-20 18:03:30 --> Security Class Initialized
DEBUG - 2023-09-20 18:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:03:30 --> Input Class Initialized
INFO - 2023-09-20 18:03:30 --> Language Class Initialized
INFO - 2023-09-20 18:03:30 --> Loader Class Initialized
INFO - 2023-09-20 18:03:30 --> Helper loaded: url_helper
INFO - 2023-09-20 18:03:30 --> Helper loaded: file_helper
INFO - 2023-09-20 18:03:30 --> Database Driver Class Initialized
INFO - 2023-09-20 18:03:30 --> Email Class Initialized
DEBUG - 2023-09-20 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:03:30 --> Controller Class Initialized
INFO - 2023-09-20 18:03:30 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:03:30 --> Model "Home_model" initialized
INFO - 2023-09-20 18:03:30 --> Helper loaded: download_helper
INFO - 2023-09-20 18:03:30 --> Helper loaded: form_helper
INFO - 2023-09-20 18:03:30 --> Form Validation Class Initialized
INFO - 2023-09-20 18:03:30 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:03:30 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:03:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:03:30 --> Final output sent to browser
DEBUG - 2023-09-20 18:03:30 --> Total execution time: 0.3323
INFO - 2023-09-20 18:04:19 --> Config Class Initialized
INFO - 2023-09-20 18:04:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:19 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:19 --> URI Class Initialized
INFO - 2023-09-20 18:04:19 --> Router Class Initialized
INFO - 2023-09-20 18:04:19 --> Output Class Initialized
INFO - 2023-09-20 18:04:19 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:19 --> Input Class Initialized
INFO - 2023-09-20 18:04:19 --> Language Class Initialized
INFO - 2023-09-20 18:04:19 --> Loader Class Initialized
INFO - 2023-09-20 18:04:19 --> Helper loaded: url_helper
INFO - 2023-09-20 18:04:19 --> Helper loaded: file_helper
INFO - 2023-09-20 18:04:19 --> Database Driver Class Initialized
INFO - 2023-09-20 18:04:19 --> Email Class Initialized
DEBUG - 2023-09-20 18:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:04:19 --> Controller Class Initialized
INFO - 2023-09-20 18:04:19 --> Model "Services_model" initialized
INFO - 2023-09-20 18:04:19 --> Helper loaded: form_helper
INFO - 2023-09-20 18:04:19 --> Form Validation Class Initialized
INFO - 2023-09-20 18:04:19 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:04:19 --> Final output sent to browser
DEBUG - 2023-09-20 18:04:19 --> Total execution time: 0.2627
INFO - 2023-09-20 18:04:21 --> Config Class Initialized
INFO - 2023-09-20 18:04:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:21 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:21 --> URI Class Initialized
INFO - 2023-09-20 18:04:21 --> Router Class Initialized
INFO - 2023-09-20 18:04:21 --> Output Class Initialized
INFO - 2023-09-20 18:04:21 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:21 --> Input Class Initialized
INFO - 2023-09-20 18:04:21 --> Language Class Initialized
ERROR - 2023-09-20 18:04:21 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 18:04:23 --> Config Class Initialized
INFO - 2023-09-20 18:04:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:23 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:23 --> URI Class Initialized
INFO - 2023-09-20 18:04:23 --> Router Class Initialized
INFO - 2023-09-20 18:04:23 --> Output Class Initialized
INFO - 2023-09-20 18:04:23 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:23 --> Input Class Initialized
INFO - 2023-09-20 18:04:23 --> Language Class Initialized
INFO - 2023-09-20 18:04:23 --> Loader Class Initialized
INFO - 2023-09-20 18:04:23 --> Helper loaded: url_helper
INFO - 2023-09-20 18:04:23 --> Helper loaded: file_helper
INFO - 2023-09-20 18:04:23 --> Database Driver Class Initialized
INFO - 2023-09-20 18:04:23 --> Email Class Initialized
DEBUG - 2023-09-20 18:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:04:23 --> Controller Class Initialized
INFO - 2023-09-20 18:04:23 --> Model "Services_model" initialized
INFO - 2023-09-20 18:04:23 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:04:23 --> Helper loaded: form_helper
INFO - 2023-09-20 18:04:23 --> Form Validation Class Initialized
INFO - 2023-09-20 18:04:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:04:23 --> Final output sent to browser
DEBUG - 2023-09-20 18:04:23 --> Total execution time: 0.2784
INFO - 2023-09-20 18:04:25 --> Config Class Initialized
INFO - 2023-09-20 18:04:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:25 --> URI Class Initialized
INFO - 2023-09-20 18:04:25 --> Router Class Initialized
INFO - 2023-09-20 18:04:25 --> Output Class Initialized
INFO - 2023-09-20 18:04:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:25 --> Input Class Initialized
INFO - 2023-09-20 18:04:25 --> Language Class Initialized
ERROR - 2023-09-20 18:04:25 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-09-20 18:04:49 --> Config Class Initialized
INFO - 2023-09-20 18:04:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:49 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:49 --> URI Class Initialized
INFO - 2023-09-20 18:04:49 --> Router Class Initialized
INFO - 2023-09-20 18:04:49 --> Output Class Initialized
INFO - 2023-09-20 18:04:49 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:49 --> Input Class Initialized
INFO - 2023-09-20 18:04:49 --> Language Class Initialized
INFO - 2023-09-20 18:04:49 --> Loader Class Initialized
INFO - 2023-09-20 18:04:49 --> Helper loaded: url_helper
INFO - 2023-09-20 18:04:49 --> Helper loaded: file_helper
INFO - 2023-09-20 18:04:49 --> Database Driver Class Initialized
INFO - 2023-09-20 18:04:49 --> Email Class Initialized
DEBUG - 2023-09-20 18:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:04:49 --> Controller Class Initialized
INFO - 2023-09-20 18:04:49 --> Model "Services_model" initialized
INFO - 2023-09-20 18:04:49 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:04:49 --> Helper loaded: form_helper
INFO - 2023-09-20 18:04:49 --> Form Validation Class Initialized
INFO - 2023-09-20 18:04:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 18:04:49 --> Final output sent to browser
DEBUG - 2023-09-20 18:04:49 --> Total execution time: 0.1793
INFO - 2023-09-20 18:04:50 --> Config Class Initialized
INFO - 2023-09-20 18:04:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:04:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:04:50 --> Utf8 Class Initialized
INFO - 2023-09-20 18:04:50 --> URI Class Initialized
INFO - 2023-09-20 18:04:50 --> Router Class Initialized
INFO - 2023-09-20 18:04:50 --> Output Class Initialized
INFO - 2023-09-20 18:04:50 --> Security Class Initialized
DEBUG - 2023-09-20 18:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:04:50 --> Input Class Initialized
INFO - 2023-09-20 18:04:50 --> Language Class Initialized
INFO - 2023-09-20 18:04:50 --> Loader Class Initialized
INFO - 2023-09-20 18:04:50 --> Helper loaded: url_helper
INFO - 2023-09-20 18:04:50 --> Helper loaded: file_helper
INFO - 2023-09-20 18:04:50 --> Database Driver Class Initialized
INFO - 2023-09-20 18:04:50 --> Email Class Initialized
DEBUG - 2023-09-20 18:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:04:50 --> Controller Class Initialized
INFO - 2023-09-20 18:04:50 --> Model "Services_model" initialized
INFO - 2023-09-20 18:04:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:04:50 --> Helper loaded: form_helper
INFO - 2023-09-20 18:04:50 --> Form Validation Class Initialized
INFO - 2023-09-20 18:04:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 18:04:50 --> Final output sent to browser
DEBUG - 2023-09-20 18:04:50 --> Total execution time: 0.1485
INFO - 2023-09-20 18:06:06 --> Config Class Initialized
INFO - 2023-09-20 18:06:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:06:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:06:06 --> Utf8 Class Initialized
INFO - 2023-09-20 18:06:06 --> URI Class Initialized
INFO - 2023-09-20 18:06:06 --> Router Class Initialized
INFO - 2023-09-20 18:06:06 --> Output Class Initialized
INFO - 2023-09-20 18:06:06 --> Security Class Initialized
DEBUG - 2023-09-20 18:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:06:06 --> Input Class Initialized
INFO - 2023-09-20 18:06:06 --> Language Class Initialized
INFO - 2023-09-20 18:06:06 --> Loader Class Initialized
INFO - 2023-09-20 18:06:06 --> Helper loaded: url_helper
INFO - 2023-09-20 18:06:06 --> Helper loaded: file_helper
INFO - 2023-09-20 18:06:06 --> Database Driver Class Initialized
INFO - 2023-09-20 18:06:06 --> Email Class Initialized
DEBUG - 2023-09-20 18:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:06:06 --> Controller Class Initialized
INFO - 2023-09-20 18:06:06 --> Model "Services_model" initialized
INFO - 2023-09-20 18:06:06 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:06:06 --> Helper loaded: form_helper
INFO - 2023-09-20 18:06:06 --> Form Validation Class Initialized
INFO - 2023-09-20 18:06:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:06:06 --> Config Class Initialized
INFO - 2023-09-20 18:06:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:06:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:06:06 --> Utf8 Class Initialized
INFO - 2023-09-20 18:06:06 --> URI Class Initialized
INFO - 2023-09-20 18:06:06 --> Router Class Initialized
INFO - 2023-09-20 18:06:06 --> Output Class Initialized
INFO - 2023-09-20 18:06:06 --> Security Class Initialized
DEBUG - 2023-09-20 18:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:06:06 --> Input Class Initialized
INFO - 2023-09-20 18:06:06 --> Language Class Initialized
INFO - 2023-09-20 18:06:06 --> Loader Class Initialized
INFO - 2023-09-20 18:06:06 --> Helper loaded: url_helper
INFO - 2023-09-20 18:06:06 --> Helper loaded: file_helper
INFO - 2023-09-20 18:06:06 --> Database Driver Class Initialized
INFO - 2023-09-20 18:06:06 --> Email Class Initialized
DEBUG - 2023-09-20 18:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:06:06 --> Controller Class Initialized
INFO - 2023-09-20 18:06:06 --> Model "Services_model" initialized
INFO - 2023-09-20 18:06:06 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:06:06 --> Helper loaded: form_helper
INFO - 2023-09-20 18:06:06 --> Form Validation Class Initialized
INFO - 2023-09-20 18:06:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:06:06 --> Final output sent to browser
DEBUG - 2023-09-20 18:06:07 --> Total execution time: 0.5588
INFO - 2023-09-20 18:06:11 --> Config Class Initialized
INFO - 2023-09-20 18:06:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:06:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:06:11 --> Utf8 Class Initialized
INFO - 2023-09-20 18:06:11 --> URI Class Initialized
INFO - 2023-09-20 18:06:11 --> Router Class Initialized
INFO - 2023-09-20 18:06:11 --> Output Class Initialized
INFO - 2023-09-20 18:06:11 --> Security Class Initialized
DEBUG - 2023-09-20 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:06:11 --> Input Class Initialized
INFO - 2023-09-20 18:06:11 --> Language Class Initialized
INFO - 2023-09-20 18:06:11 --> Loader Class Initialized
INFO - 2023-09-20 18:06:11 --> Helper loaded: url_helper
INFO - 2023-09-20 18:06:11 --> Helper loaded: file_helper
INFO - 2023-09-20 18:06:11 --> Database Driver Class Initialized
INFO - 2023-09-20 18:06:11 --> Email Class Initialized
DEBUG - 2023-09-20 18:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:06:11 --> Controller Class Initialized
INFO - 2023-09-20 18:06:11 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:06:11 --> Model "Home_model" initialized
INFO - 2023-09-20 18:06:11 --> Helper loaded: download_helper
INFO - 2023-09-20 18:06:11 --> Helper loaded: form_helper
INFO - 2023-09-20 18:06:11 --> Form Validation Class Initialized
INFO - 2023-09-20 18:06:11 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:06:11 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:06:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:06:11 --> Final output sent to browser
DEBUG - 2023-09-20 18:06:11 --> Total execution time: 0.1081
INFO - 2023-09-20 18:14:25 --> Config Class Initialized
INFO - 2023-09-20 18:14:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:14:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:14:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:14:25 --> URI Class Initialized
INFO - 2023-09-20 18:14:25 --> Router Class Initialized
INFO - 2023-09-20 18:14:25 --> Output Class Initialized
INFO - 2023-09-20 18:14:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:14:25 --> Input Class Initialized
INFO - 2023-09-20 18:14:25 --> Language Class Initialized
INFO - 2023-09-20 18:14:25 --> Loader Class Initialized
INFO - 2023-09-20 18:14:25 --> Helper loaded: url_helper
INFO - 2023-09-20 18:14:25 --> Helper loaded: file_helper
INFO - 2023-09-20 18:14:25 --> Database Driver Class Initialized
INFO - 2023-09-20 18:14:25 --> Email Class Initialized
DEBUG - 2023-09-20 18:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:14:25 --> Controller Class Initialized
INFO - 2023-09-20 18:14:25 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:14:25 --> Model "Home_model" initialized
INFO - 2023-09-20 18:14:25 --> Helper loaded: download_helper
INFO - 2023-09-20 18:14:25 --> Helper loaded: form_helper
INFO - 2023-09-20 18:14:25 --> Form Validation Class Initialized
INFO - 2023-09-20 18:14:25 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:14:25 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:14:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:14:25 --> Final output sent to browser
DEBUG - 2023-09-20 18:14:25 --> Total execution time: 0.2474
INFO - 2023-09-20 18:14:35 --> Config Class Initialized
INFO - 2023-09-20 18:14:35 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:14:35 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:14:35 --> Utf8 Class Initialized
INFO - 2023-09-20 18:14:35 --> URI Class Initialized
INFO - 2023-09-20 18:14:35 --> Router Class Initialized
INFO - 2023-09-20 18:14:35 --> Output Class Initialized
INFO - 2023-09-20 18:14:35 --> Security Class Initialized
DEBUG - 2023-09-20 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:14:35 --> Input Class Initialized
INFO - 2023-09-20 18:14:35 --> Language Class Initialized
INFO - 2023-09-20 18:14:35 --> Loader Class Initialized
INFO - 2023-09-20 18:14:35 --> Helper loaded: url_helper
INFO - 2023-09-20 18:14:35 --> Helper loaded: file_helper
INFO - 2023-09-20 18:14:35 --> Database Driver Class Initialized
INFO - 2023-09-20 18:14:35 --> Email Class Initialized
DEBUG - 2023-09-20 18:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:14:35 --> Controller Class Initialized
INFO - 2023-09-20 18:14:35 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:14:35 --> Model "Home_model" initialized
INFO - 2023-09-20 18:14:35 --> Helper loaded: download_helper
INFO - 2023-09-20 18:14:35 --> Helper loaded: form_helper
INFO - 2023-09-20 18:14:35 --> Form Validation Class Initialized
INFO - 2023-09-20 18:14:35 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:14:35 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:14:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:14:35 --> Final output sent to browser
DEBUG - 2023-09-20 18:14:36 --> Total execution time: 0.1100
INFO - 2023-09-20 18:23:17 --> Config Class Initialized
INFO - 2023-09-20 18:23:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:23:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:23:17 --> Utf8 Class Initialized
INFO - 2023-09-20 18:23:17 --> URI Class Initialized
INFO - 2023-09-20 18:23:17 --> Router Class Initialized
INFO - 2023-09-20 18:23:17 --> Output Class Initialized
INFO - 2023-09-20 18:23:17 --> Security Class Initialized
DEBUG - 2023-09-20 18:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:23:17 --> Input Class Initialized
INFO - 2023-09-20 18:23:17 --> Language Class Initialized
INFO - 2023-09-20 18:23:18 --> Loader Class Initialized
INFO - 2023-09-20 18:23:18 --> Helper loaded: url_helper
INFO - 2023-09-20 18:23:18 --> Helper loaded: file_helper
INFO - 2023-09-20 18:23:18 --> Database Driver Class Initialized
INFO - 2023-09-20 18:23:18 --> Email Class Initialized
DEBUG - 2023-09-20 18:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:23:18 --> Controller Class Initialized
INFO - 2023-09-20 18:23:18 --> Model "Services_model" initialized
INFO - 2023-09-20 18:23:18 --> Helper loaded: form_helper
INFO - 2023-09-20 18:23:18 --> Form Validation Class Initialized
INFO - 2023-09-20 18:23:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:23:18 --> Final output sent to browser
DEBUG - 2023-09-20 18:23:18 --> Total execution time: 1.1007
INFO - 2023-09-20 18:23:19 --> Config Class Initialized
INFO - 2023-09-20 18:23:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:23:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:23:19 --> Utf8 Class Initialized
INFO - 2023-09-20 18:23:19 --> URI Class Initialized
INFO - 2023-09-20 18:23:19 --> Router Class Initialized
INFO - 2023-09-20 18:23:19 --> Output Class Initialized
INFO - 2023-09-20 18:23:19 --> Security Class Initialized
DEBUG - 2023-09-20 18:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:23:19 --> Input Class Initialized
INFO - 2023-09-20 18:23:19 --> Language Class Initialized
ERROR - 2023-09-20 18:23:19 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 18:23:33 --> Config Class Initialized
INFO - 2023-09-20 18:23:33 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:23:33 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:23:33 --> Utf8 Class Initialized
INFO - 2023-09-20 18:23:33 --> URI Class Initialized
INFO - 2023-09-20 18:23:33 --> Router Class Initialized
INFO - 2023-09-20 18:23:33 --> Output Class Initialized
INFO - 2023-09-20 18:23:33 --> Security Class Initialized
DEBUG - 2023-09-20 18:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:23:33 --> Input Class Initialized
INFO - 2023-09-20 18:23:33 --> Language Class Initialized
INFO - 2023-09-20 18:23:33 --> Loader Class Initialized
INFO - 2023-09-20 18:23:33 --> Helper loaded: url_helper
INFO - 2023-09-20 18:23:33 --> Helper loaded: file_helper
INFO - 2023-09-20 18:23:33 --> Database Driver Class Initialized
INFO - 2023-09-20 18:23:33 --> Email Class Initialized
DEBUG - 2023-09-20 18:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:23:33 --> Controller Class Initialized
INFO - 2023-09-20 18:23:33 --> Model "Services_model" initialized
INFO - 2023-09-20 18:23:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:23:33 --> Helper loaded: form_helper
INFO - 2023-09-20 18:23:33 --> Form Validation Class Initialized
INFO - 2023-09-20 18:23:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:23:33 --> Final output sent to browser
DEBUG - 2023-09-20 18:23:33 --> Total execution time: 0.2526
INFO - 2023-09-20 18:23:34 --> Config Class Initialized
INFO - 2023-09-20 18:23:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:23:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:23:34 --> Utf8 Class Initialized
INFO - 2023-09-20 18:23:34 --> URI Class Initialized
INFO - 2023-09-20 18:23:34 --> Router Class Initialized
INFO - 2023-09-20 18:23:34 --> Output Class Initialized
INFO - 2023-09-20 18:23:34 --> Security Class Initialized
DEBUG - 2023-09-20 18:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:23:34 --> Input Class Initialized
INFO - 2023-09-20 18:23:34 --> Language Class Initialized
ERROR - 2023-09-20 18:23:34 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-09-20 18:23:40 --> Config Class Initialized
INFO - 2023-09-20 18:23:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:23:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:23:40 --> Utf8 Class Initialized
INFO - 2023-09-20 18:23:40 --> URI Class Initialized
INFO - 2023-09-20 18:23:40 --> Router Class Initialized
INFO - 2023-09-20 18:23:40 --> Output Class Initialized
INFO - 2023-09-20 18:23:40 --> Security Class Initialized
DEBUG - 2023-09-20 18:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:23:40 --> Input Class Initialized
INFO - 2023-09-20 18:23:40 --> Language Class Initialized
INFO - 2023-09-20 18:23:40 --> Loader Class Initialized
INFO - 2023-09-20 18:23:40 --> Helper loaded: url_helper
INFO - 2023-09-20 18:23:40 --> Helper loaded: file_helper
INFO - 2023-09-20 18:23:40 --> Database Driver Class Initialized
INFO - 2023-09-20 18:23:40 --> Email Class Initialized
DEBUG - 2023-09-20 18:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:23:40 --> Controller Class Initialized
INFO - 2023-09-20 18:23:40 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:23:40 --> Model "Home_model" initialized
INFO - 2023-09-20 18:23:40 --> Helper loaded: download_helper
INFO - 2023-09-20 18:23:40 --> Helper loaded: form_helper
INFO - 2023-09-20 18:23:40 --> Form Validation Class Initialized
INFO - 2023-09-20 18:23:40 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:23:40 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:23:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:23:40 --> Final output sent to browser
DEBUG - 2023-09-20 18:23:40 --> Total execution time: 0.3506
INFO - 2023-09-20 18:24:47 --> Config Class Initialized
INFO - 2023-09-20 18:24:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:24:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:24:47 --> Utf8 Class Initialized
INFO - 2023-09-20 18:24:47 --> URI Class Initialized
INFO - 2023-09-20 18:24:47 --> Router Class Initialized
INFO - 2023-09-20 18:24:47 --> Output Class Initialized
INFO - 2023-09-20 18:24:47 --> Security Class Initialized
DEBUG - 2023-09-20 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:24:47 --> Input Class Initialized
INFO - 2023-09-20 18:24:47 --> Language Class Initialized
INFO - 2023-09-20 18:24:47 --> Loader Class Initialized
INFO - 2023-09-20 18:24:47 --> Helper loaded: url_helper
INFO - 2023-09-20 18:24:47 --> Helper loaded: file_helper
INFO - 2023-09-20 18:24:47 --> Database Driver Class Initialized
INFO - 2023-09-20 18:24:47 --> Email Class Initialized
DEBUG - 2023-09-20 18:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:24:47 --> Controller Class Initialized
INFO - 2023-09-20 18:24:47 --> Model "Services_model" initialized
INFO - 2023-09-20 18:24:47 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:24:47 --> Helper loaded: form_helper
INFO - 2023-09-20 18:24:47 --> Form Validation Class Initialized
INFO - 2023-09-20 18:24:47 --> Config Class Initialized
INFO - 2023-09-20 18:24:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:24:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:24:47 --> Utf8 Class Initialized
INFO - 2023-09-20 18:24:47 --> URI Class Initialized
INFO - 2023-09-20 18:24:47 --> Router Class Initialized
INFO - 2023-09-20 18:24:47 --> Output Class Initialized
INFO - 2023-09-20 18:24:47 --> Security Class Initialized
DEBUG - 2023-09-20 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:24:47 --> Input Class Initialized
INFO - 2023-09-20 18:24:47 --> Language Class Initialized
INFO - 2023-09-20 18:24:47 --> Loader Class Initialized
INFO - 2023-09-20 18:24:47 --> Helper loaded: url_helper
INFO - 2023-09-20 18:24:47 --> Helper loaded: file_helper
INFO - 2023-09-20 18:24:47 --> Database Driver Class Initialized
INFO - 2023-09-20 18:24:47 --> Email Class Initialized
DEBUG - 2023-09-20 18:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:24:47 --> Controller Class Initialized
INFO - 2023-09-20 18:24:47 --> Model "Services_model" initialized
INFO - 2023-09-20 18:24:47 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:24:47 --> Helper loaded: form_helper
INFO - 2023-09-20 18:24:47 --> Form Validation Class Initialized
INFO - 2023-09-20 18:24:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:24:47 --> Final output sent to browser
DEBUG - 2023-09-20 18:24:48 --> Total execution time: 0.1177
INFO - 2023-09-20 18:24:54 --> Config Class Initialized
INFO - 2023-09-20 18:24:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:24:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:24:54 --> Utf8 Class Initialized
INFO - 2023-09-20 18:24:54 --> URI Class Initialized
INFO - 2023-09-20 18:24:54 --> Router Class Initialized
INFO - 2023-09-20 18:24:54 --> Output Class Initialized
INFO - 2023-09-20 18:24:54 --> Security Class Initialized
DEBUG - 2023-09-20 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:24:54 --> Input Class Initialized
INFO - 2023-09-20 18:24:54 --> Language Class Initialized
INFO - 2023-09-20 18:24:54 --> Loader Class Initialized
INFO - 2023-09-20 18:24:54 --> Helper loaded: url_helper
INFO - 2023-09-20 18:24:54 --> Helper loaded: file_helper
INFO - 2023-09-20 18:24:54 --> Database Driver Class Initialized
INFO - 2023-09-20 18:24:54 --> Email Class Initialized
DEBUG - 2023-09-20 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:24:54 --> Controller Class Initialized
INFO - 2023-09-20 18:24:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:24:54 --> Model "Home_model" initialized
INFO - 2023-09-20 18:24:54 --> Helper loaded: download_helper
INFO - 2023-09-20 18:24:54 --> Helper loaded: form_helper
INFO - 2023-09-20 18:24:54 --> Form Validation Class Initialized
INFO - 2023-09-20 18:24:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:24:54 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:24:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:24:54 --> Final output sent to browser
DEBUG - 2023-09-20 18:24:54 --> Total execution time: 0.1165
INFO - 2023-09-20 18:25:53 --> Config Class Initialized
INFO - 2023-09-20 18:25:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:25:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:25:53 --> Utf8 Class Initialized
INFO - 2023-09-20 18:25:53 --> URI Class Initialized
INFO - 2023-09-20 18:25:53 --> Router Class Initialized
INFO - 2023-09-20 18:25:53 --> Output Class Initialized
INFO - 2023-09-20 18:25:53 --> Security Class Initialized
DEBUG - 2023-09-20 18:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:25:53 --> Input Class Initialized
INFO - 2023-09-20 18:25:53 --> Language Class Initialized
INFO - 2023-09-20 18:25:53 --> Loader Class Initialized
INFO - 2023-09-20 18:25:53 --> Helper loaded: url_helper
INFO - 2023-09-20 18:25:53 --> Helper loaded: file_helper
INFO - 2023-09-20 18:25:53 --> Database Driver Class Initialized
INFO - 2023-09-20 18:25:53 --> Email Class Initialized
DEBUG - 2023-09-20 18:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:25:53 --> Controller Class Initialized
INFO - 2023-09-20 18:25:53 --> Model "Services_model" initialized
INFO - 2023-09-20 18:25:53 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:25:53 --> Helper loaded: form_helper
INFO - 2023-09-20 18:25:53 --> Form Validation Class Initialized
INFO - 2023-09-20 18:25:54 --> Config Class Initialized
INFO - 2023-09-20 18:25:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:25:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:25:54 --> Utf8 Class Initialized
INFO - 2023-09-20 18:25:54 --> URI Class Initialized
INFO - 2023-09-20 18:25:54 --> Router Class Initialized
INFO - 2023-09-20 18:25:54 --> Output Class Initialized
INFO - 2023-09-20 18:25:54 --> Security Class Initialized
DEBUG - 2023-09-20 18:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:25:54 --> Input Class Initialized
INFO - 2023-09-20 18:25:54 --> Language Class Initialized
INFO - 2023-09-20 18:25:54 --> Loader Class Initialized
INFO - 2023-09-20 18:25:54 --> Helper loaded: url_helper
INFO - 2023-09-20 18:25:54 --> Helper loaded: file_helper
INFO - 2023-09-20 18:25:54 --> Database Driver Class Initialized
INFO - 2023-09-20 18:25:54 --> Email Class Initialized
DEBUG - 2023-09-20 18:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:25:54 --> Controller Class Initialized
INFO - 2023-09-20 18:25:54 --> Model "Services_model" initialized
INFO - 2023-09-20 18:25:54 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:25:54 --> Helper loaded: form_helper
INFO - 2023-09-20 18:25:54 --> Form Validation Class Initialized
INFO - 2023-09-20 18:25:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:25:54 --> Final output sent to browser
DEBUG - 2023-09-20 18:25:54 --> Total execution time: 0.1265
INFO - 2023-09-20 18:26:21 --> Config Class Initialized
INFO - 2023-09-20 18:26:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:26:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:26:21 --> Utf8 Class Initialized
INFO - 2023-09-20 18:26:21 --> URI Class Initialized
INFO - 2023-09-20 18:26:21 --> Router Class Initialized
INFO - 2023-09-20 18:26:21 --> Output Class Initialized
INFO - 2023-09-20 18:26:21 --> Security Class Initialized
DEBUG - 2023-09-20 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:26:21 --> Input Class Initialized
INFO - 2023-09-20 18:26:21 --> Language Class Initialized
INFO - 2023-09-20 18:26:21 --> Loader Class Initialized
INFO - 2023-09-20 18:26:21 --> Helper loaded: url_helper
INFO - 2023-09-20 18:26:21 --> Helper loaded: file_helper
INFO - 2023-09-20 18:26:21 --> Database Driver Class Initialized
INFO - 2023-09-20 18:26:21 --> Email Class Initialized
DEBUG - 2023-09-20 18:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:26:21 --> Controller Class Initialized
INFO - 2023-09-20 18:26:21 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:26:21 --> Model "Home_model" initialized
INFO - 2023-09-20 18:26:21 --> Helper loaded: download_helper
INFO - 2023-09-20 18:26:21 --> Helper loaded: form_helper
INFO - 2023-09-20 18:26:21 --> Form Validation Class Initialized
INFO - 2023-09-20 18:26:21 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:26:21 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:26:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:26:21 --> Final output sent to browser
DEBUG - 2023-09-20 18:26:21 --> Total execution time: 0.1055
INFO - 2023-09-20 18:27:54 --> Config Class Initialized
INFO - 2023-09-20 18:27:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:27:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:27:54 --> Utf8 Class Initialized
INFO - 2023-09-20 18:27:54 --> URI Class Initialized
INFO - 2023-09-20 18:27:54 --> Router Class Initialized
INFO - 2023-09-20 18:27:54 --> Output Class Initialized
INFO - 2023-09-20 18:27:54 --> Security Class Initialized
DEBUG - 2023-09-20 18:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:27:54 --> Input Class Initialized
INFO - 2023-09-20 18:27:54 --> Language Class Initialized
INFO - 2023-09-20 18:27:54 --> Loader Class Initialized
INFO - 2023-09-20 18:27:54 --> Helper loaded: url_helper
INFO - 2023-09-20 18:27:54 --> Helper loaded: file_helper
INFO - 2023-09-20 18:27:54 --> Database Driver Class Initialized
INFO - 2023-09-20 18:27:54 --> Email Class Initialized
DEBUG - 2023-09-20 18:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:27:54 --> Controller Class Initialized
INFO - 2023-09-20 18:27:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:27:54 --> Model "Home_model" initialized
INFO - 2023-09-20 18:27:54 --> Helper loaded: download_helper
INFO - 2023-09-20 18:27:54 --> Helper loaded: form_helper
INFO - 2023-09-20 18:27:54 --> Form Validation Class Initialized
INFO - 2023-09-20 18:27:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:27:54 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:27:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:27:54 --> Final output sent to browser
DEBUG - 2023-09-20 18:27:54 --> Total execution time: 0.0998
INFO - 2023-09-20 18:29:55 --> Config Class Initialized
INFO - 2023-09-20 18:29:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:29:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:29:55 --> Utf8 Class Initialized
INFO - 2023-09-20 18:29:55 --> URI Class Initialized
INFO - 2023-09-20 18:29:55 --> Router Class Initialized
INFO - 2023-09-20 18:29:55 --> Output Class Initialized
INFO - 2023-09-20 18:29:55 --> Security Class Initialized
DEBUG - 2023-09-20 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:29:55 --> Input Class Initialized
INFO - 2023-09-20 18:29:55 --> Language Class Initialized
INFO - 2023-09-20 18:29:55 --> Loader Class Initialized
INFO - 2023-09-20 18:29:55 --> Helper loaded: url_helper
INFO - 2023-09-20 18:29:55 --> Helper loaded: file_helper
INFO - 2023-09-20 18:29:55 --> Database Driver Class Initialized
INFO - 2023-09-20 18:29:55 --> Email Class Initialized
DEBUG - 2023-09-20 18:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:29:56 --> Controller Class Initialized
INFO - 2023-09-20 18:29:56 --> Model "Services_model" initialized
INFO - 2023-09-20 18:29:56 --> Helper loaded: form_helper
INFO - 2023-09-20 18:29:56 --> Form Validation Class Initialized
INFO - 2023-09-20 18:29:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:29:56 --> Final output sent to browser
DEBUG - 2023-09-20 18:29:56 --> Total execution time: 0.0955
INFO - 2023-09-20 18:30:01 --> Config Class Initialized
INFO - 2023-09-20 18:30:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:01 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:01 --> URI Class Initialized
INFO - 2023-09-20 18:30:01 --> Router Class Initialized
INFO - 2023-09-20 18:30:01 --> Output Class Initialized
INFO - 2023-09-20 18:30:01 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:01 --> Input Class Initialized
INFO - 2023-09-20 18:30:01 --> Language Class Initialized
INFO - 2023-09-20 18:30:01 --> Loader Class Initialized
INFO - 2023-09-20 18:30:01 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:01 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:01 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:01 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:01 --> Controller Class Initialized
INFO - 2023-09-20 18:30:01 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:01 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:01 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 18:30:02 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:02 --> Total execution time: 0.3109
INFO - 2023-09-20 18:30:03 --> Config Class Initialized
INFO - 2023-09-20 18:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:03 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:03 --> URI Class Initialized
INFO - 2023-09-20 18:30:03 --> Router Class Initialized
INFO - 2023-09-20 18:30:03 --> Output Class Initialized
INFO - 2023-09-20 18:30:03 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:03 --> Input Class Initialized
INFO - 2023-09-20 18:30:03 --> Language Class Initialized
INFO - 2023-09-20 18:30:03 --> Loader Class Initialized
INFO - 2023-09-20 18:30:03 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:03 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:03 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:03 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:03 --> Controller Class Initialized
INFO - 2023-09-20 18:30:03 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:03 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:03 --> Form Validation Class Initialized
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 18:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 18:30:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 18:30:03 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:03 --> Total execution time: 0.1724
INFO - 2023-09-20 18:30:20 --> Config Class Initialized
INFO - 2023-09-20 18:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:20 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:20 --> URI Class Initialized
INFO - 2023-09-20 18:30:20 --> Router Class Initialized
INFO - 2023-09-20 18:30:20 --> Output Class Initialized
INFO - 2023-09-20 18:30:20 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:20 --> Input Class Initialized
INFO - 2023-09-20 18:30:20 --> Language Class Initialized
INFO - 2023-09-20 18:30:20 --> Loader Class Initialized
INFO - 2023-09-20 18:30:20 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:20 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:20 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:20 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:20 --> Controller Class Initialized
INFO - 2023-09-20 18:30:20 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:20 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:20 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:30:20 --> Config Class Initialized
INFO - 2023-09-20 18:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:20 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:20 --> URI Class Initialized
INFO - 2023-09-20 18:30:20 --> Router Class Initialized
INFO - 2023-09-20 18:30:20 --> Output Class Initialized
INFO - 2023-09-20 18:30:20 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:20 --> Input Class Initialized
INFO - 2023-09-20 18:30:20 --> Language Class Initialized
INFO - 2023-09-20 18:30:20 --> Loader Class Initialized
INFO - 2023-09-20 18:30:20 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:20 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:20 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:20 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:20 --> Controller Class Initialized
INFO - 2023-09-20 18:30:20 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:20 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:20 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:30:20 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:20 --> Total execution time: 0.0816
INFO - 2023-09-20 18:30:23 --> Config Class Initialized
INFO - 2023-09-20 18:30:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:23 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:23 --> URI Class Initialized
INFO - 2023-09-20 18:30:23 --> Router Class Initialized
INFO - 2023-09-20 18:30:23 --> Output Class Initialized
INFO - 2023-09-20 18:30:23 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:23 --> Input Class Initialized
INFO - 2023-09-20 18:30:23 --> Language Class Initialized
INFO - 2023-09-20 18:30:23 --> Loader Class Initialized
INFO - 2023-09-20 18:30:23 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:23 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:23 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:23 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:23 --> Controller Class Initialized
INFO - 2023-09-20 18:30:23 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:30:23 --> Model "Home_model" initialized
INFO - 2023-09-20 18:30:23 --> Helper loaded: download_helper
INFO - 2023-09-20 18:30:23 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:23 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:30:23 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:30:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:30:23 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:23 --> Total execution time: 0.1288
INFO - 2023-09-20 18:30:39 --> Config Class Initialized
INFO - 2023-09-20 18:30:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:39 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:39 --> URI Class Initialized
INFO - 2023-09-20 18:30:39 --> Router Class Initialized
INFO - 2023-09-20 18:30:39 --> Output Class Initialized
INFO - 2023-09-20 18:30:39 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:39 --> Input Class Initialized
INFO - 2023-09-20 18:30:39 --> Language Class Initialized
INFO - 2023-09-20 18:30:39 --> Loader Class Initialized
INFO - 2023-09-20 18:30:39 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:39 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:39 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:39 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:39 --> Controller Class Initialized
INFO - 2023-09-20 18:30:39 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:39 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:30:39 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:39 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:30:39 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:39 --> Total execution time: 0.1192
INFO - 2023-09-20 18:30:43 --> Config Class Initialized
INFO - 2023-09-20 18:30:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:43 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:43 --> URI Class Initialized
INFO - 2023-09-20 18:30:43 --> Router Class Initialized
INFO - 2023-09-20 18:30:43 --> Output Class Initialized
INFO - 2023-09-20 18:30:43 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:43 --> Input Class Initialized
INFO - 2023-09-20 18:30:43 --> Language Class Initialized
INFO - 2023-09-20 18:30:43 --> Loader Class Initialized
INFO - 2023-09-20 18:30:43 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:43 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:43 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:43 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:43 --> Controller Class Initialized
INFO - 2023-09-20 18:30:43 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:43 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:30:43 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:43 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 18:30:43 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:43 --> Total execution time: 0.1852
INFO - 2023-09-20 18:30:43 --> Config Class Initialized
INFO - 2023-09-20 18:30:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:30:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:30:43 --> Utf8 Class Initialized
INFO - 2023-09-20 18:30:43 --> URI Class Initialized
INFO - 2023-09-20 18:30:43 --> Router Class Initialized
INFO - 2023-09-20 18:30:43 --> Output Class Initialized
INFO - 2023-09-20 18:30:43 --> Security Class Initialized
DEBUG - 2023-09-20 18:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:30:43 --> Input Class Initialized
INFO - 2023-09-20 18:30:43 --> Language Class Initialized
INFO - 2023-09-20 18:30:43 --> Loader Class Initialized
INFO - 2023-09-20 18:30:43 --> Helper loaded: url_helper
INFO - 2023-09-20 18:30:43 --> Helper loaded: file_helper
INFO - 2023-09-20 18:30:43 --> Database Driver Class Initialized
INFO - 2023-09-20 18:30:43 --> Email Class Initialized
DEBUG - 2023-09-20 18:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:30:43 --> Controller Class Initialized
INFO - 2023-09-20 18:30:43 --> Model "Services_model" initialized
INFO - 2023-09-20 18:30:43 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:30:43 --> Helper loaded: form_helper
INFO - 2023-09-20 18:30:43 --> Form Validation Class Initialized
INFO - 2023-09-20 18:30:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 18:30:43 --> Final output sent to browser
DEBUG - 2023-09-20 18:30:43 --> Total execution time: 0.0464
INFO - 2023-09-20 18:31:01 --> Config Class Initialized
INFO - 2023-09-20 18:31:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:31:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:31:01 --> Utf8 Class Initialized
INFO - 2023-09-20 18:31:01 --> URI Class Initialized
INFO - 2023-09-20 18:31:01 --> Router Class Initialized
INFO - 2023-09-20 18:31:01 --> Output Class Initialized
INFO - 2023-09-20 18:31:01 --> Security Class Initialized
DEBUG - 2023-09-20 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:31:01 --> Input Class Initialized
INFO - 2023-09-20 18:31:01 --> Language Class Initialized
INFO - 2023-09-20 18:31:01 --> Loader Class Initialized
INFO - 2023-09-20 18:31:01 --> Helper loaded: url_helper
INFO - 2023-09-20 18:31:01 --> Helper loaded: file_helper
INFO - 2023-09-20 18:31:01 --> Database Driver Class Initialized
INFO - 2023-09-20 18:31:01 --> Email Class Initialized
DEBUG - 2023-09-20 18:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:31:01 --> Controller Class Initialized
INFO - 2023-09-20 18:31:01 --> Model "Services_model" initialized
INFO - 2023-09-20 18:31:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:31:01 --> Helper loaded: form_helper
INFO - 2023-09-20 18:31:01 --> Form Validation Class Initialized
INFO - 2023-09-20 18:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:31:01 --> Config Class Initialized
INFO - 2023-09-20 18:31:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:31:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:31:01 --> Utf8 Class Initialized
INFO - 2023-09-20 18:31:01 --> URI Class Initialized
INFO - 2023-09-20 18:31:01 --> Router Class Initialized
INFO - 2023-09-20 18:31:01 --> Output Class Initialized
INFO - 2023-09-20 18:31:01 --> Security Class Initialized
DEBUG - 2023-09-20 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:31:01 --> Input Class Initialized
INFO - 2023-09-20 18:31:01 --> Language Class Initialized
INFO - 2023-09-20 18:31:01 --> Loader Class Initialized
INFO - 2023-09-20 18:31:01 --> Helper loaded: url_helper
INFO - 2023-09-20 18:31:01 --> Helper loaded: file_helper
INFO - 2023-09-20 18:31:01 --> Database Driver Class Initialized
INFO - 2023-09-20 18:31:01 --> Email Class Initialized
DEBUG - 2023-09-20 18:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:31:01 --> Controller Class Initialized
INFO - 2023-09-20 18:31:01 --> Model "Services_model" initialized
INFO - 2023-09-20 18:31:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:31:01 --> Helper loaded: form_helper
INFO - 2023-09-20 18:31:01 --> Form Validation Class Initialized
INFO - 2023-09-20 18:31:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:31:01 --> Final output sent to browser
DEBUG - 2023-09-20 18:31:01 --> Total execution time: 0.0824
INFO - 2023-09-20 18:31:07 --> Config Class Initialized
INFO - 2023-09-20 18:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:31:07 --> Utf8 Class Initialized
INFO - 2023-09-20 18:31:07 --> URI Class Initialized
INFO - 2023-09-20 18:31:07 --> Router Class Initialized
INFO - 2023-09-20 18:31:07 --> Output Class Initialized
INFO - 2023-09-20 18:31:07 --> Security Class Initialized
DEBUG - 2023-09-20 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:31:07 --> Input Class Initialized
INFO - 2023-09-20 18:31:07 --> Language Class Initialized
INFO - 2023-09-20 18:31:07 --> Loader Class Initialized
INFO - 2023-09-20 18:31:07 --> Helper loaded: url_helper
INFO - 2023-09-20 18:31:07 --> Helper loaded: file_helper
INFO - 2023-09-20 18:31:07 --> Database Driver Class Initialized
INFO - 2023-09-20 18:31:07 --> Email Class Initialized
DEBUG - 2023-09-20 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:31:07 --> Controller Class Initialized
INFO - 2023-09-20 18:31:07 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:31:07 --> Model "Home_model" initialized
INFO - 2023-09-20 18:31:07 --> Helper loaded: download_helper
INFO - 2023-09-20 18:31:07 --> Helper loaded: form_helper
INFO - 2023-09-20 18:31:07 --> Form Validation Class Initialized
INFO - 2023-09-20 18:31:07 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:31:07 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:31:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:31:07 --> Final output sent to browser
DEBUG - 2023-09-20 18:31:07 --> Total execution time: 0.0745
INFO - 2023-09-20 18:34:15 --> Config Class Initialized
INFO - 2023-09-20 18:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:34:15 --> Utf8 Class Initialized
INFO - 2023-09-20 18:34:15 --> URI Class Initialized
INFO - 2023-09-20 18:34:15 --> Router Class Initialized
INFO - 2023-09-20 18:34:15 --> Output Class Initialized
INFO - 2023-09-20 18:34:15 --> Security Class Initialized
DEBUG - 2023-09-20 18:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:34:15 --> Input Class Initialized
INFO - 2023-09-20 18:34:15 --> Language Class Initialized
INFO - 2023-09-20 18:34:15 --> Loader Class Initialized
INFO - 2023-09-20 18:34:15 --> Helper loaded: url_helper
INFO - 2023-09-20 18:34:15 --> Helper loaded: file_helper
INFO - 2023-09-20 18:34:15 --> Database Driver Class Initialized
INFO - 2023-09-20 18:34:15 --> Email Class Initialized
DEBUG - 2023-09-20 18:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:34:15 --> Controller Class Initialized
INFO - 2023-09-20 18:34:15 --> Model "Services_model" initialized
INFO - 2023-09-20 18:34:15 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:34:15 --> Helper loaded: form_helper
INFO - 2023-09-20 18:34:15 --> Form Validation Class Initialized
INFO - 2023-09-20 18:34:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 18:34:15 --> Final output sent to browser
DEBUG - 2023-09-20 18:34:15 --> Total execution time: 0.1797
INFO - 2023-09-20 18:34:16 --> Config Class Initialized
INFO - 2023-09-20 18:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:34:16 --> Utf8 Class Initialized
INFO - 2023-09-20 18:34:16 --> URI Class Initialized
INFO - 2023-09-20 18:34:16 --> Router Class Initialized
INFO - 2023-09-20 18:34:16 --> Output Class Initialized
INFO - 2023-09-20 18:34:16 --> Security Class Initialized
DEBUG - 2023-09-20 18:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:34:16 --> Input Class Initialized
INFO - 2023-09-20 18:34:16 --> Language Class Initialized
INFO - 2023-09-20 18:34:16 --> Loader Class Initialized
INFO - 2023-09-20 18:34:16 --> Helper loaded: url_helper
INFO - 2023-09-20 18:34:16 --> Helper loaded: file_helper
INFO - 2023-09-20 18:34:16 --> Database Driver Class Initialized
INFO - 2023-09-20 18:34:16 --> Email Class Initialized
DEBUG - 2023-09-20 18:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:34:16 --> Controller Class Initialized
INFO - 2023-09-20 18:34:16 --> Model "Services_model" initialized
INFO - 2023-09-20 18:34:16 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:34:16 --> Helper loaded: form_helper
INFO - 2023-09-20 18:34:16 --> Form Validation Class Initialized
INFO - 2023-09-20 18:34:16 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 18:34:16 --> Final output sent to browser
DEBUG - 2023-09-20 18:34:16 --> Total execution time: 0.0432
INFO - 2023-09-20 18:34:50 --> Config Class Initialized
INFO - 2023-09-20 18:34:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:34:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:34:50 --> Utf8 Class Initialized
INFO - 2023-09-20 18:34:50 --> URI Class Initialized
INFO - 2023-09-20 18:34:50 --> Router Class Initialized
INFO - 2023-09-20 18:34:50 --> Output Class Initialized
INFO - 2023-09-20 18:34:50 --> Security Class Initialized
DEBUG - 2023-09-20 18:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:34:50 --> Input Class Initialized
INFO - 2023-09-20 18:34:50 --> Language Class Initialized
INFO - 2023-09-20 18:34:50 --> Loader Class Initialized
INFO - 2023-09-20 18:34:50 --> Helper loaded: url_helper
INFO - 2023-09-20 18:34:50 --> Helper loaded: file_helper
INFO - 2023-09-20 18:34:50 --> Database Driver Class Initialized
INFO - 2023-09-20 18:34:50 --> Email Class Initialized
DEBUG - 2023-09-20 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:34:50 --> Controller Class Initialized
INFO - 2023-09-20 18:34:50 --> Model "Services_model" initialized
INFO - 2023-09-20 18:34:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:34:50 --> Helper loaded: form_helper
INFO - 2023-09-20 18:34:50 --> Form Validation Class Initialized
INFO - 2023-09-20 18:34:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:34:50 --> Config Class Initialized
INFO - 2023-09-20 18:34:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:34:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:34:50 --> Utf8 Class Initialized
INFO - 2023-09-20 18:34:50 --> URI Class Initialized
INFO - 2023-09-20 18:34:50 --> Router Class Initialized
INFO - 2023-09-20 18:34:50 --> Output Class Initialized
INFO - 2023-09-20 18:34:50 --> Security Class Initialized
DEBUG - 2023-09-20 18:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:34:50 --> Input Class Initialized
INFO - 2023-09-20 18:34:50 --> Language Class Initialized
INFO - 2023-09-20 18:34:50 --> Loader Class Initialized
INFO - 2023-09-20 18:34:50 --> Helper loaded: url_helper
INFO - 2023-09-20 18:34:50 --> Helper loaded: file_helper
INFO - 2023-09-20 18:34:50 --> Database Driver Class Initialized
INFO - 2023-09-20 18:34:50 --> Email Class Initialized
DEBUG - 2023-09-20 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:34:50 --> Controller Class Initialized
INFO - 2023-09-20 18:34:50 --> Model "Services_model" initialized
INFO - 2023-09-20 18:34:50 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 18:34:50 --> Helper loaded: form_helper
INFO - 2023-09-20 18:34:50 --> Form Validation Class Initialized
INFO - 2023-09-20 18:34:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 18:34:50 --> Final output sent to browser
DEBUG - 2023-09-20 18:34:50 --> Total execution time: 0.0989
INFO - 2023-09-20 18:34:54 --> Config Class Initialized
INFO - 2023-09-20 18:34:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:34:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:34:54 --> Utf8 Class Initialized
INFO - 2023-09-20 18:34:54 --> URI Class Initialized
INFO - 2023-09-20 18:34:54 --> Router Class Initialized
INFO - 2023-09-20 18:34:54 --> Output Class Initialized
INFO - 2023-09-20 18:34:54 --> Security Class Initialized
DEBUG - 2023-09-20 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:34:54 --> Input Class Initialized
INFO - 2023-09-20 18:34:54 --> Language Class Initialized
INFO - 2023-09-20 18:34:54 --> Loader Class Initialized
INFO - 2023-09-20 18:34:54 --> Helper loaded: url_helper
INFO - 2023-09-20 18:34:54 --> Helper loaded: file_helper
INFO - 2023-09-20 18:34:54 --> Database Driver Class Initialized
INFO - 2023-09-20 18:34:54 --> Email Class Initialized
DEBUG - 2023-09-20 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:34:54 --> Controller Class Initialized
INFO - 2023-09-20 18:34:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:34:54 --> Model "Home_model" initialized
INFO - 2023-09-20 18:34:54 --> Helper loaded: download_helper
INFO - 2023-09-20 18:34:54 --> Helper loaded: form_helper
INFO - 2023-09-20 18:34:54 --> Form Validation Class Initialized
INFO - 2023-09-20 18:34:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:34:54 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:34:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:34:54 --> Final output sent to browser
DEBUG - 2023-09-20 18:34:54 --> Total execution time: 0.0595
INFO - 2023-09-20 18:35:38 --> Config Class Initialized
INFO - 2023-09-20 18:35:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:35:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:35:38 --> Utf8 Class Initialized
INFO - 2023-09-20 18:35:38 --> URI Class Initialized
INFO - 2023-09-20 18:35:38 --> Router Class Initialized
INFO - 2023-09-20 18:35:38 --> Output Class Initialized
INFO - 2023-09-20 18:35:38 --> Security Class Initialized
DEBUG - 2023-09-20 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:35:38 --> Input Class Initialized
INFO - 2023-09-20 18:35:38 --> Language Class Initialized
INFO - 2023-09-20 18:35:38 --> Loader Class Initialized
INFO - 2023-09-20 18:35:38 --> Helper loaded: url_helper
INFO - 2023-09-20 18:35:38 --> Helper loaded: file_helper
INFO - 2023-09-20 18:35:38 --> Database Driver Class Initialized
INFO - 2023-09-20 18:35:38 --> Email Class Initialized
DEBUG - 2023-09-20 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:35:38 --> Controller Class Initialized
INFO - 2023-09-20 18:35:38 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:35:38 --> Model "Home_model" initialized
INFO - 2023-09-20 18:35:38 --> Helper loaded: download_helper
INFO - 2023-09-20 18:35:38 --> Helper loaded: form_helper
INFO - 2023-09-20 18:35:38 --> Form Validation Class Initialized
INFO - 2023-09-20 18:35:38 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:35:38 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:35:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-20 18:35:38 --> Final output sent to browser
DEBUG - 2023-09-20 18:35:38 --> Total execution time: 0.1333
INFO - 2023-09-20 18:35:43 --> Config Class Initialized
INFO - 2023-09-20 18:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:35:43 --> Utf8 Class Initialized
INFO - 2023-09-20 18:35:43 --> URI Class Initialized
INFO - 2023-09-20 18:35:43 --> Router Class Initialized
INFO - 2023-09-20 18:35:43 --> Output Class Initialized
INFO - 2023-09-20 18:35:43 --> Security Class Initialized
DEBUG - 2023-09-20 18:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:35:43 --> Input Class Initialized
INFO - 2023-09-20 18:35:43 --> Language Class Initialized
INFO - 2023-09-20 18:35:43 --> Loader Class Initialized
INFO - 2023-09-20 18:35:43 --> Helper loaded: url_helper
INFO - 2023-09-20 18:35:43 --> Helper loaded: file_helper
INFO - 2023-09-20 18:35:43 --> Database Driver Class Initialized
INFO - 2023-09-20 18:35:43 --> Email Class Initialized
DEBUG - 2023-09-20 18:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:35:43 --> Controller Class Initialized
INFO - 2023-09-20 18:35:43 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:35:43 --> Model "Home_model" initialized
INFO - 2023-09-20 18:35:43 --> Helper loaded: download_helper
INFO - 2023-09-20 18:35:43 --> Helper loaded: form_helper
INFO - 2023-09-20 18:35:43 --> Form Validation Class Initialized
INFO - 2023-09-20 18:35:43 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:35:43 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:35:43 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-20 18:35:43 --> Final output sent to browser
DEBUG - 2023-09-20 18:35:43 --> Total execution time: 0.1335
INFO - 2023-09-20 18:36:23 --> Config Class Initialized
INFO - 2023-09-20 18:36:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:24 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:24 --> URI Class Initialized
INFO - 2023-09-20 18:36:24 --> Router Class Initialized
INFO - 2023-09-20 18:36:24 --> Output Class Initialized
INFO - 2023-09-20 18:36:24 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:24 --> Input Class Initialized
INFO - 2023-09-20 18:36:24 --> Language Class Initialized
ERROR - 2023-09-20 18:36:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:24 --> Config Class Initialized
INFO - 2023-09-20 18:36:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:24 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:24 --> URI Class Initialized
INFO - 2023-09-20 18:36:24 --> Router Class Initialized
INFO - 2023-09-20 18:36:24 --> Output Class Initialized
INFO - 2023-09-20 18:36:24 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:24 --> Input Class Initialized
INFO - 2023-09-20 18:36:24 --> Language Class Initialized
ERROR - 2023-09-20 18:36:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:24 --> Config Class Initialized
INFO - 2023-09-20 18:36:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:24 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:24 --> URI Class Initialized
INFO - 2023-09-20 18:36:24 --> Router Class Initialized
INFO - 2023-09-20 18:36:24 --> Output Class Initialized
INFO - 2023-09-20 18:36:24 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:24 --> Input Class Initialized
INFO - 2023-09-20 18:36:24 --> Language Class Initialized
ERROR - 2023-09-20 18:36:24 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:24 --> Config Class Initialized
INFO - 2023-09-20 18:36:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:25 --> URI Class Initialized
INFO - 2023-09-20 18:36:25 --> Router Class Initialized
INFO - 2023-09-20 18:36:25 --> Output Class Initialized
INFO - 2023-09-20 18:36:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:25 --> Input Class Initialized
INFO - 2023-09-20 18:36:25 --> Language Class Initialized
ERROR - 2023-09-20 18:36:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:25 --> Config Class Initialized
INFO - 2023-09-20 18:36:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:25 --> URI Class Initialized
INFO - 2023-09-20 18:36:25 --> Router Class Initialized
INFO - 2023-09-20 18:36:25 --> Output Class Initialized
INFO - 2023-09-20 18:36:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:25 --> Input Class Initialized
INFO - 2023-09-20 18:36:25 --> Language Class Initialized
ERROR - 2023-09-20 18:36:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:25 --> Config Class Initialized
INFO - 2023-09-20 18:36:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:25 --> URI Class Initialized
INFO - 2023-09-20 18:36:25 --> Router Class Initialized
INFO - 2023-09-20 18:36:25 --> Output Class Initialized
INFO - 2023-09-20 18:36:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:25 --> Input Class Initialized
INFO - 2023-09-20 18:36:25 --> Language Class Initialized
ERROR - 2023-09-20 18:36:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:25 --> Config Class Initialized
INFO - 2023-09-20 18:36:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:25 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:25 --> URI Class Initialized
INFO - 2023-09-20 18:36:25 --> Router Class Initialized
INFO - 2023-09-20 18:36:25 --> Output Class Initialized
INFO - 2023-09-20 18:36:25 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:25 --> Input Class Initialized
INFO - 2023-09-20 18:36:25 --> Language Class Initialized
ERROR - 2023-09-20 18:36:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 18:36:46 --> Config Class Initialized
INFO - 2023-09-20 18:36:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:46 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:46 --> URI Class Initialized
INFO - 2023-09-20 18:36:46 --> Router Class Initialized
INFO - 2023-09-20 18:36:46 --> Output Class Initialized
INFO - 2023-09-20 18:36:46 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:46 --> Input Class Initialized
INFO - 2023-09-20 18:36:46 --> Language Class Initialized
INFO - 2023-09-20 18:36:46 --> Loader Class Initialized
INFO - 2023-09-20 18:36:46 --> Helper loaded: url_helper
INFO - 2023-09-20 18:36:46 --> Helper loaded: file_helper
INFO - 2023-09-20 18:36:46 --> Database Driver Class Initialized
INFO - 2023-09-20 18:36:46 --> Email Class Initialized
DEBUG - 2023-09-20 18:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:36:46 --> Controller Class Initialized
INFO - 2023-09-20 18:36:46 --> Model "Blog_model" initialized
INFO - 2023-09-20 18:36:46 --> Helper loaded: form_helper
INFO - 2023-09-20 18:36:46 --> Form Validation Class Initialized
INFO - 2023-09-20 18:36:46 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-20 18:36:46 --> Final output sent to browser
DEBUG - 2023-09-20 18:36:46 --> Total execution time: 0.1956
INFO - 2023-09-20 18:36:49 --> Config Class Initialized
INFO - 2023-09-20 18:36:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:49 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:49 --> URI Class Initialized
INFO - 2023-09-20 18:36:49 --> Router Class Initialized
INFO - 2023-09-20 18:36:49 --> Output Class Initialized
INFO - 2023-09-20 18:36:49 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:49 --> Input Class Initialized
INFO - 2023-09-20 18:36:49 --> Language Class Initialized
INFO - 2023-09-20 18:36:49 --> Loader Class Initialized
INFO - 2023-09-20 18:36:49 --> Helper loaded: url_helper
INFO - 2023-09-20 18:36:49 --> Helper loaded: file_helper
INFO - 2023-09-20 18:36:49 --> Database Driver Class Initialized
INFO - 2023-09-20 18:36:49 --> Email Class Initialized
DEBUG - 2023-09-20 18:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:36:49 --> Controller Class Initialized
INFO - 2023-09-20 18:36:49 --> Model "Blog_model" initialized
INFO - 2023-09-20 18:36:49 --> Helper loaded: form_helper
INFO - 2023-09-20 18:36:49 --> Form Validation Class Initialized
INFO - 2023-09-20 18:36:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-20 18:36:49 --> Final output sent to browser
DEBUG - 2023-09-20 18:36:49 --> Total execution time: 0.1502
INFO - 2023-09-20 18:36:50 --> Config Class Initialized
INFO - 2023-09-20 18:36:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:36:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:36:50 --> Utf8 Class Initialized
INFO - 2023-09-20 18:36:50 --> URI Class Initialized
INFO - 2023-09-20 18:36:50 --> Router Class Initialized
INFO - 2023-09-20 18:36:50 --> Output Class Initialized
INFO - 2023-09-20 18:36:50 --> Security Class Initialized
DEBUG - 2023-09-20 18:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:36:50 --> Input Class Initialized
INFO - 2023-09-20 18:36:50 --> Language Class Initialized
INFO - 2023-09-20 18:36:50 --> Loader Class Initialized
INFO - 2023-09-20 18:36:50 --> Helper loaded: url_helper
INFO - 2023-09-20 18:36:50 --> Helper loaded: file_helper
INFO - 2023-09-20 18:36:50 --> Database Driver Class Initialized
INFO - 2023-09-20 18:36:50 --> Email Class Initialized
DEBUG - 2023-09-20 18:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:36:50 --> Controller Class Initialized
INFO - 2023-09-20 18:36:50 --> Model "Blog_model" initialized
INFO - 2023-09-20 18:36:50 --> Helper loaded: form_helper
INFO - 2023-09-20 18:36:50 --> Form Validation Class Initialized
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 40
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 49
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 58
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 59
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 60
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 72
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 86
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 97
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 109
ERROR - 2023-09-20 18:36:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\blog_edit.php 118
INFO - 2023-09-20 18:36:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-20 18:36:50 --> Final output sent to browser
DEBUG - 2023-09-20 18:36:50 --> Total execution time: 0.0521
INFO - 2023-09-20 18:37:10 --> Config Class Initialized
INFO - 2023-09-20 18:37:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:37:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:37:10 --> Utf8 Class Initialized
INFO - 2023-09-20 18:37:10 --> URI Class Initialized
INFO - 2023-09-20 18:37:10 --> Router Class Initialized
INFO - 2023-09-20 18:37:10 --> Output Class Initialized
INFO - 2023-09-20 18:37:10 --> Security Class Initialized
DEBUG - 2023-09-20 18:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:37:10 --> Input Class Initialized
INFO - 2023-09-20 18:37:10 --> Language Class Initialized
INFO - 2023-09-20 18:37:10 --> Loader Class Initialized
INFO - 2023-09-20 18:37:10 --> Helper loaded: url_helper
INFO - 2023-09-20 18:37:10 --> Helper loaded: file_helper
INFO - 2023-09-20 18:37:10 --> Database Driver Class Initialized
INFO - 2023-09-20 18:37:10 --> Email Class Initialized
DEBUG - 2023-09-20 18:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:37:10 --> Controller Class Initialized
INFO - 2023-09-20 18:37:10 --> Model "Blog_model" initialized
INFO - 2023-09-20 18:37:10 --> Helper loaded: form_helper
INFO - 2023-09-20 18:37:10 --> Form Validation Class Initialized
INFO - 2023-09-20 18:37:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:37:10 --> Config Class Initialized
INFO - 2023-09-20 18:37:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:37:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:37:10 --> Utf8 Class Initialized
INFO - 2023-09-20 18:37:10 --> URI Class Initialized
INFO - 2023-09-20 18:37:10 --> Router Class Initialized
INFO - 2023-09-20 18:37:10 --> Output Class Initialized
INFO - 2023-09-20 18:37:10 --> Security Class Initialized
DEBUG - 2023-09-20 18:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:37:10 --> Input Class Initialized
INFO - 2023-09-20 18:37:10 --> Language Class Initialized
INFO - 2023-09-20 18:37:10 --> Loader Class Initialized
INFO - 2023-09-20 18:37:10 --> Helper loaded: url_helper
INFO - 2023-09-20 18:37:10 --> Helper loaded: file_helper
INFO - 2023-09-20 18:37:10 --> Database Driver Class Initialized
INFO - 2023-09-20 18:37:10 --> Email Class Initialized
DEBUG - 2023-09-20 18:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:37:10 --> Controller Class Initialized
INFO - 2023-09-20 18:37:10 --> Model "Blog_model" initialized
INFO - 2023-09-20 18:37:10 --> Helper loaded: form_helper
INFO - 2023-09-20 18:37:10 --> Form Validation Class Initialized
INFO - 2023-09-20 18:37:10 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-20 18:37:10 --> Final output sent to browser
DEBUG - 2023-09-20 18:37:10 --> Total execution time: 0.0546
INFO - 2023-09-20 18:37:14 --> Config Class Initialized
INFO - 2023-09-20 18:37:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:37:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:37:14 --> Utf8 Class Initialized
INFO - 2023-09-20 18:37:14 --> URI Class Initialized
INFO - 2023-09-20 18:37:14 --> Router Class Initialized
INFO - 2023-09-20 18:37:14 --> Output Class Initialized
INFO - 2023-09-20 18:37:14 --> Security Class Initialized
DEBUG - 2023-09-20 18:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:37:14 --> Input Class Initialized
INFO - 2023-09-20 18:37:14 --> Language Class Initialized
INFO - 2023-09-20 18:37:14 --> Loader Class Initialized
INFO - 2023-09-20 18:37:14 --> Helper loaded: url_helper
INFO - 2023-09-20 18:37:14 --> Helper loaded: file_helper
INFO - 2023-09-20 18:37:14 --> Database Driver Class Initialized
INFO - 2023-09-20 18:37:14 --> Email Class Initialized
DEBUG - 2023-09-20 18:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:37:14 --> Controller Class Initialized
INFO - 2023-09-20 18:37:14 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:37:14 --> Model "Home_model" initialized
INFO - 2023-09-20 18:37:14 --> Helper loaded: download_helper
INFO - 2023-09-20 18:37:14 --> Helper loaded: form_helper
INFO - 2023-09-20 18:37:14 --> Form Validation Class Initialized
INFO - 2023-09-20 18:37:14 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:37:14 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:37:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-20 18:37:14 --> Final output sent to browser
DEBUG - 2023-09-20 18:37:14 --> Total execution time: 0.0648
INFO - 2023-09-20 18:38:44 --> Config Class Initialized
INFO - 2023-09-20 18:38:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:38:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:38:44 --> Utf8 Class Initialized
INFO - 2023-09-20 18:38:44 --> URI Class Initialized
INFO - 2023-09-20 18:38:44 --> Router Class Initialized
INFO - 2023-09-20 18:38:44 --> Output Class Initialized
INFO - 2023-09-20 18:38:44 --> Security Class Initialized
DEBUG - 2023-09-20 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:38:44 --> Input Class Initialized
INFO - 2023-09-20 18:38:44 --> Language Class Initialized
INFO - 2023-09-20 18:38:44 --> Loader Class Initialized
INFO - 2023-09-20 18:38:44 --> Helper loaded: url_helper
INFO - 2023-09-20 18:38:44 --> Helper loaded: file_helper
INFO - 2023-09-20 18:38:44 --> Database Driver Class Initialized
INFO - 2023-09-20 18:38:44 --> Email Class Initialized
DEBUG - 2023-09-20 18:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:38:44 --> Controller Class Initialized
INFO - 2023-09-20 18:38:44 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:38:44 --> Model "Home_model" initialized
INFO - 2023-09-20 18:38:44 --> Helper loaded: download_helper
INFO - 2023-09-20 18:38:44 --> Helper loaded: form_helper
INFO - 2023-09-20 18:38:44 --> Form Validation Class Initialized
INFO - 2023-09-20 18:38:44 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:38:44 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:38:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 18:38:44 --> Final output sent to browser
DEBUG - 2023-09-20 18:38:44 --> Total execution time: 0.1150
INFO - 2023-09-20 18:39:26 --> Config Class Initialized
INFO - 2023-09-20 18:39:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:39:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:39:26 --> Utf8 Class Initialized
INFO - 2023-09-20 18:39:26 --> URI Class Initialized
DEBUG - 2023-09-20 18:39:26 --> No URI present. Default controller set.
INFO - 2023-09-20 18:39:26 --> Router Class Initialized
INFO - 2023-09-20 18:39:26 --> Output Class Initialized
INFO - 2023-09-20 18:39:26 --> Security Class Initialized
DEBUG - 2023-09-20 18:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:39:26 --> Input Class Initialized
INFO - 2023-09-20 18:39:26 --> Language Class Initialized
INFO - 2023-09-20 18:39:26 --> Loader Class Initialized
INFO - 2023-09-20 18:39:26 --> Helper loaded: url_helper
INFO - 2023-09-20 18:39:26 --> Helper loaded: file_helper
INFO - 2023-09-20 18:39:26 --> Database Driver Class Initialized
INFO - 2023-09-20 18:39:26 --> Email Class Initialized
DEBUG - 2023-09-20 18:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:39:26 --> Controller Class Initialized
INFO - 2023-09-20 18:39:26 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:39:26 --> Model "Home_model" initialized
INFO - 2023-09-20 18:39:26 --> Helper loaded: download_helper
INFO - 2023-09-20 18:39:26 --> Helper loaded: form_helper
INFO - 2023-09-20 18:39:26 --> Form Validation Class Initialized
INFO - 2023-09-20 18:39:26 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:39:26 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 18:39:26 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 18:39:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 18:39:26 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 18:39:27 --> Final output sent to browser
DEBUG - 2023-09-20 18:39:27 --> Total execution time: 0.1599
INFO - 2023-09-20 18:41:02 --> Config Class Initialized
INFO - 2023-09-20 18:41:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:41:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:41:02 --> Utf8 Class Initialized
INFO - 2023-09-20 18:41:02 --> URI Class Initialized
INFO - 2023-09-20 18:41:02 --> Router Class Initialized
INFO - 2023-09-20 18:41:02 --> Output Class Initialized
INFO - 2023-09-20 18:41:02 --> Security Class Initialized
DEBUG - 2023-09-20 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:41:02 --> Input Class Initialized
INFO - 2023-09-20 18:41:02 --> Language Class Initialized
INFO - 2023-09-20 18:41:02 --> Loader Class Initialized
INFO - 2023-09-20 18:41:02 --> Helper loaded: url_helper
INFO - 2023-09-20 18:41:02 --> Helper loaded: file_helper
INFO - 2023-09-20 18:41:02 --> Database Driver Class Initialized
INFO - 2023-09-20 18:41:02 --> Email Class Initialized
DEBUG - 2023-09-20 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:41:02 --> Controller Class Initialized
INFO - 2023-09-20 18:41:02 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:41:02 --> Model "Home_model" initialized
INFO - 2023-09-20 18:41:02 --> Helper loaded: download_helper
INFO - 2023-09-20 18:41:02 --> Helper loaded: form_helper
INFO - 2023-09-20 18:41:02 --> Form Validation Class Initialized
INFO - 2023-09-20 18:41:02 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:41:02 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:41:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 18:41:02 --> Final output sent to browser
DEBUG - 2023-09-20 18:41:02 --> Total execution time: 0.1530
INFO - 2023-09-20 18:50:17 --> Config Class Initialized
INFO - 2023-09-20 18:50:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:50:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:50:17 --> Utf8 Class Initialized
INFO - 2023-09-20 18:50:17 --> URI Class Initialized
INFO - 2023-09-20 18:50:17 --> Router Class Initialized
INFO - 2023-09-20 18:50:17 --> Output Class Initialized
INFO - 2023-09-20 18:50:17 --> Security Class Initialized
DEBUG - 2023-09-20 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:50:17 --> Input Class Initialized
INFO - 2023-09-20 18:50:17 --> Language Class Initialized
INFO - 2023-09-20 18:50:17 --> Loader Class Initialized
INFO - 2023-09-20 18:50:17 --> Helper loaded: url_helper
INFO - 2023-09-20 18:50:17 --> Helper loaded: file_helper
INFO - 2023-09-20 18:50:17 --> Database Driver Class Initialized
INFO - 2023-09-20 18:50:17 --> Email Class Initialized
DEBUG - 2023-09-20 18:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:50:17 --> Controller Class Initialized
INFO - 2023-09-20 18:50:17 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:50:17 --> Model "Home_model" initialized
INFO - 2023-09-20 18:50:17 --> Helper loaded: download_helper
INFO - 2023-09-20 18:50:17 --> Helper loaded: form_helper
INFO - 2023-09-20 18:50:17 --> Form Validation Class Initialized
INFO - 2023-09-20 18:50:17 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:50:17 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:50:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:50:17 --> Final output sent to browser
DEBUG - 2023-09-20 18:50:17 --> Total execution time: 0.1123
INFO - 2023-09-20 18:51:12 --> Config Class Initialized
INFO - 2023-09-20 18:51:12 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:51:12 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:51:12 --> Utf8 Class Initialized
INFO - 2023-09-20 18:51:12 --> URI Class Initialized
INFO - 2023-09-20 18:51:12 --> Router Class Initialized
INFO - 2023-09-20 18:51:12 --> Output Class Initialized
INFO - 2023-09-20 18:51:12 --> Security Class Initialized
DEBUG - 2023-09-20 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:51:12 --> Input Class Initialized
INFO - 2023-09-20 18:51:12 --> Language Class Initialized
INFO - 2023-09-20 18:51:12 --> Loader Class Initialized
INFO - 2023-09-20 18:51:12 --> Helper loaded: url_helper
INFO - 2023-09-20 18:51:12 --> Helper loaded: file_helper
INFO - 2023-09-20 18:51:12 --> Database Driver Class Initialized
INFO - 2023-09-20 18:51:12 --> Email Class Initialized
DEBUG - 2023-09-20 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:51:12 --> Controller Class Initialized
INFO - 2023-09-20 18:51:12 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:51:12 --> Model "Home_model" initialized
INFO - 2023-09-20 18:51:12 --> Helper loaded: download_helper
INFO - 2023-09-20 18:51:12 --> Helper loaded: form_helper
INFO - 2023-09-20 18:51:12 --> Form Validation Class Initialized
INFO - 2023-09-20 18:51:12 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:51:12 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:51:12 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:51:12 --> Final output sent to browser
DEBUG - 2023-09-20 18:51:12 --> Total execution time: 0.0714
INFO - 2023-09-20 18:52:07 --> Config Class Initialized
INFO - 2023-09-20 18:52:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:52:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:52:07 --> Utf8 Class Initialized
INFO - 2023-09-20 18:52:07 --> URI Class Initialized
DEBUG - 2023-09-20 18:52:07 --> No URI present. Default controller set.
INFO - 2023-09-20 18:52:07 --> Router Class Initialized
INFO - 2023-09-20 18:52:07 --> Output Class Initialized
INFO - 2023-09-20 18:52:07 --> Security Class Initialized
DEBUG - 2023-09-20 18:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:52:07 --> Input Class Initialized
INFO - 2023-09-20 18:52:07 --> Language Class Initialized
INFO - 2023-09-20 18:52:07 --> Loader Class Initialized
INFO - 2023-09-20 18:52:07 --> Helper loaded: url_helper
INFO - 2023-09-20 18:52:07 --> Helper loaded: file_helper
INFO - 2023-09-20 18:52:07 --> Database Driver Class Initialized
INFO - 2023-09-20 18:52:07 --> Email Class Initialized
DEBUG - 2023-09-20 18:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:52:07 --> Controller Class Initialized
INFO - 2023-09-20 18:52:07 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:52:07 --> Model "Home_model" initialized
INFO - 2023-09-20 18:52:07 --> Helper loaded: download_helper
INFO - 2023-09-20 18:52:07 --> Helper loaded: form_helper
INFO - 2023-09-20 18:52:07 --> Form Validation Class Initialized
INFO - 2023-09-20 18:52:07 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:52:07 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 18:52:07 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 18:52:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 18:52:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 18:52:07 --> Final output sent to browser
DEBUG - 2023-09-20 18:52:07 --> Total execution time: 0.1989
INFO - 2023-09-20 18:52:42 --> Config Class Initialized
INFO - 2023-09-20 18:52:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:52:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:52:42 --> Utf8 Class Initialized
INFO - 2023-09-20 18:52:42 --> URI Class Initialized
INFO - 2023-09-20 18:52:42 --> Router Class Initialized
INFO - 2023-09-20 18:52:42 --> Output Class Initialized
INFO - 2023-09-20 18:52:42 --> Security Class Initialized
DEBUG - 2023-09-20 18:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:52:42 --> Input Class Initialized
INFO - 2023-09-20 18:52:42 --> Language Class Initialized
INFO - 2023-09-20 18:52:42 --> Loader Class Initialized
INFO - 2023-09-20 18:52:42 --> Helper loaded: url_helper
INFO - 2023-09-20 18:52:42 --> Helper loaded: file_helper
INFO - 2023-09-20 18:52:42 --> Database Driver Class Initialized
INFO - 2023-09-20 18:52:42 --> Email Class Initialized
DEBUG - 2023-09-20 18:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:52:42 --> Controller Class Initialized
INFO - 2023-09-20 18:52:42 --> Model "Services_model" initialized
INFO - 2023-09-20 18:52:42 --> Helper loaded: form_helper
INFO - 2023-09-20 18:52:42 --> Form Validation Class Initialized
INFO - 2023-09-20 18:52:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:52:42 --> Final output sent to browser
DEBUG - 2023-09-20 18:52:42 --> Total execution time: 0.1178
INFO - 2023-09-20 18:52:47 --> Config Class Initialized
INFO - 2023-09-20 18:52:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:52:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:52:47 --> Utf8 Class Initialized
INFO - 2023-09-20 18:52:47 --> URI Class Initialized
INFO - 2023-09-20 18:52:47 --> Router Class Initialized
INFO - 2023-09-20 18:52:47 --> Output Class Initialized
INFO - 2023-09-20 18:52:47 --> Security Class Initialized
DEBUG - 2023-09-20 18:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:52:47 --> Input Class Initialized
INFO - 2023-09-20 18:52:47 --> Language Class Initialized
INFO - 2023-09-20 18:52:47 --> Loader Class Initialized
INFO - 2023-09-20 18:52:47 --> Helper loaded: url_helper
INFO - 2023-09-20 18:52:47 --> Helper loaded: file_helper
INFO - 2023-09-20 18:52:47 --> Database Driver Class Initialized
INFO - 2023-09-20 18:52:47 --> Email Class Initialized
DEBUG - 2023-09-20 18:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:52:47 --> Controller Class Initialized
INFO - 2023-09-20 18:52:47 --> Model "Services_model" initialized
INFO - 2023-09-20 18:52:47 --> Helper loaded: form_helper
INFO - 2023-09-20 18:52:47 --> Form Validation Class Initialized
INFO - 2023-09-20 18:52:47 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 18:52:47 --> Final output sent to browser
DEBUG - 2023-09-20 18:52:47 --> Total execution time: 0.0569
INFO - 2023-09-20 18:52:48 --> Config Class Initialized
INFO - 2023-09-20 18:52:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:52:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:52:48 --> Utf8 Class Initialized
INFO - 2023-09-20 18:52:48 --> URI Class Initialized
INFO - 2023-09-20 18:52:48 --> Router Class Initialized
INFO - 2023-09-20 18:52:48 --> Output Class Initialized
INFO - 2023-09-20 18:52:48 --> Security Class Initialized
DEBUG - 2023-09-20 18:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:52:48 --> Input Class Initialized
INFO - 2023-09-20 18:52:48 --> Language Class Initialized
INFO - 2023-09-20 18:52:48 --> Loader Class Initialized
INFO - 2023-09-20 18:52:48 --> Helper loaded: url_helper
INFO - 2023-09-20 18:52:48 --> Helper loaded: file_helper
INFO - 2023-09-20 18:52:48 --> Database Driver Class Initialized
INFO - 2023-09-20 18:52:48 --> Email Class Initialized
DEBUG - 2023-09-20 18:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:52:48 --> Controller Class Initialized
INFO - 2023-09-20 18:52:48 --> Model "Services_model" initialized
INFO - 2023-09-20 18:52:49 --> Helper loaded: form_helper
INFO - 2023-09-20 18:52:49 --> Form Validation Class Initialized
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 18:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 18:52:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 18:52:49 --> Final output sent to browser
DEBUG - 2023-09-20 18:52:49 --> Total execution time: 0.0827
INFO - 2023-09-20 18:53:01 --> Config Class Initialized
INFO - 2023-09-20 18:53:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:53:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:53:01 --> Utf8 Class Initialized
INFO - 2023-09-20 18:53:01 --> URI Class Initialized
INFO - 2023-09-20 18:53:01 --> Router Class Initialized
INFO - 2023-09-20 18:53:01 --> Output Class Initialized
INFO - 2023-09-20 18:53:01 --> Security Class Initialized
DEBUG - 2023-09-20 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:53:01 --> Input Class Initialized
INFO - 2023-09-20 18:53:01 --> Language Class Initialized
INFO - 2023-09-20 18:53:01 --> Loader Class Initialized
INFO - 2023-09-20 18:53:01 --> Helper loaded: url_helper
INFO - 2023-09-20 18:53:01 --> Helper loaded: file_helper
INFO - 2023-09-20 18:53:01 --> Database Driver Class Initialized
INFO - 2023-09-20 18:53:01 --> Email Class Initialized
DEBUG - 2023-09-20 18:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:53:01 --> Controller Class Initialized
INFO - 2023-09-20 18:53:01 --> Model "Services_model" initialized
INFO - 2023-09-20 18:53:01 --> Helper loaded: form_helper
INFO - 2023-09-20 18:53:01 --> Form Validation Class Initialized
INFO - 2023-09-20 18:53:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 18:53:01 --> Config Class Initialized
INFO - 2023-09-20 18:53:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:53:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:53:01 --> Utf8 Class Initialized
INFO - 2023-09-20 18:53:01 --> URI Class Initialized
INFO - 2023-09-20 18:53:01 --> Router Class Initialized
INFO - 2023-09-20 18:53:01 --> Output Class Initialized
INFO - 2023-09-20 18:53:01 --> Security Class Initialized
DEBUG - 2023-09-20 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:53:01 --> Input Class Initialized
INFO - 2023-09-20 18:53:01 --> Language Class Initialized
INFO - 2023-09-20 18:53:01 --> Loader Class Initialized
INFO - 2023-09-20 18:53:01 --> Helper loaded: url_helper
INFO - 2023-09-20 18:53:01 --> Helper loaded: file_helper
INFO - 2023-09-20 18:53:01 --> Database Driver Class Initialized
INFO - 2023-09-20 18:53:01 --> Email Class Initialized
DEBUG - 2023-09-20 18:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:53:01 --> Controller Class Initialized
INFO - 2023-09-20 18:53:01 --> Model "Services_model" initialized
INFO - 2023-09-20 18:53:01 --> Helper loaded: form_helper
INFO - 2023-09-20 18:53:01 --> Form Validation Class Initialized
INFO - 2023-09-20 18:53:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 18:53:01 --> Final output sent to browser
DEBUG - 2023-09-20 18:53:01 --> Total execution time: 0.0815
INFO - 2023-09-20 18:53:18 --> Config Class Initialized
INFO - 2023-09-20 18:53:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:53:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:53:18 --> Utf8 Class Initialized
INFO - 2023-09-20 18:53:18 --> URI Class Initialized
DEBUG - 2023-09-20 18:53:18 --> No URI present. Default controller set.
INFO - 2023-09-20 18:53:18 --> Router Class Initialized
INFO - 2023-09-20 18:53:18 --> Output Class Initialized
INFO - 2023-09-20 18:53:18 --> Security Class Initialized
DEBUG - 2023-09-20 18:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:53:18 --> Input Class Initialized
INFO - 2023-09-20 18:53:18 --> Language Class Initialized
INFO - 2023-09-20 18:53:18 --> Loader Class Initialized
INFO - 2023-09-20 18:53:18 --> Helper loaded: url_helper
INFO - 2023-09-20 18:53:18 --> Helper loaded: file_helper
INFO - 2023-09-20 18:53:18 --> Database Driver Class Initialized
INFO - 2023-09-20 18:53:18 --> Email Class Initialized
DEBUG - 2023-09-20 18:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:53:18 --> Controller Class Initialized
INFO - 2023-09-20 18:53:18 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:53:18 --> Model "Home_model" initialized
INFO - 2023-09-20 18:53:18 --> Helper loaded: download_helper
INFO - 2023-09-20 18:53:18 --> Helper loaded: form_helper
INFO - 2023-09-20 18:53:18 --> Form Validation Class Initialized
INFO - 2023-09-20 18:53:18 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:53:18 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 18:53:18 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 18:53:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 18:53:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 18:53:18 --> Final output sent to browser
DEBUG - 2023-09-20 18:53:18 --> Total execution time: 0.1274
INFO - 2023-09-20 18:55:36 --> Config Class Initialized
INFO - 2023-09-20 18:55:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:55:36 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:55:36 --> Utf8 Class Initialized
INFO - 2023-09-20 18:55:36 --> URI Class Initialized
INFO - 2023-09-20 18:55:36 --> Router Class Initialized
INFO - 2023-09-20 18:55:36 --> Output Class Initialized
INFO - 2023-09-20 18:55:36 --> Security Class Initialized
DEBUG - 2023-09-20 18:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:55:36 --> Input Class Initialized
INFO - 2023-09-20 18:55:36 --> Language Class Initialized
INFO - 2023-09-20 18:55:36 --> Loader Class Initialized
INFO - 2023-09-20 18:55:36 --> Helper loaded: url_helper
INFO - 2023-09-20 18:55:36 --> Helper loaded: file_helper
INFO - 2023-09-20 18:55:36 --> Database Driver Class Initialized
INFO - 2023-09-20 18:55:36 --> Email Class Initialized
DEBUG - 2023-09-20 18:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 18:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 18:55:36 --> Controller Class Initialized
INFO - 2023-09-20 18:55:36 --> Model "Contact_model" initialized
INFO - 2023-09-20 18:55:36 --> Model "Home_model" initialized
INFO - 2023-09-20 18:55:36 --> Helper loaded: download_helper
INFO - 2023-09-20 18:55:36 --> Helper loaded: form_helper
INFO - 2023-09-20 18:55:36 --> Form Validation Class Initialized
INFO - 2023-09-20 18:55:36 --> Helper loaded: custom_helper
INFO - 2023-09-20 18:55:36 --> Model "Social_media_model" initialized
INFO - 2023-09-20 18:55:36 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 18:55:36 --> Final output sent to browser
DEBUG - 2023-09-20 18:55:37 --> Total execution time: 0.1199
INFO - 2023-09-20 18:55:37 --> Config Class Initialized
INFO - 2023-09-20 18:55:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 18:55:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 18:55:37 --> Utf8 Class Initialized
INFO - 2023-09-20 18:55:37 --> URI Class Initialized
INFO - 2023-09-20 18:55:37 --> Router Class Initialized
INFO - 2023-09-20 18:55:37 --> Output Class Initialized
INFO - 2023-09-20 18:55:37 --> Security Class Initialized
DEBUG - 2023-09-20 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 18:55:38 --> Input Class Initialized
INFO - 2023-09-20 18:55:38 --> Language Class Initialized
ERROR - 2023-09-20 18:55:38 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 19:04:37 --> Config Class Initialized
INFO - 2023-09-20 19:04:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:04:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:04:37 --> Utf8 Class Initialized
INFO - 2023-09-20 19:04:37 --> URI Class Initialized
DEBUG - 2023-09-20 19:04:37 --> No URI present. Default controller set.
INFO - 2023-09-20 19:04:37 --> Router Class Initialized
INFO - 2023-09-20 19:04:37 --> Output Class Initialized
INFO - 2023-09-20 19:04:37 --> Security Class Initialized
DEBUG - 2023-09-20 19:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:04:37 --> Input Class Initialized
INFO - 2023-09-20 19:04:37 --> Language Class Initialized
INFO - 2023-09-20 19:04:37 --> Loader Class Initialized
INFO - 2023-09-20 19:04:37 --> Helper loaded: url_helper
INFO - 2023-09-20 19:04:37 --> Helper loaded: file_helper
INFO - 2023-09-20 19:04:37 --> Database Driver Class Initialized
INFO - 2023-09-20 19:04:38 --> Email Class Initialized
DEBUG - 2023-09-20 19:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:04:38 --> Controller Class Initialized
INFO - 2023-09-20 19:04:38 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:04:38 --> Model "Home_model" initialized
INFO - 2023-09-20 19:04:38 --> Helper loaded: download_helper
INFO - 2023-09-20 19:04:38 --> Helper loaded: form_helper
INFO - 2023-09-20 19:04:38 --> Form Validation Class Initialized
INFO - 2023-09-20 19:04:38 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:04:38 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:04:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:04:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:04:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:04:38 --> Final output sent to browser
DEBUG - 2023-09-20 19:04:38 --> Total execution time: 0.1493
INFO - 2023-09-20 19:05:10 --> Config Class Initialized
INFO - 2023-09-20 19:05:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:05:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:05:10 --> Utf8 Class Initialized
INFO - 2023-09-20 19:05:10 --> URI Class Initialized
INFO - 2023-09-20 19:05:10 --> Router Class Initialized
INFO - 2023-09-20 19:05:10 --> Output Class Initialized
INFO - 2023-09-20 19:05:10 --> Security Class Initialized
DEBUG - 2023-09-20 19:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:05:10 --> Input Class Initialized
INFO - 2023-09-20 19:05:10 --> Language Class Initialized
INFO - 2023-09-20 19:05:10 --> Loader Class Initialized
INFO - 2023-09-20 19:05:10 --> Helper loaded: url_helper
INFO - 2023-09-20 19:05:10 --> Helper loaded: file_helper
INFO - 2023-09-20 19:05:10 --> Database Driver Class Initialized
INFO - 2023-09-20 19:05:10 --> Email Class Initialized
DEBUG - 2023-09-20 19:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:05:10 --> Controller Class Initialized
INFO - 2023-09-20 19:05:10 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:05:10 --> Model "Home_model" initialized
INFO - 2023-09-20 19:05:10 --> Helper loaded: download_helper
INFO - 2023-09-20 19:05:10 --> Helper loaded: form_helper
INFO - 2023-09-20 19:05:10 --> Form Validation Class Initialized
INFO - 2023-09-20 19:05:10 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:05:10 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:05:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:05:10 --> Final output sent to browser
DEBUG - 2023-09-20 19:05:10 --> Total execution time: 0.1147
INFO - 2023-09-20 19:06:07 --> Config Class Initialized
INFO - 2023-09-20 19:06:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:06:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:06:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:06:07 --> URI Class Initialized
DEBUG - 2023-09-20 19:06:07 --> No URI present. Default controller set.
INFO - 2023-09-20 19:06:07 --> Router Class Initialized
INFO - 2023-09-20 19:06:07 --> Output Class Initialized
INFO - 2023-09-20 19:06:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:06:08 --> Input Class Initialized
INFO - 2023-09-20 19:06:08 --> Language Class Initialized
INFO - 2023-09-20 19:06:08 --> Loader Class Initialized
INFO - 2023-09-20 19:06:08 --> Helper loaded: url_helper
INFO - 2023-09-20 19:06:08 --> Helper loaded: file_helper
INFO - 2023-09-20 19:06:08 --> Database Driver Class Initialized
INFO - 2023-09-20 19:06:08 --> Email Class Initialized
DEBUG - 2023-09-20 19:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:06:08 --> Controller Class Initialized
INFO - 2023-09-20 19:06:08 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:06:08 --> Model "Home_model" initialized
INFO - 2023-09-20 19:06:08 --> Helper loaded: download_helper
INFO - 2023-09-20 19:06:08 --> Helper loaded: form_helper
INFO - 2023-09-20 19:06:08 --> Form Validation Class Initialized
INFO - 2023-09-20 19:06:08 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:06:08 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:06:08 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:06:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:06:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:06:08 --> Final output sent to browser
DEBUG - 2023-09-20 19:06:08 --> Total execution time: 0.1980
INFO - 2023-09-20 19:07:35 --> Config Class Initialized
INFO - 2023-09-20 19:07:35 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:07:35 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:07:35 --> Utf8 Class Initialized
INFO - 2023-09-20 19:07:35 --> URI Class Initialized
INFO - 2023-09-20 19:07:35 --> Router Class Initialized
INFO - 2023-09-20 19:07:35 --> Output Class Initialized
INFO - 2023-09-20 19:07:35 --> Security Class Initialized
DEBUG - 2023-09-20 19:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:07:35 --> Input Class Initialized
INFO - 2023-09-20 19:07:35 --> Language Class Initialized
INFO - 2023-09-20 19:07:35 --> Loader Class Initialized
INFO - 2023-09-20 19:07:35 --> Helper loaded: url_helper
INFO - 2023-09-20 19:07:35 --> Helper loaded: file_helper
INFO - 2023-09-20 19:07:35 --> Database Driver Class Initialized
INFO - 2023-09-20 19:07:35 --> Email Class Initialized
DEBUG - 2023-09-20 19:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:07:35 --> Controller Class Initialized
INFO - 2023-09-20 19:07:35 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:07:35 --> Model "Home_model" initialized
INFO - 2023-09-20 19:07:35 --> Helper loaded: download_helper
INFO - 2023-09-20 19:07:35 --> Helper loaded: form_helper
INFO - 2023-09-20 19:07:35 --> Form Validation Class Initialized
INFO - 2023-09-20 19:07:35 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:07:35 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:07:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:07:35 --> Final output sent to browser
DEBUG - 2023-09-20 19:07:35 --> Total execution time: 0.2520
INFO - 2023-09-20 19:08:31 --> Config Class Initialized
INFO - 2023-09-20 19:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:08:31 --> Utf8 Class Initialized
INFO - 2023-09-20 19:08:31 --> URI Class Initialized
INFO - 2023-09-20 19:08:31 --> Router Class Initialized
INFO - 2023-09-20 19:08:31 --> Output Class Initialized
INFO - 2023-09-20 19:08:31 --> Security Class Initialized
DEBUG - 2023-09-20 19:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:08:31 --> Input Class Initialized
INFO - 2023-09-20 19:08:31 --> Language Class Initialized
INFO - 2023-09-20 19:08:31 --> Loader Class Initialized
INFO - 2023-09-20 19:08:31 --> Helper loaded: url_helper
INFO - 2023-09-20 19:08:31 --> Helper loaded: file_helper
INFO - 2023-09-20 19:08:31 --> Database Driver Class Initialized
INFO - 2023-09-20 19:08:31 --> Email Class Initialized
DEBUG - 2023-09-20 19:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:08:31 --> Controller Class Initialized
INFO - 2023-09-20 19:08:31 --> Model "Services_model" initialized
INFO - 2023-09-20 19:08:31 --> Helper loaded: form_helper
INFO - 2023-09-20 19:08:31 --> Form Validation Class Initialized
INFO - 2023-09-20 19:08:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:08:31 --> Final output sent to browser
DEBUG - 2023-09-20 19:08:31 --> Total execution time: 0.0919
INFO - 2023-09-20 19:08:44 --> Config Class Initialized
INFO - 2023-09-20 19:08:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:08:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:08:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:08:44 --> URI Class Initialized
INFO - 2023-09-20 19:08:44 --> Router Class Initialized
INFO - 2023-09-20 19:08:44 --> Output Class Initialized
INFO - 2023-09-20 19:08:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:08:44 --> Input Class Initialized
INFO - 2023-09-20 19:08:44 --> Language Class Initialized
INFO - 2023-09-20 19:08:44 --> Loader Class Initialized
INFO - 2023-09-20 19:08:44 --> Helper loaded: url_helper
INFO - 2023-09-20 19:08:44 --> Helper loaded: file_helper
INFO - 2023-09-20 19:08:44 --> Database Driver Class Initialized
INFO - 2023-09-20 19:08:44 --> Email Class Initialized
DEBUG - 2023-09-20 19:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:08:44 --> Controller Class Initialized
INFO - 2023-09-20 19:08:44 --> Model "Services_model" initialized
INFO - 2023-09-20 19:08:44 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:08:44 --> Helper loaded: form_helper
INFO - 2023-09-20 19:08:44 --> Form Validation Class Initialized
INFO - 2023-09-20 19:08:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:08:44 --> Final output sent to browser
DEBUG - 2023-09-20 19:08:45 --> Total execution time: 0.1161
INFO - 2023-09-20 19:09:47 --> Config Class Initialized
INFO - 2023-09-20 19:09:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:09:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:09:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:09:47 --> URI Class Initialized
DEBUG - 2023-09-20 19:09:47 --> No URI present. Default controller set.
INFO - 2023-09-20 19:09:47 --> Router Class Initialized
INFO - 2023-09-20 19:09:47 --> Output Class Initialized
INFO - 2023-09-20 19:09:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:09:47 --> Input Class Initialized
INFO - 2023-09-20 19:09:47 --> Language Class Initialized
INFO - 2023-09-20 19:09:47 --> Loader Class Initialized
INFO - 2023-09-20 19:09:47 --> Helper loaded: url_helper
INFO - 2023-09-20 19:09:47 --> Helper loaded: file_helper
INFO - 2023-09-20 19:09:47 --> Database Driver Class Initialized
INFO - 2023-09-20 19:09:47 --> Email Class Initialized
DEBUG - 2023-09-20 19:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:09:47 --> Controller Class Initialized
INFO - 2023-09-20 19:09:47 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:09:47 --> Model "Home_model" initialized
INFO - 2023-09-20 19:09:47 --> Helper loaded: download_helper
INFO - 2023-09-20 19:09:47 --> Helper loaded: form_helper
INFO - 2023-09-20 19:09:47 --> Form Validation Class Initialized
INFO - 2023-09-20 19:09:47 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:09:47 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:09:47 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:09:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:09:47 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:09:47 --> Final output sent to browser
DEBUG - 2023-09-20 19:09:47 --> Total execution time: 0.1124
INFO - 2023-09-20 19:10:00 --> Config Class Initialized
INFO - 2023-09-20 19:10:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:10:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:00 --> URI Class Initialized
INFO - 2023-09-20 19:10:00 --> Router Class Initialized
INFO - 2023-09-20 19:10:00 --> Output Class Initialized
INFO - 2023-09-20 19:10:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:00 --> Input Class Initialized
INFO - 2023-09-20 19:10:00 --> Language Class Initialized
ERROR - 2023-09-20 19:10:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:10:01 --> Config Class Initialized
INFO - 2023-09-20 19:10:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:10:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:01 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:01 --> URI Class Initialized
INFO - 2023-09-20 19:10:01 --> Router Class Initialized
INFO - 2023-09-20 19:10:01 --> Output Class Initialized
INFO - 2023-09-20 19:10:01 --> Security Class Initialized
INFO - 2023-09-20 19:10:01 --> Config Class Initialized
INFO - 2023-09-20 19:10:02 --> Config Class Initialized
INFO - 2023-09-20 19:10:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:10:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:02 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:02 --> URI Class Initialized
INFO - 2023-09-20 19:10:02 --> Router Class Initialized
INFO - 2023-09-20 19:10:02 --> Hooks Class Initialized
INFO - 2023-09-20 19:10:02 --> Config Class Initialized
DEBUG - 2023-09-20 19:10:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:02 --> Output Class Initialized
INFO - 2023-09-20 19:10:02 --> Config Class Initialized
INFO - 2023-09-20 19:10:02 --> Config Class Initialized
DEBUG - 2023-09-20 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:02 --> Input Class Initialized
INFO - 2023-09-20 19:10:02 --> Hooks Class Initialized
INFO - 2023-09-20 19:10:02 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:02 --> URI Class Initialized
INFO - 2023-09-20 19:10:02 --> Router Class Initialized
INFO - 2023-09-20 19:10:02 --> Output Class Initialized
INFO - 2023-09-20 19:10:02 --> Security Class Initialized
DEBUG - 2023-09-20 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:02 --> Input Class Initialized
INFO - 2023-09-20 19:10:02 --> Language Class Initialized
ERROR - 2023-09-20 19:10:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:10:02 --> Security Class Initialized
INFO - 2023-09-20 19:10:03 --> Language Class Initialized
INFO - 2023-09-20 19:10:03 --> Hooks Class Initialized
INFO - 2023-09-20 19:10:03 --> Hooks Class Initialized
ERROR - 2023-09-20 19:10:03 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:10:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:04 --> Utf8 Class Initialized
DEBUG - 2023-09-20 19:10:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:04 --> URI Class Initialized
DEBUG - 2023-09-20 19:10:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:05 --> Input Class Initialized
INFO - 2023-09-20 19:10:05 --> Language Class Initialized
INFO - 2023-09-20 19:10:05 --> Router Class Initialized
INFO - 2023-09-20 19:10:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:05 --> URI Class Initialized
INFO - 2023-09-20 19:10:05 --> URI Class Initialized
INFO - 2023-09-20 19:10:05 --> Router Class Initialized
ERROR - 2023-09-20 19:10:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:10:05 --> Output Class Initialized
INFO - 2023-09-20 19:10:05 --> Output Class Initialized
INFO - 2023-09-20 19:10:05 --> Security Class Initialized
INFO - 2023-09-20 19:10:05 --> Router Class Initialized
DEBUG - 2023-09-20 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:05 --> Output Class Initialized
INFO - 2023-09-20 19:10:05 --> Input Class Initialized
INFO - 2023-09-20 19:10:05 --> Security Class Initialized
INFO - 2023-09-20 19:10:05 --> Security Class Initialized
INFO - 2023-09-20 19:10:05 --> Language Class Initialized
DEBUG - 2023-09-20 19:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 19:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 19:10:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:10:05 --> Input Class Initialized
INFO - 2023-09-20 19:10:05 --> Input Class Initialized
INFO - 2023-09-20 19:10:06 --> Language Class Initialized
INFO - 2023-09-20 19:10:06 --> Language Class Initialized
ERROR - 2023-09-20 19:10:06 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:10:06 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:10:54 --> Config Class Initialized
INFO - 2023-09-20 19:10:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:10:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:10:54 --> URI Class Initialized
DEBUG - 2023-09-20 19:10:54 --> No URI present. Default controller set.
INFO - 2023-09-20 19:10:54 --> Router Class Initialized
INFO - 2023-09-20 19:10:54 --> Output Class Initialized
INFO - 2023-09-20 19:10:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:10:54 --> Input Class Initialized
INFO - 2023-09-20 19:10:54 --> Language Class Initialized
INFO - 2023-09-20 19:10:54 --> Loader Class Initialized
INFO - 2023-09-20 19:10:54 --> Helper loaded: url_helper
INFO - 2023-09-20 19:10:54 --> Helper loaded: file_helper
INFO - 2023-09-20 19:10:54 --> Database Driver Class Initialized
INFO - 2023-09-20 19:10:54 --> Email Class Initialized
DEBUG - 2023-09-20 19:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:10:54 --> Controller Class Initialized
INFO - 2023-09-20 19:10:54 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:10:54 --> Model "Home_model" initialized
INFO - 2023-09-20 19:10:54 --> Helper loaded: download_helper
INFO - 2023-09-20 19:10:54 --> Helper loaded: form_helper
INFO - 2023-09-20 19:10:54 --> Form Validation Class Initialized
INFO - 2023-09-20 19:10:54 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:10:54 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:10:54 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:10:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:10:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:10:54 --> Final output sent to browser
DEBUG - 2023-09-20 19:10:55 --> Total execution time: 0.3161
INFO - 2023-09-20 19:10:58 --> Config Class Initialized
INFO - 2023-09-20 19:10:58 --> Hooks Class Initialized
INFO - 2023-09-20 19:10:59 --> Config Class Initialized
DEBUG - 2023-09-20 19:10:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:10:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:10:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:00 --> Config Class Initialized
INFO - 2023-09-20 19:11:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:00 --> URI Class Initialized
INFO - 2023-09-20 19:11:00 --> Router Class Initialized
INFO - 2023-09-20 19:11:00 --> Output Class Initialized
INFO - 2023-09-20 19:11:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:00 --> Input Class Initialized
INFO - 2023-09-20 19:11:00 --> Language Class Initialized
ERROR - 2023-09-20 19:11:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:00 --> URI Class Initialized
INFO - 2023-09-20 19:11:00 --> Router Class Initialized
INFO - 2023-09-20 19:11:00 --> Config Class Initialized
INFO - 2023-09-20 19:11:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:00 --> URI Class Initialized
INFO - 2023-09-20 19:11:00 --> Router Class Initialized
INFO - 2023-09-20 19:11:00 --> Output Class Initialized
INFO - 2023-09-20 19:11:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:00 --> Input Class Initialized
INFO - 2023-09-20 19:11:00 --> Language Class Initialized
ERROR - 2023-09-20 19:11:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:00 --> Output Class Initialized
INFO - 2023-09-20 19:11:01 --> Hooks Class Initialized
INFO - 2023-09-20 19:11:01 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:01 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:01 --> Input Class Initialized
INFO - 2023-09-20 19:11:01 --> URI Class Initialized
INFO - 2023-09-20 19:11:01 --> Language Class Initialized
INFO - 2023-09-20 19:11:01 --> Router Class Initialized
INFO - 2023-09-20 19:11:01 --> Output Class Initialized
INFO - 2023-09-20 19:11:01 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:01 --> Input Class Initialized
INFO - 2023-09-20 19:11:01 --> Language Class Initialized
ERROR - 2023-09-20 19:11:01 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:11:01 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:02 --> Config Class Initialized
INFO - 2023-09-20 19:11:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:02 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:02 --> URI Class Initialized
INFO - 2023-09-20 19:11:02 --> Router Class Initialized
INFO - 2023-09-20 19:11:02 --> Output Class Initialized
INFO - 2023-09-20 19:11:02 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:02 --> Input Class Initialized
INFO - 2023-09-20 19:11:02 --> Language Class Initialized
ERROR - 2023-09-20 19:11:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:02 --> Config Class Initialized
INFO - 2023-09-20 19:11:02 --> Config Class Initialized
INFO - 2023-09-20 19:11:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:02 --> Hooks Class Initialized
INFO - 2023-09-20 19:11:02 --> Utf8 Class Initialized
DEBUG - 2023-09-20 19:11:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:02 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:02 --> URI Class Initialized
INFO - 2023-09-20 19:11:02 --> URI Class Initialized
INFO - 2023-09-20 19:11:02 --> Router Class Initialized
INFO - 2023-09-20 19:11:02 --> Router Class Initialized
INFO - 2023-09-20 19:11:02 --> Output Class Initialized
INFO - 2023-09-20 19:11:02 --> Output Class Initialized
INFO - 2023-09-20 19:11:02 --> Security Class Initialized
INFO - 2023-09-20 19:11:02 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 19:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:02 --> Input Class Initialized
INFO - 2023-09-20 19:11:02 --> Input Class Initialized
INFO - 2023-09-20 19:11:02 --> Language Class Initialized
INFO - 2023-09-20 19:11:02 --> Language Class Initialized
ERROR - 2023-09-20 19:11:02 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:11:02 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:47 --> Config Class Initialized
INFO - 2023-09-20 19:11:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:47 --> URI Class Initialized
DEBUG - 2023-09-20 19:11:47 --> No URI present. Default controller set.
INFO - 2023-09-20 19:11:47 --> Router Class Initialized
INFO - 2023-09-20 19:11:47 --> Output Class Initialized
INFO - 2023-09-20 19:11:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:47 --> Input Class Initialized
INFO - 2023-09-20 19:11:47 --> Language Class Initialized
INFO - 2023-09-20 19:11:47 --> Loader Class Initialized
INFO - 2023-09-20 19:11:47 --> Helper loaded: url_helper
INFO - 2023-09-20 19:11:47 --> Helper loaded: file_helper
INFO - 2023-09-20 19:11:47 --> Database Driver Class Initialized
INFO - 2023-09-20 19:11:48 --> Email Class Initialized
DEBUG - 2023-09-20 19:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:11:48 --> Controller Class Initialized
INFO - 2023-09-20 19:11:48 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:11:48 --> Model "Home_model" initialized
INFO - 2023-09-20 19:11:48 --> Helper loaded: download_helper
INFO - 2023-09-20 19:11:48 --> Helper loaded: form_helper
INFO - 2023-09-20 19:11:48 --> Form Validation Class Initialized
INFO - 2023-09-20 19:11:48 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:11:48 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:11:48 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:11:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:11:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:11:48 --> Final output sent to browser
DEBUG - 2023-09-20 19:11:48 --> Total execution time: 0.5356
INFO - 2023-09-20 19:11:53 --> Config Class Initialized
INFO - 2023-09-20 19:11:53 --> Config Class Initialized
INFO - 2023-09-20 19:11:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:55 --> Config Class Initialized
INFO - 2023-09-20 19:11:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:57 --> Config Class Initialized
INFO - 2023-09-20 19:11:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:58 --> Hooks Class Initialized
INFO - 2023-09-20 19:11:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:58 --> URI Class Initialized
INFO - 2023-09-20 19:11:58 --> Router Class Initialized
INFO - 2023-09-20 19:11:58 --> Output Class Initialized
INFO - 2023-09-20 19:11:58 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:58 --> Input Class Initialized
INFO - 2023-09-20 19:11:58 --> Language Class Initialized
ERROR - 2023-09-20 19:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:58 --> URI Class Initialized
INFO - 2023-09-20 19:11:58 --> Router Class Initialized
INFO - 2023-09-20 19:11:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:11:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:58 --> URI Class Initialized
INFO - 2023-09-20 19:11:58 --> Router Class Initialized
INFO - 2023-09-20 19:11:58 --> Output Class Initialized
INFO - 2023-09-20 19:11:58 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:58 --> Input Class Initialized
INFO - 2023-09-20 19:11:58 --> Language Class Initialized
ERROR - 2023-09-20 19:11:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:11:58 --> Config Class Initialized
INFO - 2023-09-20 19:11:59 --> Output Class Initialized
INFO - 2023-09-20 19:11:59 --> Hooks Class Initialized
INFO - 2023-09-20 19:11:59 --> Config Class Initialized
INFO - 2023-09-20 19:11:59 --> Security Class Initialized
DEBUG - 2023-09-20 19:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:11:59 --> Input Class Initialized
INFO - 2023-09-20 19:11:59 --> Language Class Initialized
ERROR - 2023-09-20 19:11:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:11:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:11:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:11:59 --> Config Class Initialized
INFO - 2023-09-20 19:11:59 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:59 --> Utf8 Class Initialized
INFO - 2023-09-20 19:11:59 --> Hooks Class Initialized
INFO - 2023-09-20 19:12:00 --> URI Class Initialized
INFO - 2023-09-20 19:12:00 --> Router Class Initialized
INFO - 2023-09-20 19:12:00 --> Output Class Initialized
INFO - 2023-09-20 19:12:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:00 --> Input Class Initialized
INFO - 2023-09-20 19:12:00 --> Language Class Initialized
ERROR - 2023-09-20 19:12:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:12:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:00 --> URI Class Initialized
INFO - 2023-09-20 19:12:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:00 --> Hooks Class Initialized
INFO - 2023-09-20 19:12:00 --> URI Class Initialized
INFO - 2023-09-20 19:12:00 --> Router Class Initialized
DEBUG - 2023-09-20 19:12:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:00 --> Router Class Initialized
INFO - 2023-09-20 19:12:00 --> Output Class Initialized
INFO - 2023-09-20 19:12:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:00 --> Output Class Initialized
INFO - 2023-09-20 19:12:00 --> Security Class Initialized
INFO - 2023-09-20 19:12:00 --> Security Class Initialized
INFO - 2023-09-20 19:12:00 --> URI Class Initialized
DEBUG - 2023-09-20 19:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 19:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:00 --> Router Class Initialized
INFO - 2023-09-20 19:12:00 --> Input Class Initialized
INFO - 2023-09-20 19:12:00 --> Input Class Initialized
INFO - 2023-09-20 19:12:00 --> Output Class Initialized
INFO - 2023-09-20 19:12:00 --> Language Class Initialized
INFO - 2023-09-20 19:12:00 --> Language Class Initialized
INFO - 2023-09-20 19:12:00 --> Security Class Initialized
ERROR - 2023-09-20 19:12:00 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:12:00 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:00 --> Input Class Initialized
INFO - 2023-09-20 19:12:00 --> Language Class Initialized
ERROR - 2023-09-20 19:12:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:12:39 --> Config Class Initialized
INFO - 2023-09-20 19:12:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:39 --> URI Class Initialized
INFO - 2023-09-20 19:12:39 --> Router Class Initialized
INFO - 2023-09-20 19:12:39 --> Output Class Initialized
INFO - 2023-09-20 19:12:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:39 --> Input Class Initialized
INFO - 2023-09-20 19:12:39 --> Language Class Initialized
INFO - 2023-09-20 19:12:39 --> Loader Class Initialized
INFO - 2023-09-20 19:12:39 --> Helper loaded: url_helper
INFO - 2023-09-20 19:12:39 --> Helper loaded: file_helper
INFO - 2023-09-20 19:12:39 --> Database Driver Class Initialized
INFO - 2023-09-20 19:12:40 --> Email Class Initialized
DEBUG - 2023-09-20 19:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:12:40 --> Controller Class Initialized
INFO - 2023-09-20 19:12:40 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:12:40 --> Helper loaded: form_helper
INFO - 2023-09-20 19:12:40 --> Form Validation Class Initialized
INFO - 2023-09-20 19:12:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-20 19:12:40 --> Final output sent to browser
DEBUG - 2023-09-20 19:12:40 --> Total execution time: 0.2973
INFO - 2023-09-20 19:12:41 --> Config Class Initialized
INFO - 2023-09-20 19:12:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:41 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:41 --> URI Class Initialized
INFO - 2023-09-20 19:12:41 --> Router Class Initialized
INFO - 2023-09-20 19:12:41 --> Output Class Initialized
INFO - 2023-09-20 19:12:41 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:41 --> Input Class Initialized
INFO - 2023-09-20 19:12:41 --> Language Class Initialized
ERROR - 2023-09-20 19:12:41 --> 404 Page Not Found: admin/Social_media/images
INFO - 2023-09-20 19:12:47 --> Config Class Initialized
INFO - 2023-09-20 19:12:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:47 --> URI Class Initialized
INFO - 2023-09-20 19:12:47 --> Router Class Initialized
INFO - 2023-09-20 19:12:47 --> Output Class Initialized
INFO - 2023-09-20 19:12:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:47 --> Input Class Initialized
INFO - 2023-09-20 19:12:47 --> Language Class Initialized
INFO - 2023-09-20 19:12:47 --> Loader Class Initialized
INFO - 2023-09-20 19:12:47 --> Helper loaded: url_helper
INFO - 2023-09-20 19:12:47 --> Helper loaded: file_helper
INFO - 2023-09-20 19:12:47 --> Database Driver Class Initialized
INFO - 2023-09-20 19:12:47 --> Email Class Initialized
DEBUG - 2023-09-20 19:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:12:47 --> Controller Class Initialized
INFO - 2023-09-20 19:12:47 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:12:47 --> Helper loaded: form_helper
INFO - 2023-09-20 19:12:47 --> Form Validation Class Initialized
INFO - 2023-09-20 19:12:47 --> Config Class Initialized
INFO - 2023-09-20 19:12:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:47 --> URI Class Initialized
INFO - 2023-09-20 19:12:47 --> Router Class Initialized
INFO - 2023-09-20 19:12:48 --> Output Class Initialized
INFO - 2023-09-20 19:12:48 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:48 --> Input Class Initialized
INFO - 2023-09-20 19:12:48 --> Language Class Initialized
INFO - 2023-09-20 19:12:48 --> Loader Class Initialized
INFO - 2023-09-20 19:12:48 --> Helper loaded: url_helper
INFO - 2023-09-20 19:12:48 --> Helper loaded: file_helper
INFO - 2023-09-20 19:12:48 --> Database Driver Class Initialized
INFO - 2023-09-20 19:12:48 --> Email Class Initialized
DEBUG - 2023-09-20 19:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:12:48 --> Controller Class Initialized
INFO - 2023-09-20 19:12:48 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:12:48 --> Helper loaded: form_helper
INFO - 2023-09-20 19:12:48 --> Form Validation Class Initialized
INFO - 2023-09-20 19:12:48 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/social_media_create.php
INFO - 2023-09-20 19:12:48 --> Final output sent to browser
DEBUG - 2023-09-20 19:12:48 --> Total execution time: 0.1261
INFO - 2023-09-20 19:12:51 --> Config Class Initialized
INFO - 2023-09-20 19:12:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:51 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:51 --> URI Class Initialized
DEBUG - 2023-09-20 19:12:51 --> No URI present. Default controller set.
INFO - 2023-09-20 19:12:51 --> Router Class Initialized
INFO - 2023-09-20 19:12:51 --> Output Class Initialized
INFO - 2023-09-20 19:12:51 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:51 --> Input Class Initialized
INFO - 2023-09-20 19:12:51 --> Language Class Initialized
INFO - 2023-09-20 19:12:51 --> Loader Class Initialized
INFO - 2023-09-20 19:12:51 --> Helper loaded: url_helper
INFO - 2023-09-20 19:12:51 --> Helper loaded: file_helper
INFO - 2023-09-20 19:12:51 --> Database Driver Class Initialized
INFO - 2023-09-20 19:12:51 --> Email Class Initialized
DEBUG - 2023-09-20 19:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:12:51 --> Controller Class Initialized
INFO - 2023-09-20 19:12:51 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:12:51 --> Model "Home_model" initialized
INFO - 2023-09-20 19:12:51 --> Helper loaded: download_helper
INFO - 2023-09-20 19:12:51 --> Helper loaded: form_helper
INFO - 2023-09-20 19:12:51 --> Form Validation Class Initialized
INFO - 2023-09-20 19:12:51 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:12:51 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:12:51 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:12:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:12:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:12:51 --> Final output sent to browser
DEBUG - 2023-09-20 19:12:51 --> Total execution time: 0.2099
INFO - 2023-09-20 19:12:52 --> Config Class Initialized
INFO - 2023-09-20 19:12:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:52 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:52 --> URI Class Initialized
INFO - 2023-09-20 19:12:52 --> Router Class Initialized
INFO - 2023-09-20 19:12:52 --> Output Class Initialized
INFO - 2023-09-20 19:12:52 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:52 --> Input Class Initialized
INFO - 2023-09-20 19:12:52 --> Language Class Initialized
ERROR - 2023-09-20 19:12:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:12:54 --> Config Class Initialized
INFO - 2023-09-20 19:12:54 --> Hooks Class Initialized
INFO - 2023-09-20 19:12:56 --> Config Class Initialized
INFO - 2023-09-20 19:12:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:56 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:56 --> URI Class Initialized
INFO - 2023-09-20 19:12:56 --> Router Class Initialized
INFO - 2023-09-20 19:12:56 --> Output Class Initialized
INFO - 2023-09-20 19:12:56 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:56 --> Input Class Initialized
INFO - 2023-09-20 19:12:56 --> Language Class Initialized
ERROR - 2023-09-20 19:12:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:12:56 --> Config Class Initialized
INFO - 2023-09-20 19:12:56 --> Config Class Initialized
INFO - 2023-09-20 19:12:56 --> Hooks Class Initialized
INFO - 2023-09-20 19:12:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:56 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:56 --> URI Class Initialized
INFO - 2023-09-20 19:12:56 --> Router Class Initialized
INFO - 2023-09-20 19:12:56 --> Output Class Initialized
INFO - 2023-09-20 19:12:56 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:56 --> Input Class Initialized
INFO - 2023-09-20 19:12:56 --> Language Class Initialized
ERROR - 2023-09-20 19:12:56 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:12:57 --> Config Class Initialized
INFO - 2023-09-20 19:12:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:57 --> URI Class Initialized
INFO - 2023-09-20 19:12:57 --> Router Class Initialized
INFO - 2023-09-20 19:12:57 --> Output Class Initialized
INFO - 2023-09-20 19:12:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:57 --> Input Class Initialized
INFO - 2023-09-20 19:12:57 --> Language Class Initialized
ERROR - 2023-09-20 19:12:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:12:57 --> Config Class Initialized
DEBUG - 2023-09-20 19:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:12:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:12:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:58 --> URI Class Initialized
INFO - 2023-09-20 19:12:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:12:58 --> Router Class Initialized
INFO - 2023-09-20 19:12:59 --> URI Class Initialized
INFO - 2023-09-20 19:12:59 --> Router Class Initialized
INFO - 2023-09-20 19:12:59 --> Output Class Initialized
INFO - 2023-09-20 19:12:59 --> URI Class Initialized
INFO - 2023-09-20 19:12:59 --> Security Class Initialized
INFO - 2023-09-20 19:12:59 --> Output Class Initialized
INFO - 2023-09-20 19:12:59 --> Router Class Initialized
INFO - 2023-09-20 19:12:59 --> Output Class Initialized
INFO - 2023-09-20 19:12:59 --> Security Class Initialized
DEBUG - 2023-09-20 19:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:59 --> Input Class Initialized
INFO - 2023-09-20 19:12:59 --> Language Class Initialized
ERROR - 2023-09-20 19:12:59 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:12:59 --> Security Class Initialized
INFO - 2023-09-20 19:12:59 --> Input Class Initialized
DEBUG - 2023-09-20 19:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:13:00 --> Language Class Initialized
INFO - 2023-09-20 19:13:00 --> Input Class Initialized
ERROR - 2023-09-20 19:13:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:13:00 --> Language Class Initialized
ERROR - 2023-09-20 19:13:00 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:13:40 --> Config Class Initialized
INFO - 2023-09-20 19:13:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:13:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:13:40 --> Utf8 Class Initialized
INFO - 2023-09-20 19:13:40 --> URI Class Initialized
DEBUG - 2023-09-20 19:13:40 --> No URI present. Default controller set.
INFO - 2023-09-20 19:13:40 --> Router Class Initialized
INFO - 2023-09-20 19:13:40 --> Output Class Initialized
INFO - 2023-09-20 19:13:40 --> Security Class Initialized
DEBUG - 2023-09-20 19:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:13:40 --> Input Class Initialized
INFO - 2023-09-20 19:13:40 --> Language Class Initialized
INFO - 2023-09-20 19:13:40 --> Loader Class Initialized
INFO - 2023-09-20 19:13:40 --> Helper loaded: url_helper
INFO - 2023-09-20 19:13:40 --> Helper loaded: file_helper
INFO - 2023-09-20 19:13:40 --> Database Driver Class Initialized
INFO - 2023-09-20 19:13:40 --> Email Class Initialized
DEBUG - 2023-09-20 19:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:13:40 --> Controller Class Initialized
INFO - 2023-09-20 19:13:40 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:13:40 --> Model "Home_model" initialized
INFO - 2023-09-20 19:13:40 --> Helper loaded: download_helper
INFO - 2023-09-20 19:13:40 --> Helper loaded: form_helper
INFO - 2023-09-20 19:13:40 --> Form Validation Class Initialized
INFO - 2023-09-20 19:13:40 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:13:40 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:13:40 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:13:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:13:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:13:40 --> Final output sent to browser
DEBUG - 2023-09-20 19:13:40 --> Total execution time: 0.2506
INFO - 2023-09-20 19:13:43 --> Config Class Initialized
INFO - 2023-09-20 19:13:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:13:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:13:43 --> Utf8 Class Initialized
INFO - 2023-09-20 19:13:43 --> URI Class Initialized
INFO - 2023-09-20 19:13:43 --> Router Class Initialized
INFO - 2023-09-20 19:13:43 --> Output Class Initialized
INFO - 2023-09-20 19:13:43 --> Security Class Initialized
DEBUG - 2023-09-20 19:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:13:43 --> Input Class Initialized
INFO - 2023-09-20 19:13:43 --> Language Class Initialized
ERROR - 2023-09-20 19:13:43 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:13:43 --> Config Class Initialized
INFO - 2023-09-20 19:13:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:13:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:13:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:13:44 --> URI Class Initialized
INFO - 2023-09-20 19:13:44 --> Router Class Initialized
INFO - 2023-09-20 19:13:44 --> Output Class Initialized
INFO - 2023-09-20 19:13:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:13:44 --> Input Class Initialized
INFO - 2023-09-20 19:13:44 --> Language Class Initialized
ERROR - 2023-09-20 19:13:44 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:13:44 --> Config Class Initialized
INFO - 2023-09-20 19:13:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:13:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:13:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:13:44 --> URI Class Initialized
INFO - 2023-09-20 19:13:45 --> Router Class Initialized
INFO - 2023-09-20 19:13:45 --> Output Class Initialized
INFO - 2023-09-20 19:13:45 --> Security Class Initialized
INFO - 2023-09-20 19:14:04 --> Config Class Initialized
INFO - 2023-09-20 19:14:04 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:04 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:04 --> URI Class Initialized
INFO - 2023-09-20 19:14:04 --> Router Class Initialized
INFO - 2023-09-20 19:14:04 --> Output Class Initialized
INFO - 2023-09-20 19:14:04 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:04 --> Input Class Initialized
INFO - 2023-09-20 19:14:04 --> Language Class Initialized
INFO - 2023-09-20 19:14:04 --> Loader Class Initialized
INFO - 2023-09-20 19:14:04 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:04 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:04 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:04 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:04 --> Controller Class Initialized
INFO - 2023-09-20 19:14:04 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:04 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:04 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:04 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:14:04 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:04 --> Total execution time: 0.1143
INFO - 2023-09-20 19:14:05 --> Config Class Initialized
INFO - 2023-09-20 19:14:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:05 --> URI Class Initialized
INFO - 2023-09-20 19:14:05 --> Router Class Initialized
INFO - 2023-09-20 19:14:05 --> Output Class Initialized
INFO - 2023-09-20 19:14:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:05 --> Input Class Initialized
INFO - 2023-09-20 19:14:05 --> Language Class Initialized
ERROR - 2023-09-20 19:14:05 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 19:14:13 --> Config Class Initialized
INFO - 2023-09-20 19:14:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:13 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:13 --> URI Class Initialized
INFO - 2023-09-20 19:14:13 --> Router Class Initialized
INFO - 2023-09-20 19:14:13 --> Output Class Initialized
INFO - 2023-09-20 19:14:13 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:13 --> Input Class Initialized
INFO - 2023-09-20 19:14:13 --> Language Class Initialized
INFO - 2023-09-20 19:14:13 --> Loader Class Initialized
INFO - 2023-09-20 19:14:13 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:13 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:13 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:13 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:13 --> Controller Class Initialized
INFO - 2023-09-20 19:14:14 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:14 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:14 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:14:14 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:14 --> Total execution time: 0.1481
INFO - 2023-09-20 19:14:15 --> Config Class Initialized
INFO - 2023-09-20 19:14:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:15 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:15 --> URI Class Initialized
INFO - 2023-09-20 19:14:15 --> Router Class Initialized
INFO - 2023-09-20 19:14:15 --> Output Class Initialized
INFO - 2023-09-20 19:14:15 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:15 --> Input Class Initialized
INFO - 2023-09-20 19:14:15 --> Language Class Initialized
INFO - 2023-09-20 19:14:15 --> Loader Class Initialized
INFO - 2023-09-20 19:14:15 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:15 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:15 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:15 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:15 --> Controller Class Initialized
INFO - 2023-09-20 19:14:15 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:15 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:15 --> Form Validation Class Initialized
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 19:14:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 19:14:15 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:14:15 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:15 --> Total execution time: 0.0617
INFO - 2023-09-20 19:14:18 --> Config Class Initialized
INFO - 2023-09-20 19:14:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:18 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:18 --> URI Class Initialized
INFO - 2023-09-20 19:14:18 --> Router Class Initialized
INFO - 2023-09-20 19:14:18 --> Output Class Initialized
INFO - 2023-09-20 19:14:18 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:18 --> Input Class Initialized
INFO - 2023-09-20 19:14:18 --> Language Class Initialized
INFO - 2023-09-20 19:14:18 --> Loader Class Initialized
INFO - 2023-09-20 19:14:18 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:18 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:18 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:18 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:18 --> Controller Class Initialized
INFO - 2023-09-20 19:14:18 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:18 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:18 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:18 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:14:18 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:18 --> Total execution time: 0.0613
INFO - 2023-09-20 19:14:22 --> Config Class Initialized
INFO - 2023-09-20 19:14:22 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:22 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:22 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:22 --> URI Class Initialized
INFO - 2023-09-20 19:14:22 --> Router Class Initialized
INFO - 2023-09-20 19:14:22 --> Output Class Initialized
INFO - 2023-09-20 19:14:22 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:22 --> Input Class Initialized
INFO - 2023-09-20 19:14:22 --> Language Class Initialized
INFO - 2023-09-20 19:14:22 --> Loader Class Initialized
INFO - 2023-09-20 19:14:22 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:22 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:22 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:22 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:22 --> Controller Class Initialized
INFO - 2023-09-20 19:14:22 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:22 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:14:22 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:22 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:14:22 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:22 --> Total execution time: 0.1150
INFO - 2023-09-20 19:14:23 --> Config Class Initialized
INFO - 2023-09-20 19:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:23 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:23 --> URI Class Initialized
INFO - 2023-09-20 19:14:23 --> Router Class Initialized
INFO - 2023-09-20 19:14:23 --> Output Class Initialized
INFO - 2023-09-20 19:14:23 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:23 --> Input Class Initialized
INFO - 2023-09-20 19:14:23 --> Language Class Initialized
ERROR - 2023-09-20 19:14:23 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-09-20 19:14:26 --> Config Class Initialized
INFO - 2023-09-20 19:14:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:26 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:26 --> URI Class Initialized
INFO - 2023-09-20 19:14:26 --> Router Class Initialized
INFO - 2023-09-20 19:14:26 --> Output Class Initialized
INFO - 2023-09-20 19:14:26 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:26 --> Input Class Initialized
INFO - 2023-09-20 19:14:26 --> Language Class Initialized
INFO - 2023-09-20 19:14:26 --> Loader Class Initialized
INFO - 2023-09-20 19:14:26 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:26 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:26 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:26 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:26 --> Controller Class Initialized
INFO - 2023-09-20 19:14:26 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:26 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:14:26 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:26 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:26 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:14:26 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:26 --> Total execution time: 0.1187
INFO - 2023-09-20 19:14:27 --> Config Class Initialized
INFO - 2023-09-20 19:14:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:27 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:27 --> URI Class Initialized
INFO - 2023-09-20 19:14:27 --> Router Class Initialized
INFO - 2023-09-20 19:14:27 --> Output Class Initialized
INFO - 2023-09-20 19:14:27 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:27 --> Input Class Initialized
INFO - 2023-09-20 19:14:27 --> Language Class Initialized
INFO - 2023-09-20 19:14:27 --> Loader Class Initialized
INFO - 2023-09-20 19:14:27 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:27 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:27 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:27 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:27 --> Controller Class Initialized
INFO - 2023-09-20 19:14:27 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:27 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:14:27 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:27 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:27 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:14:27 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:27 --> Total execution time: 0.2154
INFO - 2023-09-20 19:14:47 --> Config Class Initialized
INFO - 2023-09-20 19:14:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:47 --> URI Class Initialized
INFO - 2023-09-20 19:14:47 --> Router Class Initialized
INFO - 2023-09-20 19:14:47 --> Output Class Initialized
INFO - 2023-09-20 19:14:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:48 --> Input Class Initialized
INFO - 2023-09-20 19:14:48 --> Language Class Initialized
INFO - 2023-09-20 19:14:48 --> Loader Class Initialized
INFO - 2023-09-20 19:14:48 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:48 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:48 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:48 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:48 --> Controller Class Initialized
INFO - 2023-09-20 19:14:48 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:48 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:14:48 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:48 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:14:48 --> Config Class Initialized
INFO - 2023-09-20 19:14:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:48 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:48 --> URI Class Initialized
INFO - 2023-09-20 19:14:48 --> Router Class Initialized
INFO - 2023-09-20 19:14:48 --> Output Class Initialized
INFO - 2023-09-20 19:14:48 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:48 --> Input Class Initialized
INFO - 2023-09-20 19:14:48 --> Language Class Initialized
INFO - 2023-09-20 19:14:48 --> Loader Class Initialized
INFO - 2023-09-20 19:14:48 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:48 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:48 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:48 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:49 --> Controller Class Initialized
INFO - 2023-09-20 19:14:49 --> Model "Services_model" initialized
INFO - 2023-09-20 19:14:49 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:14:49 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:49 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:14:49 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:49 --> Total execution time: 0.2754
INFO - 2023-09-20 19:14:53 --> Config Class Initialized
INFO - 2023-09-20 19:14:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:14:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:14:53 --> Utf8 Class Initialized
INFO - 2023-09-20 19:14:53 --> URI Class Initialized
INFO - 2023-09-20 19:14:53 --> Router Class Initialized
INFO - 2023-09-20 19:14:53 --> Output Class Initialized
INFO - 2023-09-20 19:14:53 --> Security Class Initialized
DEBUG - 2023-09-20 19:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:14:53 --> Input Class Initialized
INFO - 2023-09-20 19:14:53 --> Language Class Initialized
INFO - 2023-09-20 19:14:53 --> Loader Class Initialized
INFO - 2023-09-20 19:14:53 --> Helper loaded: url_helper
INFO - 2023-09-20 19:14:53 --> Helper loaded: file_helper
INFO - 2023-09-20 19:14:53 --> Database Driver Class Initialized
INFO - 2023-09-20 19:14:53 --> Email Class Initialized
DEBUG - 2023-09-20 19:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:14:53 --> Controller Class Initialized
INFO - 2023-09-20 19:14:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:14:53 --> Model "Home_model" initialized
INFO - 2023-09-20 19:14:53 --> Helper loaded: download_helper
INFO - 2023-09-20 19:14:53 --> Helper loaded: form_helper
INFO - 2023-09-20 19:14:53 --> Form Validation Class Initialized
INFO - 2023-09-20 19:14:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:14:53 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:14:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:14:53 --> Final output sent to browser
DEBUG - 2023-09-20 19:14:53 --> Total execution time: 0.1159
INFO - 2023-09-20 19:15:00 --> Config Class Initialized
INFO - 2023-09-20 19:15:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:00 --> URI Class Initialized
INFO - 2023-09-20 19:15:00 --> Router Class Initialized
INFO - 2023-09-20 19:15:01 --> Output Class Initialized
INFO - 2023-09-20 19:15:01 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:01 --> Input Class Initialized
INFO - 2023-09-20 19:15:01 --> Language Class Initialized
INFO - 2023-09-20 19:15:01 --> Loader Class Initialized
INFO - 2023-09-20 19:15:01 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:01 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:01 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:01 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:01 --> Controller Class Initialized
INFO - 2023-09-20 19:15:01 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:15:01 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:01 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:15:01 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:01 --> Total execution time: 0.1127
INFO - 2023-09-20 19:15:01 --> Config Class Initialized
INFO - 2023-09-20 19:15:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:01 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:01 --> URI Class Initialized
INFO - 2023-09-20 19:15:01 --> Router Class Initialized
INFO - 2023-09-20 19:15:01 --> Output Class Initialized
INFO - 2023-09-20 19:15:01 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:01 --> Input Class Initialized
INFO - 2023-09-20 19:15:01 --> Language Class Initialized
INFO - 2023-09-20 19:15:01 --> Loader Class Initialized
INFO - 2023-09-20 19:15:01 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:01 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:01 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:01 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:01 --> Controller Class Initialized
INFO - 2023-09-20 19:15:01 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:01 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:15:01 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:01 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:01 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:15:01 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:01 --> Total execution time: 0.0979
INFO - 2023-09-20 19:15:02 --> Config Class Initialized
INFO - 2023-09-20 19:15:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:02 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:02 --> URI Class Initialized
INFO - 2023-09-20 19:15:02 --> Router Class Initialized
INFO - 2023-09-20 19:15:02 --> Output Class Initialized
INFO - 2023-09-20 19:15:02 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:02 --> Input Class Initialized
INFO - 2023-09-20 19:15:02 --> Language Class Initialized
INFO - 2023-09-20 19:15:02 --> Loader Class Initialized
INFO - 2023-09-20 19:15:02 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:02 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:02 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:02 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:02 --> Controller Class Initialized
INFO - 2023-09-20 19:15:02 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:02 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:15:02 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:02 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:02 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:15:02 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:02 --> Total execution time: 0.1311
INFO - 2023-09-20 19:15:03 --> Config Class Initialized
INFO - 2023-09-20 19:15:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:03 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:03 --> URI Class Initialized
INFO - 2023-09-20 19:15:03 --> Router Class Initialized
INFO - 2023-09-20 19:15:03 --> Output Class Initialized
INFO - 2023-09-20 19:15:03 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:03 --> Input Class Initialized
INFO - 2023-09-20 19:15:03 --> Language Class Initialized
INFO - 2023-09-20 19:15:03 --> Loader Class Initialized
INFO - 2023-09-20 19:15:03 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:03 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:03 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:03 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:03 --> Controller Class Initialized
INFO - 2023-09-20 19:15:03 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:03 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:03 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:15:03 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:04 --> Total execution time: 0.1088
INFO - 2023-09-20 19:15:07 --> Config Class Initialized
INFO - 2023-09-20 19:15:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:07 --> URI Class Initialized
INFO - 2023-09-20 19:15:07 --> Router Class Initialized
INFO - 2023-09-20 19:15:07 --> Output Class Initialized
INFO - 2023-09-20 19:15:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:07 --> Input Class Initialized
INFO - 2023-09-20 19:15:07 --> Language Class Initialized
INFO - 2023-09-20 19:15:07 --> Loader Class Initialized
INFO - 2023-09-20 19:15:07 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:07 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:07 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:07 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:07 --> Controller Class Initialized
INFO - 2023-09-20 19:15:07 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:07 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:07 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:15:07 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:07 --> Total execution time: 0.1161
INFO - 2023-09-20 19:15:08 --> Config Class Initialized
INFO - 2023-09-20 19:15:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:08 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:08 --> URI Class Initialized
INFO - 2023-09-20 19:15:08 --> Router Class Initialized
INFO - 2023-09-20 19:15:08 --> Output Class Initialized
INFO - 2023-09-20 19:15:08 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:08 --> Input Class Initialized
INFO - 2023-09-20 19:15:08 --> Language Class Initialized
INFO - 2023-09-20 19:15:08 --> Loader Class Initialized
INFO - 2023-09-20 19:15:08 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:08 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:08 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:08 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:08 --> Controller Class Initialized
INFO - 2023-09-20 19:15:08 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:08 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:08 --> Form Validation Class Initialized
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 19:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 19:15:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:15:08 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:08 --> Total execution time: 0.2487
INFO - 2023-09-20 19:15:28 --> Config Class Initialized
INFO - 2023-09-20 19:15:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:28 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:28 --> URI Class Initialized
INFO - 2023-09-20 19:15:28 --> Router Class Initialized
INFO - 2023-09-20 19:15:28 --> Output Class Initialized
INFO - 2023-09-20 19:15:28 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:28 --> Input Class Initialized
INFO - 2023-09-20 19:15:28 --> Language Class Initialized
INFO - 2023-09-20 19:15:28 --> Loader Class Initialized
INFO - 2023-09-20 19:15:28 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:28 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:28 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:28 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:28 --> Controller Class Initialized
INFO - 2023-09-20 19:15:28 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:28 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:28 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:15:28 --> Config Class Initialized
INFO - 2023-09-20 19:15:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:28 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:28 --> URI Class Initialized
INFO - 2023-09-20 19:15:28 --> Router Class Initialized
INFO - 2023-09-20 19:15:28 --> Output Class Initialized
INFO - 2023-09-20 19:15:28 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:28 --> Input Class Initialized
INFO - 2023-09-20 19:15:28 --> Language Class Initialized
INFO - 2023-09-20 19:15:28 --> Loader Class Initialized
INFO - 2023-09-20 19:15:28 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:28 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:28 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:28 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:28 --> Controller Class Initialized
INFO - 2023-09-20 19:15:28 --> Model "Services_model" initialized
INFO - 2023-09-20 19:15:28 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:28 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:28 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:15:28 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:28 --> Total execution time: 0.1206
INFO - 2023-09-20 19:15:32 --> Config Class Initialized
INFO - 2023-09-20 19:15:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:15:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:15:32 --> Utf8 Class Initialized
INFO - 2023-09-20 19:15:32 --> URI Class Initialized
INFO - 2023-09-20 19:15:32 --> Router Class Initialized
INFO - 2023-09-20 19:15:32 --> Output Class Initialized
INFO - 2023-09-20 19:15:32 --> Security Class Initialized
DEBUG - 2023-09-20 19:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:15:32 --> Input Class Initialized
INFO - 2023-09-20 19:15:32 --> Language Class Initialized
INFO - 2023-09-20 19:15:32 --> Loader Class Initialized
INFO - 2023-09-20 19:15:32 --> Helper loaded: url_helper
INFO - 2023-09-20 19:15:32 --> Helper loaded: file_helper
INFO - 2023-09-20 19:15:32 --> Database Driver Class Initialized
INFO - 2023-09-20 19:15:32 --> Email Class Initialized
DEBUG - 2023-09-20 19:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:15:32 --> Controller Class Initialized
INFO - 2023-09-20 19:15:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:15:32 --> Model "Home_model" initialized
INFO - 2023-09-20 19:15:32 --> Helper loaded: download_helper
INFO - 2023-09-20 19:15:32 --> Helper loaded: form_helper
INFO - 2023-09-20 19:15:32 --> Form Validation Class Initialized
INFO - 2023-09-20 19:15:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:15:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:15:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:15:32 --> Final output sent to browser
DEBUG - 2023-09-20 19:15:32 --> Total execution time: 0.1255
INFO - 2023-09-20 19:16:33 --> Config Class Initialized
INFO - 2023-09-20 19:16:33 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:33 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:33 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:33 --> URI Class Initialized
INFO - 2023-09-20 19:16:33 --> Router Class Initialized
INFO - 2023-09-20 19:16:33 --> Output Class Initialized
INFO - 2023-09-20 19:16:33 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:33 --> Input Class Initialized
INFO - 2023-09-20 19:16:33 --> Language Class Initialized
INFO - 2023-09-20 19:16:33 --> Loader Class Initialized
INFO - 2023-09-20 19:16:33 --> Helper loaded: url_helper
INFO - 2023-09-20 19:16:33 --> Helper loaded: file_helper
INFO - 2023-09-20 19:16:33 --> Database Driver Class Initialized
INFO - 2023-09-20 19:16:33 --> Email Class Initialized
DEBUG - 2023-09-20 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:16:33 --> Controller Class Initialized
INFO - 2023-09-20 19:16:33 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:16:33 --> Model "Home_model" initialized
INFO - 2023-09-20 19:16:33 --> Helper loaded: download_helper
INFO - 2023-09-20 19:16:33 --> Helper loaded: form_helper
INFO - 2023-09-20 19:16:33 --> Form Validation Class Initialized
INFO - 2023-09-20 19:16:33 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:16:33 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:16:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:16:33 --> Final output sent to browser
DEBUG - 2023-09-20 19:16:33 --> Total execution time: 0.1078
INFO - 2023-09-20 19:16:34 --> Config Class Initialized
INFO - 2023-09-20 19:16:35 --> Hooks Class Initialized
INFO - 2023-09-20 19:16:35 --> Config Class Initialized
INFO - 2023-09-20 19:16:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:16:36 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:37 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:37 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:37 --> URI Class Initialized
INFO - 2023-09-20 19:16:37 --> URI Class Initialized
INFO - 2023-09-20 19:16:37 --> Router Class Initialized
INFO - 2023-09-20 19:16:38 --> Output Class Initialized
INFO - 2023-09-20 19:16:38 --> Router Class Initialized
INFO - 2023-09-20 19:16:38 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:38 --> Input Class Initialized
INFO - 2023-09-20 19:16:38 --> Language Class Initialized
ERROR - 2023-09-20 19:16:38 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:38 --> Output Class Initialized
INFO - 2023-09-20 19:16:38 --> Security Class Initialized
INFO - 2023-09-20 19:16:38 --> Config Class Initialized
INFO - 2023-09-20 19:16:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:38 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:38 --> URI Class Initialized
INFO - 2023-09-20 19:16:38 --> Router Class Initialized
INFO - 2023-09-20 19:16:38 --> Output Class Initialized
INFO - 2023-09-20 19:16:38 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:38 --> Input Class Initialized
INFO - 2023-09-20 19:16:38 --> Language Class Initialized
ERROR - 2023-09-20 19:16:38 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:39 --> Input Class Initialized
INFO - 2023-09-20 19:16:39 --> Language Class Initialized
ERROR - 2023-09-20 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:39 --> Config Class Initialized
INFO - 2023-09-20 19:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:39 --> URI Class Initialized
INFO - 2023-09-20 19:16:39 --> Router Class Initialized
INFO - 2023-09-20 19:16:39 --> Output Class Initialized
INFO - 2023-09-20 19:16:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:39 --> Input Class Initialized
INFO - 2023-09-20 19:16:39 --> Language Class Initialized
ERROR - 2023-09-20 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:39 --> Config Class Initialized
INFO - 2023-09-20 19:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:39 --> URI Class Initialized
INFO - 2023-09-20 19:16:39 --> Router Class Initialized
INFO - 2023-09-20 19:16:39 --> Output Class Initialized
INFO - 2023-09-20 19:16:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:39 --> Input Class Initialized
INFO - 2023-09-20 19:16:39 --> Language Class Initialized
ERROR - 2023-09-20 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:39 --> Config Class Initialized
INFO - 2023-09-20 19:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:39 --> URI Class Initialized
INFO - 2023-09-20 19:16:39 --> Router Class Initialized
INFO - 2023-09-20 19:16:39 --> Output Class Initialized
INFO - 2023-09-20 19:16:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:39 --> Input Class Initialized
INFO - 2023-09-20 19:16:39 --> Language Class Initialized
ERROR - 2023-09-20 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:39 --> Config Class Initialized
INFO - 2023-09-20 19:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:39 --> URI Class Initialized
INFO - 2023-09-20 19:16:39 --> Router Class Initialized
INFO - 2023-09-20 19:16:39 --> Output Class Initialized
INFO - 2023-09-20 19:16:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:39 --> Input Class Initialized
INFO - 2023-09-20 19:16:39 --> Language Class Initialized
ERROR - 2023-09-20 19:16:39 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:16:58 --> Config Class Initialized
INFO - 2023-09-20 19:16:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:16:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:16:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:16:58 --> URI Class Initialized
INFO - 2023-09-20 19:16:58 --> Router Class Initialized
INFO - 2023-09-20 19:16:58 --> Output Class Initialized
INFO - 2023-09-20 19:16:58 --> Security Class Initialized
DEBUG - 2023-09-20 19:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:16:58 --> Input Class Initialized
INFO - 2023-09-20 19:16:58 --> Language Class Initialized
INFO - 2023-09-20 19:16:58 --> Loader Class Initialized
INFO - 2023-09-20 19:16:58 --> Helper loaded: url_helper
INFO - 2023-09-20 19:16:58 --> Helper loaded: file_helper
INFO - 2023-09-20 19:16:58 --> Database Driver Class Initialized
INFO - 2023-09-20 19:16:58 --> Email Class Initialized
DEBUG - 2023-09-20 19:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:16:58 --> Controller Class Initialized
INFO - 2023-09-20 19:16:58 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:16:58 --> Model "Home_model" initialized
INFO - 2023-09-20 19:16:58 --> Helper loaded: download_helper
INFO - 2023-09-20 19:16:58 --> Helper loaded: form_helper
INFO - 2023-09-20 19:16:58 --> Form Validation Class Initialized
INFO - 2023-09-20 19:16:58 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:16:58 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:16:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:16:58 --> Final output sent to browser
DEBUG - 2023-09-20 19:16:58 --> Total execution time: 0.1022
INFO - 2023-09-20 19:17:23 --> Config Class Initialized
INFO - 2023-09-20 19:17:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:17:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:17:23 --> Utf8 Class Initialized
INFO - 2023-09-20 19:17:23 --> URI Class Initialized
INFO - 2023-09-20 19:17:23 --> Router Class Initialized
INFO - 2023-09-20 19:17:23 --> Output Class Initialized
INFO - 2023-09-20 19:17:23 --> Security Class Initialized
DEBUG - 2023-09-20 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:17:23 --> Input Class Initialized
INFO - 2023-09-20 19:17:23 --> Language Class Initialized
INFO - 2023-09-20 19:17:23 --> Loader Class Initialized
INFO - 2023-09-20 19:17:23 --> Helper loaded: url_helper
INFO - 2023-09-20 19:17:23 --> Helper loaded: file_helper
INFO - 2023-09-20 19:17:23 --> Database Driver Class Initialized
INFO - 2023-09-20 19:17:23 --> Email Class Initialized
DEBUG - 2023-09-20 19:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:17:23 --> Controller Class Initialized
INFO - 2023-09-20 19:17:23 --> Model "Services_model" initialized
INFO - 2023-09-20 19:17:23 --> Helper loaded: form_helper
INFO - 2023-09-20 19:17:23 --> Form Validation Class Initialized
INFO - 2023-09-20 19:17:23 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:17:23 --> Final output sent to browser
DEBUG - 2023-09-20 19:17:23 --> Total execution time: 0.0919
INFO - 2023-09-20 19:17:33 --> Config Class Initialized
INFO - 2023-09-20 19:17:33 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:17:33 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:17:33 --> Utf8 Class Initialized
INFO - 2023-09-20 19:17:33 --> URI Class Initialized
INFO - 2023-09-20 19:17:33 --> Router Class Initialized
INFO - 2023-09-20 19:17:33 --> Output Class Initialized
INFO - 2023-09-20 19:17:33 --> Security Class Initialized
DEBUG - 2023-09-20 19:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:17:33 --> Input Class Initialized
INFO - 2023-09-20 19:17:33 --> Language Class Initialized
INFO - 2023-09-20 19:17:33 --> Loader Class Initialized
INFO - 2023-09-20 19:17:33 --> Helper loaded: url_helper
INFO - 2023-09-20 19:17:33 --> Helper loaded: file_helper
INFO - 2023-09-20 19:17:33 --> Database Driver Class Initialized
INFO - 2023-09-20 19:17:33 --> Email Class Initialized
DEBUG - 2023-09-20 19:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:17:33 --> Controller Class Initialized
INFO - 2023-09-20 19:17:33 --> Model "Services_model" initialized
INFO - 2023-09-20 19:17:33 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:17:33 --> Helper loaded: form_helper
INFO - 2023-09-20 19:17:33 --> Form Validation Class Initialized
INFO - 2023-09-20 19:17:33 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:17:33 --> Final output sent to browser
DEBUG - 2023-09-20 19:17:33 --> Total execution time: 0.1311
INFO - 2023-09-20 19:18:19 --> Config Class Initialized
INFO - 2023-09-20 19:18:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:18:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:18:19 --> Utf8 Class Initialized
INFO - 2023-09-20 19:18:19 --> URI Class Initialized
INFO - 2023-09-20 19:18:19 --> Router Class Initialized
INFO - 2023-09-20 19:18:19 --> Output Class Initialized
INFO - 2023-09-20 19:18:19 --> Security Class Initialized
DEBUG - 2023-09-20 19:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:18:19 --> Input Class Initialized
INFO - 2023-09-20 19:18:19 --> Language Class Initialized
INFO - 2023-09-20 19:18:19 --> Loader Class Initialized
INFO - 2023-09-20 19:18:19 --> Helper loaded: url_helper
INFO - 2023-09-20 19:18:19 --> Helper loaded: file_helper
INFO - 2023-09-20 19:18:20 --> Database Driver Class Initialized
INFO - 2023-09-20 19:18:20 --> Email Class Initialized
DEBUG - 2023-09-20 19:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:18:20 --> Controller Class Initialized
INFO - 2023-09-20 19:18:20 --> Model "Services_model" initialized
INFO - 2023-09-20 19:18:20 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:18:20 --> Helper loaded: form_helper
INFO - 2023-09-20 19:18:20 --> Form Validation Class Initialized
INFO - 2023-09-20 19:18:20 --> Config Class Initialized
INFO - 2023-09-20 19:18:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:18:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:18:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:18:20 --> URI Class Initialized
INFO - 2023-09-20 19:18:20 --> Router Class Initialized
INFO - 2023-09-20 19:18:20 --> Output Class Initialized
INFO - 2023-09-20 19:18:20 --> Security Class Initialized
DEBUG - 2023-09-20 19:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:18:20 --> Input Class Initialized
INFO - 2023-09-20 19:18:20 --> Language Class Initialized
INFO - 2023-09-20 19:18:20 --> Loader Class Initialized
INFO - 2023-09-20 19:18:20 --> Helper loaded: url_helper
INFO - 2023-09-20 19:18:20 --> Helper loaded: file_helper
INFO - 2023-09-20 19:18:20 --> Database Driver Class Initialized
INFO - 2023-09-20 19:18:20 --> Email Class Initialized
DEBUG - 2023-09-20 19:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:18:20 --> Controller Class Initialized
INFO - 2023-09-20 19:18:20 --> Model "Services_model" initialized
INFO - 2023-09-20 19:18:20 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:18:20 --> Helper loaded: form_helper
INFO - 2023-09-20 19:18:20 --> Form Validation Class Initialized
INFO - 2023-09-20 19:18:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:18:20 --> Final output sent to browser
DEBUG - 2023-09-20 19:18:20 --> Total execution time: 0.1149
INFO - 2023-09-20 19:18:25 --> Config Class Initialized
INFO - 2023-09-20 19:18:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:18:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:18:25 --> Utf8 Class Initialized
INFO - 2023-09-20 19:18:25 --> URI Class Initialized
INFO - 2023-09-20 19:18:25 --> Router Class Initialized
INFO - 2023-09-20 19:18:25 --> Output Class Initialized
INFO - 2023-09-20 19:18:25 --> Security Class Initialized
DEBUG - 2023-09-20 19:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:18:25 --> Input Class Initialized
INFO - 2023-09-20 19:18:25 --> Language Class Initialized
INFO - 2023-09-20 19:18:25 --> Loader Class Initialized
INFO - 2023-09-20 19:18:25 --> Helper loaded: url_helper
INFO - 2023-09-20 19:18:25 --> Helper loaded: file_helper
INFO - 2023-09-20 19:18:25 --> Database Driver Class Initialized
INFO - 2023-09-20 19:18:25 --> Email Class Initialized
DEBUG - 2023-09-20 19:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:18:25 --> Controller Class Initialized
INFO - 2023-09-20 19:18:25 --> Model "Services_model" initialized
INFO - 2023-09-20 19:18:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:18:25 --> Helper loaded: form_helper
INFO - 2023-09-20 19:18:25 --> Form Validation Class Initialized
INFO - 2023-09-20 19:18:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:18:25 --> Final output sent to browser
DEBUG - 2023-09-20 19:18:25 --> Total execution time: 0.0584
INFO - 2023-09-20 19:18:25 --> Config Class Initialized
INFO - 2023-09-20 19:18:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:18:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:18:25 --> Utf8 Class Initialized
INFO - 2023-09-20 19:18:25 --> URI Class Initialized
INFO - 2023-09-20 19:18:25 --> Router Class Initialized
INFO - 2023-09-20 19:18:25 --> Output Class Initialized
INFO - 2023-09-20 19:18:25 --> Security Class Initialized
DEBUG - 2023-09-20 19:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:18:25 --> Input Class Initialized
INFO - 2023-09-20 19:18:25 --> Language Class Initialized
INFO - 2023-09-20 19:18:25 --> Loader Class Initialized
INFO - 2023-09-20 19:18:25 --> Helper loaded: url_helper
INFO - 2023-09-20 19:18:25 --> Helper loaded: file_helper
INFO - 2023-09-20 19:18:25 --> Database Driver Class Initialized
INFO - 2023-09-20 19:18:25 --> Email Class Initialized
DEBUG - 2023-09-20 19:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:18:25 --> Controller Class Initialized
INFO - 2023-09-20 19:18:25 --> Model "Services_model" initialized
INFO - 2023-09-20 19:18:25 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:18:25 --> Helper loaded: form_helper
INFO - 2023-09-20 19:18:25 --> Form Validation Class Initialized
INFO - 2023-09-20 19:18:25 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_create.php
INFO - 2023-09-20 19:18:25 --> Final output sent to browser
DEBUG - 2023-09-20 19:18:25 --> Total execution time: 0.0943
INFO - 2023-09-20 19:19:17 --> Config Class Initialized
INFO - 2023-09-20 19:19:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:19:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:19:17 --> Utf8 Class Initialized
INFO - 2023-09-20 19:19:17 --> URI Class Initialized
INFO - 2023-09-20 19:19:17 --> Router Class Initialized
INFO - 2023-09-20 19:19:17 --> Output Class Initialized
INFO - 2023-09-20 19:19:17 --> Security Class Initialized
DEBUG - 2023-09-20 19:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:19:17 --> Input Class Initialized
INFO - 2023-09-20 19:19:17 --> Language Class Initialized
INFO - 2023-09-20 19:19:17 --> Loader Class Initialized
INFO - 2023-09-20 19:19:17 --> Helper loaded: url_helper
INFO - 2023-09-20 19:19:17 --> Helper loaded: file_helper
INFO - 2023-09-20 19:19:17 --> Database Driver Class Initialized
INFO - 2023-09-20 19:19:17 --> Email Class Initialized
DEBUG - 2023-09-20 19:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:19:17 --> Controller Class Initialized
INFO - 2023-09-20 19:19:17 --> Model "Services_model" initialized
INFO - 2023-09-20 19:19:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:19:17 --> Helper loaded: form_helper
INFO - 2023-09-20 19:19:17 --> Form Validation Class Initialized
INFO - 2023-09-20 19:19:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:19:17 --> Config Class Initialized
INFO - 2023-09-20 19:19:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:19:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:19:17 --> Utf8 Class Initialized
INFO - 2023-09-20 19:19:17 --> URI Class Initialized
INFO - 2023-09-20 19:19:17 --> Router Class Initialized
INFO - 2023-09-20 19:19:17 --> Output Class Initialized
INFO - 2023-09-20 19:19:17 --> Security Class Initialized
DEBUG - 2023-09-20 19:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:19:17 --> Input Class Initialized
INFO - 2023-09-20 19:19:17 --> Language Class Initialized
INFO - 2023-09-20 19:19:17 --> Loader Class Initialized
INFO - 2023-09-20 19:19:17 --> Helper loaded: url_helper
INFO - 2023-09-20 19:19:17 --> Helper loaded: file_helper
INFO - 2023-09-20 19:19:17 --> Database Driver Class Initialized
INFO - 2023-09-20 19:19:17 --> Email Class Initialized
DEBUG - 2023-09-20 19:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:19:17 --> Controller Class Initialized
INFO - 2023-09-20 19:19:17 --> Model "Services_model" initialized
INFO - 2023-09-20 19:19:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 19:19:17 --> Helper loaded: form_helper
INFO - 2023-09-20 19:19:17 --> Form Validation Class Initialized
INFO - 2023-09-20 19:19:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 19:19:17 --> Final output sent to browser
DEBUG - 2023-09-20 19:19:18 --> Total execution time: 0.1353
INFO - 2023-09-20 19:19:24 --> Config Class Initialized
INFO - 2023-09-20 19:19:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:19:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:19:24 --> Utf8 Class Initialized
INFO - 2023-09-20 19:19:24 --> URI Class Initialized
INFO - 2023-09-20 19:19:24 --> Router Class Initialized
INFO - 2023-09-20 19:19:24 --> Output Class Initialized
INFO - 2023-09-20 19:19:24 --> Security Class Initialized
DEBUG - 2023-09-20 19:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:19:24 --> Input Class Initialized
INFO - 2023-09-20 19:19:24 --> Language Class Initialized
INFO - 2023-09-20 19:19:24 --> Loader Class Initialized
INFO - 2023-09-20 19:19:24 --> Helper loaded: url_helper
INFO - 2023-09-20 19:19:24 --> Helper loaded: file_helper
INFO - 2023-09-20 19:19:24 --> Database Driver Class Initialized
INFO - 2023-09-20 19:19:24 --> Email Class Initialized
DEBUG - 2023-09-20 19:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:19:24 --> Controller Class Initialized
INFO - 2023-09-20 19:19:24 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:19:24 --> Model "Home_model" initialized
INFO - 2023-09-20 19:19:24 --> Helper loaded: download_helper
INFO - 2023-09-20 19:19:24 --> Helper loaded: form_helper
INFO - 2023-09-20 19:19:24 --> Form Validation Class Initialized
INFO - 2023-09-20 19:19:24 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:19:24 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:19:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:19:24 --> Final output sent to browser
DEBUG - 2023-09-20 19:19:24 --> Total execution time: 0.1178
INFO - 2023-09-20 19:20:18 --> Config Class Initialized
INFO - 2023-09-20 19:20:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:20:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:20:18 --> Utf8 Class Initialized
INFO - 2023-09-20 19:20:18 --> URI Class Initialized
INFO - 2023-09-20 19:20:18 --> Router Class Initialized
INFO - 2023-09-20 19:20:18 --> Output Class Initialized
INFO - 2023-09-20 19:20:18 --> Security Class Initialized
DEBUG - 2023-09-20 19:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:20:18 --> Input Class Initialized
INFO - 2023-09-20 19:20:18 --> Language Class Initialized
INFO - 2023-09-20 19:20:18 --> Loader Class Initialized
INFO - 2023-09-20 19:20:18 --> Helper loaded: url_helper
INFO - 2023-09-20 19:20:18 --> Helper loaded: file_helper
INFO - 2023-09-20 19:20:18 --> Database Driver Class Initialized
INFO - 2023-09-20 19:20:18 --> Email Class Initialized
DEBUG - 2023-09-20 19:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:20:18 --> Controller Class Initialized
INFO - 2023-09-20 19:20:18 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:20:18 --> Model "Home_model" initialized
INFO - 2023-09-20 19:20:18 --> Helper loaded: download_helper
INFO - 2023-09-20 19:20:18 --> Helper loaded: form_helper
INFO - 2023-09-20 19:20:18 --> Form Validation Class Initialized
INFO - 2023-09-20 19:20:18 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:20:18 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:20:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:20:18 --> Final output sent to browser
DEBUG - 2023-09-20 19:20:18 --> Total execution time: 0.1156
INFO - 2023-09-20 19:21:00 --> Config Class Initialized
INFO - 2023-09-20 19:21:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:21:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:21:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:21:00 --> URI Class Initialized
INFO - 2023-09-20 19:21:00 --> Router Class Initialized
INFO - 2023-09-20 19:21:00 --> Output Class Initialized
INFO - 2023-09-20 19:21:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:21:00 --> Input Class Initialized
INFO - 2023-09-20 19:21:00 --> Language Class Initialized
INFO - 2023-09-20 19:21:00 --> Loader Class Initialized
INFO - 2023-09-20 19:21:00 --> Helper loaded: url_helper
INFO - 2023-09-20 19:21:00 --> Helper loaded: file_helper
INFO - 2023-09-20 19:21:00 --> Database Driver Class Initialized
INFO - 2023-09-20 19:21:00 --> Email Class Initialized
DEBUG - 2023-09-20 19:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:21:00 --> Controller Class Initialized
INFO - 2023-09-20 19:21:00 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:21:00 --> Model "Home_model" initialized
INFO - 2023-09-20 19:21:00 --> Helper loaded: download_helper
INFO - 2023-09-20 19:21:00 --> Helper loaded: form_helper
INFO - 2023-09-20 19:21:00 --> Form Validation Class Initialized
INFO - 2023-09-20 19:21:00 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:21:00 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:21:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:21:00 --> Final output sent to browser
DEBUG - 2023-09-20 19:21:01 --> Total execution time: 0.2367
INFO - 2023-09-20 19:21:57 --> Config Class Initialized
INFO - 2023-09-20 19:21:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:21:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:21:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:21:57 --> URI Class Initialized
INFO - 2023-09-20 19:21:57 --> Router Class Initialized
INFO - 2023-09-20 19:21:57 --> Output Class Initialized
INFO - 2023-09-20 19:21:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:21:57 --> Input Class Initialized
INFO - 2023-09-20 19:21:57 --> Language Class Initialized
INFO - 2023-09-20 19:21:57 --> Loader Class Initialized
INFO - 2023-09-20 19:21:57 --> Helper loaded: url_helper
INFO - 2023-09-20 19:21:57 --> Helper loaded: file_helper
INFO - 2023-09-20 19:21:57 --> Database Driver Class Initialized
INFO - 2023-09-20 19:21:57 --> Email Class Initialized
DEBUG - 2023-09-20 19:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:21:57 --> Controller Class Initialized
INFO - 2023-09-20 19:21:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:21:57 --> Model "Home_model" initialized
INFO - 2023-09-20 19:21:57 --> Helper loaded: download_helper
INFO - 2023-09-20 19:21:57 --> Helper loaded: form_helper
INFO - 2023-09-20 19:21:57 --> Form Validation Class Initialized
INFO - 2023-09-20 19:21:57 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:21:57 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:21:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:21:57 --> Final output sent to browser
DEBUG - 2023-09-20 19:21:57 --> Total execution time: 0.1282
INFO - 2023-09-20 19:24:39 --> Config Class Initialized
INFO - 2023-09-20 19:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:24:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:24:39 --> URI Class Initialized
INFO - 2023-09-20 19:24:39 --> Router Class Initialized
INFO - 2023-09-20 19:24:39 --> Output Class Initialized
INFO - 2023-09-20 19:24:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:24:39 --> Input Class Initialized
INFO - 2023-09-20 19:24:39 --> Language Class Initialized
INFO - 2023-09-20 19:24:39 --> Loader Class Initialized
INFO - 2023-09-20 19:24:39 --> Helper loaded: url_helper
INFO - 2023-09-20 19:24:39 --> Helper loaded: file_helper
INFO - 2023-09-20 19:24:39 --> Database Driver Class Initialized
INFO - 2023-09-20 19:24:39 --> Email Class Initialized
DEBUG - 2023-09-20 19:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:24:39 --> Controller Class Initialized
INFO - 2023-09-20 19:24:39 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:24:39 --> Model "Home_model" initialized
INFO - 2023-09-20 19:24:39 --> Helper loaded: download_helper
INFO - 2023-09-20 19:24:39 --> Helper loaded: form_helper
INFO - 2023-09-20 19:24:39 --> Form Validation Class Initialized
INFO - 2023-09-20 19:24:40 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:24:40 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:24:40 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:24:40 --> Final output sent to browser
DEBUG - 2023-09-20 19:24:40 --> Total execution time: 0.3670
INFO - 2023-09-20 19:24:44 --> Config Class Initialized
INFO - 2023-09-20 19:24:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:24:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:24:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:24:44 --> URI Class Initialized
INFO - 2023-09-20 19:24:44 --> Router Class Initialized
INFO - 2023-09-20 19:24:44 --> Output Class Initialized
INFO - 2023-09-20 19:24:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:24:44 --> Input Class Initialized
INFO - 2023-09-20 19:24:44 --> Language Class Initialized
INFO - 2023-09-20 19:24:44 --> Loader Class Initialized
INFO - 2023-09-20 19:24:44 --> Helper loaded: url_helper
INFO - 2023-09-20 19:24:44 --> Helper loaded: file_helper
INFO - 2023-09-20 19:24:44 --> Database Driver Class Initialized
INFO - 2023-09-20 19:24:44 --> Email Class Initialized
DEBUG - 2023-09-20 19:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:24:44 --> Controller Class Initialized
INFO - 2023-09-20 19:24:44 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:24:44 --> Model "Home_model" initialized
INFO - 2023-09-20 19:24:44 --> Helper loaded: download_helper
INFO - 2023-09-20 19:24:44 --> Helper loaded: form_helper
INFO - 2023-09-20 19:24:44 --> Form Validation Class Initialized
INFO - 2023-09-20 19:24:44 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:24:44 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:24:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:24:44 --> Final output sent to browser
DEBUG - 2023-09-20 19:24:44 --> Total execution time: 0.1628
INFO - 2023-09-20 19:25:09 --> Config Class Initialized
INFO - 2023-09-20 19:25:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:25:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:25:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:25:09 --> URI Class Initialized
DEBUG - 2023-09-20 19:25:09 --> No URI present. Default controller set.
INFO - 2023-09-20 19:25:09 --> Router Class Initialized
INFO - 2023-09-20 19:25:09 --> Output Class Initialized
INFO - 2023-09-20 19:25:09 --> Security Class Initialized
DEBUG - 2023-09-20 19:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:25:09 --> Input Class Initialized
INFO - 2023-09-20 19:25:09 --> Language Class Initialized
INFO - 2023-09-20 19:25:09 --> Loader Class Initialized
INFO - 2023-09-20 19:25:09 --> Helper loaded: url_helper
INFO - 2023-09-20 19:25:09 --> Helper loaded: file_helper
INFO - 2023-09-20 19:25:09 --> Database Driver Class Initialized
INFO - 2023-09-20 19:25:09 --> Email Class Initialized
DEBUG - 2023-09-20 19:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:25:09 --> Controller Class Initialized
INFO - 2023-09-20 19:25:09 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:25:09 --> Model "Home_model" initialized
INFO - 2023-09-20 19:25:09 --> Helper loaded: download_helper
INFO - 2023-09-20 19:25:09 --> Helper loaded: form_helper
INFO - 2023-09-20 19:25:09 --> Form Validation Class Initialized
INFO - 2023-09-20 19:25:09 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:25:09 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:25:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:25:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:25:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:25:09 --> Final output sent to browser
DEBUG - 2023-09-20 19:25:09 --> Total execution time: 0.1142
INFO - 2023-09-20 19:27:57 --> Config Class Initialized
INFO - 2023-09-20 19:27:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:27:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:27:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:27:57 --> URI Class Initialized
DEBUG - 2023-09-20 19:27:57 --> No URI present. Default controller set.
INFO - 2023-09-20 19:27:57 --> Router Class Initialized
INFO - 2023-09-20 19:27:57 --> Output Class Initialized
INFO - 2023-09-20 19:27:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:27:57 --> Input Class Initialized
INFO - 2023-09-20 19:27:57 --> Language Class Initialized
INFO - 2023-09-20 19:27:57 --> Loader Class Initialized
INFO - 2023-09-20 19:27:57 --> Helper loaded: url_helper
INFO - 2023-09-20 19:27:57 --> Helper loaded: file_helper
INFO - 2023-09-20 19:27:57 --> Database Driver Class Initialized
INFO - 2023-09-20 19:27:57 --> Email Class Initialized
DEBUG - 2023-09-20 19:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:27:57 --> Controller Class Initialized
INFO - 2023-09-20 19:27:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:27:57 --> Model "Home_model" initialized
INFO - 2023-09-20 19:27:57 --> Helper loaded: download_helper
INFO - 2023-09-20 19:27:57 --> Helper loaded: form_helper
INFO - 2023-09-20 19:27:57 --> Form Validation Class Initialized
INFO - 2023-09-20 19:27:57 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:27:57 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 19:27:57 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 19:27:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 19:27:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 19:27:57 --> Final output sent to browser
DEBUG - 2023-09-20 19:27:57 --> Total execution time: 0.1968
INFO - 2023-09-20 19:28:39 --> Config Class Initialized
INFO - 2023-09-20 19:28:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:28:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:28:39 --> Utf8 Class Initialized
INFO - 2023-09-20 19:28:39 --> URI Class Initialized
INFO - 2023-09-20 19:28:39 --> Router Class Initialized
INFO - 2023-09-20 19:28:39 --> Output Class Initialized
INFO - 2023-09-20 19:28:39 --> Security Class Initialized
DEBUG - 2023-09-20 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:28:39 --> Input Class Initialized
INFO - 2023-09-20 19:28:39 --> Language Class Initialized
INFO - 2023-09-20 19:28:39 --> Loader Class Initialized
INFO - 2023-09-20 19:28:39 --> Helper loaded: url_helper
INFO - 2023-09-20 19:28:39 --> Helper loaded: file_helper
INFO - 2023-09-20 19:28:39 --> Database Driver Class Initialized
INFO - 2023-09-20 19:28:39 --> Email Class Initialized
DEBUG - 2023-09-20 19:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:28:39 --> Controller Class Initialized
INFO - 2023-09-20 19:28:39 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:28:39 --> Model "Home_model" initialized
INFO - 2023-09-20 19:28:39 --> Helper loaded: download_helper
INFO - 2023-09-20 19:28:39 --> Helper loaded: form_helper
INFO - 2023-09-20 19:28:39 --> Form Validation Class Initialized
INFO - 2023-09-20 19:28:39 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:28:39 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:28:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:28:39 --> Final output sent to browser
DEBUG - 2023-09-20 19:28:39 --> Total execution time: 0.1350
INFO - 2023-09-20 19:28:42 --> Config Class Initialized
INFO - 2023-09-20 19:28:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:28:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:28:42 --> Utf8 Class Initialized
INFO - 2023-09-20 19:28:42 --> URI Class Initialized
INFO - 2023-09-20 19:28:42 --> Router Class Initialized
INFO - 2023-09-20 19:28:42 --> Output Class Initialized
INFO - 2023-09-20 19:28:42 --> Security Class Initialized
DEBUG - 2023-09-20 19:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:28:42 --> Input Class Initialized
INFO - 2023-09-20 19:28:42 --> Language Class Initialized
INFO - 2023-09-20 19:28:42 --> Loader Class Initialized
INFO - 2023-09-20 19:28:42 --> Helper loaded: url_helper
INFO - 2023-09-20 19:28:42 --> Helper loaded: file_helper
INFO - 2023-09-20 19:28:42 --> Database Driver Class Initialized
INFO - 2023-09-20 19:28:42 --> Email Class Initialized
DEBUG - 2023-09-20 19:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:28:42 --> Controller Class Initialized
INFO - 2023-09-20 19:28:42 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:28:42 --> Model "Home_model" initialized
INFO - 2023-09-20 19:28:42 --> Helper loaded: download_helper
INFO - 2023-09-20 19:28:42 --> Helper loaded: form_helper
INFO - 2023-09-20 19:28:42 --> Form Validation Class Initialized
INFO - 2023-09-20 19:28:42 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:28:42 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:28:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:28:42 --> Final output sent to browser
DEBUG - 2023-09-20 19:28:42 --> Total execution time: 0.0701
INFO - 2023-09-20 19:29:32 --> Config Class Initialized
INFO - 2023-09-20 19:29:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:29:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:29:32 --> Utf8 Class Initialized
INFO - 2023-09-20 19:29:32 --> URI Class Initialized
INFO - 2023-09-20 19:29:32 --> Router Class Initialized
INFO - 2023-09-20 19:29:32 --> Output Class Initialized
INFO - 2023-09-20 19:29:32 --> Security Class Initialized
DEBUG - 2023-09-20 19:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:29:32 --> Input Class Initialized
INFO - 2023-09-20 19:29:32 --> Language Class Initialized
INFO - 2023-09-20 19:29:32 --> Loader Class Initialized
INFO - 2023-09-20 19:29:32 --> Helper loaded: url_helper
INFO - 2023-09-20 19:29:32 --> Helper loaded: file_helper
INFO - 2023-09-20 19:29:32 --> Database Driver Class Initialized
INFO - 2023-09-20 19:29:32 --> Email Class Initialized
DEBUG - 2023-09-20 19:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:29:32 --> Controller Class Initialized
INFO - 2023-09-20 19:29:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:29:32 --> Model "Home_model" initialized
INFO - 2023-09-20 19:29:32 --> Helper loaded: download_helper
INFO - 2023-09-20 19:29:32 --> Helper loaded: form_helper
INFO - 2023-09-20 19:29:32 --> Form Validation Class Initialized
INFO - 2023-09-20 19:29:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:29:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:29:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:29:32 --> Final output sent to browser
DEBUG - 2023-09-20 19:29:32 --> Total execution time: 0.1386
INFO - 2023-09-20 19:31:20 --> Config Class Initialized
INFO - 2023-09-20 19:31:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:31:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:31:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:31:20 --> URI Class Initialized
INFO - 2023-09-20 19:31:20 --> Router Class Initialized
INFO - 2023-09-20 19:31:20 --> Output Class Initialized
INFO - 2023-09-20 19:31:20 --> Security Class Initialized
DEBUG - 2023-09-20 19:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:31:20 --> Input Class Initialized
INFO - 2023-09-20 19:31:20 --> Language Class Initialized
INFO - 2023-09-20 19:31:20 --> Loader Class Initialized
INFO - 2023-09-20 19:31:20 --> Helper loaded: url_helper
INFO - 2023-09-20 19:31:20 --> Helper loaded: file_helper
INFO - 2023-09-20 19:31:20 --> Database Driver Class Initialized
INFO - 2023-09-20 19:31:20 --> Email Class Initialized
DEBUG - 2023-09-20 19:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:31:20 --> Controller Class Initialized
INFO - 2023-09-20 19:31:20 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:31:20 --> Model "Home_model" initialized
INFO - 2023-09-20 19:31:20 --> Helper loaded: download_helper
INFO - 2023-09-20 19:31:20 --> Helper loaded: form_helper
INFO - 2023-09-20 19:31:20 --> Form Validation Class Initialized
INFO - 2023-09-20 19:31:20 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:31:20 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:31:20 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:31:20 --> Final output sent to browser
DEBUG - 2023-09-20 19:31:20 --> Total execution time: 0.1491
INFO - 2023-09-20 19:31:50 --> Config Class Initialized
INFO - 2023-09-20 19:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:31:50 --> Utf8 Class Initialized
INFO - 2023-09-20 19:31:50 --> URI Class Initialized
INFO - 2023-09-20 19:31:50 --> Router Class Initialized
INFO - 2023-09-20 19:31:50 --> Output Class Initialized
INFO - 2023-09-20 19:31:50 --> Security Class Initialized
DEBUG - 2023-09-20 19:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:31:50 --> Input Class Initialized
INFO - 2023-09-20 19:31:50 --> Language Class Initialized
INFO - 2023-09-20 19:31:50 --> Loader Class Initialized
INFO - 2023-09-20 19:31:50 --> Helper loaded: url_helper
INFO - 2023-09-20 19:31:50 --> Helper loaded: file_helper
INFO - 2023-09-20 19:31:50 --> Database Driver Class Initialized
INFO - 2023-09-20 19:31:50 --> Email Class Initialized
DEBUG - 2023-09-20 19:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:31:50 --> Controller Class Initialized
INFO - 2023-09-20 19:31:50 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:31:50 --> Model "Home_model" initialized
INFO - 2023-09-20 19:31:50 --> Helper loaded: download_helper
INFO - 2023-09-20 19:31:50 --> Helper loaded: form_helper
INFO - 2023-09-20 19:31:50 --> Form Validation Class Initialized
INFO - 2023-09-20 19:31:50 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:31:50 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:31:50 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:31:50 --> Final output sent to browser
DEBUG - 2023-09-20 19:31:50 --> Total execution time: 0.1340
INFO - 2023-09-20 19:32:04 --> Config Class Initialized
INFO - 2023-09-20 19:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:05 --> URI Class Initialized
INFO - 2023-09-20 19:32:05 --> Router Class Initialized
INFO - 2023-09-20 19:32:05 --> Output Class Initialized
INFO - 2023-09-20 19:32:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:05 --> Input Class Initialized
INFO - 2023-09-20 19:32:05 --> Language Class Initialized
ERROR - 2023-09-20 19:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:05 --> Config Class Initialized
INFO - 2023-09-20 19:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:05 --> URI Class Initialized
INFO - 2023-09-20 19:32:05 --> Router Class Initialized
INFO - 2023-09-20 19:32:05 --> Output Class Initialized
INFO - 2023-09-20 19:32:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:05 --> Input Class Initialized
INFO - 2023-09-20 19:32:05 --> Language Class Initialized
ERROR - 2023-09-20 19:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:05 --> Config Class Initialized
INFO - 2023-09-20 19:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:05 --> URI Class Initialized
INFO - 2023-09-20 19:32:05 --> Router Class Initialized
INFO - 2023-09-20 19:32:05 --> Output Class Initialized
INFO - 2023-09-20 19:32:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:05 --> Input Class Initialized
INFO - 2023-09-20 19:32:05 --> Language Class Initialized
ERROR - 2023-09-20 19:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:05 --> Config Class Initialized
INFO - 2023-09-20 19:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:05 --> URI Class Initialized
INFO - 2023-09-20 19:32:05 --> Router Class Initialized
INFO - 2023-09-20 19:32:05 --> Output Class Initialized
INFO - 2023-09-20 19:32:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:05 --> Input Class Initialized
INFO - 2023-09-20 19:32:05 --> Language Class Initialized
ERROR - 2023-09-20 19:32:05 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:06 --> Config Class Initialized
INFO - 2023-09-20 19:32:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:07 --> URI Class Initialized
INFO - 2023-09-20 19:32:07 --> Router Class Initialized
INFO - 2023-09-20 19:32:07 --> Output Class Initialized
INFO - 2023-09-20 19:32:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:07 --> Input Class Initialized
INFO - 2023-09-20 19:32:07 --> Language Class Initialized
ERROR - 2023-09-20 19:32:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:08 --> Config Class Initialized
INFO - 2023-09-20 19:32:08 --> Config Class Initialized
INFO - 2023-09-20 19:32:08 --> Hooks Class Initialized
INFO - 2023-09-20 19:32:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:32:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:32:08 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:08 --> Utf8 Class Initialized
INFO - 2023-09-20 19:32:08 --> URI Class Initialized
INFO - 2023-09-20 19:32:08 --> URI Class Initialized
INFO - 2023-09-20 19:32:08 --> Router Class Initialized
INFO - 2023-09-20 19:32:08 --> Router Class Initialized
INFO - 2023-09-20 19:32:08 --> Output Class Initialized
INFO - 2023-09-20 19:32:08 --> Security Class Initialized
INFO - 2023-09-20 19:32:08 --> Output Class Initialized
DEBUG - 2023-09-20 19:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:08 --> Security Class Initialized
INFO - 2023-09-20 19:32:08 --> Input Class Initialized
DEBUG - 2023-09-20 19:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:32:08 --> Language Class Initialized
INFO - 2023-09-20 19:32:08 --> Input Class Initialized
ERROR - 2023-09-20 19:32:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:32:08 --> Language Class Initialized
ERROR - 2023-09-20 19:32:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:33:59 --> Config Class Initialized
INFO - 2023-09-20 19:33:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:33:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:33:59 --> Utf8 Class Initialized
INFO - 2023-09-20 19:33:59 --> URI Class Initialized
INFO - 2023-09-20 19:33:59 --> Router Class Initialized
INFO - 2023-09-20 19:33:59 --> Output Class Initialized
INFO - 2023-09-20 19:33:59 --> Security Class Initialized
DEBUG - 2023-09-20 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:33:59 --> Input Class Initialized
INFO - 2023-09-20 19:33:59 --> Language Class Initialized
INFO - 2023-09-20 19:33:59 --> Loader Class Initialized
INFO - 2023-09-20 19:33:59 --> Helper loaded: url_helper
INFO - 2023-09-20 19:33:59 --> Helper loaded: file_helper
INFO - 2023-09-20 19:33:59 --> Database Driver Class Initialized
INFO - 2023-09-20 19:33:59 --> Email Class Initialized
DEBUG - 2023-09-20 19:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:33:59 --> Controller Class Initialized
INFO - 2023-09-20 19:33:59 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:33:59 --> Model "Home_model" initialized
INFO - 2023-09-20 19:33:59 --> Helper loaded: download_helper
INFO - 2023-09-20 19:33:59 --> Helper loaded: form_helper
INFO - 2023-09-20 19:33:59 --> Form Validation Class Initialized
INFO - 2023-09-20 19:33:59 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:33:59 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:33:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:33:59 --> Final output sent to browser
DEBUG - 2023-09-20 19:33:59 --> Total execution time: 0.1528
INFO - 2023-09-20 19:37:04 --> Config Class Initialized
INFO - 2023-09-20 19:37:04 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:04 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:04 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:04 --> URI Class Initialized
INFO - 2023-09-20 19:37:04 --> Router Class Initialized
INFO - 2023-09-20 19:37:04 --> Output Class Initialized
INFO - 2023-09-20 19:37:04 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:04 --> Input Class Initialized
INFO - 2023-09-20 19:37:04 --> Language Class Initialized
INFO - 2023-09-20 19:37:04 --> Loader Class Initialized
INFO - 2023-09-20 19:37:04 --> Helper loaded: url_helper
INFO - 2023-09-20 19:37:04 --> Helper loaded: file_helper
INFO - 2023-09-20 19:37:04 --> Database Driver Class Initialized
INFO - 2023-09-20 19:37:04 --> Email Class Initialized
DEBUG - 2023-09-20 19:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:37:04 --> Controller Class Initialized
INFO - 2023-09-20 19:37:04 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:37:04 --> Model "Home_model" initialized
INFO - 2023-09-20 19:37:04 --> Helper loaded: download_helper
INFO - 2023-09-20 19:37:04 --> Helper loaded: form_helper
INFO - 2023-09-20 19:37:04 --> Form Validation Class Initialized
INFO - 2023-09-20 19:37:04 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:37:04 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:37:04 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:37:04 --> Final output sent to browser
DEBUG - 2023-09-20 19:37:04 --> Total execution time: 0.1638
INFO - 2023-09-20 19:37:07 --> Config Class Initialized
INFO - 2023-09-20 19:37:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:07 --> URI Class Initialized
INFO - 2023-09-20 19:37:07 --> Router Class Initialized
INFO - 2023-09-20 19:37:07 --> Output Class Initialized
INFO - 2023-09-20 19:37:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:07 --> Input Class Initialized
INFO - 2023-09-20 19:37:07 --> Language Class Initialized
ERROR - 2023-09-20 19:37:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:37:44 --> Config Class Initialized
INFO - 2023-09-20 19:37:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:44 --> URI Class Initialized
INFO - 2023-09-20 19:37:44 --> Router Class Initialized
INFO - 2023-09-20 19:37:44 --> Output Class Initialized
INFO - 2023-09-20 19:37:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:44 --> Input Class Initialized
INFO - 2023-09-20 19:37:44 --> Language Class Initialized
INFO - 2023-09-20 19:37:44 --> Loader Class Initialized
INFO - 2023-09-20 19:37:44 --> Helper loaded: url_helper
INFO - 2023-09-20 19:37:44 --> Helper loaded: file_helper
INFO - 2023-09-20 19:37:45 --> Database Driver Class Initialized
INFO - 2023-09-20 19:37:45 --> Email Class Initialized
DEBUG - 2023-09-20 19:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:37:45 --> Controller Class Initialized
INFO - 2023-09-20 19:37:45 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:37:45 --> Model "Home_model" initialized
INFO - 2023-09-20 19:37:45 --> Helper loaded: download_helper
INFO - 2023-09-20 19:37:45 --> Helper loaded: form_helper
INFO - 2023-09-20 19:37:45 --> Form Validation Class Initialized
INFO - 2023-09-20 19:37:45 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:37:45 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:37:45 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:37:45 --> Final output sent to browser
DEBUG - 2023-09-20 19:37:45 --> Total execution time: 0.1460
INFO - 2023-09-20 19:37:47 --> Config Class Initialized
INFO - 2023-09-20 19:37:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:48 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:48 --> URI Class Initialized
INFO - 2023-09-20 19:37:48 --> Router Class Initialized
INFO - 2023-09-20 19:37:49 --> Output Class Initialized
INFO - 2023-09-20 19:37:49 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:49 --> Input Class Initialized
INFO - 2023-09-20 19:37:49 --> Language Class Initialized
ERROR - 2023-09-20 19:37:49 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:37:50 --> Config Class Initialized
INFO - 2023-09-20 19:37:50 --> Config Class Initialized
INFO - 2023-09-20 19:37:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:51 --> Config Class Initialized
INFO - 2023-09-20 19:37:51 --> Config Class Initialized
INFO - 2023-09-20 19:37:51 --> Hooks Class Initialized
INFO - 2023-09-20 19:37:51 --> Config Class Initialized
INFO - 2023-09-20 19:37:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:51 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:51 --> URI Class Initialized
INFO - 2023-09-20 19:37:51 --> Router Class Initialized
INFO - 2023-09-20 19:37:51 --> Output Class Initialized
INFO - 2023-09-20 19:37:51 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:51 --> Input Class Initialized
INFO - 2023-09-20 19:37:51 --> Language Class Initialized
ERROR - 2023-09-20 19:37:51 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:37:51 --> Config Class Initialized
INFO - 2023-09-20 19:37:51 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:37:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:52 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:52 --> Hooks Class Initialized
INFO - 2023-09-20 19:37:52 --> URI Class Initialized
INFO - 2023-09-20 19:37:53 --> Router Class Initialized
INFO - 2023-09-20 19:37:53 --> Hooks Class Initialized
INFO - 2023-09-20 19:37:53 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:53 --> URI Class Initialized
DEBUG - 2023-09-20 19:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:54 --> Utf8 Class Initialized
DEBUG - 2023-09-20 19:37:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:37:54 --> URI Class Initialized
INFO - 2023-09-20 19:37:54 --> Router Class Initialized
INFO - 2023-09-20 19:37:54 --> Output Class Initialized
INFO - 2023-09-20 19:37:54 --> Router Class Initialized
INFO - 2023-09-20 19:37:54 --> URI Class Initialized
INFO - 2023-09-20 19:37:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:37:54 --> Output Class Initialized
INFO - 2023-09-20 19:37:54 --> URI Class Initialized
INFO - 2023-09-20 19:37:54 --> Output Class Initialized
INFO - 2023-09-20 19:37:54 --> Router Class Initialized
INFO - 2023-09-20 19:37:54 --> Security Class Initialized
INFO - 2023-09-20 19:37:54 --> Security Class Initialized
INFO - 2023-09-20 19:37:54 --> Security Class Initialized
INFO - 2023-09-20 19:37:54 --> Router Class Initialized
INFO - 2023-09-20 19:37:54 --> Output Class Initialized
DEBUG - 2023-09-20 19:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:54 --> Input Class Initialized
INFO - 2023-09-20 19:37:54 --> Language Class Initialized
ERROR - 2023-09-20 19:37:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:54 --> Input Class Initialized
INFO - 2023-09-20 19:37:54 --> Output Class Initialized
INFO - 2023-09-20 19:37:54 --> Language Class Initialized
INFO - 2023-09-20 19:37:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 19:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:54 --> Input Class Initialized
INFO - 2023-09-20 19:37:54 --> Security Class Initialized
ERROR - 2023-09-20 19:37:54 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:37:54 --> Input Class Initialized
INFO - 2023-09-20 19:37:54 --> Language Class Initialized
INFO - 2023-09-20 19:37:54 --> Input Class Initialized
ERROR - 2023-09-20 19:37:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:37:54 --> Language Class Initialized
INFO - 2023-09-20 19:37:54 --> Language Class Initialized
ERROR - 2023-09-20 19:37:54 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:37:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:21 --> Config Class Initialized
INFO - 2023-09-20 19:38:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:21 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:21 --> URI Class Initialized
INFO - 2023-09-20 19:38:21 --> Router Class Initialized
INFO - 2023-09-20 19:38:21 --> Output Class Initialized
INFO - 2023-09-20 19:38:21 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:21 --> Input Class Initialized
INFO - 2023-09-20 19:38:21 --> Language Class Initialized
INFO - 2023-09-20 19:38:21 --> Loader Class Initialized
INFO - 2023-09-20 19:38:21 --> Helper loaded: url_helper
INFO - 2023-09-20 19:38:21 --> Helper loaded: file_helper
INFO - 2023-09-20 19:38:21 --> Database Driver Class Initialized
INFO - 2023-09-20 19:38:21 --> Email Class Initialized
DEBUG - 2023-09-20 19:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:38:21 --> Controller Class Initialized
INFO - 2023-09-20 19:38:21 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:38:21 --> Model "Home_model" initialized
INFO - 2023-09-20 19:38:21 --> Helper loaded: download_helper
INFO - 2023-09-20 19:38:21 --> Helper loaded: form_helper
INFO - 2023-09-20 19:38:21 --> Form Validation Class Initialized
INFO - 2023-09-20 19:38:21 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:38:21 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:38:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:38:21 --> Final output sent to browser
DEBUG - 2023-09-20 19:38:22 --> Total execution time: 0.1845
INFO - 2023-09-20 19:38:24 --> Config Class Initialized
INFO - 2023-09-20 19:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:25 --> Config Class Initialized
INFO - 2023-09-20 19:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:25 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:25 --> URI Class Initialized
INFO - 2023-09-20 19:38:25 --> Router Class Initialized
INFO - 2023-09-20 19:38:25 --> Output Class Initialized
INFO - 2023-09-20 19:38:25 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:25 --> Input Class Initialized
INFO - 2023-09-20 19:38:25 --> Language Class Initialized
ERROR - 2023-09-20 19:38:25 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:26 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:26 --> URI Class Initialized
INFO - 2023-09-20 19:38:26 --> Router Class Initialized
INFO - 2023-09-20 19:38:26 --> Output Class Initialized
INFO - 2023-09-20 19:38:26 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:26 --> Input Class Initialized
INFO - 2023-09-20 19:38:26 --> Language Class Initialized
ERROR - 2023-09-20 19:38:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:26 --> Config Class Initialized
INFO - 2023-09-20 19:38:26 --> Config Class Initialized
INFO - 2023-09-20 19:38:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:26 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:26 --> URI Class Initialized
INFO - 2023-09-20 19:38:26 --> Config Class Initialized
INFO - 2023-09-20 19:38:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:26 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:26 --> URI Class Initialized
INFO - 2023-09-20 19:38:26 --> Router Class Initialized
INFO - 2023-09-20 19:38:26 --> Output Class Initialized
INFO - 2023-09-20 19:38:26 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:26 --> Input Class Initialized
INFO - 2023-09-20 19:38:26 --> Language Class Initialized
ERROR - 2023-09-20 19:38:26 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:26 --> Config Class Initialized
INFO - 2023-09-20 19:38:26 --> Router Class Initialized
INFO - 2023-09-20 19:38:26 --> Hooks Class Initialized
INFO - 2023-09-20 19:38:27 --> Config Class Initialized
INFO - 2023-09-20 19:38:27 --> Hooks Class Initialized
INFO - 2023-09-20 19:38:28 --> Output Class Initialized
DEBUG - 2023-09-20 19:38:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:28 --> Security Class Initialized
INFO - 2023-09-20 19:38:28 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:29 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:29 --> URI Class Initialized
INFO - 2023-09-20 19:38:29 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:29 --> URI Class Initialized
INFO - 2023-09-20 19:38:29 --> Router Class Initialized
INFO - 2023-09-20 19:38:29 --> Output Class Initialized
INFO - 2023-09-20 19:38:29 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:29 --> Input Class Initialized
INFO - 2023-09-20 19:38:29 --> Language Class Initialized
ERROR - 2023-09-20 19:38:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:29 --> Input Class Initialized
INFO - 2023-09-20 19:38:30 --> Language Class Initialized
INFO - 2023-09-20 19:38:30 --> Router Class Initialized
INFO - 2023-09-20 19:38:30 --> URI Class Initialized
INFO - 2023-09-20 19:38:30 --> Output Class Initialized
INFO - 2023-09-20 19:38:30 --> Router Class Initialized
ERROR - 2023-09-20 19:38:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:30 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:30 --> Input Class Initialized
INFO - 2023-09-20 19:38:30 --> Language Class Initialized
ERROR - 2023-09-20 19:38:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:30 --> Output Class Initialized
INFO - 2023-09-20 19:38:30 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:30 --> Input Class Initialized
INFO - 2023-09-20 19:38:30 --> Language Class Initialized
ERROR - 2023-09-20 19:38:30 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:51 --> Config Class Initialized
INFO - 2023-09-20 19:38:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:51 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:51 --> URI Class Initialized
INFO - 2023-09-20 19:38:51 --> Router Class Initialized
INFO - 2023-09-20 19:38:51 --> Output Class Initialized
INFO - 2023-09-20 19:38:51 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:51 --> Input Class Initialized
INFO - 2023-09-20 19:38:51 --> Language Class Initialized
INFO - 2023-09-20 19:38:51 --> Loader Class Initialized
INFO - 2023-09-20 19:38:51 --> Helper loaded: url_helper
INFO - 2023-09-20 19:38:51 --> Helper loaded: file_helper
INFO - 2023-09-20 19:38:51 --> Database Driver Class Initialized
INFO - 2023-09-20 19:38:51 --> Email Class Initialized
DEBUG - 2023-09-20 19:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:38:51 --> Controller Class Initialized
INFO - 2023-09-20 19:38:51 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:38:51 --> Model "Home_model" initialized
INFO - 2023-09-20 19:38:51 --> Helper loaded: download_helper
INFO - 2023-09-20 19:38:51 --> Helper loaded: form_helper
INFO - 2023-09-20 19:38:51 --> Form Validation Class Initialized
INFO - 2023-09-20 19:38:51 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:38:51 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:38:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:38:51 --> Final output sent to browser
DEBUG - 2023-09-20 19:38:51 --> Total execution time: 0.1581
INFO - 2023-09-20 19:38:53 --> Config Class Initialized
INFO - 2023-09-20 19:38:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:53 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:53 --> URI Class Initialized
INFO - 2023-09-20 19:38:53 --> Router Class Initialized
INFO - 2023-09-20 19:38:54 --> Output Class Initialized
INFO - 2023-09-20 19:38:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:54 --> Input Class Initialized
INFO - 2023-09-20 19:38:54 --> Language Class Initialized
ERROR - 2023-09-20 19:38:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:54 --> Config Class Initialized
INFO - 2023-09-20 19:38:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:54 --> URI Class Initialized
INFO - 2023-09-20 19:38:54 --> Router Class Initialized
INFO - 2023-09-20 19:38:54 --> Output Class Initialized
INFO - 2023-09-20 19:38:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:54 --> Input Class Initialized
INFO - 2023-09-20 19:38:54 --> Language Class Initialized
ERROR - 2023-09-20 19:38:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:55 --> Config Class Initialized
INFO - 2023-09-20 19:38:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:55 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:55 --> URI Class Initialized
INFO - 2023-09-20 19:38:55 --> Router Class Initialized
INFO - 2023-09-20 19:38:55 --> Output Class Initialized
INFO - 2023-09-20 19:38:55 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:55 --> Input Class Initialized
INFO - 2023-09-20 19:38:55 --> Language Class Initialized
ERROR - 2023-09-20 19:38:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:56 --> Config Class Initialized
INFO - 2023-09-20 19:38:56 --> Config Class Initialized
INFO - 2023-09-20 19:38:57 --> Config Class Initialized
INFO - 2023-09-20 19:38:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:57 --> URI Class Initialized
INFO - 2023-09-20 19:38:57 --> Router Class Initialized
INFO - 2023-09-20 19:38:57 --> Output Class Initialized
INFO - 2023-09-20 19:38:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:57 --> Input Class Initialized
INFO - 2023-09-20 19:38:57 --> Language Class Initialized
ERROR - 2023-09-20 19:38:57 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:57 --> Hooks Class Initialized
INFO - 2023-09-20 19:38:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:57 --> Config Class Initialized
INFO - 2023-09-20 19:38:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:38:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:57 --> URI Class Initialized
INFO - 2023-09-20 19:38:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:57 --> URI Class Initialized
DEBUG - 2023-09-20 19:38:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:38:57 --> Router Class Initialized
INFO - 2023-09-20 19:38:57 --> Router Class Initialized
INFO - 2023-09-20 19:38:57 --> Output Class Initialized
INFO - 2023-09-20 19:38:57 --> Output Class Initialized
INFO - 2023-09-20 19:38:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:38:58 --> Security Class Initialized
INFO - 2023-09-20 19:38:58 --> Security Class Initialized
INFO - 2023-09-20 19:38:58 --> URI Class Initialized
DEBUG - 2023-09-20 19:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:58 --> Input Class Initialized
DEBUG - 2023-09-20 19:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:58 --> Language Class Initialized
INFO - 2023-09-20 19:38:58 --> Router Class Initialized
INFO - 2023-09-20 19:38:58 --> Input Class Initialized
INFO - 2023-09-20 19:38:58 --> Output Class Initialized
ERROR - 2023-09-20 19:38:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:38:58 --> Language Class Initialized
INFO - 2023-09-20 19:38:58 --> Security Class Initialized
ERROR - 2023-09-20 19:38:58 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:38:58 --> Input Class Initialized
INFO - 2023-09-20 19:38:58 --> Language Class Initialized
ERROR - 2023-09-20 19:38:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:27 --> Config Class Initialized
INFO - 2023-09-20 19:39:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:27 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:27 --> URI Class Initialized
INFO - 2023-09-20 19:39:27 --> Router Class Initialized
INFO - 2023-09-20 19:39:27 --> Output Class Initialized
INFO - 2023-09-20 19:39:27 --> Security Class Initialized
DEBUG - 2023-09-20 19:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:27 --> Input Class Initialized
INFO - 2023-09-20 19:39:27 --> Language Class Initialized
INFO - 2023-09-20 19:39:27 --> Loader Class Initialized
INFO - 2023-09-20 19:39:27 --> Helper loaded: url_helper
INFO - 2023-09-20 19:39:27 --> Helper loaded: file_helper
INFO - 2023-09-20 19:39:27 --> Database Driver Class Initialized
INFO - 2023-09-20 19:39:27 --> Email Class Initialized
DEBUG - 2023-09-20 19:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:39:27 --> Controller Class Initialized
INFO - 2023-09-20 19:39:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:39:27 --> Model "Home_model" initialized
INFO - 2023-09-20 19:39:27 --> Helper loaded: download_helper
INFO - 2023-09-20 19:39:27 --> Helper loaded: form_helper
INFO - 2023-09-20 19:39:27 --> Form Validation Class Initialized
INFO - 2023-09-20 19:39:27 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:39:27 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:39:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:39:27 --> Final output sent to browser
DEBUG - 2023-09-20 19:39:27 --> Total execution time: 0.1499
INFO - 2023-09-20 19:39:54 --> Config Class Initialized
INFO - 2023-09-20 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:54 --> URI Class Initialized
INFO - 2023-09-20 19:39:54 --> Router Class Initialized
INFO - 2023-09-20 19:39:54 --> Output Class Initialized
INFO - 2023-09-20 19:39:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:54 --> Config Class Initialized
INFO - 2023-09-20 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:54 --> URI Class Initialized
INFO - 2023-09-20 19:39:54 --> Router Class Initialized
INFO - 2023-09-20 19:39:54 --> Output Class Initialized
INFO - 2023-09-20 19:39:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:54 --> Input Class Initialized
INFO - 2023-09-20 19:39:54 --> Language Class Initialized
ERROR - 2023-09-20 19:39:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:54 --> Config Class Initialized
INFO - 2023-09-20 19:39:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:54 --> URI Class Initialized
INFO - 2023-09-20 19:39:54 --> Router Class Initialized
INFO - 2023-09-20 19:39:54 --> Output Class Initialized
INFO - 2023-09-20 19:39:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:54 --> Input Class Initialized
INFO - 2023-09-20 19:39:54 --> Language Class Initialized
INFO - 2023-09-20 19:39:54 --> Input Class Initialized
ERROR - 2023-09-20 19:39:54 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:55 --> Language Class Initialized
ERROR - 2023-09-20 19:39:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:56 --> Config Class Initialized
INFO - 2023-09-20 19:39:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:57 --> Config Class Initialized
INFO - 2023-09-20 19:39:58 --> Hooks Class Initialized
INFO - 2023-09-20 19:39:58 --> Config Class Initialized
INFO - 2023-09-20 19:39:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:39:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:58 --> URI Class Initialized
INFO - 2023-09-20 19:39:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:58 --> Router Class Initialized
INFO - 2023-09-20 19:39:58 --> URI Class Initialized
INFO - 2023-09-20 19:39:58 --> URI Class Initialized
INFO - 2023-09-20 19:39:58 --> Router Class Initialized
INFO - 2023-09-20 19:39:58 --> Output Class Initialized
INFO - 2023-09-20 19:39:58 --> Router Class Initialized
INFO - 2023-09-20 19:39:58 --> Output Class Initialized
INFO - 2023-09-20 19:39:58 --> Security Class Initialized
INFO - 2023-09-20 19:39:58 --> Output Class Initialized
DEBUG - 2023-09-20 19:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:58 --> Security Class Initialized
INFO - 2023-09-20 19:39:58 --> Input Class Initialized
DEBUG - 2023-09-20 19:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:58 --> Language Class Initialized
INFO - 2023-09-20 19:39:58 --> Security Class Initialized
INFO - 2023-09-20 19:39:58 --> Input Class Initialized
DEBUG - 2023-09-20 19:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:58 --> Language Class Initialized
ERROR - 2023-09-20 19:39:58 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:39:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:58 --> Input Class Initialized
INFO - 2023-09-20 19:39:58 --> Language Class Initialized
ERROR - 2023-09-20 19:39:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:39:58 --> Config Class Initialized
INFO - 2023-09-20 19:39:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:39:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:39:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:39:58 --> URI Class Initialized
INFO - 2023-09-20 19:39:58 --> Router Class Initialized
INFO - 2023-09-20 19:39:58 --> Output Class Initialized
INFO - 2023-09-20 19:39:58 --> Security Class Initialized
DEBUG - 2023-09-20 19:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:39:58 --> Input Class Initialized
INFO - 2023-09-20 19:39:58 --> Language Class Initialized
ERROR - 2023-09-20 19:39:58 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:13 --> Config Class Initialized
INFO - 2023-09-20 19:41:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:13 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:13 --> URI Class Initialized
INFO - 2023-09-20 19:41:13 --> Router Class Initialized
INFO - 2023-09-20 19:41:13 --> Output Class Initialized
INFO - 2023-09-20 19:41:13 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:13 --> Input Class Initialized
INFO - 2023-09-20 19:41:13 --> Language Class Initialized
INFO - 2023-09-20 19:41:13 --> Loader Class Initialized
INFO - 2023-09-20 19:41:13 --> Helper loaded: url_helper
INFO - 2023-09-20 19:41:13 --> Helper loaded: file_helper
INFO - 2023-09-20 19:41:13 --> Database Driver Class Initialized
INFO - 2023-09-20 19:41:13 --> Email Class Initialized
DEBUG - 2023-09-20 19:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:41:13 --> Controller Class Initialized
INFO - 2023-09-20 19:41:13 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:41:13 --> Model "Home_model" initialized
INFO - 2023-09-20 19:41:13 --> Helper loaded: download_helper
INFO - 2023-09-20 19:41:13 --> Helper loaded: form_helper
INFO - 2023-09-20 19:41:13 --> Form Validation Class Initialized
INFO - 2023-09-20 19:41:13 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:41:13 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:41:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:41:13 --> Final output sent to browser
DEBUG - 2023-09-20 19:41:13 --> Total execution time: 0.2386
INFO - 2023-09-20 19:41:14 --> Config Class Initialized
INFO - 2023-09-20 19:41:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:14 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:14 --> URI Class Initialized
INFO - 2023-09-20 19:41:15 --> Router Class Initialized
INFO - 2023-09-20 19:41:15 --> Output Class Initialized
INFO - 2023-09-20 19:41:15 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:15 --> Input Class Initialized
INFO - 2023-09-20 19:41:15 --> Language Class Initialized
ERROR - 2023-09-20 19:41:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:15 --> Config Class Initialized
INFO - 2023-09-20 19:41:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:15 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:15 --> URI Class Initialized
INFO - 2023-09-20 19:41:15 --> Router Class Initialized
INFO - 2023-09-20 19:41:15 --> Output Class Initialized
INFO - 2023-09-20 19:41:15 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:15 --> Input Class Initialized
INFO - 2023-09-20 19:41:15 --> Language Class Initialized
ERROR - 2023-09-20 19:41:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:16 --> Config Class Initialized
INFO - 2023-09-20 19:41:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:16 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:16 --> URI Class Initialized
INFO - 2023-09-20 19:41:16 --> Router Class Initialized
INFO - 2023-09-20 19:41:16 --> Output Class Initialized
INFO - 2023-09-20 19:41:16 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:16 --> Input Class Initialized
INFO - 2023-09-20 19:41:16 --> Language Class Initialized
ERROR - 2023-09-20 19:41:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:16 --> Config Class Initialized
INFO - 2023-09-20 19:41:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:16 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:16 --> URI Class Initialized
INFO - 2023-09-20 19:41:16 --> Router Class Initialized
INFO - 2023-09-20 19:41:16 --> Output Class Initialized
INFO - 2023-09-20 19:41:16 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:16 --> Input Class Initialized
INFO - 2023-09-20 19:41:16 --> Language Class Initialized
ERROR - 2023-09-20 19:41:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:16 --> Config Class Initialized
INFO - 2023-09-20 19:41:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:16 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:16 --> URI Class Initialized
INFO - 2023-09-20 19:41:16 --> Router Class Initialized
INFO - 2023-09-20 19:41:16 --> Output Class Initialized
INFO - 2023-09-20 19:41:16 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:16 --> Input Class Initialized
INFO - 2023-09-20 19:41:16 --> Language Class Initialized
ERROR - 2023-09-20 19:41:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:17 --> Config Class Initialized
INFO - 2023-09-20 19:41:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:17 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:17 --> URI Class Initialized
INFO - 2023-09-20 19:41:17 --> Router Class Initialized
INFO - 2023-09-20 19:41:17 --> Output Class Initialized
INFO - 2023-09-20 19:41:17 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:17 --> Input Class Initialized
INFO - 2023-09-20 19:41:17 --> Language Class Initialized
ERROR - 2023-09-20 19:41:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:41:17 --> Config Class Initialized
INFO - 2023-09-20 19:41:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:41:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:41:17 --> Utf8 Class Initialized
INFO - 2023-09-20 19:41:17 --> URI Class Initialized
INFO - 2023-09-20 19:41:17 --> Router Class Initialized
INFO - 2023-09-20 19:41:17 --> Output Class Initialized
INFO - 2023-09-20 19:41:17 --> Security Class Initialized
DEBUG - 2023-09-20 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:41:17 --> Input Class Initialized
INFO - 2023-09-20 19:41:17 --> Language Class Initialized
ERROR - 2023-09-20 19:41:17 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:05 --> Config Class Initialized
INFO - 2023-09-20 19:42:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:05 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:05 --> URI Class Initialized
INFO - 2023-09-20 19:42:05 --> Router Class Initialized
INFO - 2023-09-20 19:42:05 --> Output Class Initialized
INFO - 2023-09-20 19:42:05 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:05 --> Input Class Initialized
INFO - 2023-09-20 19:42:05 --> Language Class Initialized
INFO - 2023-09-20 19:42:05 --> Loader Class Initialized
INFO - 2023-09-20 19:42:05 --> Helper loaded: url_helper
INFO - 2023-09-20 19:42:05 --> Helper loaded: file_helper
INFO - 2023-09-20 19:42:05 --> Database Driver Class Initialized
INFO - 2023-09-20 19:42:05 --> Email Class Initialized
DEBUG - 2023-09-20 19:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:42:05 --> Controller Class Initialized
INFO - 2023-09-20 19:42:05 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:42:05 --> Model "Home_model" initialized
INFO - 2023-09-20 19:42:05 --> Helper loaded: download_helper
INFO - 2023-09-20 19:42:05 --> Helper loaded: form_helper
INFO - 2023-09-20 19:42:05 --> Form Validation Class Initialized
INFO - 2023-09-20 19:42:05 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:42:05 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:42:05 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:42:05 --> Final output sent to browser
DEBUG - 2023-09-20 19:42:05 --> Total execution time: 0.1048
INFO - 2023-09-20 19:42:07 --> Config Class Initialized
INFO - 2023-09-20 19:42:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:07 --> URI Class Initialized
INFO - 2023-09-20 19:42:07 --> Router Class Initialized
INFO - 2023-09-20 19:42:07 --> Output Class Initialized
INFO - 2023-09-20 19:42:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:07 --> Input Class Initialized
INFO - 2023-09-20 19:42:07 --> Language Class Initialized
ERROR - 2023-09-20 19:42:07 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:08 --> Config Class Initialized
INFO - 2023-09-20 19:42:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:08 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:08 --> URI Class Initialized
INFO - 2023-09-20 19:42:08 --> Router Class Initialized
INFO - 2023-09-20 19:42:08 --> Output Class Initialized
INFO - 2023-09-20 19:42:08 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:08 --> Input Class Initialized
INFO - 2023-09-20 19:42:08 --> Language Class Initialized
ERROR - 2023-09-20 19:42:08 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:09 --> Config Class Initialized
INFO - 2023-09-20 19:42:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:09 --> URI Class Initialized
INFO - 2023-09-20 19:42:09 --> Router Class Initialized
INFO - 2023-09-20 19:42:09 --> Output Class Initialized
INFO - 2023-09-20 19:42:09 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:09 --> Input Class Initialized
INFO - 2023-09-20 19:42:09 --> Language Class Initialized
ERROR - 2023-09-20 19:42:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:09 --> Config Class Initialized
INFO - 2023-09-20 19:42:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:09 --> URI Class Initialized
INFO - 2023-09-20 19:42:09 --> Router Class Initialized
INFO - 2023-09-20 19:42:09 --> Output Class Initialized
INFO - 2023-09-20 19:42:09 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:09 --> Input Class Initialized
INFO - 2023-09-20 19:42:09 --> Language Class Initialized
ERROR - 2023-09-20 19:42:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:09 --> Config Class Initialized
INFO - 2023-09-20 19:42:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:09 --> URI Class Initialized
INFO - 2023-09-20 19:42:09 --> Router Class Initialized
INFO - 2023-09-20 19:42:09 --> Output Class Initialized
INFO - 2023-09-20 19:42:09 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:09 --> Input Class Initialized
INFO - 2023-09-20 19:42:09 --> Language Class Initialized
ERROR - 2023-09-20 19:42:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:09 --> Config Class Initialized
INFO - 2023-09-20 19:42:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:09 --> URI Class Initialized
INFO - 2023-09-20 19:42:09 --> Router Class Initialized
INFO - 2023-09-20 19:42:09 --> Output Class Initialized
INFO - 2023-09-20 19:42:09 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:09 --> Input Class Initialized
INFO - 2023-09-20 19:42:09 --> Language Class Initialized
ERROR - 2023-09-20 19:42:09 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:09 --> Config Class Initialized
INFO - 2023-09-20 19:42:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:09 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:09 --> URI Class Initialized
INFO - 2023-09-20 19:42:10 --> Router Class Initialized
INFO - 2023-09-20 19:42:10 --> Output Class Initialized
INFO - 2023-09-20 19:42:10 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:10 --> Input Class Initialized
INFO - 2023-09-20 19:42:10 --> Language Class Initialized
ERROR - 2023-09-20 19:42:10 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:44 --> Config Class Initialized
INFO - 2023-09-20 19:42:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:44 --> URI Class Initialized
INFO - 2023-09-20 19:42:44 --> Router Class Initialized
INFO - 2023-09-20 19:42:44 --> Output Class Initialized
INFO - 2023-09-20 19:42:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:44 --> Input Class Initialized
INFO - 2023-09-20 19:42:44 --> Language Class Initialized
INFO - 2023-09-20 19:42:44 --> Loader Class Initialized
INFO - 2023-09-20 19:42:44 --> Helper loaded: url_helper
INFO - 2023-09-20 19:42:44 --> Helper loaded: file_helper
INFO - 2023-09-20 19:42:44 --> Database Driver Class Initialized
INFO - 2023-09-20 19:42:44 --> Email Class Initialized
DEBUG - 2023-09-20 19:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:42:44 --> Controller Class Initialized
INFO - 2023-09-20 19:42:44 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:42:44 --> Model "Home_model" initialized
INFO - 2023-09-20 19:42:44 --> Helper loaded: download_helper
INFO - 2023-09-20 19:42:44 --> Helper loaded: form_helper
INFO - 2023-09-20 19:42:44 --> Form Validation Class Initialized
INFO - 2023-09-20 19:42:44 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:42:44 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:42:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:42:44 --> Final output sent to browser
DEBUG - 2023-09-20 19:42:44 --> Total execution time: 0.3653
INFO - 2023-09-20 19:42:47 --> Config Class Initialized
INFO - 2023-09-20 19:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:47 --> URI Class Initialized
INFO - 2023-09-20 19:42:47 --> Router Class Initialized
INFO - 2023-09-20 19:42:47 --> Output Class Initialized
INFO - 2023-09-20 19:42:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:47 --> Input Class Initialized
INFO - 2023-09-20 19:42:47 --> Language Class Initialized
ERROR - 2023-09-20 19:42:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:47 --> Config Class Initialized
INFO - 2023-09-20 19:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:47 --> URI Class Initialized
INFO - 2023-09-20 19:42:47 --> Router Class Initialized
INFO - 2023-09-20 19:42:47 --> Output Class Initialized
INFO - 2023-09-20 19:42:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:47 --> Input Class Initialized
INFO - 2023-09-20 19:42:47 --> Language Class Initialized
ERROR - 2023-09-20 19:42:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:47 --> Config Class Initialized
INFO - 2023-09-20 19:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:47 --> URI Class Initialized
INFO - 2023-09-20 19:42:47 --> Router Class Initialized
INFO - 2023-09-20 19:42:47 --> Output Class Initialized
INFO - 2023-09-20 19:42:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:47 --> Input Class Initialized
INFO - 2023-09-20 19:42:47 --> Language Class Initialized
ERROR - 2023-09-20 19:42:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:47 --> Config Class Initialized
INFO - 2023-09-20 19:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:47 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:47 --> URI Class Initialized
INFO - 2023-09-20 19:42:47 --> Router Class Initialized
INFO - 2023-09-20 19:42:47 --> Output Class Initialized
INFO - 2023-09-20 19:42:47 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:47 --> Input Class Initialized
INFO - 2023-09-20 19:42:47 --> Language Class Initialized
ERROR - 2023-09-20 19:42:47 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:48 --> Config Class Initialized
INFO - 2023-09-20 19:42:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:48 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:48 --> URI Class Initialized
INFO - 2023-09-20 19:42:48 --> Router Class Initialized
INFO - 2023-09-20 19:42:48 --> Output Class Initialized
INFO - 2023-09-20 19:42:48 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:48 --> Input Class Initialized
INFO - 2023-09-20 19:42:48 --> Language Class Initialized
ERROR - 2023-09-20 19:42:48 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:50 --> Config Class Initialized
INFO - 2023-09-20 19:42:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:50 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:50 --> URI Class Initialized
INFO - 2023-09-20 19:42:50 --> Router Class Initialized
INFO - 2023-09-20 19:42:50 --> Output Class Initialized
INFO - 2023-09-20 19:42:50 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:50 --> Input Class Initialized
INFO - 2023-09-20 19:42:50 --> Language Class Initialized
ERROR - 2023-09-20 19:42:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:42:50 --> Config Class Initialized
INFO - 2023-09-20 19:42:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:42:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:42:50 --> Utf8 Class Initialized
INFO - 2023-09-20 19:42:50 --> URI Class Initialized
INFO - 2023-09-20 19:42:50 --> Router Class Initialized
INFO - 2023-09-20 19:42:50 --> Output Class Initialized
INFO - 2023-09-20 19:42:50 --> Security Class Initialized
DEBUG - 2023-09-20 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:42:50 --> Input Class Initialized
INFO - 2023-09-20 19:42:50 --> Language Class Initialized
ERROR - 2023-09-20 19:42:50 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:43:32 --> Config Class Initialized
INFO - 2023-09-20 19:43:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:43:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:43:32 --> Utf8 Class Initialized
INFO - 2023-09-20 19:43:32 --> URI Class Initialized
INFO - 2023-09-20 19:43:32 --> Router Class Initialized
INFO - 2023-09-20 19:43:32 --> Output Class Initialized
INFO - 2023-09-20 19:43:32 --> Security Class Initialized
DEBUG - 2023-09-20 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:43:32 --> Input Class Initialized
INFO - 2023-09-20 19:43:32 --> Language Class Initialized
INFO - 2023-09-20 19:43:32 --> Loader Class Initialized
INFO - 2023-09-20 19:43:32 --> Helper loaded: url_helper
INFO - 2023-09-20 19:43:32 --> Helper loaded: file_helper
INFO - 2023-09-20 19:43:32 --> Database Driver Class Initialized
INFO - 2023-09-20 19:43:32 --> Email Class Initialized
DEBUG - 2023-09-20 19:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:43:32 --> Controller Class Initialized
INFO - 2023-09-20 19:43:32 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:43:32 --> Model "Home_model" initialized
INFO - 2023-09-20 19:43:32 --> Helper loaded: download_helper
INFO - 2023-09-20 19:43:32 --> Helper loaded: form_helper
INFO - 2023-09-20 19:43:32 --> Form Validation Class Initialized
INFO - 2023-09-20 19:43:32 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:43:32 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:43:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 19:43:33 --> Final output sent to browser
DEBUG - 2023-09-20 19:43:33 --> Total execution time: 0.1168
INFO - 2023-09-20 19:44:27 --> Config Class Initialized
INFO - 2023-09-20 19:44:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:44:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:44:27 --> Utf8 Class Initialized
INFO - 2023-09-20 19:44:27 --> URI Class Initialized
INFO - 2023-09-20 19:44:27 --> Router Class Initialized
INFO - 2023-09-20 19:44:27 --> Output Class Initialized
INFO - 2023-09-20 19:44:27 --> Security Class Initialized
DEBUG - 2023-09-20 19:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:44:27 --> Input Class Initialized
INFO - 2023-09-20 19:44:27 --> Language Class Initialized
INFO - 2023-09-20 19:44:27 --> Loader Class Initialized
INFO - 2023-09-20 19:44:27 --> Helper loaded: url_helper
INFO - 2023-09-20 19:44:27 --> Helper loaded: file_helper
INFO - 2023-09-20 19:44:27 --> Database Driver Class Initialized
INFO - 2023-09-20 19:44:27 --> Email Class Initialized
DEBUG - 2023-09-20 19:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:44:27 --> Controller Class Initialized
INFO - 2023-09-20 19:44:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:44:27 --> Model "Home_model" initialized
INFO - 2023-09-20 19:44:27 --> Helper loaded: download_helper
INFO - 2023-09-20 19:44:27 --> Helper loaded: form_helper
INFO - 2023-09-20 19:44:27 --> Form Validation Class Initialized
INFO - 2023-09-20 19:46:19 --> Config Class Initialized
INFO - 2023-09-20 19:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:19 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:19 --> URI Class Initialized
INFO - 2023-09-20 19:46:19 --> Router Class Initialized
INFO - 2023-09-20 19:46:19 --> Output Class Initialized
INFO - 2023-09-20 19:46:19 --> Security Class Initialized
DEBUG - 2023-09-20 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:19 --> Input Class Initialized
INFO - 2023-09-20 19:46:19 --> Language Class Initialized
ERROR - 2023-09-20 19:46:19 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
INFO - 2023-09-20 19:46:20 --> Config Class Initialized
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
INFO - 2023-09-20 19:46:20 --> Hooks Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
DEBUG - 2023-09-20 19:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
INFO - 2023-09-20 19:46:20 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> URI Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:20 --> Router Class Initialized
INFO - 2023-09-20 19:46:20 --> Output Class Initialized
INFO - 2023-09-20 19:46:20 --> Security Class Initialized
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 19:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
INFO - 2023-09-20 19:46:20 --> Input Class Initialized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
INFO - 2023-09-20 19:46:20 --> Language Class Initialized
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 19:46:20 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 19:46:57 --> Config Class Initialized
INFO - 2023-09-20 19:46:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:46:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:46:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:46:57 --> URI Class Initialized
INFO - 2023-09-20 19:46:57 --> Router Class Initialized
INFO - 2023-09-20 19:46:57 --> Output Class Initialized
INFO - 2023-09-20 19:46:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:46:57 --> Input Class Initialized
INFO - 2023-09-20 19:46:57 --> Language Class Initialized
INFO - 2023-09-20 19:46:57 --> Loader Class Initialized
INFO - 2023-09-20 19:46:57 --> Helper loaded: url_helper
INFO - 2023-09-20 19:46:57 --> Helper loaded: file_helper
INFO - 2023-09-20 19:46:57 --> Database Driver Class Initialized
INFO - 2023-09-20 19:46:57 --> Email Class Initialized
DEBUG - 2023-09-20 19:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:46:57 --> Controller Class Initialized
INFO - 2023-09-20 19:46:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:46:57 --> Model "Home_model" initialized
INFO - 2023-09-20 19:46:57 --> Helper loaded: download_helper
INFO - 2023-09-20 19:46:57 --> Helper loaded: form_helper
INFO - 2023-09-20 19:46:57 --> Form Validation Class Initialized
INFO - 2023-09-20 19:48:56 --> Config Class Initialized
INFO - 2023-09-20 19:48:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:48:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:48:56 --> Utf8 Class Initialized
INFO - 2023-09-20 19:48:56 --> URI Class Initialized
INFO - 2023-09-20 19:48:56 --> Router Class Initialized
INFO - 2023-09-20 19:48:56 --> Output Class Initialized
INFO - 2023-09-20 19:48:56 --> Security Class Initialized
DEBUG - 2023-09-20 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:48:56 --> Input Class Initialized
INFO - 2023-09-20 19:48:56 --> Language Class Initialized
INFO - 2023-09-20 19:48:56 --> Loader Class Initialized
INFO - 2023-09-20 19:48:56 --> Helper loaded: url_helper
INFO - 2023-09-20 19:48:56 --> Helper loaded: file_helper
INFO - 2023-09-20 19:48:56 --> Database Driver Class Initialized
INFO - 2023-09-20 19:48:56 --> Email Class Initialized
DEBUG - 2023-09-20 19:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:48:56 --> Controller Class Initialized
INFO - 2023-09-20 19:48:56 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:48:56 --> Model "Home_model" initialized
INFO - 2023-09-20 19:48:56 --> Helper loaded: download_helper
INFO - 2023-09-20 19:48:56 --> Helper loaded: form_helper
INFO - 2023-09-20 19:48:56 --> Form Validation Class Initialized
INFO - 2023-09-20 19:51:31 --> Config Class Initialized
INFO - 2023-09-20 19:51:31 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:51:31 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:51:31 --> Utf8 Class Initialized
INFO - 2023-09-20 19:51:31 --> URI Class Initialized
INFO - 2023-09-20 19:51:31 --> Router Class Initialized
INFO - 2023-09-20 19:51:31 --> Output Class Initialized
INFO - 2023-09-20 19:51:31 --> Security Class Initialized
DEBUG - 2023-09-20 19:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:51:31 --> Input Class Initialized
INFO - 2023-09-20 19:51:31 --> Language Class Initialized
INFO - 2023-09-20 19:51:31 --> Loader Class Initialized
INFO - 2023-09-20 19:51:31 --> Helper loaded: url_helper
INFO - 2023-09-20 19:51:31 --> Helper loaded: file_helper
INFO - 2023-09-20 19:51:31 --> Database Driver Class Initialized
INFO - 2023-09-20 19:51:31 --> Email Class Initialized
DEBUG - 2023-09-20 19:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:51:31 --> Controller Class Initialized
INFO - 2023-09-20 19:51:31 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:51:31 --> Model "Home_model" initialized
INFO - 2023-09-20 19:51:31 --> Helper loaded: download_helper
INFO - 2023-09-20 19:51:31 --> Helper loaded: form_helper
INFO - 2023-09-20 19:51:31 --> Form Validation Class Initialized
INFO - 2023-09-20 19:51:31 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:51:31 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:51:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:51:31 --> Final output sent to browser
DEBUG - 2023-09-20 19:51:31 --> Total execution time: 0.2161
INFO - 2023-09-20 19:51:41 --> Config Class Initialized
INFO - 2023-09-20 19:51:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:51:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:51:41 --> Utf8 Class Initialized
INFO - 2023-09-20 19:51:41 --> URI Class Initialized
INFO - 2023-09-20 19:51:41 --> Router Class Initialized
INFO - 2023-09-20 19:51:41 --> Output Class Initialized
INFO - 2023-09-20 19:51:41 --> Security Class Initialized
DEBUG - 2023-09-20 19:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:51:41 --> Input Class Initialized
INFO - 2023-09-20 19:51:41 --> Language Class Initialized
INFO - 2023-09-20 19:51:41 --> Loader Class Initialized
INFO - 2023-09-20 19:51:41 --> Helper loaded: url_helper
INFO - 2023-09-20 19:51:41 --> Helper loaded: file_helper
INFO - 2023-09-20 19:51:41 --> Database Driver Class Initialized
INFO - 2023-09-20 19:51:41 --> Email Class Initialized
DEBUG - 2023-09-20 19:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:51:41 --> Controller Class Initialized
INFO - 2023-09-20 19:51:41 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:51:41 --> Model "Home_model" initialized
INFO - 2023-09-20 19:51:41 --> Helper loaded: download_helper
INFO - 2023-09-20 19:51:41 --> Helper loaded: form_helper
INFO - 2023-09-20 19:51:41 --> Form Validation Class Initialized
INFO - 2023-09-20 19:51:41 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:51:41 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:51:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:51:41 --> Final output sent to browser
DEBUG - 2023-09-20 19:51:41 --> Total execution time: 0.1143
INFO - 2023-09-20 19:54:49 --> Config Class Initialized
INFO - 2023-09-20 19:54:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:54:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:54:49 --> Utf8 Class Initialized
INFO - 2023-09-20 19:54:49 --> URI Class Initialized
INFO - 2023-09-20 19:54:49 --> Router Class Initialized
INFO - 2023-09-20 19:54:49 --> Output Class Initialized
INFO - 2023-09-20 19:54:49 --> Security Class Initialized
DEBUG - 2023-09-20 19:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:54:49 --> Input Class Initialized
INFO - 2023-09-20 19:54:49 --> Language Class Initialized
INFO - 2023-09-20 19:54:49 --> Loader Class Initialized
INFO - 2023-09-20 19:54:49 --> Helper loaded: url_helper
INFO - 2023-09-20 19:54:49 --> Helper loaded: file_helper
INFO - 2023-09-20 19:54:49 --> Database Driver Class Initialized
INFO - 2023-09-20 19:54:49 --> Email Class Initialized
DEBUG - 2023-09-20 19:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:54:49 --> Controller Class Initialized
INFO - 2023-09-20 19:54:49 --> Model "Services_model" initialized
INFO - 2023-09-20 19:54:49 --> Helper loaded: form_helper
INFO - 2023-09-20 19:54:49 --> Form Validation Class Initialized
INFO - 2023-09-20 19:54:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:54:49 --> Final output sent to browser
DEBUG - 2023-09-20 19:54:49 --> Total execution time: 0.0965
INFO - 2023-09-20 19:54:50 --> Config Class Initialized
INFO - 2023-09-20 19:54:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:54:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:54:50 --> Utf8 Class Initialized
INFO - 2023-09-20 19:54:50 --> URI Class Initialized
INFO - 2023-09-20 19:54:50 --> Router Class Initialized
INFO - 2023-09-20 19:54:50 --> Output Class Initialized
INFO - 2023-09-20 19:54:50 --> Security Class Initialized
DEBUG - 2023-09-20 19:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:54:50 --> Input Class Initialized
INFO - 2023-09-20 19:54:50 --> Language Class Initialized
ERROR - 2023-09-20 19:54:50 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 19:54:53 --> Config Class Initialized
INFO - 2023-09-20 19:54:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:54:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:54:53 --> Utf8 Class Initialized
INFO - 2023-09-20 19:54:53 --> URI Class Initialized
INFO - 2023-09-20 19:54:53 --> Router Class Initialized
INFO - 2023-09-20 19:54:53 --> Output Class Initialized
INFO - 2023-09-20 19:54:53 --> Security Class Initialized
DEBUG - 2023-09-20 19:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:54:53 --> Input Class Initialized
INFO - 2023-09-20 19:54:54 --> Language Class Initialized
INFO - 2023-09-20 19:54:54 --> Loader Class Initialized
INFO - 2023-09-20 19:54:54 --> Helper loaded: url_helper
INFO - 2023-09-20 19:54:54 --> Helper loaded: file_helper
INFO - 2023-09-20 19:54:54 --> Database Driver Class Initialized
INFO - 2023-09-20 19:54:54 --> Email Class Initialized
DEBUG - 2023-09-20 19:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:54:54 --> Controller Class Initialized
INFO - 2023-09-20 19:54:54 --> Model "Services_model" initialized
INFO - 2023-09-20 19:54:54 --> Helper loaded: form_helper
INFO - 2023-09-20 19:54:54 --> Form Validation Class Initialized
INFO - 2023-09-20 19:54:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:54:54 --> Final output sent to browser
DEBUG - 2023-09-20 19:54:54 --> Total execution time: 0.1292
INFO - 2023-09-20 19:54:54 --> Config Class Initialized
INFO - 2023-09-20 19:54:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:54:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:54:54 --> Utf8 Class Initialized
INFO - 2023-09-20 19:54:54 --> URI Class Initialized
INFO - 2023-09-20 19:54:54 --> Router Class Initialized
INFO - 2023-09-20 19:54:54 --> Output Class Initialized
INFO - 2023-09-20 19:54:54 --> Security Class Initialized
DEBUG - 2023-09-20 19:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:54:54 --> Input Class Initialized
INFO - 2023-09-20 19:54:54 --> Language Class Initialized
INFO - 2023-09-20 19:54:54 --> Loader Class Initialized
INFO - 2023-09-20 19:54:54 --> Helper loaded: url_helper
INFO - 2023-09-20 19:54:54 --> Helper loaded: file_helper
INFO - 2023-09-20 19:54:54 --> Database Driver Class Initialized
INFO - 2023-09-20 19:54:54 --> Email Class Initialized
DEBUG - 2023-09-20 19:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:54:54 --> Controller Class Initialized
INFO - 2023-09-20 19:54:54 --> Model "Services_model" initialized
INFO - 2023-09-20 19:54:54 --> Helper loaded: form_helper
INFO - 2023-09-20 19:54:54 --> Form Validation Class Initialized
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 19:54:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 19:54:55 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:54:55 --> Final output sent to browser
DEBUG - 2023-09-20 19:54:55 --> Total execution time: 0.1522
INFO - 2023-09-20 19:55:00 --> Config Class Initialized
INFO - 2023-09-20 19:55:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:55:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:55:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:55:00 --> URI Class Initialized
INFO - 2023-09-20 19:55:00 --> Router Class Initialized
INFO - 2023-09-20 19:55:00 --> Output Class Initialized
INFO - 2023-09-20 19:55:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:55:00 --> Input Class Initialized
INFO - 2023-09-20 19:55:00 --> Language Class Initialized
INFO - 2023-09-20 19:55:00 --> Loader Class Initialized
INFO - 2023-09-20 19:55:00 --> Helper loaded: url_helper
INFO - 2023-09-20 19:55:00 --> Helper loaded: file_helper
INFO - 2023-09-20 19:55:00 --> Database Driver Class Initialized
INFO - 2023-09-20 19:55:00 --> Email Class Initialized
DEBUG - 2023-09-20 19:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:55:00 --> Controller Class Initialized
INFO - 2023-09-20 19:55:00 --> Model "Services_model" initialized
INFO - 2023-09-20 19:55:00 --> Helper loaded: form_helper
INFO - 2023-09-20 19:55:00 --> Form Validation Class Initialized
INFO - 2023-09-20 19:55:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:55:00 --> Config Class Initialized
INFO - 2023-09-20 19:55:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:55:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:55:00 --> Utf8 Class Initialized
INFO - 2023-09-20 19:55:00 --> URI Class Initialized
INFO - 2023-09-20 19:55:00 --> Router Class Initialized
INFO - 2023-09-20 19:55:00 --> Output Class Initialized
INFO - 2023-09-20 19:55:00 --> Security Class Initialized
DEBUG - 2023-09-20 19:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:55:00 --> Input Class Initialized
INFO - 2023-09-20 19:55:00 --> Language Class Initialized
INFO - 2023-09-20 19:55:00 --> Loader Class Initialized
INFO - 2023-09-20 19:55:00 --> Helper loaded: url_helper
INFO - 2023-09-20 19:55:00 --> Helper loaded: file_helper
INFO - 2023-09-20 19:55:00 --> Database Driver Class Initialized
INFO - 2023-09-20 19:55:00 --> Email Class Initialized
DEBUG - 2023-09-20 19:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:55:00 --> Controller Class Initialized
INFO - 2023-09-20 19:55:00 --> Model "Services_model" initialized
INFO - 2023-09-20 19:55:00 --> Helper loaded: form_helper
INFO - 2023-09-20 19:55:00 --> Form Validation Class Initialized
INFO - 2023-09-20 19:55:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:55:00 --> Final output sent to browser
DEBUG - 2023-09-20 19:55:00 --> Total execution time: 0.2102
INFO - 2023-09-20 19:55:03 --> Config Class Initialized
INFO - 2023-09-20 19:55:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:55:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:55:03 --> Utf8 Class Initialized
INFO - 2023-09-20 19:55:03 --> URI Class Initialized
INFO - 2023-09-20 19:55:03 --> Router Class Initialized
INFO - 2023-09-20 19:55:03 --> Output Class Initialized
INFO - 2023-09-20 19:55:03 --> Security Class Initialized
DEBUG - 2023-09-20 19:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:55:03 --> Input Class Initialized
INFO - 2023-09-20 19:55:03 --> Language Class Initialized
INFO - 2023-09-20 19:55:03 --> Loader Class Initialized
INFO - 2023-09-20 19:55:03 --> Helper loaded: url_helper
INFO - 2023-09-20 19:55:03 --> Helper loaded: file_helper
INFO - 2023-09-20 19:55:03 --> Database Driver Class Initialized
INFO - 2023-09-20 19:55:03 --> Email Class Initialized
DEBUG - 2023-09-20 19:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:55:03 --> Controller Class Initialized
INFO - 2023-09-20 19:55:03 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:55:03 --> Model "Home_model" initialized
INFO - 2023-09-20 19:55:03 --> Helper loaded: download_helper
INFO - 2023-09-20 19:55:03 --> Helper loaded: form_helper
INFO - 2023-09-20 19:55:03 --> Form Validation Class Initialized
INFO - 2023-09-20 19:55:03 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:55:03 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:55:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:55:03 --> Final output sent to browser
DEBUG - 2023-09-20 19:55:03 --> Total execution time: 0.1136
INFO - 2023-09-20 19:56:42 --> Config Class Initialized
INFO - 2023-09-20 19:56:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:56:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:56:42 --> Utf8 Class Initialized
INFO - 2023-09-20 19:56:42 --> URI Class Initialized
INFO - 2023-09-20 19:56:42 --> Router Class Initialized
INFO - 2023-09-20 19:56:42 --> Output Class Initialized
INFO - 2023-09-20 19:56:42 --> Security Class Initialized
DEBUG - 2023-09-20 19:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:56:42 --> Input Class Initialized
INFO - 2023-09-20 19:56:42 --> Language Class Initialized
INFO - 2023-09-20 19:56:42 --> Loader Class Initialized
INFO - 2023-09-20 19:56:42 --> Helper loaded: url_helper
INFO - 2023-09-20 19:56:42 --> Helper loaded: file_helper
INFO - 2023-09-20 19:56:42 --> Database Driver Class Initialized
INFO - 2023-09-20 19:56:42 --> Email Class Initialized
DEBUG - 2023-09-20 19:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:56:42 --> Controller Class Initialized
INFO - 2023-09-20 19:56:42 --> Model "Services_model" initialized
INFO - 2023-09-20 19:56:42 --> Helper loaded: form_helper
INFO - 2023-09-20 19:56:42 --> Form Validation Class Initialized
INFO - 2023-09-20 19:56:42 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:56:42 --> Final output sent to browser
DEBUG - 2023-09-20 19:56:43 --> Total execution time: 0.1191
INFO - 2023-09-20 19:56:44 --> Config Class Initialized
INFO - 2023-09-20 19:56:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:56:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:56:44 --> Utf8 Class Initialized
INFO - 2023-09-20 19:56:44 --> URI Class Initialized
INFO - 2023-09-20 19:56:44 --> Router Class Initialized
INFO - 2023-09-20 19:56:44 --> Output Class Initialized
INFO - 2023-09-20 19:56:44 --> Security Class Initialized
DEBUG - 2023-09-20 19:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:56:44 --> Input Class Initialized
INFO - 2023-09-20 19:56:44 --> Language Class Initialized
INFO - 2023-09-20 19:56:44 --> Loader Class Initialized
INFO - 2023-09-20 19:56:44 --> Helper loaded: url_helper
INFO - 2023-09-20 19:56:44 --> Helper loaded: file_helper
INFO - 2023-09-20 19:56:44 --> Database Driver Class Initialized
INFO - 2023-09-20 19:56:44 --> Email Class Initialized
DEBUG - 2023-09-20 19:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:56:44 --> Controller Class Initialized
INFO - 2023-09-20 19:56:44 --> Model "Services_model" initialized
INFO - 2023-09-20 19:56:44 --> Helper loaded: form_helper
INFO - 2023-09-20 19:56:44 --> Form Validation Class Initialized
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 19:56:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 19:56:44 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:56:44 --> Final output sent to browser
DEBUG - 2023-09-20 19:56:44 --> Total execution time: 0.1528
INFO - 2023-09-20 19:56:49 --> Config Class Initialized
INFO - 2023-09-20 19:56:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:56:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:56:49 --> Utf8 Class Initialized
INFO - 2023-09-20 19:56:49 --> URI Class Initialized
INFO - 2023-09-20 19:56:49 --> Router Class Initialized
INFO - 2023-09-20 19:56:49 --> Output Class Initialized
INFO - 2023-09-20 19:56:49 --> Security Class Initialized
DEBUG - 2023-09-20 19:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:56:49 --> Input Class Initialized
INFO - 2023-09-20 19:56:49 --> Language Class Initialized
INFO - 2023-09-20 19:56:49 --> Loader Class Initialized
INFO - 2023-09-20 19:56:49 --> Helper loaded: url_helper
INFO - 2023-09-20 19:56:49 --> Helper loaded: file_helper
INFO - 2023-09-20 19:56:49 --> Database Driver Class Initialized
INFO - 2023-09-20 19:56:49 --> Email Class Initialized
DEBUG - 2023-09-20 19:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:56:49 --> Controller Class Initialized
INFO - 2023-09-20 19:56:49 --> Model "Services_model" initialized
INFO - 2023-09-20 19:56:49 --> Helper loaded: form_helper
INFO - 2023-09-20 19:56:49 --> Form Validation Class Initialized
INFO - 2023-09-20 19:56:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:56:50 --> Config Class Initialized
INFO - 2023-09-20 19:56:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:56:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:56:50 --> Utf8 Class Initialized
INFO - 2023-09-20 19:56:50 --> URI Class Initialized
INFO - 2023-09-20 19:56:50 --> Router Class Initialized
INFO - 2023-09-20 19:56:50 --> Output Class Initialized
INFO - 2023-09-20 19:56:50 --> Security Class Initialized
DEBUG - 2023-09-20 19:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:56:50 --> Input Class Initialized
INFO - 2023-09-20 19:56:50 --> Language Class Initialized
INFO - 2023-09-20 19:56:50 --> Loader Class Initialized
INFO - 2023-09-20 19:56:50 --> Helper loaded: url_helper
INFO - 2023-09-20 19:56:50 --> Helper loaded: file_helper
INFO - 2023-09-20 19:56:50 --> Database Driver Class Initialized
INFO - 2023-09-20 19:56:50 --> Email Class Initialized
DEBUG - 2023-09-20 19:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:56:50 --> Controller Class Initialized
INFO - 2023-09-20 19:56:50 --> Model "Services_model" initialized
INFO - 2023-09-20 19:56:50 --> Helper loaded: form_helper
INFO - 2023-09-20 19:56:50 --> Form Validation Class Initialized
INFO - 2023-09-20 19:56:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:56:50 --> Final output sent to browser
DEBUG - 2023-09-20 19:56:50 --> Total execution time: 0.1258
INFO - 2023-09-20 19:56:58 --> Config Class Initialized
INFO - 2023-09-20 19:56:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:56:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:56:58 --> Utf8 Class Initialized
INFO - 2023-09-20 19:56:58 --> URI Class Initialized
INFO - 2023-09-20 19:56:58 --> Router Class Initialized
INFO - 2023-09-20 19:56:58 --> Output Class Initialized
INFO - 2023-09-20 19:56:58 --> Security Class Initialized
DEBUG - 2023-09-20 19:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:56:58 --> Input Class Initialized
INFO - 2023-09-20 19:56:58 --> Language Class Initialized
INFO - 2023-09-20 19:56:58 --> Loader Class Initialized
INFO - 2023-09-20 19:56:58 --> Helper loaded: url_helper
INFO - 2023-09-20 19:56:58 --> Helper loaded: file_helper
INFO - 2023-09-20 19:56:58 --> Database Driver Class Initialized
INFO - 2023-09-20 19:56:58 --> Email Class Initialized
DEBUG - 2023-09-20 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:56:58 --> Controller Class Initialized
INFO - 2023-09-20 19:56:58 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:56:58 --> Model "Home_model" initialized
INFO - 2023-09-20 19:56:58 --> Helper loaded: download_helper
INFO - 2023-09-20 19:56:58 --> Helper loaded: form_helper
INFO - 2023-09-20 19:56:58 --> Form Validation Class Initialized
INFO - 2023-09-20 19:56:58 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:56:58 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:56:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:56:58 --> Final output sent to browser
DEBUG - 2023-09-20 19:56:58 --> Total execution time: 0.1337
INFO - 2023-09-20 19:57:03 --> Config Class Initialized
INFO - 2023-09-20 19:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:57:03 --> Utf8 Class Initialized
INFO - 2023-09-20 19:57:03 --> URI Class Initialized
INFO - 2023-09-20 19:57:03 --> Router Class Initialized
INFO - 2023-09-20 19:57:03 --> Output Class Initialized
INFO - 2023-09-20 19:57:03 --> Security Class Initialized
DEBUG - 2023-09-20 19:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:57:03 --> Input Class Initialized
INFO - 2023-09-20 19:57:03 --> Language Class Initialized
INFO - 2023-09-20 19:57:03 --> Loader Class Initialized
INFO - 2023-09-20 19:57:03 --> Helper loaded: url_helper
INFO - 2023-09-20 19:57:03 --> Helper loaded: file_helper
INFO - 2023-09-20 19:57:03 --> Database Driver Class Initialized
INFO - 2023-09-20 19:57:03 --> Email Class Initialized
DEBUG - 2023-09-20 19:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:57:03 --> Controller Class Initialized
INFO - 2023-09-20 19:57:03 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:57:03 --> Model "Home_model" initialized
INFO - 2023-09-20 19:57:03 --> Helper loaded: download_helper
INFO - 2023-09-20 19:57:03 --> Helper loaded: form_helper
INFO - 2023-09-20 19:57:03 --> Form Validation Class Initialized
INFO - 2023-09-20 19:57:03 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:57:03 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:57:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:57:03 --> Final output sent to browser
DEBUG - 2023-09-20 19:57:04 --> Total execution time: 0.1499
INFO - 2023-09-20 19:57:13 --> Config Class Initialized
INFO - 2023-09-20 19:57:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:57:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:57:13 --> Utf8 Class Initialized
INFO - 2023-09-20 19:57:13 --> URI Class Initialized
INFO - 2023-09-20 19:57:13 --> Router Class Initialized
INFO - 2023-09-20 19:57:13 --> Output Class Initialized
INFO - 2023-09-20 19:57:13 --> Security Class Initialized
DEBUG - 2023-09-20 19:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:57:13 --> Input Class Initialized
INFO - 2023-09-20 19:57:13 --> Language Class Initialized
INFO - 2023-09-20 19:57:13 --> Loader Class Initialized
INFO - 2023-09-20 19:57:13 --> Helper loaded: url_helper
INFO - 2023-09-20 19:57:13 --> Helper loaded: file_helper
INFO - 2023-09-20 19:57:13 --> Database Driver Class Initialized
INFO - 2023-09-20 19:57:13 --> Email Class Initialized
DEBUG - 2023-09-20 19:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:57:13 --> Controller Class Initialized
INFO - 2023-09-20 19:57:13 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:57:13 --> Model "Home_model" initialized
INFO - 2023-09-20 19:57:13 --> Helper loaded: download_helper
INFO - 2023-09-20 19:57:13 --> Helper loaded: form_helper
INFO - 2023-09-20 19:57:13 --> Form Validation Class Initialized
INFO - 2023-09-20 19:57:13 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:57:13 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:57:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:57:13 --> Final output sent to browser
DEBUG - 2023-09-20 19:57:13 --> Total execution time: 0.1114
INFO - 2023-09-20 19:57:14 --> Config Class Initialized
INFO - 2023-09-20 19:57:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:57:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:57:14 --> Utf8 Class Initialized
INFO - 2023-09-20 19:57:14 --> URI Class Initialized
INFO - 2023-09-20 19:57:14 --> Router Class Initialized
INFO - 2023-09-20 19:57:14 --> Output Class Initialized
INFO - 2023-09-20 19:57:14 --> Security Class Initialized
DEBUG - 2023-09-20 19:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:57:14 --> Input Class Initialized
INFO - 2023-09-20 19:57:14 --> Language Class Initialized
ERROR - 2023-09-20 19:57:14 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 19:58:56 --> Config Class Initialized
INFO - 2023-09-20 19:58:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:58:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:58:56 --> Utf8 Class Initialized
INFO - 2023-09-20 19:58:56 --> URI Class Initialized
INFO - 2023-09-20 19:58:56 --> Router Class Initialized
INFO - 2023-09-20 19:58:56 --> Output Class Initialized
INFO - 2023-09-20 19:58:56 --> Security Class Initialized
DEBUG - 2023-09-20 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:58:56 --> Input Class Initialized
INFO - 2023-09-20 19:58:56 --> Language Class Initialized
INFO - 2023-09-20 19:58:56 --> Loader Class Initialized
INFO - 2023-09-20 19:58:56 --> Helper loaded: url_helper
INFO - 2023-09-20 19:58:56 --> Helper loaded: file_helper
INFO - 2023-09-20 19:58:56 --> Database Driver Class Initialized
INFO - 2023-09-20 19:58:56 --> Email Class Initialized
DEBUG - 2023-09-20 19:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:58:56 --> Controller Class Initialized
INFO - 2023-09-20 19:58:56 --> Model "Services_model" initialized
INFO - 2023-09-20 19:58:56 --> Helper loaded: form_helper
INFO - 2023-09-20 19:58:56 --> Form Validation Class Initialized
INFO - 2023-09-20 19:58:56 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:58:56 --> Final output sent to browser
DEBUG - 2023-09-20 19:58:56 --> Total execution time: 0.1390
INFO - 2023-09-20 19:58:56 --> Config Class Initialized
INFO - 2023-09-20 19:58:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:58:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:58:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:58:57 --> URI Class Initialized
INFO - 2023-09-20 19:58:57 --> Router Class Initialized
INFO - 2023-09-20 19:58:57 --> Output Class Initialized
INFO - 2023-09-20 19:58:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:58:57 --> Input Class Initialized
INFO - 2023-09-20 19:58:57 --> Language Class Initialized
ERROR - 2023-09-20 19:58:57 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 19:58:57 --> Config Class Initialized
INFO - 2023-09-20 19:58:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:58:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:58:57 --> Utf8 Class Initialized
INFO - 2023-09-20 19:58:57 --> URI Class Initialized
INFO - 2023-09-20 19:58:57 --> Router Class Initialized
INFO - 2023-09-20 19:58:57 --> Output Class Initialized
INFO - 2023-09-20 19:58:57 --> Security Class Initialized
DEBUG - 2023-09-20 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:58:57 --> Input Class Initialized
INFO - 2023-09-20 19:58:57 --> Language Class Initialized
INFO - 2023-09-20 19:58:57 --> Loader Class Initialized
INFO - 2023-09-20 19:58:57 --> Helper loaded: url_helper
INFO - 2023-09-20 19:58:57 --> Helper loaded: file_helper
INFO - 2023-09-20 19:58:57 --> Database Driver Class Initialized
INFO - 2023-09-20 19:58:57 --> Email Class Initialized
DEBUG - 2023-09-20 19:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:58:57 --> Controller Class Initialized
INFO - 2023-09-20 19:58:57 --> Model "Services_model" initialized
INFO - 2023-09-20 19:58:57 --> Helper loaded: form_helper
INFO - 2023-09-20 19:58:57 --> Form Validation Class Initialized
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 39
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 49
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 50
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 64
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 74
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 90
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 103
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 104
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 105
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 123
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 135
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 147
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 159
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 172
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 182
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 195
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 205
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 218
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 228
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 238
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 240
ERROR - 2023-09-20 19:58:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\services_edit.php 242
INFO - 2023-09-20 19:58:57 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_edit.php
INFO - 2023-09-20 19:58:57 --> Final output sent to browser
DEBUG - 2023-09-20 19:58:57 --> Total execution time: 0.2335
INFO - 2023-09-20 19:59:03 --> Config Class Initialized
INFO - 2023-09-20 19:59:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:59:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:59:03 --> Utf8 Class Initialized
INFO - 2023-09-20 19:59:03 --> URI Class Initialized
INFO - 2023-09-20 19:59:03 --> Router Class Initialized
INFO - 2023-09-20 19:59:03 --> Output Class Initialized
INFO - 2023-09-20 19:59:03 --> Security Class Initialized
DEBUG - 2023-09-20 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:59:03 --> Input Class Initialized
INFO - 2023-09-20 19:59:03 --> Language Class Initialized
INFO - 2023-09-20 19:59:03 --> Loader Class Initialized
INFO - 2023-09-20 19:59:03 --> Helper loaded: url_helper
INFO - 2023-09-20 19:59:03 --> Helper loaded: file_helper
INFO - 2023-09-20 19:59:03 --> Database Driver Class Initialized
INFO - 2023-09-20 19:59:03 --> Email Class Initialized
DEBUG - 2023-09-20 19:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:59:03 --> Controller Class Initialized
INFO - 2023-09-20 19:59:03 --> Model "Services_model" initialized
INFO - 2023-09-20 19:59:03 --> Helper loaded: form_helper
INFO - 2023-09-20 19:59:03 --> Form Validation Class Initialized
INFO - 2023-09-20 19:59:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 19:59:03 --> Config Class Initialized
INFO - 2023-09-20 19:59:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:59:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:59:03 --> Utf8 Class Initialized
INFO - 2023-09-20 19:59:03 --> URI Class Initialized
INFO - 2023-09-20 19:59:03 --> Router Class Initialized
INFO - 2023-09-20 19:59:03 --> Output Class Initialized
INFO - 2023-09-20 19:59:03 --> Security Class Initialized
DEBUG - 2023-09-20 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:59:03 --> Input Class Initialized
INFO - 2023-09-20 19:59:03 --> Language Class Initialized
INFO - 2023-09-20 19:59:03 --> Loader Class Initialized
INFO - 2023-09-20 19:59:03 --> Helper loaded: url_helper
INFO - 2023-09-20 19:59:03 --> Helper loaded: file_helper
INFO - 2023-09-20 19:59:03 --> Database Driver Class Initialized
INFO - 2023-09-20 19:59:03 --> Email Class Initialized
DEBUG - 2023-09-20 19:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:59:03 --> Controller Class Initialized
INFO - 2023-09-20 19:59:03 --> Model "Services_model" initialized
INFO - 2023-09-20 19:59:03 --> Helper loaded: form_helper
INFO - 2023-09-20 19:59:03 --> Form Validation Class Initialized
INFO - 2023-09-20 19:59:03 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_list.php
INFO - 2023-09-20 19:59:03 --> Final output sent to browser
DEBUG - 2023-09-20 19:59:03 --> Total execution time: 0.0854
INFO - 2023-09-20 19:59:06 --> Config Class Initialized
INFO - 2023-09-20 19:59:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:59:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:59:06 --> Utf8 Class Initialized
INFO - 2023-09-20 19:59:06 --> URI Class Initialized
INFO - 2023-09-20 19:59:06 --> Router Class Initialized
INFO - 2023-09-20 19:59:06 --> Output Class Initialized
INFO - 2023-09-20 19:59:06 --> Security Class Initialized
DEBUG - 2023-09-20 19:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:59:06 --> Input Class Initialized
INFO - 2023-09-20 19:59:06 --> Language Class Initialized
INFO - 2023-09-20 19:59:06 --> Loader Class Initialized
INFO - 2023-09-20 19:59:06 --> Helper loaded: url_helper
INFO - 2023-09-20 19:59:06 --> Helper loaded: file_helper
INFO - 2023-09-20 19:59:06 --> Database Driver Class Initialized
INFO - 2023-09-20 19:59:06 --> Email Class Initialized
DEBUG - 2023-09-20 19:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 19:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 19:59:06 --> Controller Class Initialized
INFO - 2023-09-20 19:59:06 --> Model "Contact_model" initialized
INFO - 2023-09-20 19:59:06 --> Model "Home_model" initialized
INFO - 2023-09-20 19:59:06 --> Helper loaded: download_helper
INFO - 2023-09-20 19:59:06 --> Helper loaded: form_helper
INFO - 2023-09-20 19:59:06 --> Form Validation Class Initialized
INFO - 2023-09-20 19:59:06 --> Helper loaded: custom_helper
INFO - 2023-09-20 19:59:06 --> Model "Social_media_model" initialized
INFO - 2023-09-20 19:59:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 19:59:06 --> Final output sent to browser
DEBUG - 2023-09-20 19:59:07 --> Total execution time: 0.1540
INFO - 2023-09-20 19:59:07 --> Config Class Initialized
INFO - 2023-09-20 19:59:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 19:59:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 19:59:07 --> Utf8 Class Initialized
INFO - 2023-09-20 19:59:07 --> URI Class Initialized
INFO - 2023-09-20 19:59:07 --> Router Class Initialized
INFO - 2023-09-20 19:59:07 --> Output Class Initialized
INFO - 2023-09-20 19:59:07 --> Security Class Initialized
DEBUG - 2023-09-20 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 19:59:07 --> Input Class Initialized
INFO - 2023-09-20 19:59:07 --> Language Class Initialized
ERROR - 2023-09-20 19:59:07 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 20:00:07 --> Config Class Initialized
INFO - 2023-09-20 20:00:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:07 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:07 --> URI Class Initialized
INFO - 2023-09-20 20:00:07 --> Router Class Initialized
INFO - 2023-09-20 20:00:07 --> Output Class Initialized
INFO - 2023-09-20 20:00:08 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:08 --> Input Class Initialized
INFO - 2023-09-20 20:00:08 --> Language Class Initialized
INFO - 2023-09-20 20:00:08 --> Loader Class Initialized
INFO - 2023-09-20 20:00:08 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:08 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:08 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:08 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:08 --> Controller Class Initialized
INFO - 2023-09-20 20:00:08 --> Model "Services_model" initialized
INFO - 2023-09-20 20:00:08 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:00:08 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:08 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:08 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 20:00:08 --> Final output sent to browser
DEBUG - 2023-09-20 20:00:08 --> Total execution time: 0.1360
INFO - 2023-09-20 20:00:09 --> Config Class Initialized
INFO - 2023-09-20 20:00:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:09 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:09 --> URI Class Initialized
INFO - 2023-09-20 20:00:09 --> Router Class Initialized
INFO - 2023-09-20 20:00:09 --> Output Class Initialized
INFO - 2023-09-20 20:00:09 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:09 --> Input Class Initialized
INFO - 2023-09-20 20:00:09 --> Language Class Initialized
ERROR - 2023-09-20 20:00:09 --> 404 Page Not Found: admin/Services_cards/images
INFO - 2023-09-20 20:00:13 --> Config Class Initialized
INFO - 2023-09-20 20:00:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:13 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:13 --> URI Class Initialized
INFO - 2023-09-20 20:00:13 --> Router Class Initialized
INFO - 2023-09-20 20:00:13 --> Output Class Initialized
INFO - 2023-09-20 20:00:13 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:13 --> Input Class Initialized
INFO - 2023-09-20 20:00:13 --> Language Class Initialized
INFO - 2023-09-20 20:00:13 --> Loader Class Initialized
INFO - 2023-09-20 20:00:13 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:13 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:13 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:13 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:13 --> Controller Class Initialized
INFO - 2023-09-20 20:00:13 --> Model "Services_model" initialized
INFO - 2023-09-20 20:00:13 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:00:13 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:13 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 20:00:13 --> Final output sent to browser
DEBUG - 2023-09-20 20:00:13 --> Total execution time: 0.0730
INFO - 2023-09-20 20:00:14 --> Config Class Initialized
INFO - 2023-09-20 20:00:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:14 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:14 --> URI Class Initialized
INFO - 2023-09-20 20:00:14 --> Router Class Initialized
INFO - 2023-09-20 20:00:14 --> Output Class Initialized
INFO - 2023-09-20 20:00:14 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:14 --> Input Class Initialized
INFO - 2023-09-20 20:00:14 --> Language Class Initialized
INFO - 2023-09-20 20:00:14 --> Loader Class Initialized
INFO - 2023-09-20 20:00:14 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:14 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:14 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:14 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:14 --> Controller Class Initialized
INFO - 2023-09-20 20:00:14 --> Model "Services_model" initialized
INFO - 2023-09-20 20:00:14 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:00:14 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:14 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:14 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 20:00:14 --> Final output sent to browser
DEBUG - 2023-09-20 20:00:14 --> Total execution time: 0.0472
INFO - 2023-09-20 20:00:17 --> Config Class Initialized
INFO - 2023-09-20 20:00:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:17 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:17 --> URI Class Initialized
INFO - 2023-09-20 20:00:17 --> Router Class Initialized
INFO - 2023-09-20 20:00:17 --> Output Class Initialized
INFO - 2023-09-20 20:00:17 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:17 --> Input Class Initialized
INFO - 2023-09-20 20:00:17 --> Language Class Initialized
INFO - 2023-09-20 20:00:17 --> Loader Class Initialized
INFO - 2023-09-20 20:00:17 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:17 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:17 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:17 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:17 --> Controller Class Initialized
INFO - 2023-09-20 20:00:17 --> Model "Services_model" initialized
INFO - 2023-09-20 20:00:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:00:17 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:17 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 20:00:17 --> Config Class Initialized
INFO - 2023-09-20 20:00:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:17 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:17 --> URI Class Initialized
INFO - 2023-09-20 20:00:17 --> Router Class Initialized
INFO - 2023-09-20 20:00:17 --> Output Class Initialized
INFO - 2023-09-20 20:00:17 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:17 --> Input Class Initialized
INFO - 2023-09-20 20:00:17 --> Language Class Initialized
INFO - 2023-09-20 20:00:17 --> Loader Class Initialized
INFO - 2023-09-20 20:00:17 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:17 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:17 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:17 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:17 --> Controller Class Initialized
INFO - 2023-09-20 20:00:17 --> Model "Services_model" initialized
INFO - 2023-09-20 20:00:17 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:00:17 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:17 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:17 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 20:00:17 --> Final output sent to browser
DEBUG - 2023-09-20 20:00:17 --> Total execution time: 0.0948
INFO - 2023-09-20 20:00:21 --> Config Class Initialized
INFO - 2023-09-20 20:00:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:21 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:21 --> URI Class Initialized
INFO - 2023-09-20 20:00:21 --> Router Class Initialized
INFO - 2023-09-20 20:00:21 --> Output Class Initialized
INFO - 2023-09-20 20:00:21 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:21 --> Input Class Initialized
INFO - 2023-09-20 20:00:21 --> Language Class Initialized
INFO - 2023-09-20 20:00:21 --> Loader Class Initialized
INFO - 2023-09-20 20:00:21 --> Helper loaded: url_helper
INFO - 2023-09-20 20:00:21 --> Helper loaded: file_helper
INFO - 2023-09-20 20:00:21 --> Database Driver Class Initialized
INFO - 2023-09-20 20:00:21 --> Email Class Initialized
DEBUG - 2023-09-20 20:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:00:21 --> Controller Class Initialized
INFO - 2023-09-20 20:00:21 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:00:21 --> Model "Home_model" initialized
INFO - 2023-09-20 20:00:21 --> Helper loaded: download_helper
INFO - 2023-09-20 20:00:21 --> Helper loaded: form_helper
INFO - 2023-09-20 20:00:21 --> Form Validation Class Initialized
INFO - 2023-09-20 20:00:21 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:00:21 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:00:21 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 20:00:21 --> Final output sent to browser
DEBUG - 2023-09-20 20:00:21 --> Total execution time: 0.0709
INFO - 2023-09-20 20:00:21 --> Config Class Initialized
INFO - 2023-09-20 20:00:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:00:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:00:21 --> Utf8 Class Initialized
INFO - 2023-09-20 20:00:21 --> URI Class Initialized
INFO - 2023-09-20 20:00:21 --> Router Class Initialized
INFO - 2023-09-20 20:00:21 --> Output Class Initialized
INFO - 2023-09-20 20:00:21 --> Security Class Initialized
DEBUG - 2023-09-20 20:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:00:21 --> Input Class Initialized
INFO - 2023-09-20 20:00:21 --> Language Class Initialized
ERROR - 2023-09-20 20:00:21 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 20:02:23 --> Config Class Initialized
INFO - 2023-09-20 20:02:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:23 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:23 --> URI Class Initialized
INFO - 2023-09-20 20:02:23 --> Router Class Initialized
INFO - 2023-09-20 20:02:23 --> Output Class Initialized
INFO - 2023-09-20 20:02:23 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:23 --> Input Class Initialized
INFO - 2023-09-20 20:02:23 --> Language Class Initialized
INFO - 2023-09-20 20:02:23 --> Loader Class Initialized
INFO - 2023-09-20 20:02:23 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:23 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:23 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:23 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:23 --> Controller Class Initialized
INFO - 2023-09-20 20:02:23 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:02:23 --> Model "Home_model" initialized
INFO - 2023-09-20 20:02:23 --> Helper loaded: download_helper
INFO - 2023-09-20 20:02:23 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:23 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:02:23 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:02:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 20:02:23 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:23 --> Total execution time: 0.1652
INFO - 2023-09-20 20:02:24 --> Config Class Initialized
INFO - 2023-09-20 20:02:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:24 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:24 --> URI Class Initialized
INFO - 2023-09-20 20:02:24 --> Router Class Initialized
INFO - 2023-09-20 20:02:24 --> Output Class Initialized
INFO - 2023-09-20 20:02:24 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:24 --> Input Class Initialized
INFO - 2023-09-20 20:02:24 --> Language Class Initialized
ERROR - 2023-09-20 20:02:24 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 20:02:28 --> Config Class Initialized
INFO - 2023-09-20 20:02:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:28 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:28 --> URI Class Initialized
INFO - 2023-09-20 20:02:28 --> Router Class Initialized
INFO - 2023-09-20 20:02:28 --> Output Class Initialized
INFO - 2023-09-20 20:02:28 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:28 --> Input Class Initialized
INFO - 2023-09-20 20:02:28 --> Language Class Initialized
INFO - 2023-09-20 20:02:28 --> Loader Class Initialized
INFO - 2023-09-20 20:02:28 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:28 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:28 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:28 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:28 --> Controller Class Initialized
INFO - 2023-09-20 20:02:28 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:02:28 --> Model "Home_model" initialized
INFO - 2023-09-20 20:02:28 --> Helper loaded: download_helper
INFO - 2023-09-20 20:02:28 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:28 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:28 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:02:28 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:02:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 20:02:28 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:28 --> Total execution time: 0.0635
INFO - 2023-09-20 20:02:29 --> Config Class Initialized
INFO - 2023-09-20 20:02:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:29 --> URI Class Initialized
INFO - 2023-09-20 20:02:29 --> Router Class Initialized
INFO - 2023-09-20 20:02:29 --> Output Class Initialized
INFO - 2023-09-20 20:02:29 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:29 --> Input Class Initialized
INFO - 2023-09-20 20:02:29 --> Language Class Initialized
ERROR - 2023-09-20 20:02:29 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 20:02:39 --> Config Class Initialized
INFO - 2023-09-20 20:02:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:39 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:39 --> URI Class Initialized
INFO - 2023-09-20 20:02:39 --> Router Class Initialized
INFO - 2023-09-20 20:02:39 --> Output Class Initialized
INFO - 2023-09-20 20:02:39 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:39 --> Input Class Initialized
INFO - 2023-09-20 20:02:39 --> Language Class Initialized
INFO - 2023-09-20 20:02:39 --> Loader Class Initialized
INFO - 2023-09-20 20:02:39 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:39 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:39 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:39 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:39 --> Controller Class Initialized
INFO - 2023-09-20 20:02:39 --> Model "Services_model" initialized
INFO - 2023-09-20 20:02:39 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:02:39 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:39 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:39 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 20:02:39 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:39 --> Total execution time: 0.1488
INFO - 2023-09-20 20:02:40 --> Config Class Initialized
INFO - 2023-09-20 20:02:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:40 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:40 --> URI Class Initialized
INFO - 2023-09-20 20:02:40 --> Router Class Initialized
INFO - 2023-09-20 20:02:40 --> Output Class Initialized
INFO - 2023-09-20 20:02:40 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:40 --> Input Class Initialized
INFO - 2023-09-20 20:02:40 --> Language Class Initialized
INFO - 2023-09-20 20:02:40 --> Loader Class Initialized
INFO - 2023-09-20 20:02:40 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:40 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:40 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:40 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:40 --> Controller Class Initialized
INFO - 2023-09-20 20:02:40 --> Model "Services_model" initialized
INFO - 2023-09-20 20:02:40 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:02:40 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:40 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_edit.php
INFO - 2023-09-20 20:02:40 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:40 --> Total execution time: 0.0503
INFO - 2023-09-20 20:02:43 --> Config Class Initialized
INFO - 2023-09-20 20:02:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:43 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:43 --> URI Class Initialized
INFO - 2023-09-20 20:02:43 --> Router Class Initialized
INFO - 2023-09-20 20:02:43 --> Output Class Initialized
INFO - 2023-09-20 20:02:43 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:43 --> Input Class Initialized
INFO - 2023-09-20 20:02:43 --> Language Class Initialized
INFO - 2023-09-20 20:02:43 --> Loader Class Initialized
INFO - 2023-09-20 20:02:43 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:43 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:43 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:43 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:43 --> Controller Class Initialized
INFO - 2023-09-20 20:02:43 --> Model "Services_model" initialized
INFO - 2023-09-20 20:02:43 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:02:43 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:43 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 20:02:43 --> Config Class Initialized
INFO - 2023-09-20 20:02:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:43 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:43 --> URI Class Initialized
INFO - 2023-09-20 20:02:43 --> Router Class Initialized
INFO - 2023-09-20 20:02:43 --> Output Class Initialized
INFO - 2023-09-20 20:02:43 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:43 --> Input Class Initialized
INFO - 2023-09-20 20:02:43 --> Language Class Initialized
INFO - 2023-09-20 20:02:43 --> Loader Class Initialized
INFO - 2023-09-20 20:02:43 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:43 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:43 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:43 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:43 --> Controller Class Initialized
INFO - 2023-09-20 20:02:43 --> Model "Services_model" initialized
INFO - 2023-09-20 20:02:43 --> Model "Services_cards_model" initialized
INFO - 2023-09-20 20:02:43 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:43 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:43 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/services_cards_list.php
INFO - 2023-09-20 20:02:43 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:43 --> Total execution time: 0.0821
INFO - 2023-09-20 20:02:46 --> Config Class Initialized
INFO - 2023-09-20 20:02:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:46 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:46 --> URI Class Initialized
INFO - 2023-09-20 20:02:46 --> Router Class Initialized
INFO - 2023-09-20 20:02:46 --> Output Class Initialized
INFO - 2023-09-20 20:02:46 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:46 --> Input Class Initialized
INFO - 2023-09-20 20:02:46 --> Language Class Initialized
INFO - 2023-09-20 20:02:46 --> Loader Class Initialized
INFO - 2023-09-20 20:02:46 --> Helper loaded: url_helper
INFO - 2023-09-20 20:02:46 --> Helper loaded: file_helper
INFO - 2023-09-20 20:02:46 --> Database Driver Class Initialized
INFO - 2023-09-20 20:02:46 --> Email Class Initialized
DEBUG - 2023-09-20 20:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:02:46 --> Controller Class Initialized
INFO - 2023-09-20 20:02:46 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:02:46 --> Model "Home_model" initialized
INFO - 2023-09-20 20:02:46 --> Helper loaded: download_helper
INFO - 2023-09-20 20:02:46 --> Helper loaded: form_helper
INFO - 2023-09-20 20:02:46 --> Form Validation Class Initialized
INFO - 2023-09-20 20:02:46 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:02:46 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:02:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 20:02:46 --> Final output sent to browser
DEBUG - 2023-09-20 20:02:46 --> Total execution time: 0.0724
INFO - 2023-09-20 20:02:47 --> Config Class Initialized
INFO - 2023-09-20 20:02:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:02:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:02:47 --> Utf8 Class Initialized
INFO - 2023-09-20 20:02:47 --> URI Class Initialized
INFO - 2023-09-20 20:02:47 --> Router Class Initialized
INFO - 2023-09-20 20:02:47 --> Output Class Initialized
INFO - 2023-09-20 20:02:47 --> Security Class Initialized
DEBUG - 2023-09-20 20:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:02:47 --> Input Class Initialized
INFO - 2023-09-20 20:02:47 --> Language Class Initialized
ERROR - 2023-09-20 20:02:47 --> 404 Page Not Found: Assets/images
INFO - 2023-09-20 20:03:00 --> Config Class Initialized
INFO - 2023-09-20 20:03:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:03:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:03:00 --> Utf8 Class Initialized
INFO - 2023-09-20 20:03:00 --> URI Class Initialized
DEBUG - 2023-09-20 20:03:00 --> No URI present. Default controller set.
INFO - 2023-09-20 20:03:00 --> Router Class Initialized
INFO - 2023-09-20 20:03:00 --> Output Class Initialized
INFO - 2023-09-20 20:03:00 --> Security Class Initialized
DEBUG - 2023-09-20 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:03:00 --> Input Class Initialized
INFO - 2023-09-20 20:03:00 --> Language Class Initialized
INFO - 2023-09-20 20:03:00 --> Loader Class Initialized
INFO - 2023-09-20 20:03:00 --> Helper loaded: url_helper
INFO - 2023-09-20 20:03:00 --> Helper loaded: file_helper
INFO - 2023-09-20 20:03:00 --> Database Driver Class Initialized
INFO - 2023-09-20 20:03:00 --> Email Class Initialized
DEBUG - 2023-09-20 20:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:03:01 --> Controller Class Initialized
INFO - 2023-09-20 20:03:01 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:03:01 --> Model "Home_model" initialized
INFO - 2023-09-20 20:03:01 --> Helper loaded: download_helper
INFO - 2023-09-20 20:03:01 --> Helper loaded: form_helper
INFO - 2023-09-20 20:03:01 --> Form Validation Class Initialized
INFO - 2023-09-20 20:03:01 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:03:01 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:03:01 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:03:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:03:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:03:01 --> Final output sent to browser
DEBUG - 2023-09-20 20:03:01 --> Total execution time: 0.1641
INFO - 2023-09-20 20:05:32 --> Config Class Initialized
INFO - 2023-09-20 20:05:32 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:05:32 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:05:32 --> Utf8 Class Initialized
INFO - 2023-09-20 20:05:32 --> URI Class Initialized
DEBUG - 2023-09-20 20:05:32 --> No URI present. Default controller set.
INFO - 2023-09-20 20:05:32 --> Router Class Initialized
INFO - 2023-09-20 20:05:32 --> Output Class Initialized
INFO - 2023-09-20 20:05:32 --> Security Class Initialized
DEBUG - 2023-09-20 20:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:05:32 --> Input Class Initialized
INFO - 2023-09-20 20:05:32 --> Language Class Initialized
INFO - 2023-09-20 20:05:32 --> Loader Class Initialized
INFO - 2023-09-20 20:05:32 --> Helper loaded: url_helper
INFO - 2023-09-20 20:05:33 --> Helper loaded: file_helper
INFO - 2023-09-20 20:05:33 --> Database Driver Class Initialized
INFO - 2023-09-20 20:05:33 --> Email Class Initialized
DEBUG - 2023-09-20 20:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:05:33 --> Controller Class Initialized
INFO - 2023-09-20 20:05:33 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:05:33 --> Model "Home_model" initialized
INFO - 2023-09-20 20:05:33 --> Helper loaded: download_helper
INFO - 2023-09-20 20:05:33 --> Helper loaded: form_helper
INFO - 2023-09-20 20:05:33 --> Form Validation Class Initialized
INFO - 2023-09-20 20:05:33 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:05:33 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:05:33 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:05:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:05:33 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:05:33 --> Final output sent to browser
DEBUG - 2023-09-20 20:05:33 --> Total execution time: 0.1527
INFO - 2023-09-20 20:07:23 --> Config Class Initialized
INFO - 2023-09-20 20:07:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:07:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:07:23 --> Utf8 Class Initialized
INFO - 2023-09-20 20:07:23 --> URI Class Initialized
DEBUG - 2023-09-20 20:07:23 --> No URI present. Default controller set.
INFO - 2023-09-20 20:07:23 --> Router Class Initialized
INFO - 2023-09-20 20:07:23 --> Output Class Initialized
INFO - 2023-09-20 20:07:23 --> Security Class Initialized
DEBUG - 2023-09-20 20:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:07:23 --> Input Class Initialized
INFO - 2023-09-20 20:07:23 --> Language Class Initialized
INFO - 2023-09-20 20:07:23 --> Loader Class Initialized
INFO - 2023-09-20 20:07:23 --> Helper loaded: url_helper
INFO - 2023-09-20 20:07:23 --> Helper loaded: file_helper
INFO - 2023-09-20 20:07:23 --> Database Driver Class Initialized
INFO - 2023-09-20 20:07:23 --> Email Class Initialized
DEBUG - 2023-09-20 20:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:07:23 --> Controller Class Initialized
INFO - 2023-09-20 20:07:23 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:07:23 --> Model "Home_model" initialized
INFO - 2023-09-20 20:07:23 --> Helper loaded: download_helper
INFO - 2023-09-20 20:07:23 --> Helper loaded: form_helper
INFO - 2023-09-20 20:07:23 --> Form Validation Class Initialized
INFO - 2023-09-20 20:07:23 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:07:23 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:07:23 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:07:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:07:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:07:23 --> Final output sent to browser
DEBUG - 2023-09-20 20:07:23 --> Total execution time: 0.1997
INFO - 2023-09-20 20:07:25 --> Config Class Initialized
INFO - 2023-09-20 20:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:07:25 --> Utf8 Class Initialized
INFO - 2023-09-20 20:07:25 --> URI Class Initialized
INFO - 2023-09-20 20:07:25 --> Router Class Initialized
INFO - 2023-09-20 20:07:26 --> Output Class Initialized
INFO - 2023-09-20 20:07:26 --> Security Class Initialized
DEBUG - 2023-09-20 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:07:26 --> Input Class Initialized
INFO - 2023-09-20 20:07:26 --> Language Class Initialized
ERROR - 2023-09-20 20:07:26 --> 404 Page Not Found: Whatsapp-iconpng/index
INFO - 2023-09-20 20:07:52 --> Config Class Initialized
INFO - 2023-09-20 20:07:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:07:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:07:52 --> Utf8 Class Initialized
INFO - 2023-09-20 20:07:52 --> URI Class Initialized
DEBUG - 2023-09-20 20:07:52 --> No URI present. Default controller set.
INFO - 2023-09-20 20:07:53 --> Router Class Initialized
INFO - 2023-09-20 20:07:53 --> Output Class Initialized
INFO - 2023-09-20 20:07:53 --> Security Class Initialized
DEBUG - 2023-09-20 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:07:53 --> Input Class Initialized
INFO - 2023-09-20 20:07:53 --> Language Class Initialized
INFO - 2023-09-20 20:07:53 --> Loader Class Initialized
INFO - 2023-09-20 20:07:53 --> Helper loaded: url_helper
INFO - 2023-09-20 20:07:53 --> Helper loaded: file_helper
INFO - 2023-09-20 20:07:53 --> Database Driver Class Initialized
INFO - 2023-09-20 20:07:53 --> Email Class Initialized
DEBUG - 2023-09-20 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:07:53 --> Controller Class Initialized
INFO - 2023-09-20 20:07:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:07:53 --> Model "Home_model" initialized
INFO - 2023-09-20 20:07:53 --> Helper loaded: download_helper
INFO - 2023-09-20 20:07:53 --> Helper loaded: form_helper
INFO - 2023-09-20 20:07:53 --> Form Validation Class Initialized
INFO - 2023-09-20 20:07:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:07:53 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:07:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:07:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:07:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:07:53 --> Final output sent to browser
DEBUG - 2023-09-20 20:07:53 --> Total execution time: 0.1526
INFO - 2023-09-20 20:07:58 --> Config Class Initialized
INFO - 2023-09-20 20:07:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:07:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:07:58 --> Utf8 Class Initialized
INFO - 2023-09-20 20:07:58 --> URI Class Initialized
DEBUG - 2023-09-20 20:07:58 --> No URI present. Default controller set.
INFO - 2023-09-20 20:07:58 --> Router Class Initialized
INFO - 2023-09-20 20:07:58 --> Output Class Initialized
INFO - 2023-09-20 20:07:58 --> Security Class Initialized
DEBUG - 2023-09-20 20:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:07:58 --> Input Class Initialized
INFO - 2023-09-20 20:07:58 --> Language Class Initialized
INFO - 2023-09-20 20:07:58 --> Loader Class Initialized
INFO - 2023-09-20 20:07:58 --> Helper loaded: url_helper
INFO - 2023-09-20 20:07:58 --> Helper loaded: file_helper
INFO - 2023-09-20 20:07:58 --> Database Driver Class Initialized
INFO - 2023-09-20 20:07:58 --> Email Class Initialized
DEBUG - 2023-09-20 20:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:07:58 --> Controller Class Initialized
INFO - 2023-09-20 20:07:58 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:07:58 --> Model "Home_model" initialized
INFO - 2023-09-20 20:07:58 --> Helper loaded: download_helper
INFO - 2023-09-20 20:07:58 --> Helper loaded: form_helper
INFO - 2023-09-20 20:07:58 --> Form Validation Class Initialized
INFO - 2023-09-20 20:07:58 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:07:58 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:07:58 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:07:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:07:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:07:58 --> Final output sent to browser
DEBUG - 2023-09-20 20:07:58 --> Total execution time: 0.1182
INFO - 2023-09-20 20:08:17 --> Config Class Initialized
INFO - 2023-09-20 20:08:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:08:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:08:17 --> Utf8 Class Initialized
INFO - 2023-09-20 20:08:17 --> URI Class Initialized
DEBUG - 2023-09-20 20:08:17 --> No URI present. Default controller set.
INFO - 2023-09-20 20:08:17 --> Router Class Initialized
INFO - 2023-09-20 20:08:17 --> Output Class Initialized
INFO - 2023-09-20 20:08:17 --> Security Class Initialized
DEBUG - 2023-09-20 20:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:08:17 --> Input Class Initialized
INFO - 2023-09-20 20:08:17 --> Language Class Initialized
INFO - 2023-09-20 20:08:17 --> Loader Class Initialized
INFO - 2023-09-20 20:08:17 --> Helper loaded: url_helper
INFO - 2023-09-20 20:08:17 --> Helper loaded: file_helper
INFO - 2023-09-20 20:08:17 --> Database Driver Class Initialized
INFO - 2023-09-20 20:08:17 --> Email Class Initialized
DEBUG - 2023-09-20 20:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:08:17 --> Controller Class Initialized
INFO - 2023-09-20 20:08:17 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:08:17 --> Model "Home_model" initialized
INFO - 2023-09-20 20:08:17 --> Helper loaded: download_helper
INFO - 2023-09-20 20:08:17 --> Helper loaded: form_helper
INFO - 2023-09-20 20:08:17 --> Form Validation Class Initialized
INFO - 2023-09-20 20:08:17 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:08:17 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:08:17 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:08:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:08:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:08:18 --> Final output sent to browser
DEBUG - 2023-09-20 20:08:18 --> Total execution time: 0.1526
INFO - 2023-09-20 20:08:51 --> Config Class Initialized
INFO - 2023-09-20 20:08:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:08:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:08:51 --> Utf8 Class Initialized
INFO - 2023-09-20 20:08:51 --> URI Class Initialized
DEBUG - 2023-09-20 20:08:51 --> No URI present. Default controller set.
INFO - 2023-09-20 20:08:51 --> Router Class Initialized
INFO - 2023-09-20 20:08:51 --> Output Class Initialized
INFO - 2023-09-20 20:08:51 --> Security Class Initialized
DEBUG - 2023-09-20 20:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:08:51 --> Input Class Initialized
INFO - 2023-09-20 20:08:51 --> Language Class Initialized
INFO - 2023-09-20 20:08:51 --> Loader Class Initialized
INFO - 2023-09-20 20:08:51 --> Helper loaded: url_helper
INFO - 2023-09-20 20:08:51 --> Helper loaded: file_helper
INFO - 2023-09-20 20:08:51 --> Database Driver Class Initialized
INFO - 2023-09-20 20:08:51 --> Email Class Initialized
DEBUG - 2023-09-20 20:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:08:51 --> Controller Class Initialized
INFO - 2023-09-20 20:08:51 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:08:51 --> Model "Home_model" initialized
INFO - 2023-09-20 20:08:51 --> Helper loaded: download_helper
INFO - 2023-09-20 20:08:51 --> Helper loaded: form_helper
INFO - 2023-09-20 20:08:51 --> Form Validation Class Initialized
INFO - 2023-09-20 20:08:51 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:08:51 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:08:51 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:08:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:08:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:08:51 --> Final output sent to browser
DEBUG - 2023-09-20 20:08:51 --> Total execution time: 0.1323
INFO - 2023-09-20 20:09:29 --> Config Class Initialized
INFO - 2023-09-20 20:09:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:09:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:09:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:09:29 --> URI Class Initialized
DEBUG - 2023-09-20 20:09:29 --> No URI present. Default controller set.
INFO - 2023-09-20 20:09:29 --> Router Class Initialized
INFO - 2023-09-20 20:09:29 --> Output Class Initialized
INFO - 2023-09-20 20:09:29 --> Security Class Initialized
DEBUG - 2023-09-20 20:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:09:29 --> Input Class Initialized
INFO - 2023-09-20 20:09:29 --> Language Class Initialized
INFO - 2023-09-20 20:09:29 --> Loader Class Initialized
INFO - 2023-09-20 20:09:29 --> Helper loaded: url_helper
INFO - 2023-09-20 20:09:29 --> Helper loaded: file_helper
INFO - 2023-09-20 20:09:29 --> Database Driver Class Initialized
INFO - 2023-09-20 20:09:29 --> Email Class Initialized
DEBUG - 2023-09-20 20:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:09:29 --> Controller Class Initialized
INFO - 2023-09-20 20:09:29 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:09:29 --> Model "Home_model" initialized
INFO - 2023-09-20 20:09:29 --> Helper loaded: download_helper
INFO - 2023-09-20 20:09:29 --> Helper loaded: form_helper
INFO - 2023-09-20 20:09:29 --> Form Validation Class Initialized
INFO - 2023-09-20 20:09:29 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:09:29 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:09:29 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:09:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:09:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:09:29 --> Final output sent to browser
DEBUG - 2023-09-20 20:09:29 --> Total execution time: 0.2135
INFO - 2023-09-20 20:10:07 --> Config Class Initialized
INFO - 2023-09-20 20:10:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:10:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:10:07 --> Utf8 Class Initialized
INFO - 2023-09-20 20:10:07 --> URI Class Initialized
DEBUG - 2023-09-20 20:10:07 --> No URI present. Default controller set.
INFO - 2023-09-20 20:10:07 --> Router Class Initialized
INFO - 2023-09-20 20:10:07 --> Output Class Initialized
INFO - 2023-09-20 20:10:07 --> Security Class Initialized
DEBUG - 2023-09-20 20:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:10:07 --> Input Class Initialized
INFO - 2023-09-20 20:10:07 --> Language Class Initialized
INFO - 2023-09-20 20:10:07 --> Loader Class Initialized
INFO - 2023-09-20 20:10:07 --> Helper loaded: url_helper
INFO - 2023-09-20 20:10:07 --> Helper loaded: file_helper
INFO - 2023-09-20 20:10:07 --> Database Driver Class Initialized
INFO - 2023-09-20 20:10:07 --> Email Class Initialized
DEBUG - 2023-09-20 20:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:10:07 --> Controller Class Initialized
INFO - 2023-09-20 20:10:07 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:10:07 --> Model "Home_model" initialized
INFO - 2023-09-20 20:10:07 --> Helper loaded: download_helper
INFO - 2023-09-20 20:10:07 --> Helper loaded: form_helper
INFO - 2023-09-20 20:10:07 --> Form Validation Class Initialized
INFO - 2023-09-20 20:10:07 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:10:07 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:10:07 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:10:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:10:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:10:07 --> Final output sent to browser
DEBUG - 2023-09-20 20:10:07 --> Total execution time: 0.2880
INFO - 2023-09-20 20:10:16 --> Config Class Initialized
INFO - 2023-09-20 20:10:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:10:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:10:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:10:16 --> URI Class Initialized
DEBUG - 2023-09-20 20:10:16 --> No URI present. Default controller set.
INFO - 2023-09-20 20:10:16 --> Router Class Initialized
INFO - 2023-09-20 20:10:16 --> Output Class Initialized
INFO - 2023-09-20 20:10:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:10:16 --> Input Class Initialized
INFO - 2023-09-20 20:10:16 --> Language Class Initialized
INFO - 2023-09-20 20:10:16 --> Loader Class Initialized
INFO - 2023-09-20 20:10:16 --> Helper loaded: url_helper
INFO - 2023-09-20 20:10:16 --> Helper loaded: file_helper
INFO - 2023-09-20 20:10:16 --> Database Driver Class Initialized
INFO - 2023-09-20 20:10:16 --> Email Class Initialized
DEBUG - 2023-09-20 20:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:10:16 --> Controller Class Initialized
INFO - 2023-09-20 20:10:16 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:10:16 --> Model "Home_model" initialized
INFO - 2023-09-20 20:10:16 --> Helper loaded: download_helper
INFO - 2023-09-20 20:10:16 --> Helper loaded: form_helper
INFO - 2023-09-20 20:10:16 --> Form Validation Class Initialized
INFO - 2023-09-20 20:10:16 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:10:16 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:10:17 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:10:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:10:17 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:10:17 --> Final output sent to browser
DEBUG - 2023-09-20 20:10:17 --> Total execution time: 0.1977
INFO - 2023-09-20 20:10:59 --> Config Class Initialized
INFO - 2023-09-20 20:10:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:10:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:10:59 --> Utf8 Class Initialized
INFO - 2023-09-20 20:10:59 --> URI Class Initialized
DEBUG - 2023-09-20 20:10:59 --> No URI present. Default controller set.
INFO - 2023-09-20 20:10:59 --> Router Class Initialized
INFO - 2023-09-20 20:10:59 --> Output Class Initialized
INFO - 2023-09-20 20:10:59 --> Security Class Initialized
DEBUG - 2023-09-20 20:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:10:59 --> Input Class Initialized
INFO - 2023-09-20 20:10:59 --> Language Class Initialized
INFO - 2023-09-20 20:10:59 --> Loader Class Initialized
INFO - 2023-09-20 20:10:59 --> Helper loaded: url_helper
INFO - 2023-09-20 20:10:59 --> Helper loaded: file_helper
INFO - 2023-09-20 20:10:59 --> Database Driver Class Initialized
INFO - 2023-09-20 20:10:59 --> Email Class Initialized
DEBUG - 2023-09-20 20:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:10:59 --> Controller Class Initialized
INFO - 2023-09-20 20:10:59 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:10:59 --> Model "Home_model" initialized
INFO - 2023-09-20 20:10:59 --> Helper loaded: download_helper
INFO - 2023-09-20 20:10:59 --> Helper loaded: form_helper
INFO - 2023-09-20 20:10:59 --> Form Validation Class Initialized
INFO - 2023-09-20 20:10:59 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:10:59 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:10:59 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:10:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:10:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:10:59 --> Final output sent to browser
DEBUG - 2023-09-20 20:10:59 --> Total execution time: 0.1996
INFO - 2023-09-20 20:11:34 --> Config Class Initialized
INFO - 2023-09-20 20:11:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:11:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:11:34 --> Utf8 Class Initialized
INFO - 2023-09-20 20:11:34 --> URI Class Initialized
DEBUG - 2023-09-20 20:11:34 --> No URI present. Default controller set.
INFO - 2023-09-20 20:11:34 --> Router Class Initialized
INFO - 2023-09-20 20:11:34 --> Output Class Initialized
INFO - 2023-09-20 20:11:34 --> Security Class Initialized
DEBUG - 2023-09-20 20:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:11:34 --> Input Class Initialized
INFO - 2023-09-20 20:11:34 --> Language Class Initialized
INFO - 2023-09-20 20:11:34 --> Loader Class Initialized
INFO - 2023-09-20 20:11:34 --> Helper loaded: url_helper
INFO - 2023-09-20 20:11:34 --> Helper loaded: file_helper
INFO - 2023-09-20 20:11:34 --> Database Driver Class Initialized
INFO - 2023-09-20 20:11:34 --> Email Class Initialized
DEBUG - 2023-09-20 20:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:11:34 --> Controller Class Initialized
INFO - 2023-09-20 20:11:34 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:11:34 --> Model "Home_model" initialized
INFO - 2023-09-20 20:11:34 --> Helper loaded: download_helper
INFO - 2023-09-20 20:11:34 --> Helper loaded: form_helper
INFO - 2023-09-20 20:11:34 --> Form Validation Class Initialized
INFO - 2023-09-20 20:11:34 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:11:34 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:11:34 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:11:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:11:34 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:11:34 --> Final output sent to browser
DEBUG - 2023-09-20 20:11:34 --> Total execution time: 0.1987
INFO - 2023-09-20 20:11:53 --> Config Class Initialized
INFO - 2023-09-20 20:11:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:11:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:11:53 --> Utf8 Class Initialized
INFO - 2023-09-20 20:11:53 --> URI Class Initialized
DEBUG - 2023-09-20 20:11:53 --> No URI present. Default controller set.
INFO - 2023-09-20 20:11:53 --> Router Class Initialized
INFO - 2023-09-20 20:11:53 --> Output Class Initialized
INFO - 2023-09-20 20:11:53 --> Security Class Initialized
DEBUG - 2023-09-20 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:11:53 --> Input Class Initialized
INFO - 2023-09-20 20:11:53 --> Language Class Initialized
INFO - 2023-09-20 20:11:53 --> Loader Class Initialized
INFO - 2023-09-20 20:11:53 --> Helper loaded: url_helper
INFO - 2023-09-20 20:11:53 --> Helper loaded: file_helper
INFO - 2023-09-20 20:11:53 --> Database Driver Class Initialized
INFO - 2023-09-20 20:11:53 --> Email Class Initialized
DEBUG - 2023-09-20 20:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:11:53 --> Controller Class Initialized
INFO - 2023-09-20 20:11:53 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:11:53 --> Model "Home_model" initialized
INFO - 2023-09-20 20:11:53 --> Helper loaded: download_helper
INFO - 2023-09-20 20:11:53 --> Helper loaded: form_helper
INFO - 2023-09-20 20:11:53 --> Form Validation Class Initialized
INFO - 2023-09-20 20:11:53 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:11:53 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:11:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:11:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:11:53 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:11:53 --> Final output sent to browser
DEBUG - 2023-09-20 20:11:53 --> Total execution time: 0.1936
INFO - 2023-09-20 20:12:57 --> Config Class Initialized
INFO - 2023-09-20 20:12:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:12:57 --> Utf8 Class Initialized
INFO - 2023-09-20 20:12:57 --> URI Class Initialized
DEBUG - 2023-09-20 20:12:57 --> No URI present. Default controller set.
INFO - 2023-09-20 20:12:57 --> Router Class Initialized
INFO - 2023-09-20 20:12:57 --> Output Class Initialized
INFO - 2023-09-20 20:12:57 --> Security Class Initialized
DEBUG - 2023-09-20 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:12:57 --> Input Class Initialized
INFO - 2023-09-20 20:12:57 --> Language Class Initialized
INFO - 2023-09-20 20:12:57 --> Loader Class Initialized
INFO - 2023-09-20 20:12:58 --> Helper loaded: url_helper
INFO - 2023-09-20 20:12:58 --> Helper loaded: file_helper
INFO - 2023-09-20 20:12:58 --> Database Driver Class Initialized
INFO - 2023-09-20 20:12:58 --> Email Class Initialized
DEBUG - 2023-09-20 20:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:12:58 --> Controller Class Initialized
INFO - 2023-09-20 20:12:58 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:12:58 --> Model "Home_model" initialized
INFO - 2023-09-20 20:12:58 --> Helper loaded: download_helper
INFO - 2023-09-20 20:12:58 --> Helper loaded: form_helper
INFO - 2023-09-20 20:12:58 --> Form Validation Class Initialized
INFO - 2023-09-20 20:12:58 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:12:58 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:12:58 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:12:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:12:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:12:58 --> Final output sent to browser
DEBUG - 2023-09-20 20:12:58 --> Total execution time: 0.2090
INFO - 2023-09-20 20:13:18 --> Config Class Initialized
INFO - 2023-09-20 20:13:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:13:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:13:18 --> Utf8 Class Initialized
INFO - 2023-09-20 20:13:18 --> URI Class Initialized
DEBUG - 2023-09-20 20:13:18 --> No URI present. Default controller set.
INFO - 2023-09-20 20:13:18 --> Router Class Initialized
INFO - 2023-09-20 20:13:18 --> Output Class Initialized
INFO - 2023-09-20 20:13:18 --> Security Class Initialized
DEBUG - 2023-09-20 20:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:13:18 --> Input Class Initialized
INFO - 2023-09-20 20:13:18 --> Language Class Initialized
INFO - 2023-09-20 20:13:18 --> Loader Class Initialized
INFO - 2023-09-20 20:13:18 --> Helper loaded: url_helper
INFO - 2023-09-20 20:13:18 --> Helper loaded: file_helper
INFO - 2023-09-20 20:13:18 --> Database Driver Class Initialized
INFO - 2023-09-20 20:13:18 --> Email Class Initialized
DEBUG - 2023-09-20 20:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:13:18 --> Controller Class Initialized
INFO - 2023-09-20 20:13:18 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:13:18 --> Model "Home_model" initialized
INFO - 2023-09-20 20:13:18 --> Helper loaded: download_helper
INFO - 2023-09-20 20:13:18 --> Helper loaded: form_helper
INFO - 2023-09-20 20:13:18 --> Form Validation Class Initialized
INFO - 2023-09-20 20:13:18 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:13:18 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:13:18 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:13:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:13:18 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:13:18 --> Final output sent to browser
DEBUG - 2023-09-20 20:13:18 --> Total execution time: 0.2108
INFO - 2023-09-20 20:14:51 --> Config Class Initialized
INFO - 2023-09-20 20:14:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:14:51 --> Utf8 Class Initialized
INFO - 2023-09-20 20:14:51 --> URI Class Initialized
DEBUG - 2023-09-20 20:14:51 --> No URI present. Default controller set.
INFO - 2023-09-20 20:14:51 --> Router Class Initialized
INFO - 2023-09-20 20:14:51 --> Output Class Initialized
INFO - 2023-09-20 20:14:51 --> Security Class Initialized
DEBUG - 2023-09-20 20:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:14:51 --> Input Class Initialized
INFO - 2023-09-20 20:14:51 --> Language Class Initialized
INFO - 2023-09-20 20:14:51 --> Loader Class Initialized
INFO - 2023-09-20 20:14:51 --> Helper loaded: url_helper
INFO - 2023-09-20 20:14:51 --> Helper loaded: file_helper
INFO - 2023-09-20 20:14:51 --> Database Driver Class Initialized
INFO - 2023-09-20 20:14:51 --> Email Class Initialized
DEBUG - 2023-09-20 20:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:14:51 --> Controller Class Initialized
INFO - 2023-09-20 20:14:51 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:14:51 --> Model "Home_model" initialized
INFO - 2023-09-20 20:14:51 --> Helper loaded: download_helper
INFO - 2023-09-20 20:14:51 --> Helper loaded: form_helper
INFO - 2023-09-20 20:14:51 --> Form Validation Class Initialized
INFO - 2023-09-20 20:14:51 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:14:51 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:14:51 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:14:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:14:51 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:14:51 --> Final output sent to browser
DEBUG - 2023-09-20 20:14:52 --> Total execution time: 0.2477
INFO - 2023-09-20 20:16:00 --> Config Class Initialized
INFO - 2023-09-20 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:00 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:00 --> URI Class Initialized
DEBUG - 2023-09-20 20:16:00 --> No URI present. Default controller set.
INFO - 2023-09-20 20:16:00 --> Router Class Initialized
INFO - 2023-09-20 20:16:00 --> Output Class Initialized
INFO - 2023-09-20 20:16:00 --> Security Class Initialized
DEBUG - 2023-09-20 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:16:00 --> Input Class Initialized
INFO - 2023-09-20 20:16:00 --> Language Class Initialized
INFO - 2023-09-20 20:16:00 --> Loader Class Initialized
INFO - 2023-09-20 20:16:00 --> Helper loaded: url_helper
INFO - 2023-09-20 20:16:00 --> Helper loaded: file_helper
INFO - 2023-09-20 20:16:00 --> Database Driver Class Initialized
INFO - 2023-09-20 20:16:00 --> Email Class Initialized
DEBUG - 2023-09-20 20:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:16:00 --> Controller Class Initialized
INFO - 2023-09-20 20:16:00 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:16:00 --> Model "Home_model" initialized
INFO - 2023-09-20 20:16:00 --> Helper loaded: download_helper
INFO - 2023-09-20 20:16:00 --> Helper loaded: form_helper
INFO - 2023-09-20 20:16:00 --> Form Validation Class Initialized
INFO - 2023-09-20 20:16:00 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:16:00 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:16:00 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:16:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:16:00 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:16:00 --> Final output sent to browser
DEBUG - 2023-09-20 20:16:00 --> Total execution time: 0.2144
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:16:29 --> Config Class Initialized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:16:29 --> Hooks Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
DEBUG - 2023-09-20 20:16:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:16:29 --> Utf8 Class Initialized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
INFO - 2023-09-20 20:16:29 --> URI Class Initialized
INFO - 2023-09-20 20:16:29 --> Router Class Initialized
INFO - 2023-09-20 20:16:29 --> Output Class Initialized
INFO - 2023-09-20 20:16:29 --> Security Class Initialized
DEBUG - 2023-09-20 20:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:16:29 --> Input Class Initialized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:16:29 --> Language Class Initialized
ERROR - 2023-09-20 20:16:29 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:17:06 --> Config Class Initialized
INFO - 2023-09-20 20:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:06 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:06 --> URI Class Initialized
DEBUG - 2023-09-20 20:17:06 --> No URI present. Default controller set.
INFO - 2023-09-20 20:17:06 --> Router Class Initialized
INFO - 2023-09-20 20:17:06 --> Output Class Initialized
INFO - 2023-09-20 20:17:06 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:06 --> Input Class Initialized
INFO - 2023-09-20 20:17:06 --> Language Class Initialized
INFO - 2023-09-20 20:17:06 --> Loader Class Initialized
INFO - 2023-09-20 20:17:06 --> Helper loaded: url_helper
INFO - 2023-09-20 20:17:06 --> Helper loaded: file_helper
INFO - 2023-09-20 20:17:06 --> Database Driver Class Initialized
INFO - 2023-09-20 20:17:06 --> Email Class Initialized
DEBUG - 2023-09-20 20:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:17:06 --> Controller Class Initialized
INFO - 2023-09-20 20:17:06 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:17:06 --> Model "Home_model" initialized
INFO - 2023-09-20 20:17:06 --> Helper loaded: download_helper
INFO - 2023-09-20 20:17:06 --> Helper loaded: form_helper
INFO - 2023-09-20 20:17:06 --> Form Validation Class Initialized
INFO - 2023-09-20 20:17:06 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:17:06 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:17:06 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:17:06 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:17:07 --> Final output sent to browser
DEBUG - 2023-09-20 20:17:07 --> Total execution time: 0.1522
INFO - 2023-09-20 20:17:14 --> Config Class Initialized
INFO - 2023-09-20 20:17:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:14 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:14 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:14 --> URI Class Initialized
INFO - 2023-09-20 20:17:14 --> Router Class Initialized
INFO - 2023-09-20 20:17:14 --> Output Class Initialized
INFO - 2023-09-20 20:17:14 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:14 --> Input Class Initialized
INFO - 2023-09-20 20:17:14 --> Language Class Initialized
ERROR - 2023-09-20 20:17:14 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:17:14 --> Config Class Initialized
INFO - 2023-09-20 20:17:14 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:15 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:15 --> URI Class Initialized
INFO - 2023-09-20 20:17:15 --> Router Class Initialized
INFO - 2023-09-20 20:17:15 --> Output Class Initialized
INFO - 2023-09-20 20:17:15 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:15 --> Input Class Initialized
INFO - 2023-09-20 20:17:15 --> Language Class Initialized
ERROR - 2023-09-20 20:17:15 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:17:16 --> Config Class Initialized
INFO - 2023-09-20 20:17:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:16 --> URI Class Initialized
INFO - 2023-09-20 20:17:16 --> Router Class Initialized
INFO - 2023-09-20 20:17:16 --> Output Class Initialized
INFO - 2023-09-20 20:17:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:16 --> Input Class Initialized
INFO - 2023-09-20 20:17:16 --> Language Class Initialized
ERROR - 2023-09-20 20:17:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:17:16 --> Config Class Initialized
INFO - 2023-09-20 20:17:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:16 --> URI Class Initialized
INFO - 2023-09-20 20:17:16 --> Router Class Initialized
INFO - 2023-09-20 20:17:16 --> Output Class Initialized
INFO - 2023-09-20 20:17:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:16 --> Input Class Initialized
INFO - 2023-09-20 20:17:16 --> Language Class Initialized
ERROR - 2023-09-20 20:17:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:17:16 --> Config Class Initialized
INFO - 2023-09-20 20:17:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:17:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:17:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:17:16 --> URI Class Initialized
INFO - 2023-09-20 20:17:16 --> Router Class Initialized
INFO - 2023-09-20 20:17:16 --> Output Class Initialized
INFO - 2023-09-20 20:17:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:17:16 --> Input Class Initialized
INFO - 2023-09-20 20:17:16 --> Language Class Initialized
ERROR - 2023-09-20 20:17:16 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:19:25 --> Config Class Initialized
INFO - 2023-09-20 20:19:25 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:19:25 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:19:25 --> Utf8 Class Initialized
INFO - 2023-09-20 20:19:25 --> URI Class Initialized
DEBUG - 2023-09-20 20:19:25 --> No URI present. Default controller set.
INFO - 2023-09-20 20:19:25 --> Router Class Initialized
INFO - 2023-09-20 20:19:25 --> Output Class Initialized
INFO - 2023-09-20 20:19:25 --> Security Class Initialized
DEBUG - 2023-09-20 20:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:19:25 --> Input Class Initialized
INFO - 2023-09-20 20:19:25 --> Language Class Initialized
INFO - 2023-09-20 20:19:25 --> Loader Class Initialized
INFO - 2023-09-20 20:19:25 --> Helper loaded: url_helper
INFO - 2023-09-20 20:19:25 --> Helper loaded: file_helper
INFO - 2023-09-20 20:19:25 --> Database Driver Class Initialized
INFO - 2023-09-20 20:19:25 --> Email Class Initialized
DEBUG - 2023-09-20 20:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:19:25 --> Controller Class Initialized
INFO - 2023-09-20 20:19:25 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:19:25 --> Model "Home_model" initialized
INFO - 2023-09-20 20:19:25 --> Helper loaded: download_helper
INFO - 2023-09-20 20:19:25 --> Helper loaded: form_helper
INFO - 2023-09-20 20:19:25 --> Form Validation Class Initialized
INFO - 2023-09-20 20:19:25 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:19:25 --> Model "Social_media_model" initialized
ERROR - 2023-09-20 20:19:25 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\dw\application\views\home\index.php 174
ERROR - 2023-09-20 20:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\dw\application\views\home\index.php 174
INFO - 2023-09-20 20:19:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-09-20 20:19:25 --> Final output sent to browser
DEBUG - 2023-09-20 20:19:25 --> Total execution time: 0.4561
INFO - 2023-09-20 20:19:35 --> Config Class Initialized
INFO - 2023-09-20 20:19:35 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:19:35 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:19:35 --> Utf8 Class Initialized
INFO - 2023-09-20 20:19:35 --> URI Class Initialized
INFO - 2023-09-20 20:19:35 --> Router Class Initialized
INFO - 2023-09-20 20:19:35 --> Output Class Initialized
INFO - 2023-09-20 20:19:35 --> Security Class Initialized
DEBUG - 2023-09-20 20:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:19:35 --> Input Class Initialized
INFO - 2023-09-20 20:19:35 --> Language Class Initialized
INFO - 2023-09-20 20:19:35 --> Loader Class Initialized
INFO - 2023-09-20 20:19:35 --> Helper loaded: url_helper
INFO - 2023-09-20 20:19:35 --> Helper loaded: file_helper
INFO - 2023-09-20 20:19:35 --> Database Driver Class Initialized
INFO - 2023-09-20 20:19:35 --> Email Class Initialized
DEBUG - 2023-09-20 20:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:19:35 --> Controller Class Initialized
INFO - 2023-09-20 20:19:35 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:19:35 --> Model "Home_model" initialized
INFO - 2023-09-20 20:19:35 --> Helper loaded: download_helper
INFO - 2023-09-20 20:19:35 --> Helper loaded: form_helper
INFO - 2023-09-20 20:19:35 --> Form Validation Class Initialized
INFO - 2023-09-20 20:19:35 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:19:35 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:19:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 20:19:35 --> Final output sent to browser
DEBUG - 2023-09-20 20:19:35 --> Total execution time: 0.3848
INFO - 2023-09-20 20:20:48 --> Config Class Initialized
INFO - 2023-09-20 20:20:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:20:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:20:48 --> Utf8 Class Initialized
INFO - 2023-09-20 20:20:48 --> URI Class Initialized
INFO - 2023-09-20 20:20:48 --> Router Class Initialized
INFO - 2023-09-20 20:20:48 --> Output Class Initialized
INFO - 2023-09-20 20:20:48 --> Security Class Initialized
DEBUG - 2023-09-20 20:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:20:48 --> Input Class Initialized
INFO - 2023-09-20 20:20:48 --> Language Class Initialized
INFO - 2023-09-20 20:20:48 --> Loader Class Initialized
INFO - 2023-09-20 20:20:48 --> Helper loaded: url_helper
INFO - 2023-09-20 20:20:48 --> Helper loaded: file_helper
INFO - 2023-09-20 20:20:48 --> Database Driver Class Initialized
INFO - 2023-09-20 20:20:48 --> Email Class Initialized
DEBUG - 2023-09-20 20:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:20:48 --> Controller Class Initialized
INFO - 2023-09-20 20:20:48 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:20:48 --> Model "Home_model" initialized
INFO - 2023-09-20 20:20:48 --> Helper loaded: download_helper
INFO - 2023-09-20 20:20:48 --> Helper loaded: form_helper
INFO - 2023-09-20 20:20:48 --> Form Validation Class Initialized
INFO - 2023-09-20 20:20:48 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:20:48 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:20:48 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 20:20:48 --> Final output sent to browser
DEBUG - 2023-09-20 20:20:48 --> Total execution time: 0.1427
INFO - 2023-09-20 20:21:07 --> Config Class Initialized
INFO - 2023-09-20 20:21:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:21:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:21:07 --> Utf8 Class Initialized
INFO - 2023-09-20 20:21:07 --> URI Class Initialized
INFO - 2023-09-20 20:21:07 --> Router Class Initialized
INFO - 2023-09-20 20:21:07 --> Output Class Initialized
INFO - 2023-09-20 20:21:07 --> Security Class Initialized
DEBUG - 2023-09-20 20:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:21:07 --> Input Class Initialized
INFO - 2023-09-20 20:21:07 --> Language Class Initialized
INFO - 2023-09-20 20:21:07 --> Loader Class Initialized
INFO - 2023-09-20 20:21:07 --> Helper loaded: url_helper
INFO - 2023-09-20 20:21:07 --> Helper loaded: file_helper
INFO - 2023-09-20 20:21:07 --> Database Driver Class Initialized
INFO - 2023-09-20 20:21:07 --> Email Class Initialized
DEBUG - 2023-09-20 20:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:21:07 --> Controller Class Initialized
INFO - 2023-09-20 20:21:07 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:21:07 --> Model "Home_model" initialized
INFO - 2023-09-20 20:21:07 --> Helper loaded: download_helper
INFO - 2023-09-20 20:21:07 --> Helper loaded: form_helper
INFO - 2023-09-20 20:21:07 --> Form Validation Class Initialized
INFO - 2023-09-20 20:21:07 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:21:07 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:21:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-09-20 20:21:07 --> Final output sent to browser
DEBUG - 2023-09-20 20:21:07 --> Total execution time: 0.1296
INFO - 2023-09-20 20:21:45 --> Config Class Initialized
INFO - 2023-09-20 20:21:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:21:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:21:45 --> Utf8 Class Initialized
INFO - 2023-09-20 20:21:45 --> URI Class Initialized
INFO - 2023-09-20 20:21:45 --> Router Class Initialized
INFO - 2023-09-20 20:21:45 --> Output Class Initialized
INFO - 2023-09-20 20:21:45 --> Security Class Initialized
DEBUG - 2023-09-20 20:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:21:45 --> Input Class Initialized
INFO - 2023-09-20 20:21:45 --> Language Class Initialized
INFO - 2023-09-20 20:21:45 --> Loader Class Initialized
INFO - 2023-09-20 20:21:45 --> Helper loaded: url_helper
INFO - 2023-09-20 20:21:45 --> Helper loaded: file_helper
INFO - 2023-09-20 20:21:45 --> Database Driver Class Initialized
INFO - 2023-09-20 20:21:45 --> Email Class Initialized
DEBUG - 2023-09-20 20:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:21:45 --> Controller Class Initialized
INFO - 2023-09-20 20:21:45 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:21:45 --> Model "Home_model" initialized
INFO - 2023-09-20 20:21:45 --> Helper loaded: download_helper
INFO - 2023-09-20 20:21:45 --> Helper loaded: form_helper
INFO - 2023-09-20 20:21:45 --> Form Validation Class Initialized
INFO - 2023-09-20 20:31:57 --> Config Class Initialized
INFO - 2023-09-20 20:31:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:31:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:31:57 --> Utf8 Class Initialized
INFO - 2023-09-20 20:31:57 --> URI Class Initialized
INFO - 2023-09-20 20:31:57 --> Router Class Initialized
INFO - 2023-09-20 20:31:57 --> Output Class Initialized
INFO - 2023-09-20 20:31:57 --> Security Class Initialized
DEBUG - 2023-09-20 20:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:31:57 --> Input Class Initialized
INFO - 2023-09-20 20:31:57 --> Language Class Initialized
INFO - 2023-09-20 20:31:57 --> Loader Class Initialized
INFO - 2023-09-20 20:31:57 --> Helper loaded: url_helper
INFO - 2023-09-20 20:31:57 --> Helper loaded: file_helper
INFO - 2023-09-20 20:31:57 --> Database Driver Class Initialized
INFO - 2023-09-20 20:31:57 --> Email Class Initialized
DEBUG - 2023-09-20 20:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:31:57 --> Controller Class Initialized
INFO - 2023-09-20 20:31:57 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:31:57 --> Model "Home_model" initialized
INFO - 2023-09-20 20:31:57 --> Helper loaded: download_helper
INFO - 2023-09-20 20:31:57 --> Helper loaded: form_helper
INFO - 2023-09-20 20:31:57 --> Form Validation Class Initialized
INFO - 2023-09-20 20:31:57 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:31:57 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:31:57 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-20 20:31:57 --> Final output sent to browser
DEBUG - 2023-09-20 20:31:57 --> Total execution time: 0.1462
INFO - 2023-09-20 20:32:01 --> Config Class Initialized
INFO - 2023-09-20 20:32:01 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:32:01 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:32:01 --> Utf8 Class Initialized
INFO - 2023-09-20 20:32:01 --> URI Class Initialized
INFO - 2023-09-20 20:32:01 --> Router Class Initialized
INFO - 2023-09-20 20:32:01 --> Output Class Initialized
INFO - 2023-09-20 20:32:01 --> Security Class Initialized
DEBUG - 2023-09-20 20:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:32:01 --> Input Class Initialized
INFO - 2023-09-20 20:32:01 --> Language Class Initialized
INFO - 2023-09-20 20:32:01 --> Loader Class Initialized
INFO - 2023-09-20 20:32:01 --> Helper loaded: url_helper
INFO - 2023-09-20 20:32:01 --> Helper loaded: file_helper
INFO - 2023-09-20 20:32:01 --> Database Driver Class Initialized
INFO - 2023-09-20 20:32:02 --> Email Class Initialized
DEBUG - 2023-09-20 20:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:32:02 --> Controller Class Initialized
INFO - 2023-09-20 20:32:02 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:32:02 --> Model "Home_model" initialized
INFO - 2023-09-20 20:32:02 --> Helper loaded: download_helper
INFO - 2023-09-20 20:32:02 --> Helper loaded: form_helper
INFO - 2023-09-20 20:32:02 --> Form Validation Class Initialized
INFO - 2023-09-20 20:32:02 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:32:02 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:32:02 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-20 20:32:02 --> Final output sent to browser
DEBUG - 2023-09-20 20:32:02 --> Total execution time: 0.4260
INFO - 2023-09-20 20:33:16 --> Config Class Initialized
INFO - 2023-09-20 20:33:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:33:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:33:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:33:16 --> URI Class Initialized
INFO - 2023-09-20 20:33:16 --> Router Class Initialized
INFO - 2023-09-20 20:33:16 --> Output Class Initialized
INFO - 2023-09-20 20:33:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:33:16 --> Input Class Initialized
INFO - 2023-09-20 20:33:16 --> Language Class Initialized
INFO - 2023-09-20 20:33:16 --> Loader Class Initialized
INFO - 2023-09-20 20:33:16 --> Helper loaded: url_helper
INFO - 2023-09-20 20:33:16 --> Helper loaded: file_helper
INFO - 2023-09-20 20:33:16 --> Database Driver Class Initialized
INFO - 2023-09-20 20:33:16 --> Email Class Initialized
DEBUG - 2023-09-20 20:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:33:16 --> Controller Class Initialized
INFO - 2023-09-20 20:33:16 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:33:16 --> Model "Home_model" initialized
INFO - 2023-09-20 20:33:16 --> Helper loaded: download_helper
INFO - 2023-09-20 20:33:16 --> Helper loaded: form_helper
INFO - 2023-09-20 20:33:16 --> Form Validation Class Initialized
INFO - 2023-09-20 20:33:16 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:33:16 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:33:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_only_we.php
INFO - 2023-09-20 20:33:16 --> Final output sent to browser
DEBUG - 2023-09-20 20:33:17 --> Total execution time: 0.1623
INFO - 2023-09-20 20:33:22 --> Config Class Initialized
INFO - 2023-09-20 20:33:22 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:33:22 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:33:22 --> Utf8 Class Initialized
INFO - 2023-09-20 20:33:22 --> URI Class Initialized
INFO - 2023-09-20 20:33:22 --> Router Class Initialized
INFO - 2023-09-20 20:33:22 --> Output Class Initialized
INFO - 2023-09-20 20:33:22 --> Security Class Initialized
DEBUG - 2023-09-20 20:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:33:22 --> Input Class Initialized
INFO - 2023-09-20 20:33:22 --> Language Class Initialized
INFO - 2023-09-20 20:33:22 --> Loader Class Initialized
INFO - 2023-09-20 20:33:22 --> Helper loaded: url_helper
INFO - 2023-09-20 20:33:22 --> Helper loaded: file_helper
INFO - 2023-09-20 20:33:22 --> Database Driver Class Initialized
INFO - 2023-09-20 20:33:22 --> Email Class Initialized
DEBUG - 2023-09-20 20:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:33:22 --> Controller Class Initialized
INFO - 2023-09-20 20:33:22 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:33:22 --> Model "Home_model" initialized
INFO - 2023-09-20 20:33:22 --> Helper loaded: download_helper
INFO - 2023-09-20 20:33:22 --> Helper loaded: form_helper
INFO - 2023-09-20 20:33:22 --> Form Validation Class Initialized
INFO - 2023-09-20 20:33:22 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:33:22 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:33:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-20 20:33:22 --> Final output sent to browser
DEBUG - 2023-09-20 20:33:23 --> Total execution time: 0.1662
INFO - 2023-09-20 20:33:27 --> Config Class Initialized
INFO - 2023-09-20 20:33:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:33:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:33:27 --> Utf8 Class Initialized
INFO - 2023-09-20 20:33:27 --> URI Class Initialized
INFO - 2023-09-20 20:33:27 --> Router Class Initialized
INFO - 2023-09-20 20:33:27 --> Output Class Initialized
INFO - 2023-09-20 20:33:27 --> Security Class Initialized
DEBUG - 2023-09-20 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:33:27 --> Input Class Initialized
INFO - 2023-09-20 20:33:27 --> Language Class Initialized
INFO - 2023-09-20 20:33:27 --> Loader Class Initialized
INFO - 2023-09-20 20:33:27 --> Helper loaded: url_helper
INFO - 2023-09-20 20:33:27 --> Helper loaded: file_helper
INFO - 2023-09-20 20:33:27 --> Database Driver Class Initialized
INFO - 2023-09-20 20:33:27 --> Email Class Initialized
DEBUG - 2023-09-20 20:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:33:27 --> Controller Class Initialized
INFO - 2023-09-20 20:33:27 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:33:27 --> Model "Home_model" initialized
INFO - 2023-09-20 20:33:27 --> Helper loaded: download_helper
INFO - 2023-09-20 20:33:27 --> Helper loaded: form_helper
INFO - 2023-09-20 20:33:27 --> Form Validation Class Initialized
INFO - 2023-09-20 20:33:27 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:33:27 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:33:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/why_digital_marketing.php
INFO - 2023-09-20 20:33:27 --> Final output sent to browser
DEBUG - 2023-09-20 20:33:27 --> Total execution time: 0.1278
INFO - 2023-09-20 20:36:51 --> Config Class Initialized
INFO - 2023-09-20 20:36:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:36:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:36:51 --> Utf8 Class Initialized
INFO - 2023-09-20 20:36:51 --> URI Class Initialized
INFO - 2023-09-20 20:36:51 --> Router Class Initialized
INFO - 2023-09-20 20:36:51 --> Output Class Initialized
INFO - 2023-09-20 20:36:51 --> Security Class Initialized
DEBUG - 2023-09-20 20:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:36:51 --> Input Class Initialized
INFO - 2023-09-20 20:36:51 --> Language Class Initialized
INFO - 2023-09-20 20:36:51 --> Loader Class Initialized
INFO - 2023-09-20 20:36:51 --> Helper loaded: url_helper
INFO - 2023-09-20 20:36:51 --> Helper loaded: file_helper
INFO - 2023-09-20 20:36:51 --> Database Driver Class Initialized
INFO - 2023-09-20 20:36:51 --> Email Class Initialized
DEBUG - 2023-09-20 20:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:36:51 --> Controller Class Initialized
INFO - 2023-09-20 20:36:51 --> Model "Blog_model" initialized
INFO - 2023-09-20 20:36:51 --> Helper loaded: form_helper
INFO - 2023-09-20 20:36:51 --> Form Validation Class Initialized
INFO - 2023-09-20 20:36:51 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-20 20:36:52 --> Final output sent to browser
DEBUG - 2023-09-20 20:36:52 --> Total execution time: 0.1024
INFO - 2023-09-20 20:36:53 --> Config Class Initialized
INFO - 2023-09-20 20:36:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:36:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:36:53 --> Utf8 Class Initialized
INFO - 2023-09-20 20:36:53 --> URI Class Initialized
INFO - 2023-09-20 20:36:53 --> Router Class Initialized
INFO - 2023-09-20 20:36:53 --> Output Class Initialized
INFO - 2023-09-20 20:36:53 --> Security Class Initialized
DEBUG - 2023-09-20 20:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:36:53 --> Input Class Initialized
INFO - 2023-09-20 20:36:53 --> Language Class Initialized
ERROR - 2023-09-20 20:36:53 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-09-20 20:36:54 --> Config Class Initialized
INFO - 2023-09-20 20:36:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:36:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:36:54 --> Utf8 Class Initialized
INFO - 2023-09-20 20:36:54 --> URI Class Initialized
INFO - 2023-09-20 20:36:54 --> Router Class Initialized
INFO - 2023-09-20 20:36:54 --> Output Class Initialized
INFO - 2023-09-20 20:36:54 --> Security Class Initialized
DEBUG - 2023-09-20 20:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:36:54 --> Input Class Initialized
INFO - 2023-09-20 20:36:54 --> Language Class Initialized
INFO - 2023-09-20 20:36:54 --> Loader Class Initialized
INFO - 2023-09-20 20:36:54 --> Helper loaded: url_helper
INFO - 2023-09-20 20:36:54 --> Helper loaded: file_helper
INFO - 2023-09-20 20:36:54 --> Database Driver Class Initialized
INFO - 2023-09-20 20:36:54 --> Email Class Initialized
DEBUG - 2023-09-20 20:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:36:54 --> Controller Class Initialized
INFO - 2023-09-20 20:36:54 --> Model "Blog_model" initialized
INFO - 2023-09-20 20:36:54 --> Helper loaded: form_helper
INFO - 2023-09-20 20:36:54 --> Form Validation Class Initialized
INFO - 2023-09-20 20:36:54 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_edit.php
INFO - 2023-09-20 20:36:54 --> Final output sent to browser
DEBUG - 2023-09-20 20:36:54 --> Total execution time: 0.1587
INFO - 2023-09-20 20:37:05 --> Config Class Initialized
INFO - 2023-09-20 20:37:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:05 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:05 --> URI Class Initialized
INFO - 2023-09-20 20:37:05 --> Router Class Initialized
INFO - 2023-09-20 20:37:05 --> Output Class Initialized
INFO - 2023-09-20 20:37:05 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:05 --> Input Class Initialized
INFO - 2023-09-20 20:37:05 --> Language Class Initialized
INFO - 2023-09-20 20:37:05 --> Loader Class Initialized
INFO - 2023-09-20 20:37:05 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:05 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:05 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:05 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:05 --> Controller Class Initialized
INFO - 2023-09-20 20:37:06 --> Model "Blog_model" initialized
INFO - 2023-09-20 20:37:06 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:06 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-20 20:37:06 --> Config Class Initialized
INFO - 2023-09-20 20:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:06 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:06 --> URI Class Initialized
INFO - 2023-09-20 20:37:06 --> Router Class Initialized
INFO - 2023-09-20 20:37:06 --> Output Class Initialized
INFO - 2023-09-20 20:37:06 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:06 --> Input Class Initialized
INFO - 2023-09-20 20:37:06 --> Language Class Initialized
INFO - 2023-09-20 20:37:06 --> Loader Class Initialized
INFO - 2023-09-20 20:37:06 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:06 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:06 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:06 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:06 --> Controller Class Initialized
INFO - 2023-09-20 20:37:06 --> Model "Blog_model" initialized
INFO - 2023-09-20 20:37:06 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:06 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:06 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-09-20 20:37:06 --> Final output sent to browser
DEBUG - 2023-09-20 20:37:06 --> Total execution time: 0.1124
INFO - 2023-09-20 20:37:09 --> Config Class Initialized
INFO - 2023-09-20 20:37:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:09 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:09 --> URI Class Initialized
INFO - 2023-09-20 20:37:09 --> Router Class Initialized
INFO - 2023-09-20 20:37:09 --> Output Class Initialized
INFO - 2023-09-20 20:37:09 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:09 --> Input Class Initialized
INFO - 2023-09-20 20:37:09 --> Language Class Initialized
INFO - 2023-09-20 20:37:09 --> Loader Class Initialized
INFO - 2023-09-20 20:37:09 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:09 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:09 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:09 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:09 --> Controller Class Initialized
INFO - 2023-09-20 20:37:09 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:37:09 --> Model "Home_model" initialized
INFO - 2023-09-20 20:37:09 --> Helper loaded: download_helper
INFO - 2023-09-20 20:37:09 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:09 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:09 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:37:09 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:37:09 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-09-20 20:37:09 --> Final output sent to browser
DEBUG - 2023-09-20 20:37:09 --> Total execution time: 0.1144
INFO - 2023-09-20 20:37:11 --> Config Class Initialized
INFO - 2023-09-20 20:37:16 --> Config Class Initialized
INFO - 2023-09-20 20:37:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:16 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:16 --> URI Class Initialized
INFO - 2023-09-20 20:37:16 --> Router Class Initialized
INFO - 2023-09-20 20:37:16 --> Output Class Initialized
INFO - 2023-09-20 20:37:16 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:16 --> Input Class Initialized
INFO - 2023-09-20 20:37:16 --> Language Class Initialized
INFO - 2023-09-20 20:37:16 --> Loader Class Initialized
INFO - 2023-09-20 20:37:16 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:16 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:16 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:16 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:16 --> Controller Class Initialized
INFO - 2023-09-20 20:37:16 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:37:16 --> Model "Home_model" initialized
INFO - 2023-09-20 20:37:16 --> Helper loaded: download_helper
INFO - 2023-09-20 20:37:16 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:16 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:16 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:37:16 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:37:16 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog_detail.php
INFO - 2023-09-20 20:37:16 --> Final output sent to browser
DEBUG - 2023-09-20 20:37:17 --> Total execution time: 0.1323
INFO - 2023-09-20 20:37:37 --> Config Class Initialized
INFO - 2023-09-20 20:37:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:37 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:37 --> URI Class Initialized
INFO - 2023-09-20 20:37:37 --> Router Class Initialized
INFO - 2023-09-20 20:37:37 --> Output Class Initialized
INFO - 2023-09-20 20:37:37 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:37 --> Input Class Initialized
INFO - 2023-09-20 20:37:37 --> Language Class Initialized
INFO - 2023-09-20 20:37:37 --> Loader Class Initialized
INFO - 2023-09-20 20:37:37 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:37 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:37 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:37 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:37 --> Controller Class Initialized
INFO - 2023-09-20 20:37:37 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:37:37 --> Model "Home_model" initialized
INFO - 2023-09-20 20:37:37 --> Helper loaded: download_helper
INFO - 2023-09-20 20:37:37 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:37 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:37 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:37:37 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:37:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/service_detail.php
INFO - 2023-09-20 20:37:37 --> Final output sent to browser
DEBUG - 2023-09-20 20:37:38 --> Total execution time: 0.3489
INFO - 2023-09-20 20:37:42 --> Config Class Initialized
INFO - 2023-09-20 20:37:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:42 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:42 --> URI Class Initialized
INFO - 2023-09-20 20:37:42 --> Router Class Initialized
INFO - 2023-09-20 20:37:42 --> Output Class Initialized
INFO - 2023-09-20 20:37:42 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:42 --> Input Class Initialized
INFO - 2023-09-20 20:37:42 --> Language Class Initialized
INFO - 2023-09-20 20:37:42 --> Loader Class Initialized
INFO - 2023-09-20 20:37:42 --> Helper loaded: url_helper
INFO - 2023-09-20 20:37:42 --> Helper loaded: file_helper
INFO - 2023-09-20 20:37:42 --> Database Driver Class Initialized
INFO - 2023-09-20 20:37:42 --> Email Class Initialized
DEBUG - 2023-09-20 20:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-20 20:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 20:37:42 --> Controller Class Initialized
INFO - 2023-09-20 20:37:42 --> Model "Contact_model" initialized
INFO - 2023-09-20 20:37:42 --> Model "Home_model" initialized
INFO - 2023-09-20 20:37:42 --> Helper loaded: download_helper
INFO - 2023-09-20 20:37:42 --> Helper loaded: form_helper
INFO - 2023-09-20 20:37:42 --> Form Validation Class Initialized
INFO - 2023-09-20 20:37:42 --> Helper loaded: custom_helper
INFO - 2023-09-20 20:37:42 --> Model "Social_media_model" initialized
INFO - 2023-09-20 20:37:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/services.php
INFO - 2023-09-20 20:37:42 --> Final output sent to browser
INFO - 2023-09-20 20:37:52 --> Config Class Initialized
INFO - 2023-09-20 20:37:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:52 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:52 --> URI Class Initialized
INFO - 2023-09-20 20:37:52 --> Router Class Initialized
INFO - 2023-09-20 20:37:52 --> Output Class Initialized
INFO - 2023-09-20 20:37:52 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:52 --> Input Class Initialized
INFO - 2023-09-20 20:37:52 --> Language Class Initialized
ERROR - 2023-09-20 20:37:52 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:37:52 --> Config Class Initialized
INFO - 2023-09-20 20:37:53 --> Config Class Initialized
INFO - 2023-09-20 20:37:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:53 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:53 --> URI Class Initialized
INFO - 2023-09-20 20:37:53 --> Router Class Initialized
INFO - 2023-09-20 20:37:53 --> Output Class Initialized
INFO - 2023-09-20 20:37:53 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:53 --> Input Class Initialized
INFO - 2023-09-20 20:37:53 --> Language Class Initialized
ERROR - 2023-09-20 20:37:53 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:37:53 --> Config Class Initialized
INFO - 2023-09-20 20:37:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 20:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:54 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:54 --> Config Class Initialized
INFO - 2023-09-20 20:37:54 --> Hooks Class Initialized
INFO - 2023-09-20 20:37:54 --> Hooks Class Initialized
INFO - 2023-09-20 20:37:54 --> URI Class Initialized
DEBUG - 2023-09-20 20:37:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:54 --> Router Class Initialized
INFO - 2023-09-20 20:37:55 --> Output Class Initialized
INFO - 2023-09-20 20:37:55 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:55 --> Config Class Initialized
INFO - 2023-09-20 20:37:55 --> Hooks Class Initialized
INFO - 2023-09-20 20:37:55 --> URI Class Initialized
DEBUG - 2023-09-20 20:37:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 20:37:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 20:37:55 --> Security Class Initialized
INFO - 2023-09-20 20:37:55 --> Utf8 Class Initialized
DEBUG - 2023-09-20 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:55 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:55 --> Router Class Initialized
INFO - 2023-09-20 20:37:55 --> Input Class Initialized
INFO - 2023-09-20 20:37:55 --> Output Class Initialized
INFO - 2023-09-20 20:37:55 --> URI Class Initialized
INFO - 2023-09-20 20:37:55 --> Router Class Initialized
INFO - 2023-09-20 20:37:55 --> Language Class Initialized
INFO - 2023-09-20 20:37:55 --> URI Class Initialized
INFO - 2023-09-20 20:37:55 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:55 --> Input Class Initialized
INFO - 2023-09-20 20:37:55 --> Language Class Initialized
ERROR - 2023-09-20 20:37:55 --> 404 Page Not Found: Assets/home
ERROR - 2023-09-20 20:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:37:55 --> Config Class Initialized
INFO - 2023-09-20 20:37:55 --> Router Class Initialized
INFO - 2023-09-20 20:37:55 --> Output Class Initialized
INFO - 2023-09-20 20:37:55 --> Hooks Class Initialized
INFO - 2023-09-20 20:37:55 --> Security Class Initialized
INFO - 2023-09-20 20:37:55 --> Output Class Initialized
DEBUG - 2023-09-20 20:37:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-20 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:55 --> Security Class Initialized
INFO - 2023-09-20 20:37:55 --> Utf8 Class Initialized
INFO - 2023-09-20 20:37:55 --> Input Class Initialized
DEBUG - 2023-09-20 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:55 --> Language Class Initialized
INFO - 2023-09-20 20:37:55 --> Input Class Initialized
INFO - 2023-09-20 20:37:55 --> URI Class Initialized
ERROR - 2023-09-20 20:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:37:55 --> Language Class Initialized
INFO - 2023-09-20 20:37:55 --> Router Class Initialized
ERROR - 2023-09-20 20:37:55 --> 404 Page Not Found: Assets/home
INFO - 2023-09-20 20:37:55 --> Output Class Initialized
INFO - 2023-09-20 20:37:55 --> Security Class Initialized
DEBUG - 2023-09-20 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 20:37:55 --> Input Class Initialized
INFO - 2023-09-20 20:37:55 --> Language Class Initialized
ERROR - 2023-09-20 20:37:55 --> 404 Page Not Found: Assets/home
