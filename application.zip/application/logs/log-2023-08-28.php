<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-28 18:05:22 --> Config Class Initialized
INFO - 2023-08-28 18:05:22 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:22 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:22 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:22 --> URI Class Initialized
DEBUG - 2023-08-28 18:05:22 --> No URI present. Default controller set.
INFO - 2023-08-28 18:05:22 --> Router Class Initialized
INFO - 2023-08-28 18:05:22 --> Output Class Initialized
INFO - 2023-08-28 18:05:22 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:22 --> Input Class Initialized
INFO - 2023-08-28 18:05:22 --> Language Class Initialized
INFO - 2023-08-28 18:05:23 --> Loader Class Initialized
INFO - 2023-08-28 18:05:23 --> Helper loaded: url_helper
INFO - 2023-08-28 18:05:23 --> Helper loaded: file_helper
INFO - 2023-08-28 18:05:23 --> Database Driver Class Initialized
INFO - 2023-08-28 18:05:23 --> Email Class Initialized
DEBUG - 2023-08-28 18:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:05:23 --> Controller Class Initialized
INFO - 2023-08-28 18:05:23 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:05:23 --> Model "Home_model" initialized
INFO - 2023-08-28 18:05:23 --> Helper loaded: download_helper
INFO - 2023-08-28 18:05:23 --> Helper loaded: form_helper
INFO - 2023-08-28 18:05:23 --> Form Validation Class Initialized
INFO - 2023-08-28 18:05:23 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:05:23 --> Final output sent to browser
DEBUG - 2023-08-28 18:05:23 --> Total execution time: 1.5491
INFO - 2023-08-28 18:05:25 --> Config Class Initialized
INFO - 2023-08-28 18:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:25 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:25 --> URI Class Initialized
INFO - 2023-08-28 18:05:25 --> Router Class Initialized
INFO - 2023-08-28 18:05:25 --> Output Class Initialized
INFO - 2023-08-28 18:05:25 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:25 --> Input Class Initialized
INFO - 2023-08-28 18:05:25 --> Language Class Initialized
ERROR - 2023-08-28 18:05:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:25 --> Config Class Initialized
INFO - 2023-08-28 18:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:25 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:25 --> URI Class Initialized
INFO - 2023-08-28 18:05:25 --> Router Class Initialized
INFO - 2023-08-28 18:05:25 --> Output Class Initialized
INFO - 2023-08-28 18:05:25 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:25 --> Input Class Initialized
INFO - 2023-08-28 18:05:25 --> Language Class Initialized
ERROR - 2023-08-28 18:05:25 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:25 --> Config Class Initialized
INFO - 2023-08-28 18:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:25 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:25 --> URI Class Initialized
INFO - 2023-08-28 18:05:25 --> Router Class Initialized
INFO - 2023-08-28 18:05:25 --> Output Class Initialized
INFO - 2023-08-28 18:05:25 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:25 --> Input Class Initialized
INFO - 2023-08-28 18:05:25 --> Language Class Initialized
ERROR - 2023-08-28 18:05:25 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:05:29 --> Config Class Initialized
INFO - 2023-08-28 18:05:29 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:29 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:29 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:29 --> URI Class Initialized
INFO - 2023-08-28 18:05:29 --> Router Class Initialized
INFO - 2023-08-28 18:05:29 --> Output Class Initialized
INFO - 2023-08-28 18:05:29 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:29 --> Input Class Initialized
INFO - 2023-08-28 18:05:29 --> Language Class Initialized
ERROR - 2023-08-28 18:05:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:05:41 --> Config Class Initialized
INFO - 2023-08-28 18:05:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:41 --> URI Class Initialized
INFO - 2023-08-28 18:05:41 --> Router Class Initialized
INFO - 2023-08-28 18:05:41 --> Output Class Initialized
INFO - 2023-08-28 18:05:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:41 --> Input Class Initialized
INFO - 2023-08-28 18:05:41 --> Language Class Initialized
ERROR - 2023-08-28 18:05:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:41 --> Config Class Initialized
INFO - 2023-08-28 18:05:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:41 --> URI Class Initialized
INFO - 2023-08-28 18:05:41 --> Router Class Initialized
INFO - 2023-08-28 18:05:41 --> Output Class Initialized
INFO - 2023-08-28 18:05:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:41 --> Input Class Initialized
INFO - 2023-08-28 18:05:41 --> Language Class Initialized
ERROR - 2023-08-28 18:05:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:54 --> Config Class Initialized
INFO - 2023-08-28 18:05:54 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:54 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:54 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:54 --> URI Class Initialized
DEBUG - 2023-08-28 18:05:54 --> No URI present. Default controller set.
INFO - 2023-08-28 18:05:54 --> Router Class Initialized
INFO - 2023-08-28 18:05:54 --> Output Class Initialized
INFO - 2023-08-28 18:05:54 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:54 --> Input Class Initialized
INFO - 2023-08-28 18:05:54 --> Language Class Initialized
INFO - 2023-08-28 18:05:54 --> Loader Class Initialized
INFO - 2023-08-28 18:05:54 --> Helper loaded: url_helper
INFO - 2023-08-28 18:05:54 --> Helper loaded: file_helper
INFO - 2023-08-28 18:05:54 --> Database Driver Class Initialized
INFO - 2023-08-28 18:05:54 --> Email Class Initialized
DEBUG - 2023-08-28 18:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:05:54 --> Controller Class Initialized
INFO - 2023-08-28 18:05:54 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:05:54 --> Model "Home_model" initialized
INFO - 2023-08-28 18:05:54 --> Helper loaded: download_helper
INFO - 2023-08-28 18:05:54 --> Helper loaded: form_helper
INFO - 2023-08-28 18:05:54 --> Form Validation Class Initialized
INFO - 2023-08-28 18:05:54 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:05:54 --> Final output sent to browser
DEBUG - 2023-08-28 18:05:54 --> Total execution time: 0.0809
INFO - 2023-08-28 18:05:55 --> Config Class Initialized
INFO - 2023-08-28 18:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:55 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:55 --> URI Class Initialized
INFO - 2023-08-28 18:05:55 --> Router Class Initialized
INFO - 2023-08-28 18:05:55 --> Output Class Initialized
INFO - 2023-08-28 18:05:55 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:55 --> Input Class Initialized
INFO - 2023-08-28 18:05:55 --> Language Class Initialized
ERROR - 2023-08-28 18:05:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:55 --> Config Class Initialized
INFO - 2023-08-28 18:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:55 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:55 --> URI Class Initialized
INFO - 2023-08-28 18:05:55 --> Router Class Initialized
INFO - 2023-08-28 18:05:55 --> Output Class Initialized
INFO - 2023-08-28 18:05:55 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:55 --> Input Class Initialized
INFO - 2023-08-28 18:05:55 --> Language Class Initialized
ERROR - 2023-08-28 18:05:55 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:05:55 --> Config Class Initialized
INFO - 2023-08-28 18:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:05:55 --> Utf8 Class Initialized
INFO - 2023-08-28 18:05:55 --> URI Class Initialized
INFO - 2023-08-28 18:05:55 --> Router Class Initialized
INFO - 2023-08-28 18:05:55 --> Output Class Initialized
INFO - 2023-08-28 18:05:55 --> Security Class Initialized
DEBUG - 2023-08-28 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:05:55 --> Input Class Initialized
INFO - 2023-08-28 18:05:55 --> Language Class Initialized
ERROR - 2023-08-28 18:05:55 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:06:20 --> Config Class Initialized
INFO - 2023-08-28 18:06:20 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:06:20 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:06:20 --> Utf8 Class Initialized
INFO - 2023-08-28 18:06:20 --> URI Class Initialized
INFO - 2023-08-28 18:06:20 --> Router Class Initialized
INFO - 2023-08-28 18:06:20 --> Output Class Initialized
INFO - 2023-08-28 18:06:20 --> Security Class Initialized
DEBUG - 2023-08-28 18:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:06:20 --> Input Class Initialized
INFO - 2023-08-28 18:06:20 --> Language Class Initialized
ERROR - 2023-08-28 18:06:20 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:06:58 --> Config Class Initialized
INFO - 2023-08-28 18:06:58 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:06:58 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:06:58 --> Utf8 Class Initialized
INFO - 2023-08-28 18:06:58 --> URI Class Initialized
INFO - 2023-08-28 18:06:58 --> Router Class Initialized
INFO - 2023-08-28 18:06:58 --> Output Class Initialized
INFO - 2023-08-28 18:06:58 --> Security Class Initialized
DEBUG - 2023-08-28 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:06:58 --> Input Class Initialized
INFO - 2023-08-28 18:06:58 --> Language Class Initialized
ERROR - 2023-08-28 18:06:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:06:58 --> Config Class Initialized
INFO - 2023-08-28 18:06:58 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:06:58 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:06:58 --> Utf8 Class Initialized
INFO - 2023-08-28 18:06:58 --> URI Class Initialized
INFO - 2023-08-28 18:06:58 --> Router Class Initialized
INFO - 2023-08-28 18:06:58 --> Output Class Initialized
INFO - 2023-08-28 18:06:58 --> Security Class Initialized
DEBUG - 2023-08-28 18:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:06:58 --> Input Class Initialized
INFO - 2023-08-28 18:06:58 --> Language Class Initialized
ERROR - 2023-08-28 18:06:58 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:07:43 --> Config Class Initialized
INFO - 2023-08-28 18:07:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:07:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:07:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:07:43 --> URI Class Initialized
INFO - 2023-08-28 18:07:43 --> Router Class Initialized
INFO - 2023-08-28 18:07:43 --> Output Class Initialized
INFO - 2023-08-28 18:07:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:07:43 --> Input Class Initialized
INFO - 2023-08-28 18:07:43 --> Language Class Initialized
INFO - 2023-08-28 18:07:43 --> Loader Class Initialized
INFO - 2023-08-28 18:07:43 --> Helper loaded: url_helper
INFO - 2023-08-28 18:07:43 --> Helper loaded: file_helper
INFO - 2023-08-28 18:07:43 --> Database Driver Class Initialized
INFO - 2023-08-28 18:07:43 --> Email Class Initialized
DEBUG - 2023-08-28 18:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:07:43 --> Controller Class Initialized
INFO - 2023-08-28 18:07:43 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:07:43 --> Model "Home_model" initialized
INFO - 2023-08-28 18:07:43 --> Helper loaded: download_helper
INFO - 2023-08-28 18:07:44 --> Helper loaded: form_helper
INFO - 2023-08-28 18:07:44 --> Form Validation Class Initialized
INFO - 2023-08-28 18:07:44 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-28 18:07:44 --> Final output sent to browser
DEBUG - 2023-08-28 18:07:44 --> Total execution time: 1.1714
INFO - 2023-08-28 18:07:45 --> Config Class Initialized
INFO - 2023-08-28 18:07:45 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:07:45 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:07:45 --> Utf8 Class Initialized
INFO - 2023-08-28 18:07:45 --> URI Class Initialized
INFO - 2023-08-28 18:07:45 --> Router Class Initialized
INFO - 2023-08-28 18:07:45 --> Output Class Initialized
INFO - 2023-08-28 18:07:45 --> Security Class Initialized
DEBUG - 2023-08-28 18:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:07:45 --> Input Class Initialized
INFO - 2023-08-28 18:07:45 --> Language Class Initialized
ERROR - 2023-08-28 18:07:45 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:07:45 --> Config Class Initialized
INFO - 2023-08-28 18:07:45 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:07:45 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:07:45 --> Utf8 Class Initialized
INFO - 2023-08-28 18:07:45 --> URI Class Initialized
INFO - 2023-08-28 18:07:45 --> Router Class Initialized
INFO - 2023-08-28 18:07:45 --> Output Class Initialized
INFO - 2023-08-28 18:07:45 --> Security Class Initialized
DEBUG - 2023-08-28 18:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:07:46 --> Input Class Initialized
INFO - 2023-08-28 18:07:46 --> Language Class Initialized
ERROR - 2023-08-28 18:07:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:07:46 --> Config Class Initialized
INFO - 2023-08-28 18:07:46 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:07:46 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:07:46 --> Utf8 Class Initialized
INFO - 2023-08-28 18:07:46 --> URI Class Initialized
INFO - 2023-08-28 18:07:46 --> Router Class Initialized
INFO - 2023-08-28 18:07:46 --> Output Class Initialized
INFO - 2023-08-28 18:07:46 --> Security Class Initialized
DEBUG - 2023-08-28 18:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:07:46 --> Input Class Initialized
INFO - 2023-08-28 18:07:46 --> Language Class Initialized
ERROR - 2023-08-28 18:07:46 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:07:46 --> Config Class Initialized
INFO - 2023-08-28 18:07:46 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:07:46 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:07:46 --> Utf8 Class Initialized
INFO - 2023-08-28 18:07:46 --> URI Class Initialized
INFO - 2023-08-28 18:07:46 --> Router Class Initialized
INFO - 2023-08-28 18:07:46 --> Output Class Initialized
INFO - 2023-08-28 18:07:46 --> Security Class Initialized
DEBUG - 2023-08-28 18:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:07:46 --> Input Class Initialized
INFO - 2023-08-28 18:07:46 --> Language Class Initialized
ERROR - 2023-08-28 18:07:46 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:08:21 --> Config Class Initialized
INFO - 2023-08-28 18:08:21 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:08:21 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:08:21 --> Utf8 Class Initialized
INFO - 2023-08-28 18:08:21 --> URI Class Initialized
INFO - 2023-08-28 18:08:21 --> Router Class Initialized
INFO - 2023-08-28 18:08:21 --> Output Class Initialized
INFO - 2023-08-28 18:08:21 --> Security Class Initialized
DEBUG - 2023-08-28 18:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:08:21 --> Input Class Initialized
INFO - 2023-08-28 18:08:21 --> Language Class Initialized
ERROR - 2023-08-28 18:08:21 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:09:39 --> Config Class Initialized
INFO - 2023-08-28 18:09:39 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:39 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:39 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:39 --> URI Class Initialized
INFO - 2023-08-28 18:09:39 --> Router Class Initialized
INFO - 2023-08-28 18:09:39 --> Output Class Initialized
INFO - 2023-08-28 18:09:39 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:39 --> Input Class Initialized
INFO - 2023-08-28 18:09:39 --> Language Class Initialized
INFO - 2023-08-28 18:09:39 --> Loader Class Initialized
INFO - 2023-08-28 18:09:39 --> Helper loaded: url_helper
INFO - 2023-08-28 18:09:39 --> Helper loaded: file_helper
INFO - 2023-08-28 18:09:39 --> Database Driver Class Initialized
INFO - 2023-08-28 18:09:39 --> Email Class Initialized
DEBUG - 2023-08-28 18:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:09:39 --> Controller Class Initialized
INFO - 2023-08-28 18:09:39 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:09:39 --> Model "Home_model" initialized
INFO - 2023-08-28 18:09:39 --> Helper loaded: download_helper
INFO - 2023-08-28 18:09:39 --> Helper loaded: form_helper
INFO - 2023-08-28 18:09:39 --> Form Validation Class Initialized
INFO - 2023-08-28 18:09:39 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-28 18:09:39 --> Final output sent to browser
DEBUG - 2023-08-28 18:09:39 --> Total execution time: 0.3330
INFO - 2023-08-28 18:09:41 --> Config Class Initialized
INFO - 2023-08-28 18:09:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:41 --> URI Class Initialized
INFO - 2023-08-28 18:09:41 --> Router Class Initialized
INFO - 2023-08-28 18:09:41 --> Output Class Initialized
INFO - 2023-08-28 18:09:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:41 --> Input Class Initialized
INFO - 2023-08-28 18:09:41 --> Config Class Initialized
INFO - 2023-08-28 18:09:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:41 --> URI Class Initialized
INFO - 2023-08-28 18:09:41 --> Router Class Initialized
INFO - 2023-08-28 18:09:41 --> Output Class Initialized
INFO - 2023-08-28 18:09:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:41 --> Input Class Initialized
INFO - 2023-08-28 18:09:41 --> Language Class Initialized
ERROR - 2023-08-28 18:09:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:09:41 --> Config Class Initialized
INFO - 2023-08-28 18:09:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:41 --> URI Class Initialized
INFO - 2023-08-28 18:09:41 --> Router Class Initialized
INFO - 2023-08-28 18:09:41 --> Output Class Initialized
INFO - 2023-08-28 18:09:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:41 --> Input Class Initialized
INFO - 2023-08-28 18:09:41 --> Language Class Initialized
ERROR - 2023-08-28 18:09:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:09:41 --> Config Class Initialized
INFO - 2023-08-28 18:09:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:41 --> URI Class Initialized
INFO - 2023-08-28 18:09:41 --> Router Class Initialized
INFO - 2023-08-28 18:09:41 --> Output Class Initialized
INFO - 2023-08-28 18:09:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:41 --> Input Class Initialized
INFO - 2023-08-28 18:09:41 --> Language Class Initialized
ERROR - 2023-08-28 18:09:41 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:09:41 --> Language Class Initialized
ERROR - 2023-08-28 18:09:41 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:09:42 --> Config Class Initialized
INFO - 2023-08-28 18:09:42 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:42 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:42 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:42 --> URI Class Initialized
INFO - 2023-08-28 18:09:42 --> Router Class Initialized
INFO - 2023-08-28 18:09:42 --> Output Class Initialized
INFO - 2023-08-28 18:09:42 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:42 --> Input Class Initialized
INFO - 2023-08-28 18:09:42 --> Language Class Initialized
ERROR - 2023-08-28 18:09:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:09:42 --> Config Class Initialized
INFO - 2023-08-28 18:09:42 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:09:42 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:09:42 --> Utf8 Class Initialized
INFO - 2023-08-28 18:09:42 --> URI Class Initialized
INFO - 2023-08-28 18:09:42 --> Router Class Initialized
INFO - 2023-08-28 18:09:42 --> Output Class Initialized
INFO - 2023-08-28 18:09:42 --> Security Class Initialized
DEBUG - 2023-08-28 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:09:42 --> Input Class Initialized
INFO - 2023-08-28 18:09:42 --> Language Class Initialized
ERROR - 2023-08-28 18:09:42 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:10:10 --> Config Class Initialized
INFO - 2023-08-28 18:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:10 --> URI Class Initialized
DEBUG - 2023-08-28 18:10:10 --> No URI present. Default controller set.
INFO - 2023-08-28 18:10:10 --> Router Class Initialized
INFO - 2023-08-28 18:10:10 --> Output Class Initialized
INFO - 2023-08-28 18:10:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:10 --> Input Class Initialized
INFO - 2023-08-28 18:10:10 --> Language Class Initialized
INFO - 2023-08-28 18:10:10 --> Loader Class Initialized
INFO - 2023-08-28 18:10:10 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:10 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:10 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:10 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:10 --> Controller Class Initialized
INFO - 2023-08-28 18:10:10 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:10:10 --> Model "Home_model" initialized
INFO - 2023-08-28 18:10:10 --> Helper loaded: download_helper
INFO - 2023-08-28 18:10:10 --> Helper loaded: form_helper
INFO - 2023-08-28 18:10:10 --> Form Validation Class Initialized
INFO - 2023-08-28 18:10:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:10:10 --> Final output sent to browser
DEBUG - 2023-08-28 18:10:10 --> Total execution time: 0.1323
INFO - 2023-08-28 18:10:10 --> Config Class Initialized
INFO - 2023-08-28 18:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:10 --> URI Class Initialized
INFO - 2023-08-28 18:10:10 --> Router Class Initialized
INFO - 2023-08-28 18:10:10 --> Output Class Initialized
INFO - 2023-08-28 18:10:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:10 --> Input Class Initialized
INFO - 2023-08-28 18:10:10 --> Language Class Initialized
ERROR - 2023-08-28 18:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:10:10 --> Config Class Initialized
INFO - 2023-08-28 18:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:10 --> URI Class Initialized
INFO - 2023-08-28 18:10:10 --> Router Class Initialized
INFO - 2023-08-28 18:10:10 --> Output Class Initialized
INFO - 2023-08-28 18:10:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:10 --> Input Class Initialized
INFO - 2023-08-28 18:10:10 --> Language Class Initialized
ERROR - 2023-08-28 18:10:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:10:10 --> Config Class Initialized
INFO - 2023-08-28 18:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:10 --> URI Class Initialized
INFO - 2023-08-28 18:10:10 --> Router Class Initialized
INFO - 2023-08-28 18:10:10 --> Output Class Initialized
INFO - 2023-08-28 18:10:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:10 --> Input Class Initialized
INFO - 2023-08-28 18:10:10 --> Language Class Initialized
ERROR - 2023-08-28 18:10:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:10:10 --> Config Class Initialized
INFO - 2023-08-28 18:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:10 --> URI Class Initialized
INFO - 2023-08-28 18:10:10 --> Router Class Initialized
INFO - 2023-08-28 18:10:10 --> Output Class Initialized
INFO - 2023-08-28 18:10:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:10 --> Input Class Initialized
INFO - 2023-08-28 18:10:10 --> Language Class Initialized
ERROR - 2023-08-28 18:10:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:10:11 --> Config Class Initialized
INFO - 2023-08-28 18:10:11 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:11 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:11 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:11 --> URI Class Initialized
INFO - 2023-08-28 18:10:11 --> Router Class Initialized
INFO - 2023-08-28 18:10:11 --> Output Class Initialized
INFO - 2023-08-28 18:10:11 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:11 --> Input Class Initialized
INFO - 2023-08-28 18:10:11 --> Language Class Initialized
ERROR - 2023-08-28 18:10:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:10:11 --> Config Class Initialized
INFO - 2023-08-28 18:10:11 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:11 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:11 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:11 --> URI Class Initialized
INFO - 2023-08-28 18:10:11 --> Router Class Initialized
INFO - 2023-08-28 18:10:11 --> Output Class Initialized
INFO - 2023-08-28 18:10:11 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:11 --> Input Class Initialized
INFO - 2023-08-28 18:10:11 --> Language Class Initialized
ERROR - 2023-08-28 18:10:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:10:22 --> Config Class Initialized
INFO - 2023-08-28 18:10:22 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:22 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:22 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:22 --> URI Class Initialized
INFO - 2023-08-28 18:10:22 --> Router Class Initialized
INFO - 2023-08-28 18:10:22 --> Output Class Initialized
INFO - 2023-08-28 18:10:22 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:22 --> Input Class Initialized
INFO - 2023-08-28 18:10:22 --> Language Class Initialized
INFO - 2023-08-28 18:10:22 --> Loader Class Initialized
INFO - 2023-08-28 18:10:22 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:22 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:22 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:22 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:22 --> Controller Class Initialized
INFO - 2023-08-28 18:10:22 --> Config Class Initialized
INFO - 2023-08-28 18:10:22 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:22 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:22 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:22 --> URI Class Initialized
INFO - 2023-08-28 18:10:22 --> Router Class Initialized
INFO - 2023-08-28 18:10:22 --> Output Class Initialized
INFO - 2023-08-28 18:10:22 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:22 --> Input Class Initialized
INFO - 2023-08-28 18:10:22 --> Language Class Initialized
INFO - 2023-08-28 18:10:22 --> Loader Class Initialized
INFO - 2023-08-28 18:10:22 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:22 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:22 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:22 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:22 --> Controller Class Initialized
INFO - 2023-08-28 18:10:22 --> Model "User_model" initialized
INFO - 2023-08-28 18:10:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-28 18:10:22 --> Final output sent to browser
DEBUG - 2023-08-28 18:10:22 --> Total execution time: 0.0334
INFO - 2023-08-28 18:10:24 --> Config Class Initialized
INFO - 2023-08-28 18:10:24 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:24 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:24 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:24 --> URI Class Initialized
INFO - 2023-08-28 18:10:24 --> Router Class Initialized
INFO - 2023-08-28 18:10:24 --> Output Class Initialized
INFO - 2023-08-28 18:10:24 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:24 --> Input Class Initialized
INFO - 2023-08-28 18:10:24 --> Language Class Initialized
ERROR - 2023-08-28 18:10:24 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-08-28 18:10:29 --> Config Class Initialized
INFO - 2023-08-28 18:10:29 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:29 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:29 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:29 --> URI Class Initialized
INFO - 2023-08-28 18:10:29 --> Router Class Initialized
INFO - 2023-08-28 18:10:29 --> Output Class Initialized
INFO - 2023-08-28 18:10:29 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:29 --> Input Class Initialized
INFO - 2023-08-28 18:10:29 --> Language Class Initialized
INFO - 2023-08-28 18:10:29 --> Loader Class Initialized
INFO - 2023-08-28 18:10:29 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:29 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:29 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:29 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:29 --> Controller Class Initialized
INFO - 2023-08-28 18:10:29 --> Model "User_model" initialized
INFO - 2023-08-28 18:10:30 --> Config Class Initialized
INFO - 2023-08-28 18:10:30 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:30 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:30 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:30 --> URI Class Initialized
INFO - 2023-08-28 18:10:30 --> Router Class Initialized
INFO - 2023-08-28 18:10:30 --> Output Class Initialized
INFO - 2023-08-28 18:10:30 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:30 --> Input Class Initialized
INFO - 2023-08-28 18:10:30 --> Language Class Initialized
INFO - 2023-08-28 18:10:30 --> Loader Class Initialized
INFO - 2023-08-28 18:10:30 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:30 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:30 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:30 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:30 --> Controller Class Initialized
INFO - 2023-08-28 18:10:30 --> Model "User_model" initialized
INFO - 2023-08-28 18:10:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-08-28 18:10:30 --> Final output sent to browser
DEBUG - 2023-08-28 18:10:30 --> Total execution time: 0.0429
INFO - 2023-08-28 18:10:41 --> Config Class Initialized
INFO - 2023-08-28 18:10:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:41 --> URI Class Initialized
INFO - 2023-08-28 18:10:41 --> Router Class Initialized
INFO - 2023-08-28 18:10:41 --> Output Class Initialized
INFO - 2023-08-28 18:10:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:41 --> Input Class Initialized
INFO - 2023-08-28 18:10:41 --> Language Class Initialized
INFO - 2023-08-28 18:10:41 --> Loader Class Initialized
INFO - 2023-08-28 18:10:41 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:41 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:41 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:41 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:41 --> Controller Class Initialized
INFO - 2023-08-28 18:10:41 --> Model "User_model" initialized
INFO - 2023-08-28 18:10:41 --> Config Class Initialized
INFO - 2023-08-28 18:10:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:10:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:10:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:10:41 --> URI Class Initialized
INFO - 2023-08-28 18:10:41 --> Router Class Initialized
INFO - 2023-08-28 18:10:41 --> Output Class Initialized
INFO - 2023-08-28 18:10:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:10:41 --> Input Class Initialized
INFO - 2023-08-28 18:10:41 --> Language Class Initialized
INFO - 2023-08-28 18:10:41 --> Loader Class Initialized
INFO - 2023-08-28 18:10:41 --> Helper loaded: url_helper
INFO - 2023-08-28 18:10:41 --> Helper loaded: file_helper
INFO - 2023-08-28 18:10:41 --> Database Driver Class Initialized
INFO - 2023-08-28 18:10:41 --> Email Class Initialized
DEBUG - 2023-08-28 18:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:10:41 --> Controller Class Initialized
INFO - 2023-08-28 18:10:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-08-28 18:10:41 --> Final output sent to browser
DEBUG - 2023-08-28 18:10:41 --> Total execution time: 0.1504
INFO - 2023-08-28 18:11:40 --> Config Class Initialized
INFO - 2023-08-28 18:11:40 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:11:40 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:11:40 --> Utf8 Class Initialized
INFO - 2023-08-28 18:11:40 --> URI Class Initialized
INFO - 2023-08-28 18:11:40 --> Router Class Initialized
INFO - 2023-08-28 18:11:40 --> Output Class Initialized
INFO - 2023-08-28 18:11:40 --> Security Class Initialized
DEBUG - 2023-08-28 18:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:11:40 --> Input Class Initialized
INFO - 2023-08-28 18:11:40 --> Language Class Initialized
INFO - 2023-08-28 18:11:40 --> Loader Class Initialized
INFO - 2023-08-28 18:11:40 --> Helper loaded: url_helper
INFO - 2023-08-28 18:11:40 --> Helper loaded: file_helper
INFO - 2023-08-28 18:11:41 --> Database Driver Class Initialized
INFO - 2023-08-28 18:11:41 --> Email Class Initialized
DEBUG - 2023-08-28 18:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:11:41 --> Controller Class Initialized
INFO - 2023-08-28 18:11:41 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:11:41 --> Helper loaded: form_helper
INFO - 2023-08-28 18:11:41 --> Form Validation Class Initialized
INFO - 2023-08-28 18:11:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-28 18:11:41 --> Final output sent to browser
DEBUG - 2023-08-28 18:11:41 --> Total execution time: 0.1006
INFO - 2023-08-28 18:12:12 --> Config Class Initialized
INFO - 2023-08-28 18:12:12 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:12 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:12 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:12 --> URI Class Initialized
INFO - 2023-08-28 18:12:12 --> Router Class Initialized
INFO - 2023-08-28 18:12:12 --> Output Class Initialized
INFO - 2023-08-28 18:12:12 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:12 --> Input Class Initialized
INFO - 2023-08-28 18:12:12 --> Language Class Initialized
INFO - 2023-08-28 18:12:12 --> Loader Class Initialized
INFO - 2023-08-28 18:12:12 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:12 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:12 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:12 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:12 --> Controller Class Initialized
INFO - 2023-08-28 18:12:12 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:12 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:12 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:12 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:12 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:12 --> Total execution time: 0.1278
INFO - 2023-08-28 18:12:13 --> Config Class Initialized
INFO - 2023-08-28 18:12:13 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:13 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:13 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:13 --> URI Class Initialized
INFO - 2023-08-28 18:12:13 --> Router Class Initialized
INFO - 2023-08-28 18:12:13 --> Output Class Initialized
INFO - 2023-08-28 18:12:13 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:13 --> Input Class Initialized
INFO - 2023-08-28 18:12:13 --> Language Class Initialized
INFO - 2023-08-28 18:12:13 --> Loader Class Initialized
INFO - 2023-08-28 18:12:13 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:13 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:13 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:13 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:13 --> Controller Class Initialized
INFO - 2023-08-28 18:12:13 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:13 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:13 --> Form Validation Class Initialized
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-28 18:12:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-28 18:12:13 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:13 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:13 --> Total execution time: 0.0535
INFO - 2023-08-28 18:12:22 --> Config Class Initialized
INFO - 2023-08-28 18:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:22 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:22 --> URI Class Initialized
INFO - 2023-08-28 18:12:22 --> Router Class Initialized
INFO - 2023-08-28 18:12:22 --> Output Class Initialized
INFO - 2023-08-28 18:12:22 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:22 --> Input Class Initialized
INFO - 2023-08-28 18:12:22 --> Language Class Initialized
INFO - 2023-08-28 18:12:22 --> Loader Class Initialized
INFO - 2023-08-28 18:12:22 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:22 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:22 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:22 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:22 --> Controller Class Initialized
INFO - 2023-08-28 18:12:22 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:22 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:22 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-28 18:12:22 --> Config Class Initialized
INFO - 2023-08-28 18:12:22 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:22 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:22 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:22 --> URI Class Initialized
INFO - 2023-08-28 18:12:22 --> Router Class Initialized
INFO - 2023-08-28 18:12:22 --> Output Class Initialized
INFO - 2023-08-28 18:12:22 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:22 --> Input Class Initialized
INFO - 2023-08-28 18:12:22 --> Language Class Initialized
INFO - 2023-08-28 18:12:22 --> Loader Class Initialized
INFO - 2023-08-28 18:12:22 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:22 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:22 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:22 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:22 --> Controller Class Initialized
INFO - 2023-08-28 18:12:22 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:22 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:22 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:22 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-28 18:12:22 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:22 --> Total execution time: 0.0495
INFO - 2023-08-28 18:12:31 --> Config Class Initialized
INFO - 2023-08-28 18:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:31 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:31 --> URI Class Initialized
INFO - 2023-08-28 18:12:31 --> Router Class Initialized
INFO - 2023-08-28 18:12:31 --> Output Class Initialized
INFO - 2023-08-28 18:12:31 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:31 --> Input Class Initialized
INFO - 2023-08-28 18:12:31 --> Language Class Initialized
INFO - 2023-08-28 18:12:31 --> Loader Class Initialized
INFO - 2023-08-28 18:12:31 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:31 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:31 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:31 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:31 --> Controller Class Initialized
INFO - 2023-08-28 18:12:31 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:31 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:31 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:31 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:31 --> Total execution time: 0.0871
INFO - 2023-08-28 18:12:32 --> Config Class Initialized
INFO - 2023-08-28 18:12:32 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:32 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:32 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:32 --> URI Class Initialized
INFO - 2023-08-28 18:12:32 --> Router Class Initialized
INFO - 2023-08-28 18:12:32 --> Output Class Initialized
INFO - 2023-08-28 18:12:32 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:32 --> Input Class Initialized
INFO - 2023-08-28 18:12:32 --> Language Class Initialized
INFO - 2023-08-28 18:12:32 --> Loader Class Initialized
INFO - 2023-08-28 18:12:32 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:32 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:32 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:32 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:32 --> Controller Class Initialized
INFO - 2023-08-28 18:12:32 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:32 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:32 --> Form Validation Class Initialized
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-28 18:12:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-28 18:12:32 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:32 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:32 --> Total execution time: 0.0629
INFO - 2023-08-28 18:12:40 --> Config Class Initialized
INFO - 2023-08-28 18:12:40 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:40 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:40 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:40 --> URI Class Initialized
INFO - 2023-08-28 18:12:40 --> Router Class Initialized
INFO - 2023-08-28 18:12:40 --> Output Class Initialized
INFO - 2023-08-28 18:12:40 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:40 --> Input Class Initialized
INFO - 2023-08-28 18:12:40 --> Language Class Initialized
INFO - 2023-08-28 18:12:40 --> Loader Class Initialized
INFO - 2023-08-28 18:12:40 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:40 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:40 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:40 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:40 --> Controller Class Initialized
INFO - 2023-08-28 18:12:40 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:40 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:41 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-28 18:12:41 --> Config Class Initialized
INFO - 2023-08-28 18:12:41 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:41 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:41 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:41 --> URI Class Initialized
INFO - 2023-08-28 18:12:41 --> Router Class Initialized
INFO - 2023-08-28 18:12:41 --> Output Class Initialized
INFO - 2023-08-28 18:12:41 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:41 --> Input Class Initialized
INFO - 2023-08-28 18:12:41 --> Language Class Initialized
INFO - 2023-08-28 18:12:41 --> Loader Class Initialized
INFO - 2023-08-28 18:12:41 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:41 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:41 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:41 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:41 --> Controller Class Initialized
INFO - 2023-08-28 18:12:41 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:41 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:41 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:41 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-28 18:12:41 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:41 --> Total execution time: 0.0521
INFO - 2023-08-28 18:12:49 --> Config Class Initialized
INFO - 2023-08-28 18:12:49 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:49 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:49 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:49 --> URI Class Initialized
INFO - 2023-08-28 18:12:49 --> Router Class Initialized
INFO - 2023-08-28 18:12:49 --> Output Class Initialized
INFO - 2023-08-28 18:12:49 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:49 --> Input Class Initialized
INFO - 2023-08-28 18:12:49 --> Language Class Initialized
INFO - 2023-08-28 18:12:49 --> Loader Class Initialized
INFO - 2023-08-28 18:12:49 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:49 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:49 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:49 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:49 --> Controller Class Initialized
INFO - 2023-08-28 18:12:49 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:49 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:49 --> Form Validation Class Initialized
INFO - 2023-08-28 18:12:49 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:49 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:49 --> Total execution time: 0.0993
INFO - 2023-08-28 18:12:50 --> Config Class Initialized
INFO - 2023-08-28 18:12:50 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:12:50 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:12:50 --> Utf8 Class Initialized
INFO - 2023-08-28 18:12:50 --> URI Class Initialized
INFO - 2023-08-28 18:12:50 --> Router Class Initialized
INFO - 2023-08-28 18:12:50 --> Output Class Initialized
INFO - 2023-08-28 18:12:50 --> Security Class Initialized
DEBUG - 2023-08-28 18:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:12:50 --> Input Class Initialized
INFO - 2023-08-28 18:12:50 --> Language Class Initialized
INFO - 2023-08-28 18:12:50 --> Loader Class Initialized
INFO - 2023-08-28 18:12:50 --> Helper loaded: url_helper
INFO - 2023-08-28 18:12:50 --> Helper loaded: file_helper
INFO - 2023-08-28 18:12:50 --> Database Driver Class Initialized
INFO - 2023-08-28 18:12:50 --> Email Class Initialized
DEBUG - 2023-08-28 18:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:12:50 --> Controller Class Initialized
INFO - 2023-08-28 18:12:50 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:12:50 --> Helper loaded: form_helper
INFO - 2023-08-28 18:12:50 --> Form Validation Class Initialized
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 39
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 48
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 58
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 59
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 72
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 73
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 83
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 99
ERROR - 2023-08-28 18:12:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\dw\application\views\admin\banner_edit.php 111
INFO - 2023-08-28 18:12:50 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banner_edit.php
INFO - 2023-08-28 18:12:50 --> Final output sent to browser
DEBUG - 2023-08-28 18:12:50 --> Total execution time: 0.0626
INFO - 2023-08-28 18:13:00 --> Config Class Initialized
INFO - 2023-08-28 18:13:00 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:00 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:00 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:00 --> URI Class Initialized
INFO - 2023-08-28 18:13:00 --> Router Class Initialized
INFO - 2023-08-28 18:13:00 --> Output Class Initialized
INFO - 2023-08-28 18:13:00 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:00 --> Input Class Initialized
INFO - 2023-08-28 18:13:00 --> Language Class Initialized
INFO - 2023-08-28 18:13:00 --> Loader Class Initialized
INFO - 2023-08-28 18:13:00 --> Helper loaded: url_helper
INFO - 2023-08-28 18:13:00 --> Helper loaded: file_helper
INFO - 2023-08-28 18:13:00 --> Database Driver Class Initialized
INFO - 2023-08-28 18:13:00 --> Email Class Initialized
DEBUG - 2023-08-28 18:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:13:00 --> Controller Class Initialized
INFO - 2023-08-28 18:13:00 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:13:00 --> Helper loaded: form_helper
INFO - 2023-08-28 18:13:00 --> Form Validation Class Initialized
INFO - 2023-08-28 18:13:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-08-28 18:13:00 --> Config Class Initialized
INFO - 2023-08-28 18:13:00 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:00 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:00 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:00 --> URI Class Initialized
INFO - 2023-08-28 18:13:00 --> Router Class Initialized
INFO - 2023-08-28 18:13:00 --> Output Class Initialized
INFO - 2023-08-28 18:13:00 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:00 --> Input Class Initialized
INFO - 2023-08-28 18:13:00 --> Language Class Initialized
INFO - 2023-08-28 18:13:00 --> Loader Class Initialized
INFO - 2023-08-28 18:13:00 --> Helper loaded: url_helper
INFO - 2023-08-28 18:13:00 --> Helper loaded: file_helper
INFO - 2023-08-28 18:13:00 --> Database Driver Class Initialized
INFO - 2023-08-28 18:13:00 --> Email Class Initialized
DEBUG - 2023-08-28 18:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:13:00 --> Controller Class Initialized
INFO - 2023-08-28 18:13:00 --> Model "Banner_model" initialized
INFO - 2023-08-28 18:13:00 --> Helper loaded: form_helper
INFO - 2023-08-28 18:13:00 --> Form Validation Class Initialized
INFO - 2023-08-28 18:13:00 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/banners_list.php
INFO - 2023-08-28 18:13:00 --> Final output sent to browser
DEBUG - 2023-08-28 18:13:00 --> Total execution time: 0.0481
INFO - 2023-08-28 18:13:02 --> Config Class Initialized
INFO - 2023-08-28 18:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:02 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:02 --> URI Class Initialized
DEBUG - 2023-08-28 18:13:02 --> No URI present. Default controller set.
INFO - 2023-08-28 18:13:02 --> Router Class Initialized
INFO - 2023-08-28 18:13:02 --> Output Class Initialized
INFO - 2023-08-28 18:13:02 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:02 --> Input Class Initialized
INFO - 2023-08-28 18:13:02 --> Language Class Initialized
INFO - 2023-08-28 18:13:02 --> Loader Class Initialized
INFO - 2023-08-28 18:13:02 --> Helper loaded: url_helper
INFO - 2023-08-28 18:13:02 --> Helper loaded: file_helper
INFO - 2023-08-28 18:13:02 --> Database Driver Class Initialized
INFO - 2023-08-28 18:13:02 --> Email Class Initialized
DEBUG - 2023-08-28 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:13:02 --> Controller Class Initialized
INFO - 2023-08-28 18:13:02 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:13:02 --> Model "Home_model" initialized
INFO - 2023-08-28 18:13:02 --> Helper loaded: download_helper
INFO - 2023-08-28 18:13:03 --> Helper loaded: form_helper
INFO - 2023-08-28 18:13:03 --> Form Validation Class Initialized
INFO - 2023-08-28 18:13:03 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:13:03 --> Final output sent to browser
DEBUG - 2023-08-28 18:13:03 --> Total execution time: 0.0618
INFO - 2023-08-28 18:13:03 --> Config Class Initialized
INFO - 2023-08-28 18:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:03 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:03 --> URI Class Initialized
INFO - 2023-08-28 18:13:03 --> Router Class Initialized
INFO - 2023-08-28 18:13:03 --> Output Class Initialized
INFO - 2023-08-28 18:13:03 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:03 --> Input Class Initialized
INFO - 2023-08-28 18:13:03 --> Language Class Initialized
ERROR - 2023-08-28 18:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:13:03 --> Config Class Initialized
INFO - 2023-08-28 18:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:03 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:03 --> URI Class Initialized
INFO - 2023-08-28 18:13:03 --> Router Class Initialized
INFO - 2023-08-28 18:13:03 --> Output Class Initialized
INFO - 2023-08-28 18:13:03 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:03 --> Input Class Initialized
INFO - 2023-08-28 18:13:03 --> Language Class Initialized
ERROR - 2023-08-28 18:13:03 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:13:03 --> Config Class Initialized
INFO - 2023-08-28 18:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:03 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:03 --> URI Class Initialized
INFO - 2023-08-28 18:13:03 --> Router Class Initialized
INFO - 2023-08-28 18:13:03 --> Output Class Initialized
INFO - 2023-08-28 18:13:03 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:03 --> Input Class Initialized
INFO - 2023-08-28 18:13:03 --> Language Class Initialized
ERROR - 2023-08-28 18:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:13:03 --> Config Class Initialized
INFO - 2023-08-28 18:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:03 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:03 --> URI Class Initialized
INFO - 2023-08-28 18:13:03 --> Router Class Initialized
INFO - 2023-08-28 18:13:03 --> Output Class Initialized
INFO - 2023-08-28 18:13:03 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:03 --> Input Class Initialized
INFO - 2023-08-28 18:13:03 --> Language Class Initialized
ERROR - 2023-08-28 18:13:03 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:13:04 --> Config Class Initialized
INFO - 2023-08-28 18:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:04 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:04 --> URI Class Initialized
INFO - 2023-08-28 18:13:04 --> Router Class Initialized
INFO - 2023-08-28 18:13:04 --> Output Class Initialized
INFO - 2023-08-28 18:13:04 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:04 --> Input Class Initialized
INFO - 2023-08-28 18:13:04 --> Language Class Initialized
ERROR - 2023-08-28 18:13:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:13:04 --> Config Class Initialized
INFO - 2023-08-28 18:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:13:04 --> Utf8 Class Initialized
INFO - 2023-08-28 18:13:04 --> URI Class Initialized
INFO - 2023-08-28 18:13:04 --> Router Class Initialized
INFO - 2023-08-28 18:13:04 --> Output Class Initialized
INFO - 2023-08-28 18:13:04 --> Security Class Initialized
DEBUG - 2023-08-28 18:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:13:04 --> Input Class Initialized
INFO - 2023-08-28 18:13:04 --> Language Class Initialized
ERROR - 2023-08-28 18:13:04 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:14:10 --> Config Class Initialized
INFO - 2023-08-28 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:10 --> URI Class Initialized
INFO - 2023-08-28 18:14:10 --> Router Class Initialized
INFO - 2023-08-28 18:14:10 --> Output Class Initialized
INFO - 2023-08-28 18:14:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:10 --> Input Class Initialized
INFO - 2023-08-28 18:14:10 --> Language Class Initialized
INFO - 2023-08-28 18:14:10 --> Loader Class Initialized
INFO - 2023-08-28 18:14:10 --> Helper loaded: url_helper
INFO - 2023-08-28 18:14:10 --> Helper loaded: file_helper
INFO - 2023-08-28 18:14:10 --> Database Driver Class Initialized
INFO - 2023-08-28 18:14:10 --> Email Class Initialized
DEBUG - 2023-08-28 18:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:14:10 --> Controller Class Initialized
INFO - 2023-08-28 18:14:10 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:14:10 --> Model "Home_model" initialized
INFO - 2023-08-28 18:14:10 --> Helper loaded: download_helper
INFO - 2023-08-28 18:14:10 --> Helper loaded: form_helper
INFO - 2023-08-28 18:14:10 --> Form Validation Class Initialized
INFO - 2023-08-28 18:14:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/about.php
INFO - 2023-08-28 18:14:10 --> Final output sent to browser
DEBUG - 2023-08-28 18:14:10 --> Total execution time: 0.1510
INFO - 2023-08-28 18:14:10 --> Config Class Initialized
INFO - 2023-08-28 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:10 --> URI Class Initialized
INFO - 2023-08-28 18:14:10 --> Router Class Initialized
INFO - 2023-08-28 18:14:10 --> Output Class Initialized
INFO - 2023-08-28 18:14:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:10 --> Input Class Initialized
INFO - 2023-08-28 18:14:10 --> Language Class Initialized
ERROR - 2023-08-28 18:14:10 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:14:10 --> Config Class Initialized
INFO - 2023-08-28 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:10 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:10 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:10 --> URI Class Initialized
INFO - 2023-08-28 18:14:10 --> Router Class Initialized
INFO - 2023-08-28 18:14:10 --> Output Class Initialized
INFO - 2023-08-28 18:14:10 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:10 --> Input Class Initialized
INFO - 2023-08-28 18:14:10 --> Language Class Initialized
ERROR - 2023-08-28 18:14:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:14:10 --> Config Class Initialized
INFO - 2023-08-28 18:14:10 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:11 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:11 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:11 --> URI Class Initialized
INFO - 2023-08-28 18:14:11 --> Router Class Initialized
INFO - 2023-08-28 18:14:11 --> Output Class Initialized
INFO - 2023-08-28 18:14:11 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:11 --> Input Class Initialized
INFO - 2023-08-28 18:14:11 --> Language Class Initialized
ERROR - 2023-08-28 18:14:11 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:14:11 --> Config Class Initialized
INFO - 2023-08-28 18:14:11 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:11 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:11 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:11 --> URI Class Initialized
INFO - 2023-08-28 18:14:11 --> Router Class Initialized
INFO - 2023-08-28 18:14:11 --> Output Class Initialized
INFO - 2023-08-28 18:14:11 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:11 --> Input Class Initialized
INFO - 2023-08-28 18:14:11 --> Language Class Initialized
ERROR - 2023-08-28 18:14:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:14:11 --> Config Class Initialized
INFO - 2023-08-28 18:14:11 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:14:11 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:14:11 --> Utf8 Class Initialized
INFO - 2023-08-28 18:14:11 --> URI Class Initialized
INFO - 2023-08-28 18:14:11 --> Router Class Initialized
INFO - 2023-08-28 18:14:11 --> Output Class Initialized
INFO - 2023-08-28 18:14:11 --> Security Class Initialized
DEBUG - 2023-08-28 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:14:11 --> Input Class Initialized
INFO - 2023-08-28 18:14:11 --> Language Class Initialized
ERROR - 2023-08-28 18:14:11 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:18:42 --> Config Class Initialized
INFO - 2023-08-28 18:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:42 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:42 --> URI Class Initialized
DEBUG - 2023-08-28 18:18:42 --> No URI present. Default controller set.
INFO - 2023-08-28 18:18:42 --> Router Class Initialized
INFO - 2023-08-28 18:18:42 --> Output Class Initialized
INFO - 2023-08-28 18:18:42 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:42 --> Input Class Initialized
INFO - 2023-08-28 18:18:42 --> Language Class Initialized
INFO - 2023-08-28 18:18:42 --> Loader Class Initialized
INFO - 2023-08-28 18:18:42 --> Helper loaded: url_helper
INFO - 2023-08-28 18:18:42 --> Helper loaded: file_helper
INFO - 2023-08-28 18:18:42 --> Database Driver Class Initialized
INFO - 2023-08-28 18:18:42 --> Email Class Initialized
DEBUG - 2023-08-28 18:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:18:42 --> Controller Class Initialized
INFO - 2023-08-28 18:18:42 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:18:42 --> Model "Home_model" initialized
INFO - 2023-08-28 18:18:42 --> Helper loaded: download_helper
INFO - 2023-08-28 18:18:42 --> Helper loaded: form_helper
INFO - 2023-08-28 18:18:42 --> Form Validation Class Initialized
INFO - 2023-08-28 18:18:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:18:42 --> Final output sent to browser
DEBUG - 2023-08-28 18:18:42 --> Total execution time: 0.2926
INFO - 2023-08-28 18:18:43 --> Config Class Initialized
INFO - 2023-08-28 18:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:43 --> URI Class Initialized
INFO - 2023-08-28 18:18:43 --> Router Class Initialized
INFO - 2023-08-28 18:18:43 --> Output Class Initialized
INFO - 2023-08-28 18:18:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:43 --> Input Class Initialized
INFO - 2023-08-28 18:18:43 --> Language Class Initialized
ERROR - 2023-08-28 18:18:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:18:43 --> Config Class Initialized
INFO - 2023-08-28 18:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:43 --> URI Class Initialized
INFO - 2023-08-28 18:18:43 --> Router Class Initialized
INFO - 2023-08-28 18:18:43 --> Output Class Initialized
INFO - 2023-08-28 18:18:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:43 --> Input Class Initialized
INFO - 2023-08-28 18:18:43 --> Language Class Initialized
ERROR - 2023-08-28 18:18:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:18:43 --> Config Class Initialized
INFO - 2023-08-28 18:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:43 --> URI Class Initialized
INFO - 2023-08-28 18:18:43 --> Router Class Initialized
INFO - 2023-08-28 18:18:43 --> Output Class Initialized
INFO - 2023-08-28 18:18:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:43 --> Input Class Initialized
INFO - 2023-08-28 18:18:43 --> Language Class Initialized
ERROR - 2023-08-28 18:18:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:18:43 --> Config Class Initialized
INFO - 2023-08-28 18:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:43 --> URI Class Initialized
INFO - 2023-08-28 18:18:43 --> Router Class Initialized
INFO - 2023-08-28 18:18:43 --> Output Class Initialized
INFO - 2023-08-28 18:18:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:43 --> Input Class Initialized
INFO - 2023-08-28 18:18:43 --> Language Class Initialized
ERROR - 2023-08-28 18:18:43 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:18:43 --> Config Class Initialized
INFO - 2023-08-28 18:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:18:43 --> Utf8 Class Initialized
INFO - 2023-08-28 18:18:43 --> URI Class Initialized
INFO - 2023-08-28 18:18:43 --> Router Class Initialized
INFO - 2023-08-28 18:18:43 --> Output Class Initialized
INFO - 2023-08-28 18:18:43 --> Security Class Initialized
DEBUG - 2023-08-28 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:18:43 --> Input Class Initialized
INFO - 2023-08-28 18:18:43 --> Language Class Initialized
ERROR - 2023-08-28 18:18:43 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:30:07 --> Config Class Initialized
INFO - 2023-08-28 18:30:07 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:07 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:07 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:07 --> URI Class Initialized
DEBUG - 2023-08-28 18:30:07 --> No URI present. Default controller set.
INFO - 2023-08-28 18:30:07 --> Router Class Initialized
INFO - 2023-08-28 18:30:07 --> Output Class Initialized
INFO - 2023-08-28 18:30:07 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:07 --> Input Class Initialized
INFO - 2023-08-28 18:30:07 --> Language Class Initialized
INFO - 2023-08-28 18:30:07 --> Loader Class Initialized
INFO - 2023-08-28 18:30:07 --> Helper loaded: url_helper
INFO - 2023-08-28 18:30:07 --> Helper loaded: file_helper
INFO - 2023-08-28 18:30:07 --> Database Driver Class Initialized
INFO - 2023-08-28 18:30:07 --> Email Class Initialized
DEBUG - 2023-08-28 18:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:30:07 --> Controller Class Initialized
INFO - 2023-08-28 18:30:07 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:30:07 --> Model "Home_model" initialized
INFO - 2023-08-28 18:30:07 --> Helper loaded: download_helper
INFO - 2023-08-28 18:30:07 --> Helper loaded: form_helper
INFO - 2023-08-28 18:30:07 --> Form Validation Class Initialized
INFO - 2023-08-28 18:30:07 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:30:07 --> Final output sent to browser
DEBUG - 2023-08-28 18:30:07 --> Total execution time: 0.0874
INFO - 2023-08-28 18:30:07 --> Config Class Initialized
INFO - 2023-08-28 18:30:07 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:07 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:07 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:07 --> URI Class Initialized
INFO - 2023-08-28 18:30:07 --> Router Class Initialized
INFO - 2023-08-28 18:30:08 --> Config Class Initialized
INFO - 2023-08-28 18:30:08 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:08 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:08 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:08 --> URI Class Initialized
INFO - 2023-08-28 18:30:08 --> Router Class Initialized
INFO - 2023-08-28 18:30:08 --> Output Class Initialized
INFO - 2023-08-28 18:30:08 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:08 --> Input Class Initialized
INFO - 2023-08-28 18:30:08 --> Language Class Initialized
ERROR - 2023-08-28 18:30:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:30:08 --> Config Class Initialized
INFO - 2023-08-28 18:30:08 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:08 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:08 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:08 --> URI Class Initialized
INFO - 2023-08-28 18:30:08 --> Router Class Initialized
INFO - 2023-08-28 18:30:08 --> Output Class Initialized
INFO - 2023-08-28 18:30:08 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:08 --> Input Class Initialized
INFO - 2023-08-28 18:30:08 --> Language Class Initialized
ERROR - 2023-08-28 18:30:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:30:08 --> Config Class Initialized
INFO - 2023-08-28 18:30:08 --> Output Class Initialized
INFO - 2023-08-28 18:30:08 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:08 --> Input Class Initialized
INFO - 2023-08-28 18:30:08 --> Language Class Initialized
ERROR - 2023-08-28 18:30:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:30:08 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:08 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:08 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:08 --> Config Class Initialized
INFO - 2023-08-28 18:30:08 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:30:08 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:30:08 --> Utf8 Class Initialized
INFO - 2023-08-28 18:30:08 --> URI Class Initialized
INFO - 2023-08-28 18:30:08 --> Router Class Initialized
INFO - 2023-08-28 18:30:08 --> Output Class Initialized
INFO - 2023-08-28 18:30:08 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:08 --> Input Class Initialized
INFO - 2023-08-28 18:30:08 --> Language Class Initialized
ERROR - 2023-08-28 18:30:08 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:30:08 --> URI Class Initialized
INFO - 2023-08-28 18:30:08 --> Router Class Initialized
INFO - 2023-08-28 18:30:08 --> Output Class Initialized
INFO - 2023-08-28 18:30:08 --> Security Class Initialized
DEBUG - 2023-08-28 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:30:08 --> Input Class Initialized
INFO - 2023-08-28 18:30:08 --> Language Class Initialized
ERROR - 2023-08-28 18:30:08 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:31:56 --> Config Class Initialized
INFO - 2023-08-28 18:31:56 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:56 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:56 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:56 --> URI Class Initialized
DEBUG - 2023-08-28 18:31:56 --> No URI present. Default controller set.
INFO - 2023-08-28 18:31:56 --> Router Class Initialized
INFO - 2023-08-28 18:31:56 --> Output Class Initialized
INFO - 2023-08-28 18:31:56 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:56 --> Input Class Initialized
INFO - 2023-08-28 18:31:56 --> Language Class Initialized
INFO - 2023-08-28 18:31:56 --> Loader Class Initialized
INFO - 2023-08-28 18:31:56 --> Helper loaded: url_helper
INFO - 2023-08-28 18:31:56 --> Helper loaded: file_helper
INFO - 2023-08-28 18:31:56 --> Database Driver Class Initialized
INFO - 2023-08-28 18:31:56 --> Email Class Initialized
DEBUG - 2023-08-28 18:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:31:56 --> Controller Class Initialized
INFO - 2023-08-28 18:31:56 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:31:56 --> Model "Home_model" initialized
INFO - 2023-08-28 18:31:56 --> Helper loaded: download_helper
INFO - 2023-08-28 18:31:56 --> Helper loaded: form_helper
INFO - 2023-08-28 18:31:56 --> Form Validation Class Initialized
INFO - 2023-08-28 18:31:56 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:31:56 --> Final output sent to browser
DEBUG - 2023-08-28 18:31:57 --> Total execution time: 0.1662
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:31:57 --> Config Class Initialized
INFO - 2023-08-28 18:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:31:57 --> Utf8 Class Initialized
INFO - 2023-08-28 18:31:57 --> URI Class Initialized
INFO - 2023-08-28 18:31:57 --> Router Class Initialized
INFO - 2023-08-28 18:31:57 --> Output Class Initialized
INFO - 2023-08-28 18:31:57 --> Security Class Initialized
DEBUG - 2023-08-28 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:31:57 --> Input Class Initialized
INFO - 2023-08-28 18:31:57 --> Language Class Initialized
ERROR - 2023-08-28 18:31:57 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:41:59 --> Config Class Initialized
INFO - 2023-08-28 18:41:59 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:41:59 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:41:59 --> Utf8 Class Initialized
INFO - 2023-08-28 18:41:59 --> URI Class Initialized
DEBUG - 2023-08-28 18:41:59 --> No URI present. Default controller set.
INFO - 2023-08-28 18:41:59 --> Router Class Initialized
INFO - 2023-08-28 18:41:59 --> Output Class Initialized
INFO - 2023-08-28 18:41:59 --> Security Class Initialized
DEBUG - 2023-08-28 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:41:59 --> Input Class Initialized
INFO - 2023-08-28 18:41:59 --> Language Class Initialized
INFO - 2023-08-28 18:41:59 --> Loader Class Initialized
INFO - 2023-08-28 18:41:59 --> Helper loaded: url_helper
INFO - 2023-08-28 18:41:59 --> Helper loaded: file_helper
INFO - 2023-08-28 18:41:59 --> Database Driver Class Initialized
INFO - 2023-08-28 18:41:59 --> Email Class Initialized
DEBUG - 2023-08-28 18:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:41:59 --> Controller Class Initialized
INFO - 2023-08-28 18:41:59 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:41:59 --> Model "Home_model" initialized
INFO - 2023-08-28 18:41:59 --> Helper loaded: download_helper
INFO - 2023-08-28 18:41:59 --> Helper loaded: form_helper
INFO - 2023-08-28 18:41:59 --> Form Validation Class Initialized
INFO - 2023-08-28 18:41:59 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:41:59 --> Final output sent to browser
DEBUG - 2023-08-28 18:41:59 --> Total execution time: 0.0473
INFO - 2023-08-28 18:41:59 --> Config Class Initialized
INFO - 2023-08-28 18:41:59 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:41:59 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:41:59 --> Utf8 Class Initialized
INFO - 2023-08-28 18:41:59 --> URI Class Initialized
INFO - 2023-08-28 18:41:59 --> Router Class Initialized
INFO - 2023-08-28 18:41:59 --> Output Class Initialized
INFO - 2023-08-28 18:41:59 --> Security Class Initialized
DEBUG - 2023-08-28 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:41:59 --> Input Class Initialized
INFO - 2023-08-28 18:41:59 --> Language Class Initialized
ERROR - 2023-08-28 18:41:59 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:41:59 --> Config Class Initialized
INFO - 2023-08-28 18:41:59 --> Hooks Class Initialized
INFO - 2023-08-28 18:41:59 --> Config Class Initialized
DEBUG - 2023-08-28 18:41:59 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:41:59 --> Utf8 Class Initialized
INFO - 2023-08-28 18:41:59 --> URI Class Initialized
INFO - 2023-08-28 18:41:59 --> Router Class Initialized
INFO - 2023-08-28 18:41:59 --> Output Class Initialized
INFO - 2023-08-28 18:41:59 --> Security Class Initialized
DEBUG - 2023-08-28 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:41:59 --> Input Class Initialized
INFO - 2023-08-28 18:41:59 --> Language Class Initialized
ERROR - 2023-08-28 18:41:59 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:41:59 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:41:59 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:41:59 --> Utf8 Class Initialized
INFO - 2023-08-28 18:41:59 --> URI Class Initialized
INFO - 2023-08-28 18:41:59 --> Router Class Initialized
INFO - 2023-08-28 18:42:00 --> Config Class Initialized
INFO - 2023-08-28 18:42:00 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:42:00 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:42:00 --> Utf8 Class Initialized
INFO - 2023-08-28 18:42:00 --> URI Class Initialized
INFO - 2023-08-28 18:42:00 --> Router Class Initialized
INFO - 2023-08-28 18:42:00 --> Output Class Initialized
INFO - 2023-08-28 18:42:00 --> Security Class Initialized
DEBUG - 2023-08-28 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:42:00 --> Input Class Initialized
INFO - 2023-08-28 18:42:00 --> Language Class Initialized
ERROR - 2023-08-28 18:42:00 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:42:00 --> Output Class Initialized
INFO - 2023-08-28 18:42:00 --> Security Class Initialized
DEBUG - 2023-08-28 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:42:00 --> Input Class Initialized
INFO - 2023-08-28 18:42:00 --> Language Class Initialized
ERROR - 2023-08-28 18:42:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:42:00 --> Config Class Initialized
INFO - 2023-08-28 18:42:00 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:42:00 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:42:00 --> Utf8 Class Initialized
INFO - 2023-08-28 18:42:00 --> URI Class Initialized
INFO - 2023-08-28 18:42:00 --> Router Class Initialized
INFO - 2023-08-28 18:42:00 --> Output Class Initialized
INFO - 2023-08-28 18:42:00 --> Security Class Initialized
DEBUG - 2023-08-28 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:42:00 --> Input Class Initialized
INFO - 2023-08-28 18:42:00 --> Language Class Initialized
ERROR - 2023-08-28 18:42:00 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:42:00 --> Config Class Initialized
INFO - 2023-08-28 18:42:00 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:42:00 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:42:01 --> Utf8 Class Initialized
INFO - 2023-08-28 18:42:01 --> URI Class Initialized
INFO - 2023-08-28 18:42:01 --> Router Class Initialized
INFO - 2023-08-28 18:42:01 --> Output Class Initialized
INFO - 2023-08-28 18:42:01 --> Security Class Initialized
DEBUG - 2023-08-28 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:42:01 --> Input Class Initialized
INFO - 2023-08-28 18:42:01 --> Language Class Initialized
ERROR - 2023-08-28 18:42:01 --> 404 Page Not Found: Assets/home
INFO - 2023-08-28 18:45:46 --> Config Class Initialized
INFO - 2023-08-28 18:45:46 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:45:46 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:45:46 --> Utf8 Class Initialized
INFO - 2023-08-28 18:45:46 --> URI Class Initialized
DEBUG - 2023-08-28 18:45:46 --> No URI present. Default controller set.
INFO - 2023-08-28 18:45:46 --> Router Class Initialized
INFO - 2023-08-28 18:45:46 --> Output Class Initialized
INFO - 2023-08-28 18:45:46 --> Security Class Initialized
DEBUG - 2023-08-28 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:45:46 --> Input Class Initialized
INFO - 2023-08-28 18:45:46 --> Language Class Initialized
INFO - 2023-08-28 18:45:46 --> Loader Class Initialized
INFO - 2023-08-28 18:45:46 --> Helper loaded: url_helper
INFO - 2023-08-28 18:45:46 --> Helper loaded: file_helper
INFO - 2023-08-28 18:45:46 --> Database Driver Class Initialized
INFO - 2023-08-28 18:45:46 --> Email Class Initialized
DEBUG - 2023-08-28 18:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:45:46 --> Controller Class Initialized
INFO - 2023-08-28 18:45:46 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:45:46 --> Model "Home_model" initialized
INFO - 2023-08-28 18:45:46 --> Helper loaded: download_helper
INFO - 2023-08-28 18:45:46 --> Helper loaded: form_helper
INFO - 2023-08-28 18:45:46 --> Form Validation Class Initialized
INFO - 2023-08-28 18:45:46 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:45:46 --> Final output sent to browser
DEBUG - 2023-08-28 18:45:46 --> Total execution time: 0.1700
INFO - 2023-08-28 18:45:47 --> Config Class Initialized
INFO - 2023-08-28 18:45:47 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:45:47 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:45:47 --> Utf8 Class Initialized
INFO - 2023-08-28 18:45:47 --> URI Class Initialized
INFO - 2023-08-28 18:45:47 --> Config Class Initialized
INFO - 2023-08-28 18:45:47 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:45:47 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:45:47 --> Utf8 Class Initialized
INFO - 2023-08-28 18:45:47 --> URI Class Initialized
INFO - 2023-08-28 18:45:47 --> Router Class Initialized
INFO - 2023-08-28 18:45:47 --> Output Class Initialized
INFO - 2023-08-28 18:45:47 --> Security Class Initialized
DEBUG - 2023-08-28 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:45:47 --> Input Class Initialized
INFO - 2023-08-28 18:45:47 --> Language Class Initialized
ERROR - 2023-08-28 18:45:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:45:47 --> Router Class Initialized
INFO - 2023-08-28 18:45:47 --> Output Class Initialized
INFO - 2023-08-28 18:45:47 --> Security Class Initialized
DEBUG - 2023-08-28 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:45:47 --> Input Class Initialized
INFO - 2023-08-28 18:45:47 --> Language Class Initialized
ERROR - 2023-08-28 18:45:47 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:48:28 --> Config Class Initialized
INFO - 2023-08-28 18:48:28 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:48:28 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:48:28 --> Utf8 Class Initialized
INFO - 2023-08-28 18:48:28 --> URI Class Initialized
DEBUG - 2023-08-28 18:48:28 --> No URI present. Default controller set.
INFO - 2023-08-28 18:48:28 --> Router Class Initialized
INFO - 2023-08-28 18:48:28 --> Output Class Initialized
INFO - 2023-08-28 18:48:28 --> Security Class Initialized
DEBUG - 2023-08-28 18:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:48:28 --> Input Class Initialized
INFO - 2023-08-28 18:48:28 --> Language Class Initialized
INFO - 2023-08-28 18:48:28 --> Loader Class Initialized
INFO - 2023-08-28 18:48:28 --> Helper loaded: url_helper
INFO - 2023-08-28 18:48:28 --> Helper loaded: file_helper
INFO - 2023-08-28 18:48:28 --> Database Driver Class Initialized
INFO - 2023-08-28 18:48:28 --> Email Class Initialized
DEBUG - 2023-08-28 18:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:48:28 --> Controller Class Initialized
INFO - 2023-08-28 18:48:28 --> Model "Contact_model" initialized
INFO - 2023-08-28 18:48:29 --> Model "Home_model" initialized
INFO - 2023-08-28 18:48:29 --> Helper loaded: download_helper
INFO - 2023-08-28 18:48:29 --> Helper loaded: form_helper
INFO - 2023-08-28 18:48:29 --> Form Validation Class Initialized
INFO - 2023-08-28 18:48:29 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 18:48:29 --> Final output sent to browser
DEBUG - 2023-08-28 18:48:29 --> Total execution time: 0.7875
INFO - 2023-08-28 18:48:29 --> Config Class Initialized
INFO - 2023-08-28 18:48:29 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:48:29 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:48:29 --> Utf8 Class Initialized
INFO - 2023-08-28 18:48:29 --> URI Class Initialized
INFO - 2023-08-28 18:48:29 --> Router Class Initialized
INFO - 2023-08-28 18:48:29 --> Output Class Initialized
INFO - 2023-08-28 18:48:29 --> Security Class Initialized
DEBUG - 2023-08-28 18:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:48:29 --> Input Class Initialized
INFO - 2023-08-28 18:48:29 --> Language Class Initialized
ERROR - 2023-08-28 18:48:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:48:29 --> Config Class Initialized
INFO - 2023-08-28 18:48:29 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:48:29 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:48:29 --> Utf8 Class Initialized
INFO - 2023-08-28 18:48:29 --> URI Class Initialized
INFO - 2023-08-28 18:48:29 --> Router Class Initialized
INFO - 2023-08-28 18:48:29 --> Output Class Initialized
INFO - 2023-08-28 18:48:29 --> Security Class Initialized
DEBUG - 2023-08-28 18:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:48:29 --> Input Class Initialized
INFO - 2023-08-28 18:48:29 --> Language Class Initialized
ERROR - 2023-08-28 18:48:29 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 18:55:30 --> Config Class Initialized
INFO - 2023-08-28 18:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:55:30 --> Utf8 Class Initialized
INFO - 2023-08-28 18:55:30 --> URI Class Initialized
INFO - 2023-08-28 18:55:30 --> Router Class Initialized
INFO - 2023-08-28 18:55:30 --> Output Class Initialized
INFO - 2023-08-28 18:55:30 --> Security Class Initialized
DEBUG - 2023-08-28 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:55:30 --> Input Class Initialized
INFO - 2023-08-28 18:55:30 --> Language Class Initialized
INFO - 2023-08-28 18:55:30 --> Loader Class Initialized
INFO - 2023-08-28 18:55:30 --> Helper loaded: url_helper
INFO - 2023-08-28 18:55:30 --> Helper loaded: file_helper
INFO - 2023-08-28 18:55:30 --> Database Driver Class Initialized
INFO - 2023-08-28 18:55:30 --> Email Class Initialized
DEBUG - 2023-08-28 18:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:55:31 --> Controller Class Initialized
INFO - 2023-08-28 18:55:31 --> Model "Blog_model" initialized
INFO - 2023-08-28 18:55:31 --> Helper loaded: form_helper
INFO - 2023-08-28 18:55:31 --> Form Validation Class Initialized
INFO - 2023-08-28 18:55:31 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_list.php
INFO - 2023-08-28 18:55:31 --> Final output sent to browser
DEBUG - 2023-08-28 18:55:31 --> Total execution time: 0.6619
INFO - 2023-08-28 18:55:37 --> Config Class Initialized
INFO - 2023-08-28 18:55:37 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:55:37 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:55:37 --> Utf8 Class Initialized
INFO - 2023-08-28 18:55:37 --> URI Class Initialized
INFO - 2023-08-28 18:55:37 --> Router Class Initialized
INFO - 2023-08-28 18:55:37 --> Output Class Initialized
INFO - 2023-08-28 18:55:37 --> Security Class Initialized
DEBUG - 2023-08-28 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:55:37 --> Input Class Initialized
INFO - 2023-08-28 18:55:37 --> Language Class Initialized
INFO - 2023-08-28 18:55:37 --> Loader Class Initialized
INFO - 2023-08-28 18:55:37 --> Helper loaded: url_helper
INFO - 2023-08-28 18:55:37 --> Helper loaded: file_helper
INFO - 2023-08-28 18:55:37 --> Database Driver Class Initialized
INFO - 2023-08-28 18:55:37 --> Email Class Initialized
DEBUG - 2023-08-28 18:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 18:55:37 --> Controller Class Initialized
INFO - 2023-08-28 18:55:37 --> Model "Blog_model" initialized
INFO - 2023-08-28 18:55:37 --> Helper loaded: form_helper
INFO - 2023-08-28 18:55:37 --> Form Validation Class Initialized
INFO - 2023-08-28 18:55:37 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/blog_create.php
INFO - 2023-08-28 18:55:38 --> Final output sent to browser
DEBUG - 2023-08-28 18:55:38 --> Total execution time: 0.7341
INFO - 2023-08-28 18:55:38 --> Config Class Initialized
INFO - 2023-08-28 18:55:38 --> Hooks Class Initialized
DEBUG - 2023-08-28 18:55:38 --> UTF-8 Support Enabled
INFO - 2023-08-28 18:55:38 --> Utf8 Class Initialized
INFO - 2023-08-28 18:55:38 --> URI Class Initialized
INFO - 2023-08-28 18:55:38 --> Router Class Initialized
INFO - 2023-08-28 18:55:38 --> Output Class Initialized
INFO - 2023-08-28 18:55:38 --> Security Class Initialized
DEBUG - 2023-08-28 18:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 18:55:38 --> Input Class Initialized
INFO - 2023-08-28 18:55:38 --> Language Class Initialized
ERROR - 2023-08-28 18:55:38 --> 404 Page Not Found: admin/Blog/images
INFO - 2023-08-28 19:14:51 --> Config Class Initialized
INFO - 2023-08-28 19:14:51 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:14:51 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:14:51 --> Utf8 Class Initialized
INFO - 2023-08-28 19:14:51 --> URI Class Initialized
DEBUG - 2023-08-28 19:14:51 --> No URI present. Default controller set.
INFO - 2023-08-28 19:14:51 --> Router Class Initialized
INFO - 2023-08-28 19:14:51 --> Output Class Initialized
INFO - 2023-08-28 19:14:51 --> Security Class Initialized
DEBUG - 2023-08-28 19:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:14:51 --> Input Class Initialized
INFO - 2023-08-28 19:14:51 --> Language Class Initialized
INFO - 2023-08-28 19:14:51 --> Loader Class Initialized
INFO - 2023-08-28 19:14:51 --> Helper loaded: url_helper
INFO - 2023-08-28 19:14:51 --> Helper loaded: file_helper
INFO - 2023-08-28 19:14:51 --> Database Driver Class Initialized
INFO - 2023-08-28 19:14:51 --> Email Class Initialized
DEBUG - 2023-08-28 19:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 19:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 19:14:52 --> Controller Class Initialized
INFO - 2023-08-28 19:14:52 --> Model "Contact_model" initialized
INFO - 2023-08-28 19:14:52 --> Model "Home_model" initialized
INFO - 2023-08-28 19:14:52 --> Helper loaded: download_helper
INFO - 2023-08-28 19:14:52 --> Helper loaded: form_helper
INFO - 2023-08-28 19:14:52 --> Form Validation Class Initialized
INFO - 2023-08-28 19:14:52 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 19:14:52 --> Final output sent to browser
DEBUG - 2023-08-28 19:14:52 --> Total execution time: 0.7451
INFO - 2023-08-28 19:14:53 --> Config Class Initialized
INFO - 2023-08-28 19:14:53 --> Config Class Initialized
INFO - 2023-08-28 19:14:53 --> Hooks Class Initialized
INFO - 2023-08-28 19:14:53 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2023-08-28 19:14:53 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:14:53 --> Utf8 Class Initialized
INFO - 2023-08-28 19:14:53 --> URI Class Initialized
INFO - 2023-08-28 19:14:53 --> Utf8 Class Initialized
INFO - 2023-08-28 19:14:53 --> Router Class Initialized
INFO - 2023-08-28 19:14:53 --> Output Class Initialized
INFO - 2023-08-28 19:14:53 --> URI Class Initialized
INFO - 2023-08-28 19:14:53 --> Security Class Initialized
INFO - 2023-08-28 19:14:53 --> Router Class Initialized
INFO - 2023-08-28 19:14:53 --> Output Class Initialized
DEBUG - 2023-08-28 19:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:14:53 --> Security Class Initialized
INFO - 2023-08-28 19:14:53 --> Input Class Initialized
DEBUG - 2023-08-28 19:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:14:53 --> Input Class Initialized
INFO - 2023-08-28 19:14:53 --> Language Class Initialized
INFO - 2023-08-28 19:14:53 --> Language Class Initialized
ERROR - 2023-08-28 19:14:53 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-28 19:14:53 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:19:26 --> Config Class Initialized
INFO - 2023-08-28 19:19:26 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:19:26 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:19:26 --> Utf8 Class Initialized
INFO - 2023-08-28 19:19:26 --> URI Class Initialized
DEBUG - 2023-08-28 19:19:26 --> No URI present. Default controller set.
INFO - 2023-08-28 19:19:26 --> Router Class Initialized
INFO - 2023-08-28 19:19:26 --> Output Class Initialized
INFO - 2023-08-28 19:19:26 --> Security Class Initialized
DEBUG - 2023-08-28 19:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:19:27 --> Input Class Initialized
INFO - 2023-08-28 19:19:27 --> Language Class Initialized
INFO - 2023-08-28 19:19:27 --> Loader Class Initialized
INFO - 2023-08-28 19:19:27 --> Helper loaded: url_helper
INFO - 2023-08-28 19:19:27 --> Helper loaded: file_helper
INFO - 2023-08-28 19:19:27 --> Database Driver Class Initialized
INFO - 2023-08-28 19:19:27 --> Email Class Initialized
DEBUG - 2023-08-28 19:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 19:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 19:19:27 --> Controller Class Initialized
INFO - 2023-08-28 19:19:27 --> Model "Contact_model" initialized
INFO - 2023-08-28 19:19:27 --> Model "Home_model" initialized
INFO - 2023-08-28 19:19:27 --> Helper loaded: download_helper
INFO - 2023-08-28 19:19:27 --> Helper loaded: form_helper
INFO - 2023-08-28 19:19:27 --> Form Validation Class Initialized
INFO - 2023-08-28 19:19:27 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 19:19:27 --> Final output sent to browser
DEBUG - 2023-08-28 19:19:27 --> Total execution time: 0.7735
INFO - 2023-08-28 19:19:28 --> Config Class Initialized
INFO - 2023-08-28 19:19:28 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:19:28 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:19:28 --> Utf8 Class Initialized
INFO - 2023-08-28 19:19:28 --> URI Class Initialized
INFO - 2023-08-28 19:19:28 --> Router Class Initialized
INFO - 2023-08-28 19:19:28 --> Output Class Initialized
INFO - 2023-08-28 19:19:28 --> Security Class Initialized
DEBUG - 2023-08-28 19:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:19:28 --> Input Class Initialized
INFO - 2023-08-28 19:19:28 --> Language Class Initialized
ERROR - 2023-08-28 19:19:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:19:28 --> Config Class Initialized
INFO - 2023-08-28 19:19:28 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:19:28 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:19:28 --> Utf8 Class Initialized
INFO - 2023-08-28 19:19:28 --> URI Class Initialized
INFO - 2023-08-28 19:19:28 --> Router Class Initialized
INFO - 2023-08-28 19:19:28 --> Output Class Initialized
INFO - 2023-08-28 19:19:28 --> Security Class Initialized
DEBUG - 2023-08-28 19:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:19:28 --> Input Class Initialized
INFO - 2023-08-28 19:19:28 --> Language Class Initialized
ERROR - 2023-08-28 19:19:28 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:23:08 --> Config Class Initialized
INFO - 2023-08-28 19:23:08 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:08 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:08 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:08 --> URI Class Initialized
DEBUG - 2023-08-28 19:23:08 --> No URI present. Default controller set.
INFO - 2023-08-28 19:23:08 --> Router Class Initialized
INFO - 2023-08-28 19:23:08 --> Output Class Initialized
INFO - 2023-08-28 19:23:08 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:08 --> Input Class Initialized
INFO - 2023-08-28 19:23:08 --> Language Class Initialized
INFO - 2023-08-28 19:23:08 --> Loader Class Initialized
INFO - 2023-08-28 19:23:08 --> Helper loaded: url_helper
INFO - 2023-08-28 19:23:08 --> Helper loaded: file_helper
INFO - 2023-08-28 19:23:08 --> Database Driver Class Initialized
INFO - 2023-08-28 19:23:08 --> Email Class Initialized
DEBUG - 2023-08-28 19:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 19:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 19:23:08 --> Controller Class Initialized
INFO - 2023-08-28 19:23:08 --> Model "Contact_model" initialized
INFO - 2023-08-28 19:23:08 --> Model "Home_model" initialized
INFO - 2023-08-28 19:23:08 --> Helper loaded: download_helper
INFO - 2023-08-28 19:23:08 --> Helper loaded: form_helper
INFO - 2023-08-28 19:23:08 --> Form Validation Class Initialized
INFO - 2023-08-28 19:23:08 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-08-28 19:23:08 --> Final output sent to browser
DEBUG - 2023-08-28 19:23:08 --> Total execution time: 0.5938
INFO - 2023-08-28 19:23:09 --> Config Class Initialized
INFO - 2023-08-28 19:23:09 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:09 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:09 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:09 --> URI Class Initialized
INFO - 2023-08-28 19:23:09 --> Router Class Initialized
INFO - 2023-08-28 19:23:09 --> Output Class Initialized
INFO - 2023-08-28 19:23:09 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:09 --> Input Class Initialized
INFO - 2023-08-28 19:23:09 --> Language Class Initialized
ERROR - 2023-08-28 19:23:09 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:23:09 --> Config Class Initialized
INFO - 2023-08-28 19:23:09 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:09 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:09 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:09 --> URI Class Initialized
INFO - 2023-08-28 19:23:09 --> Router Class Initialized
INFO - 2023-08-28 19:23:09 --> Output Class Initialized
INFO - 2023-08-28 19:23:10 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:10 --> Input Class Initialized
INFO - 2023-08-28 19:23:10 --> Language Class Initialized
ERROR - 2023-08-28 19:23:10 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:23:31 --> Config Class Initialized
INFO - 2023-08-28 19:23:31 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:31 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:31 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:31 --> URI Class Initialized
INFO - 2023-08-28 19:23:31 --> Router Class Initialized
INFO - 2023-08-28 19:23:31 --> Output Class Initialized
INFO - 2023-08-28 19:23:31 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:31 --> Input Class Initialized
INFO - 2023-08-28 19:23:31 --> Language Class Initialized
INFO - 2023-08-28 19:23:31 --> Loader Class Initialized
INFO - 2023-08-28 19:23:31 --> Helper loaded: url_helper
INFO - 2023-08-28 19:23:31 --> Helper loaded: file_helper
INFO - 2023-08-28 19:23:31 --> Database Driver Class Initialized
INFO - 2023-08-28 19:23:31 --> Email Class Initialized
DEBUG - 2023-08-28 19:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-28 19:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-28 19:23:32 --> Controller Class Initialized
INFO - 2023-08-28 19:23:32 --> Model "Contact_model" initialized
INFO - 2023-08-28 19:23:32 --> Model "Home_model" initialized
INFO - 2023-08-28 19:23:32 --> Helper loaded: download_helper
INFO - 2023-08-28 19:23:32 --> Helper loaded: form_helper
INFO - 2023-08-28 19:23:32 --> Form Validation Class Initialized
INFO - 2023-08-28 19:23:32 --> File loaded: C:\xampp\htdocs\dw\application\views\home/contact.php
INFO - 2023-08-28 19:23:32 --> Final output sent to browser
DEBUG - 2023-08-28 19:23:32 --> Total execution time: 0.4009
INFO - 2023-08-28 19:23:32 --> Config Class Initialized
INFO - 2023-08-28 19:23:32 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:32 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:32 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:32 --> URI Class Initialized
INFO - 2023-08-28 19:23:32 --> Router Class Initialized
INFO - 2023-08-28 19:23:32 --> Output Class Initialized
INFO - 2023-08-28 19:23:32 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:32 --> Input Class Initialized
INFO - 2023-08-28 19:23:32 --> Language Class Initialized
ERROR - 2023-08-28 19:23:32 --> 404 Page Not Found: Assets/images
INFO - 2023-08-28 19:23:32 --> Config Class Initialized
INFO - 2023-08-28 19:23:32 --> Hooks Class Initialized
DEBUG - 2023-08-28 19:23:32 --> UTF-8 Support Enabled
INFO - 2023-08-28 19:23:32 --> Utf8 Class Initialized
INFO - 2023-08-28 19:23:32 --> URI Class Initialized
INFO - 2023-08-28 19:23:32 --> Router Class Initialized
INFO - 2023-08-28 19:23:32 --> Output Class Initialized
INFO - 2023-08-28 19:23:32 --> Security Class Initialized
DEBUG - 2023-08-28 19:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-28 19:23:32 --> Input Class Initialized
INFO - 2023-08-28 19:23:32 --> Language Class Initialized
ERROR - 2023-08-28 19:23:32 --> 404 Page Not Found: Assets/images
