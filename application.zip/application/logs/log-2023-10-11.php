<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-11 16:58:57 --> Config Class Initialized
INFO - 2023-10-11 16:58:57 --> Hooks Class Initialized
DEBUG - 2023-10-11 16:58:57 --> UTF-8 Support Enabled
INFO - 2023-10-11 16:58:57 --> Utf8 Class Initialized
INFO - 2023-10-11 16:58:57 --> URI Class Initialized
DEBUG - 2023-10-11 16:58:57 --> No URI present. Default controller set.
INFO - 2023-10-11 16:58:57 --> Router Class Initialized
INFO - 2023-10-11 16:58:57 --> Output Class Initialized
INFO - 2023-10-11 16:58:57 --> Security Class Initialized
DEBUG - 2023-10-11 16:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 16:58:57 --> Input Class Initialized
INFO - 2023-10-11 16:58:57 --> Language Class Initialized
INFO - 2023-10-11 16:58:57 --> Loader Class Initialized
INFO - 2023-10-11 16:58:57 --> Helper loaded: url_helper
INFO - 2023-10-11 16:58:57 --> Helper loaded: file_helper
INFO - 2023-10-11 16:58:57 --> Database Driver Class Initialized
INFO - 2023-10-11 16:58:57 --> Email Class Initialized
DEBUG - 2023-10-11 16:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 16:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 16:58:57 --> Controller Class Initialized
INFO - 2023-10-11 16:58:57 --> Model "Contact_model" initialized
INFO - 2023-10-11 16:58:57 --> Model "Home_model" initialized
INFO - 2023-10-11 16:58:57 --> Helper loaded: download_helper
INFO - 2023-10-11 16:58:58 --> Helper loaded: form_helper
INFO - 2023-10-11 16:58:58 --> Form Validation Class Initialized
INFO - 2023-10-11 16:58:58 --> Helper loaded: custom_helper
INFO - 2023-10-11 16:58:58 --> Model "Social_media_model" initialized
INFO - 2023-10-11 16:58:58 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 16:58:58 --> Final output sent to browser
DEBUG - 2023-10-11 16:58:58 --> Total execution time: 0.1901
INFO - 2023-10-11 16:59:07 --> Config Class Initialized
INFO - 2023-10-11 16:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-11 16:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-11 16:59:07 --> Utf8 Class Initialized
INFO - 2023-10-11 16:59:07 --> URI Class Initialized
INFO - 2023-10-11 16:59:07 --> Router Class Initialized
INFO - 2023-10-11 16:59:07 --> Output Class Initialized
INFO - 2023-10-11 16:59:07 --> Security Class Initialized
DEBUG - 2023-10-11 16:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 16:59:07 --> Input Class Initialized
INFO - 2023-10-11 16:59:07 --> Language Class Initialized
INFO - 2023-10-11 16:59:07 --> Loader Class Initialized
INFO - 2023-10-11 16:59:07 --> Helper loaded: url_helper
INFO - 2023-10-11 16:59:07 --> Helper loaded: file_helper
INFO - 2023-10-11 16:59:07 --> Database Driver Class Initialized
INFO - 2023-10-11 16:59:07 --> Email Class Initialized
DEBUG - 2023-10-11 16:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 16:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 16:59:07 --> Controller Class Initialized
INFO - 2023-10-11 16:59:07 --> Config Class Initialized
INFO - 2023-10-11 16:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-11 16:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-11 16:59:07 --> Utf8 Class Initialized
INFO - 2023-10-11 16:59:07 --> URI Class Initialized
INFO - 2023-10-11 16:59:07 --> Router Class Initialized
INFO - 2023-10-11 16:59:07 --> Output Class Initialized
INFO - 2023-10-11 16:59:07 --> Security Class Initialized
DEBUG - 2023-10-11 16:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 16:59:07 --> Input Class Initialized
INFO - 2023-10-11 16:59:07 --> Language Class Initialized
INFO - 2023-10-11 16:59:07 --> Loader Class Initialized
INFO - 2023-10-11 16:59:07 --> Helper loaded: url_helper
INFO - 2023-10-11 16:59:07 --> Helper loaded: file_helper
INFO - 2023-10-11 16:59:07 --> Database Driver Class Initialized
INFO - 2023-10-11 16:59:07 --> Email Class Initialized
DEBUG - 2023-10-11 16:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 16:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 16:59:07 --> Controller Class Initialized
INFO - 2023-10-11 16:59:07 --> Model "User_model" initialized
INFO - 2023-10-11 16:59:07 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-10-11 16:59:07 --> Final output sent to browser
DEBUG - 2023-10-11 16:59:07 --> Total execution time: 0.0766
INFO - 2023-10-11 16:59:09 --> Config Class Initialized
INFO - 2023-10-11 16:59:09 --> Hooks Class Initialized
DEBUG - 2023-10-11 16:59:09 --> UTF-8 Support Enabled
INFO - 2023-10-11 16:59:09 --> Utf8 Class Initialized
INFO - 2023-10-11 16:59:09 --> URI Class Initialized
INFO - 2023-10-11 16:59:09 --> Router Class Initialized
INFO - 2023-10-11 16:59:09 --> Output Class Initialized
INFO - 2023-10-11 16:59:09 --> Security Class Initialized
DEBUG - 2023-10-11 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 16:59:09 --> Input Class Initialized
INFO - 2023-10-11 16:59:09 --> Language Class Initialized
ERROR - 2023-10-11 16:59:09 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-11 17:16:20 --> Config Class Initialized
INFO - 2023-10-11 17:16:20 --> Hooks Class Initialized
DEBUG - 2023-10-11 17:16:20 --> UTF-8 Support Enabled
INFO - 2023-10-11 17:16:20 --> Utf8 Class Initialized
INFO - 2023-10-11 17:16:20 --> URI Class Initialized
INFO - 2023-10-11 17:16:20 --> Router Class Initialized
INFO - 2023-10-11 17:16:20 --> Output Class Initialized
INFO - 2023-10-11 17:16:20 --> Security Class Initialized
DEBUG - 2023-10-11 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 17:16:20 --> Input Class Initialized
INFO - 2023-10-11 17:16:20 --> Language Class Initialized
INFO - 2023-10-11 17:16:20 --> Loader Class Initialized
INFO - 2023-10-11 17:16:20 --> Helper loaded: url_helper
INFO - 2023-10-11 17:16:20 --> Helper loaded: file_helper
INFO - 2023-10-11 17:16:20 --> Database Driver Class Initialized
INFO - 2023-10-11 17:16:20 --> Email Class Initialized
DEBUG - 2023-10-11 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 17:16:20 --> Controller Class Initialized
INFO - 2023-10-11 17:16:20 --> Model "User_model" initialized
INFO - 2023-10-11 17:16:20 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/login.php
INFO - 2023-10-11 17:16:20 --> Final output sent to browser
DEBUG - 2023-10-11 17:16:20 --> Total execution time: 0.1717
INFO - 2023-10-11 17:16:21 --> Config Class Initialized
INFO - 2023-10-11 17:16:21 --> Hooks Class Initialized
DEBUG - 2023-10-11 17:16:21 --> UTF-8 Support Enabled
INFO - 2023-10-11 17:16:21 --> Utf8 Class Initialized
INFO - 2023-10-11 17:16:21 --> URI Class Initialized
INFO - 2023-10-11 17:16:21 --> Router Class Initialized
INFO - 2023-10-11 17:16:21 --> Output Class Initialized
INFO - 2023-10-11 17:16:21 --> Security Class Initialized
DEBUG - 2023-10-11 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 17:16:21 --> Input Class Initialized
INFO - 2023-10-11 17:16:21 --> Language Class Initialized
ERROR - 2023-10-11 17:16:21 --> 404 Page Not Found: admin/Images/favicon.png
INFO - 2023-10-11 17:16:30 --> Config Class Initialized
INFO - 2023-10-11 17:16:30 --> Hooks Class Initialized
DEBUG - 2023-10-11 17:16:30 --> UTF-8 Support Enabled
INFO - 2023-10-11 17:16:30 --> Utf8 Class Initialized
INFO - 2023-10-11 17:16:30 --> URI Class Initialized
INFO - 2023-10-11 17:16:30 --> Router Class Initialized
INFO - 2023-10-11 17:16:30 --> Output Class Initialized
INFO - 2023-10-11 17:16:30 --> Security Class Initialized
DEBUG - 2023-10-11 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 17:16:30 --> Input Class Initialized
INFO - 2023-10-11 17:16:30 --> Language Class Initialized
INFO - 2023-10-11 17:16:30 --> Loader Class Initialized
INFO - 2023-10-11 17:16:30 --> Helper loaded: url_helper
INFO - 2023-10-11 17:16:30 --> Helper loaded: file_helper
INFO - 2023-10-11 17:16:30 --> Database Driver Class Initialized
INFO - 2023-10-11 17:16:30 --> Email Class Initialized
DEBUG - 2023-10-11 17:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 17:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 17:16:30 --> Controller Class Initialized
INFO - 2023-10-11 17:16:30 --> Model "User_model" initialized
INFO - 2023-10-11 17:16:30 --> Config Class Initialized
INFO - 2023-10-11 17:16:30 --> Hooks Class Initialized
DEBUG - 2023-10-11 17:16:30 --> UTF-8 Support Enabled
INFO - 2023-10-11 17:16:30 --> Utf8 Class Initialized
INFO - 2023-10-11 17:16:30 --> URI Class Initialized
INFO - 2023-10-11 17:16:30 --> Router Class Initialized
INFO - 2023-10-11 17:16:30 --> Output Class Initialized
INFO - 2023-10-11 17:16:30 --> Security Class Initialized
DEBUG - 2023-10-11 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 17:16:30 --> Input Class Initialized
INFO - 2023-10-11 17:16:30 --> Language Class Initialized
INFO - 2023-10-11 17:16:30 --> Loader Class Initialized
INFO - 2023-10-11 17:16:30 --> Helper loaded: url_helper
INFO - 2023-10-11 17:16:30 --> Helper loaded: file_helper
INFO - 2023-10-11 17:16:30 --> Database Driver Class Initialized
INFO - 2023-10-11 17:16:30 --> Email Class Initialized
DEBUG - 2023-10-11 17:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 17:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 17:16:30 --> Controller Class Initialized
INFO - 2023-10-11 17:16:30 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/dashboard.php
INFO - 2023-10-11 17:16:30 --> Final output sent to browser
DEBUG - 2023-10-11 17:16:30 --> Total execution time: 0.0718
INFO - 2023-10-11 17:16:40 --> Config Class Initialized
INFO - 2023-10-11 17:16:40 --> Hooks Class Initialized
DEBUG - 2023-10-11 17:16:40 --> UTF-8 Support Enabled
INFO - 2023-10-11 17:16:40 --> Utf8 Class Initialized
INFO - 2023-10-11 17:16:40 --> URI Class Initialized
INFO - 2023-10-11 17:16:40 --> Router Class Initialized
INFO - 2023-10-11 17:16:40 --> Output Class Initialized
INFO - 2023-10-11 17:16:40 --> Security Class Initialized
DEBUG - 2023-10-11 17:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 17:16:40 --> Input Class Initialized
INFO - 2023-10-11 17:16:40 --> Language Class Initialized
INFO - 2023-10-11 17:16:40 --> Loader Class Initialized
INFO - 2023-10-11 17:16:40 --> Helper loaded: url_helper
INFO - 2023-10-11 17:16:40 --> Helper loaded: file_helper
INFO - 2023-10-11 17:16:40 --> Database Driver Class Initialized
INFO - 2023-10-11 17:16:40 --> Email Class Initialized
DEBUG - 2023-10-11 17:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 17:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 17:16:40 --> Controller Class Initialized
INFO - 2023-10-11 17:16:40 --> Model "Contact_model" initialized
INFO - 2023-10-11 17:16:40 --> Helper loaded: form_helper
INFO - 2023-10-11 17:16:40 --> Form Validation Class Initialized
INFO - 2023-10-11 17:16:40 --> File loaded: C:\xampp\htdocs\dw\application\views\admin/contact_list.php
INFO - 2023-10-11 17:16:40 --> Final output sent to browser
DEBUG - 2023-10-11 17:16:40 --> Total execution time: 0.1052
INFO - 2023-10-11 18:26:30 --> Config Class Initialized
INFO - 2023-10-11 18:26:30 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:26:30 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:26:30 --> Utf8 Class Initialized
INFO - 2023-10-11 18:26:30 --> URI Class Initialized
DEBUG - 2023-10-11 18:26:30 --> No URI present. Default controller set.
INFO - 2023-10-11 18:26:30 --> Router Class Initialized
INFO - 2023-10-11 18:26:30 --> Output Class Initialized
INFO - 2023-10-11 18:26:30 --> Security Class Initialized
DEBUG - 2023-10-11 18:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:26:30 --> Input Class Initialized
INFO - 2023-10-11 18:26:30 --> Language Class Initialized
INFO - 2023-10-11 18:26:30 --> Loader Class Initialized
INFO - 2023-10-11 18:26:30 --> Helper loaded: url_helper
INFO - 2023-10-11 18:26:30 --> Helper loaded: file_helper
INFO - 2023-10-11 18:26:31 --> Database Driver Class Initialized
INFO - 2023-10-11 18:26:31 --> Email Class Initialized
DEBUG - 2023-10-11 18:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:26:31 --> Controller Class Initialized
INFO - 2023-10-11 18:26:31 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:26:31 --> Model "Home_model" initialized
INFO - 2023-10-11 18:26:31 --> Helper loaded: download_helper
INFO - 2023-10-11 18:26:31 --> Helper loaded: form_helper
INFO - 2023-10-11 18:26:31 --> Form Validation Class Initialized
INFO - 2023-10-11 18:26:31 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:26:31 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:26:31 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 18:26:31 --> Final output sent to browser
DEBUG - 2023-10-11 18:26:31 --> Total execution time: 0.2430
INFO - 2023-10-11 18:32:10 --> Config Class Initialized
INFO - 2023-10-11 18:32:10 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:32:10 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:32:10 --> Utf8 Class Initialized
INFO - 2023-10-11 18:32:10 --> URI Class Initialized
DEBUG - 2023-10-11 18:32:10 --> No URI present. Default controller set.
INFO - 2023-10-11 18:32:10 --> Router Class Initialized
INFO - 2023-10-11 18:32:10 --> Output Class Initialized
INFO - 2023-10-11 18:32:10 --> Security Class Initialized
DEBUG - 2023-10-11 18:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:32:10 --> Input Class Initialized
INFO - 2023-10-11 18:32:10 --> Language Class Initialized
INFO - 2023-10-11 18:32:10 --> Loader Class Initialized
INFO - 2023-10-11 18:32:10 --> Helper loaded: url_helper
INFO - 2023-10-11 18:32:10 --> Helper loaded: file_helper
INFO - 2023-10-11 18:32:10 --> Database Driver Class Initialized
INFO - 2023-10-11 18:32:10 --> Email Class Initialized
DEBUG - 2023-10-11 18:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:32:10 --> Controller Class Initialized
INFO - 2023-10-11 18:32:10 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:32:10 --> Model "Home_model" initialized
INFO - 2023-10-11 18:32:10 --> Helper loaded: download_helper
INFO - 2023-10-11 18:32:10 --> Helper loaded: form_helper
INFO - 2023-10-11 18:32:10 --> Form Validation Class Initialized
INFO - 2023-10-11 18:32:10 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:32:10 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:32:10 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 18:32:10 --> Final output sent to browser
DEBUG - 2023-10-11 18:32:11 --> Total execution time: 0.3461
INFO - 2023-10-11 18:32:38 --> Config Class Initialized
INFO - 2023-10-11 18:32:38 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:32:38 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:32:38 --> Utf8 Class Initialized
INFO - 2023-10-11 18:32:38 --> URI Class Initialized
DEBUG - 2023-10-11 18:32:38 --> No URI present. Default controller set.
INFO - 2023-10-11 18:32:38 --> Router Class Initialized
INFO - 2023-10-11 18:32:38 --> Output Class Initialized
INFO - 2023-10-11 18:32:38 --> Security Class Initialized
DEBUG - 2023-10-11 18:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:32:38 --> Input Class Initialized
INFO - 2023-10-11 18:32:38 --> Language Class Initialized
INFO - 2023-10-11 18:32:38 --> Loader Class Initialized
INFO - 2023-10-11 18:32:38 --> Helper loaded: url_helper
INFO - 2023-10-11 18:32:38 --> Helper loaded: file_helper
INFO - 2023-10-11 18:32:38 --> Database Driver Class Initialized
INFO - 2023-10-11 18:32:38 --> Email Class Initialized
DEBUG - 2023-10-11 18:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:32:38 --> Controller Class Initialized
INFO - 2023-10-11 18:32:38 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:32:38 --> Model "Home_model" initialized
INFO - 2023-10-11 18:32:38 --> Helper loaded: download_helper
INFO - 2023-10-11 18:32:38 --> Helper loaded: form_helper
INFO - 2023-10-11 18:32:38 --> Form Validation Class Initialized
INFO - 2023-10-11 18:32:38 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:32:38 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:32:38 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 18:32:38 --> Final output sent to browser
DEBUG - 2023-10-11 18:32:38 --> Total execution time: 0.1616
INFO - 2023-10-11 18:33:11 --> Config Class Initialized
INFO - 2023-10-11 18:33:11 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:33:11 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:33:11 --> Utf8 Class Initialized
INFO - 2023-10-11 18:33:11 --> URI Class Initialized
DEBUG - 2023-10-11 18:33:11 --> No URI present. Default controller set.
INFO - 2023-10-11 18:33:11 --> Router Class Initialized
INFO - 2023-10-11 18:33:11 --> Output Class Initialized
INFO - 2023-10-11 18:33:11 --> Security Class Initialized
DEBUG - 2023-10-11 18:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:33:11 --> Input Class Initialized
INFO - 2023-10-11 18:33:11 --> Language Class Initialized
INFO - 2023-10-11 18:33:11 --> Loader Class Initialized
INFO - 2023-10-11 18:33:11 --> Helper loaded: url_helper
INFO - 2023-10-11 18:33:11 --> Helper loaded: file_helper
INFO - 2023-10-11 18:33:11 --> Database Driver Class Initialized
INFO - 2023-10-11 18:33:11 --> Email Class Initialized
DEBUG - 2023-10-11 18:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:33:11 --> Controller Class Initialized
INFO - 2023-10-11 18:33:11 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:33:11 --> Model "Home_model" initialized
INFO - 2023-10-11 18:33:11 --> Helper loaded: download_helper
INFO - 2023-10-11 18:33:11 --> Helper loaded: form_helper
INFO - 2023-10-11 18:33:11 --> Form Validation Class Initialized
INFO - 2023-10-11 18:33:11 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:33:11 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:33:11 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 18:33:11 --> Final output sent to browser
DEBUG - 2023-10-11 18:33:11 --> Total execution time: 0.1607
INFO - 2023-10-11 18:33:24 --> Config Class Initialized
INFO - 2023-10-11 18:33:24 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:33:24 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:33:24 --> Utf8 Class Initialized
INFO - 2023-10-11 18:33:24 --> URI Class Initialized
INFO - 2023-10-11 18:33:24 --> Router Class Initialized
INFO - 2023-10-11 18:33:24 --> Output Class Initialized
INFO - 2023-10-11 18:33:24 --> Security Class Initialized
DEBUG - 2023-10-11 18:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:33:24 --> Input Class Initialized
INFO - 2023-10-11 18:33:24 --> Language Class Initialized
INFO - 2023-10-11 18:33:24 --> Loader Class Initialized
INFO - 2023-10-11 18:33:24 --> Helper loaded: url_helper
INFO - 2023-10-11 18:33:24 --> Helper loaded: file_helper
INFO - 2023-10-11 18:33:24 --> Database Driver Class Initialized
INFO - 2023-10-11 18:33:24 --> Email Class Initialized
DEBUG - 2023-10-11 18:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:33:24 --> Controller Class Initialized
INFO - 2023-10-11 18:33:24 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:33:24 --> Model "Home_model" initialized
INFO - 2023-10-11 18:33:24 --> Helper loaded: download_helper
INFO - 2023-10-11 18:33:24 --> Helper loaded: form_helper
INFO - 2023-10-11 18:33:24 --> Form Validation Class Initialized
INFO - 2023-10-11 18:33:24 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:33:24 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:33:24 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-11 18:33:24 --> Final output sent to browser
DEBUG - 2023-10-11 18:33:24 --> Total execution time: 0.1365
INFO - 2023-10-11 18:34:33 --> Config Class Initialized
INFO - 2023-10-11 18:34:33 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:34:33 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:34:33 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:33 --> URI Class Initialized
INFO - 2023-10-11 18:34:33 --> Router Class Initialized
INFO - 2023-10-11 18:34:33 --> Output Class Initialized
INFO - 2023-10-11 18:34:33 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:33 --> Input Class Initialized
INFO - 2023-10-11 18:34:33 --> Language Class Initialized
ERROR - 2023-10-11 18:34:33 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:34:34 --> Config Class Initialized
INFO - 2023-10-11 18:34:34 --> Config Class Initialized
INFO - 2023-10-11 18:34:34 --> Hooks Class Initialized
INFO - 2023-10-11 18:34:34 --> Hooks Class Initialized
INFO - 2023-10-11 18:34:35 --> Config Class Initialized
INFO - 2023-10-11 18:34:35 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:34:35 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:34:35 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:35 --> URI Class Initialized
INFO - 2023-10-11 18:34:35 --> Router Class Initialized
INFO - 2023-10-11 18:34:35 --> Output Class Initialized
INFO - 2023-10-11 18:34:35 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:35 --> Input Class Initialized
INFO - 2023-10-11 18:34:35 --> Language Class Initialized
ERROR - 2023-10-11 18:34:35 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-11 18:34:35 --> UTF-8 Support Enabled
DEBUG - 2023-10-11 18:34:35 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:34:35 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:35 --> URI Class Initialized
INFO - 2023-10-11 18:34:35 --> Router Class Initialized
INFO - 2023-10-11 18:34:35 --> Output Class Initialized
INFO - 2023-10-11 18:34:35 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:35 --> Input Class Initialized
INFO - 2023-10-11 18:34:35 --> Language Class Initialized
ERROR - 2023-10-11 18:34:35 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:34:35 --> Config Class Initialized
INFO - 2023-10-11 18:34:35 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:34:35 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:34:35 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:35 --> URI Class Initialized
INFO - 2023-10-11 18:34:35 --> Router Class Initialized
INFO - 2023-10-11 18:34:35 --> Output Class Initialized
INFO - 2023-10-11 18:34:36 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:36 --> Config Class Initialized
INFO - 2023-10-11 18:34:36 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:36 --> Config Class Initialized
INFO - 2023-10-11 18:34:36 --> Input Class Initialized
INFO - 2023-10-11 18:34:36 --> URI Class Initialized
INFO - 2023-10-11 18:34:36 --> Router Class Initialized
INFO - 2023-10-11 18:34:36 --> Output Class Initialized
INFO - 2023-10-11 18:34:36 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:36 --> Input Class Initialized
INFO - 2023-10-11 18:34:36 --> Language Class Initialized
ERROR - 2023-10-11 18:34:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:34:36 --> Hooks Class Initialized
INFO - 2023-10-11 18:34:36 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:34:36 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:34:36 --> Language Class Initialized
DEBUG - 2023-10-11 18:34:36 --> UTF-8 Support Enabled
ERROR - 2023-10-11 18:34:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:34:36 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:36 --> Utf8 Class Initialized
INFO - 2023-10-11 18:34:36 --> URI Class Initialized
INFO - 2023-10-11 18:34:36 --> URI Class Initialized
INFO - 2023-10-11 18:34:36 --> Router Class Initialized
INFO - 2023-10-11 18:34:36 --> Output Class Initialized
INFO - 2023-10-11 18:34:36 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:36 --> Input Class Initialized
INFO - 2023-10-11 18:34:36 --> Language Class Initialized
ERROR - 2023-10-11 18:34:36 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:34:37 --> Router Class Initialized
INFO - 2023-10-11 18:34:38 --> Output Class Initialized
INFO - 2023-10-11 18:34:38 --> Security Class Initialized
DEBUG - 2023-10-11 18:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:34:38 --> Input Class Initialized
INFO - 2023-10-11 18:34:38 --> Language Class Initialized
ERROR - 2023-10-11 18:34:38 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 18:36:34 --> Config Class Initialized
INFO - 2023-10-11 18:36:34 --> Hooks Class Initialized
DEBUG - 2023-10-11 18:36:34 --> UTF-8 Support Enabled
INFO - 2023-10-11 18:36:35 --> Utf8 Class Initialized
INFO - 2023-10-11 18:36:35 --> URI Class Initialized
INFO - 2023-10-11 18:36:35 --> Router Class Initialized
INFO - 2023-10-11 18:36:35 --> Output Class Initialized
INFO - 2023-10-11 18:36:35 --> Security Class Initialized
DEBUG - 2023-10-11 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 18:36:35 --> Input Class Initialized
INFO - 2023-10-11 18:36:35 --> Language Class Initialized
INFO - 2023-10-11 18:36:35 --> Loader Class Initialized
INFO - 2023-10-11 18:36:35 --> Helper loaded: url_helper
INFO - 2023-10-11 18:36:35 --> Helper loaded: file_helper
INFO - 2023-10-11 18:36:35 --> Database Driver Class Initialized
INFO - 2023-10-11 18:36:35 --> Email Class Initialized
DEBUG - 2023-10-11 18:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 18:36:35 --> Controller Class Initialized
INFO - 2023-10-11 18:36:35 --> Model "Contact_model" initialized
INFO - 2023-10-11 18:36:35 --> Model "Home_model" initialized
INFO - 2023-10-11 18:36:35 --> Helper loaded: download_helper
INFO - 2023-10-11 18:36:35 --> Helper loaded: form_helper
INFO - 2023-10-11 18:36:35 --> Form Validation Class Initialized
INFO - 2023-10-11 18:36:35 --> Helper loaded: custom_helper
INFO - 2023-10-11 18:36:35 --> Model "Social_media_model" initialized
INFO - 2023-10-11 18:36:35 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-11 18:36:35 --> Final output sent to browser
DEBUG - 2023-10-11 18:36:35 --> Total execution time: 0.1259
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:55 --> Config Class Initialized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
INFO - 2023-10-11 19:04:55 --> Hooks Class Initialized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:55 --> Security Class Initialized
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-11 19:04:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-11 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Input Class Initialized
INFO - 2023-10-11 19:04:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
INFO - 2023-10-11 19:04:55 --> Language Class Initialized
INFO - 2023-10-11 19:04:55 --> URI Class Initialized
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:04:55 --> Router Class Initialized
ERROR - 2023-10-11 19:04:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:04:55 --> Output Class Initialized
INFO - 2023-10-11 19:04:56 --> Security Class Initialized
DEBUG - 2023-10-11 19:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:04:56 --> Input Class Initialized
INFO - 2023-10-11 19:04:56 --> Language Class Initialized
ERROR - 2023-10-11 19:04:56 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:11:30 --> Config Class Initialized
INFO - 2023-10-11 19:11:30 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:11:30 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:11:30 --> Utf8 Class Initialized
INFO - 2023-10-11 19:11:30 --> URI Class Initialized
INFO - 2023-10-11 19:11:30 --> Router Class Initialized
INFO - 2023-10-11 19:11:30 --> Output Class Initialized
INFO - 2023-10-11 19:11:30 --> Security Class Initialized
DEBUG - 2023-10-11 19:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:11:30 --> Input Class Initialized
INFO - 2023-10-11 19:11:30 --> Language Class Initialized
INFO - 2023-10-11 19:11:30 --> Loader Class Initialized
INFO - 2023-10-11 19:11:30 --> Helper loaded: url_helper
INFO - 2023-10-11 19:11:30 --> Helper loaded: file_helper
INFO - 2023-10-11 19:11:30 --> Database Driver Class Initialized
INFO - 2023-10-11 19:11:30 --> Email Class Initialized
DEBUG - 2023-10-11 19:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:11:30 --> Controller Class Initialized
INFO - 2023-10-11 19:11:30 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:11:30 --> Model "Home_model" initialized
INFO - 2023-10-11 19:11:30 --> Helper loaded: download_helper
INFO - 2023-10-11 19:11:30 --> Helper loaded: form_helper
INFO - 2023-10-11 19:11:30 --> Form Validation Class Initialized
INFO - 2023-10-11 19:11:30 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:11:30 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:11:30 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-11 19:11:30 --> Final output sent to browser
DEBUG - 2023-10-11 19:11:30 --> Total execution time: 0.1430
INFO - 2023-10-11 19:11:32 --> Config Class Initialized
INFO - 2023-10-11 19:11:32 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:11:32 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:11:32 --> Utf8 Class Initialized
INFO - 2023-10-11 19:11:32 --> URI Class Initialized
INFO - 2023-10-11 19:11:32 --> Router Class Initialized
INFO - 2023-10-11 19:11:32 --> Output Class Initialized
INFO - 2023-10-11 19:11:32 --> Security Class Initialized
DEBUG - 2023-10-11 19:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:11:32 --> Input Class Initialized
INFO - 2023-10-11 19:11:32 --> Language Class Initialized
ERROR - 2023-10-11 19:11:32 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:11:49 --> Config Class Initialized
INFO - 2023-10-11 19:11:49 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:11:49 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:11:49 --> Utf8 Class Initialized
INFO - 2023-10-11 19:11:49 --> URI Class Initialized
INFO - 2023-10-11 19:11:49 --> Router Class Initialized
INFO - 2023-10-11 19:11:49 --> Output Class Initialized
INFO - 2023-10-11 19:11:49 --> Security Class Initialized
DEBUG - 2023-10-11 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:11:49 --> Input Class Initialized
INFO - 2023-10-11 19:11:49 --> Language Class Initialized
INFO - 2023-10-11 19:11:49 --> Loader Class Initialized
INFO - 2023-10-11 19:11:49 --> Helper loaded: url_helper
INFO - 2023-10-11 19:11:49 --> Helper loaded: file_helper
INFO - 2023-10-11 19:11:49 --> Database Driver Class Initialized
INFO - 2023-10-11 19:11:49 --> Email Class Initialized
DEBUG - 2023-10-11 19:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:11:49 --> Controller Class Initialized
INFO - 2023-10-11 19:11:49 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:11:49 --> Model "Home_model" initialized
INFO - 2023-10-11 19:11:49 --> Helper loaded: download_helper
INFO - 2023-10-11 19:11:49 --> Helper loaded: form_helper
INFO - 2023-10-11 19:11:49 --> Form Validation Class Initialized
INFO - 2023-10-11 19:11:49 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:11:49 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:11:49 --> File loaded: C:\xampp\htdocs\dw\application\views\home/blog.php
INFO - 2023-10-11 19:11:49 --> Final output sent to browser
DEBUG - 2023-10-11 19:11:49 --> Total execution time: 0.1247
INFO - 2023-10-11 19:12:25 --> Config Class Initialized
INFO - 2023-10-11 19:12:25 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:12:25 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:12:25 --> Utf8 Class Initialized
INFO - 2023-10-11 19:12:25 --> URI Class Initialized
DEBUG - 2023-10-11 19:12:25 --> No URI present. Default controller set.
INFO - 2023-10-11 19:12:25 --> Router Class Initialized
INFO - 2023-10-11 19:12:25 --> Output Class Initialized
INFO - 2023-10-11 19:12:25 --> Security Class Initialized
DEBUG - 2023-10-11 19:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:12:25 --> Input Class Initialized
INFO - 2023-10-11 19:12:25 --> Language Class Initialized
INFO - 2023-10-11 19:12:25 --> Loader Class Initialized
INFO - 2023-10-11 19:12:25 --> Helper loaded: url_helper
INFO - 2023-10-11 19:12:25 --> Helper loaded: file_helper
INFO - 2023-10-11 19:12:25 --> Database Driver Class Initialized
INFO - 2023-10-11 19:12:25 --> Email Class Initialized
DEBUG - 2023-10-11 19:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:12:25 --> Controller Class Initialized
INFO - 2023-10-11 19:12:25 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:12:25 --> Model "Home_model" initialized
INFO - 2023-10-11 19:12:25 --> Helper loaded: download_helper
INFO - 2023-10-11 19:12:25 --> Helper loaded: form_helper
INFO - 2023-10-11 19:12:25 --> Form Validation Class Initialized
INFO - 2023-10-11 19:12:25 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:12:25 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:12:25 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:12:25 --> Final output sent to browser
DEBUG - 2023-10-11 19:12:25 --> Total execution time: 0.1683
INFO - 2023-10-11 19:13:37 --> Config Class Initialized
INFO - 2023-10-11 19:13:37 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:37 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:37 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:37 --> URI Class Initialized
DEBUG - 2023-10-11 19:13:37 --> No URI present. Default controller set.
INFO - 2023-10-11 19:13:37 --> Router Class Initialized
INFO - 2023-10-11 19:13:37 --> Output Class Initialized
INFO - 2023-10-11 19:13:37 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:37 --> Input Class Initialized
INFO - 2023-10-11 19:13:37 --> Language Class Initialized
INFO - 2023-10-11 19:13:37 --> Loader Class Initialized
INFO - 2023-10-11 19:13:37 --> Helper loaded: url_helper
INFO - 2023-10-11 19:13:37 --> Helper loaded: file_helper
INFO - 2023-10-11 19:13:37 --> Database Driver Class Initialized
INFO - 2023-10-11 19:13:37 --> Email Class Initialized
DEBUG - 2023-10-11 19:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:13:37 --> Controller Class Initialized
INFO - 2023-10-11 19:13:37 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:13:37 --> Model "Home_model" initialized
INFO - 2023-10-11 19:13:37 --> Helper loaded: download_helper
INFO - 2023-10-11 19:13:37 --> Helper loaded: form_helper
INFO - 2023-10-11 19:13:37 --> Form Validation Class Initialized
INFO - 2023-10-11 19:13:37 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:13:37 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:13:37 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:13:37 --> Final output sent to browser
DEBUG - 2023-10-11 19:13:38 --> Total execution time: 0.3137
INFO - 2023-10-11 19:13:53 --> Config Class Initialized
INFO - 2023-10-11 19:13:53 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:53 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:53 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:53 --> URI Class Initialized
INFO - 2023-10-11 19:13:53 --> Router Class Initialized
INFO - 2023-10-11 19:13:53 --> Output Class Initialized
INFO - 2023-10-11 19:13:53 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:53 --> Input Class Initialized
INFO - 2023-10-11 19:13:53 --> Language Class Initialized
ERROR - 2023-10-11 19:13:53 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:53 --> Config Class Initialized
INFO - 2023-10-11 19:13:53 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:53 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:53 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:53 --> URI Class Initialized
INFO - 2023-10-11 19:13:53 --> Router Class Initialized
INFO - 2023-10-11 19:13:53 --> Output Class Initialized
INFO - 2023-10-11 19:13:53 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:53 --> Input Class Initialized
INFO - 2023-10-11 19:13:53 --> Language Class Initialized
ERROR - 2023-10-11 19:13:53 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:53 --> Config Class Initialized
INFO - 2023-10-11 19:13:53 --> Config Class Initialized
INFO - 2023-10-11 19:13:53 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:53 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:53 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:53 --> URI Class Initialized
INFO - 2023-10-11 19:13:53 --> Router Class Initialized
INFO - 2023-10-11 19:13:53 --> Output Class Initialized
INFO - 2023-10-11 19:13:53 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:53 --> Input Class Initialized
INFO - 2023-10-11 19:13:53 --> Language Class Initialized
ERROR - 2023-10-11 19:13:53 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:54 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:54 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:54 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:54 --> URI Class Initialized
INFO - 2023-10-11 19:13:54 --> Router Class Initialized
INFO - 2023-10-11 19:13:54 --> Output Class Initialized
INFO - 2023-10-11 19:13:54 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:54 --> Input Class Initialized
INFO - 2023-10-11 19:13:54 --> Language Class Initialized
ERROR - 2023-10-11 19:13:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:54 --> Config Class Initialized
INFO - 2023-10-11 19:13:54 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:54 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:54 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:54 --> URI Class Initialized
INFO - 2023-10-11 19:13:54 --> Router Class Initialized
INFO - 2023-10-11 19:13:54 --> Output Class Initialized
INFO - 2023-10-11 19:13:54 --> Security Class Initialized
DEBUG - 2023-10-11 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:54 --> Input Class Initialized
INFO - 2023-10-11 19:13:54 --> Language Class Initialized
ERROR - 2023-10-11 19:13:54 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:55 --> Config Class Initialized
INFO - 2023-10-11 19:13:55 --> Config Class Initialized
INFO - 2023-10-11 19:13:55 --> Hooks Class Initialized
INFO - 2023-10-11 19:13:55 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-10-11 19:13:55 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:13:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:55 --> URI Class Initialized
INFO - 2023-10-11 19:13:55 --> Utf8 Class Initialized
INFO - 2023-10-11 19:13:55 --> Router Class Initialized
INFO - 2023-10-11 19:13:55 --> URI Class Initialized
INFO - 2023-10-11 19:13:55 --> Output Class Initialized
INFO - 2023-10-11 19:13:55 --> Router Class Initialized
INFO - 2023-10-11 19:13:55 --> Security Class Initialized
INFO - 2023-10-11 19:13:55 --> Output Class Initialized
DEBUG - 2023-10-11 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:55 --> Security Class Initialized
INFO - 2023-10-11 19:13:55 --> Input Class Initialized
DEBUG - 2023-10-11 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:13:55 --> Language Class Initialized
INFO - 2023-10-11 19:13:55 --> Input Class Initialized
ERROR - 2023-10-11 19:13:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:13:55 --> Language Class Initialized
ERROR - 2023-10-11 19:13:55 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:17:42 --> Config Class Initialized
INFO - 2023-10-11 19:17:42 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:17:42 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:17:42 --> Utf8 Class Initialized
INFO - 2023-10-11 19:17:42 --> URI Class Initialized
DEBUG - 2023-10-11 19:17:42 --> No URI present. Default controller set.
INFO - 2023-10-11 19:17:42 --> Router Class Initialized
INFO - 2023-10-11 19:17:42 --> Output Class Initialized
INFO - 2023-10-11 19:17:42 --> Security Class Initialized
DEBUG - 2023-10-11 19:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:17:42 --> Input Class Initialized
INFO - 2023-10-11 19:17:42 --> Language Class Initialized
INFO - 2023-10-11 19:17:42 --> Loader Class Initialized
INFO - 2023-10-11 19:17:42 --> Helper loaded: url_helper
INFO - 2023-10-11 19:17:42 --> Helper loaded: file_helper
INFO - 2023-10-11 19:17:42 --> Database Driver Class Initialized
INFO - 2023-10-11 19:17:42 --> Email Class Initialized
DEBUG - 2023-10-11 19:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:17:42 --> Controller Class Initialized
INFO - 2023-10-11 19:17:42 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:17:42 --> Model "Home_model" initialized
INFO - 2023-10-11 19:17:42 --> Helper loaded: download_helper
INFO - 2023-10-11 19:17:42 --> Helper loaded: form_helper
INFO - 2023-10-11 19:17:42 --> Form Validation Class Initialized
INFO - 2023-10-11 19:17:42 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:17:42 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:17:42 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:17:42 --> Final output sent to browser
DEBUG - 2023-10-11 19:17:42 --> Total execution time: 0.1576
INFO - 2023-10-11 19:18:13 --> Config Class Initialized
INFO - 2023-10-11 19:18:13 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:18:13 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:18:13 --> Utf8 Class Initialized
INFO - 2023-10-11 19:18:13 --> URI Class Initialized
DEBUG - 2023-10-11 19:18:13 --> No URI present. Default controller set.
INFO - 2023-10-11 19:18:13 --> Router Class Initialized
INFO - 2023-10-11 19:18:13 --> Output Class Initialized
INFO - 2023-10-11 19:18:13 --> Security Class Initialized
DEBUG - 2023-10-11 19:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:18:13 --> Input Class Initialized
INFO - 2023-10-11 19:18:13 --> Language Class Initialized
INFO - 2023-10-11 19:18:13 --> Loader Class Initialized
INFO - 2023-10-11 19:18:13 --> Helper loaded: url_helper
INFO - 2023-10-11 19:18:13 --> Helper loaded: file_helper
INFO - 2023-10-11 19:18:13 --> Database Driver Class Initialized
INFO - 2023-10-11 19:18:13 --> Email Class Initialized
DEBUG - 2023-10-11 19:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:18:13 --> Controller Class Initialized
INFO - 2023-10-11 19:18:13 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:18:13 --> Model "Home_model" initialized
INFO - 2023-10-11 19:18:13 --> Helper loaded: download_helper
INFO - 2023-10-11 19:18:13 --> Helper loaded: form_helper
INFO - 2023-10-11 19:18:13 --> Form Validation Class Initialized
INFO - 2023-10-11 19:18:13 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:18:13 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:18:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:18:13 --> Final output sent to browser
DEBUG - 2023-10-11 19:18:14 --> Total execution time: 0.1554
INFO - 2023-10-11 19:18:41 --> Config Class Initialized
INFO - 2023-10-11 19:18:41 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:18:41 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:18:41 --> Utf8 Class Initialized
INFO - 2023-10-11 19:18:41 --> URI Class Initialized
DEBUG - 2023-10-11 19:18:41 --> No URI present. Default controller set.
INFO - 2023-10-11 19:18:41 --> Router Class Initialized
INFO - 2023-10-11 19:18:41 --> Output Class Initialized
INFO - 2023-10-11 19:18:41 --> Security Class Initialized
DEBUG - 2023-10-11 19:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:18:41 --> Input Class Initialized
INFO - 2023-10-11 19:18:41 --> Language Class Initialized
INFO - 2023-10-11 19:18:41 --> Loader Class Initialized
INFO - 2023-10-11 19:18:41 --> Helper loaded: url_helper
INFO - 2023-10-11 19:18:41 --> Helper loaded: file_helper
INFO - 2023-10-11 19:18:41 --> Database Driver Class Initialized
INFO - 2023-10-11 19:18:41 --> Email Class Initialized
DEBUG - 2023-10-11 19:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:18:41 --> Controller Class Initialized
INFO - 2023-10-11 19:18:41 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:18:41 --> Model "Home_model" initialized
INFO - 2023-10-11 19:18:41 --> Helper loaded: download_helper
INFO - 2023-10-11 19:18:41 --> Helper loaded: form_helper
INFO - 2023-10-11 19:18:41 --> Form Validation Class Initialized
INFO - 2023-10-11 19:18:41 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:18:41 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:18:41 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:18:41 --> Final output sent to browser
DEBUG - 2023-10-11 19:18:41 --> Total execution time: 0.1272
INFO - 2023-10-11 19:21:28 --> Config Class Initialized
INFO - 2023-10-11 19:21:28 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:21:28 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:21:28 --> Utf8 Class Initialized
INFO - 2023-10-11 19:21:28 --> URI Class Initialized
DEBUG - 2023-10-11 19:21:28 --> No URI present. Default controller set.
INFO - 2023-10-11 19:21:28 --> Router Class Initialized
INFO - 2023-10-11 19:21:28 --> Output Class Initialized
INFO - 2023-10-11 19:21:28 --> Security Class Initialized
DEBUG - 2023-10-11 19:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:21:28 --> Input Class Initialized
INFO - 2023-10-11 19:21:28 --> Language Class Initialized
INFO - 2023-10-11 19:21:28 --> Loader Class Initialized
INFO - 2023-10-11 19:21:28 --> Helper loaded: url_helper
INFO - 2023-10-11 19:21:28 --> Helper loaded: file_helper
INFO - 2023-10-11 19:21:28 --> Database Driver Class Initialized
INFO - 2023-10-11 19:21:28 --> Email Class Initialized
DEBUG - 2023-10-11 19:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:21:28 --> Controller Class Initialized
INFO - 2023-10-11 19:21:28 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:21:28 --> Model "Home_model" initialized
INFO - 2023-10-11 19:21:28 --> Helper loaded: download_helper
INFO - 2023-10-11 19:21:28 --> Helper loaded: form_helper
INFO - 2023-10-11 19:21:28 --> Form Validation Class Initialized
INFO - 2023-10-11 19:21:28 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:21:28 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:21:28 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:21:28 --> Final output sent to browser
DEBUG - 2023-10-11 19:21:28 --> Total execution time: 0.1961
INFO - 2023-10-11 19:23:17 --> Config Class Initialized
INFO - 2023-10-11 19:23:17 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:17 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:17 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:17 --> URI Class Initialized
INFO - 2023-10-11 19:23:17 --> Router Class Initialized
INFO - 2023-10-11 19:23:17 --> Output Class Initialized
INFO - 2023-10-11 19:23:17 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:17 --> Input Class Initialized
INFO - 2023-10-11 19:23:17 --> Language Class Initialized
ERROR - 2023-10-11 19:23:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:17 --> Config Class Initialized
INFO - 2023-10-11 19:23:17 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:17 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:17 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:17 --> URI Class Initialized
INFO - 2023-10-11 19:23:17 --> Router Class Initialized
INFO - 2023-10-11 19:23:17 --> Output Class Initialized
INFO - 2023-10-11 19:23:17 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:17 --> Input Class Initialized
INFO - 2023-10-11 19:23:17 --> Language Class Initialized
ERROR - 2023-10-11 19:23:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:17 --> Config Class Initialized
INFO - 2023-10-11 19:23:17 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:17 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:17 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:17 --> URI Class Initialized
INFO - 2023-10-11 19:23:17 --> Router Class Initialized
INFO - 2023-10-11 19:23:17 --> Output Class Initialized
INFO - 2023-10-11 19:23:17 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:17 --> Input Class Initialized
INFO - 2023-10-11 19:23:17 --> Language Class Initialized
ERROR - 2023-10-11 19:23:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:18 --> Config Class Initialized
INFO - 2023-10-11 19:23:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:18 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:18 --> URI Class Initialized
INFO - 2023-10-11 19:23:18 --> Router Class Initialized
INFO - 2023-10-11 19:23:18 --> Output Class Initialized
INFO - 2023-10-11 19:23:18 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:18 --> Input Class Initialized
INFO - 2023-10-11 19:23:18 --> Language Class Initialized
ERROR - 2023-10-11 19:23:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:18 --> Config Class Initialized
INFO - 2023-10-11 19:23:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:18 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:18 --> URI Class Initialized
INFO - 2023-10-11 19:23:18 --> Router Class Initialized
INFO - 2023-10-11 19:23:18 --> Output Class Initialized
INFO - 2023-10-11 19:23:18 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:18 --> Input Class Initialized
INFO - 2023-10-11 19:23:18 --> Language Class Initialized
ERROR - 2023-10-11 19:23:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:18 --> Config Class Initialized
INFO - 2023-10-11 19:23:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:18 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:18 --> URI Class Initialized
INFO - 2023-10-11 19:23:18 --> Router Class Initialized
INFO - 2023-10-11 19:23:18 --> Output Class Initialized
INFO - 2023-10-11 19:23:18 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:18 --> Input Class Initialized
INFO - 2023-10-11 19:23:18 --> Language Class Initialized
ERROR - 2023-10-11 19:23:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:23:18 --> Config Class Initialized
INFO - 2023-10-11 19:23:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:23:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:23:18 --> Utf8 Class Initialized
INFO - 2023-10-11 19:23:18 --> URI Class Initialized
INFO - 2023-10-11 19:23:18 --> Router Class Initialized
INFO - 2023-10-11 19:23:18 --> Output Class Initialized
INFO - 2023-10-11 19:23:18 --> Security Class Initialized
DEBUG - 2023-10-11 19:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:23:18 --> Input Class Initialized
INFO - 2023-10-11 19:23:18 --> Language Class Initialized
ERROR - 2023-10-11 19:23:18 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:24:13 --> Config Class Initialized
INFO - 2023-10-11 19:24:13 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:13 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:13 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:13 --> URI Class Initialized
DEBUG - 2023-10-11 19:24:13 --> No URI present. Default controller set.
INFO - 2023-10-11 19:24:13 --> Router Class Initialized
INFO - 2023-10-11 19:24:13 --> Output Class Initialized
INFO - 2023-10-11 19:24:13 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:13 --> Input Class Initialized
INFO - 2023-10-11 19:24:13 --> Language Class Initialized
INFO - 2023-10-11 19:24:13 --> Loader Class Initialized
INFO - 2023-10-11 19:24:13 --> Helper loaded: url_helper
INFO - 2023-10-11 19:24:13 --> Helper loaded: file_helper
INFO - 2023-10-11 19:24:13 --> Database Driver Class Initialized
INFO - 2023-10-11 19:24:13 --> Email Class Initialized
DEBUG - 2023-10-11 19:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:24:13 --> Controller Class Initialized
INFO - 2023-10-11 19:24:13 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:24:13 --> Model "Home_model" initialized
INFO - 2023-10-11 19:24:13 --> Helper loaded: download_helper
INFO - 2023-10-11 19:24:13 --> Helper loaded: form_helper
INFO - 2023-10-11 19:24:13 --> Form Validation Class Initialized
INFO - 2023-10-11 19:24:13 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:24:13 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:24:13 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:24:13 --> Final output sent to browser
DEBUG - 2023-10-11 19:24:13 --> Total execution time: 0.1123
INFO - 2023-10-11 19:24:15 --> Config Class Initialized
INFO - 2023-10-11 19:24:15 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:15 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:15 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:15 --> URI Class Initialized
INFO - 2023-10-11 19:24:15 --> Router Class Initialized
INFO - 2023-10-11 19:24:15 --> Output Class Initialized
INFO - 2023-10-11 19:24:15 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:15 --> Input Class Initialized
INFO - 2023-10-11 19:24:15 --> Language Class Initialized
ERROR - 2023-10-11 19:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:24:15 --> Config Class Initialized
INFO - 2023-10-11 19:24:15 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:15 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:15 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:15 --> URI Class Initialized
INFO - 2023-10-11 19:24:15 --> Router Class Initialized
INFO - 2023-10-11 19:24:15 --> Output Class Initialized
INFO - 2023-10-11 19:24:15 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:15 --> Input Class Initialized
INFO - 2023-10-11 19:24:15 --> Language Class Initialized
ERROR - 2023-10-11 19:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:24:15 --> Config Class Initialized
INFO - 2023-10-11 19:24:15 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:15 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:15 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:15 --> URI Class Initialized
INFO - 2023-10-11 19:24:15 --> Router Class Initialized
INFO - 2023-10-11 19:24:15 --> Output Class Initialized
INFO - 2023-10-11 19:24:15 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:15 --> Input Class Initialized
INFO - 2023-10-11 19:24:15 --> Language Class Initialized
ERROR - 2023-10-11 19:24:15 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:24:16 --> Config Class Initialized
INFO - 2023-10-11 19:24:16 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:16 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:16 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:16 --> URI Class Initialized
INFO - 2023-10-11 19:24:16 --> Router Class Initialized
INFO - 2023-10-11 19:24:16 --> Output Class Initialized
INFO - 2023-10-11 19:24:16 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:16 --> Input Class Initialized
INFO - 2023-10-11 19:24:16 --> Language Class Initialized
ERROR - 2023-10-11 19:24:16 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:24:17 --> Config Class Initialized
INFO - 2023-10-11 19:24:17 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:24:17 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:24:17 --> Utf8 Class Initialized
INFO - 2023-10-11 19:24:17 --> URI Class Initialized
INFO - 2023-10-11 19:24:17 --> Router Class Initialized
INFO - 2023-10-11 19:24:17 --> Output Class Initialized
INFO - 2023-10-11 19:24:17 --> Security Class Initialized
DEBUG - 2023-10-11 19:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:24:17 --> Input Class Initialized
INFO - 2023-10-11 19:24:17 --> Language Class Initialized
ERROR - 2023-10-11 19:24:17 --> 404 Page Not Found: Assets/home
INFO - 2023-10-11 19:25:14 --> Config Class Initialized
INFO - 2023-10-11 19:25:14 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:25:14 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:25:14 --> Utf8 Class Initialized
INFO - 2023-10-11 19:25:14 --> URI Class Initialized
DEBUG - 2023-10-11 19:25:14 --> No URI present. Default controller set.
INFO - 2023-10-11 19:25:14 --> Router Class Initialized
INFO - 2023-10-11 19:25:14 --> Output Class Initialized
INFO - 2023-10-11 19:25:14 --> Security Class Initialized
DEBUG - 2023-10-11 19:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:25:14 --> Input Class Initialized
INFO - 2023-10-11 19:25:14 --> Language Class Initialized
INFO - 2023-10-11 19:25:14 --> Loader Class Initialized
INFO - 2023-10-11 19:25:14 --> Helper loaded: url_helper
INFO - 2023-10-11 19:25:14 --> Helper loaded: file_helper
INFO - 2023-10-11 19:25:14 --> Database Driver Class Initialized
INFO - 2023-10-11 19:25:14 --> Email Class Initialized
DEBUG - 2023-10-11 19:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:25:14 --> Controller Class Initialized
INFO - 2023-10-11 19:25:14 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:25:14 --> Model "Home_model" initialized
INFO - 2023-10-11 19:25:14 --> Helper loaded: download_helper
INFO - 2023-10-11 19:25:14 --> Helper loaded: form_helper
INFO - 2023-10-11 19:25:14 --> Form Validation Class Initialized
INFO - 2023-10-11 19:25:14 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:25:14 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:25:14 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:25:14 --> Final output sent to browser
DEBUG - 2023-10-11 19:25:15 --> Total execution time: 0.1712
INFO - 2023-10-11 19:26:01 --> Config Class Initialized
INFO - 2023-10-11 19:26:01 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:26:01 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:26:01 --> Utf8 Class Initialized
INFO - 2023-10-11 19:26:01 --> URI Class Initialized
DEBUG - 2023-10-11 19:26:01 --> No URI present. Default controller set.
INFO - 2023-10-11 19:26:01 --> Router Class Initialized
INFO - 2023-10-11 19:26:01 --> Output Class Initialized
INFO - 2023-10-11 19:26:01 --> Security Class Initialized
DEBUG - 2023-10-11 19:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:26:01 --> Input Class Initialized
INFO - 2023-10-11 19:26:01 --> Language Class Initialized
INFO - 2023-10-11 19:26:01 --> Loader Class Initialized
INFO - 2023-10-11 19:26:01 --> Helper loaded: url_helper
INFO - 2023-10-11 19:26:01 --> Helper loaded: file_helper
INFO - 2023-10-11 19:26:01 --> Database Driver Class Initialized
INFO - 2023-10-11 19:26:01 --> Email Class Initialized
DEBUG - 2023-10-11 19:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:26:01 --> Controller Class Initialized
INFO - 2023-10-11 19:26:01 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:26:01 --> Model "Home_model" initialized
INFO - 2023-10-11 19:26:01 --> Helper loaded: download_helper
INFO - 2023-10-11 19:26:01 --> Helper loaded: form_helper
INFO - 2023-10-11 19:26:01 --> Form Validation Class Initialized
INFO - 2023-10-11 19:26:01 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:26:01 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:26:01 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:26:01 --> Final output sent to browser
DEBUG - 2023-10-11 19:26:02 --> Total execution time: 0.1537
INFO - 2023-10-11 19:26:22 --> Config Class Initialized
INFO - 2023-10-11 19:26:22 --> Hooks Class Initialized
DEBUG - 2023-10-11 19:26:22 --> UTF-8 Support Enabled
INFO - 2023-10-11 19:26:22 --> Utf8 Class Initialized
INFO - 2023-10-11 19:26:22 --> URI Class Initialized
DEBUG - 2023-10-11 19:26:22 --> No URI present. Default controller set.
INFO - 2023-10-11 19:26:22 --> Router Class Initialized
INFO - 2023-10-11 19:26:22 --> Output Class Initialized
INFO - 2023-10-11 19:26:22 --> Security Class Initialized
DEBUG - 2023-10-11 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 19:26:22 --> Input Class Initialized
INFO - 2023-10-11 19:26:22 --> Language Class Initialized
INFO - 2023-10-11 19:26:22 --> Loader Class Initialized
INFO - 2023-10-11 19:26:22 --> Helper loaded: url_helper
INFO - 2023-10-11 19:26:22 --> Helper loaded: file_helper
INFO - 2023-10-11 19:26:22 --> Database Driver Class Initialized
INFO - 2023-10-11 19:26:22 --> Email Class Initialized
DEBUG - 2023-10-11 19:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 19:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 19:26:22 --> Controller Class Initialized
INFO - 2023-10-11 19:26:22 --> Model "Contact_model" initialized
INFO - 2023-10-11 19:26:22 --> Model "Home_model" initialized
INFO - 2023-10-11 19:26:22 --> Helper loaded: download_helper
INFO - 2023-10-11 19:26:22 --> Helper loaded: form_helper
INFO - 2023-10-11 19:26:22 --> Form Validation Class Initialized
INFO - 2023-10-11 19:26:22 --> Helper loaded: custom_helper
INFO - 2023-10-11 19:26:22 --> Model "Social_media_model" initialized
INFO - 2023-10-11 19:26:22 --> File loaded: C:\xampp\htdocs\dw\application\views\home/index.php
INFO - 2023-10-11 19:26:22 --> Final output sent to browser
DEBUG - 2023-10-11 19:26:23 --> Total execution time: 0.1834
